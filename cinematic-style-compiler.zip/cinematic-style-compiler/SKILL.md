---
name: cinematic-style-compiler
description: 从电影、电视剧、短剧或广告的多张原始静帧与片段中建立可解释的 FILM_AESTHETIC_MODEL，并把影片级美学 DNA、叙事阶段、镜头功能语法和锚点联动关系编译为可复刻、可回验的 REPLICATION_SPEC。用于“影视美学锚点提取”“分析电影镜头语法”“复刻某部影片的美学系统”“把原片美学迁移到新内容”“判断生成图为什么只有色调像、构图或焦点不像”等任务；核心是证据建模、条件语法、锚点耦合、复刻编译和相似性回验，不以片名、道具堆或单张构图模板替代分析。普通最终生图 Prompt、单图严格复刻、剧情改写或仅需调色时不要使用。
---

# 影视美学分析与复刻编译

## 职责

本 Skill 是 `CAP-STY-001` 的项目级 `active_candidate` 实现，核心产物只有两个：

1. `FILM_AESTHETIC_MODEL`：从原片证据中建立影片美学系统。
2. `REPLICATION_SPEC`：把该系统条件化地复刻到目标镜头。

内容防串线、空间物理和人物差异是复刻边界，不是分析核心。最终 AI 生图 Prompt 仍由 `image-prompt-director` 编译；单图结构严格复刻交给 `reference-prompt-reconstruction`；正式视频 Prompt 交给 AI 视频项目权威。

## 必读资源

按任务读取：

1. 输入角色与证据边界：[references/source-role-ledger.md](references/source-role-ledger.md)
2. 十轴分析、镜头功能和锚点耦合：[references/aesthetic-analysis-system.md](references/aesthetic-analysis-system.md)
3. 多帧证据提取：[references/aesthetic-anchor-extraction.md](references/aesthetic-anchor-extraction.md)
4. 从美学模型到复刻规格：[references/replication-compiler.md](references/replication-compiler.md)
5. 结构化输出合同：[references/anchor-output-contract.md](references/anchor-output-contract.md)
6. 结果相似性回验：[references/validation-rubric.md](references/validation-rubric.md)

发生属性冲突时读取 [references/contradiction-audit.md](references/contradiction-audit.md)；跨内容迁移出现建筑、道具、前景或构图串线时才读取 [references/content-framework-first.md](references/content-framework-first.md)；案例分析读取 [references/a-beautiful-mind-aesthetic-anchor-case.md](references/a-beautiful-mind-aesthetic-anchor-case.md)。

只有片名、主创名或文字风格说明而没有可见原片素材时，读取 [references/source-routing.md](references/source-routing.md)，先补证据或明确降级，不直接伪造影片级模型。

## 核心原则

- **分析关系，不收集名词**：合格锚点说明若干视觉属性如何共同控制观众注意与情绪。
- **建模条件，不求平均**：影片可以有多套叙事阶段和镜头功能语法；不把它们平均成一个滤镜。
- **复刻系统，不复印画面**：复刻的是观看方式、空间组织、焦点选择、光色、介质和表演关系，不是重复同一窗框、墙、道具或人物位置。
- **全量复刻优先**：影片模型形成后，首次复刻必须保留所有与目标镜头相关的锚点束、条件和护栏；在真实结果证明复现前，不讨论最小载荷或 Prompt 压缩。
- **相似性与内容正确性分账**：一张图可以内容正确但美学漂移，也可以美学接近却发生内容污染。

## 工作流程

### 1. 建立证据语料库

把每项输入标为：

- `AESTHETIC_SOURCE`：原片静帧或视频。
- `TARGET_CONTENT`：新画面的内容合同。
- `VALIDATION_OUTPUT`：按锚点生成的结果。
- `FAILURE_OUTPUT`：失败结果。
- `TEXT_CONTEXT`：片名、主创说明、年代与文字资料。

原片和生成结果不能混为同一种证据。文字资料可解释主创意图，但不能替代画面观察。

### 2. 建立证据覆盖图

先记录语料覆盖了哪些：

- 叙事阶段；
- 场景类型与时间；
- 镜头功能；
- 景别和人物数量；
- 室内/室外、静态/运动；
- 连续视频或仅静帧。

单镜只支持局部外观；同场景多帧支持场景语法；跨场景、跨阶段证据才支持影片级模型。覆盖不足的维度标 `unknown`，不靠片名补齐。

### 3. 十轴逐镜分析

每个原片镜头都按十轴取证：

1. `PERCEPTUAL_INTENT`：镜头要观众先感到、发现或误解什么。
2. `COMPOSITION_GEOMETRY`：画面重心、线性秩序、负空间和层次怎样组织。
3. `VIEWPOINT_RELATION`：摄影机属于谁、与人物的社会/心理距离是什么。
4. `OPTICAL_PERSPECTIVE`：景别、透视、压缩、畸变和主体尺度。
5. `FOCUS_ATTENTION`：焦点所有者、景深、清晰度和注意顺序。
6. `LIGHT_EXPOSURE`：光源动机、方向、软硬、覆盖、光比和高光控制。
7. `COLOR_TONALITY`：色温、色相结构、饱和度、黑白位、肤色和色彩层级。
8. `MEDIUM_TEXTURE`：胶片/数字响应、颗粒、锐度、晕光、材质和空气感。
9. `PERFORMANCE_BLOCKING`：人物动作、停顿、视线、群体关系及其与环境的配合。
10. `TEMPORAL_PHASE`：叙事阶段；有视频时再记录摄影机运动、剪辑和节奏。

十轴用于解释观感如何形成，不要求每轴都变成一个 Prompt 词或可见物件。

### 4. 建立跨镜头美学模型

不要只取交集。把证据分为四类：

- `AESTHETIC_DNA`：跨阶段仍稳定的观看与成像原则。
- `PHASE_VARIANT`：随叙事阶段改变的光色、清晰度、运动或心理距离。
- `SHOT_FUNCTION_GRAMMAR`：当镜头承担揭示、观察、亲密、社会压力、主观不安等功能时，各轴怎样组合。
- `LOCAL_DEVICE`：只属于单镜的有效手段，不升级为影片规则。

同时建立 `ANCHOR_BUNDLE`。一个 bundle 至少连接两个轴，例如：

`受控正面空间秩序 + 接近正常透视 + 克制表演 + 柔和动机光 -> 产生安静而带社会压力的观察感。`

只出现频率高但没有辨识度的属性不能成为核心；只出现一次但具有明确触发条件的属性可以成为镜头功能语法。

### 5. 形成 FILM_AESTHETIC_MODEL

模型必须包括：

- 一句可证伪的美学机制判断；
- 4–7 个 `AESTHETIC_DNA` 锚点束；
- `NARRATIVE_PHASE_MAP`；
- `SHOT_FUNCTION_GRAMMAR` 条件表；
- 每个锚点束的证据、可见机制、感知效果、启用条件和漂移护栏；
- 内容事实、未知项和拒绝项。

如果模型只剩“低饱和、电影感、复古、浅景深”，说明尚未完成分析。

### 6. 编译 REPLICATION_SPEC

先判断目标镜头承担什么功能，再选择：

1. 对应叙事阶段。
2. 所有与目标镜头功能相关的 `AESTHETIC_DNA` bundle。
3. 所有被当前阶段和镜头功能触发的条件 bundle。
4. 十轴之间完整的因果和联动关系。
5. 目标场景中可执行的观看、焦点、光色、介质与表演关系。
6. 每个 bundle 的明确反漂移规则和可见验收标准。

默认 `STYLE_ONLY`。`CONTENT_FRAMEWORK_LOCK` 只检查复刻是否越权；没有目标原生载体的关系写 `not_applicable`。只有用户明确授权进入原片的时代或世界时才启用 `WORLD_AUTHORIZED`。

首次复刻使用 `FULL_FIDELITY_REPLICATION`：不设锚点数量上限，不删减条件分支，不为追求简短而合并不同控制维度。每个执行组必须完整保留 `证据机制 -> 镜头目的 -> 视觉关系 -> 感知效果 -> 可见结果 -> 漂移护栏`。只有同一完整规格已经通过真实结果回验，才可以另立任务研究压缩版；压缩版不得反向覆盖全量母版。

### 7. 下游交接

AI 生图只接收静态可见的 `REPLICATION_SPEC`，再由 `image-prompt-director` 输出五段工程 Prompt。AI 视频可额外接收有真实视频证据的摄影机运动、剪辑、速度和声音倾向；静帧未观察到的时间属性保持 `not_observed`。

不得把片名或主创名当作执行捷径，但必须把当前镜头需要的完整可执行美学机制交给下游，不以 Prompt 长度为理由省略。

### 8. 双账本回验

生成结果分开验收：

**AESTHETIC_FIDELITY**

- 观看/感知目的是否成立；
- 主 anchor bundle 是否完整；
- 阶段与镜头功能是否匹配；
- 焦点、光色、介质和表演是否共同指向同一观感；
- 是否退化成通用 AI 电影剧照。

**TARGET_INTEGRITY**

- 人物、动作、空间和时代是否保持；
- 是否复制原片人物、建筑、道具或布局；
- 空间与焦点是否物理可信。

逐项标记 `preserved`、`adapted`、`drifted`、`contaminated`、`not_tested`。修复时优先恢复权重最高且断裂的 anchor bundle，不通过追加影片名词补救。

## 默认输出

```text
【证据职责与覆盖图】
【十轴逐镜证据摘要】
【影片级美学 DNA】
【叙事阶段图】
【镜头功能语法】
【ANCHOR_BUNDLE 联动表】
【FILM_AESTHETIC_MODEL】
【REPLICATION_SPEC】
【美学相似性 / 目标内容双账本】
【证据等级与下一步】
```

用户只要求分析时，到 `FILM_AESTHETIC_MODEL` 停止。用户要求复刻方案时再给 `REPLICATION_SPEC`；用户明确要求生成或正式 Prompt 时才进入下游执行。

## 停止条件

- 原片证据不可见或职责无法区分。
- 证据只覆盖单镜，却要求宣称影片级定律。
- 只能依赖片名、导演名、演员、建筑或剧情道具描述风格。
- 找不到主 anchor bundle，只能堆砌独立形容词。
- 复刻必须改写目标身份、剧情、空间或动作因果才能成立。
- 需要付费生成、批量测试或第三方上传但未获批准。

## 完成检查

- 已建立证据覆盖图，而不是任取几张漂亮截图。
- 十轴分析解释了观感机制，不是标签清单。
- 已区分美学 DNA、阶段变体、镜头功能语法和单镜手段。
- 核心以 anchor bundle 表达，至少连接两个轴并说明感知效果。
- 影片美学模型先于复刻规格形成。
- 首次复刻使用全量规格，没有预先压缩锚点、条件分支或漂移护栏。
- 复刻规格保留证据机制、目的、关系、感知效果和可见结果，没有退化成色调或物件模仿。
- 美学相似性和目标内容完整性分开验收。
- 一次成功或一次失败只更新 candidate 证据，不直接升级为 validated。
