from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def require(text: str, needles: list[str], label: str) -> list[str]:
    return [f"{label}: missing {needle}" for needle in needles if needle not in text]


def main() -> int:
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    yaml = (ROOT / "agents" / "openai.yaml").read_text(encoding="utf-8")
    errors: list[str] = []

    errors += require(
        skill,
        [
            "active_candidate",
            "FILM_AESTHETIC_MODEL",
            "REPLICATION_SPEC",
            "FULL_FIDELITY_REPLICATION",
            "AESTHETIC_SOURCE",
            "TARGET_CONTENT",
            "VALIDATION_OUTPUT",
            "FAILURE_OUTPUT",
            "TEXT_CONTEXT",
            "AESTHETIC_DNA",
            "PHASE_VARIANT",
            "SHOT_FUNCTION_GRAMMAR",
            "ANCHOR_BUNDLE",
            "preserved",
            "adapted",
            "contaminated",
            "image-prompt-director",
            "不设锚点数量上限",
            "一次成功或一次失败只更新 candidate 证据",
        ],
        "SKILL.md",
    )
    errors += require(
        yaml,
        ["影视美学分析与全量复刻", "allow_implicit_invocation: true", "$cinematic-style-compiler"],
        "agents/openai.yaml",
    )

    expected = [
        "source-routing.md",
        "source-role-ledger.md",
        "aesthetic-analysis-system.md",
        "aesthetic-anchor-extraction.md",
        "replication-compiler.md",
        "anchor-output-contract.md",
        "contradiction-audit.md",
        "validation-rubric.md",
        "a-beautiful-mind-aesthetic-anchor-case.md",
        "content-framework-first.md",
    ]
    for name in expected:
        if not (ROOT / "references" / name).is_file():
            errors.append(f"references: missing {name}")
        if f"references/{name}" not in skill:
            errors.append(f"SKILL.md: reference not linked {name}")

    if errors:
        print("FAIL")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS: cinematic-style-compiler aesthetic anchor contract")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
