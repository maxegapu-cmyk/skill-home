# 多帧影视美学锚点提取

## 1. 先设计证据覆盖

不要只挑“最漂亮”的截图。按以下字段建立覆盖矩阵：

```text
source_id:
narrative_phase:
scene_type:
shot_function:
shot_scale:
character_count:
interior_or_exterior:
day_or_night:
static_or_motion:
source_quality:
pollution:
```

如果所有证据都来自同一场景，只输出 `scene_level` 模型。需要影片级结论时，至少要覆盖两个叙事阶段和三种镜头功能；做不到就保持 `unknown`，不从片名补齐。

## 2. 逐镜证据卡

每个 `AESTHETIC_SOURCE` 使用：

```text
source_id:
shot_function:
perceptual_intent:
composition_geometry:
viewpoint_relation:
optical_perspective:
focus_attention:
light_exposure:
color_tonality:
medium_texture:
performance_blocking:
temporal_phase:
content_facts:
observed:
inferred:
unknown:
pollution:
```

所有判断必须回指可见证据。焦段、光圈、胶片型号、灯具和 LUT 没有制作资料时，只描述可见效果。

## 3. 从单轴属性升级为联动机制

单轴标签不能直接成为锚点。对每个候选关系回答：

1. 哪些轴同时变化或稳定共现？
2. 这种联动怎样改变观众注意、信息或情绪？
3. 它由哪个叙事阶段或镜头功能触发？
4. 如果删掉其中一轴，原片观感是否明显减弱？
5. 在新内容中能否通过可见关系复刻并验收？

能回答后才建立 `ANCHOR_BUNDLE`。

## 4. 跨镜头分类

- `AESTHETIC_DNA`：跨阶段稳定的观看、空间、光色或介质原则。
- `PHASE_VARIANT`：叙事阶段改变时联动变化的属性组。
- `SHOT_FUNCTION_GRAMMAR`：特定镜头功能触发的组合规则。
- `LOCAL_DEVICE`：单镜有效但不可泛化。
- `CONTENT_ONLY`：人物、地点、服装、建筑、道具和剧情事实。
- `UNKNOWN`：证据不足。
- `REJECT`：截图污染、矛盾推断或会覆盖目标内容的项目。

`AESTHETIC_DNA` 不等于简单交集。高频但低辨识度的自然主义属性只能做支持层；低频但有明确功能触发、能解释影片观看方式的关系可进入条件语法。

## 5. 建立锚点束

```text
bundle_id:
classification: AESTHETIC_DNA | PHASE_VARIANT | SHOT_FUNCTION_GRAMMAR
evidence_sources:
linked_axes:
visible_mechanism:
perceptual_effect:
activation_condition:
replication_instruction:
drift_guard:
visible_acceptance_test:
evidence_strength: strong | moderate | weak
distinctiveness: high | medium | low
```

核心模型优先保留 `evidence_strength` 和 `distinctiveness` 都较高的束；其他束不删除，而是放入支持层或条件分支。

## 6. 建立影片美学机制

最终不是词表，而是三种关系图：

1. `DNA_GRAPH`：哪些 bundle 构成影片长期稳定的观看方式。
2. `PHASE_MAP`：叙事阶段改变时哪些 bundle 开启、关闭或变形。
3. `FUNCTION_MAP`：不同镜头功能调用哪些 bundle，以及焦点、光色、构图与表演如何联动。

机制判断必须可证伪。例如：

`影片用接近人物的主观信息位置和克制的自然主义表面，让观众先相信角色经验；当现实被揭开时，同时改变光线清晰度、色彩温度与观看距离。`

如果任何一部心理剧情片都可直接套用，应继续收紧到具体可见联动。

## 7. 不做提前压缩

首次形成的 `FILM_AESTHETIC_MODEL` 和首次 `REPLICATION_SPEC` 都保留全部相关 bundle、证据、条件、反例和漂移护栏。不要在这里选择“最小锚点”、限制 3–6 项或优化 Prompt 长度。
