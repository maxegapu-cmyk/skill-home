# 来源与权威路由

## 实时权威

| 任务 | 先读入口 | 本 Skill 的职责 |
|---|---|---|
| 多张原片静帧的影视美学观察 | `E:\AI\AI-Projects\AI生图\AGENTS.md` 与本 Skill | 建职责账本、逐帧证据卡、跨帧矩阵和美学锚点 |
| 单张图严格结构/身份复现 | `E:\AI\AI-Projects\AI生图\.agents\skills\reference-prompt-reconstruction\SKILL.md` | 不接管像素结构、身份或局部编辑权威 |
| 最终 AI 生图 Prompt | `E:\AI\AI-Projects\AI生图\.agents\skills\image-prompt-director\SKILL.md` 与当前输出标准 | 只提供风格资产交接卡 |
| 真实视频的镜头、运动、剪辑、声音观察 | `E:\AI\AI-Projects\AI视频\AGENTS.md` 与 `.agents\skills\reference-video-prompt-reconstruction\SKILL.md` | 接收视频证据，抽取跨场景常量与变量 |
| 最终 AI 视频 Prompt | AI 视频项目当前任务路由、模型适配与正式模板 | 只提供场景适配后的最小风格载荷 |
| 剧情或人物事实 | 对应项目 Bible/canon、用户最新完整剧本 | 不改写，只服从 |

## 来源优先级

同一属性冲突时按以下顺序判断：

1. 用户明确锁定与项目 canon。
2. 当前可见的原始图片或视频证据。
3. 已核实的项目方法与资产说明。
4. 来源文本中的描述。
5. 类型片、导演或片名引发的推断。

导演名、电影名、流派名只用于检索和提出假设，不能单独成为最终风格资产。若用户只提供名称，先将其转成待验证维度，不伪装成精确摄影事实。
