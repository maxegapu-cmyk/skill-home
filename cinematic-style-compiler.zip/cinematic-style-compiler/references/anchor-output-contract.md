# 影视美学模型与复刻规格输出合同

## FILM_AESTHETIC_MODEL

```text
FILM_AESTHETIC_MODEL
scope: single_shot | scene_level | film_level
evidence_sources:
evidence_coverage:
evidence_limit:
source_pollution:

aesthetic_mechanism:

ten_axis_findings:
  perceptual_intent:
  composition_geometry:
  viewpoint_relation:
  optical_perspective:
  focus_attention:
  light_exposure:
  color_tonality:
  medium_texture:
  performance_blocking:
  temporal_phase:

aesthetic_dna:
  - ANCHOR_BUNDLE

narrative_phase_map:
  - phase_id:
    evidence:
    active_bundles:
    changed_axes:
    perceptual_effect:
    forbidden_mix:

shot_function_grammar:
  - function:
    trigger:
    active_bundles:
    visible_behavior:
    exceptions:

local_devices:
content_only:
unknown:
reject:
model_confidence:
```

## ANCHOR_BUNDLE

```text
bundle_id:
classification:
evidence_sources:
linked_axes:
visible_mechanism:
perceptual_effect:
activation_condition:
replication_instruction:
drift_guard:
visible_acceptance_test:
evidence_strength:
distinctiveness:
```

## REPLICATION_SPEC

```text
REPLICATION_SPEC
replication_mode: FULL_FIDELITY_REPLICATION
target_level: R0_COLOR_ECHO | R1_SURFACE_LOOK | R2_SHOT_GRAMMAR | R3_AESTHETIC_SYSTEM
target_shot_function:
secondary_function:
selected_narrative_phase:
target_content_lock:

activated_aesthetic_dna:
activated_phase_variants:
activated_shot_function_grammar:
not_applicable_bundles:

ten_axis_execution:
  perceptual_intent:
  composition_geometry:
  viewpoint_relation:
  optical_perspective:
  focus_attention:
  light_exposure:
  color_tonality:
  medium_texture:
  performance_blocking:
  temporal_phase:

bundle_execution:
  - source_mechanism:
    target_carrier:
    target_visible_result:
    drift_guard:
    visible_acceptance_test:

content_firewall:
physical_coherence:
multi_character_differentiation:
forbidden_drift:
compression_status: prohibited_until_full_fidelity_validated
evidence_status:
```

## 下游交接

首次复刻把完整 `REPLICATION_SPEC` 交给对应 Prompt 权威。不得预先删减锚点束、条件分支、十轴执行关系或验收标准。片名和主创名只留在来源记录，不作为执行捷径。

同一全量规格通过真实生成回验后，才可以另立 `COMPRESSION_EXPERIMENT`。压缩版本必须有独立版本号和 A/B，不得覆盖全量母版。
