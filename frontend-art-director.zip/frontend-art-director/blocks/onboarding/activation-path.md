---
name: activation-path
category: onboarding
surface_modes: [OPERATE]
novelty_range: [3-6]
motion_range: [2-5]
density_range: [3-6]
when_to_use: "New users should reach the first valuable action quickly."
not_for: "Products whose first use requires no setup."
---
# Activation Path

## Visual Sketch
One goal-oriented step list with current progress and a live destination/work area. Explain only what is necessary for the next valuable action.

## Data / Props Contract
`steps[]`, `currentStep`, `skipPolicy?`, `completionAction`, `help?`.

## Implementation Sketch
Persist progress only when useful. Let users act in the real interface rather than forcing a long coach-mark tour.

## Mobile Fallback
Steps become a compact progress header; the actual task gets most of the screen.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Seven-step tour explaining every button; blocking modal walkthrough; celebration before value is achieved.
