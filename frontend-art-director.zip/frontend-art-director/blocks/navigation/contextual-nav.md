---
name: contextual-nav
category: navigation
surface_modes: [CONVERT, EXPLAIN, SHOWCASE]
novelty_range: [3-7]
motion_range: [1-4]
density_range: [2-6]
when_to_use: "A small stable global nav plus context-aware secondary navigation fits the information architecture."
not_for: "Complex enterprise IA needing a dedicated application shell."
---
# Contextual Nav

## Visual Sketch
One global row remains stable; a second compact context row appears only where a subsection actually needs it.

## Data / Props Contract
`globalItems[]`, `contextItems?`, `current`, `primaryAction?`, `brand`.

## Implementation Sketch
Use nav landmarks with explicit labels when more than one nav exists. Current state is semantic (`aria-current`) and visual.

## Mobile Fallback
Collapse global nav to an accessible menu; context nav may become horizontal tabs/scroll only if current location remains visible.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Mega menu for five links; every nav item in a pill; hidden current state; hover-only submenu.
