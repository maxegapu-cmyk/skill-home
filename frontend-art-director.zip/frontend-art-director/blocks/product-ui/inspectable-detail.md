---
name: inspectable-detail
category: product-ui
surface_modes: [OPERATE]
novelty_range: [3-6]
motion_range: [1-4]
density_range: [6-9]
when_to_use: "List/table selection should reveal detail without losing context."
not_for: "Tiny datasets where separate pages are clearer."
---
# Inspectable Detail

## Visual Sketch
Master list/table occupies the main lane; selected item opens a persistent side inspector with a clear close/back path.

## Data / Props Contract
`items`, `selectedId`, `columns?`, `detail`, `actions`, `loading/error`.

## Implementation Sketch
Selection is represented in URL/state when appropriate. Inspector has semantic heading and focus behavior; closing restores context.

## Mobile Fallback
Inspector becomes a full-screen detail view or route while preserving back/selection state.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Drawer with no focus management; selection only indicated by color; inspector overlays the entire table on medium screens.
