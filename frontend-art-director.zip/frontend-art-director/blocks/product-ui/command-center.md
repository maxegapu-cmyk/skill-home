---
name: command-center
category: product-ui
surface_modes: [OPERATE]
novelty_range: [3-6]
motion_range: [1-4]
density_range: [7-10]
when_to_use: "Expert users benefit from dense simultaneous information and stable actions."
not_for: "Consumer onboarding or simple forms."
---
# Command Center

## Visual Sketch
Stable app shell, compact toolbar, main data workspace, optional inspection rail. Alignment and separators carry structure more than cards.

## Data / Props Contract
`primaryNav`, `toolbarActions`, `dataRegion`, `filters?`, `selection?`, `detailRail?`, `status`.

## Implementation Sketch
Reuse incumbent application shell/table primitives. Keep keyboard shortcuts discoverable and selection/state persistent across nearby actions.

## Mobile Fallback
Do not pretend the full cockpit fits. Prioritize one primary task, move detail to drill-in/drawer, and collapse secondary controls behind explicit actions.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Marketing-sized typography in a tool; giant rounded cards around every data region; essential actions hidden behind hover.
