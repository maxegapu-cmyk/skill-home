---
name: trust-first-form
category: forms
surface_modes: [CONVERT, OPERATE]
novelty_range: [2-5]
motion_range: [1-3]
density_range: [3-6]
when_to_use: "Signup, checkout, permissions, or regulated forms where certainty matters."
not_for: "Experimental showcase interactions."
---
# Trust First Form

## Visual Sketch
Clear title and expectation, grouped fields, persistent labels, concise help, visible validation, one primary submit action, explicit trust/legal context where real.

## Data / Props Contract
`fields[]`, `submitLabel`, `errors`, `status`, `legal?`, `secondaryAction?`.

## Implementation Sketch
Use native inputs and labels, autocomplete where appropriate, fieldset/legend for grouped choices, and error associations. Preserve entered data on failure.

## Mobile Fallback
Single column by default, numeric/email keyboards via correct input types, sticky submit only if it does not cover fields/errors.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Placeholder-only labels; disabled submit with no reason; fake security badges; success/error communicated only by color.
