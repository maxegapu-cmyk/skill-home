---
name: evidence-band
category: social-proof
surface_modes: [CONVERT]
novelty_range: [3-7]
motion_range: [1-3]
density_range: [3-6]
when_to_use: "Verified evidence exists: metrics, quotes, customer categories, or product proof."
not_for: "No verified evidence is available."
---
# Evidence Band

## Visual Sketch
A low-height band interrupts the narrative with 1-3 pieces of strong evidence. Visual weight is proportional to credibility, not decoration.

## Data / Props Contract
One of: `metrics[]`, `quotes[]`, `logos[]`, `artifactProof`. Every item requires source/authorization in project context.

## Implementation Sketch
Use real text/media assets. Keep logos optically normalized but do not recolor them unless brand guidelines allow.

## Mobile Fallback
Wrap evidence into a vertical stack or swipe only if all evidence remains discoverable without gestures.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Fake “trusted by” logos; invented 99.9% numbers; carousel that hides all proof by default; grayscale logo cemetery used as decoration.
