---
name: structured-exit
category: footer
surface_modes: [CONVERT, EXPLAIN, OPERATE]
novelty_range: [2-5]
motion_range: [1-2]
density_range: [4-7]
when_to_use: "A real information architecture needs predictable exit/navigation."
not_for: "Immersive one-screen installations."
---
# Structured Exit

## Visual Sketch
Brand/legal anchor plus 2-5 labeled link groups. Utility links and legal links are visually distinct from primary navigation.

## Data / Props Contract
`brand`, `groups[]`, `legal[]`, `locale?`, `social?`. Only include destinations that exist.

## Implementation Sketch
Use `<footer>` and grouped nav lists with headings/aria labels where useful. Keep target sizes and focus obvious.

## Mobile Fallback
Accordion only if link volume truly warrants it; otherwise stack groups to avoid hiding important legal/support links.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Footer as another giant CTA billboard; duplicated entire header nav without hierarchy; fake social links.
