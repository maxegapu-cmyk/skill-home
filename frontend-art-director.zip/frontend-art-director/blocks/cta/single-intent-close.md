---
name: single-intent-close
category: cta
surface_modes: [CONVERT]
novelty_range: [4-8]
motion_range: [2-5]
density_range: [2-4]
when_to_use: "The page needs one decisive final action after proof."
not_for: "Multiple unrelated actions must remain equal."
---
# Single Intent Close

## Visual Sketch
One sentence resolves the remaining objection, then one primary action. Optional secondary link is quiet and clearly different in intent.

## Data / Props Contract
`headline`, `support?`, `primaryAction`, `secondaryAction?`, `legal?`.

## Implementation Sketch
Keep action label identical to the same intent used elsewhere. Button width follows content and layout, not arbitrary narrow max-width.

## Mobile Fallback
Primary action becomes full-width only if that improves reachability; legal/support copy stays readable and not trapped inside the button group.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Three equivalent CTAs; “Get started / Try free / Sign up” all on one page for the same action; giant decorative glow behind a normal button.
