---
name: case-study-stage
category: portfolio
surface_modes: [SHOWCASE]
novelty_range: [7-10]
motion_range: [4-8]
density_range: [2-5]
when_to_use: "A project needs narrative, artifact, role, and outcome instead of a card grid."
not_for: "High-volume gallery where quick scanning is primary."
---
# Case Study Stage

## Visual Sketch
Full-width artifact alternates with compact narrative beats: problem → role → process → outcome. Metadata sits in a disciplined side rail.

## Data / Props Contract
`title`, `role`, `date?`, `artifacts[]`, `storySections[]`, `outcome?`, `nextProject?`.

## Implementation Sketch
Prioritize media loading and narrative order. Use figure/caption structures. Motion may connect sections but never hide the work behind chrome.

## Mobile Fallback
Artifact and story interleave linearly; side rail becomes an intro metadata block. Preserve media aspect ratios and captions.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Identical thumbnail cards; giant “creative” transitions between every image; role/outcome absent; work impossible to inspect at rest.
