---
name: tempo-shift
category: transition
surface_modes: [CONVERT, SHOWCASE, EXPLAIN]
novelty_range: [5-8]
motion_range: [3-7]
density_range: [2-5]
when_to_use: "A long page needs a deliberate rhythm change between narrative acts."
not_for: "Short utilitarian pages."
---
# Tempo Shift

## Visual Sketch
A transitional section changes scale, whitespace, media treatment, or typography to mark a new act without switching to an unrelated theme.

## Data / Props Contract
`label?`, `statement?`, `media?`, `nextAnchor?`.

## Implementation Sketch
Change one or two grammar variables while preserving theme tokens and typography family. Keep transition meaningful in the document outline.

## Mobile Fallback
Use spacing/scale rather than large viewport pinning. Avoid transitions that consume multiple screens before content resumes.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Random dark section inside a light page; meaningless quote; animation-only interstitial with no content role.
