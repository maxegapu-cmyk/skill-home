---
name: decision-table
category: pricing
surface_modes: [CONVERT, OPERATE]
novelty_range: [3-6]
motion_range: [1-3]
density_range: [5-8]
when_to_use: "Plan differences are concrete and comparison is the task."
not_for: "Simple single-offer pages."
---
# Decision Table

## Visual Sketch
Plan headers across the top, decision criteria down the left. One recommendation may be highlighted only when product truth supports it.

## Data / Props Contract
`plans[]`, `features[]`, `billingPeriod?`, `disclaimers`, `actions`. Prices/copy are immutable factual inputs.

## Implementation Sketch
Use semantic table markup for desktop when truly tabular; connect headers to cells. Keep CTA associated with each plan.

## Mobile Fallback
Use plan selector + criterion list or horizontally scrollable table with sticky labels. Never shrink 4 columns to unreadable widths.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Card-only pricing that hides feature differences; duplicate signup labels with different meanings; invented discounts.
