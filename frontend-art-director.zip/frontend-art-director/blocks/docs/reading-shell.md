---
name: reading-shell
category: docs
surface_modes: [EXPLAIN]
novelty_range: [2-5]
motion_range: [1-3]
density_range: [4-7]
when_to_use: "Long-form technical/help content with navigation, code, tables, and anchors."
not_for: "Marketing landing pages."
---
# Reading Shell

## Visual Sketch
Left or top navigation, central readable article measure, optional right outline. Code/table/media can break the measure intentionally.

## Data / Props Contract
`navigation`, `title`, `body`, `toc?`, `previousNext?`, `feedback?`.

## Implementation Sketch
Semantic headings drive the outline. Code blocks support horizontal scroll/copy without breaking page width. Anchor links remain keyboard reachable.

## Mobile Fallback
Primary article first; docs navigation becomes a clear drawer/menu; TOC may collapse but current section should remain understandable.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Marketing hero above every doc; narrow code blocks clipped by rounded cards; body text stretched edge-to-edge.
