---
name: sticky-story-rail
category: feature
surface_modes: [CONVERT, SHOWCASE]
novelty_range: [6-9]
motion_range: [5-9]
density_range: [2-5]
when_to_use: "A sequential story benefits from one persistent visual changing with text."
not_for: "Short pages or motion-sensitive contexts without a static fallback."
---
# Sticky Story Rail

## Visual Sketch
One sticky media rail occupies ~45-60%; the opposite rail contains 3-5 narrative steps. Active step swaps/updates the persistent visual.

## Data / Props Contract
`steps[{title,body,media,alt}]`, `initialStep`, optional `progressLabel`. Keep step count bounded.

## Implementation Sketch
Prefer IntersectionObserver or a verified motion library. DOM includes all textual content normally; visual swapping is enhancement. Avoid raw unthrottled scroll handlers.

## Mobile Fallback
Disable sticky behavior; render media directly with each step or use a simple swipe/stack pattern.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Sticky panel longer than the viewport; content only visible when JS runs; scroll-jacking; 8+ steps with no pacing break.
