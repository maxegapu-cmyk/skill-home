---
name: comparison-lens
category: feature
surface_modes: [CONVERT, EXPLAIN]
novelty_range: [4-7]
motion_range: [1-4]
density_range: [4-7]
when_to_use: "The user must compare plans, states, approaches, or before/after outcomes."
not_for: "Purely emotional brand storytelling."
---
# Comparison Lens

## Visual Sketch
Shared criteria form the stable axis; two or more alternatives occupy parallel columns/lanes. Differences are emphasized, sameness de-emphasized.

## Data / Props Contract
`criteria[]`, `options[]`, `recommended?`, `notes?`. All claims come from product truth.

## Implementation Sketch
Use semantic table/list structures when comparison is tabular. Visual highlight does not remove text labels. Preserve column/row associations.

## Mobile Fallback
Switch to criterion-by-criterion stacked comparison or horizontally scrollable table with sticky first column when appropriate.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Checkmark wall with no criteria; “recommended” invented for visual hierarchy; color-only differences; unreadable squeezed columns.
