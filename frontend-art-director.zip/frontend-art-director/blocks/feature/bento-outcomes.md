---
name: bento-outcomes
category: feature
surface_modes: [CONVERT]
novelty_range: [5-8]
motion_range: [2-6]
density_range: [3-6]
when_to_use: "Capabilities differ enough to deserve unequal visual weight."
not_for: "Six identical features with equal importance."
---
# Bento Outcomes

## Visual Sketch
2-5 unequal cells with one anchor outcome, one supporting proof cell, and smaller tertiary capabilities. Cell size maps to importance.

## Data / Props Contract
Array of `{title, body, evidence?, media?, priority}`. Priority controls span; content decides geometry.

## Implementation Sketch
Use CSS Grid with explicit named spans or responsive templates. One cell may be visually dominant; avoid assigning random spans purely for novelty.

## Mobile Fallback
Linearize by priority, not by desktop coordinates. Each cell becomes a section or compact panel; no tiny multi-column bento on phones.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Six identical rounded cards called bento; random sizes unrelated to content; every cell using a different visual language.
