---
name: immersive-artifact
category: hero
surface_modes: [SHOWCASE]
novelty_range: [8-10]
motion_range: [5-10]
density_range: [1-4]
when_to_use: "Portfolio or launch where the artifact should dominate the first viewport."
not_for: "Trust-critical forms, checkout, admin."
---
# Immersive Artifact

## Visual Sketch
Artifact/media fills 65-90% of the first viewport. Minimal chrome hugs an edge. Title and navigation are readable but deliberately secondary.

## Data / Props Contract
`artifact`, `title`, `role?`, `year?`, `openAction?`, `alt/description`. Metadata stays real and sparse.

## Implementation Sketch
Layer semantic content over/around media without making the artifact inaccessible. Advanced parallax/masking is progressive enhancement; baseline remains a strong static composition.

## Mobile Fallback
Reduce motion and crop aggressively but intentionally; preserve a clear exit/navigation affordance and artifact identity.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Portfolio reduced to generic project cards; cursor effects that block selection; autoplay motion with no reduced-motion path; unreadable overlaid text.
