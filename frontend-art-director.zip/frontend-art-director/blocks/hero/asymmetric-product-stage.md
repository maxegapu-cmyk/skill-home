---
name: asymmetric-product-stage
category: hero
surface_modes: [CONVERT, SHOWCASE]
novelty_range: [6-9]
motion_range: [3-7]
density_range: [2-5]
when_to_use: "One strong message plus one authentic product/artifact visual."
not_for: "Dense product workflows or text-only editorial."
---
# Asymmetric Product Stage

## Visual Sketch
Desktop: 5/12 text column anchored to one edge, 7/12 product/artifact stage crossing the grid. The media is proof, not wallpaper. Keep one dominant CTA cluster and one secondary proof cue.

## Data / Props Contract
`eyebrow?`, `headline`, `support`, `primaryAction`, `secondaryAction?`, `media`, `mediaAlt`, `proof?`. Do not accept arbitrary badge arrays by default.

## Implementation Sketch
Use semantic `<header>`/`<section>` with text and figure regions. Let the media stage break the content grid visually while keeping DOM order text-first when that matches reading priority. Crop with `object-position` tokens rather than hardcoded per-device offsets.

## Mobile Fallback
Text first, then media; CTA stays above the first major scroll break where practical. Remove overlap and absolute positioning that can clip the artifact.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Centered generic SaaS hero; fake dashboard screenshot; five badges above the headline; gradient text without brand reason; image as decorative blur only.
