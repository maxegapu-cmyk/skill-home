---
name: editorial-proofline
category: hero
surface_modes: [CONVERT, EXPLAIN]
novelty_range: [5-8]
motion_range: [1-5]
density_range: [2-5]
when_to_use: "A message-led launch where typography and one proof object carry the page."
not_for: "Products that require immediate dense controls."
---
# Editorial Proofline

## Visual Sketch
Large editorial headline occupies the main measure; one compact proof line/object sits beside or below it. The page opens like a magazine spread, not a component stack.

## Data / Props Contract
`headline`, `dek`, `proofLabel?`, `proofValue?`, `action?`, `supportingMedia?`. Proof must be verified or omitted.

## Implementation Sketch
Use a strong type scale and a restrained grid. Prefer CSS columns/grid over decorative cards. If media exists, align it to a typographic edge or baseline rather than floating randomly.

## Mobile Fallback
Collapse to a single reading column; keep headline line length controlled and proof immediately adjacent to the claim it supports.

## Motion Bands
- 1-3: state feedback only; no ornamental entrance sequence.
- 4-7: one coordinated transition tied to hierarchy or continuity.
- 8-10: only when the surface and block range allow it; always provide static/reduced-motion behavior.

## Dark Mode
Use semantic theme tokens and preserve hierarchy, focus, CTA/action prominence, borders/elevation, and media treatment. Never implement dark mode as a blind inversion.

## Accessibility
Use semantic structure, accessible names, visible focus, sufficient contrast, and non-motion/non-color cues for required information. Preserve logical DOM order even when the visual composition is asymmetric.

## Anti-Patterns
Every line in a separate pill; tiny mono section numbers; ornamental statistics with no source; excessive letterspacing to simulate “editorial”.
