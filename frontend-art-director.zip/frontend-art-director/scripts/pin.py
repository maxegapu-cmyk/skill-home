#!/usr/bin/env python3
from pathlib import Path
import argparse, json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['pin','unpin']); ap.add_argument('command'); ap.add_argument('--project',default='.'); ns=ap.parse_args()
    d=Path(ns.project)/'.frontend-art-director/shortcuts'; d.mkdir(parents=True,exist_ok=True)
    p=d/f'{ns.command}.json'
    if ns.action=='pin':
        p.write_text(json.dumps({'command':ns.command,'invoke':f'frontend-art-director {ns.command}','note':'Host harness may map this descriptor to a native shortcut.'},indent=2),encoding='utf-8'); print(p)
    else:
        if p.exists(): p.unlink(); print(f'removed {p}')
        else: print('not pinned')
if __name__=='__main__': main()
