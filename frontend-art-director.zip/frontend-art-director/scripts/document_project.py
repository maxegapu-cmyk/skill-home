#!/usr/bin/env python3
from pathlib import Path
import re, sys, collections

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
    exts={'.css','.scss','.less','.tsx','.jsx','.html','.vue','.svelte'}
    files=[p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in exts and 'node_modules' not in p.parts and '.git' not in p.parts]
    colors=collections.Counter(); fonts=collections.Counter(); vars=collections.Counter(); radii=collections.Counter(); gaps=collections.Counter()
    for p in files[:5000]:
        t=p.read_text(encoding='utf-8',errors='ignore')
        colors.update(x.lower() for x in re.findall(r'#[0-9a-fA-F]{3,8}\b',t))
        fonts.update(x.strip() for x in re.findall(r'font-family\s*:\s*([^;}{]+)',t,re.I))
        vars.update(re.findall(r'--[a-zA-Z0-9_-]+\s*:',t))
        radii.update(re.findall(r'border-radius\s*:\s*([^;}{]+)',t,re.I))
        gaps.update(re.findall(r'(?:gap|padding|margin)\s*:\s*([^;}{]+)',t,re.I))
    lines=['# DESIGN.inferred','',f'Scanned files: {len(files)}','','> Static inventory only. Human/agent review must decide which patterns are intentional.','']
    def sec(title,counter,n=20):
        lines.extend([f'## {title}','']); lines.extend([f'- `{k}` × {v}' for k,v in counter.most_common(n)] or ['- none detected']); lines.append('')
    sec('Frequent colors',colors); sec('Font-family declarations',fonts); sec('CSS variables',vars); sec('Radii',radii); sec('Spacing-like declarations',gaps)
    (root/'DESIGN.inferred.md').write_text('\n'.join(lines),encoding='utf-8')
    print(root/'DESIGN.inferred.md')
if __name__=='__main__': main()
