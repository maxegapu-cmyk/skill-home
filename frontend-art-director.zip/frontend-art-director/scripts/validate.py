#!/usr/bin/env python3
from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parents[1]


def fail(msg):
    print('FAIL:', msg)
    return False


def main():
    ok = True
    required = [
        'SKILL.md', 'VERSION', 'detector_rules.json',
        'references/28-preflight.md',
        'references/24-design-system-router.md',
        'references/35-block-library.md',
        'scripts/detector.py', 'scripts/doctor.py',
        'scripts/hooks.py', 'scripts/preflight.py', 'scripts/pin.py',
    ]
    for rel in required:
        if not (ROOT / rel).exists():
            ok = fail('missing ' + rel) and ok

    skill = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
    if 'version: 2.0.0' not in skill:
        ok = fail('version mismatch') and ok

    refs = set(re.findall(r'`(references/[^`]+\.md)`', skill))
    for rel in sorted(refs):
        if not (ROOT / rel).exists():
            ok = fail('broken reference ' + rel) and ok

    commands = re.findall(r'\| `([a-z-]+)(?: \[[^\]]+\])?` \|', skill)
    if len(set(commands)) < 23:
        ok = fail(f'only {len(set(commands))} canonical/extended commands') and ok

    data = json.loads((ROOT / 'detector_rules.json').read_text(encoding='utf-8'))
    rules = data.get('rules', [])
    if data.get('rule_count') != len(rules):
        ok = fail('rule_count mismatch') and ok
    if len(rules) < 70:
        ok = fail('detector has fewer than 70 rules') and ok

    ids = [r['id'] for r in rules]
    if len(ids) != len(set(ids)):
        ok = fail('duplicate detector rule ids') and ok
    for rule in rules:
        try:
            re.compile(rule['pattern'])
        except re.error as exc:
            ok = fail(f"bad regex {rule['id']}: {exc}") and ok

    blocks = list((ROOT / 'blocks').rglob('*.md'))
    if len(blocks) < 18:
        ok = fail(f'only {len(blocks)} blocks') and ok
    required_sections = [
        '## Visual Sketch', '## Data / Props Contract',
        '## Implementation Sketch', '## Mobile Fallback',
        '## Motion Bands', '## Dark Mode', '## Accessibility',
        '## Anti-Patterns',
    ]
    for block in blocks:
        text = block.read_text(encoding='utf-8')
        if not text.startswith('---\n'):
            ok = fail(f'block frontmatter missing {block.relative_to(ROOT)}') and ok
        for section in required_sections:
            if section not in text:
                ok = fail(f'{section} missing in {block.relative_to(ROOT)}') and ok

    if ok:
        print(
            f'PASS: {len(set(commands))} commands, {len(rules)} detector rules, '
            f'{len(blocks)} blocks, {len(refs)} routed references'
        )
    return 0 if ok else 2


if __name__ == '__main__':
    raise SystemExit(main())
