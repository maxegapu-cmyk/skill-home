#!/usr/bin/env python3
from pathlib import Path
import json, sys

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
    issues=[]; notes=[]
    for name in ['PRODUCT.md','DESIGN.md']:
        p=root/name
        if not p.exists(): issues.append(f'missing {name}')
        elif p.stat().st_size<120: issues.append(f'{name} appears too thin')
    cfg=root/'.frontend-art-director/config.json'
    if not cfg.exists(): notes.append('no local detector config')
    else:
        try:
            x=json.loads(cfg.read_text());
            if x.get('runtime_version')!='2.0.0': notes.append(f"runtime_version={x.get('runtime_version')} differs from 2.0.0")
        except Exception as e: issues.append(f'config invalid: {e}')
    inf=root/'DESIGN.inferred.md'
    if inf.exists() and (not (root/'DESIGN.md').exists() or inf.stat().st_mtime>(root/'DESIGN.md').stat().st_mtime): notes.append('DESIGN.inferred.md is newer than DESIGN.md; review potential drift')
    print('ISSUES' if issues else 'PASS')
    for i in issues: print('-',i)
    for n in notes: print('NOTE -',n)
    return 2 if issues else 0
if __name__=='__main__': raise SystemExit(main())
