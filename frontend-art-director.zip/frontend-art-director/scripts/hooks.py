#!/usr/bin/env python3
from pathlib import Path
import argparse, json, textwrap

HERE=Path(__file__).resolve()

def cfgpath(root): return Path(root)/'.frontend-art-director/config.json'
def helperpath(root): return Path(root)/'.frontend-art-director/run_detector.py'
def load(root):
    p=cfgpath(root)
    if p.exists():
        try:return json.loads(p.read_text())
        except Exception: pass
    return {'runtime_version':'2.0.0','enabled':True,'ignore_rules':[],'ignore_files':[],'ignore_values':[]}
def save(root,x):
    p=cfgpath(root); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,indent=2),encoding='utf-8')
def write_helper(root):
    hp=helperpath(root); hp.parent.mkdir(parents=True,exist_ok=True)
    detector=HERE.with_name('detector.py')
    project=Path(root).resolve()
    hp.write_text(textwrap.dedent(f'''\
        #!/usr/bin/env python3
        import subprocess, sys
        cmd=[sys.executable, {str(detector)!r}, '--project', {str(project)!r}, '--fail-on', 'error'] + (sys.argv[1:] or [{str(project)!r}])
        raise SystemExit(subprocess.call(cmd))
    '''),encoding='utf-8')
    hp.chmod(0o755)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action'); ap.add_argument('value',nargs='?'); ap.add_argument('--project',default='.'); ns=ap.parse_args(); x=load(ns.project)
    if ns.action=='on':
        x['enabled']=True; write_helper(ns.project)
    elif ns.action=='off': x['enabled']=False
    elif ns.action=='status':
        print(json.dumps({**x,'helper':str(helperpath(ns.project)),'helper_exists':helperpath(ns.project).exists()},indent=2)); return
    elif ns.action=='ignore-rule' and ns.value: x.setdefault('ignore_rules',[]).append(ns.value); x['ignore_rules']=sorted(set(x['ignore_rules']))
    elif ns.action=='ignore-file' and ns.value: x.setdefault('ignore_files',[]).append(ns.value); x['ignore_files']=sorted(set(x['ignore_files']))
    elif ns.action=='ignore-value' and ns.value: x.setdefault('ignore_values',[]).append(ns.value); x['ignore_values']=sorted(set(x['ignore_values']))
    elif ns.action=='reset':
        x={'runtime_version':'2.0.0','enabled':True,'ignore_rules':[],'ignore_files':[],'ignore_values':[]}
        hp=helperpath(ns.project)
        if hp.exists(): hp.unlink()
    else: raise SystemExit('invalid action/value')
    save(ns.project,x); print(json.dumps(x,indent=2))
if __name__=='__main__': main()
