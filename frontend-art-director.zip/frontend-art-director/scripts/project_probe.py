#!/usr/bin/env python3
from pathlib import Path
import json, sys

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
    pkg=root/'package.json'
    out={'project':str(root.resolve()),'package_json':pkg.exists(),'package_manager':None,'frameworks':[],'ui_libraries':[],'motion_libraries':[]}
    for f,n in [('pnpm-lock.yaml','pnpm'),('yarn.lock','yarn'),('package-lock.json','npm'),('bun.lock','bun'),('bun.lockb','bun')]:
        if (root/f).exists(): out['package_manager']=n; break
    if pkg.exists():
        try:
            data=json.loads(pkg.read_text(encoding='utf-8')); deps={**data.get('dependencies',{}),**data.get('devDependencies',{})}
            for k in deps:
                lk=k.lower()
                if k in ('next','react','vue','svelte','astro','@angular/core'): out['frameworks'].append(k)
                if any(x in lk for x in ['radix','shadcn','chakra','mui','material','fluent','carbon','polaris','atlaskit','primer']): out['ui_libraries'].append(k)
                if any(x in lk for x in ['motion','framer','gsap','lottie','three','pixi']): out['motion_libraries'].append(k)
        except Exception as e: out['error']=str(e)
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
