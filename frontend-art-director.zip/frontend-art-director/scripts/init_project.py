#!/usr/bin/env python3
from pathlib import Path
import argparse, json

PRODUCT="# PRODUCT\n\n## Product truth\n- What this product is:\n- What it is not:\n\n## Audience\n- Primary:\n- Secondary:\n\n## Jobs and actions\n- Primary job:\n- Primary action:\n\n## Trust / risk\n- Regulated or sensitive constraints:\n- Irreversible actions:\n\n## Brand\n- Voice:\n- Existing assets:\n- References:\n- Anti-references:\n\n## Immutable facts\n- Routes / claims / legal / field semantics that must not change silently:\n"
DESIGN="# DESIGN\n\n## Surface modes\n\n## Visual world\n\n## Typography\n\n## Grid and spacing\n\n## Shape / border / elevation\n\n## Semantic color and themes\n\n## Imagery / icons\n\n## Motion\n\n## Component states\n\n## Responsive / density\n"

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('--force',action='store_true'); ns=ap.parse_args()
    root=Path(ns.project); root.mkdir(parents=True,exist_ok=True)
    for name,content in [('PRODUCT.md',PRODUCT),('DESIGN.md',DESIGN)]:
        p=root/name
        if not p.exists() or ns.force: p.write_text(content,encoding='utf-8')
        else: print(f'preserved {p}')
    cfgdir=root/'.frontend-art-director'; cfgdir.mkdir(exist_ok=True)
    cfg=cfgdir/'config.json'
    if not cfg.exists() or ns.force:
        cfg.write_text(json.dumps({'runtime_version':'2.0.0','enabled':True,'ignore_rules':[],'ignore_files':[],'ignore_values':[]},indent=2),encoding='utf-8')
    print('context initialized')
if __name__=='__main__': main()
