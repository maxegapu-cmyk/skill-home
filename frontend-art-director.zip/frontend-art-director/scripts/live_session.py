#!/usr/bin/env python3
from pathlib import Path
import json, sys, time
P=Path('.frontend-art-director/live-session.json')

def load(): return json.loads(P.read_text()) if P.exists() else None
def save(x): P.parent.mkdir(exist_ok=True); P.write_text(json.dumps(x,indent=2),encoding='utf-8')
def main():
    if len(sys.argv)<2: raise SystemExit('usage: live_session.py start|add|choose|close ...')
    cmd=sys.argv[1]
    if cmd=='start':
        target=' '.join(sys.argv[2:]) or 'unspecified'; save({'target':target,'started':time.time(),'variants':[],'chosen':None,'closed':False}); print('started')
    elif cmd=='add':
        x=load() or {}; x.setdefault('variants',[]).append({'name':sys.argv[2] if len(sys.argv)>2 else f"v{len(x.get('variants',[]))+1}",'note':' '.join(sys.argv[3:])}); save(x); print('added')
    elif cmd=='choose':
        x=load() or {}; x['chosen']=sys.argv[2] if len(sys.argv)>2 else None; save(x); print('chosen')
    elif cmd=='close':
        x=load() or {}; x['closed']=True; x['closed_at']=time.time(); save(x); print('closed')
    else: raise SystemExit('unknown command')
if __name__=='__main__': main()
