#!/usr/bin/env python3
from pathlib import Path
import argparse, subprocess, sys

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('paths',nargs='+'); ap.add_argument('--project',default='.'); ns=ap.parse_args()
    det=Path(__file__).with_name('detector.py')
    cmd=[sys.executable,str(det),'--project',ns.project,'--fail-on','error',*ns.paths]
    rc=subprocess.call(cmd)
    print('Static preflight:', 'PASS' if rc==0 else 'FAIL')
    print('Manual matrix: references/28-preflight.md')
    return rc
if __name__=='__main__': raise SystemExit(main())
