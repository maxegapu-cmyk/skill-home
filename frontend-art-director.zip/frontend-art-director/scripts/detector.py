#!/usr/bin/env python3
from pathlib import Path
import argparse, fnmatch, json, re, sys

ROOT=Path(__file__).resolve().parents[1]
RULES=json.loads((ROOT/'detector_rules.json').read_text(encoding='utf-8'))['rules']

def load_config(project):
    p=Path(project)/'.frontend-art-director/config.json'
    if not p.exists(): return {'enabled':True,'ignore_rules':[],'ignore_files':[],'ignore_values':[]}
    try: return json.loads(p.read_text(encoding='utf-8'))
    except Exception: return {'enabled':True,'ignore_rules':[],'ignore_files':[],'ignore_values':[]}

def files_from(paths):
    for raw in paths:
        p=Path(raw)
        if p.is_file(): yield p
        elif p.is_dir():
            for f in p.rglob('*'):
                if f.is_file() and '.git' not in f.parts and 'node_modules' not in f.parts and 'dist' not in f.parts and 'build' not in f.parts:
                    yield f

def main():
    ap=argparse.ArgumentParser(description='Deterministic frontend design/quality detector')
    ap.add_argument('paths', nargs='+')
    ap.add_argument('--project', default='.')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--fail-on', choices=['none','error','warn','info'], default='error')
    ns=ap.parse_args()
    cfg=load_config(ns.project)
    if cfg.get('enabled') is False:
        print('detector disabled')
        return 0
    ignored=set(cfg.get('ignore_rules',[]))
    ignore_globs=cfg.get('ignore_files',[])
    ignore_values=[str(v).lower() for v in cfg.get('ignore_values',[])]
    findings=[]
    ranks={'info':1,'warn':2,'error':3}
    for f in files_from(ns.paths):
        try: rel=str(f.resolve().relative_to(Path(ns.project).resolve()))
        except Exception: rel=str(f)
        if any(fnmatch.fnmatch(rel,g) for g in ignore_globs): continue
        ext=f.suffix.lower()
        try: text=f.read_text(encoding='utf-8',errors='ignore')
        except Exception: continue
        for rule in RULES:
            if rule['id'] in ignored or ext not in rule['extensions']: continue
            try: matches=list(re.finditer(rule['pattern'],text,re.I|re.M|re.S))
            except re.error as e:
                findings.append({'rule':rule['id'],'severity':'error','file':rel,'line':1,'message':f'Invalid detector regex: {e}'})
                continue
            for m in matches[:8]:
                if any(v and v in m.group(0).lower() for v in ignore_values):
                    continue
                line=text.count('\n',0,m.start())+1
                findings.append({'rule':rule['id'],'severity':rule['severity'],'file':rel,'line':line,'message':rule['message']})
    if ns.json:
        print(json.dumps(findings,indent=2,ensure_ascii=False))
    else:
        for x in findings:
            print(f"{x['severity'].upper():5} {x['rule']} {x['file']}:{x['line']} - {x['message']}")
        print(f"Findings: {len(findings)}")
    if ns.fail_on=='none': return 0
    threshold=ranks[ns.fail_on]
    return 2 if any(ranks.get(x['severity'],0)>=threshold for x in findings) else 0

if __name__=='__main__': raise SystemExit(main())
