# Overdrive

Overdrive is for surfaces where extraordinary technique is part of the experience, not for routine controls.

Eligible examples: launch moments, showcase/portfolio hero, immersive product storytelling, campaign microsites.
Avoid by default: checkout, authentication, permissions, dense admin, regulated forms, critical settings.

## Allowed techniques when justified
- WebGL/canvas/WebGPU scenes
- shader-like material effects
- scroll-linked spatial choreography
- kinetic typography
- mask/clip-path reveals
- layered depth/parallax
- generative background systems
- high-fidelity pointer/hover response

## Required budget
Before implementation define:
- visual job
- fallback without advanced API
- reduced-motion path
- interaction escape/recoverability
- mobile strategy
- performance budget and device degradation strategy

Advanced technique that harms comprehension or blocks input is a failure, not sophistication.
