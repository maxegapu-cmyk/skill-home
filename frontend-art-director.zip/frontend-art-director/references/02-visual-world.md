# Visual World

Choose a visual world before choosing components.

## World statement
Define, in one compact sentence:
- geometry: sharp / soft / mixed
- typography: rational / editorial / expressive / technical
- color: restrained / chromatic / monochrome / material
- imagery: photographic / illustrative / product-led / typographic
- space: compact / balanced / monumental
- motion: functional / atmospheric / choreographed

Example form: "Monumental editorial typography, low-chroma mineral palette, hard grid breaks, sparse product imagery, slow spatial motion."

## Coherence locks
Commit to:
- one radius family
- one border logic
- one shadow/material logic
- one spacing scale
- one accent strategy
- one primary icon family
- one motion grammar

Consistency does not mean every section has the same layout. Repeat rules, not templates.

## Composition families
Rotate among composition families only when content supports it:
- anchored split
- editorial stack
- asymmetric grid
- full-bleed media
- dense matrix
- timeline/sequence
- sticky narrative
- comparison field
- focused form/task lane
- data workspace

Avoid repeating the same two-column image/text section several times in a row.

## Specificity test
If the same page could plausibly represent five unrelated startups after swapping the logo and accent color, the visual world is too generic.
