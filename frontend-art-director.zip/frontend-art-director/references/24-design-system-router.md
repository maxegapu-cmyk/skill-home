# Design-System Router

Use established systems when their interaction model and domain fit the product. Use official packages/docs when implementing them.

## Routing heuristics

| Product context | Prefer investigating | Why |
|---|---|---|
| Microsoft ecosystem / enterprise productivity | Fluent UI | enterprise controls, productivity conventions |
| IBM / enterprise data-heavy apps | Carbon | dense enterprise/data patterns |
| Atlassian-like work management | Atlassian Design System | collaboration/workflow conventions |
| GitHub-integrated developer tooling | Primer | developer-product vocabulary |
| Shopify embedded/admin commerce | Polaris | commerce/admin patterns |
| Public sector UK | GOV.UK Design System | trust, accessibility, government service patterns |
| Public sector US | USWDS | government service/accessibility patterns |
| Android / Google-aligned product | Material | mature adaptive component language |
| Existing Radix/shadcn stack | extend incumbent primitives | preserve project architecture and tokens |

This table is routing guidance, not a mandate. A brand marketing page can use a custom visual world even if the product UI uses a mature system.

## Rules
- Detect existing system before adding another.
- One dominant system per product surface unless a migration plan exists.
- Do not copy visual branding from a system when only its interaction primitives are needed.
- Do not claim a package is installed until verified.
- Do not use a marketing-oriented art-direction pattern in place of a specialized table, editor, or form control.
