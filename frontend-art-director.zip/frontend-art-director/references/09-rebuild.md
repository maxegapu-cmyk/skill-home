# Rebuild

Use when the current visual system is the problem.

Preserve unless explicitly authorized otherwise:
- factual content and product claims
- navigation meaning and important routes
- form field semantics and data requirements
- legal/compliance content
- core product behavior
- user data and saved-state expectations

Process:
1. Audit incumbent system as evidence, not as a style constraint.
2. Identify what must survive and what should be discarded.
3. Select a new visual world.
4. Re-map tokens and major components.
5. Rebuild representative critical screens first.
6. Verify feature/route parity.
7. Propagate the new system.

Do not produce a half-old, half-new compromise unless migration itself is the goal.
