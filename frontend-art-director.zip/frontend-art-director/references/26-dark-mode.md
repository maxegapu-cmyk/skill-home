# Dark Mode and Theme Protocol

Theme behavior is a system decision, not a per-section styling trick.

## Choose one strategy
- CSS semantic variables switched by class/data attribute
- CSS semantic variables switched by `prefers-color-scheme`
- utility variants when the existing stack already uses them

Do not mix strategies casually.

## Hierarchy parity
Both themes must preserve:
- primary vs secondary text hierarchy
- CTA prominence
- focus visibility
- elevation/boundary readability
- semantic status colors
- imagery legibility

## Theme lock
A page should not randomly alternate entire light/dark worlds between sections. A deliberate single theme transition is allowed only when it is a compositional device with a clear boundary and reason.

## Avoid
- pure black/white as automatic defaults when a tinted neutral better fits the world
- dark mode made by simple inversion
- glow as a substitute for contrast
- desaturating brand color until identity disappears

Test actual contrast rather than assuming dark mode is accessible.
