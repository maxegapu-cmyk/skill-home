# Imagery, Icons, and Asset Direction

Decide what imagery is for before choosing images.

## Possible jobs
- demonstrate the real product
- establish atmosphere/identity
- provide evidence or scale
- explain a process
- carry narrative pacing
- showcase work/artifacts

## Rules
- Prefer real product objects and real screenshots when they are proof.
- Do not invent customer logos, awards, press marks, or fake metrics.
- Keep one icon family and optical weight.
- Avoid generic stock imagery that says nothing about the product.
- Define crop/focal behavior across breakpoints.
- Provide alt text based on informational purpose; decorative imagery should be correctly marked decorative.
- Respect asset licensing/source constraints supplied by the user/project.

For image-heavy showcase work, the interface should frame the artifact rather than compete with it.
