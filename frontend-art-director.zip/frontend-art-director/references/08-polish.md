# Polish

Polish means removing the last visible signs of incompleteness, not redesigning the product.

Inspect in this order:
1. page-level hierarchy and silhouette
2. alignment and spacing rhythm
3. typography scale, measure, wrapping, baseline relationships
4. color/contrast consistency
5. component state completeness
6. icons and optical alignment
7. imagery crop and focal point
8. motion timing and interruption behavior
9. responsive transitions
10. copy micro-friction

Prefer ten coherent micro-fixes over one flashy new effect.
