# Accessibility Pass

Accessibility is part of design quality, not a final cosmetic audit.

Check:
- semantic landmarks and heading order
- native controls before div/button imitation
- accessible names for icon-only controls
- persistent labels for form fields
- programmatic error association
- visible focus
- keyboard reachability and modal focus management
- contrast for text, controls, states, and focus
- non-color cues for status/error/selection
- alt text according to image purpose
- reduced motion
- zoom/reflow and text resizing
- target size and spacing for touch
- live/status announcements when asynchronous changes need them

Do not claim conformance from visual inspection alone. Use available automated tooling and manual keyboard checks when possible.
