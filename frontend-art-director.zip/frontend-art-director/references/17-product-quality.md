# Product Quality

## clarify
Replace vague labels with action/result language. Error messages state what happened, why when known, and what the user can do next.

## adapt
Test reflow, not just breakpoints. Preserve primary action visibility, touch target size, content order, and table/form usability. Consider keyboard, touch, mouse, and zoom.

## harden
Test:
- zero/one/many items
- very long names and translated strings
- slow/failing network
- permission denied
- expired session
- partial data
- repeated submit
- destructive action
- offline/reconnect where relevant
- empty results vs empty account

## optimize
Optimize the user-visible bottleneck, not a theoretical metric. Check image payload, font loading, JS cost, animation effects, hydration/render churn, and layout instability.

## onboard
Teach by helping the user perform the first valuable action. Avoid tours that explain every button before the user has context.
