# Anti-Template Gate

Flag patterns when they are contextless, repetitive, or substituting style for product truth:
- generic gradient/mesh hero with no brand reason
- default purple/blue "AI" palette
- universal centered headline + subhead + two buttons + screenshot
- equal-card rows for every content type
- nested cards or panels inside panels without hierarchy need
- excessive pills/chips/rounded rectangles
- glass/blur everywhere
- giant radius on dense/product controls
- decorative terminal/dashboard imagery that is not the product
- metadata/version/location micro-labels used as ornament
- repeated image/text split sections
- mixed icon families
- every section independently animating in
- borders replacing hierarchy
- fake testimonials/logos/metrics
- "premium" reduced to beige + brass + serif + huge whitespace
- "developer" reduced to black + mono + neon green + terminal chrome
- dark mode reduced to glow/neon
- portfolio reduced to a grid of identical project cards

## Repair
Replace cliché with product-specific truth: real object/data shape, real editorial structure, brand-specific type, meaningful media, task-driven grouping, or a composition that reveals the product's distinctive behavior.

## Distinctiveness test
Could a competitor swap its logo/accent and use the interface unchanged? If yes, add at least one product-specific structural or visual idea.
