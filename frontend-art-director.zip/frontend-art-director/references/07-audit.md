# Audit

This is a measurable implementation audit, not subjective art direction.

Check:
- semantic HTML / landmark structure
- keyboard reachability and visible focus
- accessible names and form labeling
- contrast and non-color state cues
- responsive overflow and reflow
- tap/click targets
- loading, empty, error, retry, disabled, success states
- long text, localization expansion, number/date formats
- image dimensions, lazy loading, decoding, source sizing
- layout shift risks
- animation/reduced-motion behavior
- expensive effects, large bundles, re-render hotspots
- table/list behavior on narrow screens
- modal/dialog focus handling
- destructive-action safeguards

Report confirmed defects separately from likely risks. Do not fabricate Lighthouse numbers if you did not measure them.
