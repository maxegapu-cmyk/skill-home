# Design System and Token Architecture

Use a system when repetition, scale, or maintainability justifies it. Do not manufacture a ceremonial design system for a one-off page.

## Token layers
1. **Primitives**: hue ramps, font families, spacing units, radii, border widths, shadows, z-index.
2. **Semantic**: surface, text, muted, accent, success, warning, danger, focus, selection, overlay.
3. **Component**: button, input, panel, nav, table, dialog, tooltip, toast, chart, code.
4. **Density/theme variants**: compact/cozy, light/dark/high-contrast when the product supports them.

## Extraction
1. inventory repeated values and anatomy
2. separate intentional variants from drift
3. promote only stable patterns
4. preserve public component APIs unless breaking refactor is authorized
5. migrate gradually with visual/regression checks

## External system rule
If a mature system is already present, extend it before creating parallel primitives. See `24-design-system-router.md`.

## Health checks
- same semantic role → same token
- variants named by intent, not color alone
- focus is first-class
- disabled is not opacity-only
- dark/light preserve hierarchy parity
- data-heavy density is explicit
- component states share motion/feedback grammar
