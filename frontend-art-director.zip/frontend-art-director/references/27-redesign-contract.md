# Redesign Contract

## Detect mode
- **PRESERVE**: requested visual repair; retain brand and information architecture.
- **REBUILD**: visual system replacement; retain product truth and critical contracts.

## Audit before mutation
Record:
- what is structurally successful
- what is merely dated
- what is inconsistent
- what harms task success
- what carries brand recognition

## Never change silently
- routes / URL slugs
- primary navigation meaning
- form field names/semantics and data requirements
- legal/compliance copy
- pricing/product claims
- authentication/permission behavior
- destructive-action semantics
- brand wordmark/logo assets
- analytics/SEO identifiers whose change could break integrations

## Rebuild order
1. immutable contract
2. new visual world
3. tokens
4. high-traffic primitives
5. representative critical surfaces
6. responsive/state parity
7. full propagation
8. regression verification

A half-old, half-new compromise is allowed only when staged migration is itself the plan.
