# Strict Pre-Flight Matrix

Run every applicable item before declaring implementation complete. Unknown is not pass.

## Context
- [ ] Design read is clear: surface, audience, action, visual world, hard constraints.
- [ ] Surface/change modes are correct for this route.
- [ ] Five-axis state is contextual rather than inherited blindly.
- [ ] Existing design system/dependencies were inspected when code was available.
- [ ] Redesign immutable contract was recorded when applicable.

## Visual system
- [ ] One coherent typography role system.
- [ ] One spacing rhythm and grid logic.
- [ ] One radius/shape family unless exceptions are meaningful.
- [ ] One semantic accent strategy.
- [ ] Theme strategy is explicit and coherent.
- [ ] Icon family/style is consistent.
- [ ] Imagery has a defined role and crop/focal policy.
- [ ] Motion grammar has a purpose and reduced-motion fallback.

## Composition
- [ ] Hero has one dominant job and no pile of decorative metadata.
- [ ] Primary CTA is visible, readable, and does not wrap at normal desktop width.
- [ ] One intent uses one primary label unless context demands otherwise.
- [ ] No three consecutive sections repeat the same split-layout family.
- [ ] Eyebrows/micro-labels are sparse, not used above every heading.
- [ ] Cards/pills are not the default grouping mechanism for everything.
- [ ] Product-specific content or composition creates recognisable authorship.

## Product quality
- [ ] Hover/focus/pressed/selected/disabled states exist where relevant.
- [ ] Loading/empty/error/success states exist where needed.
- [ ] Destructive actions are explicit and recoverable/confirmable where appropriate.
- [ ] Long names and localization expansion do not destroy critical layout.
- [ ] Forms have persistent labels, errors, instructions, and visible focus.
- [ ] Tables/dense data remain usable at narrow widths.

## Responsive/input
- [ ] Layout recomposes rather than merely shrinking.
- [ ] No accidental horizontal overflow.
- [ ] Primary actions remain reachable.
- [ ] Touch targets are adequate.
- [ ] Keyboard order follows visual/logical order.
- [ ] 200% zoom/reflow does not hide critical content where applicable.

## Accessibility
- [ ] Landmarks/headings are semantic.
- [ ] Interactive elements have accessible names.
- [ ] Text and control contrast were checked, not guessed.
- [ ] Focus is visible and not removed without replacement.
- [ ] Status/error information is not color-only.
- [ ] Motion has reduced-motion behavior.

## Performance
- [ ] Images have appropriate dimensions/sizing/lazy strategy.
- [ ] Fonts are intentional and not over-requested.
- [ ] Effects do not cause avoidable continuous repaint/layout work.
- [ ] Large dependencies are justified.
- [ ] Layout shift risks are controlled.

## Verification
- [ ] Deterministic detector ran when files were accessible.
- [ ] Representative wide view inspected.
- [ ] Representative narrow view inspected.
- [ ] Critical states inspected.
- [ ] Taste Gate passed.
- [ ] Engineering Gate passed.
