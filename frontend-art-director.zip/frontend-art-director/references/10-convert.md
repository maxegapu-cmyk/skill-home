# CONVERT Mode

Success: attention becomes a clear, credible action.

Priorities:
1. value proposition comprehension
2. audience relevance
3. proof and trust
4. action clarity
5. differentiation
6. visual memorability

Hero should establish one dominant idea, not a pile of badges, chips, micro-labels, trust strips, and decorative metadata.
Do not fabricate customer logos or statistics.
Use authentic product imagery when the product itself is proof.
Vary section composition according to content; repeated feature-card grids are a last resort, not the default.
Keep CTA hierarchy stable across the page.
