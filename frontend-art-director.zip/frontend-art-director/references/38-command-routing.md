# Command Routing

Choose the smallest command that fully matches the request.

- asking what is wrong → `critique` or `audit`
- asking to fix the whole requested UI → `craft`
- asking for structure before implementation → `shape`
- asking to make bland work stronger → `bolder`
- asking to reduce visual noise → `quieter` / `distill`
- asking for final finish → `polish`
- asking for device fixes → `adapt`
- asking for edge cases → `harden`
- asking for performance → `optimize`
- asking for real visual alternatives → `live`
- asking for extraordinary visual technique → `overdrive`
- existing project without design record → `document`
- new durable project/context → `init`

When two commands are truly inseparable, run the primary command and include the secondary pass rather than forcing a menu.
