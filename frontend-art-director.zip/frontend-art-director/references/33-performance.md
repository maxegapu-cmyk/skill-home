# Performance Pass

Optimize user-visible bottlenecks, not vanity scores.

## Inspect
- responsive image sizing, dimensions, modern formats where supported
- hero/LCP asset priority
- font count, weights, preload strategy, fallback metrics
- JS dependency and hydration cost
- animation/compositing cost
- backdrop blur/filter over large moving regions
- unnecessary re-renders
- long lists/data rendering strategy
- layout shift from late dimensions/fonts/content
- third-party scripts

## Rules
- Prefer transform/opacity for routine motion.
- Do not leave broad `will-change` permanently on large trees.
- Advanced effects need degradation paths.
- Do not invent performance numbers without measurement.
