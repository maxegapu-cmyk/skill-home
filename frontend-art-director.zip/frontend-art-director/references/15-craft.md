# Craft: type / layout / color

## Typography
- define display, heading, body, label, data roles
- use a deliberate scale rather than arbitrary one-off sizes
- control line length and wrapping
- preserve readable line height at small sizes
- use weight contrast sparingly; weight is not hierarchy by itself
- verify numeric alignment in data surfaces

## Layout
- choose a grid strategy before local margins
- maintain a small spacing scale
- optical alignment may override mathematical centering for icons/type
- create hierarchy through scale and grouping before borders
- narrow layouts should recompose, not just shrink

## Color
- assign semantic roles before hex values
- accent is a scarce resource
- maintain contrast for text, controls, focus, and error states
- use neutral chroma intentionally; "premium" is not synonymous with beige
- gradients require a compositional or material reason
