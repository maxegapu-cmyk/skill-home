# Shape

Planning-only mode for UX/IA before code.

Deliver:
- primary user/job
- information architecture
- key objects and actions
- page/screen hierarchy
- critical states and transitions
- risky ambiguities
- recommended surface mode and design state

Do not spend the output on colors and gradients if the user's problem is task structure.
For irreversible/destructive flows, include confirmation and recovery strategy.
