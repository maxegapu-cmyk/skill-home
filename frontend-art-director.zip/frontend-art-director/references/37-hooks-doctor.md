# Hooks and Doctor

## Hooks
`python scripts/hooks.py on --project <project-root>` enables local detector configuration and writes `.frontend-art-director/run_detector.py`, a helper that a host editor/agent may wire into its own post-edit hook.
It does not impersonate provider-specific editor hooks. An agent/editor may wire that command into its own post-edit hook if supported.

Supported actions:
- `on`
- `off`
- `status`
- `ignore-rule RULE_ID`
- `ignore-file GLOB`
- `ignore-value TEXT`
- `reset`

## Doctor
`python scripts/doctor.py <project-root>` checks:
- PRODUCT.md / DESIGN.md presence
- local config validity
- stale/inferred design records
- detector rule availability
- hook configuration
- package/runtime version alignment when recorded

Doctor reports; it does not rewrite project design decisions automatically.

## Pin / unpin
`python scripts/pin.py pin <command> --project <root>` writes a portable shortcut descriptor. `unpin` removes it. Native command registration remains host-specific; the script does not pretend otherwise.
