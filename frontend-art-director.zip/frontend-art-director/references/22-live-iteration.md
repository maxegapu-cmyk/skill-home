# Live Visual Iteration

Use when a browser/runtime is available and the user wants to compare visual alternatives on a real element.

## Protocol
1. Select one target element or bounded region.
2. Record current baseline before mutation.
3. State the variable being tested: composition, type, color, density, imagery, motion, or material.
4. Generate 2-4 materially distinct variants. Do not make four nearly identical options.
5. Keep product content and behavior constant unless the experiment explicitly concerns them.
6. Test wide + narrow for the winning variant.
7. Commit the winner; remove temporary variant code/state.
8. Run pre-flight + twin gate on the committed version.

## Variant ledger
Use `python scripts/live_session.py start <target>` to create a local ledger, then `add`, `choose`, and `close` to track experiments. The script records decisions; it does not pretend to control a browser.

## Stop rule
If no variant improves the stated success criterion, keep the baseline.
