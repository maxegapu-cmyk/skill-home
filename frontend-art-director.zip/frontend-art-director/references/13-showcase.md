# SHOWCASE Mode

Success: the visitor experiences the work, not the chrome around it.

Let the artifact lead. Use interface chrome sparingly.
Higher novelty and motion are allowed when orientation is preserved.
Prefer curated sequencing and strong transitions over a grid of identical project cards.
Give each project enough space to reveal why it matters.
Navigation can be minimal, but must remain recoverable and obvious.
