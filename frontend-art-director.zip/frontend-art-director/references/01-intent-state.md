# Intent State

Infer the state before designing.

## Surface mode
Choose exactly one primary mode: CONVERT, OPERATE, EXPLAIN, SHOWCASE.
A product may contain several modes across different routes; classify the surface being edited, not the company.

## Change mode
GREENFIELD / PRESERVE / REBUILD.

## Five axes

### NOVELTY 1..10
1-3: conventional, trust-first, familiar patterns.
4-6: recognizable patterns with authored composition.
7-8: strong identity and asymmetric/expressive choices.
9-10: experimental; reserve for surfaces where navigation and comprehension remain obvious.

### MOTION 1..10
1-3: state transitions only.
4-6: purposeful entrance, emphasis, and spatial transitions.
7-8: choreography and scroll-linked sequences where justified.
9-10: motion-led experience; never for critical task UI.

### DENSITY 1..10
1-3: gallery-like, large breathing room.
4-6: standard editorial/product density.
7-8: information-dense professional tools.
9-10: expert cockpit; only when users benefit from simultaneous information.

### TRUST_PRESSURE 1..10
High for finance, health, security, government, checkout, enterprise procurement, destructive actions. High trust pressure reduces gimmicks, ambiguous controls, faux metrics, and visual novelty that competes with certainty.

### TASK_CRITICALITY 1..10
High when failure blocks work, loses data, spends money, changes permissions, or causes irreversible actions. High task criticality increases explicit states, predictable controls, recoverability, validation, and keyboard behavior.

## Suggested starting states
- CONVERT SaaS: 7 / 5 / 4 / 5 / 4
- CONVERT luxury consumer: 8 / 4 / 3 / 6 / 3
- OPERATE dashboard: 4 / 3 / 7 / 7 / 8
- OPERATE creative tool: 6 / 5 / 7 / 5 / 8
- EXPLAIN docs: 4 / 2 / 5 / 7 / 5
- SHOWCASE portfolio: 9 / 6 / 3 / 3 / 2

These are starting points, not mandatory presets.
