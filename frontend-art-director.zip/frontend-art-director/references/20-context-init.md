# Context Init

Purpose: create durable project context so later design work does not reset to generic defaults.

## Capture
- product name and one-sentence truth
- primary audience and secondary audience
- key jobs/actions
- surface inventory and primary surface modes
- brand voice and anti-voice
- existing logo, colors, type, imagery, icons
- references and anti-references
- legal/trust/accessibility constraints
- technical stack and existing UI libraries
- immutable product facts

## Output
Write or update:
- `PRODUCT.md`: audience, product truth, actions, trust constraints, anti-references.
- `DESIGN.md`: visual grammar, tokens, component rules, theme strategy, motion grammar.
- `.frontend-art-director/config.json`: runtime settings and ignored detector rules/files.

Never overwrite a richer existing document with a thin template. Merge intentionally.

## Tool helper
When filesystem access exists, `python scripts/init_project.py <project-root>` can create non-destructive starter files. Existing files are preserved unless `--force` is explicitly supplied.
