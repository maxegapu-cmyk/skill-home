# UX Copy and Content Resilience

## Clarity
Labels describe the action/result, not internal implementation.
Error messages answer:
1. what happened
2. why, if known and useful
3. what the user can do next

## Consistency
Use one stable term for one product concept. Do not rotate synonyms merely for literary variety in navigation and controls.

## Content stress tests
Test:
- very long names
- translated strings ~30-50% longer
- empty values
- large numbers
- dates/time zones
- validation errors
- multiline user-generated content

## Marketing truth
Never fabricate proof. If evidence is unavailable, design an evidence slot or use product demonstration rather than fake testimonials/metrics.
