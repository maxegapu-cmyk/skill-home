# Refine: push / restrain / distill

## push
Increase authorship by changing the highest-leverage variables first:
- scale contrast
- composition asymmetry
- typographic character
- image crop/placement
- rhythm
- selective color contrast
- purposeful motion
Do not merely add gradients, glow, blur, and larger shadows.

## restrain
Reduce simultaneous signals. Remove decorative layers before reducing semantic hierarchy.
Keep one dominant focal point, one accent strategy, one motion grammar.

## distill
Delete things that do not change comprehension, persuasion, task success, identity, or emotional pacing.
Distillation is not making everything gray and tiny.
