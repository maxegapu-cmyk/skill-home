# Motion and Delight

Motion must communicate at least one: causality, spatial relationship, hierarchy, progress, state change, continuity, or character.

## Motion bands
- **1-3**: state transitions only; 100-220ms class timing, minimal travel.
- **4-7**: purposeful entrances, shared-element/spatial transitions, moderate stagger, scroll reveal when it helps pacing.
- **8-10**: choreographed/scroll-linked systems only on surfaces that can afford them; require degradation and reduced-motion plans.

## Implementation discipline
- prefer CSS for simple transitions
- verify dependencies before using an animation library
- prefer transform/opacity for routine animation
- avoid broad `transition: all`
- no required information exclusively revealed by hover/motion
- no endless ornamental animation near reading/task zones
- reduced-motion path is mandatory for material motion
- critical feedback must have a static/semantic cue

## Delight
Delight follows clarity. It should attach to a meaningful action or brand moment, not appear as random confetti, bounce, or sparkles.
