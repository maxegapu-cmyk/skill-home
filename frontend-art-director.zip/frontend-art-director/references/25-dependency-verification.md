# Dependency Verification

Before using any third-party package:
1. inspect `package.json` and lockfile when available
2. verify framework/runtime compatibility
3. verify package is already present, or explicitly add it only when the task authorizes dependency changes
4. prefer native CSS/platform primitives for small effects
5. avoid two libraries that solve the same primitive unless migration requires it

## Failure rules
- Never hallucinate an import path.
- Never write code that assumes a package exists because it is common.
- If the project cannot be inspected, present dependency-requiring code as conditional and provide a native fallback.
- Do not silently introduce a large animation/rendering dependency for one microinteraction.

`python scripts/project_probe.py <project-root>` inventories framework, package manager, and common UI/motion libraries without modifying the project.
