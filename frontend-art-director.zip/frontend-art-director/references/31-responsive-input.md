# Responsive and Input Adaptation

Responsive means recomposition, not uniform shrinking.

## Test ranges
At minimum inspect one wide desktop and one narrow/mobile state. Add tablet/intermediate states when the layout meaningfully changes.

## Preserve
- content priority
- primary action visibility
- logical reading order
- touch target adequacy
- form/table/task usability
- media focal point

## Input modes
Account for keyboard, mouse/trackpad, touch, and zoom.
- Hover cannot be the only way to reveal a required action.
- Keyboard focus order follows task order.
- Drag interactions need an alternative when essential.
- Sticky elements must not consume most of a narrow viewport.

## Dense data
Prefer responsive column priority, horizontal scroll with clear affordance, stacked summaries, or detail drill-in over crushing columns to illegibility.
