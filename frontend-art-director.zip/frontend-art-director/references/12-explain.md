# EXPLAIN Mode

Success: the reader understands, finds, and retains information.

Priorities:
- hierarchy and navigation
- readable line length and type size
- predictable heading structure
- code/table/media readability
- anchors/search when content scale requires them
- calm contrast and durable links
- mobile reading behavior

Decoration must support pacing or memory. Do not turn documentation into a marketing page.
