# Critique

Give a judgment, not a compliment sandwich.

Score only where useful. Prioritize issues by impact:
1. task/content failure
2. hierarchy/comprehension failure
3. interaction/accessibility failure
4. system inconsistency
5. generic/derivative styling
6. micro-polish

For each material issue: evidence → consequence → smallest effective fix.
Distinguish "ugly but usable" from "beautiful but unusable"; they require different remedies.
End with: keep / change / remove.
