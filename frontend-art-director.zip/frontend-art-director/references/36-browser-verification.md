# Browser / Visual Verification

When browser or screenshot tooling is available:
1. capture baseline before large redesigns
2. inspect 1280-1440px-class desktop (or representative wide view)
3. inspect 360-430px-class narrow view
4. inspect hover/focus/open/error/loading states that materially affect the task
5. check fixed/sticky overlays, clipping, scroll traps, and content jumps
6. compare final implementation against the stated visual world rather than only against code correctness

## Verification hierarchy
- browser result beats code intention
- real content beats lorem ipsum assumptions
- narrow-state failures are not deferred cosmetic bugs

If browser tooling is unavailable, run static checks and state the visual-verification limitation.
