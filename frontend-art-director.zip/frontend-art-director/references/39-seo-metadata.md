# Web Metadata / Discoverability Hygiene

Apply when the task includes public web pages and metadata is in scope.

Check:
- unique, truthful title and description
- canonical URL strategy when relevant
- social preview metadata/assets
- semantic heading structure
- link text quality
- image alt purpose
- structured data only when factually valid
- no hidden keyword stuffing

Do not invent organization details, ratings, reviews, prices, or schema fields simply to fill structured data.
