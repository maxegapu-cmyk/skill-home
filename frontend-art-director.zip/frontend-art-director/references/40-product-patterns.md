# Product Patterns: Forms, Tables, Dialogs, Dense Data

## Forms
- persistent labels
- clear required/optional semantics
- field-level errors tied to fields
- preserve user input after validation failure
- disable destructive duplicate submits but keep recovery clear
- do not use placeholder as the only label

## Tables
- align numbers consistently
- preserve header association
- offer sort/filter only when real
- define narrow-screen strategy
- avoid cardifying every row on desktop unless it improves comprehension

## Dialogs
- clear title/purpose
- focus enters and returns correctly
- Escape/cancel behavior is predictable unless unsafe
- destructive confirmation names the object/action

## Dense workspaces
- use separators, alignment, grouping, and density tokens before adding more containers
- keep primary actions stable
- support keyboard where expert speed matters
