# Twin Final Gate

Completion requires both gates.

## Taste Gate
- hierarchy understood quickly
- one primary focal event per region
- typography roles are distinct and coherent
- spacing/grid feel systemic, not locally improvised
- composition avoids repetitive template grammar
- semantic/accent color has a job
- imagery/crops belong to the visual world
- shape/border/elevation/material rules agree
- motion is purposeful and consistent
- product-specific authorship is visible
- dark/light theme hierarchy is coherent where applicable
- anti-template gate has no material unresolved finding

## Engineering Gate
- requested behavior still works
- keyboard/focus behavior credible
- semantic structure and accessible names present
- contrast sufficient or measured where tools exist
- wide/narrow layouts avoid clipping and accidental overflow
- long/localized content survives critical UI
- loading/empty/error/success/disabled states exist where needed
- destructive/irreversible actions protected
- forms/tables/dialogs follow robust interaction patterns
- assets/fonts/effects have reasonable cost
- reduced-motion path exists
- no unverified dependency/import remains

## Stop rule
If both gates pass and no reproducible material defect remains, stop. Do not destabilize a finished interface merely because another variation is imaginable.
