# Block Library Contract

Blocks are reusable solution patterns with explicit constraints, not page templates.

## Required frontmatter
- `name`
- `category`
- `surface_modes`
- `novelty_range`
- `motion_range`
- `density_range`
- `when_to_use`
- `not_for`

## Required body sections
1. Visual Sketch
2. Data / Props Contract
3. Implementation Sketch
4. Mobile Fallback
5. Motion Bands
6. Dark Mode
7. Accessibility
8. Anti-Patterns

## Discipline
- One block per file.
- Every block must stand alone conceptually.
- A block may reference existing project primitives instead of adding dependencies.
- Do not use a block when the content model does not fit it.
- Product UI blocks prioritize task grammar; marketing blocks prioritize narrative/persuasion grammar.
- Every selected block still passes full pre-flight.
