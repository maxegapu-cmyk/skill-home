# Document Existing Design System

Use when a codebase exists but its design decisions are undocumented or drifted.

## Evidence pass
Inspect representative layout, navigation, buttons, forms, cards/panels, tables, dialogs, empty states, and theme variables.
Extract:
- font families, weights, sizes, line-heights
- color primitives and semantic roles
- CSS variables / design tokens
- spacing scale and recurring gaps
- radii, borders, shadows
- component variants
- responsive breakpoints and density shifts
- dark-mode implementation
- motion timings/easing

## Reconciliation
Separate:
1. stable intentional patterns
2. one-off exceptions with a reason
3. accidental drift
4. dead/unused styles

Document the first two. Flag the latter two; do not canonize accidents.

## Helper
`python scripts/document_project.py <project-root>` performs a conservative static inventory and writes `DESIGN.inferred.md`; it does not claim semantic certainty.
