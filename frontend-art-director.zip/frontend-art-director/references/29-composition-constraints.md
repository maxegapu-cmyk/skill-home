# Composition Constraints

These constraints stop repeated AI page grammar. Apply contextually; the product may justify exceptions.

## Hero discipline
- One dominant message.
- Keep supporting copy short enough to scan without pushing the action below the first viewport on normal desktop.
- Do not stack eyebrow + badge + headline + subheadline + feature chips + trust strip + CTA + tiny legal line unless the content truly requires them.
- Use authentic product/artifact imagery when it is stronger proof than abstract decoration.

## Repetition caps
- Avoid more than two consecutive image/text split sections.
- Avoid repeated equal-weight card grids for every section.
- Avoid an eyebrow above every heading; reserve micro-labels for real taxonomy/context.
- Avoid identical entrance animation on every section.

## CTA discipline
- Primary desktop CTA label should stay on one line.
- Keep one stable label per intent unless a different action is genuinely different.
- Secondary action must be visually secondary.

## Density
- Low density does not mean empty for no reason.
- High density uses alignment, grouping, and separators before card chrome.
- Expert tools may expose simultaneous information; marketing pages should not mimic a cockpit to look technical.
