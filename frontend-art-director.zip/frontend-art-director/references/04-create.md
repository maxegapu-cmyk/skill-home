# Create

For new UI, do not start with component names. Start with the user sequence.

1. State the primary user action and secondary action.
2. Sketch information hierarchy in plain text.
3. Choose surface mode and five-axis state.
4. Choose a visual world and system strategy.
5. Implement the full requested scope.
6. Add real states: hover/focus/pressed where relevant, loading, empty, error, disabled, success.
7. Test wide and narrow layouts.
8. Run anti-template and twin final gates.

For CONVERT, copy structure follows persuasion and proof.
For OPERATE, screen structure follows tasks, objects, and state.
For EXPLAIN, structure follows comprehension and retrieval.
For SHOWCASE, structure follows the artifact and narrative experience.
