# OPERATE Mode

Success: the user completes work quickly and confidently.

Priorities:
1. task flow and object model
2. information hierarchy and scanability
3. predictable controls
4. state visibility
5. error prevention/recovery
6. keyboard/input efficiency
7. density without confusion
8. brand character in detail, not obstruction

Use familiar patterns for tables, filters, settings, forms, dialogs, and destructive actions unless a novel pattern demonstrably improves the task.
Brand can appear in type, color, icon detail, empty states, micro-motion, and composition. It should not make controls mysterious.
Dense interfaces need explicit spacing/density rules rather than random compression.
