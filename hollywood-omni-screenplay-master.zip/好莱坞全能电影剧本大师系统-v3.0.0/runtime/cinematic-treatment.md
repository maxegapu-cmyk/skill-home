# CINEMATIC TREATMENT FORGE — 电影化 Treatment 锻造

## 目的
把结构大纲翻译成一部“已经能在脑中放映”的电影，同时保持因果与人物选择，不把 Treatment 写成结构术语说明书。

## 1. Treatment Unit
每个段落至少包含：

```text
CURRENT SITUATION
CHARACTER INTENT
VISIBLE ACTION
OPPOSITION / FRICTION
RESULT
WHAT CHANGES NEXT
```

只写观众最终能够通过画面、声音、行为或可演对白理解的内容。

## 2. Visual Causality
不要写“他终于意识到自己一直活在谎言里”。
要写：什么新事实到达、他正在做的动作怎样停住/改变、他随后做出什么不同选择。

## 3. Treatment Rhythm
Treatment 不是逐场剧本，也不是梗概。它应该让读者连续感到：

`目标形成 → 方案展开 → 世界反制 → 结果偏离 → 人物调整 → 代价积累`

连续数段只有背景说明或设定解释，标为 `EXPOSITION POOL`。

## 4. Character Visibility
每个主要角色在 Treatment 中必须拥有可观察的策略，不只拥有性格标签。配角的存在要么改变主角行动，要么改变信息/资源/关系/道德压力。

## 5. Setpiece Integration
大片型 Treatment 的大场面至少承担两项：
- 改变资源/空间；
- 公开秘密；
- 破坏关系；
- 造成不可逆伤害；
- 改写胜利条件；
- 证明/反驳角色能力或信念。

只有“很好看”但可以从故事中摘掉的奇观，标为 `DETACHABLE SPECTACLE`。

## 6. Ending Continuity
Treatment 的最后一段必须自然通往 Ending Vector；不能在末段突然更换电影问题。

## 7. Treatment Exit Gate

```text
[ ] 每个 Sequence 的目标与结果在 Treatment 中可读
[ ] 主要转折来自选择/反制，不是作者摘要
[ ] 视觉/声音足够承载情绪与信息
[ ] 大场面至少留下两个真实后果
[ ] 主角策略在推进中发生变化
[ ] 对手在主角之外仍有行动痕迹
[ ] 结尾与前文同一因果链
```
