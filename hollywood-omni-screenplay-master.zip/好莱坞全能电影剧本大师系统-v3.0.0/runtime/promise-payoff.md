# PROMISE–PAYOFF ENGINE

## Promise Ledger

```text
ID | PROMISE | CREATED | EXPECTED WINDOW | STATUS | PAYOFF | EFFECT
```

状态：`OPEN / PARTIAL / PAID / DELIBERATELY_UNPAID / BROKEN`

## What Creates Promise
- 强调的身份/秘密；
- 特殊能力；
- 关键道具；
- 反复规则；
- 明显关系问题；
- 预言/警告；
- 视觉/声音母题；
- 类型承诺；
- 观众被刻意拒绝看见的东西。

## Surprise Inevitability
反转必须同时过两关：

### Surprise
第一次看不能太早显而易见。

### Inevitability
回看时至少找到 2 个此前存在且当时有其它合理解释的证据。

靠人物突然忘记信息、作者隐藏关键事实、临时新规则制造的反转不通过。

## DELIBERATELY_UNPAID
开放项只有在“不回答本身产生意义”时才可保留，并明确观众已经得到哪一层答案。
