# REWRITE LAB — 后期强化总工厂

> 初稿只是材料。每一轮只处理一个层级的失败，避免所有问题混在一起重写。

## PASS 1 — MACRO STRUCTURE
检查 Dramatic Question、Opening Promise、Commitment、Midpoint Reframe、Crisis、Climax、Closing Proof。

输出只列：`KEEP / WEAK / MISSING / REBUILD TARGET`。

## PASS 2 — CAUSAL DEPENDENCY
对关键节点跑 Delete Node Test。修掉“发生了但没有造成后果”的假节点与巧合解法。

## PASS 3 — PROTAGONIST AGENCY
删掉主角关键选择，如果剧情仍自动走到同一结果，重做行动链。高潮必须由主角做出不可替代的决定。

## PASS 4 — ANTAGONIST AUTONOMY
重跑对手 Counter-Spine。检查对手是否学习、适应、保护资源、执行计划；修掉“等主角上门”的反派。

## PASS 5 — POWER / INFORMATION WARFARE
逐个核心场检查谁掌权、为什么、何时移动；检查知道/怀疑/证明/行动权是否混淆。

## PASS 6 — PROMISE / PAYOFF + SURPRISE INEVITABILITY
清理 BROKEN Promise；对反转跑 Surprise + Inevitability 双检。

## PASS 7 — SCENE VITALITY + GOLDEN SCENE STANDARD

### GOLDEN SCENE
先选出当前最强对白场、动作场、情绪场、反派场、视觉场。

### Raise-to-Gold Test
对核心弱场问：
- 缺真正的策略冲突？
- 缺不可逆变化？
- 缺视觉行动？
- 缺信息/权力重分配？
- 缺一个只有本片人物才会做的选择？

不是把所有场写成同一种“高潮”。

## PASS 8 — DIALOGUE / REHEARSAL / SAYABILITY
顺序：Fact → Objective → Tactic → Trigger → Subtext → Silence → Voice → Sayability → Consequence。

关键场重跑 Cold Table Read 与 Actor Objection。

## PASS 9 — ENDING ECHO + CLIMAX OWNERSHIP
核对：
- 最终行动是否来自此前建立？
- 主角赢/输是否由选择而不是作者偏爱？
- 结尾是否留下持续后果？
- Closing Proof 是否回应 Opening Promise，但没有机械复刻？

## Stop Condition
当一个 Pass 的剩余问题只属于其它层，不继续越权修改；把问题交给对应 Pass。
