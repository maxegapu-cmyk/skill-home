# OUTLINE STRESS TEST — 长片大纲敌意性压力测试

## 目的
在进入逐场写作前，主动尝试把大纲打坏。能被轻易打坏的结构，不值得用几十场戏去掩盖。

## Test 1 — 30-Second Spine
不用专有结构术语，在 30 秒内讲清：主角想什么、谁/什么阻止、为什么越来越不能退、最终必须做什么选择。

讲不清通常表示主线被支线/设定淹没。

## Test 2 — Delete Five
随机删掉五个非首尾关键节点。若大部分后续仍能原样继续，因果密度不足。

## Test 3 — Swap Sequences
尝试交换两个中段 Sequence。若几乎无需修改，Sequence 之间依赖不足。

## Test 4 — Smart Character
为主角写出最合理方案，为对手写出最合理反制。若结构必须依赖一方犯低级错误才能成立，重做。

## Test 5 — Antagonist-Only Movie
只写对手时间线。若对手没有连续计划，只是一串“出场制造麻烦”，反派结构失败。

## Test 6 — Midpoint Removal
删掉中点。若后半电影的目标、理解、胜利条件和关系几乎不变，中点不是 Reframe。

## Test 7 — Crisis Free Exit
寻找第三条几乎无代价的路。找得到就不是危机，先补逻辑封锁或前序承诺。

## Test 8 — Climax Autopsy
把高潮解法拆成最小元素，逐个标出首次建立位置。任何关键元素首次出现在高潮都进入风险。

## Test 9 — Trailer Test
只看大纲能否找出 3–5 个独特、属于本片而不是“任何大片都能有”的戏剧/视觉时刻。若只能找到通用追车、爆炸、争吵，作品身份不足。

## Test 10 — Golden Scene Forecast
在大纲阶段指出至少三个“如果写好会成为招牌场”的候选，并说明它们为什么只有本片能成立。不是提前写金句，而是确保结构会孕育招牌场。

## Test 11 — Promise Debt
列出所有高显著 Promise，检查后半是否有支付窗口。没有窗口的承诺要删、降显著或重构。

## Test 12 — Ending Echo
把 Opening Promise 与 Closing Proof 并排。若结尾只完成情节而没有改变开头意义，补人物/主题层回响。

## Exit
只有硬伤被修到不会在逐场阶段无限放大，才允许进入 Scene Engine。
