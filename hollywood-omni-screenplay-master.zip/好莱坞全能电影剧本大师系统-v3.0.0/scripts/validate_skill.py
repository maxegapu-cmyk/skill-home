from pathlib import Path
import hashlib, re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1])
required = [
 'SKILL.md','VERSION','runtime/outline-forge.md','runtime/feature-architecture.md','runtime/sequence-engine.md',
 'runtime/character-antagonist-engine.md','runtime/power-information-war.md','runtime/scene-engine.md','runtime/rehearsal-dialogue.md',
 'runtime/story-state.md','runtime/promise-payoff.md','runtime/rewrite-lab.md','runtime/final-audit.md','runtime/cinematic-treatment.md','runtime/outline-stress-test.md',
 'references/dialogue-master.md','references/hollywood-feature.md','references/genre-adapters.md','references/ending-and-payoff.md',
 'references/natural-chinese.md','references/structure-lenses.md','tests/regression-cases.md'
]
errors=[]
for rel in required:
    if not (root/rel).is_file(): errors.append(f'missing:{rel}')
text='\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in root.rglob('*') if p.is_file() and p.name != 'SHA256SUMS')
for term in ['hollywood-omni-screenplay-master','OUTLINE FORGE','MIDPOINT REFRAME','CRISIS CHOICE','CLIMAX OWNERSHIP','ANTAGONIST AUTONOMY','GOLDEN SCENE','COLD TABLE READ','ACTOR OBJECTION','SILENCE PASS','REWRITE LAB']:
    if term.lower() not in text.lower(): errors.append(f'missing-concept:{term}')
skill=(root/'SKILL.md').read_text(encoding='utf-8') if (root/'SKILL.md').exists() else ''
if not re.search(r'^name:\s*hollywood-omni-screenplay-master\s*$', skill, re.M): errors.append('frontmatter-name')
if not re.search(r'^version:\s*3\.0\.0\s*$', skill, re.M): errors.append('frontmatter-version')
cases=(root/'tests/regression-cases.md').read_text(encoding='utf-8') if (root/'tests/regression-cases.md').exists() else ''
case_count=len(re.findall(r'^\d{2}\.', cases, re.M))
if case_count < 30: errors.append(f'regression-count:{case_count}')
# basic relative markdown link target check
for p in root.rglob('*.md'):
    s=p.read_text(encoding='utf-8', errors='ignore')
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', s):
        if '://' in target or target.startswith('#'): continue
        q=(p.parent/target.split('#')[0]).resolve()
        if not q.exists(): errors.append(f'broken-link:{p.relative_to(root)}->{target}')
if errors:
    print('VALIDATION FAIL')
    for e in errors: print(e)
    raise SystemExit(1)
print(f'VALIDATION PASS | files={sum(1 for p in root.rglob("*") if p.is_file())} | regression_cases={case_count}')
