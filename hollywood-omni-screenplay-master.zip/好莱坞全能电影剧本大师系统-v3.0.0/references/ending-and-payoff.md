# Ending & Payoff

## Ending Vector
结尾先定“最后要付的代价和最终选择”，再找最具体的动作/画面/声音证明。

## Two Ending Tests
### Logic Completion
核心行动线是否得到足够结算？

### Emotional Residue
最后留下的是胜利、失去、错位、恐惧、释放、悔恨还是新的责任？必须由可见后果承担。

## Ending Echo
结尾可以回响开场的：
- 同一物件不同用法；
- 同一空间不同关系；
- 同一句话不同意义；
- 同一能力不同道德选择；
- 同一声音从日常变成代价。

机械重复不算 Echo；意义必须变化。
