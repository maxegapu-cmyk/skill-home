#!/usr/bin/env python3
import importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("sbforge", ROOT/"scripts/sbforge.py")
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
cases=[
({"model":"Seedance 2.0","duration":8,"reference_count":2},"20_SINGLE"),
({"model":"Seedance 2.0","duration":25,"reference_count":2},"20_CHAIN"),
({"model":"Seedance 2.5","duration":22,"reference_count":6},"25_SINGLE"),
({"model":"Seedance 2.5","duration":22,"edit_existing":True},"25_EDIT"),
({"model":"Seedance 2.5","duration":22,"extend_existing":True},"25_EXTEND"),
({"model":"Seedance 2.5","duration":22,"strict_keyframes":True},"25_KEYFRAME"),
({"model":"Seedance 2.5","duration":22,"storyboard_reference":True},"25_STORYBOARD"),
({"model":"Seedance 2.5","duration":90},"25_SEQUENCE"),
({"model":"unknown","duration":10},"MODEL_AGNOSTIC")
]
for brief,want in cases:
    got=m.choose_route(brief)
    assert got==want,(brief,got,want)
print(f"PASS: {len(cases)} routing cases")
