#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
cmds=[
 [sys.executable, str(ROOT/'scripts/validate_skill.py')],
 [sys.executable, str(ROOT/'tests/test_router_matrix.py')],
 [sys.executable, str(ROOT/'scripts/storyboard_lint.py'), str(ROOT/'examples/board-dialogue.json')],
 [sys.executable, str(ROOT/'scripts/sbforge.py'), str(ROOT/'examples/brief-action.json')],
 [sys.executable, str(ROOT/'scripts/sbforge.py'), str(ROOT/'examples/brief-dialogue.json')]
]
for c in cmds:
    print('>', ' '.join(c))
    r=subprocess.run(c,capture_output=True,text=True)
    print(r.stdout,end='')
    if r.stderr: print(r.stderr,end='')
    if r.returncode: raise SystemExit(r.returncode)
print('ALL TESTS PASS')
