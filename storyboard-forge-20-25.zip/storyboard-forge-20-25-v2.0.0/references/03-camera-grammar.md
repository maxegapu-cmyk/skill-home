# Camera Grammar

Use camera language because it changes storytelling, not to decorate prompts.

## Shot-size jobs
- ECU: micro-information, eye/hand/object cue
- CU: emotion, reaction, detail ownership
- MCU/MS: dialogue + gesture
- MLS/FS: body action, blocking
- WS/EWS: geography, scale, isolation

## Angle jobs
- eye level: neutral relationship
- low: power/scale/threat
- high: vulnerability/diagrammatic clarity
- overhead: geometry, choreography, pattern
- profile: motion readability / confrontation
- over-shoulder: dialogue relation and eyeline
- POV: subjective information

## Movement jobs
- push/dolly-in: attention narrows / commitment
- pull-out: reveal context / emotional separation
- lateral track: follow movement / compare spaces
- orbit: relationship/scale/hero reveal; use sparingly
- pan/tilt: reframe or reveal; keep motivation explicit
- handheld: instability/observation, not automatic realism
- locked-off: tension, comedy timing, graphic clarity

## Movement phase
Always specify whether the camera is:
`stationary -> accelerates -> cruises -> decelerates -> stops`.
For handoffs, preserve the phase or intentionally break it.

## Avoid
- stacking dolly + orbit + crane + rack focus in one short shot without narrative reason
- impossible lens jargon
- changing focal length every cut with no visual logic
- using “cinematic” as a substitute for composition
