# Scenario Playbooks

## Dialogue
Coverage minimum: master/relationship shot + speaker emphasis + listener reaction only if the dramatic change needs it. Protect eyelines, mouth visibility, room geography and overlap.

## Action
Use pose-chain cards. Prefer clear silhouettes and grounded contact over excessive cuts. Re-establish geography after any axis-breaking cut.

## Product
Lock product geometry first. Build reveal order: context -> need -> feature interaction -> proof/detail -> hero end frame. Treat readable packaging text as a risk item.

## MV / performance
Map musical phrases, not just seconds. Decide when camera follows the performer, when performer crosses camera, and when edit takes control. Crowd inserts must not interrupt identity/performance continuity unless intentional.

## Horror
Design information asymmetry: what audience sees, what character sees, and what sound reveals. Negative space and offscreen sound often outperform constant monster exposure.

## Comedy
The reaction shot is often the punchline. Protect hold duration after the visual event; do not overcut the laugh away.

## Trailer
Each shot must sell one of: world, character, threat, escalation, signature image, hook, title/end beat. Avoid synopsis coverage.
