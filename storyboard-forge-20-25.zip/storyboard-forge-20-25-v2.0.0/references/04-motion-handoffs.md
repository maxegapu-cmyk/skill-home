# Motion Handoffs — Action / Dance / Sports / Performance

## Pose chain
For each action beat write:
`setup pose -> initiation -> contact/peak -> recoil/recovery -> handoff pose`.

## Contact integrity
At the moment of contact specify:
- who initiates
- which limb/prop
- target contact point
- force direction
- receiving body reaction
- feet/support points
- what does NOT move

## Screen direction
Preserve left/right travel across cuts unless the cut intentionally reverses orientation and includes a re-establishing cue.

## Motion budget
A short unit should prioritize one hard thing:
- complex body interaction OR
- complex camera move OR
- destruction/simulation OR
- complex multi-character dialogue.
Combining two may be viable; combining all usually lowers usable rate.

## Handoff trick
End on a readable, stable but still energized pose. Avoid cutting during ambiguous limb occlusion unless the next shot is deliberately hiding the match.
