# Continuity Bible

## State vector
Track only dimensions that can visibly drift:

### Character
identity, age appearance, hair, facial hair, body build, makeup, scars, accessories.

### Wardrobe
item, material, layer order, closure state, dirt/wetness/damage, sleeves/gloves/footwear.

### Props
shape, color, size, handedness/owner, exact location, open/closed/on/off, damage.

### Space
cardinal layout or screen-space layout, entrances/exits, key furniture, height levels, distance anchors.

### Light/time
source direction, softness, color temperature, practicals, weather, time-of-day.

### Motion
body orientation, lead foot, planted/contact points, velocity direction, camera movement phase.

### Audio
speaker identity, voice texture, room tone, music phase, sound bridge.

## Handoff card
At each cut write:
- outgoing body pose
- outgoing gaze
- outgoing prop ownership
- outgoing motion vector
- outgoing camera vector
- next shot entry match / intentional mismatch

## Drift priority
1. identity
2. prop geometry/ownership central to story
3. spatial geography
4. wardrobe state
5. pose/momentum
6. lighting direction
7. fine style texture

When prompt budget is tight, protect in this order unless the user says otherwise.
