# Capability Router — Seedance 2.0 / 2.5

## Principle
The current product UI/API beats any static document. Capabilities can differ by surface, region and date. Verify before quoting hard limits.

## Stable high-level distinctions
### Seedance 2.0
Use when the job benefits from short, tightly controlled generation units, multimodal references, native audio, or a workflow where short clips will be chained and edited. Public product materials describe text/image/audio/video input, multi-shot storytelling and reference-driven control.

### Seedance 2.5
Use when the job benefits from longer single-pass storytelling, higher reference capacity, stronger reference interpretation, targeted editing, extension, or storyboard/keyframe style control. ByteDance announced up to 30 seconds per generation and up to 30 image, 10 video and 10 audio references, with timestamp-level editing and multi-round extension.

## Conservative router
Choose **2.0** when:
- the scene is naturally short and dense;
- a 4–15s generation unit is enough on the active surface;
- short-chain iteration is cheaper/safer than one long render;
- maximum resolution on the chosen surface matters more than long single-pass duration;
- the accepted project already uses 2.0 references and handoffs.

Choose **2.5** when:
- one scene wants >15s continuous narrative and the surface supports it;
- many identity/location/prop/camera/audio references must coexist;
- targeted edit/extension can save an otherwise good result;
- storyboard/keyframe/reference interpretation is central;
- the scene has several ordered beats that benefit from time ranges.

Choose **MODEL_AGNOSTIC** when:
- the user has not selected a model;
- the platform is unknown;
- the scene will be shopped across several models.

## Surface check block
Before giving model-specific settings, record:
- surface/app/API:
- model label actually visible:
- duration options:
- aspect/resolution options:
- reference counts/types:
- first/last frame available?:
- storyboard/keyframe available?:
- extend available?:
- local edit available?:
- audio generation/reference available?:
- notes/date checked:

If unknown, omit the setting rather than inventing it.
