# Shot Contract

A shot contract is the unit of direction. It answers what the audience sees change, how the camera witnesses it, and what exact state must survive into the next shot.

## Required fields
- id
- duration
- story_job
- start_state
- end_state
- shot_size
- camera_angle
- camera_move
- blocking
- spatial_layers
- continuity_locks
- reference_bindings
- transition
- risk_flags
- prompt

## Start/end state grammar
Prefer concrete state tuples:
`CHAR_A standing left of table, right hand on cup, gaze to CHAR_B, camera 2m front-right, dolly stopped`
not:
`the character is tense in a cinematic scene`.

## Overload detector
Split a shot if it asks for more than one of these simultaneously without a clear causal chain:
- major location change
- major costume/identity change
- complex contact choreography
- new prop reveal + complex action
- dialogue exchange among 3+ speakers
- camera move with multiple reversals
- transformation + fight + environment destruction

## Edit shot vs generation unit
An edit shot may be 0.5–3 seconds. A generation unit may contain several edit shots when the model can hold continuity, or one edit shot may need several generations when physics is difficult. Never force them to be the same thing.
