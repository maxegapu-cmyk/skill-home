# Prompt Compiler

## Global block
Write once per generation unit:
- identities and asset bindings
- setting/time
- visual treatment that truly matters
- audio policy
- invariants

## Timed block
Use exact time windows only when supported and useful:
`00:00-00:04 visible event + camera + sound + end state`

Do not fill every second with text. Time windows are for control, not verbosity.

## Reference binding syntax (surface-neutral)
`REF_CHAR_A -> identity only; do not copy background or pose`
`REF_CAM_01 -> camera motion/rhythm only; do not copy subject identity`
`REF_LOC_A -> architecture/spatial layout; do not change time-of-day unless specified`

## Prompt spine
`who/what + where + visible action + camera witness + sound/dialogue + endpoint`

## Bad abstraction
“epic, premium, masterpiece, immersive, emotional, cinematic, dynamic”
These words may be style hints but cannot replace visible direction.

## Good concreteness
“CHAR_A backs two steps toward the doorway while keeping the pistol low; CHAR_B remains seated; the camera tracks laterally at waist height and stops when the doorway aligns behind CHAR_A.”

## Negatives
Use only failure-linked exclusions:
- no identity swap
- no extra limb/weapon
- no text/logo mutation
- do not change wardrobe/prop
- no camera jump before endpoint
Avoid giant generic negative lists.
