# Storyboard Forge 20/25 v2.0.0

原创的 AI 视频分镜 Skill，重点不是“把脚本切成若干漂亮画面”，而是把故事、镜头、人物/道具连续性、动作交接、参考素材权限、Seedance 2.0/2.5 路由、返修策略放进同一条生产链。

## 适合
剧情短片、AI 电影、广告、产品片、MV/演唱、打斗、追逐、对白、恐怖、喜剧、动漫、纪录感、预告片，以及需要人物/服装/道具/场景跨镜头一致的项目。

## 核心区别
1. **Beat Spine**：先保证每个段落真的推进故事，再切镜头。
2. **Shot Contract**：每镜有明确起始状态、结束状态、镜头任务和交接状态。
3. **Continuity Bible**：不靠“保持一致”四个字，直接追踪脸、服装、道具所有权、空间、屏幕方向、动作相位。
4. **Model Router**：根据任务选择 2.0 / 2.5 / 单段 / 链式 / 分镜参考 / 关键帧 / 延长 / 局部编辑。
5. **Reference Authority Map**：每个参考素材只给一个主权，防止人脸、动作、场景、风格互相污染。
6. **Retake Matrix**：局部坏就局部修，不默认整段重抽。

## 使用
把整个目录放进支持 `SKILL.md` 的 Agent Skill 目录，或让 Agent 直接读取根目录 `SKILL.md`。

典型请求：

> 用 storyboard-forge-20-25 把这个 90 秒科幻追逐场景做成 Seedance 2.5 的完整生产分镜。角色脸、装甲、武器不能漂，动作镜头需要连续，最后给生成单元和返修策略。

也可以只调用某个模式：

> FAST_BOARD：把这 15 秒对白切成最少镜头。

> REPAIR_ONLY：这是我生成失败的第 4 镜，只修人物转身后武器换手和镜头跳轴，不动其它内容。

## 工具
- `python scripts/validate_skill.py`：检查 Skill 包结构。
- `python scripts/sbforge.py examples/brief-action.json`：确定性预检/路由器。
- `python scripts/storyboard_lint.py examples/board-dialogue.json`：检查分镜 JSON 的必需字段、重复 ID、空状态等。
- `python tests/run_tests.py`：跑全部内置测试。

## 设计边界
Skill 不假装替代导演判断，也不把某个第三方平台的临时 UI 参数写成永恒规则。模型能力变化时，只需要更新 `references/00-capability-router.md`，镜头设计、连续性和动作交接逻辑仍然可用。
