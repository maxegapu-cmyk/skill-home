---
name: storyboard-forge-20-25
description: Director-grade storyboard and shot-planning skill for Seedance 2.0/2.5 and general AI video workflows. Turns scripts, concepts, ads, action scenes, dialogue, MV/performance, product films, trailers, horror, comedy, anime, documentary, and mixed-reference briefs into model-routed storyboards, shot contracts, continuity locks, reference plans, generation prompts, retake plans, and edit handoffs.
version: 2.0.0
user-invocable: true
---

# Storyboard Forge 20/25 — v2.0.0

## Mission
Turn an idea into a shootable, generatable and editable sequence. Do not merely describe attractive frames. Every shot must have a dramatic purpose, a visible start state, a visible end state, a camera job, a continuity handoff, and a generation route.

This skill is model-aware but not model-worshipping. Use the smallest workflow that preserves intent and continuity.

## 0. Non-negotiables
1. Preserve user story facts, character identities, product facts and explicit visual constraints.
2. Never invent a platform limit. Read `references/00-capability-router.md` and treat current UI/API as final authority.
3. Separate STORY decisions from MODEL decisions. A good scene should survive a model swap.
4. One shot = one primary dramatic job. Split overloaded shots before adding more prompt words.
5. Continuity must be state-based, not adjective-based: pose, gaze, screen direction, prop ownership, spatial relation, camera vector, lighting direction, damage/state, audio phase.
6. For action/performance, the end pose of shot N must be a valid start pose for shot N+1 unless a deliberate discontinuity is specified.
7. Never change character face/wardrobe/prop/scene merely to make a prompt prettier.
8. Prefer repair/edit of a good take over full regeneration when the active model/surface supports it.

## 1. Intake — infer before asking
Extract if present:
- goal: film scene / ad / MV / trailer / dialogue / action / product / social / documentary / animation
- total duration and delivery aspect ratio
- recurring characters / wardrobe / props / locations
- reference assets and intended authority of each asset
- dialogue, lyrics, sound cues
- required beats / forbidden changes
- desired realism / style / camera language
- target: Seedance 2.0, Seedance 2.5, unknown, or model-agnostic

If target is unknown, build the model-agnostic storyboard first and attach a conservative route. Do not block on non-critical missing details.

## 2. Story pass
Before shots, write a **Beat Spine**:
`B# | purpose | visible change | information/emotion gained | entry state -> exit state`

Reject beats that do not change information, emotion, position, ownership, danger, goal, rhythm, or product understanding.

For scenes longer than one generation, group beats into **generation units**. A generation unit is not necessarily an edit shot; it is the smallest chunk the model can generate reliably while preserving a coherent state.

## 3. Route pass
Load `references/00-capability-router.md`.
Choose one route per generation unit:
- `20_SINGLE` — short self-contained 2.0 unit
- `20_CHAIN` — 2.0 sequence made from short linked units
- `25_SINGLE` — 2.5 unit up to the verified surface limit
- `25_STORYBOARD` — storyboard/reference guided sequence
- `25_SEQUENCE` — sequence longer than one verified single-pass unit; use native long/extension if the active surface supports it, otherwise chain units
- `25_KEYFRAME` — strict endpoint/keyframe-driven unit
- `25_EXTEND` — continue an accepted take
- `25_EDIT` — local repair without regenerating everything
- `MODEL_AGNOSTIC` — storyboard first, compile later

Write one sentence explaining why the chosen route is lower-risk than the nearest alternative.

## 4. Continuity bible
Load `references/02-continuity-bible.md`.
Create only the locks needed by the scene:
- CHARACTER LOCK
- WARDROBE LOCK
- PROP LOCK
- SPACE MAP
- LIGHT/TIME LOCK
- DAMAGE/STATE LOCK
- SCREEN-DIRECTION LOCK
- AUDIO/VOICE LOCK
- STYLE LOCK

Every recurring asset gets a canonical short ID, e.g. `CHAR_A`, `PROP_SWORD_01`, `LOC_HALL_A`.

## 5. Shot design
Load `references/01-shot-contract.md` and `references/03-camera-grammar.md`.
For every shot output:

`SHOT ID / duration / edit role / generation unit`
- Story job
- Start state
- End state
- Shot size + angle
- Camera position + movement + movement phase
- Subject blocking / action
- Foreground / midground / background relationship
- Focus / exposure intent when important
- Dialogue / sound / music cue
- Continuity locks used
- Reference bindings
- Transition / handoff
- Risk flags
- Model-ready prompt
- Minimal negatives / exclusions

Do not repeat global style prose in every shot. Put global locks once, then write only shot deltas.

## 6. Specialized modes
Route to one of these only when it materially improves the scene:
- **DIALOGUE**: eyeline, turn-taking, mouth visibility, reaction coverage, overlap, room tone, insert protection.
- **ACTION**: pose-chain, contact points, force direction, limb ownership, terrain constraints, recoveries. Load `references/04-motion-handoffs.md`.
- **PERFORMANCE/MV**: choreography phrase, beat grid, body orientation, stage geography, camera-to-performer relation, crowd cutaways.
- **PRODUCT/AD**: product geometry lock, label/text risk, feature reveal, hero angle, legal/claim-safe language.
- **HORROR/SUSPENSE**: information withholding, negative space, reveal timing, POV logic, sound-before-image.
- **COMEDY**: setup, anticipation, reaction, visual punchline, hold length.
- **ANIME/STYLIZED**: graphic pose clarity, silhouette, line-of-action, controlled camera rather than pseudo-real lens clutter.
- **DOCUMENTARY**: coverage logic, observational camera, evidence hierarchy, no invented real-world fact.

## 7. Reference architecture
Each reference gets ONE primary authority and optional exclusions:
`REF_ID | type | primary authority | allowed secondary influence | must NOT control`

Example authorities: identity, wardrobe, prop geometry, location geometry, color, lighting, camera motion, choreography, edit rhythm, voice, sound texture, first frame, last frame.

If two references compete for the same authority, resolve the conflict before prompt compilation.

## 8. Prompt compiler
Load `references/05-prompt-compiler.md`.
Compile in this order:
1. Reference bindings
2. Global continuity locks
3. One-line scene intention
4. Time-ordered visible actions
5. Camera behavior
6. Audio/dialogue
7. Explicit end state
8. Minimal exclusions

For 2.5 multi-beat work, use timestamps only when the surface/model accepts them and the timing adds control. For 2.0, avoid cramming many hard-timed beats into one short unit; split instead.

## 9. Retake policy
After a take, classify defects:
- A: identity/continuity
- B: action/physics
- C: camera/composition
- D: timing/edit rhythm
- E: dialogue/audio
- F: local visual defect

Then choose the smallest intervention:
`accept` / `prompt delta` / `reference rebinding` / `keyframe repair` / `extend` / `local edit` / `regenerate unit`.
Never rewrite the whole scene to fix a local defect if a smaller repair exists.

## 10. Output modes
Choose the smallest useful deliverable:
- `FAST_BOARD`: 4–8 shot board + prompts
- `FULL_BOARD`: beat spine + continuity bible + complete shot contracts
- `REFERENCE_BOARD`: adds reference manifest and storyboard-panel plan
- `PRODUCTION_PACK`: adds generation units, retake matrix, edit handoff, audio plan, QC checklist
- `REPAIR_ONLY`: analyzes an existing result and emits only fixes

Default: `FULL_BOARD`.

## 11. Quality gates
Before delivery, verify:
- no missing story beat
- no overloaded shot
- no impossible spatial jump without motivation
- screen direction intentional
- recurring props have ownership/state across cuts
- action handoffs preserve pose/momentum
- every generation unit has a clear final state
- reference authority has no conflict
- 2.0/2.5 limits are surface-verified or labeled unknown
- prompts contain visible instructions, not abstract praise words
- negatives are minimal and failure-specific

Run `python scripts/validate_skill.py` for package integrity.
For JSON storyboards, run `python scripts/storyboard_lint.py path/to/board.json`.
