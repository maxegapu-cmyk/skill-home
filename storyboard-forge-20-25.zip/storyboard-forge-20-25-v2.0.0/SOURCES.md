# Public research sources

This package is an original implementation. Public materials were used to identify useful problem categories and current Seedance capabilities.

## First-party/current capability references
- ByteDance Seed — “One-take Creation, Flexible Referencing: Introducing Seedance 2.5” (2026-07-31)
  https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5
- ByteDance Seed — Seedance 2.5 product page
  https://seed.bytedance.com/zh/seedance2_5
- ByteDance Seed — Seedance 2.0 official launch (2026-02-12)
  https://seed.bytedance.com/en/blog/seedance-2-0-official-launch
- Dreamina — Seedance 2.0 product page
  https://dreamina.capcut.com/tools/seedance-2-0
- Dreamina — Seedance 2.5 storyboard-to-video overview
  https://dreamina.capcut.com/seedance/seedance-2-5-storyboard-to-video

## Public GitHub patterns reviewed
- seaartpublic/skills — storyboard-prompt-assistant
- agentara/skills — aigc/video-storyboard
- aicontentskills/ai-video-storyboard-skill
- thoxakihiko/shotlist-forge
- scenario-labs/skills — scenario-seedance-storyboard
- divolleggett/character-consistency-skill
- anyhui/video-storyboard-gen-skill
- public Seedance 2.0/2.5 skill repositories surfaced by GitHub search

The package intentionally re-derives its own structure: beat spine, state-based continuity, generation-unit routing, reference authority mapping, motion handoffs, defect taxonomy and deterministic lint tooling.
