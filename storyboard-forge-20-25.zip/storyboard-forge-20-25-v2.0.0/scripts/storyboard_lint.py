#!/usr/bin/env python3
import json, sys
from pathlib import Path

ROUTES = {"20_SINGLE","20_CHAIN","25_SINGLE","25_STORYBOARD","25_KEYFRAME","25_EXTEND","25_EDIT","25_SEQUENCE","MODEL_AGNOSTIC"}
REQ = ["id","duration","story_job","start_state","end_state","camera","action","prompt"]

def fail(msg):
    print(f"FAIL: {msg}")
    return 1

def main():
    if len(sys.argv) != 2:
        print("usage: storyboard_lint.py board.json")
        return 2
    p = Path(sys.argv[1])
    data = json.loads(p.read_text(encoding="utf-8"))
    errors=[]; warns=[]
    if not data.get("title"): errors.append("missing title")
    if data.get("model_route") not in ROUTES: errors.append("invalid model_route")
    shots=data.get("shots") or []
    if not shots: errors.append("shots empty")
    ids=set()
    for i,s in enumerate(shots,1):
        for k in REQ:
            if k not in s or s[k] in (None,""): errors.append(f"shot {i}: missing {k}")
        if s.get("id") in ids: errors.append(f"duplicate shot id {s.get('id')}")
        ids.add(s.get("id"))
        if isinstance(s.get("duration"),(int,float)) and s["duration"] <= 0: errors.append(f"shot {i}: duration <= 0")
        if s.get("start_state") == s.get("end_state"): warns.append(f"shot {i}: start_state equals end_state; verify the shot changes something")
        text=(s.get("prompt") or "").lower()
        fluff=sum(w in text for w in ["masterpiece","best quality","epic cinematic masterpiece","8k ultra hd masterpiece"])
        if fluff >= 2: warns.append(f"shot {i}: prompt may rely on generic quality fluff")
    for e in errors: print("ERROR:",e)
    for w in warns: print("WARN:",w)
    if errors: return 1
    print(f"PASS: {len(shots)} shots, route={data['model_route']}, warnings={len(warns)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
