#!/usr/bin/env python3
"""Deterministic preflight/router for Storyboard Forge. No external dependencies."""
import argparse, json
from pathlib import Path


def choose_route(b):
    model=str(b.get("model","unknown")).lower()
    duration=float(b.get("duration",0) or 0)
    needs_edit=bool(b.get("edit_existing"))
    needs_extend=bool(b.get("extend_existing"))
    strict_keyframes=bool(b.get("strict_keyframes"))
    storyboard=bool(b.get("storyboard_reference"))
    refs=int(b.get("reference_count",0) or 0)
    if "2.5" in model or model in {"25","seedance25","seedance-2.5"}:
        if needs_edit: return "25_EDIT"
        if needs_extend: return "25_EXTEND"
        if strict_keyframes: return "25_KEYFRAME"
        if storyboard: return "25_STORYBOARD"
        return "25_SINGLE" if duration <= 30 else "25_SEQUENCE"
    if "2.0" in model or model in {"20","seedance20","seedance-2.0"}:
        return "20_SINGLE" if duration <= 15 and refs <= 15 else "20_CHAIN"
    return "MODEL_AGNOSTIC"


def risks(b):
    r=[]
    if int(b.get("characters",1) or 1) >= 3: r.append("multi-character identity/eyeline drift")
    if b.get("action"): r.append("physics/contact continuity")
    if b.get("dialogue"): r.append("lip-sync/turn-taking/eyeline")
    if b.get("readable_text"): r.append("in-frame text fidelity")
    if int(b.get("reference_count",0) or 0) > 8: r.append("reference authority conflict")
    if float(b.get("duration",0) or 0) > 30: r.append("long-form handoff and edit continuity")
    return r


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("brief")
    ap.add_argument("-o","--output")
    a=ap.parse_args()
    b=json.loads(Path(a.brief).read_text(encoding="utf-8"))
    route=choose_route(b)
    lines=[f"# Preflight — {b.get('title','Untitled')}","",f"- Route: `{route}`",f"- Duration: {b.get('duration','?')}s",f"- Aspect: {b.get('aspect','unspecified')}",f"- References: {b.get('reference_count',0)}",""]
    rr=risks(b)
    lines.append("## Risk flags")
    lines += [f"- {x}" for x in rr] or ["- none from deterministic preflight; creative review still required"]
    lines += ["","## Required planning blocks","- Beat Spine","- Continuity Bible","- Shot Contracts","- Reference Authority Map","- Generation Unit Plan","- Retake/Repair Plan"]
    out="\n".join(lines)+"\n"
    if a.output: Path(a.output).write_text(out,encoding="utf-8")
    else: print(out)

if __name__=="__main__": main()
