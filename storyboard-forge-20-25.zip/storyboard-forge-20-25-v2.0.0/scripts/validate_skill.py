#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
required=[
"SKILL.md","README.md","SOURCES.md","references/00-capability-router.md","references/01-shot-contract.md",
"references/02-continuity-bible.md","references/03-camera-grammar.md","references/04-motion-handoffs.md",
"references/05-prompt-compiler.md","references/06-scenario-playbooks.md","schemas/storyboard.schema.json",
"scripts/storyboard_lint.py","scripts/sbforge.py","templates/production-board.md","examples/brief-action.json","examples/board-dialogue.json"
]
errs=[]
for f in required:
    if not (ROOT/f).exists(): errs.append(f"missing {f}")
sk=(ROOT/"SKILL.md").read_text(encoding="utf-8")
if "name: storyboard-forge-20-25" not in sk: errs.append("frontmatter name missing")
for rel in re.findall(r'`(references/[^`]+\.md)`',sk):
    if not (ROOT/rel).exists(): errs.append(f"broken reference {rel}")
if errs:
    for e in errs: print("ERROR:",e)
    sys.exit(1)
print("PASS: package structure and internal references OK")
