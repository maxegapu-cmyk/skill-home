# {{PROJECT}} — Production Board

## 1. Delivery target
- Final duration:
- Aspect ratio:
- Target model/surface:
- Output mode: FAST_BOARD / FULL_BOARD / REFERENCE_BOARD / PRODUCTION_PACK / REPAIR_ONLY

## 2. Beat Spine
| Beat | Purpose | Visible change | Entry -> Exit |
|---|---|---|---|

## 3. Model route
- Chosen route:
- Why this route:
- Surface capabilities verified:

## 4. Continuity Bible
### Character locks
### Wardrobe locks
### Prop locks
### Space map
### Light/time locks
### Audio/voice locks

## 5. Reference Authority Map
| Ref | Type | Primary authority | Allowed secondary | Must not control |
|---|---|---|---|---|

## 6. Generation Units
| Unit | Model route | Duration | Included shots | Start state | End state |
|---|---|---:|---|---|---|

## 7. Shot Contracts
### S01
- Story job:
- Start state:
- End state:
- Camera:
- Blocking/action:
- Spatial layers:
- Dialogue/sound:
- Continuity locks:
- References:
- Transition/handoff:
- Risks:
- Model-ready prompt:
- Minimal exclusions:

## 8. Retake Matrix
| Defect | Smallest repair | What must remain unchanged |
|---|---|---|

## 9. QC
- [ ] story beats complete
- [ ] identities stable
- [ ] prop ownership stable
- [ ] geography/screen direction intentional
- [ ] pose/momentum handoffs valid
- [ ] generation-unit endpoints explicit
- [ ] reference authority conflicts resolved
- [ ] model/surface limits verified or marked unknown
