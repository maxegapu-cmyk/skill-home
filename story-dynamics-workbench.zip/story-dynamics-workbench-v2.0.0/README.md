# Story Dynamics Workbench v2.0.0

A clean-room, model-agnostic workbench for **novel writing, screenplay development, character-life modeling, long-form continuity, and causal plot simulation**.

The core idea is simple:

> A story is not a sequence of generated scenes. It is an evolving system of people, memories, beliefs, relationships, material constraints, promises, and irreversible consequences.

## What v2 adds

v2.0 is a full rebuild around **character life history + temporal world state + branch simulation**.

It can:

- reconstruct a character from childhood through the present;
- store formative experiences as memory episodes rather than flat adjectives;
- distinguish what objectively happened from what each character perceived, remembers, believes, hides, or misunderstands;
- model desires, fears, values, self-image, defenses, habitual tactics, stress behavior, and change thresholds;
- maintain a temporal event graph with cause, effect, provenance, and validity windows;
- simulate several plausible future branches without committing any of them to canon;
- propagate consequences through characters, relationships, institutions, locations, objects, resources, and public knowledge;
- write novels, scenes, episode outlines, treatments, and Fountain-compatible screenplays;
- convert prose into screenplay through factual anchors and fidelity checks;
- run continuity, causality, character, knowledge-boundary, setup/payoff, and scene-function audits;
- snapshot and roll back project state.

## Design rule

**Drafts propose. State validates. Human acceptance commits.**

Generated material never becomes canon merely because a model produced it.

## Quick start

```bash
python tools/storyforge.py init demo_project
python tools/storyforge.py validate demo_project
python tools/storyforge.py context demo_project --character mira
python tools/storyforge.py snapshot demo_project before_branch
```

Then use `SKILL.md` + `PLAYBOOK.md` with your preferred LLM.

## Core folders

- `state/` — accepted story state only.
- `drafts/` — prose/script drafts; non-canon.
- `branches/` — simulated futures; non-canon until accepted.
- `characters/` — life history, psyche, memory, knowledge, relationships.
- `references/` — public-source design notes.
- `schemas/` — machine-readable contracts.
- `tools/` — standard-library prototype utilities.
- `tests/` — regression tests.

## Modes

- `DISCOVER` — reconstruct source material and current story state.
- `CHARACTER` — build or update a character life model.
- `SIMULATE` — forecast plausible future plot branches.
- `NOVEL` — write prose from validated state.
- `SCREENPLAY` — write screenplays/treatments/scenes in a filmable form.
- `ADAPT` — convert prose to screenplay while protecting factual anchors.
- `AUDIT` — diagnose without mutating canon.
- `REPAIR` — apply targeted fixes while preserving unrelated valid work.

## Status

v2.0.0 includes a working state-management prototype, context compiler, continuity auditor, Fountain exporter, branch validator, snapshot/rollback support, sample project, and regression tests. It intentionally does **not** bundle an LLM provider.
