# Prose-to-Screenplay Adaptation

## Protected anchors

Before adapting, extract:
- indispensable events;
- cause/effect relationships;
- character decisions;
- relationship turns;
- identity/role facts;
- important objects;
- setup/payoff pairs;
- ending conditions.

## Adaptation choices

Each omitted/combined/moved beat records:
- source function;
- screenplay replacement;
- information preserved;
- character effect preserved;
- risk created.

## Fidelity audit

Check not only “did this event remain?” but:
- who caused it;
- who knew what;
- what it meant to the character;
- what later event depended on it.
