# Long-Form Context Compiler

## Problem

Long stories fail when every new generation either receives too little context or receives a giant undifferentiated summary.

## Context Pack structure

### Must include
- hard canon constraints directly relevant to task;
- current time/location;
- active cast state;
- knowledge boundaries;
- unresolved promises that can be affected.

### Usually include
- 3–8 causally relevant events;
- active relationship edges;
- memory episodes whose triggers match the scene;
- current plans/secrets;
- location/resource state.

### Include only when needed
- remote lore;
- resolved old arcs;
- inactive side characters;
- style examples.

## Character-private context

When simulating a character, remove:
- secrets they have never learned;
- audience-only reveals;
- another person's internal state;
- future facts.

## Compression rule

Compress facts, not causality. Preserve:
- who chose;
- why;
- what changed;
- what remains unresolved.
