# Causality and Timeline

## Two orders

Always separate:
- chronological order: when events objectively occur;
- narrative/reveal order: when the audience learns about them.

## Causal edge types

- prerequisite;
- trigger;
- decision;
- enabling condition;
- constraint;
- reaction;
- delayed consequence;
- correlation only.

Never label “B happened after A” as causal without a mechanism.

## Causal chain template

`condition -> perception -> character choice -> world reaction -> direct result -> interpretation -> secondary choice -> persistent consequence`

## Time safety

Check:
- travel duration;
- sleep/recovery;
- injury duration;
- communication delay;
- institutional process time;
- object/location availability;
- overlapping scenes;
- flashback age consistency.
