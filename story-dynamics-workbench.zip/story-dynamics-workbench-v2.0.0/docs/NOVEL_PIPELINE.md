# Novel Pipeline

## Before drafting

Compile:
- POV legal knowledge;
- active memories;
- scene question;
- current desire/fear;
- location state;
- causal obligation from prior scene.

## During drafting

Backstory enters only when activated by present stimulus or when strategically necessary for reader understanding.

Use memory as a dynamic object:
- involuntary flash;
- deliberate recall;
- avoided memory;
- false recall;
- reinterpretation.

Do not dump the complete biography because a character entered a room.

## After drafting

Check:
- viewpoint leakage;
- redundant interior explanation;
- repeated sensory motifs;
- scene delta;
- causal handoff to next scene;
- memory continuity;
- voice drift.
