# Plot Simulation Engine

## Objective

Generate plausible future story paths from current character/world state without letting a single narrator decide everything at once.

## Simulation stages

1. State freeze.
2. Active pressure extraction.
3. Independent actor intentions.
4. Collision resolution.
5. Candidate divergence.
6. Consequence propagation.
7. Continuity and character audit.
8. Human selection or no-commit.

## Pressure extraction

Identify:
- unmet desires;
- active fears;
- secrets at risk;
- deadlines;
- debts/obligations;
- resource scarcity;
- relationship instability;
- institutional pressure;
- unresolved promises;
- environmental changes.

## Independent actor intention packet

For each major actor:
- desired outcome;
- legal knowledge;
- relevant memory;
- current belief;
- preferred tactic;
- fallback tactic;
- threshold for escalation;
- red line;
- likely error.

## Collision resolution

Resolve conflicts using facts, not author convenience:
- who arrives first;
- who has access;
- who has leverage;
- who has resources;
- who can communicate;
- what physical/institutional rules apply;
- what each person is willing to risk.

## Branch diversity

Branches should differ in causal mechanism, not decorative outcome.

Bad:
- A argues angrily;
- A argues sadly;
- A argues sarcastically.

Good:
- A confesses before B discovers evidence;
- B discovers evidence first and misreads it;
- C intervenes and changes who knows what;
- A repeats an old avoidance pattern;
- A breaks the pattern at a meaningful cost.

## Multi-horizon propagation

For each branch:
- scene horizon: what changes before the scene ends;
- short horizon: 1–3 scenes;
- arc horizon: next sequence/episode/chapter cluster;
- long horizon: future constraint/debt/promise.

## Counterfactual pass

For major turns, simulate “what if the decisive choice did not happen?” This reveals whether the choice truly drives the story or whether the plot would happen anyway.
