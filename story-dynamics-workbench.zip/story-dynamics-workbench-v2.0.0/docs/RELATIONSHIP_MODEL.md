# Relationship Model

Relationships are multi-dimensional and time-varying.

Suggested dimensions:
- trust;
- affection;
- fear;
- resentment;
- dependence;
- obligation;
- leverage;
- intimacy;
- admiration;
- rivalry;
- knowledge asymmetry.

Each update must reference an event.

A relationship has two directional views: A's state toward B can differ from B's state toward A.

Track public relationship and private relationship separately when the story requires it.
