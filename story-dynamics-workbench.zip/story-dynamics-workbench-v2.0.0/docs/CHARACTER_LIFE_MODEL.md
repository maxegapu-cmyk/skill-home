# Character Life Model

## Purpose

Replace flat personality adjectives with a causal model that can explain present choices and generate plausible future behavior.

## 1. Life chronology

Use broad periods unless the source requires exact ages:
- family origin / early environment;
- early childhood;
- later childhood;
- adolescence;
- early adulthood;
- pre-story period;
- current story period.

For each period, record stable environment + important changes.

## 2. Formative event record

Each formative event separates:
- objective event;
- what the character actually perceived;
- perceived agency/control;
- social meaning (“what this says about me/us/the world”);
- immediate emotion;
- action taken;
- reward/punishment;
- memory strength;
- later reinterpretations;
- belief created/reinforced;
- strategy learned;
- relationship residue.

## 3. Self-model

Track statements such as:
- “I am the kind of person who…”
- “People like me are…”
- “If others really knew me…”
- “I deserve / do not deserve…”

Separate public self-image, private self-image, and feared self-image.

## 4. World-model

What does the character expect from:
- authority;
- intimacy;
- strangers;
- institutions;
- success;
- failure;
- conflict;
- dependence;
- vulnerability?

## 5. Strategy library

A character should have recurring strategies such as:
- charm;
- avoidance;
- bargaining;
- intimidation;
- humor;
- over-preparation;
- appeasement;
- secrecy;
- confrontation;
- caretaking;
- competence display.

For each strategy store:
- trigger;
- goal;
- expected payoff;
- failure condition;
- fallback strategy.

## 6. Change threshold

Character change requires pressure. Record:
- what evidence would challenge a belief;
- how much loss/cost is required;
- who is credible enough to influence the character;
- whether change is conscious or behavioral first;
- likely relapse pattern.

## 7. Arc types

Do not force every character into positive growth. Supported arc shapes include:
- positive change;
- negative change;
- steadfast/flat arc that changes others;
- tragic recognition too late to act;
- cyclical relapse;
- false growth;
- partial growth;
- role/identity shift without moral improvement;
- ensemble relay arc.

## 8. Evidence discipline

Every psychological claim is labeled:
- source fact;
- strong inference;
- hypothesis;
- deliberate invention for an original character.

Do not convert a single event into a permanent trait without repeated evidence or explicit design intent.
