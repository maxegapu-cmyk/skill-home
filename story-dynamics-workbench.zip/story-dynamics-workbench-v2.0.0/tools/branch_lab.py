#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))

def validate_branch(b):
    errs=[]
    for key in ('id','status','divergence','steps'):
        if key not in b: errs.append(f'missing {key}')
    if b.get('status') not in ('PROPOSED','ACCEPTED','REJECTED'): errs.append('bad status')
    if not b.get('steps'): errs.append('branch has no causal steps')
    for i,s in enumerate(b.get('steps',[]),1):
        if not any(k in s for k in ('choice','event','result')): errs.append(f'step {i} lacks choice/event/result')
    return errs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('branch'); a=ap.parse_args(); b=load(a.branch)
    e=validate_branch(b); print(json.dumps({'ok':not e,'errors':e},indent=2)); raise SystemExit(1 if e else 0)
if __name__=='__main__': main()
