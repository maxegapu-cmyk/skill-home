#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def load_json(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def jsonl(p):
    p=Path(p)
    if not p.exists(): return []
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def audit(project):
    root=Path(project); findings=[]
    events=jsonl(root/'state'/'canon_events.jsonl'); event_ids={e.get('id') for e in events}
    # dangling causes
    for e in events:
        for c in e.get('causes',[]):
            if c.startswith('ev_') and c not in event_ids:
                findings.append({'severity':'warning','kind':'dangling_cause','event':e.get('id'),'detail':c})
    # memory event refs
    for mfile in (root/'memories').glob('*.json') if (root/'memories').exists() else []:
        m=load_json(mfile); eid=m.get('event_id')
        if eid and eid.startswith('ev_') and eid not in event_ids:
            findings.append({'severity':'warning','kind':'memory_missing_event','memory':m.get('id'),'detail':eid})
    # character memory refs
    for cfile in (root/'characters').glob('*.json') if (root/'characters').exists() else []:
        c=load_json(cfile)
        for mid in c.get('memory_ids',[]):
            if not (root/'memories'/f'{mid}.json').exists():
                findings.append({'severity':'error','kind':'missing_memory','character':c.get('id'),'detail':mid})
    return findings

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); a=ap.parse_args(); f=audit(a.project)
    print(json.dumps({'ok':not any(x['severity']=='error' for x in f),'findings':f},ensure_ascii=False,indent=2))
    raise SystemExit(1 if any(x['severity']=='error' for x in f) else 0)
if __name__=='__main__': main()
