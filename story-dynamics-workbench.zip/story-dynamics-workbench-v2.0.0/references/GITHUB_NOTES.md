# Public GitHub design notes

This file records public architectural inspirations. The implementation in this package is independent and newly written.

## N0819/Sonder_Engine
Public idea used: keep objective truth, perception, memory, belief, and narration as separate layers; use a narrow persistence boundary.

Repository: https://github.com/N0819/Sonder_Engine

## YfengJ/novel-studio-ai
Public idea used: drafts do not automatically update canon; accepted chapters update persistent story memory/state; combine story bible, character state, timeline, graph facts, and retrieval.

Repository: https://github.com/YfengJ/novel-studio-ai

## lishiyo/ficworld
Public idea used: characters can be independent agents with backstory, memory, emotion, private reasoning, and goals; narrative can emerge from interaction between characters and world state.

Repository: https://github.com/lishiyo/ficworld

## pauljCherian/generative-agents
Public idea used: long-term memory stream, retrieval by importance/recency/relevance, reflection, planning, perceive-retrieve-react loop.

Repository: https://github.com/pauljCherian/generative-agents

## getzep/graphiti
Public idea used: temporal context graphs, time-varying relationships, provenance, historical queries, and incremental updates.

Repository: https://github.com/getzep/graphiti

## google-deepmind/dramatron
Public idea used: hierarchical script co-writing from logline through characters, plot, locations, and dialogue; human writer remains in control.

Repository: https://github.com/google-deepmind/dramatron

## vincentgiraud/interactive-fiction
Public idea used: structured world state plus model-generated narrative proposals; state validation belongs to the engine rather than free-form text.

Repository: https://github.com/vincentgiraud/interactive-fiction

## Feed-Scription/openovel
Public idea used: separate fast foreground narration from background state/memory maintenance.

Repository: https://github.com/Feed-Scription/openovel

## giapnguyen74/xnovelist
Public idea used: a human-readable story bible as the durable reference for characters, locations, style, and continuity.

Repository: https://github.com/giapnguyen74/xnovelist

## DuckTraDo/Novel
Public idea used: story bible + character knowledge/secrets/relationships + events/timeline + foreshadowing ledger for long-form writing.

Repository: https://github.com/DuckTraDo/Novel

## septiannugraha/narrative-engine
Public idea used: checkpointing/rollback and persistent multi-character world state.

Repository: https://github.com/septiannugraha/narrative-engine

## nyousefi/Fountain
Public idea used: Fountain-compatible screenplay text as a simple, readable interchange format.

Repository: https://github.com/nyousefi/Fountain
