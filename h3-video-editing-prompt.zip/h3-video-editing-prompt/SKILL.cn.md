---
name: h3-video-editing-prompt
description: 编写或修改 MiniMax H3 的视频编辑类提示词（全参考 Ref2VA 六段格式）。通用于把视频中的任意对象替换／修改成参考图中的对象：换脸与人物身份、服装配饰、手持或场景物体（苹果换西瓜）、场景背景、画内文字与标识、材质表面、光照风格，以及物体移除与新增、源视频续写。当用户说「视频编辑 / 编辑这个视频 / 把视频里的 X 换成 Y / 替换 / 换掉 / 换成参考图里那个 / 换脸 / 把这张脸换到视频里 / 脸上有绿幕 / 绿色遮罩 / 遮罩区域重建 / 换衣服 / 改颜色 / 换材质 / 重新打光 / 续写」或同时提供源视频 + 参考素材时使用。MiniMax H3 video editing prompt, masked region replacement, any-object replacement, face swap, Ref2VA.
compatibility: Portable to any agent that can read local files. 仅依赖本地文件读取；不调用外部 API，不依赖 MiniMax Hub 运行时。
agent_created: true
---

# MiniMax H3 视频编辑提示词

**核心区分：编辑类任务描述的是「目标视频里最终看到什么」，不是「要做哪一步」。** 全篇不允许出现 `swap` / `remove` / `replace` / `chroma key` 这类指令式或后期术语——它们会被模型当作画面内容。

配套官方源：`h3-prompt-writing/references/ref-en.txt`（全参考格式）。本技能只补充编辑类任务的专属规则。

## 交付契约（默认，除非用户本轮明确推翻）

1. **只输出英文版提示词主体**，放在**单个 ```text 代码块**里。字段名、H3 标签、`(S1)`、任务类型、`[Shot N]`、画面与声音描述全部英文。
2. 代码块前后**不写导语、使用说明、字段解读、确认语**。
3. 对白、歌词、画内文字保留原文。
4. 全文（含所有字段）**≤ 7000 字符**。编辑类 `detailed_description` 随源视频复杂度伸缩，不受 350–500 词区间限制，单镜头也不因此自动缩短。
5. 写盘存档到工作区 `outputs/`，命名 `主题-英文投喂版.txt`。
6. 只有用户明确要分析、要中文版时才输出代码块之外的内容。

## 标准入口：一句话需求 → 模板

用户最常用的输入形态是一句话：「**将视频中的 XX 替换／修改成参考图中的 XX，保持视频中的其它元素不变。如果有对话或者唱歌等口型要匹配。**」

### 触发判定（先于一切写作动作）

用户一句话里出现「**将视频中的绿色的部分／绿色区域／遮罩区域替换为参考图中的 XXX**」时，**这就是视频编辑任务（`video editing`），且被替换对象是 XXX 本身**，不是只给脸部换身份。按此强制解读：

1. **替换范围 = 遮罩覆盖的全部可见内容**。遮罩盖到腰、盖到全身，就重建到腰、重建到全身——发型、脸、上衣、外套、裤子、鞋、配饰，凡在遮罩内的一律按参考图重建。**不得只写「换脸」而保留遮罩内其余的源服装与源发型**。
2. **源视频自己的服装／帽子／发型只要落在遮罩内，就全部「不被迁移」**，逐项否定（`the flat cap, the emblem on the cap, the pale crop top and the blue jeans in <Video 1> are not carried over`）。把它们写进 `<Subject 1>` 定义和保留项的「保留清单」是**错误写法**——保留项里只能保留「源人物的动作、姿势、体位、时序」，不能保留「遮罩内的外观」。
3. **典型翻车样本**（用户提供的失败成稿）：遮罩盖全身，成稿却写 `<Subject 1>` 保留「白色短款T恤、深绿色棒球帽、浅色牛仔裤」、`summary` 写「她的白色短款T恤、带标志的棒球帽、牛仔裤……保持不变」——这是把「被替换物」当成「保留物」写了，结果成片人物没换、只动了脸。**自检方法：逐项问「这个元素在遮罩内吗？」在遮罩内 → 归 `<Subject 2>` 重建并否定源版本；在遮罩外 → 才能进保留清单。**
4. 任务类型固定为 `[video editing + reference generation]`（有音轨再 `+ audio reuse`），`summary` 开头固定 `The target video is an edited version of <Video 1>.`

**这句话通用于任何对象**——人物身份、服装配饰、手持或场景物体、场景背景、画内文字与标识、材质表面、光照风格，以及移除与新增。它只提供两个真实变量（目标、参考），其余槽位由素材检测与读图决定。此时直接套 `references/universal-replacement-template.md`，不要每次从零重写结构：

1. 先确定**三归属**：外观 ← 参考素材；运动与几何 ← 源视频；光学 ← 源视频环境。漏运动几何 → 目标乱动／脱手／穿模／衣服变硬壳；漏光学 → 参考图影棚光被搬进场景，目标像贴纸浮在画面上。
2. 跑四项检测（音轨、遮罩形态、遮罩边界与遮挡、构图与镜头）。
3. 用「目标类型 → 槽位速查」抄出该类型的外观清单、几何锚点、不迁移项。
4. 用七模块拼正文：`REBUILD` / `LIGHT` / `SYNC` / `PERFORMANCE`（人物类必填，四组可见行为）/ `OCCLUSION` / `FIT` / `SEAM_AND_EXCLUDE`，末尾补收口句 `NO_ADDED_EVENT`。

**类型专属的时间敏感点**：物体写尺寸规则（默认 R1 保持占位，抓握与遮挡全自洽）；服装**必须是身体驱动衣服**，不能让衣服保持参考图的平铺／模特姿态；背景要按源视频透视与视差重算，不能沿用参考图自己的透视与镜头；画内文字逐字给原文、不翻译。
成稿示例与校验清单见工作区 `outputs/H3替换编辑-通用模板.md`。

## 六段固定结构

`subject_definitions` → `summary` → `retention_analysis` → `detailed_description` → `overall_soundscape` → `non_diegetic_music`

六个字段名一个不能省、不能改名、不能换顺序。

## 标签分配（编辑类任务的核心判断）

| 标签 | 指向 |
|---|---|
| `<Video N>` | 被编辑的源视频，或提供整段运镜／剪辑／节奏结构的视频。**不替代视频里的人** |
| `<Subject N>` | 可复用的可见内容：人、场景、服装、道具、动作、风格 |
| `<Picture N>` | **仅当图片充当精确首帧／关键帧／尾帧／编辑关键帧／构图锚点／分镜锚点**才单列 |
| `<Audio N>` | 独立音频或启用的同步音轨 |

**最易错的一条**：只用来定义人物外貌、服装、场景、风格的参考图，**不单列 `<Picture N>` 行**，而是在对应的 `<Subject N>` 定义里内联引用：

```text
<Subject 2> is the facial identity in <Picture 1>, with an oval face, soft arched eyebrows, almond eyes, a straight nose bridge, and full lips.
```

标 `keyframe completion` 的前提是图真的充当了某个具体帧；只提供生成指导时用 `reference generation`。

## 任务类型

`keyframe completion` · `reference generation` · `video editing` · `video continuation` · `audio reuse` · `audio reference`，用 ` + ` 组合、不重复。

- 直接修改已有源视频 → `video editing`；编辑源视频且**原声仍可闻** → 追加 `audio reuse`。
- 只参考源视频的运镜／剪辑／节奏 → 属于 `reference generation`，不是 `video editing`。
- 编辑类 `summary` **必须**以固定句开头：`The target video is an edited version of <Video 1>.`

## 保留关系

视觉：`fully_preserved` · `partially_preserved` · `attribute_transfer` · `weak_reference`
音频：`fully_copy` · `partially_copy` · `reference` · `weak_reference`

- 换脸／遮罩重建时，参考脸用 `attribute_transfer`（**不是** `fully_preserved`），承载它的人用 `partially_preserved`。
- `retention_analysis` 里**不写** `(Sx)`。
- 新加的动作、背景、情节不算参考保真度损失。

## 正文五条硬要点（通用）

1. **写结果，不写操作。** `Her face carries the identity of <Subject 2> throughout`，而不是 `swap the face`。
2. **给可核对的几何特征清单**（脸型、眉形、眼型、鼻梁、唇形），而不是「长得像参考图」。
3. **声明光照与皮肤色温的来源与适配**，避免把参考图自己的打光、背景、色调搬进成片。
4. **划分表演归属，并把可见行为逐项钉死**：身份／外观来自 `<Subject N>`，但表情、神态、眼神、眨眼节奏、头颈与躯干动作、口型全部由源视频的表演驱动，必须**逐项写出**（清单见下节）。不写这句极易出现表情漂移、眼神乱飘、口型错位。
5. **处理边界与遮挡**：与发际线、轮廓的衔接连续无接缝；手、发丝、眼镜、麦克风遮挡处逐处说明遮挡关系不变。

多镜头时标签编号不变、每镜延用；换角度（正脸／侧脸／低头）须点明身份仍需一致。

## 只写可见事实 + 可见行为复刻（人物替换的两条硬规则）

### 一、不猜目的：只描述看得见的东西

- **禁止**推断人物在干什么、为什么这么做、处于什么情境：不写 `she is singing along to a song` / `she is recording a vlog` / `she is greeting a friend` / `she is thinking about her answer`——意图、身份、剧情、画外因果都属于猜测。
- **改写为可见事实**：写她脸上与身上实际发生了什么——`her brows lift, her mouth corners pull up into a closed-mouth smile, her gaze drifts down-left and returns`。
- 音轨同理：只听得出有声音时写 `her lips move and keep their exact shapes and timing from <Video 1>`，不写「她在唱歌／她在说话」；歌词与台词一律不臆造。
- 场景同理：只写看得见的陈设与光线（`a panelled wooden door and white moulding behind her`），不推断地点用途（不写「她在直播间／她在排练」）。

### 二、可见行为复刻清单（人物替换时逐项写，缺项就漂移）

分四组，**每组都要同节奏约束**（`on the same beats` / `at the same moments`）：

| 组 | 逐项内容 | 英文写法 |
|---|---|---|
| **表情** | 眉高与眉形、眼睑开合度、眼眶与嘴角的松紧、唇形开合 | `the same facial expression, with the same brow height and angle, the same eyelid height and the same softness or tension around her eyes and the corners of her mouth` |
| **神态** | 面部整体状态随时间的读感（舒展／戒备／被逗到／平静），逐拍变化 | `the same demeanour as it reads on her face from moment to moment — how open, how guarded, how amused, how composed — shifting on exactly the same beats` |
| **眼神** | 视线落点与距离、漂移与回位、眨眼节奏与幅度、眼睑高度 | `the same gaze, her eyes resting on the same point at the same distance with the same drift and return; the same blink rhythm` |
| **举止** | 头转／偏／点、肩与躯干摆动、手部动作、口型形状与时序 | `the same visible behaviour, with the same head turns, tilts and nods, the same shoulder and torso sway, and the same lip shapes and mouth movement at the same moments` |

**配套收口句**（防止模型自行加戏）：
`Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.`

**遮罩已盖住面部时**：可见的表演信息被抹掉，不能靠猜补——只保留可取证的部分（头姿、肩线、来自音轨的口型时序），其余交回参考素材，**不写情绪形容词**。

**姿态类目标（无人脸可复刻时）**：四组降级为「举止」一组——头／肩／躯干／手的动作轨迹与时序，仍要同节奏。

### 三、动作迁移（替换后的人物必须与源人物动作一致）

用户说「**动作要跟视频中人物的动作一致／保持动作**」时，写法与可见行为四组同源，但重点从**脸**移到**全身骨架**。人物替换本来就隐含动作迁移，此节把「动作」单独立项、逐关节钉死，防止模型只保住脸而让身体重新编排。

**动作五组逐项复刻**（在四组之外追加，全部带同节奏约束）：

| 组 | 逐项内容 | 英文写法 |
|---|---|---|
| **躯干与重心** | 站姿或坐姿、重心左右前后移动的时序、躯干扭转与倾角 | `the same posture, with her weight shifting between her feet at the same moments, the same torso rotation and lean at the same beats` |
| **四肢轨迹** | 手臂抬起／交叉／挥动的路径与幅度、腿部迈步与膝踝屈伸 | `the same arm and hand movements, following the same paths through the air with the same amplitude and the same timing; the same steps, knee bends and ankle flexes` |
| **节奏与速度** | 动作的启动／加速／减速／停顿拍点，整体运动速率 | `at the same speed and on the same rhythm, starting, accelerating, slowing and pausing at exactly the same moments` |
| **头部联动** | 头部动作与躯干／手臂动作的配合关系（转头带动视线、抬头跟随躯干后仰） | `her head moves in the same relation to her torso and arms as in <Video 1>` |
| **次级运动** | 头发、服装、配饰随动作的摆动延迟与沉降 | `her hair, clothing and accessories swing, settle and lag behind her movement exactly as they do in <Video 1>` |

**标准动作归属句**（放在 `detailed_description`，紧跟重建句之后）：

```text
Her entire movement is reproduced exactly as it is in <Video 1>: the same posture, with her weight shifting between her feet at the same moments, the same torso rotation and lean at the same beats; the same arm and hand movements, following the same paths through the air with the same amplitude and the same timing; the same steps, knee bends and ankle flexes; at the same speed and on the same rhythm, starting, accelerating, slowing and pausing at exactly the same moments; her head moves in the same relation to her torso and arms as in <Video 1>; and her hair, clothing and accessories swing, settle and lag behind her movement exactly as they do in <Video 1>.
```

**三条配套规则**：

1. **遮罩只盖住部分身体时，动作归属只对遮罩内部位声明**，遮罩外的身体已经可见、模型本来就会保留——把两者都写全反而浪费字符。遮罩只盖头：只写头部联动 + 面部四组；遮罩盖全身：五组全写。
2. **遮罩是不透明（结构被抹掉）时**，动作信息只剩「遮罩外露出的关节」可取证（肩线、脖颈、髋位），降级为从这些锚点外推：`her shoulders and neck keep their exact motion from <Video 1>, and the rebuilt head follows that motion exactly, turning, tilting and nodding on the same beats`——**不写**无法取证的细节（手部轨迹等），否则等于凭空编动作。
3. **多人物时逐人归属**：`<Subject 1>` 写一组，其他未遮罩人物各写一句 `keeps their exact position, motion and timing from <Video 1>`（可并入保留项）。漏写第二个人，模型常顺手让他跟着动或反过来僵住。

**保留标记**：承载者仍标 `partially_preserved`（外观被替换），动作逐项列进保留清单（`head turns, arm and hand movement, weight shifts and timing are retained unchanged`）。完整规则与英文模板见 `references/editing-recipes.md`「动作迁移」一节。

## 绿色区域的重建内容必须逐项对得上

被重建的内容（来自参考图或用户文字描述）**要么不漏、要么不多**，按下列顺序抄成清单，逐项落到 `{{REBUILD_SENTENCE}}`：

1. **形状与比例**：轮廓、长宽比、端点形态（帽檐弧度／茄帽锥度／袖型）。
2. **颜色与图样**：主色（必须绑定名词，如 `a black wool-felt fedora`）、次色、纹样与位置、无图样就明说不带纹样。
3. **材质与光学**：面料（羊毛毡／陶瓷釉／皮革）、粗糙度、高光性质（`matte with a soft sheen`）。
4. **附属细节**：绶带／蝴蝶结／纽扣／Logo／缝线——**用户文字没提到的细节按参考图写；参考图也没有的，不自行添加**。
5. **反向排除**：参考图的背景、棚拍光、产品投影、孤立机位逐项否掉（`the reference image's white studio background and soft floor shadow do not appear in the target video`）。
6. **源物件的旧特征**：源视频里旧物体的形制与附着标志也要否掉（`no lettering or logo appears on the hat`）。

**判据**：把清单与用户原话／参考图逐条对照，出现「用户没要但写了」的细节＝加戏，出现「用户要了但没写」＝漏项，两者都要改。


## 跨语境换脸的默认取舍

参考脸来自与源视频不同的时代／场景（古装妆造 → 现代都市、影棚精修 → 手持夜景）时，**默认只迁移五官骨相与皮肤质感，不迁移参考图的头饰、发冠、仪式妆容、面部彩绘**。把这些不迁移项在 `<Subject 2>` 的 `retention_analysis` 行里显式点名一次（`the reference's headdress, forehead mark, eye makeup, and facial markings are not carried over`），否则古装元素会残留到现代场景。

## 把提示词写短的手法

用户说「简单一点」时按此顺序压缩，四要素不得丢：

1. `subject_definitions` 每项压到一行，只留可作锚点的特征。
2. `retention_analysis` 只写保留项，不写理由：`partially_preserved - hair, dress, posture, and framing are retained; only the face is replaced.`
3. `detailed_description` 压到 150–180 词，删掉重复的特征清单与冗余方位词，保留四要素（特征清单 / 光照色温 / 表演归属 / 边界接缝）。
4. 六个字段名与 `summary` 的 `The target video is an edited version of <Video 1>.` 固定开头句一律不省。

## 场景配方

各场景的完整可投喂示例与专属规则见 `references/editing-recipes.md`：

- **替换／编辑通用模板**（一句话需求 → 三归属 → 四项检测 → 类型速查 → 六模块骨架，见 `references/universal-replacement-template.md`）——**任何被替换对象都走这一份**
- 参考图换脸
- 绿幕／纯色遮罩脸的重建（含残留绿色的两条兜底路径）
- 遮罩盖住嘴部 + 源视频自带音轨 → 口型同步（含无音轨／有音轨／要重配台词三路分支表）
- 物体替换／移除
- **无参考图的小物体替换**（用户只说「把绿色区域换成 X」且无参考素材：不建 `<Subject 2>`、任务类型只剩 `[video editing]`、否定旧道具、处理矩形遮罩的直边）
- 风格重打光与调色迁移
- 源视频续写（`video continuation`）

## 前置检查（动手写之前必做）

拿到源视频先跑这四项，任何一项不确认都可能写出错误的提示词：

1. **音轨**：`ffprobe -v error -select_streams a -show_entries stream=index,codec_name -of csv=p=0 <file>`。**空输出 = 没有音轨**，此时 `audio reuse` / `audio reference` 都无从谈起，"口型同步音频"没有可对齐的源。ComfyUI 导出常丢音频，务必先查再问。
2. **分辨率是否为 32 的整数倍**（544=17×32、704=22×32、576=18×32、736=23×32 之类）。若是，源视频很可能已经是 `CS Spatial Stabilize` 的裁切输出，此时不得沿用原运镜词（见 `references/editing-recipes.md` 第六节）。同时留意上下是否有纯黑填充带。
   **确认手段**：抽 8–10 帧算绿区（或主体）质心的归一化坐标。质心漂移 ≤1.5% 而顶部黑带持续增厚（例如 0 → 36 行，峰值占画面高度约 20%）＝主体被锁死、边缘露出填充，是稳定节点的典型指纹；质心与黑带同步位移则不是。
3. **镜头数**：抽 6–12 帧做 `tile` 拼贴目视检查。单镜头时 `detailed_description` 只有 `[Shot 1]`，不写时间戳。
4. **遮罩形态**：放大截取目标区（脸／物体／衣物／背景）目视 + 算遮罩内均值 RGB。**不透明遮罩 vs 半透明叠加，写法几乎相反**（判据与骨架见 `references/editing-recipes.md` 第二节）。**本项目素材里被替换对象的遮罩均为半透明叠加，这是默认路径。**
   - **不透明遮罩**（平坦纯色、内部无结构、均值 R < 40）：目标的结构与运动信息已被抹除，H3 无从"保持"。
     - 目标含嘴部且源视频**无音轨**、只要求换脸 → 嘴部写中性静止（`lips stay softly closed and relaxed`），给下游 lip-sync 留干净驱动基底。
     - 目标含嘴部且源视频**有音轨**、要求口型同步 → 走 `references/editing-recipes.md` 第七节：`<Audio 1>` 标 `fully_copy`，正文用 `<Subject 1> (S1)` 显式描述 articulation，**不臆造 `<d>` 台词**。
     - 用户要 H3 自己说话 → 必须向用户索取台词原文，补 `<d>[Language] ...</d>`。
     - 目标为物体／衣物时几何约束改从周边取证（抓握它的手指、接触阴影、相邻物体、环境光方向）。
   - **半透明叠加**（绿层下结构仍可读、均值 R ≈ 80）：**运动与几何信息完整保留**，此时唯一真正重要的约束是显式声明归属——换脸写 `Her expression, gaze, blink rhythm, and the exact shapes and timing of her mouth movements continue from her performance in <Video 1>`，换物体写 `Its position, orientation, silhouette, velocity, and motion path continue unchanged from <Video 1>`，换服装写 `Its fit, folds, sway, and hem movement follow her body motion exactly as the garment in <Video 1> does`，并统一要求 `natural, untinted colour`。漏写这句，模型会把目标连同运动一起重生成：口型脱轨、物体脱手、衣服变成贴上去的硬壳。
   - **第三类：小面积硬边矩形遮罩**（手绘框／自动遮罩，面积可低至画面的 1‰，如 24×41 px 的方框压住嘴上香烟）。判定看两点：**直边**（边界是矩形而非轮廓贴合）+ **面积远大于目标物体**（同时压住周边皮肤／桌面）。此时重建是两件事——目标就位 **+ 被遮周边表面复原**，必须写 `The patch's straight edges do not survive anywhere in the target video; the rebuilt area blends into her face with no seam and no colour break.`；不漏这句会在成片里保留一个矩形色块边界。另须否定源视频的旧道具（`no cigarette appears in the target video`）。
   - **第四类：块状阶梯边界**（自动遮罩的粗糙边缘，面积可达画面 40%，如整人半身）。判定看**边界是否呈台阶／方块状**而非贴合轮廓——沿左缘逐行取遮罩最左列，位置出现十几级跳变即属此类。此类遮罩常**一直延伸到画面边缘被裁断**（人物下半身出画）。两个必写句：`The rebuilt figure fills the overlay's stepped, blocky outline exactly, so no step, no block edge and no colour break survives along the join between it and the background`，以及画外裁断 `it is cropped at the bottom edge at the same point as the source figure`。**参考图主体比源主体更长时**（源只到大腿、参考图是全身），必须接着否掉画外部分：`so the lower part of her legs and the red heels in <Picture 1> stay below the frame and out of view`——不写会被拉长画幅或把鞋硬塞进来。
   - **遮罩内是否有成团高亮像素（残留 logo／徽标／绣字）**：放大遮罩区目视 + 统计内部非绿像素。keying 工具常保留品牌标志，模型会把它照抄到新物体上，必须否定（`no lettering or logo appears on the hat`）。**佩戴物（帽子／眼镜／头饰／首饰）**另有专属规则——几何锚点只能从头发／眉骨接触阴影／头部姿态取证，且必须写"跟着头走"的运动归属句，见 `references/editing-recipes.md` 第三节「佩戴物替换」。

## 质量门

输出前逐条自检：

- [ ] 六个字段名齐全、顺序正确、无改名
- [ ] `summary` 以 `The target video is an edited version of <Video 1>.` 开头
- [ ] 仅定义外貌的参考图没有单列 `<Picture N>`
- [ ] **无参考素材时不建 `<Subject 2>`**，特征清单直接进 `detailed_description`，任务类型只留 `[video editing]`（不加 `reference generation`）
- [ ] **小面积矩形遮罩**：写了"直边不保留、重建区与周边无缝无色彩断层"，并否定了源视频的旧道具
- [ ] **块状阶梯遮罩**：写了"阶梯与方块边界不保留、衔接连续无色彩断层"，且遮罩触到画面边缘时写明了"与源主体在同一点被裁断"
- [ ] **参考图主体比源主体长**时（源到腰／腿、参考是全身），画外部分已逐项否掉（`stay below the bottom edge of the frame and out of view`）
- [ ] 参考脸标 `attribute_transfer`，承载者标 `partially_preserved`
- [ ] `retention_analysis` 无 `(Sx)`
- [ ] 正文无 `swap` / `remove` / `replace` / `chroma` / `green screen` 等指令式或后期术语
- [ ] **无目的／身份／剧情推断**：不出现「在唱歌／在直播／在排练／在想事情／在跟谁说话」这类猜测；场景只写看得见的陈设与光线
- [ ] **人物替换写全可见行为四组**：表情 · 神态 · 眼神 · 举止，每组都带同节奏约束（`on the same beats` / `at the same moments`），且都有收口句 `Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.`
- [ ] **换人归属判定（唯一判据：在不在遮罩内）**：遮罩内的全部外观（帽、上衣、裤子、发型……）归 `<Subject 2>` 重建并逐项 `are not carried over`；**绝不出现在 `<Subject 1>` 的保留清单里，也绝不在 `summary` 里写「保持不变」**；`<Subject 1>` 的保留清单只含动作、姿势、体位、时序与遮罩外的身体部位。自检：逐元素问「在遮罩内吗？」在 → 重建；不在 → 保留
- [ ] **动作迁移（用户要求动作与源人物一致）**：遮罩内部位写了动作五组（躯干与重心 · 四肢轨迹 · 节奏与速度 · 头部联动 · 次级运动）；不透明遮罩降级为从露出关节外推；多人物逐人归属；动作项已列入 `retention_analysis` 保留清单
- [ ] **重建内容与参考图／用户文字逐项对得上**：形状比例 · 颜色图样 · 材质光学 · 附属细节。没有漏项、没有加戏；参考图的背景／棚光／产品投影／旧机位已逐项否掉
- [ ] 正文含六个模块：重建句 + 光学取自源场景 + **运动归属** + 遮挡与深度顺序 + 适配句 + 接缝句
- [ ] **适配句按类型写对**：物体 = 尺寸规则（默认 R1 保持占位）／服装 = 身体驱动衣服／背景 = 透视与视差对齐／材质 = 形状体积不变
- [ ] **运动归属句按类型写对**：脸 = 表演（表情／眨眼／口型）／物 = 位移与速度（且不按新物体物理重算）／衣 = 随体摆动／背景 = 视差
- [ ] 该类型的不迁移项逐项列出（参考图的打光、背景、姿势或平铺形态、自身透视、相机镜头）
- [ ] 移除类不建 `<Subject 2>`、任务类型去掉 `reference generation`，并写明空缺回填
- [ ] 多目标时编号按首次出现递增，各自独立遮罩与几何锚点
- [ ] 服装、背景、机位在保留项里逐项列出（漏写会让模型顺手替换掉）
- [ ] **遮挡项单列**：压在重建区上的元素（发丝／手指／饰品／前景物／他人伸入的肢体）写明"保持原位并仍覆盖在新目标上"（漏写会被抹平进新目标）
- [ ] **主体自己持有的道具单列**（烟／杯／手机等夹在嘴或手里、落在遮罩内的东西）：写明保持同角度、同长度、同位置，且新嘴唇／新手指仍包住它
- [ ] **画外部位声明**：源视频里脚／腿在画外的，写 `stay below the bottom edge of the frame and out of view throughout`，否则模型会改画幅去补
- [ ] **轮廓变化**：参考服装比源服装暴露（长袖→吊带、长裤→短裙）时，写裸肤部位并在不迁移项里否定源服装形态
- [ ] **运镜判定二选一**：内容整体缩放（背景同步变大）= 真实推镜，写运镜词；主体近静止 + 背景不缩放 + 边缘露填充 = 稳定节点指纹，正文零运镜词。**黑带出现本身不是判据**
- [ ] **画布边缘**：有填充带时写成 `padding bands along the frame edges` 并保留，不逐边列像素数、不指示改写画幅
- [ ] 全文字符数 ≤ 7000
