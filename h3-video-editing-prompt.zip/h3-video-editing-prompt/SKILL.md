---
name: h3-video-editing-prompt
description: Write or revise MiniMax H3 video-editing prompts in the full-reference Ref2VA six-field format. Use when replacing or modifying anything inside a source video from reference material — face and identity replacement, costumes and accessories, held or scene objects (apple to watermelon), background and setting, on-screen text and signage, material and surface, lighting and grade, object removal and addition, and source-video continuation. Triggered by requests such as video editing, edit this video, replace X in the video with Y, swap, face swap, put this face into the video, green screen on the face, green mask, rebuild the masked area, change the clothes, change the colour, change the material, relight, continue the video, or any request that supplies a source video together with reference material. MiniMax H3 video editing prompt, masked region replacement, any-object replacement, face swap, Ref2VA.
compatibility: Portable to any agent that can read local files. No external API calls and no MiniMax Hub runtime required.
metadata:
  trigger-words: [video editing prompt, masked region replacement, replace object in video, face swap, 视频编辑提示词, 绿幕替换, 绿色遮罩重建, 换脸, 换衣服, 换成参考图里的, 任意对象替换, Ref2VA editing]
agent_created: true
---

# MiniMax H3 Video-Editing Prompts

**The core distinction: an editing task describes what the target video finally shows, not which operation is performed.** The body text must never contain `swap` / `remove` / `replace` / `chroma key` or similar imperative or post-production terms — the model reads them as visible content.

Companion official source: `h3-prompt-writing/references/ref-en.txt` (full-reference format). This skill only adds the rules that are specific to editing tasks.

## ComfyUI node adaptation

When this skill is loaded by the `ComfyUI_Qwen_H3_Prompt` node, that node's binding local output contract overrides parts of the delivery contract below:

- **No Markdown code fences.** The node rejects fenced output. Return the six fields as plain text. The single fenced block applies to chat delivery only.
- **The node receives no audio.** It is handed video frames without their audio tracks, so `audio reuse` / `audio reference` and `<Audio 1>` cannot be honoured. Leave them out: write `overall_soundscape` as an original design of room tone, ambience and physical action sounds matched to the visible timeline, never claim to copy or preserve a source track, and keep `fully_copy` out of `retention_analysis`.
- **No questions, no option lists, no confirmation gates.** Choose one conservative value for any missing creative detail and do not expose the assumption.
- **`non_diegetic_music` must be filled** with a concise instrumental score (mood, instruments, pacing, sync with the major visual beats, ending) unless the request is explicitly silent, in which case set both audio fields to exactly `N/A`.
- **Duration is authoritative.** The node passes an exact target duration; every `[Shot N]` timestamp must be strictly increasing and smaller than that duration.

## Delivery contract

Unless the current turn explicitly overrides it:

1. Output **only the English prompt body**, in a **single ```text block**. Field names, H3 labels, `(S1)`, task types, `[Shot N]`, and all visual and audio description are English.
2. Write **no preface, no usage notes, no field explanation, no confirmation** before or after the block.
3. Preserve dialogue, lyrics and on-screen text in their original language.
4. The whole text, all fields included, stays **≤ 7000 characters**. For editing work `detailed_description` scales with the complexity of the source video and is not bound to the 350–500 word range; a single-shot source does not make it shorter automatically.
5. Save a copy to the workspace `outputs/` folder as `topic-英文投喂版.txt`.
6. Only when the user explicitly asks for analysis or a Chinese version do you write anything outside the block.

## Standard entry: one-line request to template

The most common input is a single line: "**Replace/modify XX in the video with XX from the reference image, keep everything else unchanged. Match the lip movement if there is dialogue or singing.**"

### Trigger decision (before any writing)

When the user's line contains "**replace the green part / green area / masked area in the video with XXX from the reference image**", this **is a video-editing task (`video editing`) and the replaced object is XXX itself**, not just an identity swap for the face. Interpret it mandatorily as follows:

1. **The replacement scope = everything visible under the mask**. If the mask covers to the waist or the whole body, rebuild to the waist or the whole body — hair, face, top, jacket, trousers, shoes, accessories, whatever falls inside the mask is rebuilt from the reference. **Never write only "swap the face" while keeping the source costume and source hair inside the mask.**
2. **The source video's own clothing / hat / hairstyle, as long as it lies inside the mask, is "not carried over"** — negate it item by item (`the flat cap, the emblem on the cap, the pale crop top and the blue jeans in <Video 1> are not carried over`). Writing those items into the `<Subject 1>` definition and into the retained list of `retention_analysis` is **wrong** — the retained list may keep only the source figure's motion, posture, body position and timing, never the appearance inside the mask.
3. **A real failed sample** (a delivered prompt the user flagged): the mask covered the whole body, yet the prompt kept "white crop top, dark green baseball cap, light jeans" in `<Subject 1>`, and `summary` said "her white crop top, cap and jeans stay unchanged" — the replaced items were written as retained items, so the finished video never swapped the person and only touched the face. **Self-check: ask item by item "is this element inside the mask?" Inside → it belongs to `<Subject 2>` and the source version is negated; outside → only then may it enter the retained list.**
4. The task type is fixed at `[video editing + reference generation]` (add `+ audio reuse` only with a source track), and `summary` opens with the fixed `The target video is an edited version of <Video 1>.`

### Figure-swap ownership test (the only criterion: inside or outside the mask)

Ask per element "is it inside the mask?"; the answer decides where it belongs:

| Element position | Ownership | How to write it |
|---|---|---|
| **Inside the mask** (covered by the green / flat-colour overlay: face, hair, cap, top, trousers, ...) | Rebuilt as `<Subject 2>`, source version negated | The `<Subject 2>` definition carries the full new appearance from the reference; the `<Video 1>` definition declares the source appearance as marking the region to be rebuilt; it **must not appear in `<Subject 1>`'s retained list**; the body negates it item by item with `are not carried over` |
| **Outside the mask** (exposed: hands, shoes, below the neck, unmasked accessories) | Retained in `<Subject 1>` | Enters the `<Subject 1>` definition and retained list, `partially_preserved` |
| **Motion and posture** (inside or outside) | Retained from `<Video 1>` | The five motion groups + the four face groups (for people), each `the same ... as in <Video 1>` |

**Counter-example (a real failed prompt — never replicate)**: mask from head to waist, yet `<Subject 1>` retained "white T-shirt, dark green baseball cap, light jeans" and `summary` wrote "her white crop top, cap and jeans stay unchanged", while `<Subject 2>` defined only "facial features and upper-body appearance" — the finished video never swapped the person. **Root cause: the replaced items were written as retained items.** The correct shape: `<Subject 2>` defines the **complete appearance from the reference** (including the reference's own hairstyle and clothing); the `<Video 1>` definition states "a flat green cap, a pale crop top and blue jeans ... mark the region to be rebuilt and are not part of the target video's visible content"; the body writes `the flat cap, the emblem on the cap, the pale crop top and the blue jeans in <Video 1> are not carried over`.

**Matching retention marking**: `<Subject 1>`'s `partially_preserved` line lists only "motion, posture, body position, timing + body parts outside the mask", **never the appearance inside the mask**, and closes with "the appearance is replaced by `<Subject 2>`".

**That sentence works for every object type** — identity, costume and accessories, held or scene objects, background, on-screen text and signage, material and surface, lighting and grade, removal and addition. It supplies only two real variables (target, reference); every other slot is decided by probing the assets and reading the reference. Use `references/universal-replacement-template.md` directly instead of rebuilding the structure from scratch:

1. Fix the **three attributions**: appearance ← reference material; motion and geometry ← source video; optics ← source environment. Miss motion geometry and the target drifts, slips out of the hand, clips through, or turns into a rigid shell; miss optics and the reference's studio light is transplanted in and the target floats like a sticker.
2. Run the four pre-flight checks (audio, mask form, mask boundary and occlusion, composition and camera).
3. Copy the appearance list, geometry anchors and non-carried-over items for that target type from the type/slot table.
4. Assemble the body from seven modules — `REBUILD` / `LIGHT` / `SYNC` / `PERFORMANCE` (mandatory for people, four groups of visible behaviour) / `OCCLUSION` / `FIT` / `SEAM_AND_EXCLUDE` — and close with `NO_ADDED_EVENT`.

**Type-specific time-sensitive points**: objects get a size rule (default R1, keep the occupied space so grip and occlusion stay self-consistent); costumes **must be body-driven**, never left in the reference's flat-lay or model pose; backgrounds must be recomputed on the source's perspective and parallax, never the reference's own perspective and lens; on-screen text is quoted verbatim and never translated.
Worked examples and the self-check list are in the workspace `outputs/H3替换编辑-通用模板.md`.

## The six fixed fields

`subject_definitions` → `summary` → `retention_analysis` → `detailed_description` → `overall_soundscape` → `non_diegetic_music`

None of the six may be omitted, renamed or reordered.

## Label assignment

| Label | Points at |
|---|---|
| `<Video N>` | The source video being edited, or a video supplying whole-run camera, edit or rhythm structure. **Does not stand in for the people inside it** |
| `<Subject N>` | Reusable visible content: people, settings, costumes, props, actions, style |
| `<Picture N>` | Listed **only when the picture serves as an exact first frame, keyframe, last frame, edit keyframe, composition anchor or shot anchor** |
| `<Audio N>` | Standalone audio, or an enabled synchronized track |

**The most common mistake**: a reference image that only defines appearance, costume, setting or style is **not given its own `<Picture N>` line**. Reference it inline inside the matching `<Subject N>` definition:

```text
<Subject 2> is the facial identity in <Picture 1>, with an oval face, soft arched eyebrows, almond eyes, a straight nose bridge, and full lips.
```

Tag `keyframe completion` only when the picture really is a specific frame; when it merely guides generation, use `reference generation`.

## Task types

`keyframe completion` · `reference generation` · `video editing` · `video continuation` · `audio reuse` · `audio reference`, combined with ` + ` and never repeated.

- Directly modifying an existing source video → `video editing`; editing it while **the original sound remains audible** → add `audio reuse`.
- Borrowing only the camera, edit or rhythm of a source → that is `reference generation`, not `video editing`.
- A `summary` for an edit **must** open with the fixed sentence `The target video is an edited version of <Video 1>.`

## Retention marks

Visual: `fully_preserved` · `partially_preserved` · `attribute_transfer` · `weak_reference`
Audio: `fully_copy` · `partially_copy` · `reference` · `weak_reference`

- For face and masked rebuilds the reference identity takes `attribute_transfer` (**not** `fully_preserved`), and the figure carrying it takes `partially_preserved`.
- `retention_analysis` **never** contains `(Sx)`.
- Newly added action, background or plot is not a loss of reference fidelity.

## Five hard rules for the body text

1. **Write the result, not the operation.** `Her face carries the identity of <Subject 2> throughout`, never `swap the face`.
2. **Give a checkable geometry list** (face shape, brow shape, eye shape, nose bridge, lip shape), not "looks like the reference".
3. **State where lighting and skin colour temperature come from and how they adapt**, so the reference's own light, background and grade are not carried into the finished video.
4. **Split performance ownership and pin down visible behaviour item by item**: identity and appearance come from `<Subject N>`, but expression, demeanour, gaze, blink rhythm, head, neck and torso motion, and mouth shapes are all driven by the source performance and must be written out **item by item** (see the next section). Without this, expression drifts, the gaze wanders and the lip sync slips. When the user asks for the actions to stay consistent, add the five motion groups (torso and weight · limb trajectories · rhythm and speed · head coupling · secondary motion) per the motion-transfer section.
5. **Handle boundaries and occlusion**: joins at the hairline and silhouette stay continuous with no seam; occluders — hands, hair strands, glasses, microphones — each get a sentence stating that the occlusion relationship is unchanged.

With multiple shots, label numbering stays fixed and carries across shots; when the angle changes (frontal, profile, head down) say that the identity must still hold.

## Visible facts only, plus performance replication

### 1. Never guess intent — describe only what is visible

- **Forbidden**: inferring what someone is doing, why, or in what situation. Never write `she is singing along to a song` / `she is recording a vlog` / `she is greeting a friend` / `she is thinking about her answer` — intent, identity, plot and off-screen causality are all guesses.
- **Rewrite as visible fact**: write what actually happens on her face and body — `her brows lift, her mouth corners pull up into a closed-mouth smile, her gaze drifts down-left and returns`.
- The same applies to audio: when only the presence of sound is detectable, write `her lips move and keep their exact shapes and timing from <Video 1>`; never "she is singing" or "she is speaking", and never invent lyrics or lines.
- The same applies to setting: write only the visible furnishings and light (`a panelled wooden door and white moulding behind her`); never infer the purpose of a place (no "she is in a livestream room", no "she is rehearsing").

### 2. Visible-behaviour checklist — write every group when replacing a person

Four groups, **each carrying a same-beat constraint** (`on the same beats` / `at the same moments`):

| Group | What to cover | English wording |
|---|---|---|
| **Expression** | Brow height and angle, eyelid height, softness or tension around the eyes and mouth corners, lip opening | `the same facial expression, with the same brow height and angle, the same eyelid height and the same softness or tension around her eyes and the corners of her mouth` |
| **Demeanour** | How the overall facial state reads from moment to moment (open / guarded / amused / composed), shifting beat by beat | `the same demeanour as it reads on her face from moment to moment — how open, how guarded, how amused, how composed — shifting on exactly the same beats` |
| **Gaze** | Where the eyes rest and at what distance, drift and return, blink rhythm and amplitude, eyelid height | `the same gaze, her eyes resting on the same point at the same distance with the same drift and return; the same blink rhythm` |
| **Behaviour** | Head turns, tilts and nods, shoulder and torso sway, hand action, lip shapes and timing | `the same visible behaviour, with the same head turns, tilts and nods, the same shoulder and torso sway, and the same lip shapes and mouth movement at the same moments` |

**Closing sentence** (stops the model from adding its own drama):
`Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.`

**When the mask already covers the face**: the visible performance information is erased and must not be guessed back in — keep only what can be evidenced (head pose, shoulder line, mouth timing from the audio) and hand the rest back to the reference; **write no emotion adjectives**.

**Pose-type targets with no face to replicate**: the four groups collapse to `Behaviour` alone — head, shoulder, torso and hand trajectories with their timing, still on the same beats.

### 3. Motion transfer — the replaced figure must move exactly as the source figure moves

When the user says the **actions must stay consistent with the person in the video** (`保持动作` / `动作要跟视频里的一致`), write it the same way as the visible-behaviour groups but shift the focus from the face to the whole-body skeleton. Person replacement (face swap, figure swap, costume swap) already implies motion transfer; this section pins the motion down joint by joint so the model keeps the body instead of re-choreographing it while only holding the face.

**Five motion groups, itemised beyond the four behaviour groups, all with same-beat constraints:**

| Group | What to cover | English wording |
|---|---|---|
| **Torso and weight** | Stance, the timing of weight shifts between the feet, torso rotation and lean | `the same posture, with her weight shifting between her feet at the same moments, the same torso rotation and lean at the same beats` |
| **Limb trajectories** | Arm raise / cross / wave paths and amplitude, steps, knee and ankle flexes | `the same arm and hand movements, following the same paths through the air with the same amplitude and the same timing; the same steps, knee bends and ankle flexes` |
| **Rhythm and speed** | Start, acceleration, deceleration and pause beats; the overall motion rate | `at the same speed and on the same rhythm, starting, accelerating, slowing and pausing at exactly the same moments` |
| **Head coupling** | How head motion pairs with torso and arm motion (a turn carrying the gaze, a lift following the torso) | `her head moves in the same relation to her torso and arms as in <Video 1>` |
| **Secondary motion** | Hair, clothing and accessories swinging with a lag and settling behind the movement | `her hair, clothing and accessories swing, settle and lag behind her movement exactly as they do in <Video 1>` |

**Standard motion-ownership sentence** (in `detailed_description`, right after the rebuild sentence):

```text
Her entire movement is reproduced exactly as it is in <Video 1>: the same posture, with her weight shifting between her feet at the same moments, the same torso rotation and lean at the same beats; the same arm and hand movements, following the same paths through the air with the same amplitude and the same timing; the same steps, knee bends and ankle flexes; at the same speed and on the same rhythm, starting, accelerating, slowing and pausing at exactly the same moments; her head moves in the same relation to her torso and arms as in <Video 1>; and her hair, clothing and accessories swing, settle and lag behind her movement exactly as they do in <Video 1>.
```

**Three companion rules:**

1. **When the mask covers only part of the body**, claim motion ownership only for the masked parts — the unmasked body is already visible and the model keeps it anyway; writing both in full wastes characters. Mask over the head only: write head coupling + the four face groups. Mask over the whole body: write all five groups.
2. **When the mask is opaque (structure erased)**, the only evidenceable motion is at the joints the mask leaves exposed (shoulder line, neck, hip position); downgrade to extrapolating from those anchors: `her shoulders and neck keep their exact motion from <Video 1>, and the rebuilt head follows that motion exactly, turning, tilting and nodding on the same beats` — **never write** details that cannot be evidenced (hand trajectories and the like); that would be inventing motion.
3. **With several people, assign ownership per person**: one motion group for `<Subject 1>`, and for each other unmasked figure a single sentence `keeps their exact position, motion and timing from <Video 1>` (foldable into the retention items). Omit it and the model tends to make the second person move along, or freeze them.

**Retention marking**: motion transfer does not change the shape of `retention_analysis` — the carrier stays `partially_preserved` (appearance replaced), and the motion items are listed inside the retained list (`head turns, arm and hand movement, weight shifts and timing are retained unchanged`).

## The rebuilt content must match item by item

The rebuilt content (from the reference image or the user's written description) must be **neither short nor padded**. Work through this order and place each item into `{{REBUILD_SENTENCE}}`:

1. **Shape and proportion**: outline, aspect, end forms (brim curve, cap taper, sleeve shape).
2. **Colour and pattern**: main colour (must be bound to a noun, e.g. `a black wool-felt fedora`), secondary colour, motif and placement; state explicitly when there is no pattern.
3. **Material and optics**: fabric (wool felt, ceramic glaze, leather), roughness, highlight character (`matte with a soft sheen`).
4. **Attached details**: ribbon, bow, buttons, logo, stitching — **details the user did not mention are taken from the reference; details absent from both are not added**.
5. **Reverse exclusion**: the reference's background, studio light, product drop shadow and isolated camera angle are each negated (`the reference image's white studio background and soft floor shadow do not appear in the target video`).
6. **Old features of the source object**: the source video's original form and attached marks are negated too (`no lettering or logo appears on the hat`).

**Test**: compare the list against the user's words and the reference. A detail the user did not ask for that you wrote is padding; something the user asked for that you omitted is a gap. Both must be fixed.

## Cross-context identity transfer

When the reference face comes from a different era or setting than the source video (period costume into a modern city, retouched studio into handheld night footage), **by default transfer only the facial structure and skin texture — never the reference's headdress, crown, ritual makeup or facial paint**. Name those non-carried items explicitly once in the `<Subject 2>` line of `retention_analysis` (`the reference's headdress, forehead mark, eye makeup, and facial markings are not carried over`), or period elements will survive into the modern scene.

## Shortening

When the user asks for something simpler, compress in this order but keep all four essentials:

1. `subject_definitions` down to one line per item, keeping only usable anchors.
2. `retention_analysis` keeps only what is retained, with no reasoning: `partially_preserved - hair, dress, posture, and framing are retained; only the face is replaced.`
3. `detailed_description` down to 150–180 words: drop repeated feature lists and redundant spatial words, keep the four essentials (feature list, lighting and colour temperature, performance ownership, boundary and seam).
4. The six field names and the fixed `The target video is an edited version of <Video 1>.` opening are never dropped.

## Scene recipes

Full runnable examples and per-scene rules live in `references/editing-recipes.md`:

- **Universal replacement/editing template** (one-line request → three attributions → four checks → type lookup → six-module skeleton, in `references/universal-replacement-template.md`) — **everything that gets replaced goes through this one**
- Face replacement from a reference image
- Rebuilding a green or flat-colour masked face (including the two fallbacks for leftover green)
- Mask over the mouth plus a source audio track → lip sync (with the three-way branch table for no audio, audio present, and newly written lines)
- Object replacement and removal
- **Small-object replacement with no reference image** (the user only says "replace the green area with X" and supplies nothing: no `<Subject 2>`, task type stays `[video editing]`, negate the old prop, handle the straight edges of a rectangular mask)
- Style relighting and grade transfer
- Source-video continuation (`video continuation`)

## Pre-flight checks

Run these four on the source video before writing anything; missing any one of them risks a wrong prompt:

1. **Audio**: `ffprobe -v error -select_streams a -show_entries stream=index,codec_name -of csv=p=0 <file>`. **An empty result means there is no audio track**, and then `audio reuse` / `audio reference` have nothing to refer to and "match the lip sync to the audio" has no source to align to. ComfyUI exports frequently drop audio, so always check before asking.
2. **Is the resolution a multiple of 32** (544=17×32, 704=22×32, 576=18×32, 736=23×32 and so on)? If so the source is probably already a `CS Spatial Stabilize` crop, and the original camera movement must not be carried over (see section 6 of `references/editing-recipes.md`). Also check for solid black padding bands top and bottom.
   **How to confirm**: sample 8–10 frames and compute the normalized centroid of the green area (or the subject). A centroid drift of ≤1.5% while a top black band keeps thickening (for example 0 → 36 rows, peaking around 20% of frame height) means the subject is locked and padding is being exposed at the edge — the signature fingerprint of a stabilize node; if the centroid moves together with the band, it is not.
3. **Shot count**: sample 6–12 frames into a `tile` montage and look. For a single shot `detailed_description` carries `[Shot 1]` only, with no timestamp.
4. **Mask form**: magnify the target area (face, object, clothing, background) and look, plus compute the mean RGB inside the mask. **Opaque mask and translucent tint are written almost oppositely** (criteria and skeletons in section 2 of `references/editing-recipes.md`). **In this project's material the masks on replaced targets are translucent tints, which is the default path.**
   - **Opaque mask** (flat solid colour, no internal structure, mean R < 40): the target's structure and motion information has been erased and H3 has nothing to "keep".
     - Target includes the mouth, source has **no audio**, and only a face swap is wanted → write a neutral, still mouth (`lips stay softly closed and relaxed`) to leave a clean base for downstream lip sync.
     - Target includes the mouth, source **has audio**, and lip sync is wanted → follow section 7 of `references/editing-recipes.md`: mark `<Audio 1>` as `fully_copy` and describe articulation explicitly with `<Subject 1> (S1)` in the body; **never invent `<d>` lines**.
     - The user wants H3 to speak → you must ask for the exact line and add `<d>[Language] ...</d>`.
     - For object or clothing targets, evidence the geometry from the surroundings instead (fingers gripping it, contact shadow, neighbouring objects, ambient light direction).
   - **Translucent tint** (structure still readable under the green layer, mean R ≈ 80): **motion and geometry are fully preserved**, so the only constraint that really matters is stating ownership explicitly — face swap `Her expression, gaze, blink rhythm, and the exact shapes and timing of her mouth movements continue from her performance in <Video 1>`, object swap `Its position, orientation, silhouette, velocity, and motion path continue unchanged from <Video 1>`, costume swap `Its fit, folds, sway, and hem movement follow her body motion exactly as the garment in <Video 1> does`, all with `natural, untinted colour`. Without this sentence the model regenerates the target together with its motion: lips slip off the audio, the object leaves the hand, clothes turn into a rigid shell.
   - **Third type: small hard-edged rectangular mask** (hand-drawn box or auto mask, area down to 1‰ of the frame, such as a 24×41 px box over a cigarette at the mouth). Two criteria: **straight edges** (a rectangle rather than a contour fit) and **area far larger than the target object** (it covers surrounding skin or tabletop too). The rebuild is then two things — the target in place **plus restoring the masked surrounding surface** — and must carry `The patch's straight edges do not survive anywhere in the target video; the rebuilt area blends into her face with no seam and no colour break.` Without it a rectangular colour block survives into the finished video. The source's old prop must also be negated (`no cigarette appears in the target video`).
   - **Fourth type: blocky, stair-stepped boundary** (the rough edge of an auto mask, up to 40% of the frame, e.g. a whole half-body). Judge by **whether the boundary is stepped or blocky** rather than contour-fitting — walk the left edge row by row and take the leftmost mask column; a dozen-plus jumps in position puts it in this class. Such a mask often **runs all the way to the frame edge and is cut off there** (the lower body leaves frame). Two required sentences: `The rebuilt figure fills the overlay's stepped, blocky outline exactly, so no step, no block edge and no colour break survives along the join between it and the background`, and for the frame-edge cut `it is cropped at the bottom edge at the same point as the source figure`. **When the reference subject is longer than the source subject** (source only to the thighs, reference full-length), keep going and negate the off-frame part: `so the lower part of her legs and the red heels in <Picture 1> stay below the frame and out of view` — without it the model stretches the frame or forces the shoes in.
   - **Whether the mask contains clumped highlight pixels (leftover logo, emblem or embroidery)**: magnify the masked area and count non-green pixels inside. Keying tools often preserve brand marks and the model will copy them onto the new object, so negate them (`no lettering or logo appears on the hat`). **Worn items (hats, glasses, headwear, jewellery)** have their own rules — geometry anchors can only be evidenced from the hair, the contact shadow at the brow, and the head pose, and the motion-ownership sentence must state that the item follows the head; see section 3, "Worn-item replacement", in `references/editing-recipes.md`.

## Quality gate

Check every item before output:

- [ ] All six field names present, in the right order, none renamed
- [ ] `summary` opens with `The target video is an edited version of <Video 1>.`
- [ ] Reference images that only define appearance have no standalone `<Picture N>`
- [ ] **With no reference material, no `<Subject 2>` is created**, the feature list goes straight into `detailed_description`, and the task type is only `[video editing]` (no `reference generation`)
- [ ] **Small rectangular mask**: states that the straight edges do not survive and that the rebuilt area is seamless with no colour break, and negates the source's old prop
- [ ] **Blocky stair-stepped mask**: states that the steps and block edges do not survive and that the join is continuous with no colour break, and, when the mask reaches a frame edge, states that it is cut off at the same point as the source subject
- [ ] **When the reference subject is longer than the source subject** (source to waist or thighs, reference full-length), the off-frame part is negated item by item (`stay below the bottom edge of the frame and out of view`)
- [ ] Reference identity is marked `attribute_transfer`, the carrier `partially_preserved`
- [ ] `retention_analysis` contains no `(Sx)`
- [ ] No imperative or post-production term such as `swap` / `remove` / `replace` / `chroma` / `green screen` in the body
- [ ] **No intent, identity or plot inference**: nothing like "singing / livestreaming / rehearsing / thinking / talking to someone"; the setting is only visible furnishings and light
- [ ] **A person replacement writes all four visible-behaviour groups**: expression · demeanour · gaze · behaviour, each with its same-beat constraint (`on the same beats` / `at the same moments`), and the closing sentence `Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.`
- [ ] **Figure-swap ownership test (the only criterion: inside or outside the mask)**: everything visible inside the mask (cap, top, trousers, hairstyle, ...) belongs to `<Subject 2>` and its source version is negated item by item with `are not carried over`; those items **never appear in `<Subject 1>`'s retained list and never as "stay unchanged" in `summary`**; `<Subject 1>`'s retained list holds only motion, posture, body position, timing and the body parts outside the mask. Self-check: ask per element "is it inside the mask?" Inside → rebuild; outside → retain
- [ ] **Motion transfer (action must match the source person)**: the five motion groups are written for the masked parts — torso and weight · limb trajectories · rhythm and speed · head coupling · secondary motion; an opaque mask downgrades to extrapolating from the exposed joints; with several people, each person's motion ownership is assigned; motion items appear inside the retained list of `retention_analysis`
- [ ] **Rebuilt content matches the reference and the user's words item by item**: shape and proportion · colour and pattern · material and optics · attached details. No gaps, no padding; the reference's background, studio light, product shadow and original camera have each been negated
- [ ] The body carries the six modules: rebuild sentence + optics taken from the source scene + **motion ownership** + occlusion and depth order + fit + seam
- [ ] **The fit sentence matches the type**: object = size rule (default R1, keep the occupied space) / costume = body drives the garment / background = perspective and parallax aligned / material = shape and volume unchanged
- [ ] **The motion-ownership sentence matches the type**: face = performance (expression, blink, mouth shapes) / object = displacement and velocity (and not recomputed from the new object's physics) / costume = follows the body / background = parallax
- [ ] The non-carried items for that type are listed item by item (the reference's lighting, background, pose or flat-lay form, own perspective, camera)
- [ ] Removal creates no `<Subject 2>`, drops `reference generation`, and states how the gap is filled
- [ ] With multiple targets, numbering increases in order of first appearance, each with its own mask and geometry anchors
- [ ] Costume, background and camera position are listed item by item among the retained items (omitting them lets the model replace them too)
- [ ] **Occluders are listed separately**: anything lying over the rebuilt area (hair strands, fingers, jewellery, foreground objects, another person's limb entering frame) is stated to keep its position and still cover the new target (omitting it flattens them into the new target)
- [ ] **Props the subject holds are listed separately** (cigarette, cup, phone held at the mouth or in the hand, inside the mask): same angle, same length, same position, with the new lips or fingers still closing around it
- [ ] **Off-frame parts are declared**: when feet or legs are outside the frame in the source, write `stay below the bottom edge of the frame and out of view throughout` or the model will change the framing to include them
- [ ] **Silhouette change**: when the reference costume reveals more than the source costume (long sleeve → camisole, trousers → short skirt), write the bare skin areas and negate the source garment's form among the non-carried items
- [ ] **Camera decision, one of two**: content scaling as a whole (background grows with it) = a real push-in, write camera words; subject nearly static + background not scaling + padding exposed at the edge = stabilize-node fingerprint, zero camera words in the body. **The presence of a black band is not itself a criterion**
- [ ] **Canvas edges**: with padding bands present, write them as `padding bands along the frame edges` and keep them; do not list per-edge pixel counts and do not instruct a framing change
- [ ] Whole text ≤ 7000 characters
