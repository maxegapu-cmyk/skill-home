# H3 视频编辑提示词配方集

五个场景的可投喂示例与专属规则。所有示例均按六段 Ref2VA 结构书写，全文 ≤ 7000 字符。

---

## 一、参考图换脸

### 标签分配

| 标签 | 指向 | 保留标记 |
|---|---|---|
| `<Video 1>` | 被编辑的源视频 | `fully_preserved`（镜头、剪辑、时序为编辑基准） |
| `<Subject 1>` | 源视频里的那个人（身体、发型、服装、表演、走位） | `partially_preserved` |
| `<Subject 2>` | 参考图里的面部身份，拆成几何特征 | `attribute_transfer` |
| `<Picture 1>` | 参考图本体，**不单列**，内联进 `<Subject 2>` 定义 | — |
| `<Audio 1>` | 源视频原声（保留时） | `fully_copy` |

### 两条硬规则（换人／换脸必守）

1. **不猜目的，只写可见事实。** 不写 `she is singing along to a song` / `she is recording a vlog` / `she is thinking about her answer`——意图、身份、剧情、画外因果都是猜测；改成看得见的事实 `her brows lift and her mouth corners pull up into a closed-mouth smile`。有音轨但听不出内容时只写 `her lips move and keep their exact shapes and timing from <Video 1>`，歌词台词一律不臆造。
2. **可见行为四组逐项复刻**（表情 · 神态 · 眼神 · 举止），每组带同节奏约束，并收口于 `Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.` 完整句见 `references/universal-replacement-template.md`「可见行为复刻清单」——**不写这四组，成片会出现表情漂移、眼神乱飘、神态与源素材脱节**。
3. **动作迁移（用户要求动作与源人物一致时）**：在四组之外追加「动作五组」——躯干与重心 · 四肢轨迹 · 节奏与速度 · 头部联动 · 次级运动，标准句与三条配套规则见「动作迁移」一节。遮罩不透明时降级为从露出的关节锚点外推，不编造无法取证的细节。
4. **换人归属判定（唯一判据：在不在遮罩内）**：遮罩盖到哪里，替换就到哪里——遮罩内的全部外观（帽、上衣、裤子、发型）归 `<Subject 2>` 重建并逐项 `are not carried over`；**绝不能写进 `<Subject 1>` 的保留清单，也绝不能在 `summary` 里写「保持不变」**；`<Subject 1>` 只保留动作、姿势、体位、时序与遮罩外部位。真实翻车案例与正确对照写法见 `references/universal-replacement-template.md`「换人任务的归属判定」。

### 完整示例

```text
subject_definitions:
<Subject 1> is the woman performing in <Video 1>, with shoulder-length dark hair, a cream knit sweater, and a thin gold necklace.
<Subject 2> is the facial identity in <Picture 1>, with an oval face, arched dark eyebrows, almond eyes with visible double eyelids, a straight narrow nose bridge, and full lips with a soft cupid's bow.
<Video 1> is the source video for the target video edit, a single continuous eight-second handheld shot of <Subject 1> walking through a cafe toward the camera.
<Audio 1> is the synchronized audio track of <Video 1> and is reused in the target video.

summary:
[video editing + reference generation + audio reuse] The target video is an edited version of <Video 1>. Only the facial identity of the woman in the source video is replaced: her face throughout the target video carries the features of <Subject 2> from <Picture 1>, while her body, hair, clothing, performance, the cafe background, the camera path, and the original audio track stay unchanged.

retention_analysis:
<Subject 1> (appears in [Shot 1]): partially_preserved - the shoulder-length dark hair, cream knit sweater, thin gold necklace, walking motion, head turn, and framing are retained, and only the facial identity is replaced.
<Subject 2> (appears in [Shot 1]): attribute_transfer - the facial identity in <Picture 1> is transferred onto the face of <Subject 1>, so its face shape, eyebrows, eyes, nose bridge, and lips appear on the walking woman without importing the reference image's own lighting, framing, or background.
<Video 1> (edit source): fully_preserved - the continuous shot, its framing, backward camera path, pacing, and timing are retained as the base of the edit.
<Audio 1>: fully_copy - the synchronized track of <Video 1> is reused 1:1 as the target video's complete final audio track.

detailed_description:
[Shot 1] A medium close-up tracks backward as <Subject 1>, the woman in the cream knit sweater, walks toward the lens through a cafe lit by warm hanging bulbs. Her hair shifts with each step and the background blurs behind her. Her face carries the identity of <Subject 2> throughout: the same oval face shape, arched dark eyebrows, almond eyes with visible double eyelids, straight narrow nose bridge, and full lips are visible from a three-quarter angle, adapting to the cafe's warm interior light rather than the reference image's own lighting. Her visible performance is reproduced exactly as it is in <Video 1>: the same facial expression, with the same brow height and angle, the same eyelid height and the same softness or tension around her eyes and the corners of her mouth; the same demeanour as it reads on her face from moment to moment — how open, how guarded, how amused, how composed — shifting on exactly the same beats; the same gaze, her eyes resting on the same point at the same distance with the same drift and return; the same blink rhythm; and the same visible behaviour, with the same head turns, tilts and nods, the same shoulder and torso sway, and the same lip shapes and mouth movement at the same moments. At 00:04.200 she turns her head to face the camera directly, and the features remain consistent from the frontal angle; the face-to-hairline transition stays continuous with no visible seam. Her sweater, necklace, and the background remain identical to <Video 1>, and <Audio 1> continues unaltered. Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.

overall_soundscape:
The copied ambience layer from <Audio 1>, consisting of cafe room tone, footsteps on tile, and distant chatter, continues throughout the target video.

non_diegetic_music:
N/A
```

### 多镜头要点

同一张参考图跨多镜头时 `<Subject 2>` 编号不变，每个镜头延用同一标签并在首次出现处重申一致性；换角度（正脸／侧脸／低头）必须在正文点明身份仍需一致，否则模型会在侧脸时漂移。

---

## 二、绿幕／纯色遮罩脸的重建

源视频里的人脸被一块纯绿（或其他高饱和纯色）区域覆盖，是对口型／换脸流程里常见的前置状态。**它不是画面内容，而是编辑定位信息。**

### 两种遮罩形态，写法完全不同（先判这个）

判据：放大截取面部区域目视 + 算遮罩内像素的均值 RGB。**别只看"有绿"就按不透明遮罩写——两者对提示词的要求几乎相反。**

| | 不透明遮罩 | 半透明叠加（tint） |
|---|---|---|
| 表现 | 一块平坦纯色，内部无结构 | 绿色薄层盖在脸上，眉毛、眼睛、鼻型、嘴形、牙齿、表情**仍可读** |
| 遮罩内均值 R 通道 | 极低（R < 40），且方差小 | 明显偏高（经验值 R ≈ 80，如 meanRGB ≈ (84, 211, 61)） |
| 嘴部运动信息 | **已被抹除** | **完整保留** |
| 可用的表演线索 | 只剩周边（头姿、发际线、脖颈色温、环境光、发型落点） | 源表演本身（表情、视线、眨眼、口型形状与时序） |
| 正确写法 | 特征全部从周边取证；嘴部按音轨有无决定中性静止或重生成 | **声明表演由源视频驱动**，只换身份；并要求渲染为 natural, untinted colour |
| 保留标记 | `<Video 1>` = `partially_preserved` | 同左（`partially_preserved`） |

**判据升级（只看 R 均值会误判）**：某素材整个身体被遮罩覆盖，遮罩内均值 **R ≈ 30（低于 40 的不透明阈值）**，但 **R 的标准差 ≈ 43**，且目视可见面部五官、衬衫纽扣、衣袖褶皱在绿层下**清晰可读** → 实为**半透明叠加**。

正确判据是三者合判：

| 量 | 不透明遮罩 | 半透明叠加 |
|---|---|---|
| 遮罩内 R 均值 | R < 40 | 30–90（皮肤／衣物／背景透出会拉低均值） |
| 遮罩内 **R 标准差** | **< 15**（同一色值几乎无波动） | **> 30**（结构与纹理透出造成波动） |
| 目视可读性 | 内部无结构 | 轮廓、五官、布料褶皱、纽扣等可辨认 |

**标准差是关键判别量**：覆盖在深色皮肤或深色衣物上的半透明绿层会把均值压到 30 上下，与不透明遮罩的均值区间重叠；只有结合标准差（是否 > 30）与目视可读性才能定性。定性错了，正文骨架会整段写反。

半透明叠加时的正文骨架：

```text
Her face is rebuilt with the identity of <Subject 2>: <特征清单>, following the head angle, tilt, and hairline already present in the source. Her skin renders in natural, untinted colour with the warm tan undertone of <Subject 2>, adapted to the balcony's warm ambient light so the rebuilt face and her visible neck, shoulders, and chest read as one continuous skin tone rather than the reference image's cool studio light. Her expression, gaze, blink rhythm, and the exact shapes and timing of her mouth movements continue from her performance in <Video 1> and stay locked to <Audio 1>: <具体运动>. The rebuilt facial region carries no trace of the source overlay, and the join between the new face, her hairline, and her jawline stays continuous with no seam.
```

三条要点：

1. **必须显式写"表演归属在源视频"**（`continue from her performance in <Video 1>`）。不写这句，模型会把整张脸连表情一起重生成，口型随即与原音脱轨——这是半透明叠加场景下唯一真正重要的约束。
2. **`<Video 1>` 定义里要写"features stay clearly readable beneath it"**，让模型知道你拥有完整的运动信息，而不是一块需要凭空补全的空白。
3. **肤色方向只给"读作同一肤色"，不给单向强制。** 参考脸明显比主体深／浅时，写 `read as one continuous skin tone` 让模型自己去调；写死"取主体肤色"会削弱参考脸身份，写死"保留参考肤色"会在脖颈处露接缝。

### 第四类：块状阶梯边界（自动遮罩的粗糙边缘）

半透明叠加常配**块状阶梯边界**——边界不是贴合轮廓的曲线，而是 8–16px 的台阶／方块。判定：沿遮罩左缘逐行取最左列，位置出现十几级跳变（如 17 个不同位置、24 次变化）即属此类。此类遮罩面积可以很大（整人半身，占画面 30%–45%）。

两个必写句（缺任一句，成片里会留下一圈方块状色边，或人物被改画幅）：

```text
The rebuilt figure fills the overlay's stepped, blocky outline exactly, so no step, no block edge and no colour break survives along the join between her and the room behind her.
```

**遮罩延伸到画面边缘被裁断时**（人物下半身出画，`ys.max() == h-1`），写清裁断点：

```text
She is cropped at the bottom edge at the same point as the source figure.
```

**参考图主体比源主体更长时**（源只到腰／大腿，参考图是全身照），必须接着否掉画外部分——否则模型会拉长画幅或把鞋硬塞进来：

```text
so the lower part of her legs and the red heels in <Picture 1> stay below the frame and out of view.
```

同族提醒：源主体头上有帽、参考图人物赤头时，遮罩内的帽与帽上徽标要一并否定（`the flat cap, the emblem on the cap ... are not carried over`），并在不迁移项里列参考图的街景／棚光／站姿。

### 遮挡与画布边缘：用户常整段列出，逐项落到位

「保持源运动、定时、相机角度、取景、照明、背景、遮挡和所有未遮罩的区域」这类整段要求，必须逐项映射成可核对的句子，缺项会真的丢：

| 用户说法 | 正文/保留分析里写什么 |
|---|---|
| 源运动、定时 | `Her motion, timing, expression, gaze, blink rhythm, and the exact shapes and timing of her mouth movements continue unchanged from her performance in <Video 1>` |
| 相机角度、取景 | `keeps <Video 1>'s locked camera angle and framing exactly, with no camera movement`——**锁死构图时正文一个运镜词都不写** |
| 照明 | `adapted to the balcony's warm ambient light`（写明光源方向或性质） |
| 背景 | 逐项点名背景元素（`the balcony railing`、`the lit city skyline`、`warm bokeh lights`） |
| 遮挡 | **头发、饰品压在重建区上的部分必须单独写**：`The hair strands crossing the frame-left edge of her face keep their exact position and overlap over the new face, and the dangling earring at her frame-right ear stays in front of her jaw exactly as in <Video 1>.` 不写这句，模型会把手／发丝／耳饰"抹平"进新脸里 |
| 主体自己持有的道具（烟／杯／手机） | 与遮挡句**分开写第二句**：`the cigarette stays held between her rebuilt lips at the same angle, length and position, with the lips closing around it exactly as in <Video 1>`。道具在遮罩内但不属于替换目标时，漏写会被一起重画或抹掉 |
| 他人的入侵肢体（伸进画面压在前方的手／袖口） | `keep their exact position, size, depth order and motion, and stay in front of her exactly as in <Video 1>` |
| 所有未遮罩区域 | `every unmasked region stays exactly as in <Video 1>` + 逐项列（脖颈、肩、手臂、手、服装、镜头边缘） |

**画布边缘别一概而论**：黑带出现或变厚 ≠ 构图锁死。若内容在整体缩放（相邻背景人物同步变大），那是真实推镜，照常写 `the camera pushes in slowly and steadily toward her throughout, tightening from a medium shot to a close-up`；只有「主体近静止 + 背景不缩放 + 边缘单独露填充」才是稳定节点指纹（正文零运镜词，边缘按 `padding bands` 保留）。两者都有黑带，靠**背景是否同步缩放**分开。另注意：黑带可能只出现在部分边（如首帧仅底边 45px，尾帧上 31px／左 34px 也出现），保留项里写 `the padding bands along the frame edges` 即可，不逐边列数字。

**画布边缘（letterbox / 稳定填充带）怎么处理**：若源视频有稳定节点留下的黑边，`<Video N>` 定义里写成 `held in a locked frame with letterbox padding along the top and bottom edges`，保留分析里列 `letterbox padding`，正文用 `the frame edges` 指代即可——**不要展开描述黑边，更不要指示模型改写画幅**，下游 `CS Spatial Restore` 依赖同一画布尺寸做逆变换。只有用户明确表示不需要 Restore 且希望边缘被补全时，才改成让模型延长天空／背景。

### 四条硬规则

1. **遮罩相关的颜色词只在两个位置出现。** 一处是 `<Video N>` 的定义，点明它是待重建区域；一处是 `summary`，声明结果。正文其余部分不再出现 `green` / `chroma` / `key` / `green screen`——重复出现会强化模型真的渲出一块绿。
   **例外（物体类常见）**：被替换对象本身带绿色时（西瓜的深绿瓜皮、绿苹果），描述物体本色的 `green` 不受此限，但必须绑定在物体名词上（`its dark green rind`），**禁止让 `green` 单独作名词指代区域**。自检时按"遮罩相关颜色词 ≤ 2 处"判定，不按 `grep -c green` 判定。
2. **只用结果句覆盖，不用指令句。** 写 `is fully rebuilt as the face of <Subject 2>` 与 `no green region appears anywhere in the target video`；不要写 `remove the green` / `replace the green screen`。
3. **面部约束全部从「周边」取证。** 脸被盖住后可用线索只剩：头姿与转动角度、发际线位置、脖颈与肩臂皮肤色温、环境光方向与色温、发型落点与遮挡。这些必须在正文里显式声明为新脸的约束条件——这是遮罩换脸与普通换脸最大的差别，也是不写就会出现「脸和身体不是一个色温」的原因。
4. **一次性定位，之后改用中性指代。** 首次写 `the flat green region covering her face`，往后一律用 `the rebuilt facial region`。全篇颜色词只允许出现两处：`<Video N>` 定义、`summary`。`retention_analysis` 里写 `the source's flat face region`，`detailed_description` 里连否定句都不用，改写 `carries no trace of the source overlay`——颜色词每多一次，模型渲出绿块的倾向就强一分。

### 标签分配

| 标签 | 保留标记 | 理由 |
|---|---|---|
| `<Subject 1>` | `partially_preserved` | 发型、服装、姿态、构图保留，面部区域被替换 |
| `<Subject 2>` | `attribute_transfer` | 参考脸身份转移到源视频的头部，继承源视频的头姿与光照 |
| `<Video 1>` | `partially_preserved` | 镜头、构图、时序、背景保留，但绿区被重新解释为重建区域 |
| `<Audio 1>` | `fully_copy` | 源声 1:1 复用 |

> 若**没有**参考脸图、脸由文本虚构：不要建 `<Subject 2>`（官方定义中 `<Subject N>` 是「从参考素材中抽象出的可见内容」），直接在正文给特征清单，任务类型降为 `[video editing + audio reuse]`。

### 完整示例（天台夜景竖屏镜头）

```text
subject_definitions:
<Subject 1> is the woman in <Video 1>, with long dark wavy hair falling past her shoulders, a pale silver satin slip dress with thin straps, standing at a rooftop railing.
<Subject 2> is the facial identity in <Picture 1>, with an oval face, soft arched eyebrows, almond eyes, a straight nose bridge, and full lips.
<Video 1> is the source video for the target video edit: a vertical handheld night shot of <Subject 1> at a rooftop railing with a lit city skyline and a tall spire behind her. In the source, a flat green region covers her face; this region marks the area to be rebuilt and is not part of the target video's visible content.
<Audio 1> is the synchronized audio track of <Video 1> and is reused in the target video.

summary:
[video editing + reference generation + audio reuse] The target video is an edited version of <Video 1>. The green-covered face region in <Video 1> is fully rebuilt as the face of <Subject 2> from <Picture 1>, matching the head pose, hair fall, and warm night lighting already present in the source. Her hair, satin dress, posture, the rooftop railing, the city skyline, the handheld drift, and the original audio track remain unchanged, and no green region appears anywhere in the target video.

retention_analysis:
<Subject 1> (appears in [Shot 1]): partially_preserved - the long dark wavy hair, pale silver satin slip dress with thin straps, posture at the railing, and framing are retained, and only the face region is replaced by <Subject 2>.
<Subject 2> (appears in [Shot 1]): attribute_transfer - the facial identity in <Picture 1> is transferred onto the head of <Subject 1>, adopting the source's head angle, hairline position, and warm ambient light without importing the reference image's own lighting or background.
<Video 1> (edit source): partially_preserved - the shot, framing, handheld drift, timing, and background are retained, while the source's flat face region is interpreted only as the rebuild area and is not reproduced.
<Audio 1>: fully_copy - the synchronized track of <Video 1> is reused 1:1 as the target video's complete final audio track.

detailed_description:
[Shot 1] A vertical handheld night shot holds on <Subject 1>, the woman with long dark wavy hair and a pale silver satin slip dress, standing at a rooftop railing with a lit city skyline and a tall spire behind her. Warm bokeh lights glow in the background and a cool rim light picks out the edges of her hair and shoulders. Her face is fully rebuilt with the identity of <Subject 2>: the same oval face, soft arched eyebrows, almond eyes, straight nose bridge, and full lips, following the head angle, tilt, and hair fall already present in the source. Skin tone is derived from her visible neck, shoulder, and arm skin so the new face matches the body's color temperature and the warm ambient glow. The rebuilt facial region carries no trace of the source overlay; the transition between the new face and the hairline stays continuous with no seam. Her dress, the railing, the skyline, and the handheld drift remain identical to <Video 1>, and <Audio 1> continues unaltered.

overall_soundscape:
The copied ambience layer from <Audio 1>, consisting of light night wind, distant city hum, and faint traffic, continues throughout the target video.

non_diegetic_music:
N/A
```

### 残留绿色的两条兜底路径

H3 是生成模型而非合成器，提示词只能表达「这一块应当被重建」，不能施加真正的 chroma-key 运算。若成片仍残留绿色：

- **提示词侧**：进一步压缩颜色词的存在感，只在 `<Video N>` 定义与 `summary` 各保留一次，并检查正文是否误用了 `screen` / `mask` / `key` 等后期术语。
- **素材侧（更稳妥）**：把源视频的绿区先替换为中性纯灰或用参考脸预合成，再把干净源视频交给 H3——绿区问题在提示词层面完全消失，也顺带解决了色温与边缘接缝。

---

## 三、物体替换／移除

> 任何被替换对象（脸／服装／物体／背景／画内文字／材质／光照）共用同一套骨架，见 `references/universal-replacement-template.md`。本节只记物体类的专属点。

- 被替换的物体仍属 `<Subject N>`；移除类任务不要把物体写成 `<Subject N>`，否则模型会把它保留下来。
- 移除后用结果句声明空缺处的情况：背景如何延伸、光影如何回填、有无残影。
- 保留标记用 `partially_preserved`（被替换）或直接不建该 Subject（被移除）。
- 移除后新增的背景内容不算参考保真度损失。

物体类还有三件换脸没有的事，缺一件就出「贴纸感」：

1. **接触与遮挡必须单列**：几根手指在物体之前、拇指落在哪个面、接触阴影落在掌心何处、被手指遮住的部分仍不可见。漏写 → 手指被抹平进物体，或物体浮在手指之上。
2. **尺寸冲突要显式选规则**（苹果 → 西瓜必遇）：参考物与源物体积差异大时，「保持抓握关系」与「按参考物真实尺寸」不能同时成立。
   - **R1 保持占位（默认）**：`sized to fill the same space in her hand as the object in <Video 1>, so her fingers keep their exact contact points` —— 物体偏小，但抓握、遮挡、接触阴影全部自洽，不穿模。
   - **R2 忠于参考尺寸**：`rendered at the true size of <Subject 2>` 并改写接触关系，须在正文承认手部姿态被调整（与「保持源运动不变」冲突）。
   - **R3 折中**：`allowed to extend beyond the source object's footprint by up to about half its width while the grip points stay fixed`。
3. **速度不按新物体物理重算**：模型会按新物体的「应有重量」重做运动（把西瓜当重物减速、把气球当轻物飘起）。显式写 `Its velocity and motion path continue unchanged from <Video 1>; it neither accelerates nor slows down after the replacement.`

```text
<Subject 2> is the ceramic coffee cup from <Picture 1>, with a matte off-white glaze, a thin handle, and a faint crackle pattern.
```

正文写：`<Subject 2>, the ceramic cup, rests on the table edge in place of the paper cup in <Video 1>, with its handle turned toward the right and its base shadow falling on the same grain of the wooden table.`

### 无参考图的小物体替换（纯文本描述目标）

用户只说「把绿色区域换成雪茄／换成 X」并明确没有参考图时，走这一路，与前两种都不同：

1. **不建 `<Subject 2>`。** 官方定义里 `<Subject N>` 是从参考素材抽象出的可见内容；无参考素材 → 特征清单直接写进 `detailed_description`，`subject_definitions` 只留 `<Subject 1>`（承载者）与 `<Video 1>`。任务类型相应只剩 `[video editing]`：**不加 `reference generation`**（无参考指导），**不加 `audio reuse`**（除非源视频确实带音轨）。
2. **必须否定旧道具。** 源视频里的旧物体（香烟／纸杯／手机）在半透明遮罩下往往仍隐约可见，模型会照着把它再画一遍。写结果句 `no cigarette appears in the target video`（与 `no green region appears anywhere` 同形，属结果陈述，不违反禁用动词）。
3. **矩形遮罩要单独处理边缘。** 手绘／自动遮罩常是一个**硬边矩形**，覆盖范围比目标物体大（本例 24×41 px，含嘴角色皮肤与下颌）。此时重建其实有两件事：物体就位 **+ 被遮的周边表面（皮肤／桌面／背景）连续性复原**。必须显式写 `The patch's straight edges do not survive anywhere in the target video; the rebuilt area blends into her face with no seam and no colour break.` 漏写 → 成片保留一个矩形色块边界，这是本类最典型的翻车形态。
4. **新物体按占位规则贴合遮罩足迹**：`its body extending downward at the same angle and within the same footprint as the marked patch`，并补一句比例提示（`its proportion reading as a cigar rather than a cigarette`），否则模型可能只把旧物体的粗细放大一点点。
5. 遮罩相关颜色词仍按 **≤ 2 处**计：`<Video N>` 定义一处 + `summary` 结果一处；其余全用中性指代（`the marked patch` / `the rebuilt mouth area`），并避开 `mask` 一词。

### 佩戴物替换（帽子／眼镜／头饰／首饰）

佩戴物＝**随身体动的物体**，规则介于「物体」与「服装」之间。本例：不透明绿帽遮罩（内部 R≈1、G 144、平坦无结构）→ 参考图黑羊毛礼帽，卧室口播特写 5s、单镜头、带音轨。

1. **几何锚点只能从周边取证**。不透明遮罩已抹掉佩戴物本身的结构与运动，不能写「保持源帽子的形状」。锚点改为三样：遮罩下缘露出的头发（`emerging below the brim and passing in front of her ears at the same points`）、接触阴影（`the soft shadow the brim drops on her brow`）、头部姿态与旋转。
2. **必须写「跟着头走」的运动归属句**：`Its seating, scale and orientation follow her head in <Video 1> exactly: as she turns her head to one side, tips it back with her chin raised, ... the hat turns and tips with it at the same rate and by the same amount, keeping constant, believable contact with her head with no independent drift of its own, no sliding, no floating and no change in size.` 漏写 → 新帽子钉在画面上不跟头转（转头幅度大的素材必翻车）。
3. **遮罩内残留的标志／徽标／绣字会被照抄进新佩戴物**。keying 工具常保留 logo（本例绿区中央一个白色 "A" 徽标，非绿像素成团 400–530 px、均值 ≈(198,208,181)）。**前置检查要多一步**：放大遮罩区看内部是否有成团高亮像素。有就必须否定：`no lettering or logo appears on the hat`，并在 `subject_definitions` 的 `<Video 1>` 里先声明该徽标的位置，再写它不随新物体迁移。
4. **新旧佩戴物轮廓不一致时（鸭舌帽 → 宽檐礼帽）**：显式声明形状**全部**来自参考（`The hat's shape, brim width and crown crease come entirely from <Picture 1>`），并否定源遮罩轮廓（`the cap's own stiff forward silhouette ... are not carried over`）。再补一句新边缘比旧遮罩宽，露出的头发在檐下连续、**不被剪断**：`the brim never cuts, clips or erases it`——漏写会在帽檐边缘裁掉一圈头发。
5. **佩戴物不得吃掉五官**：写下檐相对眉／眼的位置，`its wide flat brim passing just above her eyebrows ..., so that her eyes, nose and mouth stay fully visible and unobstructed throughout`。
6. 遮罩含嘴部以外的面部时（本例遮罩止于眉上），口型不受影响，但仍要在保留项里逐项列出 `gaze, blink rhythm and the shapes and timing of her lip movements`，并在 `<Audio 1>` 的 `fully_copy` 行补 `in step with it`，否则模型可能顺手重画表情导致脱轨。

### 未遮罩的平台水印／叠加文字（保留类，不重建）

抖音等平台导出的素材常带**水印**，且水印会**在片内跳位**（实测：前 1 秒在左上角，约 1.2–1.6s 起移到右下角直到结束）。它落在遮罩之外，属"必须保持不变的可见元素"，写法三条：

1. **逐字给原文**，不翻译：`the Douyin mark reading "抖音" with the line "抖音号: baolinqiu997"`。
2. **写"同时序"**并点明跳位时间点：`keeps its exact text, size and timing, staying in the top-left corner for the first second and in the bottom-right corner for the rest of the shot`。只写"保持在角落"会被钉死在起始角。
3. **补否定句防添字**：`no text other than the watermark appears anywhere in the frame`。

**判定手段**：抽 8 帧分别数四角的高亮像素（`>205` 计数）。水印所在角动辄 2,500+，其余角接近 0；若两个角的计数在前段／后段互补翻转，即证实跳位。
**反向提醒**：画面里像贴纸的小图案，先放大确认是不是**配饰**（肚脐钉／项链坠／牛仔扣＋口袋缝线）——误当贴纸写进去，模型会把它画成不存在的贴图。

### 动作迁移（替换后的人物必须与源人物动作一致）

用户说「**动作要跟视频中人物的动作一致／保持动作**」时，写法与可见行为四组同源，但重点从**脸**移到**全身骨架**。人物替换（换脸／换人／换服装）本来就隐含动作迁移，此节把「动作」单独立项、逐关节钉死，防止模型只保住脸而让身体重新编排。

**动作五组逐项复刻**（在可见行为四组之外追加，全部带同节奏约束）：

| 组 | 逐项内容 | 英文写法 |
|---|---|---|
| **躯干与重心** | 站姿或坐姿、重心左右前后移动的时序、躯干扭转与倾角 | `the same posture, with her weight shifting between her feet at the same moments, the same torso rotation and lean at the same beats` |
| **四肢轨迹** | 手臂抬起／交叉／挥动的路径与幅度、腿部迈步与膝踝屈伸 | `the same arm and hand movements, following the same paths through the air with the same amplitude and the same timing; the same steps, knee bends and ankle flexes` |
| **节奏与速度** | 动作的启动／加速／减速／停顿拍点，整体运动速率 | `at the same speed and on the same rhythm, starting, accelerating, slowing and pausing at exactly the same moments` |
| **头部联动** | 头部动作与躯干／手臂动作的配合关系（转头带动视线、抬头跟随躯干后仰） | `her head moves in the same relation to her torso and arms as in <Video 1>` |
| **次级运动** | 头发、服装、配饰随动作的摆动延迟与沉降 | `her hair, clothing and accessories swing, settle and lag behind her movement exactly as they do in <Video 1>` |

**标准动作归属句**（放在 `detailed_description`，紧跟重建句之后）：

```text
Her entire movement is reproduced exactly as it is in <Video 1>: the same posture, with her weight shifting between her feet at the same moments, the same torso rotation and lean at the same beats; the same arm and hand movements, following the same paths through the air with the same amplitude and the same timing; the same steps, knee bends and ankle flexes; at the same speed and on the same rhythm, starting, accelerating, slowing and pausing at exactly the same moments; her head moves in the same relation to her torso and arms as in <Video 1>; and her hair, clothing and accessories swing, settle and lag behind her movement exactly as they do in <Video 1>.
```

**三条配套规则**：

1. **遮罩只盖住部分身体时，动作归属只对遮罩内部位声明**，遮罩外的身体已经可见、模型本来就会保留——把两者都写全反而浪费字符。例如遮罩只盖头：只写头部联动 + 面部四组；遮罩盖全身：五组全写。
2. **遮罩是不透明（结构被抹掉）时**，动作信息只剩「遮罩外露出的关节」可取证（肩线、脖颈、髋位），写法降级为从这些锚点外推：`her shoulders and neck keep their exact motion from <Video 1>, and the rebuilt head follows that motion exactly, turning, tilting and nodding on the same beats`——**不写**无法取证的细节（手部轨迹等），否则等于凭空编动作。
3. **多人物时逐人归属**：`<Subject 1>` 的动作写一组，画面里其他未遮罩人物各写一句 `keeps their exact position, motion and timing from <Video 1>`（只保未遮罩者的句子可并入保留项）。漏写第二个人，模型常顺手让他也跟着动一下或反过来僵住。

**保留标记**：动作迁移不改 `retention_analysis` 的结构——承载者仍标 `partially_preserved`（外观被替换），动作逐项列进保留清单（`head turns, arm and hand movement, weight shifts and timing are retained unchanged`）。

---

## 四、风格重打光与调色迁移

- 风格来源若为参考图／参考视频，写成 `<Subject N>`（风格属于可复用的可见内容），保留标记用 `weak_reference` 或 `attribute_transfer`。
- 全参考模式的风格句写在 `[Shot 1]` **之前**，1–2 句，包含光源方向、色温、反差、质感。
- 不要在正文里写 `color grade` / `LUT` / `cinematic` 这类抽象词，改写成可感知的具体描述：光源位置、阴影软硬、肤色倾向、高光滚降。

```text
The target video is shot in a cool night ambience with a warm practical key from the left, low contrast in the shadows, and skin rendered slightly desaturated with a soft highlight roll-off.
[Shot 1] ...
```

---

## 五、源视频续写（video continuation）

- 任务类型 `video continuation`；`summary` 不以「edited version」开头，而应说明新内容从哪一秒接续、接续后发生什么。
- `<Video N>` 的角色是续写起点与时间结构来源，保留标记用 `partially_preserved`（新内容在其后展开）。
- 首帧状态必须与源视频末帧对齐：人物位置、朝向、视线轴、光源方向、服装与道具状态逐项写出，否则接缝处会出现跳变。
- 若新音频只延续原轨的可听特征而不复制信号，用 `audio reference` 而非 `audio reuse`。

---

## 六、预处理节点对提示词的影响（CS Spatial Stabilize / Restore）

`CS Spatial Stabilize`（ComfyUI_CineStyle）本身**不吃提示词**，它只做几何：以遮罩面积最大的一帧为锚点，把每一帧 warp 到固定尺寸的裁切框里，让目标区域居中且等面积缩放，输出 `IMAGE` / `MASK` / `STABLE_DATA`，再由 `CS Spatial Restore` 逆变换贴回原视频。典型用途是「局部裁切 → 全分辨率重绘 → 贴回」，让逐帧修复不再随包围盒游移。

它会改变交给 H3 的源视频状态，因此有三条提示词后果：

1. **`<Video N>` 要按「稳定后的裁切画面」描述，不是原始画面。** 若 H3 吃的是 stabilize 的输出，正文里的构图、景别、背景可见量都得按裁切后重写：主体居中、尺寸固定、四周留有 `Crop Margin Per Side` 的余量。
2. **不得沿用原视频的运镜词。** 稳定后的裁切框是锁死的；正文若还写 `handheld drift` / `tracking backward`，模型会自造新的镜头运动，而 `CS Spatial Restore` 的逆变换会把这段运动一并错误贴回原位。改为 `Static Shot` 或极轻微的 `with small amplitude`。
3. **`Crop Margin Per Side` 决定正文能写多少环境。** 40% 说明主体周围余量充足，正文应保留头发、肩部、背景虚化，不能写成填满画面的大特写。

参数速查：

| 参数 | 作用 | 取值建议 |
|---|---|---|
| `multiple` = 32 | 裁切宽高向上取整到该倍数，供下游 latent / tile / 编码器对齐 | 保持默认，除非明确知道原因 |
| `Crop Margin Per Side` = 40% | 每侧额外余量，按锚点帧遮罩最大宽高计算。过小 → 回贴接缝落在主体上；过大 → 不经济但更安全 | 40 偏宽松，安全 |
| `Average Frames` = 8 | X/Y/scale 滑动平均窗口，去逐帧抖动；首尾帧锁定以保持可逆；1 = 关闭 | 手持抖动强可提到 10–12；主体真实变速时调低 |
| `Mask Blur Sigma` = 6 | **只用于求边界框，不作用于输出的 MASK** | 遮罩本身干净可调小；需羽化输出遮罩须另行处理 |

最后一行最易误读：`Mask Blur Sigma` 不会让输出的 `MASK` 变软，需要羽化边缘必须在下游单独加羽化节点。

---

## 七、遮罩盖住嘴部 + 源视频自带音轨 → 口型同步

**这是「嘴部被抹除」与「要求口型同步」同时成立时唯一的可行写法。** 关键判断顺序：先查音轨是否存在（`前置检查` 第 1 项），再决定嘴部写成静止还是运动。

### 分支表

| 音轨 | 用户要求 | 嘴部写法 | 任务类型 |
|---|---|---|---|
| 无 | 换脸即可 | `lips stay softly closed and relaxed`（中性静止，给下游 lip-sync 留干净基底） | `[video editing + reference generation]` |
| 无 | 要 H3 说话 | 必须补 `<d>[Language] 台词</d>`，向用户索取台词原文 | `[video editing + reference generation]` |
| 有 | 口型同步该音轨 | `<Subject 1> (S1)` 显式描述articulation，**不臆造 `<d>`** | `[video editing + reference generation + audio reuse]` |
| 有 | 重配新台词 | 台词逐字进 `<d>`；原轨只作音色参考时用 `audio reference` | 按实际复用关系 |

### 有音轨且要口型同步时的写法要点

1. **`<Audio N>` 定义里点明"carries a continuous vocal line"**，这决定了它不只是环境声，而是有可对齐的人声线条。
2. **保留标记 `fully_copy`**，并在 reason 里补一句"and drives the visible mouth motion"——否则模型可能把嘴部当静态处理。
3. **正文用 `<Subject 1> (Sx)` 显式承接发声**，句式为结果陈述 + 运动描述：
   `<Subject 1> (S1) produces the vocal line carried by <Audio 1>: her lips and jaw move visibly in exact sync with it, opening and closing with its phrasing, holding the rounded shapes of its sustained tones and closing fully in its pauses, at natural lip-level amplitude.`
4. **不要臆造 `<d>` 台词。** 官方规则允许对听不清的片段写 `[unclear]` 而非猜测，但若整段都用 `[unclear]`，模型可能自行生成语音并与原轨冲突。默认做法是不写 `<d>`、只写运动同步；用户手上有歌词／台词时再补 `<d>`（原文与语言逐字保留），并在 `summary` 里把 `no dialogue beyond <Audio 1> is added` 删掉。
5. **判断人声类型不要凭听感下结论**，用 `ffmpeg -lavfi "showspectrumpic=s=1000x420:scale=log:color=magma"` 出频谱图看：带颤音的等间距谐波堆叠 = 持续人声／歌唱线条；响度包络有 10 dB 以上起伏且存在停顿间隙 = 口语对话；包络平坦无间隙 = 连续音乐或持续发声。写 `sung`／`spoken` 前必须有依据，否则用中性词 `vocal line`。
6. **`summary` 末尾声明无新增对白**：`and no dialogue beyond <Audio 1> is added.`

### 与稳定节点的叠加

若源视频同时是 `CS Spatial Stabilize` 输出（见第六节），口型段照写，但**"锁死构图"必须比"运镜"优先**：风格句写 `keeps <Video 1>'s locked, perfectly static framing with no camera movement`，正文里不再出现任何运镜词。黑边／填充带随之保持原样，**不要指示模型改写画幅**——下游 `CS Spatial Restore` 依赖同一画布尺寸做逆变换。

