# 替换／编辑通用模板（Ref2VA）

**触发句**：「将视频中的 `{目标}` 替换／修改成参考图中的 `{参考}`，保持视频中的其它元素不变。如果有对话或者唱歌，口型要匹配。」

**通用于任何对象**：人物身份、服装配饰、手持或场景物体、场景背景、画内文字与标识、材质表面、光照风格，以及移除与新增。换脸只是「目标 = 面部」的特例。

## 一、三归属模型（一切槽位都落在这一张表里）

| 维度 | 来源 | 漏掉的后果 |
|---|---|---|
| **外观**（是什么） | 参考素材 `<Subject 2>` | 换了个不像的东西 |
| **运动与几何**（在哪／怎么动／多大／贴不贴） | 源视频 `<Video 1>` | 目标自己乱动、脱手、穿模、衣服变硬壳 |
| **光学**（受什么光） | 源视频环境 | 参考图影棚光被搬进场景，目标像贴纸浮在画面上 |

## 二、四项自动检测

| 检测 | 手段 | 决定什么 |
|---|---|---|
| 音轨 | `ffprobe -v error -select_streams a -show_entries stream=index,codec_name -of csv=p=0 <file>`，空 = 无 | `audio reuse` 与口型段 |
| 遮罩形态 | 抽帧放大 + 遮罩内均值 RGB 与 **R 标准差** | 运动信息是否可用 |
| 遮罩边界与遮挡 | 数边缘被哪些元素穿过、穿过几次 | 遮挡句条数 |
| 构图与镜头 | `select='gt(scene,0.35)'` + 质心漂移 + 黑带行数 | 运镜写法、`[Shot N]` 数量 |

**稳定性指纹**：遮罩质心漂移 ≤1.5% 而黑带持续增厚 = `CS Spatial Stabilize` 输出 → 正文零运镜词，画布边缘按 `letterbox padding` 保留。
**反向误判警告（重要）**：**黑带出现或增厚本身不等于构图锁死。** 内容若在整体缩放（相邻背景人物、桌面物件同步变大），那就是真实推镜，照常写 `the camera pushes in slowly and steadily toward her throughout, tightening from a medium shot to a close-up`；只有「主体近静止、背景也不缩放、而边缘单独露出填充」才是稳定节点指纹。两者会同时出现"有黑带"这一个特征，必须用**背景元素是否同步缩放**来分开。本项目里带黑带的素材两种都出现过，逐条判。
**本项目素材的遮罩默认为半透明叠加** → 运动几何信息完整保留，源视频是权威参照，必须显式声明归属。
**遮罩形态判据（只看 R 均值会误判）**：遮罩压在深色皮肤或深色衣物上时，半透明叠加的 R 均值也会掉到 30 上下，与不透明遮罩区间重叠。必须三者合判——**R 均值 + R 标准差 + 目视可读性**：不透明 = R<40 且 **R 标准差 < 15**、内部无结构；半透明 = **R 标准差 > 30**、五官与布料褶皱可辨认。定性错了正文骨架会整段写反。

## 三、目标类型 → 槽位速查

| 目标类型 | `<Subject 2>` 外观槽位（参考） | 几何／运动锚点（源视频） | 必列的不迁移项 |
|---|---|---|---|
| 人物身份 | 脸型、眉、眼、鼻、唇、肤色质感、辨识特征（痣／疤／须） | 头姿、发际线、**表情 · 神态 · 眼神 · 眨眼节奏**、口型形状与时序、举止（头转／肩摆／手势） | 参考图的发型、妆造、头饰、服装、背景、影棚光 |
| **整个人物（换人，含发型与服装）** | 发型发色、脸、身形与腿部比例、上衣／下装／鞋、配饰——**遮罩盖到哪里，重建到哪里** | 站姿、体位与重心、四肢运动、脚掌落点、**身高与站位宽度**、与未遮罩人物的重叠顺序 | 参考图的背景、光照、其正面站立姿势（如手叉腰／蹲姿）、自身机位；**以及源视频里被遮罩盖住的全部外观**（旧帽、旧上衣、旧裤子——逐项 `are not carried over`） |
| 整个人物·**轮廓会变**时 | 同上，另需点明**袖型变化**（长袖→无袖／吊带） | 肩线与臂线仍随源人物，但**新服装的裸露部位要写成裸肤** | 源视频自身的旧服装形态（`the source figure's own long sleeves are not carried over; her shoulders and arms are bare`） |
| 服装／配饰 | 版型（领口／袖／腰线／肩线）、面料垂坠、颜色纹样、图样位置、五金缝线 | **身体姿态驱动的褶皱与摆动**、下摆袖口轨迹、腰带贴合、头发压在衣领上的层次 | 参考图的模特体型与姿势、平铺形态、影棚背景与平光 |
| 物体 | 形状、尺寸、主色纹路、材质与高光性质、附属细节（蒂／柄／Logo） | 位置朝向、手指包裹的接触点、接触阴影、位移轨迹与速度、深度顺序 | 参考图的背景、顶光、产品打光、完整未握持形态 |
| 物体·**无参考图**（纯文本） | **不建 `<Subject 2>`**，特征清单直接写进 `detailed_description`（形状、粗细、颜色、表面质感、端点形态、比例参照） | 同上；另加 `within the same footprint as the marked patch` | **源视频里的旧道具**：`no cigarette appears in the target video` |
| 场景／背景 | 建筑植被天际线、地面材质、大气能见度、色彩层次、景深分布 | 透视与视差、主体景深位置、镜头与画幅、前景遮挡层次 | 参考图的相机镜头、拍摄时间光照、其自身透视 |
| 画内文字／标识 | 文本逐字原文（不翻译）、字体字重、字号行距、颜色、留白 | 贴附表面的透视与角度、随表面运动的形变、被遮挡部分 | 参考图自身的背景、色温、透视 |
| 材质／表面 | 粗糙度、反射方式、纹理尺度与方向、污渍磨损 | 原物体形状、轮廓、位置、运动**全部不变** | 参考图的形状与体积 |
| 光照／影调 | 光源方向性质、色温、反差、高光滚降、肤色倾向 | 场景结构、表演、机位全部不变 | 参考图的画面内容（只用影调） |
| 移除（无参考） | —（不建 `<Subject 2>`） | 背景如何延伸、光影如何回填、原物投影如何消失、不留残影 | — |
| 新增（无源物） | 同「物体」 | 插入位置、与前后景的深度顺序、投射阴影与接触点 | 同「物体」 |

多目标：按首次出现顺序编号 `<Subject 2>`、`<Subject 3>`…，各自独立遮罩与锚点；同一目标跨镜头编号不变。**画面里人员众多时**：把最突出的未遮罩者单独编号并标 `fully_preserved`，其余（人群、制服、桌椅）在保留项里集体列出，不必逐人编号。

### 换人任务的归属判定（唯一判据：在不在遮罩内）

**先逐项问「这个元素在遮罩内吗？」，答案决定它属于谁**：

| 元素位置 | 归属 | 写法 |
|---|---|---|
| **遮罩内**（被绿／纯色遮罩盖住的：脸、发、帽、上衣、裤子……） | `<Subject 2>` 重建，源版本否定 | `<Subject 2>` 定义里按参考图写全新外观；`<Video 1>` 定义里声明源外观「mark the region to be rebuilt」；`retention_analysis` 里**不得出现在 `<Subject 1>` 的保留清单**；正文写 `are not carried over` 逐项点名 |
| **遮罩外**（露出的：手、鞋、脖颈以下、未遮配饰） | `<Subject 1>` 保留 | 进 `<Subject 1>` 定义与保留清单，`partially_preserved` |
| **动作与姿势**（无论遮罩内外） | `<Video 1>` 保留 | 全身动作五组 + 面部四组（人物类），逐项 `the same ... as in <Video 1>` |

**反例（真实翻车成稿，禁止复刻）**：遮罩盖住头到腰，成稿却在 `<Subject 1>` 保留「白色T恤、深绿棒球帽、浅色牛仔裤」，`summary` 写「她的白色短款T恤、带标志的棒球帽、牛仔裤保持不变」，`<Subject 2>` 只定义了「面部特征和上半身外观」——结果成片人物完全没换。**病根：把「被替换物」写成了「保留物」。** 正确写法对照：`<Subject 2>` 按参考图定义**完整外观**（含参考图自己的发型与服装），`<Video 1>` 定义里写「a flat green cap, a pale crop top and blue jeans ... mark the region to be rebuilt and are not part of the target video's visible content」，正文写 `the flat cap, the emblem on the cap, the pale crop top and the blue jeans in <Video 1> are not carried over`。

**保留标记相应写法**：`<Subject 1>` 的 `partially_preserved` 行只列「动作、姿势、体位、时序 + 遮罩外的身体部位」，**绝不列遮罩内的外观**；「外观被 `<Subject 2>` 替换」一句收尾。

### 只写可见事实（适用于所有类型）

**不猜目的**：意图、身份、剧情、画外因果一律不写。`she is singing along to a song` / `she is recording a vlog` / `she is thinking about her answer` 都是猜测；改成看得见的事实 `her brows lift and her mouth corners pull up into a closed-mouth smile`。场景同理，只写陈设与光线，不写「她在直播间」这类用途推断。有音轨但听不出内容时，只写 `her lips move and keep their exact shapes and timing from <Video 1>`，歌词台词不臆造。

### 可见行为复刻清单（人物类必填，四组缺一即漂移）

| 组 | 逐项内容 | 英文写法 |
|---|---|---|
| **表情** | 眉高与眉形、眼睑开合度、眼眶与嘴角松紧、唇形开合 | `the same facial expression, with the same brow height and angle, the same eyelid height and the same softness or tension around her eyes and the corners of her mouth` |
| **神态** | 面部整体状态的逐拍读感（舒展／戒备／被逗到／平静） | `the same demeanour as it reads on her face from moment to moment — how open, how guarded, how amused, how composed — shifting on exactly the same beats` |
| **眼神** | 视线落点与距离、漂移与回位、眨眼节奏与幅度 | `the same gaze, her eyes resting on the same point at the same distance with the same drift and return; the same blink rhythm` |
| **举止** | 头转／偏／点、肩与躯干摆动、手部动作、口型时序 | `the same visible behaviour, with the same head turns, tilts and nods, the same shoulder and torso sway, and the same lip shapes and mouth movement at the same moments` |

**收口句**：`Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.`
**遮罩盖住面部时**：可见表演被抹掉，不能靠猜补；只保留可取证部分（头姿／肩线／来自音轨的口型时序），其余交回参考素材，不写情绪形容词。

### 重建内容必须逐项对得上（不漏项、不加戏）

按六项抄清单，逐项落进 `{{REBUILD_SENTENCE}}`：① 形状与比例 ② 颜色与图样（主色须绑定名词）③ 材质与光学（粗糙度／高光性质）④ 附属细节（绶带／纽扣／Logo／缝线；**用户文字没提到就按参考图写，参考图也没有就不加**）⑤ 参考图的背景／棚光／产品投影逐项否掉 ⑥ 源物件的旧形制与附着标志也否掉（`no lettering or logo appears on the hat`）。判据：对照用户原话与参考图，出现「用户没要但写了」＝加戏，出现「用户要了但没写」＝漏项。

### 换人的四个易丢项（逐项检查，缺一项就出片）

1. **主体自己持有的道具**：香烟／酒杯／手机等被嘴或手夹住的东西若落在遮罩内，必须单列一句「保持同一角度、长度与位置，且新嘴唇仍闭合包住它」——漏写时模型会把道具一起重画或直接抹掉。遮挡句与道具句是两句，不可合并。
2. **画面外的身体部位**：参考图有鞋而源视频脚在画外时，写 `her feet stay below the bottom edge of the frame and out of view throughout`，否则模型会把画幅上移去补脚。
3. **未遮罩的入侵元素**：他人伸进画面、压在重建区前方的手／衣袖／麦克风，写 `keep their exact position, size, depth order and motion, and stay in front of her exactly as in <Video 1>`。漏写会被抹平进新人物。
4. **轮廓变化**：参考服装比源服装暴露（长袖→吊带、长裤→短裙）时，显式写裸肤部位，并在不迁移项里否定源服装形态。

### 遮罩是硬边矩形时必须写的一句（小物体／自动遮罩常见）

手绘或自动生成的遮罩常是一个**矩形**，且覆盖范围大于目标物体（例：24×41 px 的方框同时压住香烟、嘴角与部分下颌皮肤）。此时重建包含两件事：**目标就位 + 被遮的周边表面复原**。必须写：

`The patch's straight edges do not survive anywhere in the target video; the rebuilt area blends into her face with no seam and no colour break.`

漏写会被原样保留一个矩形色块边界，这是小物体替换最典型的翻车形态。同时用中性指代 `the marked patch` 指它，不要反复写颜色词。

## 四、六个模块（骨架的固定拼装件）

| 模块 | 换脸 | 换物体 | 换服装 |
|---|---|---|---|
| `{{REBUILD_SENTENCE}}` | `Her face is rebuilt with the identity of <Subject 2>: <清单>, following the head angle, tilt, and hairline already present in the source.` | `The object in her grip is rebuilt as <Subject 2>: <清单>, following the orientation, stem direction, and position in her grip already present in the source.` | `The garment is rebuilt as <Subject 2>: <版型面料清单>, following the body's rotation and the drape already present in the source.` |
| `{{LIGHT_CLAUSE}}` | `read as one continuous skin tone rather than the reference image's cool studio light` | `takes the warm lamplight from the left rather than the reference image's overhead product light` | `catches the room's warm light from above, with folds shading the same way as the fabric already in the source` |
| `{{SYNC_CLAUSE}}` | 表演：先放 `{{PERFORMANCE_CLAUSE}}`（四组可见行为，见下），再接 `and continues unchanged from her performance in <Video 1>` | 位移：`position, orientation, silhouette, velocity, and motion path continue unchanged from <Video 1>; it neither accelerates nor slows down after the replacement` | 随体：`fit, folds, sway, and hem movement follow her body motion exactly as the garment in <Video 1> does` |
| `{{PERFORMANCE_CLAUSE}}` | **人物类必填**：表情 + 神态 + 眼神 + 举止四组全写，四组见「可见行为复刻清单」 | — | — |
| `{{NO_ADDED_EVENT}}` | 收口句：`Nothing that is not visible in <Video 1> is added: no new action, no new intention and no new event appears in the target video.` | 同左 | 同左 |
| `{{OCCLUSION_SENTENCE}}` | 发丝与耳饰压脸保持原位 | 手指在物体之前、拇指同面、接触阴影同处、被遮部分仍不可见 | 头发在衣领之前、手在原口袋位置、布料在其周围起皱 |
| `{{FIT_CLAUSE}}` | 肤色衔接读作同一肤色 | **尺寸规则默认 R1**：`sized to fill the same space in her hand as the object in <Video 1>` | `follows her body pose and proportions rather than the reference's flat-lay or model pose` |
| `{{SEAM_AND_EXCLUDE}}` | 发际线／下颌线无接缝 | 手指周边未遮像素无接缝 | 领口／袖口／下摆无接缝 |

**尺寸冲突三规则**：R1 保持占位（默认，抓握与遮挡全自洽）｜R2 忠于参考尺寸（须改写接触关系，承认手部姿态被调整）｜R3 折中（`allowed to extend beyond the source footprint by up to about half its width`）。
**服装方向相反且最易错**：必须是身体驱动衣服，不能让衣服保持参考图的平铺／模特姿态。

## 五、占位符骨架

见工作区 `outputs/H3替换编辑-通用模板-占位符版.txt`（骨架同下）。移除类：删 `<Subject 2>` 两行、任务类型去掉 `reference generation`、`{{REBUILD_SENTENCE}}` 改空缺回填句。无音轨：删 `<Audio 1>` 行与 `{{AUDIO_TASK}}` / `{{AUDIO_REASON_EXTRA}}`，`{{SOUNDSCAPE}}` 补 `; no dialogue and no on-screen speech`。

## 六、成稿

- 通用模板（含类型速查、六模块对照、三个填好示例、校验清单）：`outputs/H3替换编辑-通用模板.md`
- 占位符版：`outputs/H3替换编辑-通用模板-占位符版.txt`
