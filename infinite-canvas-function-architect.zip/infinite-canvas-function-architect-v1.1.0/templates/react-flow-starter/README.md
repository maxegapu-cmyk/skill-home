# React Flow starter

Install:

```bash
npm install @xyflow/react
```

This starter intentionally keeps layout out of `App.tsx`. The canonical model should not become coupled to a renderer.

Add Dagre or ELK in `layout.ts` only when auto-layout is required.
