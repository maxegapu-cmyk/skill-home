# Infinite Canvas Function Architect v1.1.0

A clean-room Skill for turning messy requirements into a structured infinite canvas and functional architecture map.

## What it does

This package is built around one idea: a useful infinite canvas is not “boxes on a huge surface.” It is a **graph-backed product model** with a visual editor on top.

The skill can:

- extract atomic capabilities from rough notes
- separate goals, actors, modules, features, flows, data, integrations, constraints, risks, and decisions
- cluster features by functional ownership
- build typed relationships
- surface missing prerequisites and failure paths
- detect orphans, duplicates, cycles, ownership overlap, and hidden data gaps
- create an MVP boundary without flattening the whole roadmap
- render a portable, dependency-free HTML canvas or guide a React Flow implementation
- preserve stable node IDs across iterations
- export/import one canonical JSON model


## Reliability hardening in v1.1.0

This release was stress-tested as a real artifact rather than only reviewed as prompt text. It includes:

- crash-safe validation for malformed JSON-shaped data
- iterative dependency-cycle detection that does not blow Python recursion on long chains
- transactional import: bad files do not replace the current canvas
- real Chromium drag/zoom/search/import/export smoke tests
- viewport culling and semantic zoom for larger maps
- indexed node lookup and incident-edge-only updates during drag
- unbounded world coordinates instead of a fixed-size fake "infinite" surface
- an optional strict validator gate for CI/release use

See `PRESSURE_TEST.md` for the exact failures found, fixes applied, test sizes, measured release-environment timings, and remaining limits.

### Release verification

```bash
python scripts/validate_canvas.py examples/saas-feature-map.canvas.json
python scripts/validate_canvas.py --strict examples/saas-feature-map.canvas.json
pytest -q
python tests/browser_smoke.py   # optional: requires Playwright + Chromium
```

The portable HTML lane is intentionally dependency-free. For very large production graphs, treat the 10k browser probe as headroom evidence, not an unlimited-scale guarantee. Complex custom cards, images, animation, or thousands of simultaneously visible nodes can require a framework/virtualized renderer.

## Package layout

- `SKILL.md` — main behavior contract
- `schema/canvas-model.schema.json` — canonical model schema
- `scripts/validate_canvas.py` — no-dependency structural validator
- `templates/infinite-canvas-standalone.html` — dependency-free interactive reference canvas
- `templates/react-flow-starter/` — small React Flow starter pattern
- `examples/saas-feature-map.canvas.json` — valid example model
- `tests/` — validator regression tests
- `references/` — deeper design and QA rules
- `research/OPEN_SOURCE_NOTES.md` — public-source research notes and license cautions

## Fastest use

Give an agent this package plus raw notes and ask:

> Use Infinite Canvas Function Architect. Turn these notes into a canonical function model, diagnose gaps, and generate a single-file infinite canvas I can open locally. Preserve uncertainty instead of inventing missing requirements.

## Recommended implementation choice

- Reviewable / shareable map: single-file HTML.
- Product feature graph or workflow editor: React Flow.
- Freehand whiteboard: Excalidraw.
- Executable typed-node workflow: Rete.js.

See `research/OPEN_SOURCE_NOTES.md` before selecting third-party SDKs for production.
