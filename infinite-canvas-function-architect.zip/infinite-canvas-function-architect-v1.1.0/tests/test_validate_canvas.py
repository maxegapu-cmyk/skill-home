import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = ROOT / "scripts" / "validate_canvas.py"
EXAMPLE = ROOT / "examples" / "saas-feature-map.canvas.json"


def run(path: Path, *extra: str):
    return subprocess.run([sys.executable, str(VALIDATOR), *extra, str(path)], capture_output=True, text=True)


def write_temp(data):
    td = tempfile.TemporaryDirectory()
    p = Path(td.name) / "case.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return td, p


def base():
    return json.loads(EXAMPLE.read_text(encoding="utf-8"))


def test_valid_example_passes():
    result = run(EXAMPLE)
    assert result.returncode == 0, result.stdout + result.stderr


def test_missing_edge_target_fails():
    data = base()
    data["edges"][0]["target"] = "missing-node"
    td, p = write_temp(data)
    try:
        result = run(p)
        assert result.returncode == 1
        assert "missing target node" in result.stdout
        assert "Traceback" not in result.stdout + result.stderr
    finally:
        td.cleanup()


def test_non_object_root_is_reported_without_traceback():
    td, p = write_temp([])
    try:
        result = run(p)
        assert result.returncode == 1
        assert "root must be a JSON object" in result.stdout
        assert "Traceback" not in result.stdout + result.stderr
    finally:
        td.cleanup()


def test_wrong_nodes_type_is_reported_without_traceback():
    data = base(); data["nodes"] = "not-an-array"
    td, p = write_temp(data)
    try:
        result = run(p)
        assert result.returncode == 1
        assert "nodes must be an array" in result.stdout
        assert "Traceback" not in result.stdout + result.stderr
    finally:
        td.cleanup()


def test_feature_missing_id_is_reported_without_traceback():
    data = base(); data["nodes"].append({"type":"feature","title":"x","summary":"","position":{"x":0,"y":0}})
    td, p = write_temp(data)
    try:
        result = run(p)
        assert result.returncode == 1
        assert "id must match" in result.stdout
        assert "Traceback" not in result.stdout + result.stderr
    finally:
        td.cleanup()


def test_long_requires_chain_does_not_hit_recursion_limit():
    n = 3000
    data = {
        "schema_version":"1.0","title":"Long chain","nodes":[],"edges":[],"groups":[],
        "camera":{"x":0,"y":0,"scale":1},"meta":{"created_at":"","updated_at":""}
    }
    data["nodes"].append({"id":"m","type":"module","title":"Module","summary":"","position":{"x":0,"y":0}})
    for i in range(n):
        data["nodes"].append({"id":f"n{i}","type":"feature","title":f"F{i}","summary":"","position":{"x":i*10,"y":0},"module_id":"m","acceptance":["ok"]})
    for i in range(n-1):
        data["edges"].append({"id":f"e{i}","type":"requires","source":f"n{i}","target":f"n{i+1}"})
    td, p = write_temp(data)
    try:
        result = run(p)
        assert result.returncode == 0, result.stdout + result.stderr
        assert "RecursionError" not in result.stdout + result.stderr
    finally:
        td.cleanup()


def test_requires_cycle_is_warning_not_crash():
    data = base()
    data["nodes"].extend([
        {"id":"fa","type":"feature","title":"A","summary":"","position":{"x":0,"y":0},"module_id":"mod_content","acceptance":["ok"]},
        {"id":"fb","type":"feature","title":"B","summary":"","position":{"x":0,"y":0},"module_id":"mod_content","acceptance":["ok"]},
    ])
    data["edges"].extend([
        {"id":"cycle.a","type":"requires","source":"fa","target":"fb"},
        {"id":"cycle.b","type":"requires","source":"fb","target":"fa"},
    ])
    td, p = write_temp(data)
    try:
        result = run(p)
        assert result.returncode == 0
        assert "requires cycle:" in result.stdout
    finally:
        td.cleanup()


def test_strict_mode_fails_on_warnings():
    data = base()
    data["nodes"].append({"id":"orphan","type":"risk","title":"Loose risk","summary":"","position":{"x":0,"y":0}})
    td, p = write_temp(data)
    try:
        result = run(p, "--strict")
        assert result.returncode == 1
        assert "FAIL-STRICT" in result.stdout
    finally:
        td.cleanup()


def test_duplicate_json_key_is_rejected_during_load():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "dup.json"
        p.write_text('{"schema_version":"1.0","title":"x","title":"y","nodes":[],"edges":[],"groups":[],"camera":{"x":0,"y":0,"scale":1},"meta":{"created_at":"","updated_at":""}}', encoding="utf-8")
        result = run(p)
        assert result.returncode == 2
        assert "duplicate JSON object key" in result.stdout


def test_non_finite_json_number_is_rejected_during_load():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "nan.json"
        p.write_text('{"schema_version":"1.0","title":"x","nodes":[],"edges":[],"groups":[],"camera":{"x":NaN,"y":0,"scale":1},"meta":{"created_at":"","updated_at":""}}', encoding="utf-8")
        result = run(p)
        assert result.returncode == 2
        assert "non-finite JSON number" in result.stdout


def test_bad_camera_is_structural_error():
    data = base(); data["camera"]["scale"] = 0
    td, p = write_temp(data)
    try:
        result = run(p)
        assert result.returncode == 1
        assert "camera.scale must be > 0" in result.stdout
    finally:
        td.cleanup()
