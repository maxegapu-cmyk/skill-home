#!/usr/bin/env python3
# coding: utf-8
"""选题洞察工作台：stdlib-only 本地记录、硬门槛、渐进写作；不自动联网、不调用模型。"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import pathlib
import re
import sys

DB_NAME = 'topic_project.json'
VALID_KINDS = {'firsthand', 'public', 'hypothesis'}
SECTIONS = ('opening', 'evidence', 'reasoning', 'counterargument', 'ending')
LABELS = {
    'opening': '开场：让目标读者看见自己的真实处境',
    'evidence': '事实与案例：按证据强度展开',
    'reasoning': '分析：为什么出现这个问题',
    'counterargument': '反方：最强异议、边界与修正',
    'ending': '结尾：给读者一个可执行判断',
}


def date_now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def project_path(directory):
    return pathlib.Path(directory).expanduser().resolve()


def load(directory):
    path = project_path(directory) / DB_NAME
    if not path.is_file():
        raise ValueError(f'未找到项目：{path}，请先运行 init。')
    obj = json.loads(path.read_text(encoding='utf-8'))
    if obj.get('schema') != 1 or not isinstance(obj.get('candidates'), list):
        raise ValueError('项目文件版本或结构不支持（需要 schema=1）。')
    return obj


def save(directory, obj):
    directory = project_path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / DB_NAME
    tmp = target.with_name(target.name + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(target)


def log(obj, verb, details=''):
    obj.setdefault('history', []).append({'at_utc': date_now(), 'action': verb, 'details': details})


def candidate(obj, ident):
    for cand in obj['candidates']:
        if cand['id'] == ident:
            return cand
    raise ValueError(f'没有候选 {ident}。先运行 candidate 创建。')


def checks(obj, c):
    problems = []
    spec = [('name', '候选题目'), ('reader', '具体读者'), ('problem', '真实痛点'),
            ('claim', '可争辩的中心判断'), ('mechanism', '为什么成立的因果机制'),
            ('objection', '最强反方观点'), ('value', '看完后读者能获得什么')]
    for key, label in spec:
        if not str(c.get(key, '')).strip():
            problems.append(f'缺少{label}')
    if len(str(c.get('claim', '')).strip()) < 12:
        problems.append('观点太短/模糊：写出有边界的完整判断（≥12字）')
    if not obj.get('audience', '').strip():
        problems.append('项目未定义目标受众')
    if not obj.get('platform', '').strip():
        problems.append('项目未定义发布平台')
    if not obj.get('goal', '').strip():
        problems.append('项目未定义目标行为')
    refs = c.get('signal_ids', [])
    by_id = {s['id']: s for s in obj.get('signals', [])}
    actual_refs = [by_id[n] for n in refs if n in by_id]
    if not actual_refs:
        problems.append('无受众信号或一手证据：先添加 signal 再用 --signals 关联')
    elif not any(s['kind'] in ('firsthand', 'public') for s in actual_refs):
        problems.append('仅有“待验证猜测”证据，不允许当作已验证洞察')
    # Public evidence needs traceable provenance. Firsthand must name what was observed.
    for s in actual_refs:
        if s['kind'] == 'public' and not s['source'].strip():
            problems.append(f'{s["id"]} 是公开信号但没有可核查来源/链接')
        if s['kind'] == 'firsthand' and not s['source'].strip():
            problems.append(f'{s["id"]} 是一手体验但没有留观察记录/场景说明（--source）')
        if len(s['text'].strip()) < 8:
            problems.append(f'{s["id"]} 信号描述过短，无法判断实际含义')
    if not c.get('uncertainty', '').strip():
        problems.append('未写清哪些条件下观点不成立/尚未验证')
    return list(dict.fromkeys(problems))


def md_escape(s):
    return str(s or '').replace('|', '\\|').replace('\n', ' ')


def review_text(obj, cand):
    related = {s['id']: s for s in obj['signals']}
    problems = checks(obj, cand)
    lines = [f'# 选题评审：{cand["name"]}', '',
             f'生成时间（UTC）：{date_now()}', '',
             '## 受众定位',
             f'- 平台：{obj["platform"] or "待确定"}',
             f'- 账号定位：{obj["identity"] or "待确定"}',
             f'- 目标受众：{obj["audience"] or "待确定"}',
             f'- 内容目标：{obj["goal"] or "待确定"}',
             f'- 本题核心读者：{cand["reader"] or "待确定"}', '',
             '## 选题靶心（不是一个泛话题）',
             f'- 名称：{cand["name"]}',
             f'- 痛点：{cand["problem"]}',
             f'- 判断：{cand["claim"]}',
             f'- 因果解释：{cand["mechanism"]}',
             f'- 反方最强异议：{cand["objection"]}',
             f'- 观点边界/不确定性：{cand["uncertainty"]}',
             f'- 内容新价值：{cand["value"]}', '',
             '## 可回溯的读者信号与证据',
             '| ID | 类型 | 观察/原话摘要 | 来源 | 日期 |',
             '|---|---|---|---|---|']
    for sid in cand['signal_ids']:
        s = related.get(sid)
        if s:
            lines.append(f'| {sid} | {s["kind"]} | {md_escape(s["text"])} | {md_escape(s["source"])} | {md_escape(s["date"])} |')
    if not cand['signal_ids']:
        lines.append('| — | — | 未关联任何真实信号 | — | — |')
    lines += ['', '## 硬门槛', '通过（只表示字段与可追溯性满足最低要求，不等于判断已被外部验证）。' if not problems else '未通过：', '']
    if problems:
        lines += [f'- [ ] {p}' for p in problems]
    else:
        lines += ['- [x] 具体受众、痛点、中心判断、因果、反例、边界与可追溯信号齐备']
    lines += ['', '## 对抗性讨论（由人或模型回答，禁止凭空杜撰）',
              '1. 如果读者拒绝你这个观点，他最有力的事实是什么？',
              '2. 这句话能被什么反例推翻？你是否愿意据此缩窄结论？',
              '3. 是普遍问题，还是少数极端评论？样本如何偏倚？',
              '4. 热度过去，读者为什么还要收藏、转发或行动？',
              '5. 若删掉所有夸张词，这篇内容还剩哪条独到的信息？',
              '6. 这一观点与你的账号经验与可提供的证据匹配吗？', '',
              '## 人工决策',
              '- [ ] 我确认核心受众与观点边界',
              '- [ ] 我确认至少一个可追溯信号，不把推断写成事实',
              '- [ ] 我已讨论最强反对意见',
              '- [ ] 我决定进入写作（如否，继续讨论/缩窄题目）', '']
    return '\n'.join(lines)


def cmd_init(args):
    path = project_path(args.dir)
    if (path / DB_NAME).exists() and not args.force:
        raise ValueError(f'项目已存在：{path}；拒绝覆盖。')
    obj = {'schema': 1, 'platform': args.platform or '', 'audience': args.audience or '',
           'identity': args.identity or '', 'goal': args.goal or '',
           'signals': [], 'candidates': [], 'locked': None, 'history': []}
    log(obj, 'init', '初始化项目（未知项保持空白）')
    save(path, obj)
    print(f'建立项目：{path}\n下一步：signal 收集原话/案例；candidate 提炼具体选题；review 讨论；lock 确认后才写作。')


def cmd_signal(args):
    obj = load(args.dir)
    sid = f'S{1 + max((int(x["id"][1:]) for x in obj["signals"]), default=0):03}'
    record = {'id': sid, 'kind': args.kind, 'text': args.text.strip(),
              'source': (args.source or '').strip(), 'date': (args.date or '').strip()}
    if record['kind'] == 'public' and not record['source']:
        raise ValueError('public 类型必须传 --source 可核查URL、书目或材料位置。')
    if len(record['text']) < 8:
        raise ValueError('signal 太短，请写明原话或观察场景（至少8字符）。')
    obj['signals'].append(record)
    log(obj, 'signal', sid)
    save(args.dir, obj)
    print(f'已登记 {sid} [{record["kind"]}]；注意：信号不是总体统计结论。')


def cmd_candidate(args):
    obj = load(args.dir)
    ids = [x.strip() for x in args.signals.split(',') if x.strip()]
    known = {x['id'] for x in obj['signals']}
    unknown = set(ids) - known
    if unknown:
        raise ValueError(f'未知 signal ID：{sorted(unknown)}')
    cid = f'T{1 + max((int(x["id"][1:]) for x in obj["candidates"]), default=0):03}'
    record = {'id': cid, 'name': args.name.strip(), 'reader': args.reader or '',
              'problem': args.problem or '', 'claim': args.claim or '',
              'mechanism': args.mechanism or '', 'objection': args.objection or '',
              'uncertainty': args.uncertainty or '', 'value': args.value or '', 'signal_ids': ids}
    obj['candidates'].append(record)
    log(obj, 'candidate', cid)
    save(args.dir, obj)
    print(f'已创建 {cid}。下一步：python scripts/topic_lab.py review --dir "{args.dir}" --id {cid}')


def cmd_review(args):
    obj = load(args.dir)
    c = candidate(obj, args.id)
    report = review_text(obj, c)
    dest = project_path(args.dir) / f'{args.id}_选题评审.md'
    dest.write_text(report + '\n', encoding='utf-8')
    print(report)
    print(f'\n本地报告：{dest}')


def cmd_status(args):
    obj = load(args.dir)
    print(f'平台：{obj["platform"] or "未填"}；受众：{obj["audience"] or "未填"}；目标：{obj["goal"] or "未填"}')
    print(f'信号：{len(obj["signals"])}；候选：{len(obj["candidates"])}；已锁定：{obj["locked"] or "无"}')
    for c in obj['candidates']:
        problems = checks(obj, c)
        print(f'  {c["id"]}: {c["name"]} | {"基础门槛满足" if not problems else f"待补{len(problems)}项"}')
    if not obj['candidates']:
        print('下一步：添加 signal，再创建 candidate。')


def cmd_lock(args):
    obj = load(args.dir)
    c = candidate(obj, args.id)
    missing = checks(obj, c)
    if missing:
        raise ValueError('不能锁定：\n- ' + '\n- '.join(missing))
    if args.confirm != '我已讨论并确认':
        raise ValueError('需要真人主动确认：加 --confirm "我已讨论并确认"；CLI无法代替真实讨论。')
    obj['locked'] = c['id']
    log(obj, 'lock', f'{c["id"]} (人工确认声明，非真实性认证)')
    save(args.dir, obj)
    print(f'已锁定 {c["id"]}：现在可 outline。此锁定不代表论证内容自动属实。')


def cmd_reopen(args):
    obj = load(args.dir)
    last = obj.get('locked')
    if not last:
        print('当前没有锁定选题。')
        return
    obj['locked'] = None
    log(obj, 'reopen', last)
    save(args.dir, obj)
    print(f'已解锁 {last}。保留旧大纲与草稿，但它们不再被视为当前选题版本。')


def cmd_outline(args):
    obj = load(args.dir)
    if not obj.get('locked'):
        raise ValueError('写作已被锁：先补证据、review 并 lock，不允许跨过选题讨论。')
    c = candidate(obj, obj['locked'])
    if checks(obj, c):
        raise ValueError('锁定后项目内容已不满足硬门槛，先修复或重新锁定。')
    out = project_path(args.dir) / f'{c["id"]}_写作骨架.md'
    if out.exists() and not args.force:
        raise ValueError(f'已有大纲 {out}；拒绝覆盖（除非 --force）。')
    contents = [f'# {c["name"]}', '', f'选题锁定ID：{c["id"]}',
                f'明确读者：{c["reader"]}', f'中心观点：{c["claim"]}',
                f'可信边界：{c["uncertainty"]}', '',
                '写法：逐段写，开场必须让目标读者识别情境；论证必须基于可追溯材料；禁止把抽样评论写成全体用户。', '']
    for key in SECTIONS:
        contents += [f'## {LABELS[key]}', f'<!-- TODO: {key}。先列这一节唯一要证明的论点；添加证据ID；必要时承认不确定性。 -->', '']
    out.write_text('\n'.join(contents), encoding='utf-8')
    log(obj, 'outline', c['id'])
    save(args.dir, obj)
    print(f'已生成 {out}\n先写 opening+evidence 核对事实，再写 reasoning、counterargument，最后写 ending。')


def cmd_audit(args):
    obj = load(args.dir)
    if not obj.get('locked'):
        raise ValueError('尚未锁定选题，无法做写作验收。')
    c = candidate(obj, obj['locked'])
    path = project_path(args.dir) / f'{c["id"]}_写作骨架.md'
    if not path.exists():
        raise ValueError('先运行 outline 生成大纲。')
    data = path.read_text(encoding='utf-8')
    issues = []
    for key in SECTIONS:
        if f'## {LABELS[key]}' not in data:
            issues.append(f'缺少章节：{key}')
        if f'<!-- TODO: {key}' in data:
            issues.append(f'章节仍未填写：{key}')
    if c['claim'] not in data:
        issues.append('中心观点被删改，请核对它与最终正文是否一致')
    if re.search(r'(100%|百分之百|所有人都|人人都)', data):
        issues.append('检测到绝对化表述：需人工核实是否有充分证据')
    if issues:
        print('结构审查未通过 / 需人工复核：\n- ' + '\n- '.join(issues))
    else:
        print('结构门槛通过；注意：本工具不验证文章事实、原创性、平台合规或传播效果，必须人工终审。')
    print('人工检查：来源真伪与日期、样本偏差、反例、平台措辞、标题是否兑现、素材版权。')
    return 0 if not issues else 3


def cmd_refine(args):
    obj = load(args.dir)
    c = candidate(obj, args.id)
    allowed = ('name', 'reader', 'problem', 'claim', 'mechanism', 'objection', 'uncertainty', 'value')
    if args.field not in allowed:
        raise ValueError(f'只允许修改：{", ".join(allowed)}')
    if not args.text.strip():
        raise ValueError('不能把字段改为空白。')
    old = c[args.field]
    c[args.field] = args.text.strip()
    if obj.get('locked') == c['id']:
        obj['locked'] = None
        log(obj, 'automatic_reopen', f'{c["id"]} 的 {args.field} 已改变')
    log(obj, 'refine', f'{c["id"]}.{args.field}: {old[:90]} → {args.text[:90]}')
    save(args.dir, obj)
    print(f'已更新 {c["id"]}.{args.field}。如改动发生在锁题后，已自动解锁，需要重新 review/lock。')


def cmd_attach(args):
    obj = load(args.dir)
    c = candidate(obj, args.id)
    known = {s['id'] for s in obj['signals']}
    ids = [x.strip() for x in args.signals.split(',') if x.strip()]
    bad = set(ids) - known
    if bad:
        raise ValueError(f'未知信号：{sorted(bad)}')
    if args.mode == 'add':
        c['signal_ids'] = list(dict.fromkeys(c['signal_ids'] + ids))
    else:
        c['signal_ids'] = [x for x in c['signal_ids'] if x not in ids]
    if obj.get('locked') == c['id']:
        obj['locked'] = None
        log(obj, 'automatic_reopen', f'{c["id"]} 信号变动')
    log(obj, 'attach', f'{args.id} {args.mode}: {ids}')
    save(args.dir, obj)
    print(f'{args.id} 已关联信号 {c["signal_ids"]}；如原先已锁题，现需重新确认。')


def cmd_profile(args):
    obj = load(args.dir)
    values = {'platform': args.platform, 'audience': args.audience, 'identity': args.identity, 'goal': args.goal}
    changes = {key: value for key, value in values.items() if value is not None}
    if not changes:
        raise ValueError('请至少指定 --platform、--audience、--identity、--goal 之一。')
    for key, value in changes.items():
        if not value.strip():
            raise ValueError(f'{key} 不能为空')
        obj[key] = value.strip()
    if obj.get('locked'):
        obj['locked'] = None
        log(obj, 'automatic_reopen', '项目画像变动')
    log(obj, 'profile', ', '.join(changes))
    save(args.dir, obj)
    print('项目画像已更新；已锁题时自动解锁以避免使用过期结论。')


def build_parser():
    parser = argparse.ArgumentParser(description='精确选题 → 观点辩论 → 人工锁题 → 逐步写文（离线、本地、零依赖）')
    sub = parser.add_subparsers(dest='command', required=True)
    def add_dir(p):
        p.add_argument('--dir', default='./my-topic', help='项目文件夹，默认 ./my-topic')
    p = sub.add_parser('init', help='建立项目')
    add_dir(p)
    for key in ('platform', 'audience', 'identity', 'goal'):
        p.add_argument(f'--{key}', default='')
    p.add_argument('--force', action='store_true', help='明确覆盖现有项目（会重置记录）')
    p.set_defaults(run=cmd_init)
    p = sub.add_parser('signal', help='登记受众原话/案例，手动输入可信来源')
    add_dir(p)
    p.add_argument('--text', required=True)
    p.add_argument('--kind', choices=sorted(VALID_KINDS), required=True, help='firsthand=一手观察，public=可查公开材料，hypothesis=猜测')
    p.add_argument('--source', default='')
    p.add_argument('--date', default='')
    p.set_defaults(run=cmd_signal)
    p = sub.add_parser('candidate', help='建立具体候选选题，字段可逐项完善前先写在文本中')
    add_dir(p)
    p.add_argument('--name', required=True)
    for key in ('reader', 'problem', 'claim', 'mechanism', 'objection', 'uncertainty', 'value'):
        p.add_argument(f'--{key}', default='')
    p.add_argument('--signals', default='', help='关联ID，以逗号分隔，例如 S001,S003')
    p.set_defaults(run=cmd_candidate)
    p = sub.add_parser('refine', help='讨论后逐项修改候选选题')
    add_dir(p)
    p.add_argument('--id', required=True)
    p.add_argument('--field', required=True, choices=('name', 'reader', 'problem', 'claim', 'mechanism', 'objection', 'uncertainty', 'value'))
    p.add_argument('--text', required=True)
    p.set_defaults(run=cmd_refine)
    p = sub.add_parser('attach', help='把新发现的读者信号关联到候选题')
    add_dir(p)
    p.add_argument('--id', required=True)
    p.add_argument('--signals', required=True)
    p.add_argument('--mode', choices=('add', 'remove'), default='add')
    p.set_defaults(run=cmd_attach)
    p = sub.add_parser('profile', help='修改账号和受众定位；修改后解锁旧题')
    add_dir(p)
    for key in ('platform', 'audience', 'identity', 'goal'):
        p.add_argument(f'--{key}', default=None)
    p.set_defaults(run=cmd_profile)
    p = sub.add_parser('review', help='输出选题分析与反方辩论清单')
    add_dir(p)
    p.add_argument('--id', required=True)
    p.set_defaults(run=cmd_review)
    p = sub.add_parser('status', help='查看阶段和门槛')
    add_dir(p)
    p.set_defaults(run=cmd_status)
    p = sub.add_parser('lock', help='确认方向并允许进入写作')
    add_dir(p)
    p.add_argument('--id', required=True)
    p.add_argument('--confirm', default='')
    p.set_defaults(run=cmd_lock)
    p = sub.add_parser('reopen', help='解锁重新选题，不删除历史')
    add_dir(p)
    p.set_defaults(run=cmd_reopen)
    p = sub.add_parser('outline', help='已锁题时建立分段写作骨架')
    add_dir(p)
    p.add_argument('--force', action='store_true')
    p.set_defaults(run=cmd_outline)
    p = sub.add_parser('audit', help='写作骨架静态审查（非事实核查）')
    add_dir(p)
    p.set_defaults(run=cmd_audit)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        ret = args.run(args)
        return ret if isinstance(ret, int) else 0
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f'错误：{exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
