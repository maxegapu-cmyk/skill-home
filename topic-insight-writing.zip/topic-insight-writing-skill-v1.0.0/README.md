# 精准选题·观点洞察·渐进写作 Skill v1.0.0

**一句话用途：先把“我想聊某件事”讨论成有受众、有证据、有明确判断的具体选题，再写文章/视频，而不是先写一堆标题。**

## 1. 最简单：直接在 ChatGPT / Claude / Codex 使用

解压整个文件夹。把 `SKILL.md` 作为技能说明加载给支持 Skill 的助手，或把 `SKILL.md` 发给 AI 直接阅读并执行。在对话里说：

> 请按“精准选题·观点洞察”技能工作。领域是【】，平台是【】，想影响的人是【】。我有一个模糊想法：【】。先帮我提炼真正值得做的1—3个具体选题，重点挖洞察、把观点讲清楚，跟我讨论确认后再开始写文，不要先替我写完整稿。

不需要购买任何 API，也不需要先运行 Python。**只想聊天选题的用户，到此即可。**

在 Claude Code/Codex 等支持目录型 Skills 的环境，可按其当前版本的官方安装指引，将此整个目录放进个人/项目 Skills 位置。此 ZIP 是标准文本型 Skill，不是任何模型官方预装的插件，也不宣称上传 ZIP 就会自动安装。

## 2. 需要本地追踪时：零依赖 Python 工作台

准备 Python 3.9+。打开终端进入解压文件夹，运行：

```bash
python scripts/topic_lab.py --help
```

Windows 如果 `python` 不存在，尝试 `py -3 scripts/topic_lab.py --help`；macOS/Linux 通常是 `python3`。所有命令通过 `--dir` 选择**自己的**本地项目文件夹，不向网络发送信息。

### 可直接复制的完整示范（材料全为虚构案例，仅展示操作）

```bash
python scripts/topic_lab.py init --dir ./demo-topic --platform "B站" --audience "初次学习AI视频的普通创作者" --identity "AI实战记录" --goal "让用户收藏验证清单"

python scripts/topic_lab.py signal --dir ./demo-topic --kind firsthand --text "在个人演示中，按某教程步骤操作后缺少关键输入文件导致失败；这是单次观察，不代表所有教程" --source "演示笔记，案例A" --date "示例日期"

python scripts/topic_lab.py candidate --dir ./demo-topic --name "为什么照着AI视频教程操作还是做不出来" --reader "复制教程却卡住的新手" --problem "缺少关键输入素材与排错步骤" --claim "一些教程的最大障碍并非工具复杂，而是缺少可复现的输入条件和失败处置" --mechanism "演示只展示成功画面，没有将版本、素材条件、报错出口交付给读者" --objection "有的教程已经给出完整素材，学习者也可能跳过关键步骤" --uncertainty "只适用于能找到缺失信息的具体教程，不能推断所有教程都这样" --value "学会判断一个教程能否被复现" --signals S001

python scripts/topic_lab.py review --dir ./demo-topic --id T001
```

**上一步只是机器生成讨论表，必须由真人真正讨论/确认后，才能执行下一条**：

```bash
python scripts/topic_lab.py lock --dir ./demo-topic --id T001 --confirm "我已讨论并确认"
python scripts/topic_lab.py outline --dir ./demo-topic
```

然后在 `demo-topic/T001_写作骨架.md` 中按节写，不必一次写完。最后运行：

```bash
python scripts/topic_lab.py audit --dir ./demo-topic
```

提示：`audit` 检查章节完整、占位符、少量绝对化措辞，**并不验证观点真实性、来源版权或成稿质量**。真正的内容核查请让助手结合可核查资料逐条检查。

### 讨论时怎么改题？

```bash
python scripts/topic_lab.py refine --dir ./demo-topic --id T001 --field claim --text "对缺少完整操作条件的新手教程，决定复现率的往往不是演示效果，而是输入清单与排错说明"
python scripts/topic_lab.py attach --dir ./demo-topic --id T001 --signals S002 --mode add
python scripts/topic_lab.py review --dir ./demo-topic --id T001
python scripts/topic_lab.py status --dir ./demo-topic
```

`attach` 的 `S002` 需要先由 `signal` 创建。更换平台、受众用 `profile`。改题、改受众或关联新证据会自动解除原锁定，避免旧文章与新观点不一致。

## 3. 三个不同使用场景

**有想法但讲不出来**：输入你最原始的观点，可以带情绪。AI 先提炼事实/感受/判断/机制/行动，再提供一个精确观点供讨论。

**没选题灵感**：输入赛道、平台、读者、可用案例/问题。AI 从真实需求反向给 2—3 个具备证据计划的题，而不是空洞热榜。

**已有一个争议观点**：AI 先找最强反例、限制结论与证据缺口；能承受反驳才决定是否创作。

## 4. 常见错误

- “没有真实信号能不能直接锁题？”脚本默认禁止。可以记录 `hypothesis` 但不会把它当验证材料；补一手案例/公开材料，或在对话中明确保留为探索性假设。
- “为什么我改了一句观点又要锁？”这是为避免旧稿不再支持新结论；历史文件不删，可以再次确认。
- “运行了却没有自动写文章？”这不是联网自动写稿机。请把 `T001_写作骨架.md` 交给 AI，按 Skill 逐段讨论并写。
- “脚本似乎检查了我的文章？”只做静态结构检查，不把语义判断伪装成测试。真实来源、事实、观点质量必须审阅。
- “可以直接爬平台评论吗？”此包不内置爬虫，避免不稳定接口、权限和平台规则问题。外部工具应依法合规获取授权数据，并标注来源。

## 5. 隐私与边界

脚本只写入你指定的本地文件夹（JSON、选题卡、写作骨架），没有第三方服务、自动上传、自动评论或发布。不要将私信、联系方式、私人对话原文未经授权录入外发项目。建议脱敏、只保留必要引用。所有代码与提示词为本包独立实现；GitHub 项目仅作公开思路和可选工具参考，**没有内嵌或二次打包外部库源码**。

完整研究来源与适用边界见 `references/RESEARCH.md`，使用的全部命令 `python scripts/topic_lab.py --help`。
