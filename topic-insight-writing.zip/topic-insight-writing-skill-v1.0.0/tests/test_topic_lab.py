# coding: utf-8
"""From public CLI, with empty temporary project, no network or installed packages."""
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

CLI = pathlib.Path(__file__).resolve().parents[1] / 'scripts' / 'topic_lab.py'

class TopicLabCLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.project = pathlib.Path(self.temp.name) / '中文空格 选题'

    def runcli(self, *parts, status=0):
        r = subprocess.run([sys.executable, str(CLI), *parts], text=True, capture_output=True, encoding='utf-8')
        self.assertEqual(r.returncode, status, msg=f'args={parts} stdout={r.stdout} stderr={r.stderr}')
        return r

    def init(self):
        self.runcli('init', '--dir', str(self.project), '--platform', 'B站', '--audience', 'AI创作初学者',
                    '--goal', '让用户知道如何评价教程')

    def signal(self, kind='firsthand', source='复现录屏笔记'):
        self.runcli('signal', '--dir', str(self.project), '--kind', kind,
                    '--text', '观察到新手在操作过程中因为缺少素材包而无法复现步骤，尚未抽样', '--source', source)

    def candidate(self):
        self.runcli('candidate', '--dir', str(self.project), '--name', '为什么照着教程仍然会卡住',
                    '--reader', '操作屡次失败的普通新手', '--problem', '错误与缺失条件无法区分',
                    '--claim', '标榜可跟练的教程如果未交代输入条件，即使展示很漂亮也难以真正复现',
                    '--mechanism', '缺失素材或版本导致无法执行相同操作',
                    '--objection', '学习者自己也可能省略了关键步骤',
                    '--uncertainty', '只评价承诺教学复现的教程，不评价创意展示视频',
                    '--value', '下次选教程先查版本素材和排错说明', '--signals', 'S001')

    def test_missing_project_rejected(self):
        self.runcli('status', '--dir', str(self.project), status=2)

    def test_init_safe_no_implicit_overwrite(self):
        self.init()
        self.runcli('init', '--dir', str(self.project), status=2)
        self.assertIn('AI创作初学者', (self.project / 'topic_project.json').read_text(encoding='utf-8'))

    def test_public_source_required(self):
        self.init()
        self.runcli('signal', '--dir', str(self.project), '--kind', 'public',
                    '--text', '某公开访谈中出现了无法复现的描述，但是目前还没有取得原地址', status=2)
        self.assertFalse(json.loads((self.project / 'topic_project.json').read_text(encoding='utf-8'))['signals'])

    def test_only_hypothesis_must_not_lock(self):
        self.init()
        self.signal('hypothesis', '个人猜测')
        self.candidate()
        r = self.runcli('lock', '--dir', str(self.project), '--id', 'T001',
                        '--confirm', '我已讨论并确认', status=2)
        self.assertIn('待验证猜测', r.stderr)

    def test_hard_gate_no_premature_outline(self):
        self.init()
        self.signal()
        self.candidate()
        self.runcli('outline', '--dir', str(self.project), status=2)
        self.runcli('lock', '--dir', str(self.project), '--id', 'T001', status=2)
        self.assertFalse((self.project / 'T001_写作骨架.md').exists())

    def test_complete_lifecycle_and_static_audit(self):
        self.init()
        self.signal()
        self.candidate()
        r = self.runcli('review', '--dir', str(self.project), '--id', 'T001')
        self.assertIn('反方最强异议', r.stdout)
        self.assertTrue((self.project / 'T001_选题评审.md').is_file())
        self.runcli('lock', '--dir', str(self.project), '--id', 'T001', '--confirm', '我已讨论并确认')
        self.runcli('outline', '--dir', str(self.project))
        self.runcli('audit', '--dir', str(self.project), status=3)
        f = self.project / 'T001_写作骨架.md'
        txt = f.read_text(encoding='utf-8')
        import re
        txt = re.sub(r'<!-- TODO: .*? -->', '这一段以现场记录证据为基础写成，需要人工核对。', txt)
        f.write_text(txt, encoding='utf-8')
        self.runcli('audit', '--dir', str(self.project))
        self.runcli('outline', '--dir', str(self.project), status=2)
        self.assertIn('这一段', f.read_text(encoding='utf-8'))

    def test_edit_after_lock_unlocks_and_preserves_history(self):
        self.init(); self.signal(); self.candidate()
        self.runcli('lock', '--dir', str(self.project), '--id', 'T001', '--confirm', '我已讨论并确认')
        self.runcli('refine', '--dir', str(self.project), '--id', 'T001', '--field', 'claim',
                    '--text', '改成更窄的命题：仅对教学复现承诺类视频讨论材料清单是否充分')
        obj = json.loads((self.project / 'topic_project.json').read_text(encoding='utf-8'))
        self.assertIsNone(obj['locked'])
        self.assertTrue(any(x['action']=='automatic_reopen' for x in obj['history']))
        self.runcli('outline', '--dir', str(self.project), status=2)

    def test_profile_unlocks(self):
        self.init(); self.signal(); self.candidate()
        self.runcli('lock', '--dir', str(self.project), '--id', 'T001', '--confirm', '我已讨论并确认')
        self.runcli('profile', '--dir', str(self.project), '--audience', '有2年经验的AI作者')
        r = self.runcli('status', '--dir', str(self.project))
        self.assertIn('已锁定：无', r.stdout)

    def test_attach_unknown_rejected_and_new_signal_add(self):
        self.init(); self.signal(); self.candidate()
        self.runcli('attach', '--dir', str(self.project), '--id', 'T001', '--signals', 'S999', status=2)
        self.runcli('signal', '--dir', str(self.project), '--kind', 'public',
                    '--text', '有一个可核查的外部案例展示了相关步骤的影响和结果',
                    '--source', 'https://example.org/demo', '--date', '2026-10-01')
        self.runcli('attach', '--dir', str(self.project), '--id', 'T001', '--signals', 'S002')
        obj = json.loads((self.project / 'topic_project.json').read_text(encoding='utf-8'))
        self.assertEqual(obj['candidates'][0]['signal_ids'], ['S001', 'S002'])

    def test_empty_partial_candidate_stays_open(self):
        self.init()
        self.runcli('candidate', '--dir', str(self.project), '--name', '宽泛题目')
        r = self.runcli('review', '--dir', str(self.project), '--id', 'T001')
        self.assertIn('未通过', r.stdout)
        self.runcli('lock', '--dir', str(self.project), '--id', 'T001', '--confirm', '我已讨论并确认', status=2)

    def test_garbled_json_fails_cleanly(self):
        self.init()
        (self.project / 'topic_project.json').write_text('{broken', encoding='utf-8')
        self.runcli('status', '--dir', str(self.project), status=2)

if __name__ == '__main__':
    unittest.main(verbosity=2)
