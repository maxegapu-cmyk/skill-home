# VALIDATION REPORT

Version: 2.0.0
Validation type: structural + adversarial + representative production simulation

## 1. Structural validation
- Main runtime entry present: PASS
- Main entry length target: PASS
- Required reference files present: PASS
- Writer/Director/Editor standalone routing: PASS
- Pairwise and full-chain routing: PASS
- Viewer State schema includes human-realism fields: PASS
- Hard Gates override weighted score: PASS
- Local regression path present: PASS

## 2. Representative production simulations

### SIM-01 — Writer only / unearned death
Input: a supporting character dies in scene 3 after minimal relationship establishment; script labels it “devastating”.
Expected Viewer State: low investment, surprise possible, grief weak.
Root: WRITING_ROOT.
Repair: add meaningful choice/relationship cost before death, not stronger music.
Result: PASS.

### SIM-02 — Writer only / fair but transparent twist
Input: one suspect receives every suspicious clue; twist reveals that same suspect.
Genre-core state: high prediction confidence early.
Root: WRITING_ROOT.
Repair: add credible competing model, not random false clue.
Result: PASS.

### SIM-03 — Director only / hidden clue not perceived
Input: script context says key badge must be noticed; storyboard leaves it small behind moving foreground action.
Expected: screen presence without perception.
Root: DIRECTING_ROOT.
Repair: change salience/reveal timing while preserving subtlety.
Result: PASS.

### SIM-04 — Director only / suspense leak
Input: murderer is framed brightly in center before protagonist starts searching.
Expected: viewer belief locks too early.
Root: DIRECTING_ROOT.
Repair: reassign primary attention and forbidden reveal.
Result: PASS.

### SIM-05 — Editor only / reaction truncated
Input: reveal shot cuts away before character reaction becomes legible.
Expected: event understood, emotion under-processed.
Root: EDITING_ROOT.
Repair: restore reaction hold or select a more immediately readable take.
Result: PASS.

### SIM-06 — Editor only / fast but static
Input: 18 rapid shots repeat the same chase state with no new risk, prediction or relation change.
Expected: high sensory rate, declining psychological novelty.
Root: EDITING_ROOT or DIRECTING_DEPENDENCY depending available material.
Repair: compress redundancy; preserve only state-changing beats.
Result: PASS.

### SIM-07 — Writer + Director / script works, image fails
Input: script establishes audience concern; direction obscures the object creating danger.
Expected: Writer capital present, perceived stakes weak.
Root: DIRECTING_ROOT.
Result: PASS.

### SIM-08 — Writer + Director / direction cannot rescue script
Input: no relationship capital; director proposes slow motion, close-ups and crying performance for separation scene.
Expected: manipulation/reaction gap.
Root: WRITING_ROOT primary; possible DIRECTING_OVERCOMPENSATION secondary.
Result: PASS.

### SIM-09 — Director + Editor / intent lost in cut
Input: director supplies a 2-second reaction beat; edit removes it for pace.
Expected: psychological processing truncated.
Root: EDITING_ROOT.
Repair: do not request reshoot if usable material exists.
Result: PASS.

### SIM-10 — Writer + Editor / causal explanation cut
Input: script contains a short action establishing motive; final cut removes it.
Expected: later choice feels arbitrary.
Root: EDITING_ROOT if footage exists; MATERIAL_LIMIT if not.
Result: PASS.

### SIM-11 — Full chain / one event traced through all stages
Input: script intends suspicion, direction hides face but highlights hand clue, edit holds clue 0.2 seconds.
Trace: INTENDED_IN_SCRIPT=valid; DELIVERED_BY_DIRECTION=valid; SURVIVED_THE_EDIT=failed.
Root: EDITING_ROOT.
Result: PASS.

### SIM-12 — Full chain / multi-root failure
Input: weak character investment + over-signaled sad music + premature cut from reaction.
Expected: low emotional capital, reactance risk, processing loss.
Root: WRITING_ROOT + SOUND_ROOT + EDITING_ROOT; repair upstream first.
Result: PASS.

### SIM-13 — Human memory decay
Input: climax depends on a code shown once 45 minutes earlier amid unrelated visual noise.
Expected: memory access weak/decayed for casual viewer.
Root: WRITING/DIRECTING depending where reactivation could occur.
Repair: natural reactivation before payoff.
Result: PASS.

### SIM-14 — Attention narrowing
Input: high-threat central confrontation while a subtle peripheral clue appears.
Expected: plausible clue miss, not viewer stupidity.
Root: DIRECTING_ROOT if clue is required for fair twist.
Result: PASS.

### SIM-15 — Reactance
Input: low relationship capital + repeated dialogue saying hero is noble + oversized emotional music.
Expected: reflective rejection and manipulation resistance.
Root: WRITING_ROOT + SOUND/DIRECTING reinforcement.
Result: PASS.

### SIM-16 — Genre-savvy vs casual split
Input: genre convention makes culprit guessable to experts but not casual viewers.
Expected: SEGMENT_SPLIT, not “25% guessed”.
Result: PASS.

### SIM-17 — Distracted viewer robustness
Input: one low-salience line is missed; entire plot becomes incomprehensible.
Expected: high fragility even if attentive viewer can follow.
Repair: redundant but non-repetitive causal encoding.
Result: PASS.

### SIM-18 — System restraint
Input: script, direction and edit all support clear viewer state progression with no Hard Gate.
Expected: PASS without inventing criticism to justify the tool.
Result: PASS.

## 3. Adversarial coverage
72 named adversarial cases cover:
- writing psychology;
- directing/perceptual attention;
- editing/post timing;
- cross-system blame arbitration;
- AI-generation continuity;
- bounded attention and memory;
- genre prediction;
- emotional adaptation;
- reactance;
- social/moral ambiguity;
- uncertainty and audience disagreement.

Coverage status: PASS.
Empirical audience prediction benchmark: NOT CLAIMED.

## 4. Release validation requirements
Before distribution:
- verify all internal references resolve;
- verify package manifest hashes;
- verify archive integrity after extraction;
- verify no nonessential external identifiers or links remain;
- verify no extra overview file is present;
- verify main runtime entry remains below its size target.
