# Viewer State Template

NODE_ID:
TIME / SCENE:
INPUT_LAYER: WRITER | DIRECTOR | EDITOR | FINISHED

KNOWN:
- 

BELIEVED:
- belief:
  confidence: low|medium|high
  evidence:

OPEN_QUESTIONS:
- question:
  urgency: low|medium|high

PREDICTIONS:
- prediction:
  confidence: low|medium|high

CHARACTER_INVESTMENT:
- character:
  liking:
  empathy:
  identification:
  respect:
  trust:
  fear:
  fascination:
  moral_approval:

STAKES_FELT:
- 

FAST_RESPONSE:
- 

REFLECTIVE_RESPONSE:
- 

EMOTIONAL_RESIDUE:
- valence: negative|mixed|positive
- intensity: 0-5
- label:

ATTENTION_TARGET:
- primary:
- secondary:
- forbidden_reveal:

COGNITIVE_LOAD:
- level: low|medium|high
- competing_items:

MEMORY_ACCESS:
- strong:
- weak:
- decayed:

SOCIAL_JUDGMENT:
- status:
- fairness:
- belonging:
- moral_debt:

REACTANCE:
- low|medium|high
- trigger:

CHARACTER_MIND_MODEL:
- character:
  viewer_thinks_character_knows:
  viewer_thinks_character_wants:
  viewer_thinks_character_misunderstands:

EXIT_IMPULSE:
- low|medium|high
- reason:

WHY_NEXT:
- 
