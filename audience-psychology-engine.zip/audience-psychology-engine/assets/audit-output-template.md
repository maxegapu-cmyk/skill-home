# Audit Output Template

## VERDICT
STATUS:
PRIMARY_ROOT_CAUSE:
MODE:

## FIRST-VIEWER EXPERIENCE

## VIEWER STATE TURNING POINTS

## FATAL / MAJOR ISSUES
### ISSUE
Evidence:
Audience consequence:
Root layer: WRITING_ROOT | DIRECTING_ROOT | EDITING_ROOT | PERFORMANCE_ROOT | SOUND_ROOT | MODEL_ASSET_LIMIT | CROSS_LAYER_CONFLICT | MULTI_ROOT
Confidence: low|medium|high
Minimal repair:
Regression range:

## WRITER_FEEDBACK_PACKET

## DIRECTOR_FEEDBACK_PACKET

## EDITOR_FEEDBACK_PACKET

## AUDIENCE_STATE_PACKET

## SCORES
Viewer Comprehension:
Engagement / Question Energy:
Character Investment:
Suspense / Prediction / Payoff:
Emotional Dynamics:
Human Realism / Reactance:
Social-Psychological Credibility:
Directorial Attention / Performance:
Editing / Temporal Delivery:
Memory / Continuity:

HARD GATES:
UNVERIFIED_ITEMS:
FINAL STATUS:
