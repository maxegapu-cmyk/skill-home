# Cross-System Integration Protocol

## 1. 四系统角色
- Writer：叙事事实、人物选择、因果、关系、信息存在。
- Director：镜头、调度、表演、空间、感知优先级。
- Editor/Post：最终顺序、时长、切点、镜头选择、声音时序。
- Audience Engine：观众实际理解、感觉、预测、记忆与退出风险。

## 2. 可独立运行
### Writer → Audience
输入剧本；输出 `WRITER_FEEDBACK_PACKET` + 可交给导演的 `AUDIENCE_INTENT_PACKET`。

### Director → Audience
输入导演方案；输出 `DIRECTOR_FEEDBACK_PACKET`。若剧本信息不足，标记未知，不强迫用户补齐无关材料。

### Editor → Audience
输入时间线/粗剪；输出 `EDITOR_FEEDBACK_PACKET`。素材缺失则标记素材限制。

## 3. 任意双系统
### Writer + Director
先审叙事心理，再审感知送达；镜头修复不得掩盖叙事根因。

### Director + Editor
先锁导演心理意图，再检查剪辑是否保留/改变它。

### Writer + Editor
从最终观感反推：问题来自故事本身还是剪辑送达；无法靠剪辑修时回报 Writer。

## 4. 三系统联动
推荐顺序：
1. Writer 产出 Scene/Beat；
2. Audience 做 Blind Viewer；
3. Writer 修上游根因；
4. Director 转镜头并接收 Audience Intent；
5. Audience 审镜头注意/表演；
6. Editor 形成时间线；
7. Audience 审最终时间送达；
8. 只对受影响区间回归。

## 5. 标准 Packet
### AUDIENCE_STATE_PACKET
- `TIME_OR_SCENE`
- `KNOWN`
- `BELIEVED`
- `OPEN_QUESTIONS`
- `PREDICTIONS`
- `INVESTMENT`
- `EMOTION`
- `ATTENTION`
- `MEMORY_RISK`
- `EXIT_IMPULSE`

### AUDIENCE_INTENT_PACKET
交给导演/编辑，描述必须让观众经历什么：
- `MUST_NOTICE`
- `MUST_NOT_NOTICE_YET`
- `MUST_FEEL`
- `MUST_QUESTION`
- `MUST_REMEMBER`
- `DESIRED_UNCERTAINTY`
- `PROCESSING_BEAT`

### WRITER_FEEDBACK_PACKET
- `VIEWER_MISREAD`
- `MISSING_INVESTMENT`
- `WEAK_STAKES`
- `QUESTION_FAILURE`
- `PREDICTION_FAILURE`
- `TWIST_FAIRNESS`
- `SOCIAL_LOGIC`
- `MINIMAL_WRITING_REPAIR`

### DIRECTOR_FEEDBACK_PACKET
- `PRIMARY_ATTENTION_TARGET`
- `SECONDARY_DISCOVERY`
- `FORBIDDEN_REVEAL`
- `PERFORMANCE_READABILITY`
- `SPATIAL_CLARITY`
- `SHOT_TASK`
- `REACTION_REQUIREMENT`
- `MINIMAL_DIRECTING_REPAIR`

### EDITOR_FEEDBACK_PACKET
- `REVEAL_ORDER`
- `PROCESSING_WINDOW`
- `CUT_RISK`
- `REACTION_HOLD`
- `RHYTHM_FUNCTION`
- `SOUND_TIMING`
- `MATERIAL_LIMIT`
- `MINIMAL_EDIT_REPAIR`

## 6. Cross-Layer Ticket
当修一层会伤另一层时记录：
- `ISSUE_ID`
- `UPSTREAM_ROOT`
- `DOWNSTREAM_SYMPTOM`
- `DO_NOT_BREAK`
- `REPAIR_OWNER`
- `AFFECTED_RANGE`
- `REGRESSION_TEST`

## 7. 根因优先级
原则上先修上游：Writing → Directing → Editing。
例外：若用户当前只能改剪辑，则给“当前层最佳修复 + 未消除上游风险”，不强迫重做整部作品。

## 8. 禁止甩锅
- 编剧不能用解释台词修镜头漏信息；
- 导演不能用慢镜/BGM修零情感资本；
- 编辑不能用快剪修场景没有目标；
- Audience Engine 不能为了显得有用强行制造问题。
