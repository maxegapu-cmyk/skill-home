# Rough-Cut / Finished-Video Psychology Audit

## 1. 原则
文本与分镜通过，不代表成片通过。粗剪审计只相信实际播放顺序中可被观众接收的视听信息。

## 2. 时间轴记录
关键时间段记录：
- `ATTENTION_LOCK`
- `INFO_RECEIVED`
- `FAST_RESPONSE`
- `REACTION_WINDOW`
- `EMOTION_DELTA`
- `MEMORY_ENCODING`
- `IDENTITY_CONTINUITY`
- `AUDIO_FUNCTION`
- `REACTANCE`
- `EXIT_IMPULSE`

## 3. 三级追踪
同一关键心理事件标记：
- `INTENDED_IN_SCRIPT`
- `DELIVERED_BY_DIRECTION`
- `SURVIVED_THE_EDIT`

第一级不存在：Writing root。
第二级丢失：Directing/Performance root。
第三级丢失：Editing/Sound root。

## 4. 常见纸面通过、成片失败
1. `DELIVERY_FAILURE`：看不清、听不清、太短或被抢注意。
2. `PERFORMANCE_FAILURE`：行为没传出剧本规定的心理变化。
3. `TEMPORAL_FAILURE`：不给预测、理解、反应或余味时间。
4. `CONTINUITY_FAILURE`：人物/空间漂移破坏事件模型。
5. `SALIENCE_FAILURE`：错误对象成为最强刺激。
6. `EMOTIONAL_REACTANCE`：音乐/慢镜/哭戏远超已有心理资本。

## 5. AI影视专项
以下优先归生成/执行，不要求编剧重写：
- 人脸/服装身份变形导致角色识别中断；
- 手部/道具异常抢注意；
- 背景无意义运动持续竞争；
- 视线与对象不匹配；
- 同一空间方向关系漂移；
- 表情峰值与对白时点错位；
- 镜头间角色年龄、气质、伤势状态无因果变化。

## 6. 局部回归
剪辑修复后，从修复点前一个稳定Viewer State开始重放，到后续状态重新接轨。不要因为一个切点重构全片。

## 7. 输出
成片审计必须分别给：
- 观众实际体验；
- 时间码/节点；
- 根因层；
- 当前素材内可修；
- 必须补拍/再生成；
- 修复后的回归区间。
