# Social Amplification: Comment / Share / Discussion Psychology

## 边界
“容易讨论”不等于“作品更好”，也不等于真实传播率。这里只判断作品是否制造了自然的社会表达动机。

## 常见表达动机
- **Identity Signal**：转发/评论能表达“我是谁、我认同什么”；
- **Moral Judgment**：观众想判断谁对谁错；
- **Status Knowledge**：观众想展示自己看懂了线索或知识；
- **Prediction Contest**：未决问题允许不同预测；
- **Justice Reaction**：不公平、报应、翻盘引发站队；
- **Relational Recognition**：某段关系体验“太像现实”；
- **Surprise Disclosure**：想把强惊讶推荐给别人，但必须避免依赖剧透；
- **Quote / Image Anchor**：存在可独立记忆的台词、动作或视觉符号。

## 审计问题
- 观众看完最可能和朋友争论什么？
- 有无值得站队的真实价值冲突，而非强行二选一？
- 评论点来自剧情本身，还是只能靠标题挑衅？
- 分享会不会因为必须解释大量背景而成本过高？
- 爆点是否只适合一次性惊吓，缺乏复述价值？

## 禁止
不要把愤怒、羞辱、身份冲突当作必然的传播捷径；如果破坏角色和作品信任，短期反应不能证明长期价值。
