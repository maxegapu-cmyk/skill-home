# Script Psychology Audit

## 1. 场景心理任务
每场至少应改变一个 Viewer State：
- 形成/升级/兑现问题；
- 改变预测；
- 改变关系或社会地位；
- 改变风险；
- 改变角色判断；
- 改变情绪；
- 让世界规则获得当前意义。

只有信息增加而状态不变，标记 `EXPOSITION_WITHOUT_PSYCHOLOGICAL_MOVEMENT`。

## 2. Scene Reward Ratio
问：观众为理解这一场付出的注意和认知成本，换回了什么？
高成本低回报会增加 `EXIT_IMPULSE`，即使剧情逻辑正确。

## 3. 角色投入账
记录：`投入来源 → Viewer State变化 → 可支取事件`。
有效来源常包括：具体欲望、有代价行动、能力、脆弱、选择、承担后果、独特关系、规范维护/违背。
悲惨背景不是自动同情券。

## 4. Stakes Felt
区分：
- `DECLARED_STAKES`
- `DEMONSTRATED_STAKES`
- `PERSONALIZED_STAKES`
- `FELT_STAKES`

只声明“世界要毁灭”而没有具体的人、关系或后果，可能仍然低 Felt Stakes。

## 5. 开放问题链
问题分 LOCAL / SCENE / EPISODE / ARC。
长线谜团需要中短期兑现维持信任；只开不还形成 `QUESTION_DEBT`。

## 6. 因果可读性
重大 beat 必须能回答：“为什么因为之前的事，才发生现在的事？”
答案若只是作者需要，标记 `CAUSAL_WEAKNESS`。

## 7. 预测空间
关键转折前必须允许观众形成至少一种合理预测。完全没有预测空间的揭晓更像信息投放，不是反转。

## 8. 对白与社会子文本
检查：
- 是否重复观众已知；
- 是否用台词代替行为；
- 是否所有人都直接说真实想法；
- 是否存在面子、权力、试探、回避、威胁、讨好、隐瞒等关系动作；
- 情绪是否被命名而非表现。

## 9. Earned Emotion
作者想要的情绪必须能追溯到前置关系、选择、风险和意义。若只能靠旁白/BGM想象成立，编剧层先不过。
