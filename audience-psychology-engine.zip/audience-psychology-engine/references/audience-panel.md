# Simulated Audience Panel

## 1. 原则
Audience Panel 是不同观看策略和先验，不是人口统计预测。每个镜片都必须使用同一作品证据，只改变合理的注意、知识与敏感点。

## 2. 默认四镜片
### TARGET_CORE
按作品明确目标观众的类型承诺阅读。
关注：承诺兑现、核心情绪需求、角色关系和平台观看契约。

### GENRE_CORE
类型经验高，套路预测能力强。
关注：高显著伏笔、套路透明、伪反转、类型承诺是否被廉价复制。

### CASUAL_VIEWER
投入有限、背景知识少、不会主动替作品补逻辑。
关注：理解成本、名字/规则过载、即时回报、退出冲动。

### SKEPTICAL_VIEWER
对作者作弊、强行煽情、角色降智、说教和“导演告诉我该怎么感觉”敏感。
关注：公平性、因果、情绪逆反。

## 3. 可调人性旋钮
需要时只改变明确相关的变量：
- `GENRE_LITERACY`: low/medium/high
- `INITIAL_COMMITMENT`: low/medium/high
- `AMBIGUITY_TOLERANCE`: low/medium/high
- `IP_PRIOR_KNOWLEDGE`: none/basic/deep
- `MORAL_SENSITIVITY`: context-specific
- `PLATFORM_EXIT_FRICTION`: low/medium/high
- `DISTRACTION_LOAD`: low/medium/high

不要把年龄、性别、文化等直接映射成刻板心理。若用户指定具体群体，只做有证据的观看假设，并标注不确定性。

## 4. 分歧输出
- `CONSENSUS`：多个镜片由同一结构证据得出相同风险；
- `SEGMENT_SPLIT`：因先验/类型经验不同产生合理分歧；
- `ASSUMPTION_SENSITIVE`：结论高度依赖某个未验证受众假设；
- `UNKNOWN`：材料不足。

禁止把四镜片投票成“75%观众”。
