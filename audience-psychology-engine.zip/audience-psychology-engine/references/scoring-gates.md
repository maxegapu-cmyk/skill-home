# Scoring & Gates

## 评分用途
这是内部诊断量表，不是市场预测、真人满意度或爆款概率。
每项先按 0–5 判断，再映射权重。

- 5：稳定成立，且观看链证据明确；
- 4：成立，局部泄漏；
- 3：有条件成立；
- 2：明显不稳；
- 1：基本失效；
- 0：反向伤害体验。

## 权重
- Viewer Comprehension 14
- Engagement / Question Energy 13
- Character Investment 13
- Suspense / Prediction / Payoff 12
- Emotional Dynamics 12
- Human Realism / Reactance 10
- Social-Psychological Credibility 8
- Directorial Attention / Performance 8
- Editing / Temporal Delivery 7
- Memory / Continuity 3

## 判决建议
- 90–100：`PASS_9PLUS_DESIGN`，仍必须过 Hard Gates；
- 82–89：`PASS_WITH_MINOR_REPAIR`；
- 70–81：`CONDITIONAL`；
- <70：`FAIL`。

## Hard Gates
任一命中不得靠平均分掩盖：
- 核心因果在实际观看时无法建立；
- 核心动机必须依赖作者解释；
- 重大反转无前置可回溯证据；
- 高潮此前没有心理资本；
- 导演提前泄露核心信息或根本没送达；
- 剪辑截断关键理解/反应窗口；
- 核心情绪只靠台词或音乐宣布；
- 连续区间无活问题、关系变化、目标推进或意义更新；
- 核心理解依赖已高度衰减的弱信息；
- AI 角色/空间漂移严重到观众无法稳定建立人物或事件模型。

## 证据格式
每个扣分必须能写成：
`观看节点 → Viewer State 预期 → 实际失败 → 观众后果`。
禁止“感觉节奏差”“感觉不够高级”这类无证据扣分。

## 分层评分
若只有剧本，不给导演/剪辑层假分；标记 `NOT_SCORED_FROM_CURRENT_INPUT`。
总分只能对当前有证据的维度做归一化，并明确范围。
