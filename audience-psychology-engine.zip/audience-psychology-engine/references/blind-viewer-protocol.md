# Blind First-Viewer Protocol

## 1. 目的
模拟第一次观看，不做事后聪明，不把作者说明当观众体验。

## 2. 顺序消费
按真实观看顺序切成心理节点：场景、beat、关键镜头或必要的时间段。
节点粒度以“Viewer State 是否可能改变”为准，不机械每5秒记录。

## 3. 每个节点
记录：
- `INPUT_RECEIVED`：实际送达；
- `FAST_RESPONSE`：第一反应；
- `INTERPRETATION`：当前解释；
- `OPEN_QUESTION_TOP1`；
- `PREDICTION_TOP1 + CONFIDENCE`；
- `CHARACTER_POSITIONING`；
- `EMOTIONAL_RESIDUE`；
- `ATTENTION_TARGET`；
- `COGNITIVE_LOAD`；
- `MEMORY_RISK`；
- `REACTANCE`；
- `EXIT_IMPULSE`；
- `WHY_NEXT`。

## 4. Future Wall
即使后文已经在上下文里，当前节点禁止使用：
- 后续真相；
- 后续角色动机；
- 后续解释；
- 作者后来补充的设定。

判断必须能只用“截至当前的证据”重建。

## 5. 反转保真
揭晓前冻结预测。揭晓后比较：
- Surprise；
- Fairness；
- Reinterpretation；
- Consequence。

低置信猜中过不等于反转失败；高置信提前锁死才是主要透明风险。

## 6. 作者意图隔离
作者旁注如“这里观众心疼/这里很爽/这是伏笔”只能视为目标，不得当结果。

## 7. 记忆退化
长篇/跨集按事件重要度重新计算 strong/weak/decayed。不得把模型完美上下文能力冒充人类记忆。

## 8. 修复后回归
修复某节点后，从前一个稳定 Viewer State 重新顺序观看；不得直接跳到修复点并携带旧版后文印象。
