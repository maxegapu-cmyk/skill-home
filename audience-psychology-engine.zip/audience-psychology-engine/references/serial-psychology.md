# Serial / Multi-Episode Audience Psychology

## 1. Open-Question Debt
每条跨集问题记录：建立时间、重要度、最近推进、部分兑现、记忆状态、拖欠风险。
只开不还会消耗作品信用。

## 2. Payoff Credit
中短期问题得到有意义兑现，会提高观众对长线等待的容忍度。反复“下集告诉你”但不给价值，会降低信用。

## 3. Trust in Storytelling
维护 `TRUST_IN_AUTHOR`（仅作内部状态名）：
- 线索是否最终有意义；
- 规则是否稳定；
- 角色是否按已建立动机行动；
- 承诺是否兑现。

信用低时，同样的悬念更容易被理解为拖延或作弊。

## 4. Character Investment Carryover
跨集投入会累积，但可能因无后果越界、价值突变、长期被动、重复冲突而快速重估。

## 5. Memory Reactivation
旧信息按 STRONG / WEAK / DECAYED 处理。跨集回收弱信息时用新语境、物件、后果、关系反应自然再激活。

## 6. Fatigue Pattern
检查：
- 同一种打脸/反转/误会重复；
- 同一角色长期不成长；
- 每集结尾都同款假悬念；
- 谜团增加速度远高于兑现速度。

## 7. Episode Ending
结尾至少改变一种状态：真相、风险、选择、关系定义、已知事实意义或不可逆后果。单纯切黑不是悬念。
