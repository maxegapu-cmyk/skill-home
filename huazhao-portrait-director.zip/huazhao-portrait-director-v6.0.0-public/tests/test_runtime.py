"""Real functional/negative/regression cases: stdlib only, no image model required."""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('huazhao', ROOT/'scripts/huazhao.py')
mod=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(mod)

def fixture(name):return json.loads((ROOT/'examples'/f'{name}.json').read_text(encoding='utf-8'))

class DirectorCases(unittest.TestCase):
    def test_single(self):
        x=mod.compile_plan(fixture('single'),'single')
        self.assertEqual(x['status'],'planned')
        self.assertEqual(x['shot_spec']['subject_integrity']['wardrobe_core'],'月白色襕衫和深色帽子')
        self.assertFalse(x['real_image_generated']);self.assertTrue(all(g['state']=='unverified' for g in x['quality_gates']))
    def test_reference_roles(self):
        x=mod.compile_plan(fixture('multi-reference'),'single')
        a=x['reference_authority']['roles']
        self.assertEqual(a['identity']['primary'],'img-face')
        self.assertEqual(a['wardrobe']['primary'],'img-outfit')
        self.assertEqual(a['pose']['primary'],'img-pose')
        self.assertNotIn('lighting',a)
    def test_two_subjects_identity_is_scoped(self):
        x={'intent':'双人互动写真','subjects':[{'id':'A','identity_core':'A的脸','position':'左侧','hand_task':'递信'},{'id':'B','identity_core':'B的脸','position':'右侧','hand_task':'接信'}],
           'scene':{'event':'两人交接一封信','interaction':'A将信交给B'},
           'references':[{'id':'A-face','roles':['identity'],'subject_id':'A','priority':10,'clarity':'high'},
                         {'id':'B-face','roles':['identity'],'subject_id':'B','priority':10,'clarity':'high'}]}
        r=mod.compile_plan(x,'single')
        self.assertEqual(r['status'],'planned')
        self.assertEqual(r['reference_authority']['roles']['A.identity']['primary'],'A-face')
        self.assertEqual(r['reference_authority']['roles']['B.identity']['primary'],'B-face')
        self.assertEqual(len(r['shot_spec']['staging']['participants']),2)
    def test_two_subjects_ambiguous_face_stops(self):
        x={'intent':'双人互动写真','subjects':[{'id':'A'},{'id':'B'}], 'references':[{'id':'face','roles':['identity']} ]}
        r=mod.compile_plan(x,'single')
        self.assertEqual(r['status'],'needs_decision')
        self.assertTrue(r['reference_authority']['roles']['identity']['needs_subject_assignment'])
    def test_subject_scope_bad_id_rejected(self):
        x={'intent':'双人合照','subjects':[{'id':'A'},{'id':'B'}],
           'references':[{'id':'r1','roles':['identity'],'subject_id':'C'}]}
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'single')
    def test_subject_duplicate_rejected(self):
        x={'intent':'双人合照','subjects':[{'id':'A'},{'id':'A'}]}
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'single')
    def test_reference_priority(self):
        x=fixture('multi-reference')
        x['references'].append({'id':'otherface','roles':['identity'],'priority':1,'clarity':'high'})
        r=mod.compile_plan(x,'single')
        self.assertEqual(r['reference_authority']['roles']['identity']['primary'],'img-face')
    def test_reference_clarity_breaks_tie(self):
        x=fixture('multi-reference')
        x['references'].append({'id':'otherface','roles':['identity'],'priority':10,'clarity':'low'})
        r=mod.compile_plan(x,'single')
        self.assertEqual(r['status'],'planned')
    def test_reference_same_rank_stops(self):
        x=fixture('multi-reference')
        x['references'].append({'id':'otherface','roles':['identity'],'priority':10,'clarity':'high'})
        r=mod.compile_plan(x,'single')
        self.assertEqual(r['status'],'needs_decision')
        self.assertIsNone(r['reference_authority']['roles']['identity']['primary'])
    def test_invalid_reference_role_rejected(self):
        x=fixture('single');x['references'][0]['roles']=['take_over_everything']
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'single')
    def test_duplicate_refs_rejected(self):
        x=fixture('single');x['references'].append(x['references'][0])
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'single')
    def test_references_not_visually_inspected(self):
        x=mod.compile_plan(fixture('single'),'single')
        self.assertIn('not inspected',x['reference_authority']['observation'])
    def test_series_six_unique(self):
        x=mod.compile_plan(fixture('series'),'series')
        self.assertEqual(len(x['frames']),6)
        self.assertTrue(all(r['variation_pass'] for r in x['frames']))
        self.assertEqual(len(set(r['frame_fingerprint'] for r in x['frames'])),6)
    def test_series_forty_stress(self):
        x=fixture('series');x['series_count']=40
        out=mod.compile_plan(x,'series')
        self.assertEqual(len(out['frames']),40)
        self.assertTrue(all(len(x['changes_from_previous'])>=2 for x in out['frames'][1:]))
        self.assertEqual(len(set(r['frame_fingerprint'] for r in out['frames'])),40)
    def test_series_lock_camera(self):
        x=fixture('series');x['locks']+=['camera'];x['visual']={'shot_size':'medium','camera_height':'eye'}
        r=mod.compile_plan(x,'series')
        self.assertTrue(all(z['camera_height']=='eye' and z['shot_size']=='medium' for z in r['frames']))
        self.assertTrue(all(z['variation_pass'] for z in r['frames']))
    def test_series_fully_locked_must_stop(self):
        x=fixture('series');x['locks']+=['camera','pose','gaze','hand_task']
        r=mod.compile_plan(x,'series')
        self.assertEqual(r['status'],'needs_decision')
    def test_series_out_of_range(self):
        x=fixture('series');x['series_count']=41
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'series')
    def test_series_boolean_not_count(self):
        x=fixture('series');x['series_count']=True
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'series')
    def test_user_reported_issue_does_not_claim_visual_audit(self):
        x=mod.compile_plan(fixture('repair'),'repair')
        self.assertEqual(x['status'],'ready_for_external_visual_review')
        self.assertFalse(x['real_image_audited'])
        self.assertEqual(x['review']['repair_scope'],['hands'])
        self.assertIn('identity',x['review']['keep_list'])
    def test_no_visual_evidence_refuses_verdict(self):
        x=fixture('repair');x['visual_evidence']='none'
        self.assertEqual(mod.compile_plan(x,'repair')['status'],'needs_visual_review')
    def test_issue_without_evidence_refuses(self):
        x=fixture('repair');x['observed_issues'][0]['evidence']=''
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'repair')
    def test_repair_layer_locked_blocks(self):
        x=fixture('repair');x['locks']=['hands']
        r=mod.compile_plan(x,'repair')
        self.assertEqual(r['status'],'needs_decision')
        self.assertFalse(r['review']['repair_scope'])
    def test_repair_reports_highest_severity(self):
        x=fixture('repair');x['observed_issues'] += [{'layer':'material','severity':'low','evidence':'柔化'}]
        self.assertEqual(mod.compile_plan(x,'repair')['review']['top_failure']['layer'],'hands')
    def test_audit_never_edits(self):
        x=mod.compile_plan(fixture('audit'),'audit')
        self.assertFalse(x['review']['repair_scope'])
        self.assertFalse(x['review']['changes_applied'])
    def test_tool_not_confused_with_installed(self):
        x=mod.compile_plan(fixture('single'),'single')
        self.assertIn('image_generation',x['tool_readiness']['declared_but_unverified'])
        self.assertIn('not verified',x['tool_readiness']['actual_runtime_integration'])
    def test_missing_features_listed(self):
        x=mod.compile_plan(fixture('series'),'series')
        self.assertIn('image_generation',x['tool_readiness']['missing_or_unconfirmed'])
    def test_standalone_no_references(self):
        x=mod.compile_plan({'intent':'自然室内人像'},'single')
        self.assertEqual(x['status'],'planned')
        self.assertEqual(x['reference_authority']['roles'],{})
    def test_input_types(self):
        for obj in ({},{'intent':2},{'intent':'ok','subject':'bad'},[],{'intent':'ok','tool':{'kind':'madeup'}}):
            with self.subTest(obj=obj),self.assertRaises(mod.InputError):mod.compile_plan(obj,'single')
    def test_unknown_protected_rejected(self):
        x=fixture('repair');x['protected_successes']=['something']
        with self.assertRaises(mod.InputError):mod.compile_plan(x,'repair')
    def test_cli_stdout_json(self):
        r=subprocess.run([sys.executable,str(ROOT/'scripts/huazhao.py'),'single','--input',str(ROOT/'examples/single.json')],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(json.loads(r.stdout)['status'],'planned')
    def test_cli_existing_output_protected(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'test.json';out.write_text('DO NOT OVERWRITE')
            r=subprocess.run([sys.executable,str(ROOT/'scripts/huazhao.py'),'single','--input',str(ROOT/'examples/single.json'),'--out',str(out)],capture_output=True,text=True)
            self.assertEqual(r.returncode,2)
            self.assertEqual(out.read_text(),'DO NOT OVERWRITE')
    def test_cli_file_not_found(self):
        r=subprocess.run([sys.executable,str(ROOT/'scripts/huazhao.py'),'audit','--input',str(ROOT/'examples/nonexistent.json')],capture_output=True,text=True)
        self.assertEqual(r.returncode,2)
    def test_cli_conflict_exit_code(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'brief.json';x=fixture('single');x['references'].append({'id':'face2','roles':['identity'],'priority':10,'clarity':'high'});f.write_text(json.dumps(x))
            r=subprocess.run([sys.executable,str(ROOT/'scripts/huazhao.py'),'single','--input',str(f)],capture_output=True,text=True)
            self.assertEqual(r.returncode,3)
            self.assertEqual(json.loads(r.stdout)['status'],'needs_decision')
    def test_consistency_stable(self):
        b=fixture('series');self.assertEqual(mod.compile_plan(b,'series'),mod.compile_plan(b,'series'))
    def test_legacy_case_coverage(self):
        cases=json.loads((ROOT/'tests/cases.json').read_text(encoding='utf-8'))
        self.assertGreaterEqual(len(cases),20)
        self.assertEqual(len(set(z['id'] for z in cases)),len(cases))

if __name__=='__main__':unittest.main(verbosity=2)
