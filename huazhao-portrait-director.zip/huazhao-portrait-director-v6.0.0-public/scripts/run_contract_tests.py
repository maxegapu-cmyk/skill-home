"""Run the actual behavioral test suite using the package's public Python entry."""
from pathlib import Path
import json
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
cases=json.loads((root/'tests/cases.json').read_text(encoding='utf-8'))
ids=[x.get('id') for x in cases]
if len(ids)!=len(set(ids)) or any(not x.get('task') or not x.get('expect') for x in cases):
    print('TESTS FAIL: v5 regression case registry malformed')
    sys.exit(1)
ret=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(root/'tests'),'-p','test_runtime.py','-v'],cwd=root)
if ret.returncode:
    print('TESTS FAIL')
    sys.exit(ret.returncode)
print(f'TESTS PASS | v5 regression inventory={len(cases)} | v6 behavior cases executed (see unittest output)')
