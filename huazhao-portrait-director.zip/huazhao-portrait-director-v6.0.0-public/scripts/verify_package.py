"""Zero-dependency package integrity check, including exact hash list."""
from pathlib import Path
import hashlib
import json
import sys

root=Path(__file__).resolve().parents[1]
errors=[]
contract=json.loads((root/'tests/expected-contract.json').read_text(encoding='utf-8'))
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for rel in contract['required_files']:
    if not (root/rel).is_file():errors.append(f'missing: {rel}')
if manifest.get('version')!=contract['version']:errors.append('manifest version mismatch')
if manifest.get('entry')!='SKILL.md':errors.append('wrong public entry')
if manifest.get('generation_text_included') is not False:errors.append('private generation boundary breached')
refs=list((root/'references').glob('*.md'))
if len(refs)<contract['required_reference_count']:errors.append('missing reference files')
if len(list((root/'schemas').glob('*.json')))<contract['required_schema_count']:errors.append('missing schema files')
if len(json.loads((root/'tests/cases.json').read_text(encoding='utf-8')))<contract['required_test_cases']:errors.append('missing regression inventory')
for f in root.rglob('*'):
    if f.is_symlink():errors.append('symlink forbidden: '+str(f))
    if f.is_file() and f.suffix=='.json':
        try:json.loads(f.read_text(encoding='utf-8'))
        except Exception as exc:errors.append(f'invalid json {f.name}: {exc}')
checks=root/'CHECKSUMS.sha256'
if not checks.is_file():errors.append('missing CHECKSUMS.sha256')
else:
    seen=set()
    for line in checks.read_text(encoding='utf-8').splitlines():
        if not line.strip():continue
        if '  ' not in line:errors.append('malformed checksum line');continue
        digest,rel=line.split('  ',1)
        if rel in seen:errors.append('duplicate checksum line: '+rel)
        seen.add(rel)
        path=root/rel
        try:
            if not path.resolve().is_relative_to(root.resolve()):raise ValueError('outside root')
            if not path.is_file():errors.append('checksum target missing: '+rel);continue
            if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:errors.append('hash mismatch: '+rel)
        except Exception as exc:errors.append(f'checksum invalid {rel}: {exc}')
    existing={x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file() and x.name!='CHECKSUMS.sha256'}
    if existing!=seen:
        errors.extend('untracked: '+x for x in sorted(existing-seen))
        errors.extend('not found: '+x for x in sorted(seen-existing))
if errors:
    print('PACKAGE FAIL:')
    for e in errors:print('-',e)
    sys.exit(1)
print(f'PACKAGE PASS | files={len(seen)+1} | references={len(refs)} | schemas={len(list((root/"schemas").glob("*.json")))} | sha256=verified')
