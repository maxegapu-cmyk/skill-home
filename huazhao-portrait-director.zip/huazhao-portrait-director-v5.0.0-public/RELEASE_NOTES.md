# 5.0.0-public Release Notes

这是一次重构版，而不是在旧版上继续堆模块。

新增：
- Subject Integrity Ledger：人物不可漂移项统一登记；
- Moment State Chain：动作改为前态/快门态/后态；
- Reference Authority Graph：多参考职责与冲突治理；
- Identity Control Adapter：针对身份保持类工具建立独立适配层；
- Series Continuity Ledger：系列状态显式记录；
- Closed-Loop Repair：实际结果复核后只修最高影响失败项；
- Model Capability Adapter：根据工具真实能力改变执行路径；
- 三类 JSON Schema：单张、系列、复核报告可机器验证。

移除：
- 所有可直接复用的底层生成文本；
- 旧版中用于直接拼装底层生成文本的模块；
- 会导致“文字控制能力被高估”的输出约定。

兼容：
- 可作为 ChatGPT/Codex 类工具的导演型 Skill；
- 可作为 ComfyUI / Diffusers / 其他图像工作流前端的规格生成层；
- 没有图像工具时仍可输出可检查的拍摄规格和返修报告。
