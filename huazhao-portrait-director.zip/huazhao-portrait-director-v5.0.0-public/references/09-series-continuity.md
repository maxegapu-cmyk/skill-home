# Series Continuity Ledger

## 固定状态
- subject_id；
- wardrobe_state；
- hair_makeup_state；
- time_weather_state；
- location_family；
- palette_family；
- recurring_props。

## 可变状态
- action_stage；
- shot_size；
- camera_height；
- gaze_target；
- hand_task；
- dominant_foreground；
- dominant_background；
- light_angle_within_same_world。

## 规则
每张必须继承固定状态，同时至少在两个高影响可变状态上与前一张明显不同。系列变化必须像时间和摄影选择造成，而不是人物身份忽然改变。
