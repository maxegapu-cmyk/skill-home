# 第三方公开研究与工程参考

本外发版只吸收公开项目的“可验证能力边界与控制思想”，没有复制其代码、节点文件、权重、示例生成文本或工作流文件。

## PhotoMaker V2
来源：https://github.com/TencentARC/PhotoMaker
采用的公开思想：身份一致性与可编辑性要做权衡；身份控制可以与姿态/结构控制模块组合；单一控制层不应承担所有任务。

## InstantID
来源：https://github.com/instantX-research/InstantID
采用的公开思想：单张身份参考可以作为独立身份条件；身份保持与风格/空间控制应分层。

## PuLID
来源：https://github.com/ToTheBeginning/PuLID
采用的公开思想：身份忠实度与编辑自由度存在明确权衡，身份控制强度不是越高越好。

## ControlNet
来源：https://github.com/lllyasviel/ControlNet
采用的公开思想：姿态、深度、边缘、分割等空间条件适合由专门控制信号承担，而不是让身份参考同时负责。

## ComfyUI IPAdapter Plus
来源：https://github.com/cubiq/ComfyUI_IPAdapter_plus
采用的公开思想：人脸身份、整体图像条件、风格/构图控制可以使用不同适配路径；参考图裁切和主体位置会影响条件提取质量。

## From Open Loop to Closed Loop
来源：https://github.com/zzdrill/From-Open-Loop-to-Closed-Loop
采用的公开思想：把参考一致性问题改造成“生成—测量—纠偏”的闭环，比一次性把所有约束压进单轮执行更稳健。

## 使用提醒
第三方项目、模型权重及其依赖各自受许可证约束。若实际部署对应代码或权重，请单独检查其许可证、模型卡和商业使用条款。
