from pathlib import Path
import json, sys
root = Path(__file__).resolve().parents[1]
contract = json.loads((root/'tests/expected-contract.json').read_text(encoding='utf-8'))
errors=[]
for rel in contract['required_files']:
    if not (root/rel).is_file(): errors.append(f'missing: {rel}')
refs=list((root/'references').glob('*.md'))
if len(refs) < contract['required_reference_count']: errors.append(f'references: {len(refs)}')
schemas=list((root/'schemas').glob('*.json'))
if len(schemas) < contract['required_schema_count']: errors.append(f'schemas: {len(schemas)}')
cases=json.loads((root/'tests/cases.json').read_text(encoding='utf-8'))
if len(cases) < contract['required_test_cases']: errors.append(f'test cases: {len(cases)}')
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
if manifest.get('version') != '5.0.0-public': errors.append('manifest version mismatch')
if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS')
print(f'references={len(refs)} schemas={len(schemas)} cases={len(cases)}')
