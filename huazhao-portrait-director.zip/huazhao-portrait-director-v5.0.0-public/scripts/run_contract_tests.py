from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
cases=json.loads((root/'tests/cases.json').read_text(encoding='utf-8'))
ids=[x['id'] for x in cases]
errors=[]
if len(ids)!=len(set(ids)): errors.append('duplicate case id')
for c in cases:
    if not c.get('task') or not c.get('expect'): errors.append(f'incomplete: {c.get("id")}')
if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS')
print(f'cases={len(cases)}')
