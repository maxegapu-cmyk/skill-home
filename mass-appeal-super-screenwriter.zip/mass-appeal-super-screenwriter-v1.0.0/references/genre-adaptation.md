# Reference — Genre Adaptation Without Losing the Engine

The eight engines stay constant; **pressure source, evidence type, social rules, pacing, and payoff texture** change by genre.

| Genre | Typical pressure source | Useful state changes | Common failure to avoid |
|---|---|---|---|
| Urban/social | money, work, housing, reputation, institutions | leverage, evidence, employment, public/private relationship | status-flex repetition |
| Family | loyalty, care, inheritance, old promises | allegiance, trust, obligation, truth | everyone screaming the same accusation |
| Historical | law, hierarchy, scarcity, transport, records, kinship | access, patronage, evidence, rank, survival | modern behavior in period costume |
| Suspense | incomplete information, threat, hidden motive | evidence, suspicion, safety, ally/opponent model | withholding facts the viewpoint knows |
| Science fiction | one speculative rule changing ordinary life | capability, identity, access, memory, rights | lore before human stakes |
| Comedy | incompatible goals, social misunderstanding, escalating cover-up | status, obligation, misunderstanding, exposure | randomness with no causal escalation |
| Romance | desire vs fear/duty/timing/self-protection | trust, exclusivity, vulnerability, future choice | contrived misunderstanding solvable by one sentence |
| Crime/action | evidence, territory, pursuit, duty, survival | information, route, weapon/resource, alliance, legal exposure | action scenes that reset afterward |
| Horror | safety model collapses, contamination, taboo, isolation | knowledge, space, body, trust, escape options | atmosphere with no decision pressure |
| Inspirational/growth | competence, fear, shame, opportunity | skill, self-definition, relationship, public/private choice | montage as substitute for obstacles |

## Adaptation procedure
1. Keep the human desire legible.
2. Translate pressure into the genre’s credible institutions/rules.
3. Choose evidence and tactics that belong to the world.
4. Change payoff texture: a courtroom truth, a private boundary, a tactical escape, a comic exposure, and a romantic choice can all settle different debts.
5. Preserve causal escalation and character intelligence.
