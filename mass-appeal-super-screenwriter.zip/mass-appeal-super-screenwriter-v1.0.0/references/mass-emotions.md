# Reference — Mass Emotions

Use this to anchor genre-specific plots in broadly readable human emotion. These are **roots**, not mandatory formulas.

| Root | Audience-readable pressure | Common satisfying movement |
|---|---|---|
| Dignity | humiliation, dismissal, control | boundary, recognition, reversal |
| Fairness | theft, blame, rigged rules | truth, restitution, consequence |
| Safety | threat, instability, coercion | escape, protection, regained control |
| Belonging | exclusion, betrayal, replacement | chosen loyalty, reconciliation, self-selection |
| Love | loss, distance, incompatible obligations | choice, sacrifice, honest recognition |
| Family | duty, protection, inheritance, old wounds | truth, boundary, repair, redefined loyalty |
| Money/work | debt, housing, opportunity, exploitation | competence, leverage, recovery, structural win |
| Competence | being underestimated, impossible task | visible proof, mastery, outplay |
| Freedom | surveillance, dependency, obligation | escape, agency, refusal |
| Identity | false label, hidden past, memory, legacy | self-definition, recognition, integration |
| Revenge | concrete violation without consequence | accountability, reversal, refusal to become the same |
| Second chance | prior failure, guilt, lost opportunity | repair through action, earned trust |
| Curiosity | contradiction, missing cause, impossible fact | discovery that changes action |

## Emotional clarity test
The audience should be able to name what hurts or matters **before** they know all the lore.

## Mixed emotions are stronger than pure labels
“Angry” is weak direction. Useful combinations create behavior:
- angry but dependent;
- relieved but ashamed;
- in love but unconvinced;
- triumphant but morally compromised;
- afraid but responsible for someone weaker;
- jealous while knowing the rival is innocent.

## Avoid universalizing one culture’s trope
“Filial duty,” “face,” “status,” “marriage,” “inheritance,” and “career success” vary by context. Keep the human root; adapt the social expression to the world and audience.
