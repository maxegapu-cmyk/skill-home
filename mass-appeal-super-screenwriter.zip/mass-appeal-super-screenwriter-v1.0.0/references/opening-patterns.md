# Reference — Opening Patterns

Patterns describe **dramatic functions**, not copy-ready scenes.

## 1. Promise breaks in public
A person arrives expecting a normal transaction/ceremony/meeting; a promise is visibly violated.
Best for: dignity, betrayal, relationship, workplace.
Risk: generic humiliation if no specific consequence follows.

## 2. Evidence contradicts reality
An object, message, payment, recording, biometric result, or log makes the accepted story impossible.
Best for: suspense, family secrets, crime, science fiction.
Risk: mystery-box spam if the evidence changes no action.

## 3. Deadline arrives early
A future problem becomes immediate: eviction moved up, audit starts now, transport leaves, operation begins, opponent files first.
Best for: grounded drama and thrillers.
Risk: artificial clocks with no credible reason.

## 4. Wrong person gets the consequence
Reward, accusation, arrest, inheritance, invitation, diagnosis, or responsibility lands on someone unexpected.
Best for: comedy, suspense, social drama.
Risk: coincidence unless the cause is later earned.

## 5. Safe relationship becomes unsafe
The protagonist learns the person/place/system they rely on is connected to the threat or secret.
Best for: family, romance, suspense.
Risk: cheap betrayal if no prior behavioral evidence.

## 6. Small rule reveals a large trap
A routine policy or technical detail suddenly makes escape impossible or exposes exploitation.
Best for: workplace, procedural, science fiction, social drama.
Risk: exposition-heavy rule dumping.

## 7. Competence collides with a moral cost
The protagonist can solve the immediate problem, but doing so harms something they value.
Best for: mature action, professional drama, historical.
Risk: fake dilemma when one option is obviously harmless.

## 8. Impossible ordinary moment
The scene looks normal except for one precise contradiction.
Best for: horror, speculative, suspense.
Risk: atmosphere without consequence.

## Selection rule
Choose the pattern that naturally expresses the story’s **first real pressure**. Never pick an opening pattern just because it is loud.
