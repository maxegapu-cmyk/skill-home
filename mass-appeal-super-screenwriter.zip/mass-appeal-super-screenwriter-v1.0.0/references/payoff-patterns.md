# Reference — Payoff Patterns

Use payoff patterns to answer earlier pressure with the **right emotional shape**.

## Competence payoff
Earlier: protagonist is doubted or constrained.
Plant: skill, preparation, domain knowledge, habit.
Pay: skill changes the outcome under pressure.
Avoid: revealing an unmentioned superpower at the moment of need.

## Evidence payoff
Earlier: truth is doubted or hidden.
Plant: trace, contradiction, witness behavior, object, record.
Pay: evidence becomes actionable in the exact arena where truth matters.
Avoid: villain volunteering a confession.

## Boundary payoff
Earlier: protagonist repeatedly yields to protect connection/status/safety.
Plant: escalating cost of yielding.
Pay: protagonist refuses, leaves, names the condition, or accepts the cost.
Avoid: speech-only empowerment with no changed behavior.

## Relationship payoff
Earlier: loyalty is uncertain or damaged.
Plant: choices under smaller pressures.
Pay: someone chooses when the choice costs them.
Avoid: declaring “we are family” without prior behavior.

## Reversal payoff
Earlier: opponent exploits a rule/assumption/leverage.
Plant: limits or blind spots of that mechanism.
Pay: protagonist changes the conditions so the same mechanism turns against the opponent.
Avoid: arbitrary authority override.

## Sacrifice payoff
Earlier: protagonist wants two incompatible things.
Plant: why both matter.
Pay: choosing one proves values and changes future possibility.
Avoid: fake sacrifice immediately refunded with no cost.

## Recognition payoff
Earlier: work, identity, care, or truth is misread.
Plant: evidence through action.
Pay: the right person or institution recognizes it when recognition changes agency/relationship.
Avoid: random crowd applause.

## Meaning payoff
Earlier: protagonist believes success means X.
Plant: consequences that challenge X.
Pay: final choice reframes what victory is.
Avoid: theme speech replacing action.
