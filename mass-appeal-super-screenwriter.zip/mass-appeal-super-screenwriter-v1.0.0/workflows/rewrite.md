# Workflow — Rewrite While Preserving Locked Facts

Use when the story facts, characters, ending, or production constraints are partly fixed but the execution needs stronger conflict, payoff, clarity, or pace.

## Step 1 — Lock table
Separate:
- **LOCKED:** must not change;
- **FLEXIBLE:** execution can change;
- **INFERRED:** current draft implies it, but user did not lock it;
- **BROKEN:** contradicts causality/character intelligence and needs explicit repair.

Never silently change LOCKED material.

## Step 2 — State map
For every scene record state before and after across:
- information;
- power;
- relationship;
- objective;
- danger;
- resources;
- time/constraint.

Scenes with no meaningful state change are candidates to merge, cut, or redesign.

## Step 3 — Preserve function, replace mechanism
When a beat is cliché or implausible, identify what function it serves:
- establishes debt;
- reveals competence;
- forces alliance;
- exposes truth;
- removes an option;
- creates deadline;
- pays an expectation.

Replace the mechanism while preserving the function and locked facts.

## Step 4 — Rewrite causal transitions
Use explicit linkage:
`because A happened, character chooses B; B causes C; C makes D unavoidable or newly desirable.`

If adjacent scenes connect only with “and then,” strengthen causality.

## Step 5 — Restore character intelligence
Give each major character the best move available **according to their knowledge, values, fear, and incentives**. Drama comes from incompatible good moves, incomplete information, cost, and consequence—not forced stupidity.

## Step 6 — Rebalance debt/payoff
If the original built an expectation, preserve or consciously transform it. Do not delete a promised payoff without replacing the audience contract.

## Step 7 — Dialogue rewrite
For each exchange define what each person wants from the other. Make lines tactics: conceal, pressure, recruit, deflect, test, comfort, accuse, bargain, provoke, protect, delay, confess. Remove lines that only tell the audience facts.

## Rewrite output
- locked/flexible table;
- root structural change;
- revised scene/episode;
- concise explanation of what was preserved and what mechanism changed;
- gate verdict.
