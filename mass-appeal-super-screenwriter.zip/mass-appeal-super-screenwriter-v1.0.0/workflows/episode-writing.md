# Workflow — Episode / Sequence Writing

Use for short drama episodes, vertical video chapters, web series, episodic scenes, or any sequence that must create immediate attention and a reason to continue.

## Episode contract
An episode must do three things:
1. **Deliver:** pay or materially advance something already promised.
2. **Change:** alter facts, power, relationship, danger, agency, or strategy.
3. **Launch:** create a next expectation from the consequence of that change.

## Step 1 — Incoming state
Write five lines:
- protagonist goal entering;
- unresolved expectation entering;
- active emotional debt;
- opposition’s current leverage;
- one fact the audience knows that matters now.

## Step 2 — Opening beat
Do not reset. The episode should inherit pressure from the prior unit or create a new consequential event immediately. Re-establish only what is necessary for comprehension.

## Step 3 — 3–7 beat causal spine
For each beat:
`goal -> resistance -> tactic -> result -> state change`

A beat may be quiet. It may not be inert.

## Step 4 — Satisfaction placement
Choose at least one meaningful local delivery:
- answer a question;
- expose a lie;
- reclaim some agency;
- let competence work;
- force an opponent to adapt;
- make a relationship decision;
- settle part of a debt.

Do not postpone every desired event to the next episode.

## Step 5 — Turn
If the episode has a reveal, verify:
- earlier material supports it;
- it changes what a character can/must do;
- it is not merely a new name, villain, or secret title.

## Step 6 — Exit hook
The final beat should be one of:
- a forced choice;
- a consequence arriving;
- a plan colliding with new information;
- a relationship crossing a point of no return;
- a deadline tightening;
- a fact that changes the next action.

Write the exact **next action implied by the hook**. If none exists, the hook is probably decorative.

## Dialogue pass
Compress after structure works:
- enter late, exit early;
- each speaker wants something from the exchange;
- unequal knowledge should produce subtext or leverage;
- let interruptions, evasions, objects, and actions carry meaning;
- remove explanations both characters already know;
- distinguish voices by priorities, vocabulary, risk tolerance, and social power—not gimmicky catchphrases.

## Episode audit card
- Existing promise delivered? yes/no + evidence
- State change? state before → state after
- Debt changed? opened / intensified / partially paid / settled / transformed
- Payoff family used?
- Escalation axis changed?
- Character intelligence protected?
- Exit hook causal?
- Last three episode payoffs repetitive?

Any “no” on delivery, state change, or causal hook triggers structural rewrite before polish.
