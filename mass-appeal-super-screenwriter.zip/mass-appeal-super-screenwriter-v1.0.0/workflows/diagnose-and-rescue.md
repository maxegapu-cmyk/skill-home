# Workflow — Diagnose & Rescue

Use when a draft “has events” but does not grip, feels AI-written, repeats itself, becomes confusing, or delivers weak satisfaction.

## Rule: preserve before replacing
List assets worth keeping:
- locked facts/user requirements;
- strong character relationships;
- memorable objects/locations;
- genuinely good scenes;
- planted clues;
- promises already made to the audience.

Do not rebuild everything just because one engine is broken.

## Diagnostic order
Always diagnose from deepest to shallowest.

### 1. Engine failure
Can the premise generate consequences after the first obvious payoff?
**Symptom:** outline becomes “another person challenges protagonist.”
**Repair:** change what victory causes, not the costume of the next opponent.

### 2. Desire failure
Is the protagonist’s active want legible and costly?
**Symptom:** protagonist mostly receives events.
**Repair:** give them an urgent decision or pursuit that can be opposed.

### 3. Opening failure
Does the opening cause a state change?
**Symptom:** lore, waking up, driving, workplace montage, narrated biography.
**Repair:** start at the first event that forces choice/loss/exposure, then backfill only essential context.

### 4. Debt/payoff failure
Did the story make the audience want something and then pay something else?
**Symptom:** “technically the hero won” but it feels hollow.
**Repair:** map the original wound to an emotionally homologous payoff.

### 5. Escalation failure
Are later conflicts different only in volume, location, or villain rank?
**Repair:** escalate meaning, relationship, constraint, agency, or moral cost.

### 6. Turn failure
Do twists update the audience model and change action?
**Symptom:** secret after secret with no consequence.
**Repair:** merge trivia reveals; preserve only ones that redirect strategy or meaning.

### 7. Character intelligence failure
Would a reasonable character solve the plot by doing an obvious thing?
**Repair:** establish a legitimate constraint/conflict of values; if that becomes contrived, rewrite the outcome.

### 8. Dialogue/pacing failure
Only after structure passes, compress redundant explanation, sharpen tactics, and remove repeated beats.

## Rescue output
Return:
1. verdict: usable / rescueable / engine replacement required;
2. top three root failures in severity order;
3. evidence from the draft;
4. smallest repair that fixes each root;
5. revised causal spine;
6. only then, rewritten scenes if requested.

## Do not cosmetically rescue structural failure
Faster cuts, more insults, extra explosions, bigger music cues, shorter lines, or additional cliffhangers cannot substitute for causality and payoff.
