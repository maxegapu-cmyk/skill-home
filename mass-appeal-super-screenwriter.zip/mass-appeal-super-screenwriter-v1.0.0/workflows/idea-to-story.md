# Workflow — Idea to Story

Use this when the input is a premise, logline, trope, theme, news-like event, character, image, or vague “I want something爽/抓人”.

## 1. Preserve the seed
Write a one-line **Seed** containing only facts the user actually supplied. Separate locked facts from assumptions. Do not “improve” the idea by silently replacing it.

## 2. Premise triage
Answer four questions before pages:
- **Instant read:** can a general viewer understand the central human situation quickly?
- **Desire:** what does the protagonist actively want now?
- **Pressure:** what credible force makes that difficult?
- **Engine:** if the first obvious payoff happens, what new problem can grow from its consequence?

If the engine answer is weak, rescue the premise first. Do not compensate with more villains or louder dialogue.

## 3. Define the audience promise
State one sentence:
> “People keep watching because they want to see whether/how ___.”

Then state the emotional promise: justice, escape, recognition, revenge, repair, discovery, forbidden attraction, competence, protection, reconciliation, survival, etc.

## 4. Build the protagonist pressure map
Record:
- immediate desire;
- visible external stake;
- private/relational meaning;
- strength/resource;
- blind spot or constraint;
- line they do not want to cross;
- what would force them to change strategy.

Do the same for the main opposition, but phrase them as pursuing their own goal rather than existing to be defeated.

## 5. Design the Nuclear Opening
Use `core/nuclear-opening.md`.
Output:
- opening event;
- state before;
- state after;
- forced question/choice;
- next action caused by it.

Reject any version that can be replaced by exposition without changing the plot.

## 6. Start the Emotional Debt Ledger
Use `core/emotional-debt.md`.
Create only debts the story intends to honor. For each major debt specify the expected payoff form. Avoid five variants of the same humiliation.

## 7. Build an escalation ladder
Create 5–9 major moves for a short story/film unit, or an arc-level ladder for a series.
For each:
`problem -> protagonist action -> consequence -> changed problem`
Label the axis that escalated: scale, cost, constraint, meaning, relationship, agency, moral pressure.

If two adjacent moves escalate on no meaningful axis, merge or redesign.

## 8. Place turns
Use `core/turn-and-reveal.md`. Major turns should:
- have prior causal support;
- change strategy or meaning;
- immediately affect what someone can do.

Do not schedule twists by timer. Put them where accumulated causes make a model update potent.

## 9. Build payoff/chase structure
For every sequence or episode:
- what expectation enters;
- what progress is delivered;
- what debt is partially/fully paid;
- what larger causal expectation leaves.

A unit that only opens questions is withholding. A unit that only closes questions may feel finished. Alternate closure and expansion.

## 10. Draft beats, then scenes
Each scene must have:
- a current want;
- resistance;
- a tactic;
- a state change;
- a handoff to the next scene.

When dialogue carries information, make the information change leverage, relationship, or choice. Otherwise put it in action or cut it.

## 11. Audit before polish
Run `evaluation/script-gates.md` and `evaluation/scroll-away-test.md`.
Repair structural failures before line-level polish. Pretty dialogue cannot rescue a dead engine.

## Default creation output
1. One-line hook
2. Audience promise
3. Protagonist desire + cost
4. Opposition
5. Nuclear opening
6. Escalation ladder
7. Emotional debt/payoff map
8. Beat/episode outline
9. Requested scene(s)
10. Audit verdict and structural repairs
