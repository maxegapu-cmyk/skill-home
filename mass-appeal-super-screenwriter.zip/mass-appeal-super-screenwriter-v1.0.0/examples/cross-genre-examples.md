# Original Cross-Genre Examples

These are compact demonstrations of **different engines and payoff forms**, not templates to copy.

## 1. Urban — The Deposit Night
**Hook:** A delivery rider learns the landlord has gambled away every tenant’s deposit the night before an elderly neighbor is due to move into assisted housing.
**Nuclear opening:** the neighbor’s new facility calls: payment must clear by midnight or the room goes to someone else.
**Escalation:** recovering his own money → discovering all deposits are gone → realizing police action freezes the remaining account → choosing between immediate recovery and preserving evidence against a larger rental scam.
**Payoff:** outplay/evidence; he uses delivery-route timestamps and tenant transfers to reconstruct where the money moved, gaining leverage without a magical authority rescue.

## 2. Family — The Edited Last Wish
**Hook:** At their father’s funeral, a daughter hears a voice recording that disinherits her—then notices the background clock chimes a time when he was already in surgery.
**Nuclear opening:** the family announces the inheritance decision publicly before she can verify the recording.
**Escalation:** prove edit → discover protective sibling made it → learn the edit concealed father’s coercive debt → choose whether exposing the truth saves her name but ruins the sibling who once saved her.
**Payoff:** truth + relationship choice; recognition matters because it changes trust and future obligation, not because a crowd applauds.

## 3. Historical — The Grain Ledger
**Hook:** A junior granary clerk finds relief grain totals that are mathematically perfect but physically impossible because every cart would need to cross a flooded bridge.
**Nuclear opening:** the inspector praises the records and orders the clerk to seal them before dawn.
**Escalation:** arithmetic suspicion → route verification → false official target → discovery that grain exists but is being diverted to buy political loyalty → exposing theft may trigger local starvation sooner.
**Payoff:** competence and moral choice; the clerk proves diversion through cart-wheel wear and chooses a release plan that protects civilians before naming culprits.

## 4. Suspense — The Thirteenth Floor
**Hook:** An elevator opens on a floor that is absent from the building plan, and a child standing there greets the protagonist by a childhood nickname no resident knows.
**Nuclear opening:** the doors close before she can reach the child; the elevator log says she never stopped there.
**Escalation:** verify floor → residents deny it → maintenance records show a sealed service level → protagonist learns her missing mother worked in the building decades earlier → the “ghost floor” is a real hidden access route tied to a current crime.
**Payoff:** discovery; the impossible fact becomes actionable evidence, not endless supernatural teasing.

## 5. Science Fiction — Memory Rent
**Hook:** Workers can sell eight hours of memory for cash; a woman receives payment for a memory she never authorized for sale.
**Nuclear opening:** the transaction receipt lists tomorrow’s date.
**Escalation:** billing error → stolen future memory → company predicts and pre-purchases high-value experiences → protagonist learns refusing the event may erase the evidence she needs → must decide whether to walk knowingly into the experience being harvested.
**Payoff:** agency/choice; she changes the event’s meaning by staging a memory that incriminates the buyer while preserving a private truth outside the rentable window.

## 6. Comedy — The Wrong Negotiator
**Hook:** A timid appliance repairman enters the wrong apartment during a livestream and is introduced to thousands of viewers as the city’s famous crisis negotiator.
**Nuclear opening:** the actual standoff next door spills into the hallway, and everyone turns to him for a decision.
**Escalation:** fake confidence → improvised appliance knowledge unexpectedly helps → livestream fame makes admitting the truth harder → real negotiator arrives but is locked outside by the building’s ridiculous smart system → repairman must stop performing and use the one thing he actually knows.
**Payoff:** competence/recognition; his ordinary expertise resolves the absurd problem, while the lie is exposed rather than rewarded forever.

## 7. Romance — The Borrowed Dress
**Hook:** A seamstress recognizes her late mother’s one-of-a-kind wedding dress on a bride who once publicly stole credit for the seamstress’s design work.
**Nuclear opening:** the bride asks her to repair a tear minutes before the ceremony without recognizing her.
**Escalation:** refuse or repair → discover bride bought the dress unknowingly from the seamstress’s estranged aunt → old plagiarism wound resurfaces → bride learns the truth and offers public credit, but accepting it during the wedding would hijack someone else’s day.
**Payoff:** boundary + recognition; the seamstress takes authorship back on her own terms after the ceremony and chooses whether this relationship has a future.

## 8. Crime — The Wrong Evidence Bag
**Hook:** An evidence technician sees an object in the bag that convicted a violent gang leader—an object he personally logged in an unrelated burglary case.
**Nuclear opening:** the convicted man’s appeal hearing starts in two hours, and reporting the mismatch may expose the technician’s closest colleague.
**Escalation:** verify barcode → discover chain-of-custody swap → colleague claims it was to stop a killer escaping → original burglary object connects to a police informant → correcting one conviction may collapse several cases and release dangerous people.
**Payoff:** procedural outplay/moral choice; the technician builds an independently verifiable chain instead of trusting either side and accepts career cost to prevent a false record from becoming permanent.

## Diversity check
Payoff families used across examples: evidence/outplay, relationship choice, competence/moral choice, discovery, agency, competence/recognition, boundary/recognition, procedural accountability. No single status-reveal mechanism is the default engine.
