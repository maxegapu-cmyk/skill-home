# Original Premise Rescue Example

## Weak input
“An ordinary person suddenly becomes rich and everyone who looked down on them regrets it.”

## Diagnosis
**Verdict: REBUILD ENGINE.**

The first reveal can create one satisfying reversal, but the premise has weak durability if later episodes are only new people underestimating the protagonist. Wealth is a resource, not yet a story engine.

### Root failures
1. **Desire is missing:** “be rich” has already happened before the story starts.
2. **Opposition is generic:** “people who looked down on them” is a crowd, not a force with a goal.
3. **Escalation is horizontal:** restaurant/hotel/reunion variants all create the same emotional debt and same payoff.

## Rescue: keep wealth, change what it causes
**New hook:** A debt-collection clerk unexpectedly inherits a failing neighborhood loan company and discovers that half the people who once mocked him now owe it money—including the family who raised him.

### Audience promise
Will he use money to become the kind of person who humiliated him, or can he survive a business whose profit depends on hurting people he knows?

### Nuclear opening
On his first morning as owner, an automated eviction order bearing his new signature is delivered to his foster mother.

### Durable engine
Every attempt to “fix” one debt changes another part of the system:
- cancel foster mother’s debt → other borrowers demand equal treatment;
- pause collections → employees may lose wages and the company defaults;
- sell the company → buyer plans harsher collections;
- investigate old contracts → discover the previous owner used illegal fees to hide a much larger fraud;
- expose fraud → legitimate borrowers may lose access to emergency credit.

### Emotional debt
The protagonist knows what humiliation by money feels like. The audience expects him not merely to flex wealth, but to decide what kind of power he will exercise when he finally has it.

### Payoff diversity
Use competence, boundary, evidence, sacrifice, relationship choice, and structural consequence. A public status reveal may occur once if causally useful, but it is not the repeating engine.

## Why the rescue is stronger
We kept the accessible fantasy—“ordinary person suddenly has money”—but converted wealth from a **final answer** into a **pressure-generating responsibility**. The story can now escalate through ethics, relationships, institutions, reputation, and survival without repeating the same face-slap scene.
