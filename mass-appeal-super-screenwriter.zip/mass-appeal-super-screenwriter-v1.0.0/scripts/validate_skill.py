#!/usr/bin/env python3
"""Deterministic release validator for mass-appeal-super-screenwriter."""
from __future__ import annotations

import re
import sys
from pathlib import Path

REQUIRED = [
    "SKILL.md",
    "core/nuclear-opening.md",
    "core/mass-desire.md",
    "core/emotional-debt.md",
    "core/satisfaction-engine.md",
    "core/escalation-engine.md",
    "core/turn-and-reveal.md",
    "core/chase-engine.md",
    "core/anti-routine.md",
    "workflows/idea-to-story.md",
    "workflows/episode-writing.md",
    "workflows/diagnose-and-rescue.md",
    "workflows/rewrite.md",
    "references/mass-emotions.md",
    "references/opening-patterns.md",
    "references/payoff-patterns.md",
    "references/genre-adaptation.md",
    "evaluation/scroll-away-test.md",
    "evaluation/script-gates.md",
    "examples/cross-genre-examples.md",
    "examples/premise-rescue.md",
    "scripts/validate_skill.py",
]

REQUIRED_CONCEPTS = [
    "state change",
    "emotional debt",
    "causal",
    "retrospective",
    "character intelligence",
    "repetition",
    "scroll-away",
]

PLACEHOLDERS = [
    re.compile(r"\bTBD\b", re.I),
    re.compile(r"\bTODO\b", re.I),
    re.compile(r"fill\s+in\s+later", re.I),
    re.compile(r"implement\s+later", re.I),
]

MD_LINK = re.compile(r"\[[^\]]+\]\(([^)]+\.md)(?:#[^)]+)?\)")


def fail(errors: list[str]) -> int:
    print("VALIDATION FAILED")
    for item in errors:
        print(f"- {item}")
    return 1


def validate(root: Path) -> int:
    errors: list[str] = []
    root = root.resolve()

    if not root.is_dir():
        return fail([f"not a directory: {root}"])

    for rel in REQUIRED:
        if not (root / rel).is_file():
            errors.append(f"missing required file: {rel}")

    skill_path = root / "SKILL.md"
    skill_text = skill_path.read_text(encoding="utf-8") if skill_path.is_file() else ""

    if skill_text:
        if not skill_text.startswith("---\n"):
            errors.append("SKILL.md must start with YAML frontmatter")
        else:
            parts = skill_text.split("---", 2)
            if len(parts) < 3:
                errors.append("SKILL.md frontmatter is not closed")
            else:
                front = parts[1]
                if len(front) > 1024:
                    errors.append("SKILL.md frontmatter exceeds 1024 characters")
                if not re.search(r"^name:\s*[a-z0-9-]+\s*$", front, re.M):
                    errors.append("frontmatter name must use lowercase letters, digits, hyphens")
                desc = re.search(r"^description:\s*(.+)$", front, re.M)
                if not desc or not desc.group(1).startswith("Use when"):
                    errors.append("description must start with 'Use when'")

    markdown_files = list(root.rglob("*.md"))
    corpus = "\n".join(p.read_text(encoding="utf-8") for p in markdown_files).lower()

    for concept in REQUIRED_CONCEPTS:
        if concept not in corpus:
            errors.append(f"missing required concept: {concept}")

    for path in markdown_files:
        text = path.read_text(encoding="utf-8")
        for pattern in PLACEHOLDERS:
            if pattern.search(text):
                errors.append(f"placeholder found in {path.relative_to(root)}: {pattern.pattern}")
        for target in MD_LINK.findall(text):
            if target.startswith(("http://", "https://")):
                continue
            resolved = (path.parent / target).resolve()
            try:
                resolved.relative_to(root)
            except ValueError:
                errors.append(f"link escapes release root in {path.relative_to(root)}: {target}")
                continue
            if not resolved.is_file():
                errors.append(f"broken markdown link in {path.relative_to(root)}: {target}")

    examples = root / "examples/cross-genre-examples.md"
    if examples.is_file():
        text = examples.read_text(encoding="utf-8").lower()
        domains = ["urban", "family", "historical", "suspense", "science fiction", "comedy", "romance", "crime"]
        for domain in domains:
            if domain not in text:
                errors.append(f"cross-genre examples missing domain: {domain}")

    if errors:
        return fail(errors)

    print(f"VALIDATION PASSED: {len(REQUIRED)} required files, {len(markdown_files)} markdown files, 0 errors")
    return 0


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    return validate(root)


if __name__ == "__main__":
    raise SystemExit(main())
