---
name: mass-appeal-super-screenwriter
description: Use when creating, diagnosing, rescuing, or rewriting screen stories that need broad audience readability, immediate conflict, sustained emotional payoff, strong episode hooks, or relief from repetitive AI-style plotting across short drama, film, series, vertical video, or narrative ads.
---

# Mass Appeal Super Screenwriter

## Core principle
Write for **low comprehension cost and high emotional voltage**. Mass appeal is not stupidity. A story becomes easy to follow by making desire, pressure, consequence, and change legible—not by flattening characters.

## Route by task
- New premise or weak idea → [Idea to Story](workflows/idea-to-story.md)
- Episode/sequence/page writing → [Episode Writing](workflows/episode-writing.md)
- Existing draft is dull, repetitive, confusing, or unsatisfying → [Diagnose & Rescue](workflows/diagnose-and-rescue.md)
- Preserve facts but rewrite execution → [Rewrite](workflows/rewrite.md)

## Eight engines
1. **Nuclear Opening** — something consequential happens now. [Rules](core/nuclear-opening.md)
2. **Mass Desire** — anchor motivation in a desire the audience can read without explanation. [Rules](core/mass-desire.md)
3. **Emotional Debt** — pressure creates a specific expectation for later repayment. [Rules](core/emotional-debt.md)
4. **Satisfaction** — payoff must settle a debt, change agency, or reveal earned meaning. [Rules](core/satisfaction-engine.md)
5. **Escalation** — later conflict must change scale, dimension, cost, or meaning. [Rules](core/escalation-engine.md)
6. **Turn & Reveal** — a turn updates the audience model and is retrospectively causal. [Rules](core/turn-and-reveal.md)
7. **Chase** — resolve/advance one expectation while opening a causally larger one. [Rules](core/chase-engine.md)
8. **Anti-Routine** — preserve character intelligence and reject repetition, coincidence rescue, fake conflict, and trope autopilot. [Rules](core/anti-routine.md)

## Non-negotiable gates
A strong scene causes a **state change**. A real turn is **retrospective** as well as surprising. A payoff closes or transforms **emotional debt**. A cliffhanger is **causal**, not an arbitrary cut. Protect **character intelligence**. Detect **repetition** before polish. Run the [Scroll-Away Test](evaluation/scroll-away-test.md) and [Script Gates](evaluation/script-gates.md) before calling a draft ready.

## Quick Reference
| Symptom | First place to inspect |
|---|---|
| Opening feels slow | Nuclear Opening |
| “爽了但没感觉” | Emotional Debt → Satisfaction |
| Episodes feel copied | Escalation → Anti-Routine |
| Twist feels random | Turn & Reveal |
| Ending feels like a cheap cut | Chase |
| Characters act stupid | Anti-Routine / Character Intelligence |

## Common Mistakes
- Treating louder dialogue as stronger conflict.
- Using hidden status, sudden money, or authority intervention as a universal payoff.
- Adding new villains instead of changing the problem.
- Saving every satisfying event for the finale.
- Polishing dialogue before the premise engine, causality, and debt/payoff structure work.

## Output contract
For substantial creation, return: **hook → audience promise → protagonist desire/cost → opposition → opening event → escalation ladder → debt/payoff map → beats/episodes → requested scene draft → audit verdict → repairs for failed gates**. If the premise cannot sustain escalation, diagnose and rebuild it before writing pages.
