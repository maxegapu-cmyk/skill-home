# Nuclear Opening

The opening is not “high energy.” It is an **irreversible or costly state change the audience can understand immediately**.

## Opening contract
Within the earliest usable beat, establish four readable facts:
1. **Someone wants something now.**
2. **Something blocks, threatens, exposes, steals, reverses, or complicates it.**
3. **The event has a consequence if ignored.**
4. **The protagonist must choose, react, or lose position.**

Do not require biography, lore, genealogy, career history, or a narrator explaining why the moment matters before the audience can feel it.

## Valid opening sources
Use the source that belongs to this story; do not cycle them mechanically.

| Source | Event | Immediate audience question |
|---|---|---|
| Violation | a boundary, promise, rule, or trust is broken | “What will they do?” |
| Exposure | hidden information becomes dangerous | “Who knows, and what does it cost?” |
| Loss | money, status, safety, person, evidence, opportunity disappears | “Can it be recovered?” |
| Collision | two incompatible goals meet in one place | “Who yields?” |
| Reversal | expected advantage becomes liability | “How did this happen?” |
| Deadline | a choice becomes time-limited | “Can they act before it closes?” |
| Impossible fact | reality contradicts the character’s model | “Which assumption is wrong?” |

## The fake-conflict detector
An opening fails if removing the shouting, insults, music, or camera intensity leaves the situation essentially unchanged.

Ask: **What is different at the end of this beat?** Valid answers include information, power, relationship, safety, resources, obligation, reputation, freedom, time, or available choices. If the answer is “everyone is angrier,” strengthen the event.

## Internal candidate competition
Before committing to an opening, privately generate **three structurally different** candidates that use different conflict sources or state changes. Compare them on immediate readability, consequence, forced response, causal expansion, and whether the rest of the story becomes richer rather than merely louder. **Select one** that best serves the premise. Unless the user explicitly asks for options, **do not show all three**; deliver the strongest selected opening and continue.

Reject a candidate if it wins only because it is more shocking. Prefer the one whose consequence produces the best next action and the strongest long-term engine.

## Pressure without melodrama
Use specific consequences. “You will regret this” is weak. “The train leaves in nine minutes and your daughter’s passport is in his locked desk” is pressure because action is forced.

## Restraint rule
Do not spend every opening at maximum volume. Quiet openings can be nuclear when the fact is destabilizing: a bank transfer from a dead person; a child calling a stranger “Dad”; a missing object appearing in sealed evidence.

## Opening handoff
The opening must hand the story to the next engine: it creates a desire, threat, emotional debt, mystery, or forced choice that can escalate. If it only produces spectacle, it is a trailer shot, not a story engine.
