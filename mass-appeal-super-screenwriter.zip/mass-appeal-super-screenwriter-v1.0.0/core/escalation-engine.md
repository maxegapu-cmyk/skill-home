# Escalation Engine

Escalation means **the problem becomes different in a consequential way**, not merely louder, richer, or populated by a stronger villain.

## Escalation axes
Change at least one major axis; strong sequences often change two.
- **Scale:** more people, territory, time, money, or systems are affected.
- **Cost:** failure now risks something the protagonist values more.
- **Constraint:** fewer safe options, less time, worse information, tighter rules.
- **Meaning:** new truth changes what winning or losing represents.
- **Relationship:** ally/opponent/dependent roles change.
- **Agency:** protagonist gains or loses ability to act.
- **Moral pressure:** success now requires sacrificing another value.

## Ladder test
For each major beat write:
`previous problem -> protagonist action -> consequence -> changed problem`

If “changed problem” can be described as “the same thing in another location with a bigger jerk,” the beat is repetition, not escalation.

## Horizontal repetition detector
Typical failure:
restaurant rejection → hotel rejection → club rejection → reunion rejection.
The setting changes, the emotional debt and payoff mechanism do not.

Repair by changing dimension:
rejection → protagonist wins access → access exposes a family conflict → solving it threatens a friendship → friend becomes the only person who can verify the truth.

## Controlled breathing
Escalation does not require constant acceleration. After a major turn, allow a short decompression beat that changes relationship, strategy, or understanding. Breathing that changes nothing is filler; breathing that reorients the next move is structure.

## Ceiling rule
Do not escalate beyond the story’s emotional frame. A neighborhood comedy does not need a national conspiracy. Increase **relevance**, not merely magnitude.
