# Anti-Routine

This module protects **character intelligence, causal integrity, and variety**. It is not a ban on tropes; it is a ban on autopilot.

## Character intelligence gate
Characters may be ignorant, emotional, biased, frightened, vain, or wrong. They may not forget obvious knowledge or refuse obvious actions solely because the plot needs delay.

For every “why don’t they just…?” objection, answer with an established constraint: cost, uncertainty, law, loyalty, fear, time, incomplete evidence, incompatible goals, or credible misbelief.

## Coincidence budget
Coincidence may create trouble. It should rarely solve the central trouble. The larger the benefit to the protagonist, the more the solution should arise from prior choice, skill, relationship, evidence, or sacrifice.

## Trope mutation
Before using a familiar beat, identify:
- the audience expectation the trope normally creates;
- the emotional function you actually need;
- one variable that can change the consequence, viewpoint, cost, or moral meaning.

Do not mutate merely by changing costume or setting.

## Repetition scan
Compare the last three major beats across:
- source of pressure;
- location/social context;
- protagonist tactic;
- payoff family;
- winner/loser pattern;
- information movement;
- emotional texture.

If four or more are effectively identical, redesign the beat.

## AI-dialogue warnings
Cut lines that:
- explain what both characters already know;
- summarize the theme out loud;
- repeat the same threat in stronger adjectives;
- state emotion instead of creating behavior that reveals it;
- make every character equally articulate and self-aware.

## Anti-stupid repair order
When a plot only works because someone acts irrationally:
1. keep the intended outcome;
2. identify the rational action that would break it;
3. add a legitimate constraint or conflicting value;
4. if that becomes contrived, change the outcome instead.

Do not pile excuses onto a broken beat.
