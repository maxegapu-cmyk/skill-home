# Satisfaction Engine

“Satisfying” is not synonymous with “the protagonist wins.” Satisfaction comes from **earned agency, debt repayment, truth landing, competence becoming visible, or a meaningful choice producing consequence**.

## Payoff families
Rotate by causal fit, not novelty for its own sake.

| Family | What changes |
|---|---|
| Reversal | pressure returns toward its source |
| Recognition | truth, competence, sacrifice, or identity becomes correctly seen |
| Recovery | stolen agency/resource/relationship is reclaimed or redefined |
| Outplay | protagonist uses information, timing, rules, or opponent assumptions better |
| Boundary | protagonist refuses a pattern that previously controlled them |
| Exposure | hidden cause or motive becomes actionable |
| Rescue | someone previously powerless can now protect self/other |
| Choice | protagonist finally chooses between incompatible values |
| Consequence | a prior action produces unavoidable cost or reward |
| Transformation | the desired thing is reinterpreted, rejected, or gained at a meaningful price |

## Earned payoff test
Before a major payoff, confirm at least two:
- the audience was made to want it;
- the protagonist paid a cost or made a choice;
- earlier information/skill/relationship enables it;
- the antagonist or obstacle had a real chance to win;
- the payoff changes the next problem rather than ending all pressure.

## Empty-satisfaction warnings
- surprise inheritance fixes unrelated problems;
- authority arrives solely to validate the protagonist;
- antagonist confesses without pressure;
- hidden status solves every conflict;
- crowd applause substitutes for changed reality;
- protagonist wins using a capability introduced in the same beat.

## Payoff diversity
Track the last three major payoffs. If they use the same mechanism—especially status reveal, public humiliation reversal, sudden money, or authority intervention—change the causal route. Repetition can be intentional only when the story is escalating the cost or meaning of the repeated pattern.
