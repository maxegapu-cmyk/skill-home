# Emotional Debt Ledger

Pressure matters when it creates a **specific audience expectation for restitution, truth, recognition, escape, or consequence**. Track that expectation as emotional debt.

## Debt record
For every major pressure beat, record:
- **Trigger:** exactly what happened.
- **Debtor:** who caused or benefits from the wrong/imbalance.
- **Bearer:** who carries the cost.
- **Audience expectation:** what viewers now want to see corrected, exposed, protected, avenged, understood, or chosen.
- **Visibility:** private / witnessed / public.
- **Payoff form:** the kind of event that would actually settle or transform the debt.
- **Maturity:** now / later / season-long.

## Matching principle
Payoff should answer the form of the wound.
- Public humiliation → public recognition, reversal, boundary, or consequence usually carries more weight than a secret win.
- Theft of agency → restored choice matters more than receiving money.
- False accusation → truth becoming actionable matters more than villain suffering elsewhere.
- Betrayal → confrontation, choice, accountability, or redefined relationship is stronger than an unrelated victory.

The payoff need not be symmetrical, but it must be **emotionally homologous**: it answers the thing that hurt.

## Debt stacking
Do not stack endless suffering just to “make the later payoff bigger.” New pressure should change the debt’s meaning or difficulty. If three beats create the same expectation, compress them.

## Partial settlement
A good long-form story often settles a smaller debt while revealing a larger one. Example: the protagonist proves one accusation false, but learns the accuser was covering for someone they love. The audience receives progress, then inherits a deeper question.

## Default rule
Never delay all satisfaction to the finale. Give local repayments along the way so trust accumulates: the story proves it will eventually honor the audience’s investment.
