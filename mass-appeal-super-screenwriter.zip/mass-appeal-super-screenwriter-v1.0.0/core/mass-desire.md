# Mass Desire

Mass-market clarity comes from **recognizable human stakes**, not generic characters.

## Desire test
A protagonist desire is usable when the audience can complete this sentence without explanation:

> “They need/want ___ because if they fail, ___ will be lost, damaged, exposed, or never recovered.”

## Universal desire families
Use these as emotional roots, not plot templates:
- survival and physical safety
- money, shelter, work, or material stability
- dignity and freedom from humiliation/control
- love, belonging, family, loyalty, and protection
- fairness, truth, restitution, and being believed
- competence, achievement, recognition, and winning
- autonomy, escape, privacy, and control over one’s life
- identity, meaning, memory, legacy, and keeping a promise
- revenge or accountability after a concrete violation
- second chances, repair, forgiveness, or recovery

## Double stake
Whenever possible pair:
- **external stake**: what can visibly be gained/lost;
- **internal or relational stake**: what the outcome means to the character.

Example: “keep the restaurant open” is clearer when closing it also means breaking a promise to a deceased parent or abandoning employees who trusted the protagonist.

## Specificity beats magnitude
“Save the world” is abstract unless localized. “Keep the last evacuation bus from leaving without his sister” is immediately legible. Large stories should still be felt through a concrete person, object, promise, deadline, or place.

## Audience alignment
The audience does not need to approve of the protagonist’s desire. They need to **understand it and predict what failure means**. Ambition, revenge, jealousy, greed, or obsession can work when the motive is legible and consequences are honest.

## Desire mutation
Desires may evolve after turns. When they do, preserve causality:
- initial desire creates action;
- action exposes new truth/cost;
- new truth makes the old goal insufficient or morally altered;
- protagonist chooses a revised goal.

A random new mission is not development.
