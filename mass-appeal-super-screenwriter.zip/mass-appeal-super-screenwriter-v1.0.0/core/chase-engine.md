# Chase Engine

Watchability is a chain of **open expectations with visible progress**. Do not confuse mystery with withholding everything.

## Expectation loop
At any meaningful unit—beat, scene, sequence, episode—track:
1. **Open:** what does the audience now want to know/see happen?
2. **Advance:** what concrete progress or complication occurs?
3. **Pay:** what part of the expectation is answered, demonstrated, or transformed?
4. **Re-open:** what causally larger or sharper expectation emerges?

## Three loop lengths
- **Micro loop:** seconds to a scene; maintains immediate attention.
- **Sequence loop:** several scenes; carries a plan, confrontation, investigation, or relationship shift.
- **Long loop:** episode/arc/season promise; should receive partial evidence, not total silence.

## Honest cliffhangers
A cliffhanger is earned when the active causal chain produces a new decision, danger, fact, arrival, deadline, or contradiction at the boundary.

Avoid:
- cutting before a routine answer that arrives unchanged next episode;
- fake death/attack with no consequence;
- hiding information the viewpoint character plainly knows;
- introducing an unrelated emergency because the episode is ending.

## Progress rule
Each episode should deliver at least one meaningful thing the audience came for. Constant postponement teaches viewers that investment is not rewarded.

## Question quality
Prefer questions that imply action:
- “Can she prove the ledger was altered before the audit?”
- “Will he protect his brother after learning who caused the crash?”
Over vague questions:
- “What will happen next?”
