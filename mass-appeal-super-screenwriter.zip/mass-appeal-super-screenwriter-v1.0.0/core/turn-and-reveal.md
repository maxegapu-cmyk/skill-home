# Turn & Reveal

A turn is a **model update**. The audience learns, realizes, or witnesses something that changes the meaning of facts, motives, power, relationships, or available action.

## Five useful turn types
- **Fact turn:** a believed fact is incomplete or wrong.
- **Motive turn:** the same action is reinterpreted through a new motive.
- **Power turn:** who can act, decide, expose, protect, or punish changes.
- **Relationship turn:** loyalty, dependency, kinship, debt, or betrayal changes meaning.
- **Choice turn:** new information makes the previous plan impossible, insufficient, or morally costly.

## Retrospective causality
A strong reveal creates two reactions at once:
1. “I did not predict that exact answer.”
2. “Now that I know, earlier details make more sense.”

Plant causes, behavior, objects, contradictions, or absences that become legible after the reveal. Do not plant neon signs that spoil the answer.

## Surprise vs randomness
Randomness adds an event from outside the active causal chain. A turn reinterprets or redirects the chain already in motion.

Weak: a stranger appears and solves the case.
Strong: the “irrelevant” repair receipt established earlier proves the supposedly broken camera was functioning.

## Turn economy
Do not twist every scene. Small turns can be tactical; major turns should change strategy or meaning. If every beat declares “actually…”, audience trust collapses and nothing feels stable enough to matter.

## Reveal consequence
After revealing, immediately ask: **What can someone now do that they could not do before?** If the answer is “nothing,” the reveal may be trivia rather than drama.
