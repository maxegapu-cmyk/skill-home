# Evaluation — Script Gates

Run gates in order. Do not polish dialogue before structural gates pass.

## G0 — Premise Engine
**Pass when:** after the first obvious payoff, consequences naturally create another meaningful problem.
**Fail symptom:** outline becomes a queue of challengers.
**Repair:** make victory cause a new constraint, relationship problem, moral cost, or truth.

## G1 — Audience Readability
**Pass when:** desire, opposition, and failure cost are understandable without background lecture.
**Fail symptom:** nouns and lore arrive before human stakes.
**Repair:** localize the conflict and defer world explanation until it changes action.

## G2 — Nuclear Opening
**Pass when:** the earliest beat creates a consequential state change and forces response.
**Fail symptom:** routine setup or loud argument with no consequence.
**Repair:** enter at the violation/exposure/loss/collision/deadline/impossible fact.

## G3 — Character Intelligence
**Pass when:** each major decision is credible from the character’s knowledge, incentives, values, fear, and constraints.
**Fail symptom:** obvious solution ignored solely to preserve plot.
**Repair:** establish a real constraint/conflicting value; otherwise change the plot.

## G4 — Emotional Debt / Payoff
**Pass when:** major satisfaction settles or transforms an expectation the story deliberately created.
**Fail symptom:** protagonist wins, audience feels little.
**Repair:** match payoff form to the wound or promise.

## G5 — Escalation
**Pass when:** adjacent major problems change scale, cost, constraint, meaning, relationship, agency, or moral pressure.
**Fail symptom:** same conflict in new place with stronger antagonist.
**Repair:** move escalation to a different axis.

## G6 — Turn Causality
**Pass when:** major reveals are surprising but retrospectively supported and change what someone can/must do.
**Fail symptom:** secret trivia, random savior, villain-of-the-week reveal.
**Repair:** plant cause earlier and make the reveal redirect action.

## G7 — Chase / Delivery
**Pass when:** each unit advances or pays an existing expectation while producing a larger causal question.
**Fail symptom:** endless tease or complete reset.
**Repair:** give local delivery before reopening the loop.

## G8 — Repetition
**Pass when:** the last three major beats differ in pressure source, tactic, payoff family, information movement, or emotional texture.
**Fail symptom:** status reveal / slapback / applause / stronger challenger repeats.
**Repair:** preserve dramatic function, replace mechanism.

## G9 — Dialogue Function
**Pass when:** dialogue is action between people with unequal wants/knowledge, not explanation for the audience.
**Fail symptom:** recap, theme speech, repeated threats, identical voices.
**Repair:** assign each speaker a tactic and cut lines that change no leverage, relationship, or choice.

## Verdict format
Return only one of:
- **READY:** all structural gates pass; line polish may continue.
- **REWRITE:** one or more gates fail but premise engine remains healthy.
- **REBUILD ENGINE:** G0 fails; do not patch scenes until the premise engine is replaced.

For every failed gate include: evidence → consequence → smallest structural repair.
