# Evaluation — Scroll-Away Test

This is an audience-attention diagnostic, not a promise that every viewer will stay. Run it at the level of opening, scene, sequence, and episode.

## The seven questions
At each boundary ask:
1. **Readable now:** Can a general viewer name who wants what without needing a glossary?
2. **Change now:** What state change just occurred? If none, why is this beat still necessary?
3. **Pressure now:** What consequence, cost, contradiction, or forced choice is active?
4. **Expectation now:** What specific thing does the audience want to see/learn next?
5. **Progress now:** Has the story paid or advanced anything it previously promised?
6. **Difference now:** Is this pressure/payoff materially different from the previous major beat?
7. **Agency now:** Is someone making a meaningful choice or tactic, rather than passively receiving plot?

## Hard scroll-away triggers
Flag immediately when:
- the opening is biography, lore, commuting, waking, landscape, or routine before the first consequential event;
- conflict is only verbal intensity with no changed state;
- the protagonist has no active desire beyond “understand what is happening” for too long;
- three consecutive beats create the same emotion using the same mechanism;
- the story withholds an answer while delivering no other meaningful progress;
- a cliffhanger has no causal next action;
- the audience must remember many names/rules before caring about any human stake;
- a character ignores an obvious solution with no established constraint.

## Repair by failure type
| Failure | Repair |
|---|---|
| unclear | localize stake to a person, object, deadline, promise, or visible choice |
| inert | move the first state change earlier or merge setup into action |
| repetitive | change pressure source, tactic, relationship, or payoff family |
| hollow | map the payoff back to the emotional debt that created expectation |
| confusing twist | restore causal plant and immediate consequence |
| fake hook | end on a decision/consequence produced by current action |
| passive lead | give the protagonist a costly goal and a tactic |

## No fake metrics
Do not invent retention percentages, virality probabilities, “3-second pass rates,” or market forecasts. The test produces a structural verdict: **hold / vulnerable / likely scroll-away**, plus the exact reason and repair.
