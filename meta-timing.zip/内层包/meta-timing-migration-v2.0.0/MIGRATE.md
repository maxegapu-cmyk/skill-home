# meta-timing v2.0.0 迁移说明

默认仅做只读演练；增加 `--apply` 才写入。写入前强制校验清单与逐文件 SHA-256，事务式安装保留回滚备份，安装后自动严格验收。
迁移模式：**full** （全量恢复模式：包含主 skill、配套、可选历史与私有上下文）

```bash
python migrate.py --skills-dir <目标目录>
python migrate.py --skills-dir <目标目录> --apply
```

历史与私有上下文是独立可选包，分别显式使用 `--history-package` 和 `--memory-package`（后者还需 `--workspace`）。配套 skill 需重复指定 `--with-companion <名称>`。依赖默认不联网安装；只有存在带哈希的 `requirements.lock` 时才可显式使用 `--install-deps`，且不升级 pip。

## 随迁资产清单

| 资产 | 状态 | 边界 |
|---|---|---|
| 主 skill | 已包含 | 强制哈希、事务替换、未知文件保留 |
| 历史版本 | 未包含 | 默认最近 3 版加显式基线；需显式安装 |
| 工作区记忆 | 未包含 | 默认脱敏；需显式安装 |
| 配套 skill | 未包含 | 只打包，不自动安装 |
| Python 依赖 | 默认不安装 | 仅接受带哈希锁文件 |
| 换机待办提醒 | 未提供 | 安装时弹出未完成事项选项卡 |

> 若制包时提供了「当前未完成任务清单」（--next-steps 或 <skill_dir>/NEXT-STEPS.md），它会被内嵌为 `NEXT-STEPS.md`，在另一台电脑安装（含 dry-run）时由运行时弹出提醒选项卡，提示换机后仍需推进的工作。
