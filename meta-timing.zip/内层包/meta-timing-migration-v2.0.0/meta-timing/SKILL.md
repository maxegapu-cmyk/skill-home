---
name: meta-timing
version: 2.0.0
type: process
tier: meta
pattern: framework
agent_created: true
depends-on: agent-harness-loop, scr-judgment
description: 基础元级时机判断——"何时行动"轴（结构/审美/循环/判定契约之外的又一元轴）。决定"何时行动/打断/浮现/提醒/等待/批量/升级"的通用元能力，语义不限于发消息。只要任务涉及"现在该不该做/打断/主动浮现/提醒/升级"，默认优先调用本 skill 的两轴模型（WHAT/WHEN 分离 + 确定性时机策略：硬禁推窗 OR 否决 + 可推窗精确区间 + 按人单独适配 + 校准回路可 override），并产出"时机决策契约"标准输出供下游收敛消费。触发词：时机、什么时候推、推送时机、打断时机、主动浮现、何时介入、通知策略、提醒节奏、打扰用户、opportune、when to notify、proactive timing。
---

# 时机判断方法论（meta-timing）

> **版本 v2.0.0**（2026-09-21）· 基础元级 · 沉淀自 ResumeDesk 推送设计对话的演化经验

## 定位

决定"**何时**做某事"的通用框架。**语义不限于"传递消息的时机"**，而覆盖一切"行动窗口"判断：

- 何时 **打断**（break 用户专注）
- 何时 **浮现**（无声显形，不打断）
- 何时 **提醒**（周期跟进）
- 何时 **自主行动**（agent 主动做一件事）
- 何时 **等待**（刻意压住不发）
- 何时 **批量**（合并多件一次给）
- 何时 **升级**（提升 urgency）

一句话：**它不回答"该说什么"，只回答"现在是不是那个 moment"。**

## 铁律

1. **WHAT 与 WHEN 必须分离**
   - "该不该做"（内容门）只用**显式信号**，绝不靠推断制造紧迫感（"这活儿急，你该现在做"——禁）。
   - "何时做"（时机门）是**可设定、可单测的精确策略**。
   - 两门串行：内容门不过，时机门免谈。

2. **时机要确定性，不要模糊打分**
   - 结构 = **硬禁推窗（guard，OR 一票否决）** + **可推窗（window，精确区间）** + **确定性谓词**。
   - 禁止"≥N 个正向信号才推"的软评分逻辑。每个规则是 `given(now, ctx) -> bool`。

3. **按人单独适配**
   - 习惯（工作/休息节奏、专注块长度）与**心理生理条件**（通知敏感度、注意力容量、精力周期、是否易被中断打扰）人人不同。
   - → 每人一套策略 + **隐式学习个人节奏**，**绝不一刀切全局默认**。

4. **校准回路必须可 override**
   - 记录结果（`acted`/`dismissed`/`snoozed`），按人/时段/窗口收紧；但用户随时可改回，不被黑盒绑架。

5. **隐私本地**
   - 个性化信号（键鼠节奏、活跃时段、dismiss 记录）**只存本地**，不外发（契合既有隐私铁律）。

6. **宁少勿扰**
   - 默认取**最不易打扰**的保守值；误推的代价 > 漏推。

## 两轴模型

```
候选事项
   │
   ▼
[内容门] 只认显式信号 T1..Tn？  ──否──▶ 不推（绝不靠推断制造紧迫感）
   │是
   ▼
[时机门] 确定性策略
   ├─ 硬禁推窗 guard：typing/fullscreen/meeting/quiet/just_woke/frantic
   │     任一命中 → 压住（OR 否决）
   ▼
   可推窗 window：idle[min,max] / boundary / cadence / low_load
   落在区间 → 推；否则压住
   │
   ▼
[按人适配] 用该用户的 timing_profile（含隐式学到的节奏）
   │
   ▼
[校准] record_outcome → learn_profile（仅改该人，可 override）
```

### 内容门（显式，不变）
只认显式信号（例：T1 新待接手 / T2 进度到点 / T3 接手后变 / T4 采集异常）。**"我觉得你该看看"这类推断内容永不进候选。**

### 时机门（确定性策略）
| 层 | 谓词 | 精确条件（默认阈值） |
|---|---|---|
| guard | `guard_typing` | 距上次键鼠 < 90s |
| guard | `guard_fullscreen` | 前台全屏 |
| guard | `guard_meeting` | 日历进行中 |
| guard | `guard_quiet` | 落在 `quiet_hours` |
| guard | `guard_just_woke` | 解锁后 < 600s |
| guard | `guard_frantic` | 60s 内切窗 > 8 次 |
| window | `idle_window` | 空闲 ∈ [120s, 900s] |
| window | `boundary_window` | 距任务边界 < 300s |
| window | `authorized_cadence` | 命中用户明说节奏（"每天 18:00"） |
| window | `low_load` | 非全屏 ∧ 日历空闲 ∧ 非 frantic |

**决策**：`is_pushable = (no guard active) AND (in_any_window)`。无模糊。

## 按人适配

- **每人一套 `timing_policy`**（绑定用户/设备；复用既有 `reminder_preferences` 根基，扩展为 `timing_profile`）。
- **显式**：用户自调旋钮——夜猫子后移 `quiet_hours`、易焦虑者收窄 `idle_window`+开批量、注意力短者缩短 `boundary_window`、手工把精力低谷加进 `quiet_hours`。
- **隐式**：按人/时段/窗口统计 `dismissed` 率 → 学出个人节奏（优先在其空隙推）、个人敏感度（某窗口 dismiss 高→仅对该人收窄，**不影响他人**）、精力周期（常 dismiss 的时段视为低精力窗避开）。
- **出厂默认最保守**；尊重差异，不假设"标准人"。

## 校准回路（伪代码）

```python
def evaluate_timing(ctx, user_policy):
    if any_guard_active(ctx, user_policy):
        return False, 'guard'          # 硬禁推，一票否决
    if not in_eligible_window(ctx, user_policy):
        return False, 'no_window'
    return True, 'ok'

def record_outcome(state, user_id, outcome, window, at):
    prof = state.setdefault('timing_profiles', {}).setdefault(user_id, _empty())
    bucket = _bucket(window, at)        # (window类型, 时段) 例 (idle_window,"14:00-15:00")
    prof['stats'][bucket][outcome] = prof['stats'][bucket].get(outcome, 0) + 1
    learn_profile(prof)                 # 仅改该人；超 dismiss 阈 → 收窄/禁用该窗
```

## 反模式（一票否决级）

- 模糊打分（软评分决定推不推）
- 用内容推断制造紧迫感（"这活儿急"）
- 全局一套默认时机（忽略人与人的心理生理差异）
- 过度推送（打断专注）
- 个性化信号外发
- 黑盒不可 override

## 时机决策契约（标准输出 schema）

任何消费本 skill 的下游（agent 循环、通知系统、调度器）都应得到**统一结构的判定**，而非各写各的布尔。这是它作为元级 skill 被下游收敛的落点（与 `scr-judgment` 的统一判定契约同构）。

```yaml
TimingDecision:
  eligible:    bool        # 内容门：是否命中显式信号（WHAT）
  pushable:    bool        # 时机门：guard 全否 且 落某可推窗（WHEN）
  decision:    bool        # = eligible AND pushable（按该人 profile 计）
  reason:      enum        # content_no_signal | guard | no_window | per_user_suppressed | ok
  window:      str|null    # 命中的可推窗：idle_window | boundary_window | authorized_cadence | low_load
  policy_id:   str         # 所用 timing_profile 归属（user_id / device_id）
  confidence:  enum        # high | medium | low（依据信号精度与样本量）
  overridable: list[str]    # 用户可调旋钮（idle_window / quiet_hours / guards.* / cadence）
```

下游只认 `decision` + `reason`；`window`/`policy_id`/`confidence` 供日志与校准；`overridable` 把"为何推/不推"透明还给用户。

## 何时用 / 何时不用

- **用**：通知系统、主动浮现、agent 主动介入、提醒节奏、批量、打断策略、任何"现在该不该打扰人"的判断。
- **不用**：一次性脚本、纯后端计算、无需人机时机判断的批处理。

## 证据与案例

- **域 1 实证**：`references/examples.md` — ResumeDesk 推送改进从「不推断 → 准确推断 → 精准把控 → 按人适配」的演化，含确定性谓词 / 按人 profile 完整伪代码与边界单测要点。
- **跨域验证**：`references/cross-domain.md` — 在 agent-mail 主动提醒 / 自动化调度 / 应用内主动浮现 3 个异质域复用同一时机门，仅内容门换信号，印证其为跨域元能力。

## 版本

- **v2.0.0** · **提级为基础元级**：补"时机决策契约"标准输出 schema、补 3 域跨域验证；断言"何时行动"为元级第四轴（继结构/审美/循环/判定契约之后）。
- v1.0.0 · 初版，沉淀自 ResumeDesk 推送设计对话（不推断→准确推断→精准把控→按人适配）。
