# 案例：ResumeDesk 推送改进的"时机"演化

> 本文件是 `meta-timing` skill 的**域 1 实证案例**，展示"时机判断"如何从粗到精、从通用到按人。跨域复用见 `references/cross-domain.md`。

## 背景

ResumeDesk 是个 macOS 浮窗，把"没干完的 AI 对话任务"列在桌面提醒你接手。原始模型是 **pull（你翻浮窗）**。设计讨论聚焦一个问题：**要不要改成"关键时刻它主动弹你一下"，以及如何判定"关键时刻"**。

## 演化四步（即本 skill 铁律的来源）

| 阶段 | 用户原话 | 结论 | 对应 skill 铁律 |
|---|---|---|---|
| ① 不推断 | "绝不推纯推断的'你该看看'" | 内容门只认显式信号 T1–T4；纯推断内容永不进候选 | 铁律 1（WHAT/WHEN 分离） |
| ② 准确推断 | "对适当的时机要做准确推断" | 时机层引入正向/负向信号 | 铁律 2 雏形 |
| ③ 精准把控 | "我需要的是对时机的精准把控" | 模糊打分 → **确定性谓词**（guard OR 否决 + window 精确区间） | 铁律 2 |
| ④ 按人适配 | "不同人习惯和心理生理条件不同，要单独适配" | 全局默认 → **每人一套 timing_policy + 隐式学习个人节奏** | 铁律 3 |

## 确定性谓词（落地产物）

```python
def any_guard_active(ctx, user_policy):
    if ctx['idle_to_last_input'] < user_policy['guards']['typing']: return True
    if ctx['fullscreen']: return True
    if ctx['calendar_busy']: return True
    if in_quiet_hours(user_policy, ctx['now']): return True
    if ctx['since_wake'] < user_policy['guards']['just_woke']: return True
    if ctx['switch_count_60s'] > user_policy['guards']['frantic']: return True
    return False

def in_eligible_window(ctx, user_policy):
    lo, hi = user_policy['idle_window']
    if lo <= ctx['idle_sec'] <= hi: return True
    if 0 <= ctx['since_boundary'] <= user_policy['boundary_window_sec']: return True
    if matches_cadence(user_policy['authorized_cadence'], ctx['now']): return True
    return False

def evaluate_timing(ctx, user_policy):
    if any_guard_active(ctx, user_policy):
        return False, 'guard'            # 硬禁推，一票否决
    if not in_eligible_window(ctx, user_policy):
        return False, 'no_window'
    return True, 'ok'

def record_outcome(state, user_id, outcome, window, at):
    # outcome: acted / dismissed / snoozed；按人、按窗口、按时段累计
    prof = state.setdefault('timing_profiles', {}).setdefault(user_id, _empty_profile())
    bucket = _bucket(window, at)
    prof['stats'][bucket][outcome] = prof['stats'][bucket].get(outcome, 0) + 1
    learn_profile(prof)                  # 仅改该人；dismiss 超阈 → 收窄/禁用该窗

def notify_check(state, now_ts, ctx, user_id):
    items, _ = candidates(state)
    rep = report(state, 'auto', items=items)
    if not rep['should_notify']:
        return {'should_push': False}
    hits = push_triggers(state, items)   # 内容门（显式 T1–T4）
    if not hits:
        return {'should_push': False}
    user_policy = state.get('timing_profiles', {}).get(user_id, DEFAULT_POLICY)
    ok, reason = evaluate_timing(ctx, user_policy)  # 时机门（该人精准策略）
    if not ok:
        return {'should_push': False, 'reason': reason}
    return {'should_push': True, 'items': [h[1] for h in hits]}
```

## 按人 profile（隐式学习产物）

```json
{
  "user_A": {
    "timing_policy": {
      "idle_window": [60, 300],
      "boundary_window_sec": 300,
      "quiet_hours": ["23:00", "08:00"],
      "guards": {"typing": 90, "just_woke": 600, "frantic": 8},
      "authorized_cadence": ["daily 18:00"]
    },
    "stats": { "(idle_window,14:00-15:00)": {"acted": 12, "dismissed": 1, "snoozed": 0} }
  },
  "user_B": {
    "timing_policy": { "idle_window": [300, 900], "quiet_hours": ["22:00","07:30"], "...": "..." },
    "stats": { "(idle_window,10:00-11:00)": {"acted": 1, "dismissed": 9} }
  }
}
```
→ `user_B` 在 10–11 点 dismiss 率 90%，`learn_profile` 自动收窄该窗并标记低精力窗；**不影响 user_A**。

## 边界单测要点（验证确定性）

- 硬禁推一票否决：构造"空闲+边界"双 eligible，但 `typing<90s`/全屏/会议/quiet/just_woke/frantic 任一命中 → `evaluate_timing` 返回 `guard`，绝不推。
- 窗口精确边界：`idle_sec` 恰为 `idle_window` 界内推、界外（119s/901s）不推。
- 每人独立：A `[60,300]`、B `[300,900]`，同一 `idle_sec=200` 对 A 推、对 B 不推。
- 隐式个性化：对某人的某窗 dismiss 率高 → 仅对该人收窄，不影响他人。
- 隐私：个性化信号仅写本地 `state.json`，无外发。
- 可 override：学到的 profile 可被用户手动改回。

## 把语义扩出去（关键收获）

本案例表面是"推送时机"，实则提炼出可迁移框架：

- **打断**（通知/弹窗）= 本文的 push；
- **浮现**（无声显形，如浮窗常驻但只在空隙高亮）= 同样用 guard/window，只是不抢焦点；
- **提醒**（周期跟进）= `authorized_cadence`；
- **自主行动**（agent 主动做一步）= 把"内容门"换成"该动作的风险门"，时机门不变；
- **等待/批量/升级** = 在 `evaluate_timing` 外再包一层聚合（攒够 N 件或超时才升 urgency）。

即：**时机门的确定性结构（guard OR + window 区间 + 按人 profile + 校准回路）对所有"何时行动"通用，只有"内容门"随场景换信号。**
