#!/usr/bin/env python3
"""Generic migration runtime: dry-run by default, preflighted and rollback-capable."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path

def configure_output() -> None:
    """Keep the generated migration entrypoint standalone and UTF-8 safe."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, OSError):
            pass


configure_output()

ROOT = Path(__file__).resolve().parent
MANAGED = ".migration-managed.json"

# 备份根：**绝不能落在 skills 根之内**。实测教训：skills/ 里的 .migration-backups/
# 会被加载器递归发现，把里面的同名旧 SKILL.md 当成「真身」（skill-architect 曾被 0.80 旧版抢占）。
# 故默认放到 skills 根之外的 ~/.workbuddy/skills-backups/。
BACKUP_ROOT_ENV = "MIGRATE_BACKUP_ROOT"


def default_backup_root() -> Path:
    env = os.environ.get(BACKUP_ROOT_ENV)
    if env:
        return Path(env).expanduser()
    return Path.home() / ".workbuddy" / "skills-backups"


def version_key(raw) -> tuple:
    """把版本号折成可比较元组；缺版本按最低处理。"""
    if not raw:
        return (-1,)
    return tuple(int(x) if str(x).isdigit() else -1
                 for x in str(raw).replace("-", ".").split("."))


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def _relative_path(raw: str) -> Path:
    rel = Path(raw)
    if rel.is_absolute() or ".." in rel.parts or not raw or "\\" in raw:
        raise RuntimeError("非法相对路径: " + raw)
    return rel


def verified(root: Path) -> dict:
    root = Path(root)
    manifest_path = root / "MANIFEST.json"
    digest_path = root / "MANIFEST.sha256"
    if not manifest_path.is_file() or not digest_path.is_file():
        raise RuntimeError(f"{root} 缺 MANIFEST.json 或 MANIFEST.sha256")
    recorded = digest_path.read_text(encoding="ascii").split()
    if not recorded or digest(manifest_path) != recorded[0]:
        raise RuntimeError("MANIFEST.json 哈希不匹配")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != 2:
        raise RuntimeError("不支持的 manifest schema")
    listed = set()
    for item in data.get("files", []):
        raw = str(item["path"])
        rel = _relative_path(raw)
        if raw in listed:
            raise RuntimeError("manifest 含重复路径: " + raw)
        listed.add(raw)
        path = root / rel
        if not path.is_file() or path.stat().st_size != item["size"] or digest(path) != item["sha256"]:
            raise RuntimeError("文件完整性校验失败: " + raw)
    actual = {
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_file() and p.name != ".migration-managed.json" and p.name not in {"MANIFEST.json", "MANIFEST.sha256"}
    }
    if actual != listed:
        extra = sorted(actual - listed)
        missing = sorted(listed - actual)
        detail = (f"多出 {extra[:3]}" if extra else "") + (f" 缺少 {missing[:3]}" if missing else "")
        raise RuntimeError("manifest 文件集合不一致: " + detail)
    return data


def extract(package: Path, destination: Path) -> None:
    with zipfile.ZipFile(package) as archive:
        for info in archive.infolist():
            rel = Path(info.filename)
            if rel.is_absolute() or ".." in rel.parts:
                raise RuntimeError("ZIP 含越界路径: " + info.filename)
            if info.flag_bits & 1:
                raise RuntimeError("不接受加密 ZIP")
        archive.extractall(destination)
    verified(destination)


def managed(target: Path) -> dict:
    path = Path(target) / MANAGED
    if not path.is_file():
        return {"files": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError("安装受管清单损坏: " + str(path)) from exc
    if not isinstance(data.get("files"), list):
        raise RuntimeError("安装受管清单格式错误: " + str(path))
    for item in data["files"]:
        _relative_path(str(item.get("path", "")))
    return data


def entries(source: Path) -> list[dict]:
    source = Path(source)
    return [
        {
            "path": p.relative_to(source).as_posix(),
            "size": p.stat().st_size,
            "sha256": digest(p),
        }
        for p in sorted(source.rglob("*"))
        if p.is_file()
    ]


def _existing_parent(path: Path) -> Path:
    candidate = Path(path)
    while not candidate.exists() and candidate != candidate.parent:
        candidate = candidate.parent
    return candidate


@dataclass
class InstallPlan:
    source: Path
    target: Path
    identity: dict
    incoming: list[dict]
    stale: list[str]
    stage_root: Path | None = None
    staged: Path | None = None
    backup: Path | None = None
    moved: bool = False
    committed: bool = False
    parent_created: bool = False
    # 版本感知：目标机已装版本 / 处置关系 -> new|identical|update|collide|downgrade
    local_version: str | None = None
    relation: str = "new"


def make_install_plan(source: Path, target: Path, package: dict) -> InstallPlan:
    source = Path(source).resolve()
    target = Path(target).resolve()
    if not source.is_dir():
        raise RuntimeError("待安装 skill 目录不存在: " + str(source))
    if target.exists() and target.is_symlink():
        raise RuntimeError("拒绝写入符号链接目标: " + str(target))
    incoming = entries(source)
    if not incoming:
        raise RuntimeError("待安装 skill 为空: " + str(source))
    old = managed(target) if target.exists() else {"files": []}
    paths = {item["path"] for item in incoming}
    stale = [item["path"] for item in old["files"] if item.get("path") not in paths]
    identity = dict(package)
    skill_file = source / "SKILL.md"
    if skill_file.is_file():
        text = skill_file.read_text(encoding="utf-8", errors="strict")
        header = text.split("---", 2)[1] if text.startswith("---") and text.count("---") >= 2 else ""
        for field in ("name", "version"):
            match = re.search(rf"(?m)^{field}:\s*['\"]?([^'\"\r\n]+)", header)
            if not match or not match.group(1).strip():
                raise RuntimeError(f"待安装 skill 的 SKILL.md 缺少 {field}: {source}")
            identity[field] = match.group(1).strip()
    plan = InstallPlan(source, target, identity, incoming, stale)
    # 版本感知：绝不盲覆盖。目标机已装版本来自受管清单 .migration-managed.json。
    # 为什么必须做：旧实现一律 OVERWRITE，于是「本机迭代了较低版本 skill 再迁移到
    # 装有较高版本的另一台机」会静默降版，且事后无从察觉。
    plan.local_version = old.get("version")
    old_map = {i["path"]: i["sha256"] for i in old.get("files", []) if i.get("path")}
    new_map = {i["path"]: i["sha256"] for i in incoming}
    if not target.exists() or not old.get("files"):
        plan.relation = "new"
    elif old_map == new_map:
        plan.relation = "identical"
    else:
        lv, iv = version_key(plan.local_version), version_key(identity.get("version"))
        plan.relation = "update" if iv > lv else ("downgrade" if iv < lv else "collide")
    return plan


def _stage(plan: InstallPlan, stage_parent: Path) -> None:
    plan.stage_root = Path(tempfile.mkdtemp(prefix=".migration-stage-", dir=str(stage_parent)))
    plan.staged = plan.stage_root / plan.target.name
    if plan.target.exists():
        shutil.copytree(plan.target, plan.staged, symlinks=False)
    else:
        plan.staged.mkdir()
    for raw in plan.stale:
        stale_path = plan.staged / _relative_path(raw)
        if stale_path.is_file() or stale_path.is_symlink():
            stale_path.unlink()
    shutil.copytree(plan.source, plan.staged, dirs_exist_ok=True, symlinks=False)
    state = {
        "schema": 2,
        "name": plan.identity.get("name", plan.source.name),
        "version": plan.identity["version"],
        "files": plan.incoming,
    }
    (plan.staged / MANAGED).write_text(
        json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def _commit(plans: list[InstallPlan], backup_root: Path) -> None:
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    committed: list[InstallPlan] = []
    try:
        for index, plan in enumerate(plans):
            parent = plan.target.parent
            if not parent.exists():
                parent.mkdir(parents=True, exist_ok=True)
                plan.parent_created = True
            if plan.target.exists():
                # 备份落到 skills 根之外（backup_root 已由调用方保证）
                backup_dir = backup_root / f"{plan.target.name}-{timestamp}-{index}"
                backup_dir.parent.mkdir(parents=True, exist_ok=True)
                if backup_dir.exists():
                    shutil.rmtree(backup_dir, ignore_errors=True)
                os.replace(plan.target, backup_dir)
                plan.backup = backup_dir
                plan.moved = True
            os.replace(plan.staged, plan.target)
            plan.committed = True
            committed.append(plan)
        for plan in committed:
            print("[apply] 完成：" + str(plan.target))
    except Exception:
        _rollback(plans)
        raise


def _rollback(plans: list[InstallPlan]) -> None:
    """Restore every target whose original directory was moved, including a mid-commit failure."""
    for plan in reversed(plans):
        if plan.backup and plan.backup.exists():
            if plan.target.exists():
                shutil.rmtree(plan.target, ignore_errors=True)
            os.replace(plan.backup, plan.target)
        elif plan.committed and plan.target.exists():
            shutil.rmtree(plan.target, ignore_errors=True)


def check(target: Path) -> None:
    data = managed(Path(target))
    if not data.get("files"):
        raise RuntimeError("缺安装受管清单: " + str(Path(target) / MANAGED))
    for item in data["files"]:
        rel = _relative_path(str(item["path"]))
        path = Path(target) / rel
        if not path.is_file() or path.stat().st_size != item["size"] or digest(path) != item["sha256"]:
            raise RuntimeError("安装后验收失败: " + item["path"])
    print(f"[check][OK] {Path(target).name} v{data.get('version')}，{len(data['files'])} 个受管文件哈希一致")


NEXT_STEPS_ENV = "MIGRATE_NEXTSTEPS_SHOWN"


def show_next_steps(root: Path) -> bool:
    """若包内含 NEXT-STEPS.md，弹出「换机待办提醒」选项卡。

    由环境变量 MIGRATE_NEXTSTEPS_SHOWN 守护，避免外层 bootstrap 与内层 migrate 重复弹出。
    返回是否实际弹出，供调用方决定是否置位环境变量。
    """
    if os.environ.get(NEXT_STEPS_ENV):
        return False
    ns = Path(root) / "NEXT-STEPS.md"
    if not ns.is_file():
        return False
    try:
        text = ns.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        return False
    if not text:
        return False
    bar = "═" * 64
    print(bar)
    print("⏳ 换机待办提醒（迁移完成后，请在另一台电脑处理以下未完成任务）")
    print(bar)
    for line in text.splitlines():
        print("  " + line)
    print(bar)
    print("请在完成上述事项后再投入实际工作；如已无未完成任务可忽略本提示。")
    return True


def asset_plan(package_root: Path, category: str, destination: Path) -> InstallPlan:
    data = verified(package_root)
    if data.get("category") != category:
        raise RuntimeError(f"资产类别应为 {category}，实际为 {data.get('category')}")
    asset_root = package_root / ("history" if category == "history" else "memory")
    if not asset_root.is_dir():
        raise RuntimeError("资产包缺少目录: " + str(asset_root))
    plan = make_install_plan(asset_root, Path(destination), data)
    print(f"[plan] {category} → {destination}；{len(plan.incoming)} 个校验项")
    return plan


def related(package: Path, category: str, manifest: dict) -> None:
    package = Path(package).resolve()
    if not package.is_file():
        raise RuntimeError(category + " 包不存在: " + str(package))
    expected = next((x for x in manifest.get("related_packages", []) if x.get("category") == category), None)
    if not expected:
        raise RuntimeError("核心清单未声明可搭配的 " + category + " 包")
    if package.name != expected["file"] or package.stat().st_size != expected["size"] or digest(package) != expected["sha256"]:
        raise RuntimeError(category + " 包与核心清单声明的精确文件/哈希不一致")


def validate_lock(target: Path) -> Path:
    lock = Path(target) / "requirements.lock"
    if not lock.is_file():
        raise RuntimeError("--install-deps 要求 skill 内存在 requirements.lock")
    reqs = [x for x in lock.read_text(encoding="utf-8", errors="ignore").splitlines()
            if x.strip() and not x.lstrip().startswith("#")]
    if not reqs or any("--hash=sha256:" not in x for x in reqs):
        raise RuntimeError("requirements.lock 每条依赖都必须带 --hash=sha256")
    return lock


def install_deps_isolated(target: Path) -> None:
    lock = validate_lock(target)
    venv = Path(target) / ".venv"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    subprocess.run([str(python), "-m", "pip", "install", "--require-hashes", "-r", str(lock)], check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="默认只演练、先预检、事务提交、可回滚的 skill 迁移安装器")
    parser.add_argument("--skills-dir", required=True)
    parser.add_argument("--workspace")
    parser.add_argument("--history-package")
    parser.add_argument("--memory-package")
    parser.add_argument("--with-history", dest="history_package", help=argparse.SUPPRESS)
    parser.add_argument("--with-memory", dest="memory_package", help=argparse.SUPPRESS)
    parser.add_argument("--with-companion", action="append", default=[])
    parser.add_argument("--install-deps", action="store_true")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--backup-root", default=None,
                        help="备份根目录（默认 ~/.workbuddy/skills-backups/migrate-<ts>）。"
                             "**绝不要设在 skills 根之内**——会被加载器当同名 skill 抢真身。")
    parser.add_argument("--allow-downgrade", action="store_true",
                        help="允许用低版本包覆盖目标机的更高版本（默认拒绝）")
    parser.add_argument("--allow-collide", action="store_true",
                        help="允许同版本异内容覆盖（默认拒绝，应先三路合并）")
    args = parser.parse_args()
    if args.apply and args.dry_run:
        parser.error("--apply 与 --dry-run 不能同时使用")

    package = verified(ROOT)
    name = package["name"]
    show_next_steps(ROOT)
    print("[提示] Loop Engineering 套件已纳入随迁：prompt-specification、context-assembly、agent-harness-loop。")
    print("[提示] skills-security-check 为第三方插件；换机安装后，请用元 skill 学习沉淀创建自研安全审计替代 skill。")
    print("[提示] 换机恢复后，如需多 skill 协同工作，请提示创建‘自动协调元 skill’及其配套 skill，再进入实际工作。")
    print("[原则] 后续迁移尽量组装为一个外层 ZIP，减少漏迁与多包管理。")
    skills = Path(args.skills_dir).resolve()
    target = skills / name
    if args.check:
        check(target)
        return 0

    # 所有包、配套、目标和依赖在任何写入前完成解析与哈希预检。
    plans: list[InstallPlan] = [make_install_plan(ROOT / name, target, package)]
    available = {x.name: x for x in (ROOT / "companions").iterdir()} if (ROOT / "companions").is_dir() else {}
    unknown = sorted(set(args.with_companion) - set(available))
    if unknown:
        raise RuntimeError("未知配套 skill: " + ", ".join(unknown))
    for companion_name in args.with_companion:
        plans.append(make_install_plan(available[companion_name], skills / companion_name, package))
    targets = [p.target for p in plans]
    if len(set(targets)) != len(targets):
        raise RuntimeError("主 skill、配套或资产目标发生路径冲突")

    with tempfile.TemporaryDirectory(prefix="migration-input-") as temp:
        temp_root = Path(temp)
        if args.history_package:
            related(Path(args.history_package), "history", package)
            history_root = temp_root / "history-package"
            extract(Path(args.history_package).resolve(), history_root)
            plans.append(asset_plan(history_root, "history", skills / ".archives" / name / "history"))
        if args.memory_package:
            if not args.workspace:
                raise RuntimeError("--memory-package 必须同时给出 --workspace")
            related(Path(args.memory_package), "private-context", package)
            memory_root = temp_root / "memory-package"
            extract(Path(args.memory_package).resolve(), memory_root)
            plans.append(asset_plan(memory_root, "private-context", Path(args.workspace).resolve() / ".workbuddy" / "memory"))

        if args.install_deps:
            validate_lock(ROOT / name)
            if not args.apply:
                print("[plan] 将在提交前于隔离 .venv 安装带哈希依赖；dry-run 不联网")

        for plan in plans:
            print(f"[plan] {plan.relation:9s} 安装 {plan.source.name} → {plan.target}；"
                  f"文件 {len(plan.incoming)}；清理旧受管文件 {len(plan.stale)}"
                  + (f"；目标机已装 v{plan.local_version}" if plan.local_version else ""))
        # 版本感知闸门：绝不盲覆盖。目标机更高 -> 降版；同版本异内容 -> 碰撞。
        blocked = []
        for plan in plans:
            if plan.relation == "downgrade" and not args.allow_downgrade:
                blocked.append((plan, "降版（包内版本低于目标机已装版本）"))
            elif plan.relation == "collide" and not args.allow_collide:
                blocked.append((plan, "版本碰撞（同版本但内容不同）"))
        if blocked:
            print("=" * 72)
            for plan, why in blocked:
                print(f"[block] {plan.target.name}: 目标机已装 v{plan.local_version}，"
                      f"包内 v{plan.identity.get('version')} -> {why}，默认拒绝覆盖。")
            print("[block] 硬覆盖会静默降版/制造新分叉。合规出路（按优先级）：")
            print("       1) 让发送方把版本号升到高于目标机，重新出包（推荐）")
            print("       2) 走三路合并（反向包安装器自动做）后回传合并结果")
            print("       3) 确知要覆盖时显式加 --allow-downgrade / --allow-collide")
            print("=" * 72)
            return 3
        if not args.apply:
            print("[dry-run] 未写入任何文件；所有输入已预检，确认后增加 --apply")
            return 0

        backup_root = Path(args.backup_root).expanduser() if args.backup_root \
            else default_backup_root() / ("migrate-" + time.strftime("%Y%m%d-%H%M%S"))
        print(f"[backup] 备份根: {backup_root}（在 skills 根之外，避免影子备份抢占真身）")
        for plan in plans:
            _stage(plan, _existing_parent(plan.target.parent))
        try:
            if args.install_deps:
                install_deps_isolated(plans[0].staged)
            _commit(plans, backup_root)
            for plan in plans:
                check(plan.target)
        except Exception:
            _rollback(plans)
            print("[rollback] 提交或安装后验收失败；已尝试恢复原目标", file=sys.stderr)
            raise
        finally:
            for plan in plans:
                if plan.stage_root:
                    shutil.rmtree(plan.stage_root, ignore_errors=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError, zipfile.BadZipFile, subprocess.CalledProcessError) as exc:
        print("[migrate][FAIL] " + str(exc), file=sys.stderr)
        raise SystemExit(1)
