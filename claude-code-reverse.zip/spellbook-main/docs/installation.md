# Installation Guide

## Prerequisites

- Claude Code CLI and/or Codex installed
- Git

## Start With One Workflow

Use the maintained `skills` CLI as the default public installation path. It
discovers the repository skills, lets you select supported coding agents, and
installs only the named workflow:

```bash
npx skills add majiayu000/spellbook --skill frontend-design --skill app-ui-design --skill ui-design-system --skill figma-to-react
```

List the full catalog without installing:

```bash
npx skills add majiayu000/spellbook --list
```

The five maintained starting workflows are listed in the repository
[README](../README.md#pick-a-workflow).

## Advanced Cross-Runtime Installer

Use `install.sh` when you need explicit runtime target paths, a non-interactive
shell flow, or the repository's Claude Code agents.

```bash
# Install skills for both Claude Code and Codex
curl -fsSL https://raw.githubusercontent.com/majiayu000/spellbook/main/install.sh | bash -s -- --target all

# Install only for Claude Code
curl -fsSL https://raw.githubusercontent.com/majiayu000/spellbook/main/install.sh | bash -s -- --target claude

# Install only for Codex
curl -fsSL https://raw.githubusercontent.com/majiayu000/spellbook/main/install.sh | bash -s -- --target codex
```

Target paths:

| Target | Skills | Agents |
|--------|--------|--------|
| Claude Code | `~/.claude/skills` | `~/.claude/agents` |
| Codex | `~/.agents/skills` | Not supported by this installer |

Codex user-level skills follow the current OpenAI-documented path,
`$HOME/.agents/skills`. Older Spellbook releases used `~/.codex/skills`; run
the current installer again to refresh symlinks into the supported location.

## Installing Claude Code Plugins

Plugins are currently Claude Code-specific because they use the `.claude-plugin`
manifest format. Codex plugin packaging is not supported by this repository
today; install Codex skills directly with `install.sh --target codex` or into
`$HOME/.agents/skills`.

### Method 1: Via Plugin Marketplace (Recommended)

```bash
# Add the plugin as a marketplace source
/plugin marketplace add https://github.com/majiayu000/spellbook/plugins/<plugin-name>

# Install the plugin
/plugin install <plugin-name>
```

### Method 2: Local Installation

```bash
# Clone the repository
git clone https://github.com/majiayu000/spellbook.git

# Add local plugin as marketplace
/plugin marketplace add /path/to/spellbook/plugins/<plugin-name>

# Install
/plugin install <plugin-name>
```

## Installing Individual Components

### Skills

For normal installation, prefer
`npx skills add majiayu000/spellbook --skill <skill-name>`. For an explicit
repository-local cross-runtime installation, use
`install.sh --target <target> --skills <skill-name>`.

- Directory skills: `skills/<skill-name>/SKILL.md`
- File skills: `skills/<skill-name>.SKILL.md`

Use the generated [Skill Registry](./skill-registry.md) to check a skill's `format` and source path.

#### Directory skill

```bash
# Claude Code
cp -R skills/<skill-name> ~/.claude/skills/<skill-name>

# Codex
cp -R skills/<skill-name> ~/.agents/skills/<skill-name>
```

#### File skill

```bash
# Claude Code: create skill directory (each skill needs its own subdirectory)
mkdir -p ~/.claude/skills/<skill-name>

# Claude Code: download a skill
curl -o ~/.claude/skills/<skill-name>/SKILL.md \
  https://raw.githubusercontent.com/majiayu000/spellbook/main/skills/<skill-name>.SKILL.md

# Codex: create skill directory and download the same source
mkdir -p ~/.agents/skills/<skill-name>
curl -o ~/.agents/skills/<skill-name>/SKILL.md \
  https://raw.githubusercontent.com/majiayu000/spellbook/main/skills/<skill-name>.SKILL.md
```

### Commands

Spellbook no longer ships repository-level Claude command files. Use the
corresponding skill entry instead.

### Agents

```bash
# Create agents directory if not exists
mkdir -p ~/.claude/agents

# Download an agent
curl -o ~/.claude/agents/<agent-name>.md \
  https://raw.githubusercontent.com/majiayu000/spellbook/main/agents/<agent-name>.md
```

### CLAUDE.md Templates

```bash
# Download to your project root
curl -o ./CLAUDE.md \
  https://raw.githubusercontent.com/majiayu000/spellbook/main/claude-md/<template-name>.md
```

## Verification

After installation, verify components are loaded:

```bash
# Check installed Claude Code plugins
/plugin list

# Ask Claude about available skills
"What skills do you have available?"

# Codex direct skill install
# Restart Codex so it reloads ~/.agents/skills.
```

## Uninstallation

```bash
# Uninstall a plugin
/plugin uninstall <plugin-name>

# Remove a skill
rm -rf ~/.claude/skills/<skill-name>

```
