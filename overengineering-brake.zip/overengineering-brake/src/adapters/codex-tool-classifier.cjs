'use strict';

const nodePath = require('node:path');

const WRITE_NAME = /(?:^|__|_)(?:add|append|apply|archive|close|commit|copy|create|delete|deploy|edit|install|merge|move|patch|post|publish|push|remove|rename|send|set|submit|update|upload|write)(?:$|__|_)/i;
const READ_NAME = /(?:^|__|_)(?:cat|check|diff|fetch|find|get|inspect|list|load|open|read|review|search|show|status|view)(?:$|__|_)/i;
const CONTROL_TOOLS = new Set(['update_plan', 'request_user_input', 'wait', 'wait_agent']);
const CODE_PATH = /\.(?:[cm]?[jt]sx?|py|go|rs|java|kt|cs|php|rb|c|cc|cpp|h|hpp)$/i;
const HASH_COMMAND = /\b(?:Get-FileHash|md5sum|sha(?:1|224|256|384|512)sum|shasum|b2sum)\b|\bcertutil\b[^\r\n]*\s-hashfile\b|\bopenssl\s+dgst\b/i;
const HASH_API = /\b(?:createHash|createHmac)\s*\(|\bcrypto\.subtle\.digest\s*\(|\bhashlib\.(?:md5|sha1|sha224|sha256|sha384|sha512|blake2[bs])\s*\(|\bMessageDigest\.getInstance\s*\(|\bDigestUtils\.[A-Za-z0-9_]+\s*\(|\bsha(?:1|256|512)\.(?:New|Sum\w*)\s*\(|\b(?:bcrypt|argon2)\.hash\s*\(|\bpassword_hash\s*\(|\bPasswordHasher\s*\(/i;
const DEPENDENCY_COMMAND = /\b(?:npm|pnpm|yarn)\s+(?:add|install)\b|\bpip(?:3)?\s+install\b|\bcargo\s+add\b|\bdotnet\s+add\b[^\r\n]*\bpackage\b|\bgo\s+get\b|\bcomposer\s+require\b|\bbundle\s+add\b/i;

function inputText(toolInput) {
  if (typeof toolInput === 'string') return toolInput;
  if (!toolInput || typeof toolInput !== 'object') return '';
  return String(toolInput.command || toolInput.cmd || toolInput.patch || toolInput.content || toolInput.new_string || '');
}

function detectHashIntent(toolName, toolInput) {
  const name = String(toolName || '');
  const text = inputText(toolInput);
  if (!text) return false;

  if (name === 'Bash' || name === 'exec_command' || name === 'shell_command') {
    return HASH_COMMAND.test(text);
  }

  if (name === 'apply_patch') {
    const added = text.split(/\r?\n/).filter((line) => /^\+(?!\+\+)/.test(line)).join('\n');
    return HASH_API.test(added);
  }

  if (name === 'Edit' || name === 'Write') {
    const filePath = String(toolInput && (toolInput.file_path || toolInput.path) || '');
    return CODE_PATH.test(filePath) && HASH_API.test(text);
  }

  return false;
}

function normalizePath(value, cwd) {
  let normalized = String(value || '').trim().replace(/^['"]|['"]$/g, '').replace(/\\/g, '/');
  if (cwd && nodePath.isAbsolute(normalized)) {
    normalized = nodePath.relative(String(cwd), normalized).replace(/\\/g, '/');
  }
  return normalized.replace(/^\.\//, '');
}

function capturedValue(match) {
  if (!match) return '';
  return match[1] || match[2] || match[3] || '';
}

function flaggedPaths(command, flagNames, cwd) {
  const flags = flagNames.join('|');
  const expression = new RegExp(`(?:${flags})\\s+(?:"([^"]+)"|'([^']+)'|([^\\s;|]+))`, 'ig');
  return [...String(command || '').matchAll(expression)]
    .map((match) => normalizePath(capturedValue(match), cwd))
    .filter(Boolean);
}

function positionalPaths(command, commandName, count, cwd) {
  const expression = new RegExp(`\\b${commandName}\\b\\s+((?:"[^"]+"|'[^']+'|[^\\s;|]+)(?:\\s+(?:"[^"]+"|'[^']+'|[^\\s;|]+)){0,${Math.max(0, count - 1)}})`, 'i');
  const match = expression.exec(String(command || ''));
  if (!match) return [];
  const values = match[1].match(/"[^"]+"|'[^']+'|[^\s;|]+/g) || [];
  if (values.some((value) => value.startsWith('-'))) return [];
  return values.slice(0, count).map((value) => normalizePath(value, cwd)).filter(Boolean);
}

function extractShellAffectedPaths(command, cwd) {
  const text = String(command || '');
  const match = /\b(Set-Content|Add-Content|Remove-Item|New-Item|Out-File|Move-Item|Copy-Item|Compress-Archive|Expand-Archive|Invoke-WebRequest|curl)\b/i.exec(text);
  if (!match) return [];
  const commandName = match[1].toLowerCase();
  let paths = [];

  if (['set-content', 'add-content', 'remove-item', 'new-item'].includes(commandName)) {
    paths = flaggedPaths(text, ['-LiteralPath', '-Path'], cwd);
    if (!paths.length) paths = positionalPaths(text, match[1], 1, cwd);
  } else if (commandName === 'out-file') {
    paths = flaggedPaths(text, ['-LiteralPath', '-FilePath'], cwd);
    if (!paths.length) paths = positionalPaths(text, match[1], 1, cwd);
  } else if (commandName === 'move-item') {
    paths = flaggedPaths(text, ['-LiteralPath', '-Path', '-Destination'], cwd);
    if (!paths.length) paths = positionalPaths(text, match[1], 2, cwd);
  } else if (commandName === 'copy-item') {
    paths = flaggedPaths(text, ['-Destination'], cwd);
    if (!paths.length) paths = positionalPaths(text, match[1], 2, cwd).slice(-1);
  } else if (commandName === 'compress-archive' || commandName === 'expand-archive') {
    paths = flaggedPaths(text, ['-DestinationPath'], cwd);
  } else if (commandName === 'invoke-webrequest') {
    paths = flaggedPaths(text, ['-OutFile'], cwd);
  } else if (commandName === 'curl') {
    paths = flaggedPaths(text, ['-o', '--output'], cwd);
  }

  return [...new Set(paths.filter(Boolean))];
}

function extractAffectedPaths(toolName, toolInput, cwd) {
  const name = String(toolName || '');
  if (name === 'Edit' || name === 'Write') {
    const filePath = normalizePath(toolInput && (toolInput.file_path || toolInput.path), cwd);
    return filePath ? [filePath] : [];
  }
  if (name === 'Bash' || name === 'exec_command' || name === 'shell_command') {
    return extractShellAffectedPaths(inputText(toolInput), cwd);
  }
  if (name !== 'apply_patch') return [];

  const paths = [];
  for (const line of inputText(toolInput).split(/\r?\n/)) {
    const match = /^\*\*\* (?:Add|Update|Delete) File:\s*(.+?)\s*$/.exec(line)
      || /^\*\*\* Move to:\s*(.+?)\s*$/.exec(line);
    if (match) paths.push(normalizePath(match[1], cwd));
  }
  return [...new Set(paths.filter(Boolean))];
}

function addedLinesByPatchedFile(text) {
  const sections = [];
  let current = null;
  for (const line of String(text || '').split(/\r?\n/)) {
    const header = /^\*\*\* (?:Add|Update) File:\s*(.+?)\s*$/.exec(line);
    if (header) {
      current = { path: normalizePath(header[1]), added: [] };
      sections.push(current);
      continue;
    }
    if (/^\*\*\*/.test(line)) {
      current = null;
      continue;
    }
    if (current && /^\+(?!\+\+)/.test(line)) current.added.push(line);
  }
  return sections;
}

function detectDependencyIntent(toolName, toolInput) {
  const name = String(toolName || '');
  const text = inputText(toolInput);
  if (name === 'Bash' || name === 'exec_command' || name === 'shell_command') {
    return DEPENDENCY_COMMAND.test(text);
  }
  if (name === 'apply_patch') {
    const manifest = /(?:^|\/)(?:package\.json|pyproject\.toml|requirements[^/]*\.txt|Cargo\.toml|go\.mod|composer\.json|Gemfile)$/i;
    const dependencyDeclaration = /["']?(?:dependencies|devDependencies|optionalDependencies)["']?\s*[:=]|^[+]\s*[^#\s][^\r\n]*(?:==|>=|~=|\^\d)/mi;
    return addedLinesByPatchedFile(text).some((section) => (
      manifest.test(section.path) && dependencyDeclaration.test(section.added.join('\n'))
    ));
  }
  return false;
}

function classifyShell(command) {
  const text = String(command || '').trim();
  if (!text) return 'unknown';

  const writePattern = /\b(?:Remove-Item|Move-Item|Copy-Item|Rename-Item|Set-Content|Add-Content|Out-File|New-Item|Set-ItemProperty|New-ItemProperty|Remove-ItemProperty|Start-Process|Stop-Process|Compress-Archive|Expand-Archive|rm|del|erase|rmdir|mv|cp|touch|mkdir|tee|apply_patch)\b|\bInvoke-WebRequest\b[^\r\n]*\s-OutFile\b|\bcurl\b[^\r\n]*(?:\s-o\s|\s--output\s)|\bgit\s+(?:add|commit|push|merge|rebase|checkout|switch|reset|clean|tag)\b|\b(?:npm|pnpm|yarn)\s+(?:add|install|remove|uninstall|publish)\b|\bpip\s+install\b|\b(?:winget|choco|scoop)\s+(?:install|uninstall|remove)\b|\bschtasks\b[^\r\n]*\s\/(?:Create|Delete|Change)\b|\breg\s+(?:add|delete|import|restore)\b|\bgh\s+(?:pr\s+(?:create|merge|close)|issue\s+(?:create|close)|release\s+create)\b/i;
  const redirection = /(^|[^<])>{1,2}\s*[^&]/;
  if (writePattern.test(text) || redirection.test(text)) return 'write';

  const dynamicProgram = /\b(?:node|python|python3|py|ruby|perl)\s+(?!-{1,2}version\b)(?:-e|-c|[^-\s][^\s]*)/i;
  if (dynamicProgram.test(text)) return 'unknown';

  const readPattern = /\b(?:Get-Content|Get-ChildItem|Get-Item|Test-Path|Resolve-Path|Select-String|Measure-Object|Compare-Object|Where-Object|ForEach-Object|rg|grep|findstr|cat|ls|dir|pwd|head|tail|wc|type)\b|\bgit\s+(?:status|diff|log|show|rev-parse|branch)\b|\b(?:node|python|python3|py)\s+--version\b/i;
  return readPattern.test(text) ? 'read' : 'unknown';
}

function classifyCodexTool(toolName, toolInput) {
  const name = String(toolName || '');
  if (name === 'apply_patch' || name === 'Edit' || name === 'Write') return 'write';
  if (name === 'Bash' || name === 'exec_command' || name === 'shell_command') {
    return classifyShell(toolInput && (toolInput.command || toolInput.cmd));
  }
  if (name === 'Agent' || name === 'spawn_agent') return 'delegate';
  if (CONTROL_TOOLS.has(name)) return 'control';
  if (WRITE_NAME.test(name)) return 'write';
  if (READ_NAME.test(name)) return 'read';
  return 'unknown';
}

module.exports = { classifyCodexTool, classifyShell, detectDependencyIntent, detectHashIntent, extractAffectedPaths };
