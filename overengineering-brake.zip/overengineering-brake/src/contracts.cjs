'use strict';

const MODES = new Set(['answer', 'review', 'change', 'monitor', 'open']);
const LEVELS = new Set(['watch', 'guard', 'lock', 'off']);
const HASH_POLICIES = new Set(['deny', 'ask', 'allow']);
const SCOPE_POLICIES = new Set(['deny', 'ask', 'allow']);

function defaultContract() {
  return {
    mode: 'unconfirmed',
    level: 'watch',
    agentBudget: 0,
    agentsUsed: 0,
    hashPolicy: 'deny',
    allowedPaths: null,
    dependencyPolicy: 'ask',
    source: 'default'
  };
}

function directiveHead(prompt, matchEnd) {
  const tail = prompt.slice(matchEnd).trimStart();
  const boundaries = [tail.indexOf('--'), tail.indexOf(':'), tail.indexOf('\n')]
    .filter((index) => index >= 0);
  const end = boundaries.length ? Math.min(...boundaries) : Math.min(tail.length, 80);
  return tail.slice(0, end).trim();
}

function parseDirective(prompt) {
  const mention = /\$overengineering-brake\b/i.exec(prompt);
  if (!mention) return null;

  const head = directiveHead(prompt, mention.index + mention[0].length);
  const tokens = head.split(/[\s,]+/).map((token) => token.trim().toLowerCase()).filter(Boolean);
  const parsed = { mentioned: true };

  for (const token of tokens) {
    if (MODES.has(token)) parsed.mode = token;
    if (LEVELS.has(token)) parsed.level = token;
    const agents = /^agents=(\d+)$/.exec(token);
    if (agents) parsed.agentBudget = Math.min(Number(agents[1]), 8);
    const hash = /^hash=(deny|ask|allow)$/.exec(token);
    if (hash && HASH_POLICIES.has(hash[1])) parsed.hashPolicy = hash[1];
    const files = /^files=(.+)$/.exec(token);
    if (files) parsed.allowedPaths = files[1].split('|').map((value) => value.replace(/\\/g, '/')).filter(Boolean);
    const dependencies = /^deps=(deny|ask|allow)$/.exec(token);
    if (dependencies && SCOPE_POLICIES.has(dependencies[1])) parsed.dependencyPolicy = dependencies[1];
  }

  return parsed;
}

function lastIndexOfAny(text, expressions) {
  let last = -1;
  for (const expression of expressions) {
    const flags = expression.flags.includes('g') ? expression.flags : `${expression.flags}g`;
    const global = new RegExp(expression.source, flags);
    for (const match of text.matchAll(global)) last = Math.max(last, match.index || 0);
  }
  return last;
}

function lastPositiveChangeIndex(text) {
  const verbs = /\b(?:fix|implement|change|apply|patch|create|install|download|save|move|delete|remove|import|archive|sync|update|package|organize|execute|replace|upload|publish|send|copy|rename|merge|restore|clean|add)\b|修复|修改|实现|创建|安装|下载|保存|移动|删除|移除|导入|入库|归档|同步|更新|打包|整理|处理|执行|应用|替换|上传|发布|发送|复制|重命名|合并|恢复|清理|改成|换成|增加|添加|去掉/gi;
  let last = -1;
  for (const match of text.matchAll(verbs)) {
    const before = text.slice(Math.max(0, (match.index || 0) - 48), match.index || 0);
    const negativeIndex = lastIndexOfAny(before, [/(?:不要|别|禁止|无需|不需要|不必|不可)/i, /\b(?:do not|don't|never)\b/i]);
    const resetIndex = lastIndexOfAny(before, [/(?:现在|改为|但是|不过|随后|然后)/i, /\b(?:now|instead|but|then)\b/i]);
    if (negativeIndex >= 0 && negativeIndex > resetIndex) continue;
    last = Math.max(last, match.index || 0);
  }
  return last;
}

function naturalCorrection(prompt, previous) {
  const text = prompt.trim();

  if (/^(?:stop|stop now|停止|停下来)[.!。！\s]*$/i.test(text)) {
    return { mode: 'answer', source: 'explicit-stop' };
  }
  if (/^(?:continue|go on|proceed|继续|继续做|接着|接着做|往下做|按刚才的|照刚才的|同样处理|这个也一样)[.!。！\s]*$/i.test(text)) {
    return null;
  }
  if (/\bmonitor only\b|只监控|只观察/i.test(text)) {
    return { mode: 'monitor', source: 'natural-explicit' };
  }
  if (/\banswer only\b|只回答/i.test(text)) {
    return { mode: 'answer', source: 'natural-explicit' };
  }

  const readOnlyIndex = lastIndexOfAny(text, [
    /\bread[ -]?only\b/i,
    /\breview only\b/i,
    /\binvestigate only\b/i,
    /\b(?:do not|don't|never)\s+(?:edit|change|fix|install|delete|move|write|modify|apply)\b/i,
    /只读|仅调查|只调查|仅检查|只检查|仅审查|只审查|只看不改/i,
    /不要(?:再)?(?:修改|改动|写入|安装|删除|移动|处理|执行|保存)/i,
    /别(?:修改|改动|写入|安装|删除|移动|处理|执行|保存)/i
  ]);
  const changeIndex = lastPositiveChangeIndex(text);
  const postCompletionBoundary = changeIndex >= 0 && readOnlyIndex > changeIndex
    && /(?:完成|做完|处理完|修改完|修复完|安装完|下载完|保存完|移动完|删除完|打包完)(?:后|以后|之后)/i.test(text.slice(changeIndex, readOnlyIndex + 16));

  if (changeIndex >= 0 || readOnlyIndex >= 0) {
    if (changeIndex >= 0 && (readOnlyIndex < 0 || changeIndex > readOnlyIndex || postCompletionBoundary)) {
      return { mode: 'change', source: 'natural-explicit' };
    }
    return { mode: 'review', source: 'natural-explicit' };
  }

  if (/分析|检查|审查|调查|研究|核对|诊断|评估|比较|看看|看一下|查看|确认|盘点|总结|解释|回答|为什么|是什么|怎么|如何|咋样|怎么样|\b(?:analyze|review|inspect|check|compare|explain|summarize|why|what|how)\b|[?？]$/i.test(text)) {
    return { mode: 'review', source: 'natural-read-only' };
  }

  return null;
}

function parseContractPrompt(prompt, previousContract = defaultContract()) {
  const previous = { ...defaultContract(), ...previousContract };
  const directive = parseDirective(String(prompt || ''));
  const correction = naturalCorrection(String(prompt || ''), previous);
  const next = { ...previous };
  let changed = false;

  if (directive) {
    if (directive.mode && directive.mode !== next.mode) {
      next.mode = directive.mode;
      next.agentsUsed = 0;
      changed = true;
    }
    if (directive.level && directive.level !== next.level) {
      next.level = directive.level;
      changed = true;
    }
    if (Number.isInteger(directive.agentBudget) && directive.agentBudget !== next.agentBudget) {
      next.agentBudget = directive.agentBudget;
      next.agentsUsed = 0;
      changed = true;
    }
    if (directive.hashPolicy && directive.hashPolicy !== next.hashPolicy) {
      next.hashPolicy = directive.hashPolicy;
      changed = true;
    }
    if (Array.isArray(directive.allowedPaths)) {
      next.allowedPaths = directive.allowedPaths;
      changed = true;
    }
    if (directive.dependencyPolicy && directive.dependencyPolicy !== next.dependencyPolicy) {
      next.dependencyPolicy = directive.dependencyPolicy;
      changed = true;
    }
    if (directive.mode && !directive.level && next.level === 'watch') {
      next.level = 'guard';
      changed = true;
    }
    if (directive.level === 'off') {
      next.level = 'off';
    }
    next.source = 'directive';
  } else if (correction) {
    if (correction.mode !== next.mode) {
      next.mode = correction.mode;
      next.agentsUsed = 0;
      changed = true;
    }
    if (next.level === 'watch') {
      next.level = 'guard';
      changed = true;
    }
    next.source = correction.source;
  }

  if (next.mode === 'unconfirmed' && next.level !== 'off') {
    next.level = 'watch';
  }

  return { contract: next, changed, directive: Boolean(directive), correction: Boolean(correction) };
}

module.exports = {
  HASH_POLICIES,
  SCOPE_POLICIES,
  LEVELS,
  MODES,
  defaultContract,
  parseContractPrompt
};
