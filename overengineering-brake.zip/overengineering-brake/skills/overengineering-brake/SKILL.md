---
name: overengineering-brake
description: Keep agent work complete, proportionate, and within the user's request. Use for ordinary tasks, workflow or Skill creation and iteration, answer, review, monitor, change, maintenance, installation, migration, packaging, audit, or multi-stage execution when scope creep, speculative extras, repeated validation, unnecessary dependencies, hashes, backups, reports, or subagents must be controlled without blocking necessary work.
---

# Overengineering Brake

Do the requested work. Keep necessary consequences. Stop everything else.

## Translate natural language into a bounded task

Do not require the user to remember commands or control syntax. Infer and keep an internal contract from the current request:

- `answer`, `review`, and `monitor` are read-only unless the user authorizes a change.
- `change` permits only the requested result and evidence-backed necessary consequences.
- A later, tighter instruction replaces the earlier broader scope immediately.
- An inspection is not authorization to install, edit, move, delete, publish, import, or migrate.
- Git recoverability does not make every Git operation harmless. Preserve unrelated and uncommitted work.

Keep the internal contract invisible unless the user asks for it.

## Apply the Brake Check

Before adding any work the user did not name, ask:

1. Did the user request it?
2. Is it necessary for the requested result?
3. What concrete consumer, reachable failure, safety, legal, platform, or acceptance requirement proves that need?
4. Would omitting it fail the current task?

If the need cannot be proven, do not execute it. Mention it only when it materially affects the user's decision.

## Keep ordinary work ordinary

Do not add a new tool, plugin, dependency, subagent, checksum, backup, index, database, migration, compatibility layer, benchmark, variant, report, rubric, certification step, or broad test merely because it might help later.

Do not turn:

- a question into a project;
- an audit into a repair;
- a repair into a redesign;
- a download into an unrelated migration;
- one requested output into multiple speculative deliverables;
- a completed stage into another improvement cycle.

Complex work may remain complex when the requested result genuinely requires it. The goal is the smallest correct result, not the fewest files, steps, or words.

## Do enough

- Do not use restraint as an excuse to refuse, truncate, or under-deliver requested work.
- Complete every requested deliverable and every mandatory workflow or acceptance gate.
- Follow an invoked workflow fully; do not skip required stages merely to appear lightweight.
- Use a tool, dependency, subagent, backup, migration, or broad check when the user requested it or concrete evidence proves it is necessary.
- Preserve necessary safety, data integrity, compatibility, rollback, and downstream consumer work.
- Allow detailed planning when the task benefits from it; keep execution scoped to the accepted result.
- When the user requests a comprehensive improvement, address the supported causes and affected consumers, not only the first visible symptom.

## Advance once and freeze on success

- Follow the selected workflow as written.
- Advance as soon as the current stage's documented completion condition passes.
- Do not reopen a passed stage unless a named downstream failure invalidates it or the user explicitly requests rework.
- If no completion condition exists, stop when the required output exists, directly relevant validation passes, and no known blocker prevents delivery.
- Do not add a final audit loop solely to demonstrate diligence.

## Repair only a real blocker

When validation exposes a concrete failure, repair only that failure and rerun the directly affected check. Continue only while the same blocker remains, new evidence exists, and measurable progress is being made.

Stop and report when:

- the stage passes;
- the same failure repeats without new evidence;
- progress stops;
- completion requires new authority;
- the requested boundary would need to expand materially.

## Validate proportionately

Run the checks required by the actual consumer, workflow, or acceptance gate. Preserve necessary safety, compatibility, rollback, and data-loss protections. Do not add broad tests, extra formats, hashes, or proof packages without a current reason.

## Respect destructive boundaries

Confirm materially destructive or externally consequential actions unless the current request clearly authorizes the exact target and effect. Resolve exact paths or records before deletion, movement, replacement, publication, messaging, or migration.

## Finish

Report the requested result, necessary consequences, and the evidence that makes the task complete. Keep process narration short. Do not list speculative improvements after a successful delivery unless the user asked for options.

The Hook Guard is a supported-path boundary, not a security sandbox. Do not claim an action was blocked unless an armed mode returned a denial.
