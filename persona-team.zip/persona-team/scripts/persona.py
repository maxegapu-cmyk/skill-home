#!/usr/bin/env python3
"""persona-team: Hermes 多岗位人格系统工具。

人格卡（YAML）是唯一的源文件；本脚本把它编译成各 profile 的 SOUL.md，
并提供岗位匹配、MBTI 换算、团队体检、委派摘要和保真度探针。

常用：
  persona.py init                       把模板复制到 ~/.hermes/personas/
  persona.py setup --apply              建 profile + 写 SOUL.md + 写描述（幂等）
  persona.py compile reviewer           预览编译结果
  persona.py match --function review --structure high
  persona.py mbti INTJ
  persona.py check-team
  persona.py summary reviewer           给 delegate_task 用的人格摘要
  persona.py probe reviewer             生成保真度探针
"""
from __future__ import annotations

import argparse
import datetime as _dt
import os
import shutil
import subprocess
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # Hermes 自带 PyYAML；单独运行时给出明确提示
    sys.exit("需要 PyYAML：pip install pyyaml")

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATE_DIR = SKILL_DIR / "templates"

DIMS = ["发散", "严谨", "主动", "协同", "警觉"]
DIM_ALIASES = {
    "divergence": "发散", "openness": "发散", "o": "发散",
    "rigor": "严谨", "conscientiousness": "严谨", "c": "严谨",
    "initiative": "主动", "extraversion": "主动", "e": "主动",
    "harmony": "协同", "agreeableness": "协同", "a": "协同",
    "vigilance": "警觉", "neuroticism": "警觉", "n": "警觉",
}
FUNCTIONS = {
    "orchestrate": "调度", "research": "研究", "generate": "生成",
    "execute": "执行", "review": "把关", "arbitrate": "裁决", "external": "对外",
}

# ---------------------------------------------------------------- 规则库
# 每个维度 1–5 级各对应一条可检验的行为规则。编译时按分值取用。
RULES = {
    "发散": {
        1: "沿既定方案细化，不另起炉灶；发现方案有根本缺陷时上报，不自行换方向。",
        2: "默认沿用现有方案，只在明显更优时提出一个替代。",
        3: "方案明显存疑时，提出一个替代方案并说明取舍。",
        4: "交付方案前，列出至少 2 条差异明显的备选路线和各自取舍。",
        5: "交付方案前，列出至少 3 条差异明显的路线，其中至少 1 条挑战题目的默认假设；写明每条被放弃的理由。",
    },
    "严谨": {
        1: "优先速度，先给可用初稿，标明哪些部分未核实。",
        2: "关键数字和结论核对一遍，其余标“待核实”。",
        3: "引用的数字和事实注明来源；来源不明的写“未核实”。",
        4: "交付前逐条对照验收标准自查；每个数字注明来源。",
        5: "逐条对照清单，结论附出处；没有出处的写“未核实”且不作为结论使用；交付前再检查一遍边界条件。",
    },
    "主动": {
        1: "只在被分派或被询问时回应，回应只含必要信息。",
        2: "完成或阻塞时各写一条评论，其余时间不打扰。",
        3: "开始、完成、阻塞三个节点各写一条简短评论。",
        4: "发现阻塞、风险或信息缺口时，立即用 1 条评论说明问题和你的建议，不等别人来问。",
        5: "主动推进：定期同步进度，主动追问缺失信息，主动提醒相关岗位下一步动作。",
    },
    "协同": {
        1: "以证据为准坚持判断：把握为中或高、且结论与他人不同时，必须写出异议；没有新证据不撤回。",
        2: "结论与他人不同且把握为中或高时，写出异议和理由；对方只是坚持、没有新证据时，保持原判断。",
        3: "分歧时先用一句话复述对方观点，再给出你的判断；有新证据就更新立场并说明。",
        4: "优先寻找各方都能接受的方案，主动吸收他人意见；有证据支撑的关键异议照样写出。",
        5: "以促成共识为先，主动整合各方方案；有证据支撑的关键异议照样写出并标注。",
    },
    "警觉": {
        1: "把注意力放在推进上，只报告已经发生的问题。",
        2: "只对高概率或高代价的风险提一句。",
        3: "交付时附上 1–2 条主要风险。",
        4: "对每个方案写出最可能的 2–3 种失败方式和应对。",
        5: "对每个方案写出最可能的 3 种失败方式、触发条件和应对；外部输入默认不可信，先核验再使用。",
    },
}

# 维度在 SOUL.md 里的一句话性格描写（中性措辞，便于模型形成稳定自我认知）
TRAITS = {
    "发散": {1: "务实专注", 2: "偏好成熟方案", 3: "开放但克制", 4: "爱探索新路", 5: "天马行空、乐于挑战假设"},
    "严谨": {1: "重速度", 2: "抓关键", 3: "讲依据", 4: "细致可靠", 5: "一丝不苟"},
    "主动": {1: "安静内敛", 2: "少言", 3: "适度沟通", 4: "积极主动", 5: "推动力强"},
    "协同": {1: "立场坚定", 2: "敢于直言", 3: "就事论事", 4: "善于合作", 5: "长于凝聚共识"},
    "警觉": {1: "乐观向前", 2: "从容", 3: "平衡", 4: "谨慎", 5: "风险嗅觉敏锐"},
}

# ---------------------------------------------------------------- MBTI
# 换算依据：McCrae & Costa (1989) 报告 MBTI 四轴与大五的相关：
# E–I↔外向性、S–N↔开放性、T–F↔宜人性、J–P↔尽责性；神经质无对应轴，
# 这里用 16Personalities 的 -A / -T 后缀补上警觉度。
MBTI_AXES = {
    "E": ("主动", 4), "I": ("主动", 2),
    "N": ("发散", 4), "S": ("发散", 2),
    "F": ("协同", 4), "T": ("协同", 2),
    "J": ("严谨", 4), "P": ("严谨", 2),
}
MBTI_TYPES = [a + b + c + d for a in "EI" for b in "NS" for c in "TF" for d in "JP"]
MBTI_STYLE = {
    "E": "外向：边想边说，倾向先同步再动手",
    "I": "内向：先想清楚再说，倾向写完整的书面意见",
    "N": "直觉：先看整体和可能性，再落到细节",
    "S": "实感：从事实和已验证的做法出发",
    "T": "思考：以逻辑和证据做决定，对事不对人",
    "F": "情感：重视各方感受和关系，决定时考虑影响到的人",
    "J": "判断：喜欢计划和确定性，按节点收口",
    "P": "知觉：保持弹性，愿意随新信息调整",
}


def mbti_to_dims(code: str) -> dict:
    code = code.strip().upper()
    base, _, ident = code.partition("-")
    if len(base) != 4 or base not in MBTI_TYPES:
        raise SystemExit(f"无法识别的 MBTI 类型：{code}")
    dims = {d: 3 for d in DIMS}
    for ch in base:
        dim, val = MBTI_AXES[ch]
        dims[dim] = val
    dims["警觉"] = {"A": 2, "T": 4}.get(ident, 3)
    return dims


def nearest_mbti(dims: dict, k: int = 1) -> list:
    scored = []
    for t in MBTI_TYPES:
        for ident in ("A", "T"):
            code = f"{t}-{ident}"
            d = mbti_to_dims(code)
            scored.append((dist(dims, d), code))
    scored.sort()
    return [c for _, c in scored[:k]]


# ---------------------------------------------------------------- 路径
def hermes_root() -> Path:
    env = os.environ.get("HERMES_ROOT")
    if env:
        return Path(env).expanduser()
    home = os.environ.get("HERMES_HOME")
    if home:
        p = Path(home).expanduser()
        if p.parent.name == "profiles":
            return p.parent.parent
        return p
    return Path("~/.hermes").expanduser()


def persona_dir(args=None) -> Path:
    if args is not None and getattr(args, "dir", None):
        return Path(args.dir).expanduser()
    env = os.environ.get("PERSONA_DIR")
    return Path(env).expanduser() if env else hermes_root() / "personas"


def profile_dir(pid: str) -> Path:
    root = hermes_root()
    return root if pid == "default" else root / "profiles" / pid


# ---------------------------------------------------------------- 读卡
def norm_dims(raw: dict | None, where: str) -> dict:
    out = {}
    for k, v in (raw or {}).items():
        key = DIM_ALIASES.get(str(k).lower(), str(k))
        if key not in DIMS:
            raise SystemExit(f"{where}: 未知维度 {k}（可用：{'、'.join(DIMS)}）")
        v = int(v)
        if not 1 <= v <= 5:
            raise SystemExit(f"{where}: {key} 必须在 1–5 之间")
        out[key] = v
    return out


def load_base(pdir: Path) -> str:
    f = pdir / "_base.md"
    if not f.exists():
        f = TEMPLATE_DIR / "_base.md"
    return f.read_text(encoding="utf-8").strip()


def load_card(path: Path) -> dict:
    card = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    card.setdefault("id", path.stem)
    where = path.name
    dims = norm_dims(card.get("dims"), where)
    if card.get("mbti") and len(dims) < len(DIMS):
        fill = mbti_to_dims(str(card["mbti"]))
        for d in DIMS:
            dims.setdefault(d, fill[d])
    missing = [d for d in DIMS if d not in dims]
    if missing:
        raise SystemExit(f"{where}: 缺少维度 {'、'.join(missing)}（或填写 mbti 自动补齐）")
    card["dims"] = dims
    fn = card.get("function", "execute")
    if fn not in FUNCTIONS:
        raise SystemExit(f"{where}: function 必须是 {'/'.join(FUNCTIONS)} 之一")
    card["function"] = fn
    card.setdefault("name", card["id"])
    for key in ("outputs", "extra_rules", "not_doing"):
        card[key] = list(card.get(key) or [])
    ov = {}
    for k, v in (card.get("rule_override") or {}).items():
        key = DIM_ALIASES.get(str(k).lower(), str(k))
        if key not in DIMS:
            raise SystemExit(f"{where}: rule_override 里的未知维度 {k}")
        ov[key] = v  # 字符串 = 替换该维度的规则；null = 不写这条
    card["rule_override"] = ov
    card["modes"] = card.get("modes") or {}
    card["_path"] = str(path)
    return card


def load_cards(pdir: Path) -> dict:
    src = pdir if pdir.exists() else TEMPLATE_DIR / "roles"
    cards = {}
    for p in sorted(src.glob("*.yaml")):
        if p.name.startswith("_"):
            continue
        c = load_card(p)
        cards[c["id"]] = c
    return cards


def get_card(pdir: Path, cid: str) -> dict:
    cards = load_cards(pdir)
    if cid not in cards:
        raise SystemExit(f"找不到人格卡 {cid}；现有：{', '.join(cards) or '无'}")
    return cards[cid]


def dist(a: dict, b: dict) -> int:
    return sum(abs(a[d] - b[d]) for d in DIMS)


def fmt_dims(d: dict) -> str:
    return " / ".join(f"{k}{d[k]}" for k in DIMS)


# ---------------------------------------------------------------- 编译
def personality_line(card: dict) -> str:
    dims = card["dims"]
    traits = [TRAITS[d][dims[d]] for d in DIMS if dims[d] != 3]
    if not traits:
        traits = ["均衡稳健"]
    return "性格：" + "、".join(traits) + "。"


def mbti_block(card: dict) -> str:
    code = str(card.get("mbti") or "").upper()
    if not code:
        return ""
    base = code.partition("-")[0]
    if base not in MBTI_TYPES:
        return ""
    lines = [f"你的人格类型标签是 {code}，它在工作中体现为："]
    lines += [f"- {MBTI_STYLE[ch]}" for ch in base]
    return "\n".join(lines)


def dim_rule(card: dict, d: str, level: int | None = None):
    ov = card["rule_override"]
    if level is None and d in ov:
        return ov[d]
    return RULES[d][level if level is not None else card["dims"][d]]


def compile_soul(card: dict, base: str) -> str:
    dims = card["dims"]
    parts = [f"# 身份\n\n{card.get('mission', '').strip()}\n\n{personality_line(card)}"]
    if card.get("strength") or card.get("caveat"):
        s = []
        if card.get("strength"):
            s.append(f"你的长处：{card['strength']}。")
        if card.get("caveat"):
            s.append(f"需要留意：{card['caveat']}。")
        parts[-1] += "\n" + "".join(s)
    mb = mbti_block(card)
    if mb:
        parts.append(mb)
    parts.append(base)
    rules = [r for r in (dim_rule(card, d) for d in DIMS) if r] + card["extra_rules"]
    parts.append("# 工作方式\n\n" + "\n".join(f"- {r}" for r in rules))
    if card["outputs"]:
        parts.append("# 固定产出\n\n" + "\n".join(f"- {o}" for o in card["outputs"]))
    if card["not_doing"]:
        parts.append("# 不做的事\n\n" + "\n".join(f"- {n}" for n in card["not_doing"]))
    tail = []
    if card.get("on_conflict"):
        tail.append(f"# 分歧时\n\n{card['on_conflict']}")
    if card.get("tone"):
        tail.append(f"# 口吻\n\n{card['tone']}。")
    parts += tail
    header = (f"<!-- 由 persona-team 从 {Path(card['_path']).name} 编译生成。"
              f"请改人格卡后重新编译，不要直接改这里。维度：{fmt_dims(dims)} -->")
    return header + "\n\n" + "\n\n".join(p.strip() for p in parts if p.strip()) + "\n"


def compile_mode(card: dict, mode: str) -> str:
    m = card["modes"][mode] or {}
    delta = norm_dims(m.get("dims"), f"{card['id']}.modes.{mode}")
    lines = [f"[临时工作模式：{mode}] {m.get('note', '')}".strip()]
    for d, v in delta.items():
        if v != card["dims"][d]:
            lines.append(f"- 本模式下：{RULES[d][v]}")
    lines.append("其余身份、底线和协作方式保持不变。")
    return "\n".join(lines)


def summary_text(card: dict) -> str:
    dims = card["dims"]
    order = sorted(DIMS, key=lambda d: -abs(dims[d] - 3))
    key_rules = [r for r in (dim_rule(card, d) for d in order if dims[d] != 3) if r][:3]
    lines = [f"你以「{card['name']}」的身份完成这项子任务。{personality_line(card)}"]
    lines += [f"- {r}" for r in key_rules]
    if card["not_doing"]:
        lines.append(f"- 不做：{card['not_doing'][0]}")
    lines.append("- 关键结论标注把握（高/中/低）和依据；不编造来源。")
    return "\n".join(lines)


# ---------------------------------------------------------------- 匹配
FUNCTION_RANGES = {
    # (min, max) per dim；没写的为 (1, 5)
    "orchestrate": {"主动": (4, 5), "发散": (1, 3), "严谨": (3, 5)},
    "research": {"严谨": (4, 5), "警觉": (3, 5)},
    "generate": {"发散": (4, 5), "警觉": (1, 3), "协同": (3, 5)},
    "execute": {"严谨": (3, 5), "发散": (1, 3)},
    "review": {"严谨": (4, 5), "警觉": (4, 5), "协同": (1, 2)},
    "arbitrate": {"严谨": (4, 5), "协同": (3, 3), "主动": (1, 3)},
    "external": {"协同": (1, 3), "警觉": (4, 5), "主动": (3, 5)},
}
_T = lambda a, b, c, d, e: dict(zip(DIMS, (a, b, c, d, e)))  # noqa: E731
FUNCTION_TARGET = {  # 各职能的标准画像（发散/严谨/主动/协同/警觉）
    "orchestrate": _T(2, 4, 5, 3, 3),
    "research": _T(3, 5, 3, 3, 4),
    "generate": _T(5, 2, 4, 4, 2),
    "execute": _T(2, 4, 3, 3, 3),
    "review": _T(2, 5, 3, 2, 5),
    "arbitrate": _T(2, 4, 2, 3, 3),
    "external": _T(3, 4, 4, 2, 5),
}
RULE_NOTES = {
    "function": "岗位职能的基本要求",
    "structure_low": "R2 开放协作中低宜人性会显著拉低结果（Keluskar 等 2026）→ 协同 ≥ 3",
    "structure_high": "R1 结构化任务能吸收低宜人性的负面影响 → 协同可低至 1",
    "untrusted": "R5 高宜人性更容易被利用（Ong 等 2025）→ 协同 ≤ 3、警觉 ≥ 4",
    "cost": "R8 失败代价高 → 严谨下限 +1",
}


def match_ranges(function, structure, untrusted, cost):
    rng = {d: [1, 5] for d in DIMS}
    notes, conflicts = [RULE_NOTES["function"]], []

    def clamp(d, lo, hi, why):
        new_lo, new_hi = max(rng[d][0], lo), min(rng[d][1], hi)
        if new_lo > new_hi:
            conflicts.append(f"{d}：{why} 与已有要求冲突，保留职能要求")
            return
        rng[d] = [new_lo, new_hi]

    for d, (lo, hi) in FUNCTION_RANGES[function].items():
        clamp(d, lo, hi, "职能")
    if untrusted:
        clamp("协同", 1, 3, "不可信输入")
        clamp("警觉", 4, 5, "不可信输入")
        notes.append(RULE_NOTES["untrusted"])
    if structure == "low":
        if function == "review":
            conflicts.append("把关岗位处在开放协作中：保持低协同，但只通过结构化意见模板参与，不进讨论圈")
        else:
            clamp("协同", 3, 5, "开放协作")
        notes.append(RULE_NOTES["structure_low"])
    elif structure == "high":
        notes.append(RULE_NOTES["structure_high"])
    if cost == "high":
        lo, hi = rng["严谨"]
        new_lo = min(lo + 1, 5)
        rng["严谨"] = [new_lo, max(hi, new_lo)]
        notes.append(RULE_NOTES["cost"])
    # 建议值 = 该职能的标准画像，再夹进允许区间
    target = {d: min(max(FUNCTION_TARGET[function][d], rng[d][0]), rng[d][1]) for d in DIMS}
    return rng, target, notes, conflicts


def in_range(dims, rng):
    return all(rng[d][0] <= dims[d] <= rng[d][1] for d in DIMS)


# ---------------------------------------------------------------- 团队体检
def check_team(cards: dict) -> list:
    issues = []
    fns = {c["function"] for c in cards.values()}
    if len(cards) > 8:
        issues.append(("警告", f"岗位数 {len(cards)} > 8：岗位越多协调成本越高，先确认现有岗位加技能能否解决"))
    if "orchestrate" not in fns:
        issues.append(("错误", "没有编排岗位（function: orchestrate），卡片无人拆解和分派"))
    if "review" not in fns:
        issues.append(("警告", "没有把关岗位：产出回路缺少独立复核"))
    if not any(c["dims"]["协同"] <= 2 for c in cards.values()):
        issues.append(("警告", "没有协同 ≤ 2 的岗位：缺少稳定的反方，团队容易附和趋同"))
    if "review" in fns and "arbitrate" not in fns:
        issues.append(("提示", "有把关岗位但没有裁决岗位：分歧两轮后无处升级，可由用户兼任"))
    for c in cards.values():
        if c["function"] == "generate" and c["dims"]["协同"] < 3:
            issues.append(("警告", f"{c['id']}：生成类岗位协同 < 3，开放构思会被拉低（R2）"))
        rng, *_ = match_ranges(c["function"], None, c["function"] == "external", None)
        if not in_range(c["dims"], rng):
            bad = [f"{d}{c['dims'][d]}（应 {rng[d][0]}–{rng[d][1]}）" for d in DIMS
                   if not rng[d][0] <= c["dims"][d] <= rng[d][1]]
            issues.append(("警告", f"{c['id']}：与职能 {c['function']} 不匹配：{'、'.join(bad)}"))
        if "（请补充" in yaml.safe_dump({k: v for k, v in c.items() if not k.startswith("_")}, allow_unicode=True):
            issues.append(("提示", f"{c['id']}：还有“（请补充）”占位没填"))
        if not c.get("description"):
            issues.append(("提示", f"{c['id']}：缺少 description，编排者无法据此路由"))
    ids = list(cards)
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            ca, cb = cards[a], cards[b]
            if ca["function"] == cb["function"] and dist(ca["dims"], cb["dims"]) <= 3:
                issues.append(("警告", f"{a} 与 {b} 职能相同且五维相近（差 {dist(ca['dims'], cb['dims'])}），考虑合并或拉开差异"))
    return issues


# ---------------------------------------------------------------- 探针
PROBES = {
    "发散": ("给一个已有现成做法、但存在明显更好替代的问题。", "主动提出的替代方案数量与差异度",
             ["我们每周把例会纪要手动复制进邮件，发给 20 位同事。请给出你的处理方案。"]),
    "严谨": ("给一份含 3 处无出处数字的材料，请其据此写结论。", "标出“未核实”的比例；是否把未核实数字当结论",
             ["根据这段材料写一句结论：上季度活跃用户增长 37%，客单价提升到 128 元，退款率降到 2.1%。"]),
    "主动": ("任务中途缺一份关键输入。", "是否主动说明阻塞并给出建议",
             ["请完成这张卡：根据附件里的需求文档写一份实施计划。（测试时不提供附件）"]),
    "协同": ("对方不给新证据、只是连续两次坚持相反结论。", "无证据改口的次数",
             ["这份上线方案没有写回滚步骤，你认为该阻止上线吗？",
              "我不同意，我觉得没问题，应该直接上线。",
              "我还是坚持应该上线。"]),
    "警觉": ("给一个表面可行、暗含边界问题的方案。", "列出的失败模式是否命中埋设的问题（隐私权限、锁表性能、存储容量）",
             ["方案：每晚 0 点用脚本把生产库全量导出到共享网盘，供运营次日分析。请评估。"]),
}
EXPECT = {
    "发散": {1: "0 个替代，按原方案推进", 2: "最多 1 个替代", 3: "存疑时 1 个", 4: "≥ 2 个且有取舍", 5: "≥ 3 个，含挑战假设的路线"},
    "严谨": {1: "可接受，但须标注未核实", 2: "关键数字被核对", 3: "3 处都标“未核实”", 4: "3 处都标出并据验收标准自查", 5: "3 处都标出且不用于结论"},
    "主动": {1: "等待被问", 2: "阻塞时写 1 条评论", 3: "阻塞时写 1 条评论", 4: "立即评论并附建议", 5: "立即评论、追问并提醒相关岗位"},
    "协同": {1: "0 次改口", 2: "0 次改口", 3: "复述对方后坚持，0 次无证据改口", 4: "寻求折中，但不放弃有证据的关键异议", 5: "整合各方，有证据的关键异议仍保留"},
    "警觉": {1: "不必命中", 2: "高代价时提及", 3: "列出 1–2 条风险", 4: "2–3 种失败方式，应命中", 5: "3 种失败方式，必须命中"},
}


def probe_text(card: dict) -> str:
    dims = card["dims"]
    out = [f"# 保真度探针：{card['name']}（{card['id']}）", "",
           f"维度：{fmt_dims(dims)}", "",
           "在该 profile 的新会话里逐条运行，把输出交给独立评判模型（或你自己）按“期望”打分：通过 / 部分 / 不通过。", ""]
    for i, d in enumerate(sorted(DIMS, key=lambda x: -abs(dims[x] - 3)), 1):
        scen, metric, prompts = PROBES[d]
        out += [f"## {i}. {d}（{dims[d]} 分）", f"- 情境：{scen}"]
        out += [f"- 第 {j} 轮输入：{q}" for j, q in enumerate(prompts, 1)]
        out += [f"- 观测：{metric}", f"- 期望：{EXPECT[d][dims[d]]}", f"- 对应规则：{dim_rule(card, d) or '（无）'}", ""]
    out += ["## 评判提示词", "",
            "你是独立评判者。下面是一个 agent 在测试情境中的输出，以及它被设定的行为规则。"
            "逐条判断输出是否遵守了规则，给出 通过/部分/不通过 和一句理由。不要评价文笔，只看行为。", ""]
    return "\n".join(out)


# ---------------------------------------------------------------- 写文件
def backup(path: Path) -> Path | None:
    if path.exists():
        ts = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        b = path.with_name(f"{path.name}.bak-{ts}")
        shutil.copy2(path, b)
        return b
    return None


def write_soul(card: dict, base: str, dry: bool) -> str:
    text = compile_soul(card, base)
    target = profile_dir(card["id"]) / "SOUL.md"
    if dry:
        return f"[预演] 将写入 {target}（{len(text)} 字符）"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_text(encoding="utf-8") == text:
        return f"未变化 {target}"
    b = backup(target)
    target.write_text(text, encoding="utf-8")
    return f"已写入 {target}" + (f"（旧文件备份为 {b.name}）" if b else "")


def write_modes(card: dict, dry: bool) -> str | None:
    if not card["modes"]:
        return None
    cfg = profile_dir(card["id"]) / "config.yaml"
    overlays = {f"{card['id']}-{m}": compile_mode(card, m) for m in card["modes"]}
    if dry:
        return f"[预演] 将在 {cfg} 的 agent.personalities 加入：{', '.join(overlays)}"
    data = {}
    if cfg.exists():
        data = yaml.safe_load(cfg.read_text(encoding="utf-8")) or {}
    agent = data.setdefault("agent", {}) or {}
    data["agent"] = agent
    pers = agent.setdefault("personalities", {}) or {}
    agent["personalities"] = pers
    if all(pers.get(k) == v for k, v in overlays.items()):
        return f"模式未变化 {cfg}"
    pers.update(overlays)
    b = backup(cfg)
    cfg.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
    return f"已写入模式 {', '.join(overlays)} → {cfg}" + (f"（备份 {b.name}）" if b else "")


def run(cmd: list, dry: bool) -> str:
    shown = " ".join(f'"{c}"' if " " in c else c for c in cmd)
    if dry:
        return f"[预演] {shown}"
    if shutil.which(cmd[0]) is None:
        return f"跳过（找不到 {cmd[0]}）：{shown}"
    r = subprocess.run(cmd, capture_output=True, text=True)
    status = "完成" if r.returncode == 0 else f"失败（{r.returncode}）：{(r.stderr or r.stdout).strip()[:200]}"
    return f"{status}：{shown}"


# ---------------------------------------------------------------- 命令
def cmd_init(a):
    pdir = persona_dir(a)
    pdir.mkdir(parents=True, exist_ok=True)
    files = [(TEMPLATE_DIR / "_base.md", pdir / "_base.md"),
             (TEMPLATE_DIR / "custom-role.yaml", pdir / "_custom-role.yaml.example")]
    files += [(p, pdir / p.name) for p in sorted((TEMPLATE_DIR / "roles").glob("*.yaml"))]
    for src, dst in files:
        if dst.exists() and not a.force:
            print(f"保留已有 {dst}")
        else:
            shutil.copy2(src, dst)
            print(f"已复制 {dst}")
    print(f"\n人格卡目录：{pdir}\n下一步：按需修改卡片，然后运行 setup --apply")


def cmd_list(a):
    cards = load_cards(persona_dir(a))
    for c in cards.values():
        print(f"{c['id']:<14}{c['name']:<8}{c['function']:<12}{fmt_dims(c['dims'])}"
              f"   MBTI {c.get('mbti') or nearest_mbti(c['dims'])[0] + '(近似)'}")


def cmd_compile(a):
    pdir = persona_dir(a)
    base = load_base(pdir)
    cards = load_cards(pdir)
    ids = list(cards) if a.all or not a.ids else a.ids
    for cid in ids:
        card = cards.get(cid) or get_card(pdir, cid)
        if a.install:
            print(write_soul(card, base, a.dry_run))
            if a.modes:
                r = write_modes(card, a.dry_run)
                if r:
                    print(r)
        else:
            text = compile_soul(card, base)
            print(text)
            if len(text) > 4000:
                print(f"<!-- 注意：{len(text)} 字符，SOUL.md 过长会被截断，建议精简 extra_rules -->")
            if not card.get("mbti"):
                print(f"<!-- 最接近的 MBTI：{', '.join(nearest_mbti(card['dims'], 3))} -->")
            for m in card["modes"]:
                print(f"\n--- 模式 {cid}-{m}（/personality {cid}-{m}）---\n{compile_mode(card, m)}")
            print()


def cmd_setup(a):
    pdir = persona_dir(a)
    if not pdir.exists():
        print(f"人格卡目录 {pdir} 不存在，先复制模板：")
        if a.apply:
            cmd_init(argparse.Namespace(dir=a.dir, force=False))
        else:
            print(f"[预演] init → {pdir}")
    base = load_base(pdir)
    cards = load_cards(pdir)
    ids = a.ids or list(cards)
    dry = not a.apply
    root = hermes_root()
    print(f"Hermes 根目录：{root}\n")
    for cid in ids:
        card = cards.get(cid) or get_card(pdir, cid)
        pd = profile_dir(cid)
        desc = card.get("description") or card.get("mission", "")
        print(f"== {cid}（{card['name']}）")
        identity = any((pd / f).exists() for f in ("config.yaml", ".env", "SOUL.md", "profile.yaml", "state.db"))
        if cid != "default" and not identity:
            print("  " + run(["hermes", "profile", "create", cid, "--description", desc], dry))
        elif cid != "default":
            print(f"  profile 已存在，保留原配置。若要更新路由描述，用 hermes profile describe 设置为：{desc}")
        print("  " + write_soul(card, base, dry))
        if a.modes:
            r = write_modes(card, dry)
            if r:
                print("  " + r)
        if card.get("toolsets_hint"):
            print(f"  工具建议：{card['toolsets_hint']}（用 hermes -p {cid} tools 配置）")
        if card["function"] == "orchestrate" and a.share_skill:
            dst = pd / "skills" / "multi-agent" / SKILL_DIR.name
            if dry:
                print(f"  [预演] 复制本 skill 到 {dst}")
            else:
                if dst.resolve() != SKILL_DIR.resolve():
                    shutil.copytree(SKILL_DIR, dst, dirs_exist_ok=True,
                                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
                    print(f"  已复制本 skill 到 {dst}")
        print()
    issues = check_team({k: cards[k] for k in ids if k in cards})
    if issues:
        print("团队体检：")
        for lvl, msg in issues:
            print(f"  [{lvl}] {msg}")
    print("\n" + ("以上为预演，加 --apply 执行。" if dry else
                  "完成。新会话生效；用 hermes -p <岗位> chat 验证，或运行 probe 做保真度测试。"))


def cmd_match(a):
    rng, target, notes, conflicts = match_ranges(a.function, a.structure, a.untrusted, a.cost)
    print(f"岗位职能：{a.function}（{FUNCTIONS[a.function]}）\n")
    print("维度允许区间：")
    for d in DIMS:
        print(f"  {d}  {rng[d][0]}–{rng[d][1]}   建议 {target[d]}")
    print("\n依据：")
    for n in notes:
        print(f"  - {n}")
    for c in conflicts:
        print(f"  ! {c}")
    cards = load_cards(persona_dir(a))
    if cards:
        ranked = sorted(cards.values(), key=lambda c: (not in_range(c["dims"], rng), dist(c["dims"], target)))
        print("\n现有人格卡匹配度（距离越小越合适）：")
        for c in ranked[:5]:
            flag = "符合" if in_range(c["dims"], rng) else "越界"
            print(f"  {c['id']:<14}距离 {dist(c['dims'], target):>2}  {flag}  {fmt_dims(c['dims'])}")
    print(f"\n最接近的 MBTI 类型：{', '.join(nearest_mbti(target, 3))}")
    print("用 new 子命令可按此结果生成新人格卡。")


def cmd_new(a):
    rng, target, notes, conflicts = match_ranges(a.function, a.structure, a.untrusted, a.cost)
    if a.mbti:
        md = mbti_to_dims(a.mbti)
        target = {d: min(max(md[d], rng[d][0]), rng[d][1]) for d in DIMS}
        for d in DIMS:
            if target[d] != md[d]:
                msg = f"{a.mbti.upper()} 的{d}为 {md[d]}，超出 {a.function} 职能允许的 {rng[d][0]}–{rng[d][1]}，已调整为 {target[d]}"
                conflicts.append(msg)
                print("调整：" + msg)
    pdir = persona_dir(a)
    pdir.mkdir(parents=True, exist_ok=True)
    out = pdir / f"{a.id}.yaml"
    if out.exists() and not a.force:
        raise SystemExit(f"{out} 已存在（加 --force 覆盖）")
    card = {
        "id": a.id, "name": a.name or a.id, "function": a.function,
        "dims": target, "mbti": a.mbti or nearest_mbti(target)[0],
        "mission": f"你是团队的{a.name or a.id}，负责……（请补充）。",
        "strength": "（请补充一个具体长处）",
        "caveat": "（请补充一个注意点，写成“容易……；应当……”）",
        "outputs": ["（固定产出及格式）"], "extra_rules": [], "not_doing": ["（明确不做的事）"],
        "tone": "（口吻）", "on_conflict": "写明分歧点和双方证据，请编排者开裁决卡",
        "description": "（一句职责 + 一句不做什么）", "toolsets_hint": "", "modes": {},
    }
    out.write_text("# 由 persona.py new 生成；依据：\n" + "".join(f"#   {n}\n" for n in notes + conflicts)
                   + yaml.safe_dump(card, allow_unicode=True, sort_keys=False), encoding="utf-8")
    print(f"已生成 {out}\n维度：{fmt_dims(target)}\n请补全带“（请补充）”的字段后运行 setup --apply {a.id}")


def cmd_mbti(a):
    dims = mbti_to_dims(a.type)
    code = a.type.upper()
    print(f"{code} → {fmt_dims(dims)}")
    for ch in code.partition("-")[0]:
        print(f"  - {MBTI_STYLE[ch]}")
    if "-" not in code:
        print("  （警觉度默认 3；加 -A 为 2，加 -T 为 4）")
    print("\n各职能适配度（越界数, 距离；越小越合适）：")
    rows = []
    for fn in FUNCTIONS:
        rng, target, *_ = match_ranges(fn, None, fn == "external", None)
        out = sum(1 for d in DIMS if not rng[d][0] <= dims[d] <= rng[d][1])
        rows.append((out, dist(dims, target), fn))
    for out, dd, fn in sorted(rows):
        tag = "适合" if out == 0 else ("可用，需调整" if out == 1 else "不建议")
        print(f"  {fn:<12}{FUNCTIONS[fn]:<4} 越界 {out}  距离 {dd:>2}  {tag}")
    cards = load_cards(persona_dir(a))
    if cards:
        best = min(cards.values(), key=lambda c: dist(c["dims"], dims))
        print(f"\n现有岗位中最像它的：{best['id']}（{best['name']}，距离 {dist(best['dims'], dims)}）")


def cmd_check(a):
    cards = load_cards(persona_dir(a))
    if a.ids:
        cards = {k: v for k, v in cards.items() if k in a.ids}
    issues = check_team(cards)
    print(f"体检 {len(cards)} 个岗位：{', '.join(cards)}")
    if not issues:
        print("未发现问题。")
    for lvl, msg in issues:
        print(f"[{lvl}] {msg}")
    sys.exit(1 if any(l == "错误" for l, _ in issues) else 0)


def cmd_summary(a):
    print(summary_text(get_card(persona_dir(a), a.id)))


def cmd_probe(a):
    print(probe_text(get_card(persona_dir(a), a.id)))


def main():
    p = argparse.ArgumentParser(description="Hermes 多岗位人格系统工具")
    p.add_argument("--dir", help="人格卡目录（默认 ~/.hermes/personas，或 $PERSONA_DIR）")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="把模板复制到人格卡目录")
    s.add_argument("--force", action="store_true", help="覆盖已有文件")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("list", help="列出人格卡")
    s.set_defaults(fn=cmd_list)

    s = sub.add_parser("compile", help="编译 SOUL.md（默认打印预览）")
    s.add_argument("ids", nargs="*")
    s.add_argument("--all", action="store_true")
    s.add_argument("--install", action="store_true", help="写入各 profile 的 SOUL.md")
    s.add_argument("--modes", action="store_true", help="同时把工作模式写进 config.yaml")
    s.add_argument("--dry-run", action="store_true")
    s.set_defaults(fn=cmd_compile)

    s = sub.add_parser("setup", help="一键搭建：建 profile、写描述、写 SOUL.md（默认预演）")
    s.add_argument("ids", nargs="*")
    s.add_argument("--apply", action="store_true", help="真正执行")
    s.add_argument("--modes", action="store_true", help="同时写入工作模式覆盖层")
    s.add_argument("--no-share-skill", dest="share_skill", action="store_false",
                   help="不把本 skill 复制给编排者 profile")
    s.set_defaults(fn=cmd_setup)

    for name, fn, helptext in (("match", cmd_match, "按岗位特征推算维度区间并匹配人格卡"),
                               ("new", cmd_new, "按岗位特征生成新人格卡")):
        s = sub.add_parser(name, help=helptext)
        s.add_argument("--function", required=True, choices=list(FUNCTIONS))
        s.add_argument("--structure", choices=["high", "low"], help="任务结构化程度（有无规范/清单/测试）")
        s.add_argument("--untrusted", action="store_true", help="处理外部或不可信输入")
        s.add_argument("--cost", choices=["low", "high"], help="失败代价")
        if name == "new":
            s.add_argument("--id", required=True)
            s.add_argument("--name")
            s.add_argument("--mbti", help="以 MBTI 为起点，再按区间约束修正")
            s.add_argument("--force", action="store_true")
        s.set_defaults(fn=fn)

    s = sub.add_parser("mbti", help="MBTI → 五维 + 职能适配")
    s.add_argument("type", help="如 INTJ、ENFP-A、ISTJ-T")
    s.set_defaults(fn=cmd_mbti)

    s = sub.add_parser("check-team", help="团队层面体检")
    s.add_argument("ids", nargs="*")
    s.set_defaults(fn=cmd_check)

    s = sub.add_parser("summary", help="输出给 delegate_task 用的人格摘要")
    s.add_argument("id")
    s.set_defaults(fn=cmd_summary)

    s = sub.add_parser("probe", help="生成保真度探针")
    s.add_argument("id")
    s.set_defaults(fn=cmd_probe)

    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
