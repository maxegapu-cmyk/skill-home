---
name: persona-team
description: 给多 agent 团队配人格、按岗位匹配并编译 SOUL.md
version: 1.0.0
author: persona-team
metadata:
  hermes:
    tags: [multi-agent, personality, soul, mbti, kanban, profiles, team]
    category: multi-agent
    requires_toolsets: [terminal]
---

# Persona Team：岗位人格系统

把一组 Hermes profile 组织成一个分工明确的团队：每个岗位一张人格卡（五个工作维度 + 职责 + 禁区），编译成该 profile 的 SOUL.md；按岗位特征匹配人格；用看板协议协作；用探针检验人格是否立住。

## When to Use

- 用户要搭一个多 agent 团队、给 bot 配“灵魂”/人格、或问某个岗位该配什么性格
- 用户用 MBTI 描述岗位或 bot（“给我一个 INTJ 的审核员”）
- 新增、调整、体检岗位；SOUL.md 需要重新生成
- 编排者委派子任务、需要让子代理带上岗位人格
- 用户觉得某个 bot“不像它该有的样子”，需要排查

## 核心概念（先读这段）

- 人格卡 `~/.hermes/personas/<id>.yaml` 是唯一源文件；各 profile 的 SOUL.md 是编译产物，不手改。
- 五个维度，1–5 分：发散（开放性）、严谨（尽责性）、主动（外向性）、协同（宜人性）、警觉（神经质的中性名）。分值编译成可检验的行为规则。
- 七种职能：orchestrate 调度、research 研究、generate 生成、execute 执行、review 把关、arbitrate 裁决、external 对外。
- 默认编制 6 个岗位：orchestrator、researcher、ideator、executor、reviewer、arbiter（模板在 `templates/roles/`）。
- MBTI 可作为入口，会被换算成五维；详见 `references/mbti.md`。

## Procedure

脚本：本 skill 目录下的 `scripts/persona.py`。路径不确定时运行 `find ~/.hermes -path '*persona-team/scripts/persona.py' | head -1`。下文记为 `P`，执行方式 `python3 P <子命令>`。

### A. 首次搭建团队

1. `python3 P init` —— 把模板复制到 `~/.hermes/personas/`（已有文件不覆盖）。
2. 和用户确认岗位清单。用户的业务需要不同岗位时，用 C 节新建；不需要的岗位删掉对应 yaml。
3. `python3 P check-team` —— 有“错误”先修。
4. `python3 P setup` —— 预演，把将要执行的动作给用户看。
5. 用户同意后 `python3 P setup --apply --modes` —— 为每个岗位建 profile（带路由描述）、写 SOUL.md、写工作模式，并把本 skill 复制给编排者 profile。已存在的 profile 只更新 SOUL.md，旧文件自动备份为 `SOUL.md.bak-<时间>`。
6. 按输出里的“工具建议”逐个配置 toolsets（`hermes -p <id> tools`）。审核员和裁决者只读。
7. 告诉用户：SOUL.md 在新会话生效；用 `hermes -p reviewer chat` 试聊，或做 E 节的探针。

### B. 调整某个岗位

1. 改 `~/.hermes/personas/<id>.yaml`（维度、规则、禁区、口吻）。每次只改一个维度，±1。
2. `python3 P compile <id>` 预览，确认后 `python3 P setup --apply <id>`。

### C. 新增岗位 / 回答“这个岗位配什么性格”

1. 从用户描述里判断四个属性：职能、结构化程度（有无规范/清单/测试）、是否处理不可信输入、失败代价。
2. `python3 P match --function <职能> [--structure high|low] [--untrusted] [--cost high]` —— 得到维度区间、建议值、现有卡片匹配度和最接近的 MBTI。
3. 要新建：`python3 P new --id <英文id> --name <中文名> --function ... [--mbti XXXX]`，再补全卡片里所有“（请补充）”字段（mission、strength、caveat、outputs、not_doing、description）。
4. `python3 P check-team` → `python3 P setup --apply <id>`。

### D. MBTI 相关

- `python3 P mbti <类型>`（如 INTJ、ENFP-A、ISTJ-T）—— 五维换算、各职能适配度、现有最像的岗位。
- 用户指定“某岗位要某 MBTI”时，用 `new --mbti`；脚本会把 MBTI 维度夹进该职能的允许区间，冲突时职能要求优先，并向用户说明调整了哪一维。

### E. 检验人格是否立住

1. `python3 P probe <id>` —— 生成探针（每维度的测试输入、观测点、期望行为）。
2. 用 `hermes -p <id> chat -q "<输入>"` 在新会话里逐条运行；协同维度的三轮输入要在同一会话里依次发送。
3. 对照“期望”和“对应规则”打分。不通过的维度：先查规则写法（`rule_override` 是否更贴合岗位），再调分值。
4. 判断人格是否带来净收益，按 `references/evaluation.md` 做对照实验。

### F. 编排者委派时

- 分派前运行 `hermes profile list`，只分派给存在的岗位。
- 按 `references/protocol.md` 的卡片模板和评论模板建卡；审核回路最多 2 轮，之后开裁决卡。
- 用 delegate_task 时，子代理不加载 SOUL.md：先运行 `python3 P summary <id>`，把输出放在 context 开头。

## Pitfalls

- 直接改 profile 里的 SOUL.md 会在下次编译时被覆盖（有备份）。改人格卡。
- 全是 3 分的卡片没有人格；职能核心维度要拉到 1–2 或 4–5。
- 低协同只给把关、对外这类有明确规范的岗位；开放共创岗位协同 ≥ 3，否则产出明显下降。
- 不让 agent 自选队友或自行增加岗位；编制变更由用户决定。
- 不开 profile 之间的直接对聊；所有交流走看板评论。
- SOUL.md 超过约 4000 字符会被截断，编译预览会提示；精简 extra_rules。
- 人设会在长对话里漂移：每张卡一个新会话，长任务拆卡。
- 星座等标签只作口吻装饰，不参与匹配。
- 设置了 HERMES_ROOT 或 PERSONA_DIR 时，脚本以它们为准；在某个 profile 里运行时，脚本会自动找回 ~/.hermes 根目录。

## Verification

- `python3 P check-team` 无“错误”。
- `ls ~/.hermes/profiles/*/SOUL.md` 每个岗位都有，且文件首行是 persona-team 的编译注释。
- `hermes profile list` 显示各岗位及描述。
- 至少对审核员跑一遍探针，协同维度三轮输入后没有无证据改口。

## 文件索引

- `scripts/persona.py` —— 全部命令（init / list / compile / setup / match / new / mbti / check-team / summary / probe）
- `templates/_base.md` —— 全员底线与协作方式，会编入每份 SOUL.md
- `templates/custom-role.yaml` —— 手写新岗位的空白模板
- `templates/roles/orchestrator.yaml`、`templates/roles/researcher.yaml`、`templates/roles/ideator.yaml`、`templates/roles/executor.yaml`、`templates/roles/reviewer.yaml`、`templates/roles/arbiter.yaml` —— 默认六岗位
- `references/dimensions.md` —— 五维定义、写卡要点、工作模式
- `references/matching.md` —— 匹配规则与团队检查
- `references/mbti.md` —— MBTI 换算与 16 型适配表
- `references/protocol.md` —— 看板协作协议、模板、人类介入点
- `references/evaluation.md` —— 探针、指标、对照实验
- `references/research.md` —— 论文依据
