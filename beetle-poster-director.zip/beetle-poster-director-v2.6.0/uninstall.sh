#!/usr/bin/env bash
set -euo pipefail

MODE=""
REPO_PATH=""
PKG_NAME="beetle-poster-director"

usage() {
  cat <<USAGE
Usage:
  bash uninstall.sh --user
  bash uninstall.sh --repo /absolute/path/to/repo
USAGE
}

if [[ $# -eq 0 ]]; then
  MODE="user"
elif [[ "$1" == "--user" ]]; then
  MODE="user"
elif [[ "$1" == "--repo" ]]; then
  MODE="repo"
  REPO_PATH="${2:-}"
  if [[ -z "$REPO_PATH" ]]; then
    echo "Error: --repo requires an absolute path"
    exit 1
  fi
else
  usage
  exit 1
fi

if [[ "$MODE" == "user" ]]; then
  TARGET_DIR="$HOME/.agents/skills/$PKG_NAME"
else
  TARGET_DIR="$REPO_PATH/.agents/skills/$PKG_NAME"
fi

if [[ -d "$TARGET_DIR" ]]; then
  rm -rf "$TARGET_DIR"
  echo "Removed: $TARGET_DIR"
else
  echo "Nothing to remove: $TARGET_DIR"
fi
