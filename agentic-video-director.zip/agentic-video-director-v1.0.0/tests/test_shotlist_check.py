import csv
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'shotlist_check.py'

def load_module():
    spec = importlib.util.spec_from_file_location('shotlist_check', SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def write_csv(path, rows):
    fields = ['id','start','end','purpose','visual','motion','audio','onscreen_text','source']
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

def test_accepts_contiguous_valid_shotlist(tmp_path):
    m = load_module()
    p = tmp_path/'shots.csv'
    write_csv(p, [
        dict(id='S01', start='0', end='2.5', purpose='hook', visual='logo', motion='push in', audio='hit', onscreen_text='Launch', source='code'),
        dict(id='S02', start='2.5', end='5', purpose='proof', visual='ui', motion='pan', audio='beat', onscreen_text='', source='capture'),
    ])
    report = m.validate_csv(p, total_duration=5.0)
    assert report['ok'] is True
    assert report['errors'] == []

def test_rejects_overlap_gap_and_bad_duration(tmp_path):
    m = load_module()
    p = tmp_path/'shots.csv'
    write_csv(p, [
        dict(id='S01', start='0', end='3', purpose='hook', visual='a', motion='x', audio='', onscreen_text='', source='code'),
        dict(id='S02', start='2.8', end='4', purpose='proof', visual='b', motion='x', audio='', onscreen_text='', source='code'),
        dict(id='S03', start='4.4', end='4.2', purpose='cta', visual='c', motion='x', audio='', onscreen_text='', source='code'),
    ])
    report = m.validate_csv(p, total_duration=5.0)
    assert report['ok'] is False
    joined = '\n'.join(report['errors']).lower()
    assert 'overlap' in joined
    assert 'end must be greater' in joined
    assert 'does not end at total duration' in joined
