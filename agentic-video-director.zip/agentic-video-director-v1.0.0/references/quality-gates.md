# Quality gates

The goal is to catch real defects without turning QA into an endless loop.

## Gate A — media integrity
- Expected resolution, fps, duration and codec/container.
- No missing media, font failures, black/blank accidental ranges or render errors.
- Audio stream present when expected; no obvious clipping or accidental silence.

## Gate B — representative visual inspection
Inspect:
- first and last meaningful frame,
- at least one frame from every major scene,
- frames around high-risk transitions,
- any frame containing dense text/UI.

Use `scripts/qc_frames.py` for a contact sheet, then inspect the actual images. If a defect is motion-specific, render a short segment around it.

## Gate C — editorial quality
Check only observable problems:
- unclear focal point,
- text collision/cropping/unsafe margins,
- discontinuity of subject/wardrobe/screen direction,
- motion that starts/stops unnaturally,
- generic transition fighting the content,
- MV accents visibly off beat,
- UI promo showing fabricated or stale states,
- audio masking speech/vocal.

## Repair policy
Fix concrete defects, then rerender the affected section and final output. Two automatic polish passes are normally enough. Continue beyond that only for a hard failure or a clearly visible defect—not because an abstract score might improve.

## Delivery report
State:
- output file,
- editable project/source,
- what was verified,
- limitations that remain.

Do not claim “perfect” or “film-grade” merely because rendering succeeded.
