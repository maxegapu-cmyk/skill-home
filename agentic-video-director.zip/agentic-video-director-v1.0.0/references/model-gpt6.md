# GPT-6 adapter

Use this adapter for GPT-6 family models, especially GPT-6 Astra in Codex.

## Prompt shape
GPT-6 follows instructions strongly and can be cautious about missing inputs. Give it explicit **authorization to infer routine details and carry the artifact to completion** while retaining boundaries around destructive/external actions.

Recommended task frame:

```text
Intent: [viewer outcome]
Deliverable: [real video artifact + editable source]
Known inputs: [files/repos/audio/assets]
Defaults you may infer: [style/timing choices not worth blocking on]
Boundaries: do not publish, purchase, delete originals, or expose secrets.
Acceptance: [duration/format/visual/audio checks]
Execution: take reversible local actions end-to-end; do not stop at a plan when the requested artifact can be built now.
```

## GPT-6-specific steering
- Keep skill descriptions narrow. GPT-6 is sensitive to instructions in skills/AGENTS.md; avoid duplicated or contradictory global rules.
- Explicitly grant follow-through for reversible local work so it does not pause unnecessarily for approval.
- Specify the desired user-facing report style; otherwise detailed formatting can sprawl.
- Scope verification to the artifact. For a video task, render + media probe + representative visual inspection is more useful than running every unrelated repo test.
- If parallel work is valuable, tell it what may be delegated; otherwise let the main agent keep coherent creative control.
- For a small edit, read only the files required for that edit. Do not preload the whole production manual.

## Video strengths to exploit
GPT-6 Astra is effective at multi-step coding/computer workflows. It can combine Remotion/HyperFrames/Canvas/Blender/ffmpeg and media generation tools when available. Use a build order and acceptance contract rather than a vague “make it cinematic” request.

## Avoid
- Asking for permission after every reversible operation.
- Bloated AGENTS.md rules inherited from older models.
- Broad test suites unrelated to the changed composition.
- Treating a tool’s “success” message as proof that the MP4 is visually correct.
