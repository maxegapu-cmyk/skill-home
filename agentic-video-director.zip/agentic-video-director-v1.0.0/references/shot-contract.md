# Shot contract

For work longer than a single shot, create `shots.csv` before heavy implementation.

Required columns:

```csv
id,start,end,purpose,visual,motion,audio,onscreen_text,source
S01,0,2.4,hook,"...","...","...","...",code
```

## Field rules
- `id`: stable ID (`S01`, `S02`...). Do not renumber during minor revisions.
- `start`, `end`: seconds on the master timeline. Adjacent shots should normally be contiguous.
- `purpose`: one editorial reason for existing.
- `visual`: concrete subject, composition and state.
- `motion`: camera/subject/graphic movement with direction and end state.
- `audio`: beat, lyric, VO, SFX or intentional silence.
- `onscreen_text`: exact visible copy; blank if none.
- `source`: `code`, `capture`, `still`, `video`, `generated`, `3d` or `reuse`.

## Shot quality test
A shot is underspecified if a compositor cannot answer all four questions:
1. What is the viewer looking at?
2. What changes during the shot?
3. Why does the cut happen at this time?
4. What state must exist at the first frame of the next shot?

## Timing rules
- Define composition timing in seconds first, convert to frames from `fps` in code.
- Do not scatter magic frame numbers through components.
- Text must stay readable; fast kinetic copy may be brief, explanatory text may not.
- Transitions consume time. Do not accidentally add transition duration on top of the promised total runtime.

Validate:
```bash
python3 scripts/shotlist_check.py shots.csv --duration 30
```
