# MV and music timing

Audio is the master clock.

## Analyze first
Use `ffprobe` for exact duration. If BPM/beat detection tooling is available, use it; otherwise mark beats/sections manually from waveform/listening. Build a small map:

```text
0:00–0:08 intro / sparse
0:08–0:24 verse / pulse established
0:24–0:40 pre / rising density
0:40–0:56 chorus / peak
```

For constant BPM:
- seconds per beat = `60 / BPM`
- seconds per bar in 4/4 = `240 / BPM`
- frame of beat `n` = `round(n * 60/BPM * fps)`

## Editing grammar
- Cut on every beat only when the style truly calls for it. Phrase-level structure matters more than mechanical beat spam.
- Use downbeats for structural cuts, snares/transients for accents, sustained notes for camera travel, rests for visual breathing room.
- Let visual density follow musical energy: number of active layers, cut frequency, camera speed, light/contrast changes.
- Lyric-led MV: map semantic image changes to phrases, not each individual word.
- Repetition in music can support a recurring visual motif; vary framing/state so repetition feels intentional.

## Sync tolerance
For obvious percussive hits, aim for frame-level alignment. If a hit feels late, test one frame earlier; perceptual sync may differ from waveform peak depending on attack.

## Audio hierarchy
Dialogue/lead vocal > intentional musical focal element > SFX > ambience. Do not use whooshes on every transition.
