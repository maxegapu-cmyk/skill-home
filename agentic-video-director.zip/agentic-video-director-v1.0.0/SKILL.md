---
name: agentic-video-director
description: Use when a coding agent must create, edit, repair, or finish a video, MV, promo, launch film, explainer, motion-graphics piece, or mixed AI-media sequence, especially with Claude Opus 5.5 or GPT-6 in Claude Code or Codex.
---

# Agentic Video Director

## Core principle
Treat video as a buildable artifact, not a prose answer. Convert intent into a timed shot contract, choose the lightest production path that can achieve the look, implement it, render it, inspect the actual pixels/audio, repair concrete defects, and deliver the real file.

## Read only what the task needs
- Claude Opus 5.5: `references/model-opus55.md`
- GPT-6: `references/model-gpt6.md`
- Production routing: `references/production-modes.md`
- Shot schema: `references/shot-contract.md`
- Music/MV timing: `references/mv-timing.md`
- Final QC: `references/quality-gates.md`

Do not preload every reference for a trivial edit.

## Workflow
1. **Inspect inputs.** Reuse supplied media, brand assets, code, music, VO, fonts, screenshots and existing project structure before generating substitutes.
2. **Choose a mode.** Pick one primary production mode from `references/production-modes.md`. Mix modes only when a shot genuinely needs it.
3. **Lock the contract.** Establish duration, aspect ratio, fps, audio source, visual direction, deliverable path and a shotlist. For multi-shot work, create `shots.csv` using `references/shot-contract.md`.
4. **Build, do not merely plan.** If the user asked to make/fix the video, continue through implementation and rendering. Preserve reversible edits; do not publish or upload externally unless explicitly asked.
5. **Respect timing.** Drive all animation from composition time/fps. For music-led work, use `references/mv-timing.md`; cuts and accents should be tied to musical structure, not random short clips.
6. **Render a real preview/final.** Prefer deterministic local rendering with Remotion/Canvas/SVG/WebGL/Three.js/Blender/ffmpeg when appropriate. Generated images/video may be used as source layers, not as an excuse to skip editing.
7. **Inspect the artifact.** Extract representative and boundary frames, check audio/metadata, and repair visible defects. Use `scripts/qc_frames.py` where ffmpeg is available. Do targeted QC, not endless polishing.
8. **Deliver.** Return the actual output path plus a concise note of what was made, any unresolved limitations, and editable source location.

## Creative rules
- Every shot needs a purpose: hook, reveal, proof, escalation, emotion, transition, payoff or CTA.
- Prefer content-motivated transitions over generic fades.
- Motion has acceleration/deceleration, overlap and settling; avoid default linear movement.
- Keep hierarchy obvious at a glance. A viewer should know where to look within ~0.5 s.
- Avoid “animated PowerPoint”: static cards plus crossfades are not sufficient when the brief calls for cinematic motion.
- For UI/product promos, use real captures when available; do not fabricate product states that look like evidence.
- For narrative/MV work, preserve identity, wardrobe, environment and screen-direction continuity across adjacent shots.
- Audio is part of the edit. Leave intentional headroom and do not let SFX mask dialogue/lead vocals.

## Finish condition
A task is finished when the requested artifact exists, the render succeeds, representative frames have been inspected, obvious defects are fixed or disclosed, and the user can locate the output. A passing command alone is not visual QA.

## Quick tools
```bash
python3 scripts/doctor.py
python3 scripts/shotlist_check.py shots.csv --duration 30
python3 scripts/qc_frames.py out/final.mp4 --out qc
```

## Examples
Use the examples as briefing patterns, not rigid magic prompts:
- `examples/01-product-launch.md`
- `examples/02-music-video.md`
- `examples/03-code-film.md`
- `examples/04-repair-existing-video.md`
