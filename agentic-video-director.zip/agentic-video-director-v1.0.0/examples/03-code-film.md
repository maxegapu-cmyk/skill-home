# Example — code-drawn short film

```text
Create a 35-second square animated short rendered entirely from code. Theme: a single paper boat crosses three impossible weather systems and reaches still water.

Use Canvas/SVG/WebGL or Remotion—choose the smallest stack that gives expressive motion. No stock footage. Sound may be synthesized or assembled from local permitted assets. Make it feel like a short film, not an infographic: establish a recurring boat silhouette, evolving light, motivated camera changes, and a clear emotional arc.

Deliver 1080x1080 30fps MP4 to out/paper-boat.mp4 with editable source. Work end-to-end. Inspect actual rendered frames and fix visible artifacts before delivery.
```
