# Example — repair an existing video

```text
Improve input.mp4 without rebuilding it from scratch.
Problems to solve: the first 3 seconds are slow, captions collide with the mobile safe area, two transitions feel like generic crossfades, and the music hit at ~12s lands late.

Preserve the original story, voice and brand identity. Diagnose the source/timeline, make the minimum edits that fix those defects, and keep total duration within ±0.5s unless a timing fix requires otherwise.

Render to out/repaired.mp4. Compare representative frames and the 11–13s segment against the original. Report only remaining limitations that are actually visible/audible.
```
