# Example — music video

```text
Make a 45-second MV from music.wav and the footage/images in assets/.
The song is the master clock. First map sections and important transients, then create shots.csv and edit to musical phrases—not random 1-second cuts.

Creative direction: nocturnal city, lonely momentum, restrained neon, one recurring reflection motif. Preserve the lead character's identity and screen direction across adjacent shots. Generated imagery is allowed only where the supplied material cannot cover the concept; keep those inserts visually consistent with the real footage.

Output: 1920x1080 24fps H.264 MP4 at out/mv.mp4. Keep vocals/lead elements clear above SFX. Render the real video, inspect boundary/representative frames and repair visible sync, continuity, text or compositing defects before delivery.
```
