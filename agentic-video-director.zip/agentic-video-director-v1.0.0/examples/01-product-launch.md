# Example — 30s product launch

Use this as a compact task prompt after the skill is installed:

```text
Create a 30-second 16:9 launch film for the app in this repository.
The viewer should understand the new workflow in one viewing and feel that the product is fast, precise and premium.

Use the real app/UI states from the repo or local browser. Do not invent feature evidence. You may choose the exact visual concept, typography and transitions, but keep the brand assets already present.

Deliver 1920x1080, 30fps, H.264 MP4 to out/launch.mp4 plus editable source. Build a timed shotlist first. Use content-motivated transitions and real interaction captures; avoid a card-slideshow look.

Proceed through implementation, render, representative-frame inspection and concrete fixes without stopping at a storyboard. Do not publish anything externally.
```

Why this shape works: the user outcome and evidence boundary are explicit, while local design decisions remain open to the model.
