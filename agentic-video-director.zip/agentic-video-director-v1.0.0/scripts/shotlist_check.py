#!/usr/bin/env python3
import argparse, csv, json, math
from pathlib import Path

REQUIRED = ['id','start','end','purpose','visual','motion','audio','onscreen_text','source']
EPS = 1e-3

def _num(v, label, errors):
    try:
        n = float(v)
        if not math.isfinite(n): raise ValueError
        return n
    except Exception:
        errors.append(f'{label} must be a finite number: {v!r}')
        return None

def validate_csv(path, total_duration=None):
    path = Path(path)
    errors, warnings = [], []
    if not path.exists():
        return {'ok': False, 'errors': [f'file not found: {path}'], 'warnings': []}
    with path.open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        missing = [k for k in REQUIRED if k not in (reader.fieldnames or [])]
        if missing:
            return {'ok': False, 'errors': [f'missing columns: {", ".join(missing)}'], 'warnings': []}
        rows = list(reader)
    if not rows:
        return {'ok': False, 'errors': ['shotlist is empty'], 'warnings': []}
    parsed=[]
    ids=set()
    for i,r in enumerate(rows, start=2):
        sid=(r.get('id') or '').strip()
        if not sid: errors.append(f'row {i}: id is required')
        elif sid in ids: errors.append(f'row {i}: duplicate id {sid}')
        ids.add(sid)
        s=_num(r.get('start',''), f'row {i} start', errors)
        e=_num(r.get('end',''), f'row {i} end', errors)
        if s is not None and e is not None:
            if s < -EPS: errors.append(f'row {i}: start must be >= 0')
            if e <= s + EPS: errors.append(f'row {i}: end must be greater than start')
        for key in ('purpose','visual','motion','source'):
            if not (r.get(key) or '').strip(): errors.append(f'row {i}: {key} is required')
        parsed.append((i,s,e,sid))
    valid=[x for x in parsed if x[1] is not None and x[2] is not None and x[2] > x[1]]
    valid.sort(key=lambda x:x[1])
    if valid and abs(valid[0][1]) > EPS:
        errors.append(f'shotlist must start at 0s, starts at {valid[0][1]:.3f}s')
    for a,b in zip(valid, valid[1:]):
        if b[1] < a[2]-EPS:
            errors.append(f'overlap: {a[3]} ends {a[2]:.3f}s, {b[3]} starts {b[1]:.3f}s')
        elif b[1] > a[2]+EPS:
            warnings.append(f'gap: {a[3]} ends {a[2]:.3f}s, {b[3]} starts {b[1]:.3f}s')
    if total_duration is not None and valid:
        if abs(valid[-1][2]-float(total_duration)) > 0.02:
            errors.append(f'shotlist does not end at total duration: ends {valid[-1][2]:.3f}s vs {float(total_duration):.3f}s')
    return {'ok': not errors, 'errors': errors, 'warnings': warnings, 'shots': len(rows)}

def main():
    ap=argparse.ArgumentParser(description='Validate Agentic Video Director shots.csv timing and required fields.')
    ap.add_argument('csv')
    ap.add_argument('--duration', type=float)
    ap.add_argument('--json', action='store_true')
    args=ap.parse_args()
    report=validate_csv(args.csv,args.duration)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print('OK' if report['ok'] else 'FAIL', f"({report.get('shots',0)} shots)")
        for w in report.get('warnings',[]): print('WARN:',w)
        for e in report.get('errors',[]): print('ERROR:',e)
    raise SystemExit(0 if report['ok'] else 1)
if __name__=='__main__': main()
