#!/usr/bin/env python3
import json, shutil, subprocess

def version(cmd):
    p=shutil.which(cmd)
    if not p: return {'found':False,'path':None,'version':None}
    try:
        out=subprocess.run([p,'-version' if cmd in ('ffmpeg','ffprobe') else '--version'],capture_output=True,text=True,timeout=8)
        first=(out.stdout or out.stderr).splitlines()[0] if (out.stdout or out.stderr) else ''
    except Exception as e: first=str(e)
    return {'found':True,'path':p,'version':first}

def main():
    tools={k:version(k) for k in ['node','npm','npx','ffmpeg','ffprobe','python3']}
    required=['node','npx','ffmpeg','ffprobe']
    ok=all(tools[k]['found'] for k in required)
    print(json.dumps({'ok':ok,'tools':tools},indent=2))
    raise SystemExit(0 if ok else 1)
if __name__=='__main__': main()
