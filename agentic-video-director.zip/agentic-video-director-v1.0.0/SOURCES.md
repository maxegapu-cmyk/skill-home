# Research sources — checked 2026-09-28

This skill is an original synthesis. It does not reproduce private/paid prompts or copy a third-party skill wholesale.

## Official model guidance
- Anthropic, Claude Opus 5.5 announcement (2026-09-22): https://www.anthropic.com/claude-opus-5-5
- Anthropic, Prompting best practices / Claude Opus guidance: https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/prompt-templates-and-variables
- Anthropic, Effective context engineering for AI agents: https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
- OpenAI, GPT-6 model guidance: https://developers.openai.com/api/docs/guides/latest-model
- OpenAI, Rethinking skills and prompts for GPT-6 Astra (2026-09-11): https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra
- OpenAI, Prompt engineering: https://developers.openai.com/api/docs/guides/prompt-engineering

## Video/skill ecosystem patterns reviewed
- Remotion official Agent Skills: https://github.com/remotion-dev/remotion/tree/main/packages/skills
- video-shotcraft: https://github.com/Vincentwei1021/video-shotcraft
- claude-remotion-skill: https://github.com/haidrrrry/claude-remotion-skill
- claude-skill-motion-graphics: https://github.com/docusphere/claude-skill-motion-graphics
- public GPT-6 Astra video-prompt index: https://github.com/LuxRealGrowth/awesome-astra-video-prompts
- public Opus 5.5 video-demo index: https://github.com/X-RayLuan/awesome-opus-5-5-video-prompts

## Patterns intentionally adopted, independently expressed
- Artifact-first prompting rather than prose-only answers.
- Short/high-signal skill context for newer models.
- Explicit autonomy/follow-through for GPT-6 reversible local work.
- Avoiding redundant over-verification for Opus while retaining targeted render inspection.
- Frame/timeline contracts for deterministic programmatic video.
- Render → inspect actual frames → repair concrete defects.
- Music-first section/beat mapping for MV work.
