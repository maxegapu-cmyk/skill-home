# Changelog

## 1.0.0 — 2026-09-28
- Initial release.
- Separate Claude Opus 5.5 and GPT-6 runtime adapters.
- Six production modes and a stable shot contract.
- Music/MV timing guidance.
- Targeted render QC workflow.
- Dependency doctor, shotlist validator and ffmpeg contact-sheet tool.
- Four original task-prompt examples.
