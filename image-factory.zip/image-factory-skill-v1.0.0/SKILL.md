---
name: image-factory
description: Use when turning image-generation requests, reference images, briefs, story beats, product requirements, or rough visual ideas into structured prompts, shot plans, controlled variants, quality checks, and targeted repair instructions across photographic, cinematic, illustration, character, product, architecture, and concept-art workflows.
---

# Image Factory

把“我想要一张什么图”稳定翻译成“模型真正能执行的视觉任务”，并在首轮失败后知道该修哪一层，而不是继续堆形容词。

## Core Principle

**先控制画面结构，再控制风格；先锁不可变项，再制造变化；先诊断失败原因，再返修。**

不要把生图当成“写一段很长的提示词”。Image Factory 把任务拆成六层：

1. **Intent**：用户真正想得到什么结果。
2. **Scene**：画面里有哪些主体、动作、关系、环境。
3. **Camera**：从哪里看、看多大、如何组织空间。
4. **Look**：光线、材质、色彩、媒介与视觉气质。
5. **Constraints**：什么必须保持，什么禁止出现。
6. **QA / Repair**：生成后如何判断，并只修失败部分。

默认目标：**可执行、可复用、可扩展、不过载。**

## Trigger Scope

本 Skill 适用于：

- 写实摄影、纪实、人像、时尚、商业摄影
- 电影剧照、电视剧画面、MV、广告视觉
- 动漫、漫画、插画、绘本、二维角色
- 概念设计、科幻、奇幻、机甲、怪物、建筑、载具
- 电商产品、食品、数码、化妆品、珠宝、包装
- 室内设计、建筑空间、景观、环境概念
- 角色设定、服装、道具、武器、资产展示
- 参考图风格、参考图构图、参考图身份、图生图
- 批量变体、系列图、镜头组、封面、海报
- 生成失败后的定点返修

不把不同任务硬塞进同一个模板。先判断任务类型，再选择对应控制重点。

## Operating Flow

收到请求后，按以下顺序工作：

### 1. Parse Brief

从用户输入中提取：

- **输出类型**：照片 / 电影帧 / 插画 / 产品图 / 设定图 / 建筑图 / 海报
- **主角**：谁或什么是视觉核心
- **动作**：主体正在做什么
- **空间**：在哪里，前中后景有什么
- **镜头**：景别、机位、焦段感、视线方向
- **时间**：昼夜、季节、天气、年代
- **视觉目标**：真实、华丽、压抑、轻盈、粗粝、精致等
- **不可变项**：身份、服装、产品比例、Logo、构图、角色数量等
- **可变项**：机位、光线、背景、动作、色调等
- **禁区**：不要出现什么

如果用户给的信息已经足够，直接执行，不重复询问。

### 2. Choose Control Mode

根据任务选主控制模式：

| 模式 | 优先控制 | 典型任务 |
|---|---|---|
| Camera-first | 镜头、构图、空间 | 影视、摄影、动作场面 |
| Identity-first | 身份、面部、服装、比例 | 人物一致性、角色资产 |
| Object-first | 产品比例、结构、材质 | 电商、工业产品 |
| Style-first | 形状语言、色彩、笔触、媒介 | 插画、动漫、艺术风格 |
| Environment-first | 空间、尺度、建筑、气氛 | 建筑、场景、概念设计 |
| Edit-first | 保留区与修改区 | 图生图、局部编辑 |

只能有一个**主控制模式**；其他维度作为辅助，否则容易互相争抢控制权。

### 3. Build Image Job

把需求整理成一个内部 Image Job：

```text
GOAL
SUBJECT
ACTION
ENVIRONMENT
CAMERA
COMPOSITION
LIGHTING
MATERIAL
COLOR
STYLE
IMMUTABLES
VARIABLES
NEGATIVES
OUTPUT
```

这不是一定要原样展示给用户，而是确保编译提示词前没有遗漏结构信息。

## Prompt Compiler

提示词遵循“**画面事实 > 空间关系 > 镜头 > 光线 > 材质 > 风格 > 质量**”顺序。

推荐骨架：

```text
[主体与身份]
[动作与主体关系]
[环境与前中后景]
[景别 + 机位 + 视角 + 构图]
[主光方向 + 光质 + 环境光]
[真实材质/媒介特征]
[综合色彩与视觉气质]
[必须保持的约束]
[明确禁止项]
```

### Prompt Compression Rules

1. 相同意思只说一次。
2. 一个视觉维度最多保留 1–3 个高信息词。
3. 优先写“可看见的结果”，少写抽象赞美。
4. “8K、masterpiece、best quality”不是结构控制词，只能最后补充，不能替代镜头和材质。
5. 有参考图时，不要同时要求模型“完全照参考图”又“大幅自由发挥”。
6. 不要把五种摄影师、三种电影、八种灯光同时混成一锅。

### Concrete-over-Abstract

差：
`高级、电影感、氛围感、顶级质感、震撼。`

好：
`低机位中近景，人物站在逆光雨幕边缘；湿衣料贴附肩部，路面反射两处冷白车灯，背景招牌虚化成稀疏色块。`

## Reference Image Routing

有多张参考图时，必须先给每张图分工，禁止“全部都参考”。

可用角色：

- **IDENTITY**：脸、体型、角色身份
- **COSTUME**：服装、饰品、装备
- **COMPOSITION**：构图、站位、画面布局
- **POSE**：动作、姿态、身体关系
- **STYLE**：视觉语言、媒介、色彩、笔触
- **LIGHTING**：光线方向、反差、时间感
- **ENVIRONMENT**：场景与建筑空间
- **PRODUCT**：产品真实结构与比例

使用多参考图时输出一份 Reference Map，例如：

```text
Ref A → IDENTITY only
Ref B → COSTUME + PRODUCT DETAILS
Ref C → COMPOSITION only
Ref D → LIGHTING + COLOR only
```

若两张参考图在同一维度冲突，必须选主参考，不平均融合。

## Camera Engine

影视与摄影任务优先从以下变量中选择，而不是无限加词：

- 景别：极远 / 远 / 全 / 中全 / 中 / 中近 / 近 / 特写
- 高度：贴地 / 低 / 平视 / 高 / 鸟瞰
- 水平角：正面 / 3/4 / 侧面 / 背面
- 镜头感：超广 / 广角 / 标准 / 中长焦 / 长焦
- 透视：强 / 中 / 弱
- 构图：中心 / 三分 / 对称 / 框中框 / 负空间 / 深层纵深
- 焦点：主体 / 前景遮挡 / 局部细节 / 多层景深

规则：**一个镜头先回答“摄影机在哪里”，再回答“画面有多漂亮”。**

更多见 `references/shot-language.md`。

## Lighting & Material Engine

光线至少回答四件事：

1. 主光来自哪里
2. 是硬光还是软光
3. 暗部是否有环境补光
4. 什么材质在响应这束光

材质写法优先“物理结果”：

- 金属：边缘高光、微划痕、粗糙度变化
- 皮肤：毛孔、细小绒毛、油脂反射差异、局部泛红
- 布料：纤维、褶皱重量、拉伸、透光或不透光
- 塑料：注塑接缝、细微橘皮、半哑光反射
- 木材：纹理方向、漆面磨损、孔隙
- 玻璃：厚度、边缘折射、内部反射

更多见 `references/lighting-material.md`。

## Variant Factory

当用户要“一次多做几种方案”时，禁止只换 seed。

每个变体至少改变两个高层变量，并保证不可变项不动。

推荐变体轴：

- A：机位变化
- B：光线变化
- C：构图变化
- D：环境变化
- E：动作变化
- F：色彩变化

示例：

```text
V1 = 平视中景 + 阴天软光
V2 = 低机位中近景 + 夕阳侧逆光
V3 = 长焦远景 + 夜雨霓虹反射
```

若目标是角色一致性，则身份、服装、关键饰品全部锁定；只允许镜头和场景变化。

## Domain Recipes

### Cinematic / Film Still

优先：人物关系 → 摄影机位置 → 空间纵深 → 主光逻辑 → 环境行为 → 表演瞬间。

避免：只写“电影感、35mm、大片感”。

### Photoreal Portrait

优先：身份 → 面部结构 → 肤质 → 发型 → 光线 → 镜头距离 → 背景。

避免：过度磨皮、无来源轮廓光、眼睛异常发亮、完美对称。

### Product / E-commerce

优先：产品结构 → 尺寸比例 → 材质 → Logo/文字 → 展示角度 → 灯光 → 背景。

禁止为了“好看”把产品比例改掉。

### Anime / Illustration

优先：轮廓 → 形状语言 → 线条 → 上色方式 → 阴影方式 → 色彩结构 → 构图。

不要仅写作品名或作者名替代视觉描述。

### Concept Art

优先：设计功能 → 轮廓差异 → 尺度 → 材质分区 → 机械/生物逻辑 → 场景验证。

### Architecture / Interior

优先：空间尺寸关系 → 摄影机高度 → 透视 → 建筑结构 → 材质 → 自然光 → 家具尺度。

### Image Editing

先分：

```text
KEEP = 不得变化
CHANGE = 必须修改
OPTIONAL = 可以优化
FORBID = 不得引入
```

编辑任务中，KEEP 的优先级高于“整体更漂亮”。

## Quality Gate

生成结果必须逐层检查，不能只看“第一眼好不好看”。

### Gate 1 — Task Match

- 主体对吗？
- 人数对吗？
- 动作对吗？
- 场景对吗？

### Gate 2 — Spatial Logic

- 手脚、武器、家具、车辆有没有穿模？
- 人物距离和前后关系合理吗？
- 镜头透视是否和景别一致？

### Gate 3 — Identity / Object Integrity

- 人脸身份是否漂移？
- 产品比例是否改变？
- 服装和关键配件有没有消失或变形？

### Gate 4 — Material / Light

- 光线有没有来源？
- 材质是否响应正确？
- 是否出现塑料皮肤、假布料、错误金属反射？

### Gate 5 — Style / Intent

- 风格是不是用户真正要的？
- 有没有只学到“滤镜”却没有学到视觉语言？
- 画面情绪是否符合目的？

### Gate 6 — AI Artifacts

- 多余手指/肢体
- 文字乱码
- 结构重复
- 过度锐化
- 无意义纹理
- 背景物体融化
- 人脸蜡感
- 局部尺度错误

完整检查表见 `references/image-qc.md`。

## Repair Loop

返修前先判定失败属于哪一类：

| 症状 | 根因层 | 优先修法 |
|---|---|---|
| 人物不像 | Identity | 加强身份证据，减少其他参考竞争 |
| 构图跑掉 | Camera | 明确机位、景别、画面占比 |
| 画风只有滤镜像 | Style | 改写形状、线条、材质、明暗方式 |
| 产品变形 | Object | 锁结构比例，减少自由设计词 |
| 手脚错误 | Anatomy/Action | 简化动作，明确遮挡与肢体关系 |
| 材质假 | Material | 描述表面物理响应，不加更多“高清”词 |
| 图很漂亮但不是需求 | Intent | 回到 Brief，删掉抢控制权的装饰词 |

### Surgical Repair Rule

**一次返修最多主修 1–2 个失败层。**

已经正确的内容写进 KEEP；错误项写进 CHANGE。不要整段提示词全部推翻。

例：

```text
KEEP:
- same woman identity
- same blue coat
- same street location
- same waist-up framing

CHANGE:
- reduce plastic skin
- make key light come from camera-left storefront

FORBID:
- face redesign
- hairstyle change
- new accessories
```

更多见 `references/repair-strategies.md`。

## Model Adapter Strategy

### Natural-language image models

适合：GPT Image、Gemini/Nano Banana、Seedream 等偏自然语言理解的模型。

写法：完整自然句 + 明确关系 + KEEP/CHANGE + 少量硬约束。

### Diffusion / node workflows

适合：FLUX、SDXL、ComfyUI 等。

写法：将内容拆成 positive / negative / reference control / sampler & resolution 等独立字段；不要把节点参数混进视觉描述。

### Unknown Model

不知道模型时默认使用自然语言版本，并输出一个“可拆分字段版本”，方便用户迁移。

## Output Contract

默认交付格式：

```text
【任务判断】
一句话说明当前属于什么生图任务、主控制模式是什么。

【最终提示词】
可以直接复制使用的完整版本。

【强约束】
必须保持 / 禁止改变。

【可选变体】
只有用户需要多方案时输出 3–6 个差异明确的版本。

【失败返修】
仅在任务高风险或已有失败样本时给出最可能的返修入口。
```

如果用户要求“只给提示词”，只输出最终提示词，不强塞解释。

## Fast Mode

用户说“直接给我”“快速做”“别解释”时：

1. 内部完成 Brief Parse。
2. 选择控制模式。
3. 直接编译成最终提示词。
4. 最多追加一行负面约束。

不要向用户展示完整内部流程。

## Pro Mode

用户要求高质量、批量、商业用途、角色一致性、复杂动作、多个参考图时：

1. 输出 Image Job 摘要。
2. 明确参考图职责。
3. 输出主提示词。
4. 输出不可变项。
5. 设计 3–6 个可控变体。
6. 给出 QA 检查点。
7. 如有失败样本，给出定点返修版本。

## Quick Reference

| 问题 | 第一动作 |
|---|---|
| 图不听话 | 删掉冲突控制词 |
| 画面普通 | 改镜头和光，不先加形容词 |
| 人不像 | 锁身份，减少竞争参考 |
| 风格不像 | 描述视觉机制，不只描述滤镜 |
| 产品变形 | 锁比例和结构 |
| 图太AI | 查材质、光源、重复纹理、对称性 |
| 变体太像 | 改高层变量，不只换随机种子 |
| 返修越修越坏 | KEEP/CHANGE 分离 |

## Common Mistakes

- 把“高质量”误认为“长提示词”
- 同时指定多个互相冲突的艺术方向
- 有参考图却不说明每张参考图负责什么
- 想改灯光，却顺便让模型重做人物
- 写了几十个镜头术语，却没说明摄影机在哪里
- 产品图只追求漂亮，不锁真实比例
- 人物一致性只写“same character”而没有身份证据
- 失败后整段重写，导致正确部分一起漂移

## Final Rule

**每一张好图都必须能回答：主体是谁、在做什么、摄影机在哪里、光从哪里来、什么不能变。**

回答不出来的提示词，哪怕很长，也不算合格的生产提示词。
