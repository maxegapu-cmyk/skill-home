from pathlib import Path
import re, json, sys
root = Path(__file__).resolve().parents[1]
skill = root / 'SKILL.md'
assert skill.exists(), 'SKILL.md missing'
text = skill.read_text(encoding='utf-8')
assert text.startswith('---\n'), 'YAML frontmatter missing'
assert re.search(r'^name:\s*[a-z0-9-]+$', text, re.M), 'invalid name'
assert re.search(r'^description:\s*Use when .+', text, re.M), 'description must start with Use when'
required = [
    '## Core Principle', '## Operating Flow', '## Prompt Compiler',
    '## Reference Image Routing', '## Variant Factory', '## Quality Gate',
    '## Repair Loop', '## Output Contract'
]
for h in required:
    assert h in text, f'missing section: {h}'
for f in [
    'references/shot-language.md','references/lighting-material.md',
    'references/image-qc.md','references/repair-strategies.md',
    'schemas/image-job.schema.json','examples/cinematic.json',
    'examples/product.json','examples/character.json'
]:
    assert (root/f).exists(), f'missing {f}'
json.loads((root/'schemas/image-job.schema.json').read_text(encoding='utf-8'))
for x in ['cinematic.json','product.json','character.json']:
    json.loads((root/'examples'/x).read_text(encoding='utf-8'))
print('PASS: skill structure, frontmatter, required sections, schema, examples')
