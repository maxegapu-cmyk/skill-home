# Repair Strategies

## Identity Drift
KEEP：场景、构图、光线。
CHANGE：只加强人物身份证据。
减少其他人物参考、风格参考对脸部的竞争。

## Composition Drift
KEEP：人物与服装。
CHANGE：景别、主体占比、机位、负空间方向。

## Plastic Skin
KEEP：身份、表情、镜头。
CHANGE：皮肤微表面、局部反射、毛孔和色差。
不要靠“更高清”解决。

## Product Geometry Drift
KEEP：真实产品结构、比例、Logo。
CHANGE：环境、灯光、背景。
必要时明确“禁止重新设计产品外形”。

## Style Is Only a Filter
将 STYLE 从“颜色/滤镜词”改为：
- 轮廓和形状
- 明暗组织
- 线条 / 笔触
- 材质简化方式
- 色块组织
- 边缘处理

## Bad Hands / Complex Action
先降低动作自由度：明确左右手、抓握物、遮挡关系、关节方向。
如果仍失败，拆镜头或改成更容易成立的姿态。
