# GitHub 公开研究路线图

这里只记录可公开核验的技术方向和本系统吸收的抽象原则，不包含第三方源码、权重或作者专属 Prompt。

## 身份条件与可编辑性

- **InstantID** — 单图、免训练身份保持。启发：身份信号应与文本场景控制分开。
  https://github.com/instantX-research/InstantID
- **IP-Adapter / FaceID 路线** — 图像提示与文本提示并行，FaceID 把面部身份作为专门条件。启发：身份参考不要兼任姿态和场景。
  https://github.com/tencent-ailab/IP-Adapter
- **PhotoMaker** — 多张 ID 图堆叠身份信息，同时考虑 fidelity、diversity、text controllability。启发：人物资产应保留多视角互补参考。
  https://github.com/TencentARC/PhotoMaker
- **PuLID** — 将身份保真、可编辑性和面部自然度同时处理。启发：锁脸不能以牺牲自然表情和场景编辑为代价。
  https://github.com/ToTheBeginning/PuLID

## 多视角与资产化

- **MV-Adapter** — 插件式多视角一致生成。启发：多视角一致性本身应作为独立验收维度，而不是从单正脸无限外推。
  https://github.com/huanngzh/MV-Adapter
- **OpenChar** — 把参考图与 identity fingerprint 打成可携带角色资产，并对输出做 continuity score。启发：角色应有独立资产容器和连续性评分，而不是散落的提示词。
  https://github.com/OpenCharAI/OpenChar

## 几何、表情与姿态

- **DECA** — 同时估计 shape、pose、detail 与 lighting。启发：光照不能写进身份结构。
  https://github.com/yfeng95/DECA
- **MICA** — 关注可度量的 3D 人脸重建。启发：高稳定几何应占更高身份预算。
  https://github.com/Zielon/MICA
- **SMIRK** — 对非对称、细微和极端表情的恢复。启发：表情是压力测试，不是身份参数。
  https://github.com/georgeretsi/smirk
- **3DDFA_V2** — 稠密对齐、姿态和跟踪。启发：多角度验收应显式记录 yaw/pitch，而不是只凭观感。
  https://github.com/cleardusk/3DDFA_V2

## 皮肤与外观

- **TRUST** — 面部 albedo / skin tone 与场景偏差分离。启发：底层肤色、反射与光照要拆开。
  https://github.com/HavenFeng/TRUST
- **NextFace** — 分阶段估计几何、diffuse/specular albedo、姿态和光照，再细化纹理。启发：真实皮肤不是一个“细节噪声层”，需要材质与光线解耦。
  https://github.com/abdallahdib/NextFace
- **UVAPM** — coarse-to-fine facial albedo 与高频细节生成。启发：皮肤应分低频底色与高频纹理层级处理。
  https://github.com/wangalong-ahpu/UVAPM

## 评估

- **ID-Booth** — 组合人脸质量、头姿、身份一致性/可分性等评估。启发：不能只拿一个身份相似度数字作为最终质量分。
  https://github.com/dariant/ID-Booth

真正集成任一项目时，仍需单独核查当时的代码许可证、模型许可证和商用限制。
