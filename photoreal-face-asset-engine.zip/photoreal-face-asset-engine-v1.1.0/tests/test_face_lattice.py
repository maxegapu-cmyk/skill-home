import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))


def test_default_recipe_has_separated_identity_and_render_layers():
    from face_lattice import default_recipe
    r = default_recipe('char-a')
    assert r['character_id'] == 'char-a'
    assert 'identity' in r and 'variation' in r and 'realism' in r
    assert 'expression' not in r['identity']
    assert r['realism']['target'] == 'photographic-human'


def test_identity_distance_ignores_expression_and_lighting():
    from face_lattice import default_recipe, identity_distance
    a = default_recipe('x')
    b = json.loads(json.dumps(a))
    b['variation']['expression']['smile'] = 0.8
    b['variation']['lighting']['directionality'] = 0.9
    assert identity_distance(a, b) == 0.0


def test_identity_distance_weights_bone_changes_more_than_surface_changes():
    from face_lattice import default_recipe, identity_distance
    a = default_recipe('x')
    bone = json.loads(json.dumps(a))
    surf = json.loads(json.dumps(a))
    bone['identity']['geometry']['jaw_width'] += 0.4
    surf['identity']['soft_tissue']['cheek_fullness'] += 0.4
    assert identity_distance(a, bone) > identity_distance(a, surf)


def test_generate_variants_are_diverse_and_valid():
    from face_lattice import generate_variants, validate_recipe, identity_distance
    variants = generate_variants(24, seed=42, min_distance=0.10)
    assert len(variants) == 24
    for v in variants:
        assert validate_recipe(v) == []
    dists = [identity_distance(variants[i], variants[j]) for i in range(len(variants)) for j in range(i)]
    assert min(dists) >= 0.10


def test_realism_contract_contains_non_ai_skin_requirements():
    from face_lattice import default_recipe, compile_realism_contract
    text = compile_realism_contract(default_recipe('x')).lower()
    required = ['pores', 'vellus', 'asymmetry', 'sclera', 'tear', 'sebum', 'available light', 'waxy']
    for term in required:
        assert term in text


def test_atlas_spec_contains_identity_recovery_views():
    from face_lattice import atlas_spec
    spec = atlas_spec()
    labels = {x['id'] for x in spec}
    assert {'front-neutral','left-45','right-45','left-profile','right-profile','up-15','down-15'} <= labels
    assert all('purpose' in x for x in spec)


def test_drift_gate_has_pass_warn_branch_thresholds():
    from face_lattice import drift_gate
    assert drift_gate(0.07)['status'] == 'pass'
    assert drift_gate(0.20)['status'] == 'warn'
    assert drift_gate(0.40)['status'] == 'branch'


def test_cli_generates_json(tmp_path):
    out = tmp_path / 'r.json'
    subprocess.run([sys.executable, str(ROOT/'scripts'/'face_lattice.py'), 'new', '--id', 'demo', '--out', str(out)], check=True)
    data = json.loads(out.read_text('utf-8'))
    assert data['character_id'] == 'demo'



def test_release_structure_present():
    required = [
        'SKILL.md','manifest.yaml','scripts/face_lattice.py','scripts/pressure_test.py',
        'references/architecture.md','references/photorealism.md','references/downstream-handoff.md',
        'references/github-research-map.md','references/source-isolation.md','references/model-adapter-contract.md','VERIFICATION.md','CHANGELOG.md','templates/character-asset-packet.yaml','schema/face-recipe.schema.json'
    ]
    for rel in required:
        assert (ROOT/rel).is_file(), rel


