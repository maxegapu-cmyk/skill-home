import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))


def test_lock_candidate_preserves_selected_identity_and_relabels():
    from face_lattice import generate_variants, lock_candidate, identity_distance
    variants=generate_variants(8, seed=17, min_distance=.10)
    chosen=variants[3]
    locked=lock_candidate(variants, candidate_id=chosen['character_id'], new_character_id='hero-locked')
    assert locked['character_id']=='hero-locked'
    assert identity_distance(chosen, locked)==0.0
    assert locked['continuity']['master_fingerprint']==locked['identity_fingerprint']


def test_identity_fingerprint_ignores_scene_variation_but_changes_with_identity():
    from face_lattice import default_recipe, fingerprint_identity
    a=default_recipe('a')
    b=json.loads(json.dumps(a)); b['variation']['lighting']['contrast']=.9
    assert fingerprint_identity(a)==fingerprint_identity(b)
    b['identity']['geometry']['jaw_width']=.4
    assert fingerprint_identity(a)!=fingerprint_identity(b)


def test_apply_edits_supports_dotted_paths_and_returns_budget():
    from face_lattice import default_recipe, apply_edits
    master=default_recipe('x')
    edited, report=apply_edits(master, {'identity.geometry.jaw_width':.25,'variation.expression.smile':.8}, master=master)
    assert edited['identity']['geometry']['jaw_width']==.25
    assert edited['variation']['expression']['smile']==.8
    assert report['distance']>0
    assert report['group_contributions']['geometry']>0
    assert report['group_contributions']['soft_tissue']==0


def test_apply_edits_rejects_unknown_or_out_of_range_identity_path():
    from face_lattice import default_recipe, apply_edits
    master=default_recipe('x')
    for edits in ({'identity.geometry.unknown_slider':.2},{'identity.geometry.face_width':1.5}):
        try:
            apply_edits(master, edits, master=master)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid edit was accepted')


def test_face_spec_is_parameter_driven_and_non_beautifying():
    from face_lattice import default_recipe, compile_face_spec
    r=default_recipe('x')
    r['identity']['geometry']['face_width']=-.8
    r['identity']['geometry']['jaw_width']=.65
    text=compile_face_spec(r).lower()
    assert 'narrow' in text and ('broad' in text or 'wide' in text)
    assert 'preserve' in text
    assert 'beautif' in text


def test_build_asset_bundle_creates_complete_self_contained_contract(tmp_path):
    from face_lattice import default_recipe, build_asset_bundle
    r=default_recipe('bundle-x')
    out=tmp_path/'asset'
    report=build_asset_bundle(r,out)
    expected={'character_recipe.json','identity_contract.txt','face_spec.txt','realism_contract.txt','atlas_spec.json','continuity_report.json','asset_packet.json'}
    assert expected <= {p.name for p in out.iterdir() if p.is_file()}
    assert report['character_id']=='bundle-x'


def test_diversity_report_measures_coverage_and_near_duplicates():
    from face_lattice import generate_variants, diversity_report
    vs=generate_variants(16, seed=99, min_distance=.10)
    report=diversity_report(vs)
    assert report['count']==16
    assert report['min_pair_distance']>=.10
    assert report['near_duplicate_pairs']==0
    assert set(report['axis_span']) >= {'face_width','face_height','jaw_width','orbital_spacing','nasal_root_width','mouth_width'}


def test_schema_has_numeric_ranges_for_identity_parameters():
    schema=json.loads((ROOT/'schema'/'face-recipe.schema.json').read_text('utf-8'))
    geom=schema['$defs']['geometry']['properties']
    assert geom['face_width']['minimum']==-1.0
    assert geom['face_width']['maximum']==1.0
    assert geom['jaw_width']['type']=='number'


def test_cli_full_workflow_roundtrip(tmp_path):
    import subprocess
    py=sys.executable; tool=str(ROOT/'scripts'/'face_lattice.py')
    candidates=tmp_path/'candidates.json'
    locked=tmp_path/'locked.json'
    edited=tmp_path/'edited.json'
    report=tmp_path/'edit-report.json'
    bundle=tmp_path/'asset'
    subprocess.run([py,tool,'variants','--count','10','--seed','123','--min-distance','.10','--out',str(candidates)],check=True)
    data=json.loads(candidates.read_text('utf-8'))
    chosen=data[4]['character_id']
    subprocess.run([py,tool,'lock','--candidates',str(candidates),'--candidate-id',chosen,'--id','roundtrip','--out',str(locked)],check=True)
    subprocess.run([py,tool,'edit','--recipe',str(locked),'--set','variation.expression.smile=.4','--set','identity.soft_tissue.cheek_fullness=.15','--out',str(edited),'--report',str(report)],check=True)
    subprocess.run([py,tool,'bundle','--recipe',str(edited),'--out-dir',str(bundle)],check=True)
    assert (bundle/'asset_packet.json').is_file()
    edit_report=json.loads(report.read_text('utf-8'))
    assert edit_report['gate']['status'] in {'pass','warn','branch'}

def test_bundle_reports_real_distance_from_locked_master(tmp_path):
    from face_lattice import generate_variants, lock_candidate, apply_edits, build_asset_bundle
    variants=generate_variants(6,seed=8,min_distance=.10)
    master=lock_candidate(variants,candidate_id=variants[1]['character_id'],new_character_id='drifted')
    edited, edit_report=apply_edits(master,{'identity.geometry.jaw_angle':.55})
    out=tmp_path/'bundle'
    build_asset_bundle(edited,out)
    continuity=json.loads((out/'continuity_report.json').read_text('utf-8'))
    assert continuity['distance_from_master']==edit_report['distance']
    assert continuity['gate']['status']==edit_report['gate']['status']

def test_identity_gate_catches_single_large_geometry_spike():
    from face_lattice import default_recipe, compare_recipes
    master=default_recipe('spike')
    candidate=json.loads(json.dumps(master))
    candidate['identity']['geometry']['jaw_width']=0.95
    # refresh through edit path is the supported workflow
    from face_lattice import apply_edits
    candidate, report=apply_edits(master,{'identity.geometry.jaw_width':0.95},master=master)
    assert report['distance'] < 0.12  # proves average alone would miss it
    assert report['gate']['status'] in {'warn','branch'}
    assert report['risk']['max_geometry_delta'] >= 0.95


def test_identity_gate_reports_top_changed_parameters():
    from face_lattice import default_recipe, apply_edits
    master=default_recipe('tops')
    _, report=apply_edits(master,{
        'identity.geometry.eye_tilt':0.55,
        'identity.geometry.nasal_root_width':-0.40,
        'identity.soft_tissue.upper_lip_volume':0.25,
    },master=master)
    names=[x['parameter'] for x in report['risk']['top_changes']]
    assert 'eye_tilt' in names
    assert 'nasal_root_width' in names

def test_precision_geometry_includes_vertical_and_profile_axes():
    from face_lattice import default_recipe, compile_face_spec
    r=default_recipe('precision')
    required={'forehead_slope','cheekbone_height','orbital_height','nose_length','nose_tip_rotation','chin_height','mandibular_length','mouth_projection'}
    assert required <= set(r['identity']['geometry'])
    r['identity']['geometry']['nose_length']=0.7
    r['identity']['geometry']['chin_height']=-0.6
    text=compile_face_spec(r).lower()
    assert 'nose_length' in text and 'chin_height' in text
