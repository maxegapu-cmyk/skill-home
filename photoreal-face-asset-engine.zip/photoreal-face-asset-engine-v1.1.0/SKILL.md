---
name: photoreal-face-asset-engine
description: Use when designing an original or authorized photoreal human face that needs high customization, strong identity continuity, reusable multi-view assets, and controlled editing across image or video workflows.
---

# Photoreal Face Asset Engine

## 目标

把“捏一张好看的脸”升级成“建立一个可长期复用的人物身份资产”。系统把身份骨架、软组织、天然不对称、可逆状态、真人材质和连续性验收拆开管理：先拉开候选脸差异，再选中并锁定一个人物，之后任何角度、表情、发型、光线和场景变化都围绕同一母资产工作。

默认结果是现实摄影中的成年人物，不是动漫、CG 人偶、蜡像或强美容滤镜脸。

## 核心原则

1. **先结构，后质感。** 眼距、面中、颧弓、下颌、鼻部比例等先决定“是谁”；皮肤和摄影只能让身份更可信，不能替代身份结构。
2. **可变状态不写回身份。** 表情、妆容、发型、灯光、焦段、场景属于可逆层。
3. **天然不对称是稳定特征，不是随机噪声。** 小幅眉眼、鼻轴、嘴角、下颌偏差应跨视图保持。
4. **候选必须真正拉开。** 使用 maximin 候选选择和最小身份距离，避免批量生成一堆近似模板脸。
5. **锁定后始终有母资产。** 长链生成遇到漂移时回母资产，不把最后一张偶然漂掉的图继续当真源。
6. **真人感服从材料与光学。** 毛孔、油脂、汗毛、眼白、泪线、头发、接触阴影和镜头行为必须有空间与物理逻辑。

## 推荐工作流

### 1. 生成高差异候选脸

```bash
python scripts/face_lattice.py variants \
  --count 24 --seed 42 --min-distance 0.10 \
  --out candidates.json

python scripts/face_lattice.py diversity \
  --candidates candidates.json
```

先看候选之间的结构跨度，不要急着加风格、妆容和强光。

### 2. 锁定选中的人物

```bash
python scripts/face_lattice.py lock \
  --candidates candidates.json \
  --candidate-id candidate-007 \
  --id character-hero \
  --out character-hero.json
```

`lock` 会保留选中候选的身份参数，生成稳定的 `identity_fingerprint`，并保存母身份快照。它不会重新创建一张零参数脸。

### 3. 精细编辑

```bash
python scripts/face_lattice.py edit \
  --recipe character-hero.json \
  --set identity.geometry.jaw_angle=0.22 \
  --set identity.soft_tissue.cheek_fullness=-0.10 \
  --set variation.expression.smile=0.30 \
  --out character-hero-v2.json \
  --report edit-report.json
```

编辑使用点路径。身份参数范围固定为 `[-1, 1]`；真人材质参数为 `[0, 1]`。每次编辑都会给出总漂移和 geometry / soft_tissue / natural_asymmetry 三组贡献。

### 4. 编译人物结构与真人材质合同

```bash
python scripts/face_lattice.py spec \
  --recipe character-hero-v2.json \
  --out face-spec.txt

python scripts/face_lattice.py realism \
  --recipe character-hero-v2.json \
  --out realism-contract.txt
```

`face-spec.txt` 是中性的结构描述，不会自动把人物推向“平均漂亮脸”。`realism-contract.txt` 负责真实皮肤、眼睛、头发、日常光线和摄影材料。

### 5. 建立多视角资产图集

```bash
python scripts/face_lattice.py atlas --out atlas-spec.json
```

至少完成：正面、左右 30°、左右 45°、左右侧面、轻仰、轻俯，再补轻笑与眯眼压力视图。校准视图应尽量用低干扰发型、可解释光源和正常透视。

### 6. 一键生成完整人物资产包

```bash
python scripts/face_lattice.py bundle \
  --recipe character-hero-v2.json \
  --out-dir character-hero-asset
```

输出：

- `character_recipe.json`：身份数值真源；
- `identity_contract.txt`：机器可读的身份参数合同；
- `face_spec.txt`：中性形态描述；
- `realism_contract.txt`：真人材质合同；
- `atlas_spec.json`：多视角资产清单；
- `continuity_report.json`：相对母资产的真实漂移与门禁；
- `asset_packet.json`：下游接入索引。

## 身份门禁

默认距离区间：

- `0.00–0.12`：`pass`，可以继续；
- `0.12–0.28`：`warn`，当前结果可以保留，但下一次重新从母资产锚定；
- `>0.28`：`branch`，应回退或明确创建新的角色身份。

门禁同时检查**总身份距离**和**单参数局部尖峰**：即使总平均距离不高，单个高权重骨骼参数被大幅拉动也会触发 `warn` 或 `branch`。

这里的距离是**配方空间距离**，不是人脸识别模型的生物特征相似度。真正接入具体图像/视频模型时，仍应增加图像级身份、头姿、质量与真人感验收。

## 真人感硬门禁

以下症状出现时，不因“整体好看”而放行：

- 毛孔全脸同尺寸、规律点阵；
- 两侧纹理像镜像复制；
- 额头、鼻、面颊和下巴共享同一种塑料高光；
- 眼白纯白、泪线消失、虹膜呈机械放射纹；
- 发际线像硬遮罩，发束和睫毛重复；
- 皮肤、耳朵、脖子材质不统一；
- 人脸异常锐，环境却毫无对应光学关系；
- 每张图都像同一美容棚灯、同一滤镜、同一焦段模板。

## 下游使用

身份参考回答“是谁”；姿态/关键点/深度回答“怎么转头与怎么站”；场景参考回答“在哪里、穿什么、什么光”；真人感合同负责“是否像真实摄影”。这四类信号不要混成一张万能参考图。

## 验证

```bash
pytest -q
python scripts/pressure_test.py
```

同时按 `references/validation-protocol.md` 做目标模型上的实际渲染验收。

## 文件导航

- `references/architecture.md`：身份参数、编辑预算与母资产逻辑。
- `references/photorealism.md`：皮肤、眼睛、头发与日常摄影真实性。
- `references/github-research-map.md`：公开 GitHub 技术路线。
- `references/downstream-handoff.md`：图像/视频下游接口。
- `references/validation-protocol.md`：实际生成后的验收方法。
- `schema/face-recipe.schema.json`：完整参数范围约束。
- `scripts/face_lattice.py`：主工具。
- `scripts/pressure_test.py`：压力测试。
