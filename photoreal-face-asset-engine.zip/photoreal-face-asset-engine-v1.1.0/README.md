# Photoreal Face Asset Engine 1.1.0

一套模型无关的真人角色捏脸与人物资产底层 Skill。它不负责替代图像模型本身，而是负责把“候选脸探索、人物锁定、精细编辑、多视角资产、真人质感、漂移回锚”变成稳定的数据合同和工作流。

最短路径：

```bash
python scripts/face_lattice.py variants --count 24 --seed 42 --min-distance .10 --out candidates.json
python scripts/face_lattice.py lock --candidates candidates.json --candidate-id candidate-007 --id hero --out hero.json
python scripts/face_lattice.py bundle --recipe hero.json --out-dir hero-asset
```

完整说明见 `SKILL.md`。
