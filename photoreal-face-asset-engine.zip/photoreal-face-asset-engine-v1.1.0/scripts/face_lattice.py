#!/usr/bin/env python3
"""Photoreal face asset recipe utilities.

Standard-library only. Creates diverse face recipes, locks selected candidates,
tracks identity edits, compiles photoreal contracts, and builds reusable asset packets.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import random
import statistics
from pathlib import Path

GEOMETRY_WEIGHTS = {
    "face_width": 1.4, "face_height": 1.4, "temple_width": 1.1,
    "cheekbone_width": 1.4, "jaw_width": 1.5, "jaw_angle": 1.3,
    "chin_width": 1.2, "chin_projection": 1.3, "midface_depth": 1.4,
    "brow_ridge": 1.0, "orbital_spacing": 1.5, "eye_fissure_length": 1.1,
    "eye_tilt": 0.8, "nasal_root_width": 1.3, "nasal_bridge_projection": 1.4,
    "alar_width": 1.2, "nose_tip_projection": 1.2, "philtrum_length": 1.0,
    "mouth_width": 1.1, "hairline_height": 0.8,
    "forehead_slope": 0.9, "cheekbone_height": 1.0, "orbital_height": 1.0,
    "nose_length": 1.2, "nose_tip_rotation": 0.9, "chin_height": 1.1,
    "mandibular_length": 1.2, "mouth_projection": 1.0,
}
SOFT_WEIGHTS = {
    "upper_lid_weight": 0.45, "lower_lid_fullness": 0.35, "cheek_fullness": 0.45,
    "nasolabial_softness": 0.30, "upper_lip_volume": 0.40, "lower_lip_volume": 0.40,
    "under_chin_softness": 0.25,
}
ASYM_WEIGHTS = {
    "brow_offset": 0.25, "lid_offset": 0.25, "mouth_corner_offset": 0.20,
    "nasal_axis_offset": 0.20, "jaw_balance_offset": 0.20,
}
ALL_WEIGHTS = {**GEOMETRY_WEIGHTS, **SOFT_WEIGHTS, **ASYM_WEIGHTS}
GROUP_WEIGHTS = {
    "geometry": GEOMETRY_WEIGHTS,
    "soft_tissue": SOFT_WEIGHTS,
    "natural_asymmetry": ASYM_WEIGHTS,
}

FACE_LABELS = {
    "face_width": ("narrow facial breadth", "balanced facial breadth", "broad facial breadth"),
    "face_height": ("shorter vertical facial proportion", "balanced vertical proportion", "longer vertical facial proportion"),
    "temple_width": ("narrower temples", "balanced temples", "broader temples"),
    "cheekbone_width": ("restrained cheekbone breadth", "balanced cheekbone breadth", "broad cheekbone span"),
    "jaw_width": ("narrow lower jaw", "balanced lower jaw", "broad lower jaw"),
    "jaw_angle": ("softer mandibular angle", "balanced mandibular angle", "more angular mandibular corner"),
    "chin_width": ("tapered chin width", "balanced chin width", "broad chin width"),
    "chin_projection": ("slightly recessed chin projection", "balanced chin projection", "forward chin projection"),
    "midface_depth": ("flatter midface depth", "balanced midface depth", "more projected midface"),
    "brow_ridge": ("soft brow ridge", "balanced brow ridge", "more defined brow ridge"),
    "orbital_spacing": ("closer orbital spacing", "balanced orbital spacing", "wider orbital spacing"),
    "eye_fissure_length": ("shorter eye fissure", "balanced eye fissure length", "longer eye fissure"),
    "eye_tilt": ("slight downward eye-axis tilt", "near-level eye axis", "slight upward eye-axis tilt"),
    "nasal_root_width": ("narrow nasal root", "balanced nasal root", "broad nasal root"),
    "nasal_bridge_projection": ("lower bridge projection", "balanced bridge projection", "stronger bridge projection"),
    "alar_width": ("narrow alar base", "balanced alar base", "broader alar base"),
    "nose_tip_projection": ("restrained tip projection", "balanced tip projection", "stronger tip projection"),
    "philtrum_length": ("shorter philtrum", "balanced philtrum length", "longer philtrum"),
    "mouth_width": ("narrower mouth span", "balanced mouth span", "wider mouth span"),
    "hairline_height": ("lower hairline", "balanced hairline height", "higher hairline"),
    "forehead_slope": ("more upright forehead profile", "balanced forehead profile", "more sloped forehead profile"),
    "cheekbone_height": ("lower cheekbone position", "balanced cheekbone height", "higher cheekbone position"),
    "orbital_height": ("shorter orbital height", "balanced orbital height", "taller orbital height"),
    "nose_length": ("shorter nasal length", "balanced nasal length", "longer nasal length"),
    "nose_tip_rotation": ("slightly downward tip rotation", "balanced tip rotation", "slightly upward tip rotation"),
    "chin_height": ("shorter chin height", "balanced chin height", "longer chin height"),
    "mandibular_length": ("shorter mandibular body", "balanced mandibular length", "longer mandibular body"),
    "mouth_projection": ("restrained mouth projection", "balanced mouth projection", "more projected mouth region"),
    "upper_lid_weight": ("lighter upper-lid tissue", "balanced upper-lid tissue", "heavier upper-lid tissue"),
    "lower_lid_fullness": ("restrained lower-lid fullness", "balanced lower-lid fullness", "more lower-lid fullness"),
    "cheek_fullness": ("leaner cheek soft tissue", "balanced cheek soft tissue", "fuller cheek soft tissue"),
    "upper_lip_volume": ("restrained upper-lip volume", "balanced upper-lip volume", "fuller upper-lip volume"),
    "lower_lip_volume": ("restrained lower-lip volume", "balanced lower-lip volume", "fuller lower-lip volume"),
}


def _zeros(keys):
    return {k: 0.0 for k in keys}


def _clip(x):
    return max(-1.0, min(1.0, float(x)))


def _identity_payload(recipe: dict) -> dict:
    return recipe["identity"]


def fingerprint_identity(recipe: dict) -> str:
    raw = json.dumps(_identity_payload(recipe), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _refresh_fingerprint(recipe: dict, set_master: bool = False) -> dict:
    recipe["identity_fingerprint"] = fingerprint_identity(recipe)
    recipe.setdefault("continuity", {})
    if set_master or not recipe["continuity"].get("master_fingerprint"):
        recipe["continuity"]["master_fingerprint"] = recipe["identity_fingerprint"]
    return recipe


def default_recipe(character_id: str = "character-001") -> dict:
    recipe = {
        "schema_version": "1.1",
        "character_id": character_id,
        "scope": "original-or-authorized-character",
        "identity": {
            "geometry": _zeros(GEOMETRY_WEIGHTS),
            "soft_tissue": _zeros(SOFT_WEIGHTS),
            "natural_asymmetry": _zeros(ASYM_WEIGHTS),
        },
        "variation": {
            "expression": {"smile": 0.0, "brow_activity": 0.0, "squint": 0.0, "jaw_open": 0.0},
            "grooming": {"hair_volume": 0.0, "strand_disorder": 0.15, "makeup_intensity": 0.0},
            "lighting": {"directionality": 0.25, "contrast": 0.10, "warmth": 0.0},
            "camera": {"focal_character": 0.0, "height_offset": 0.0, "distance": 0.0},
        },
        "realism": {
            "target": "photographic-human",
            "skin": {
                "pore_heterogeneity": 0.55,
                "vellus_hair_visibility": 0.25,
                "sebum_zone_variation": 0.35,
                "micro_color_variation": 0.35,
                "under_eye_translucency": 0.22,
                "lip_surface_irregularity": 0.25,
                "roughness_variation": 0.35,
            },
            "eyes": {"sclera_tint_variation": 0.25, "tear_line_presence": 0.35, "iris_microcontrast": 0.35},
            "daily_life": {"available_light_bias": 0.75, "minor_pose_imperfection": 0.30, "stray_hair": 0.35},
        },
        "continuity": {
            "pass_max": 0.12,
            "warn_max": 0.28,
            "branch_above": 0.28,
            "reanchor_from_master": True,
            "lock_state": "draft",
            "master_fingerprint": "",
        },
    }
    return _refresh_fingerprint(recipe, set_master=True)


def _iter_identity(recipe):
    identity = recipe["identity"]
    for group, weights in GROUP_WEIGHTS.items():
        vals = identity[group]
        for key, weight in weights.items():
            yield group, key, float(vals[key]), weight


def identity_distance(a: dict, b: dict) -> float:
    """Weighted normalized L1 distance on identity-only parameters, 0..1."""
    av = {(g, k): (v, w) for g, k, v, w in _iter_identity(a)}
    bv = {(g, k): (v, w) for g, k, v, w in _iter_identity(b)}
    num = den = 0.0
    for key, (x, w) in av.items():
        y = bv[key][0]
        num += w * min(2.0, abs(x - y)) / 2.0
        den += w
    return round(num / den if den else 0.0, 6)


def identity_group_contributions(a: dict, b: dict) -> dict:
    total_den = sum(ALL_WEIGHTS.values())
    out = {}
    for group, weights in GROUP_WEIGHTS.items():
        av = a["identity"][group]
        bv = b["identity"][group]
        raw = sum(w * min(2.0, abs(float(av[k]) - float(bv[k]))) / 2.0 for k, w in weights.items())
        out[group] = round(raw / total_den, 6)
    return out


def drift_gate(distance: float, recipe: dict | None = None) -> dict:
    d = float(distance)
    pass_max = float(recipe["continuity"]["pass_max"]) if recipe else 0.12
    warn_max = float(recipe["continuity"]["warn_max"]) if recipe else 0.28
    if d <= pass_max:
        return {"status": "pass", "action": "continue-from-current-approved-frame", "distance": d}
    if d <= warn_max:
        return {"status": "warn", "action": "reanchor-from-master-atlas-before-next-generation", "distance": d}
    return {"status": "branch", "action": "treat-as-new-character-or-revert-to-master-identity", "distance": d}


def identity_risk(master: dict, candidate: dict) -> dict:
    changes = []
    maxima = {"geometry": 0.0, "soft_tissue": 0.0, "natural_asymmetry": 0.0}
    for group, weights in GROUP_WEIGHTS.items():
        for key, weight in weights.items():
            delta = abs(float(master["identity"][group][key]) - float(candidate["identity"][group][key]))
            maxima[group] = max(maxima[group], delta)
            if delta > 0:
                changes.append({"group": group, "parameter": key, "delta": round(delta, 6), "weight": weight, "weighted_delta": round(delta * weight, 6)})
    changes.sort(key=lambda item: (item["weighted_delta"], item["delta"]), reverse=True)
    return {
        "max_geometry_delta": round(maxima["geometry"], 6),
        "max_soft_tissue_delta": round(maxima["soft_tissue"], 6),
        "max_asymmetry_delta": round(maxima["natural_asymmetry"], 6),
        "top_changes": changes[:8],
    }


def identity_gate(master: dict, candidate: dict) -> dict:
    distance = identity_distance(master, candidate)
    risk = identity_risk(master, candidate)
    pass_max = float(master["continuity"]["pass_max"])
    warn_max = float(master["continuity"]["warn_max"])
    branch_spike = (
        risk["max_geometry_delta"] > 0.85
        or risk["max_soft_tissue_delta"] > 1.10
        or risk["max_asymmetry_delta"] > 0.40
    )
    warn_spike = (
        risk["max_geometry_delta"] > 0.45
        or risk["max_soft_tissue_delta"] > 0.70
        or risk["max_asymmetry_delta"] > 0.22
    )
    if distance > warn_max or branch_spike:
        return {"status": "branch", "action": "treat-as-new-character-or-revert-to-master-identity", "distance": distance, "reason": "aggregate-drift-or-local-identity-spike"}
    if distance > pass_max or warn_spike:
        return {"status": "warn", "action": "reanchor-from-master-atlas-before-next-generation", "distance": distance, "reason": "aggregate-drift-or-local-identity-spike"}
    return {"status": "pass", "action": "continue-from-current-approved-frame", "distance": distance, "reason": "within-aggregate-and-local-budgets"}


def compare_recipes(master: dict, candidate: dict) -> dict:
    distance = identity_distance(master, candidate)
    return {
        "master_character_id": master.get("character_id", ""),
        "candidate_character_id": candidate.get("character_id", ""),
        "distance": distance,
        "gate": identity_gate(master, candidate),
        "risk": identity_risk(master, candidate),
        "group_contributions": identity_group_contributions(master, candidate),
        "master_fingerprint": fingerprint_identity(master),
        "candidate_fingerprint": fingerprint_identity(candidate),
    }


def validate_recipe(recipe: dict) -> list[str]:
    errors = []
    if recipe.get("scope") != "original-or-authorized-character":
        errors.append("scope must stay original-or-authorized-character")
    try:
        for _group, key, value, _weight in _iter_identity(recipe):
            if not -1.0 <= value <= 1.0:
                errors.append(f"{key} out of [-1,1]: {value}")
    except Exception as exc:
        errors.append(f"identity structure invalid: {exc}")
        return errors
    g = recipe["identity"]["geometry"]
    if abs(g["face_width"] - g["cheekbone_width"]) > 1.25:
        errors.append("face_width/cheekbone_width coupling broken")
    if g["jaw_width"] - g["face_width"] > 1.10:
        errors.append("jaw_width too detached from face_width")
    if abs(g["orbital_spacing"] - g["eye_fissure_length"]) > 1.55:
        errors.append("orbital/eye span combination too extreme")
    if abs(g["alar_width"] - g["nasal_root_width"]) > 1.55:
        errors.append("nasal width coupling broken")
    fp = recipe.get("identity_fingerprint")
    if fp and fp != fingerprint_identity(recipe):
        errors.append("identity_fingerprint does not match identity payload")
    return errors


def _candidate(rng: random.Random, idx: int) -> dict:
    recipe = default_recipe(f"candidate-{idx:03d}")
    g = recipe["identity"]["geometry"]
    s = recipe["identity"]["soft_tissue"]
    asym = recipe["identity"]["natural_asymmetry"]

    width = rng.uniform(-0.90, 0.90)
    vertical = rng.uniform(-0.90, 0.90)
    lower = rng.uniform(-0.90, 0.90)
    orbital = rng.uniform(-0.90, 0.90)
    nasal = rng.uniform(-0.90, 0.90)
    mouth = rng.uniform(-0.90, 0.90)
    depth = rng.uniform(-0.80, 0.80)

    g.update({
        "face_width": width,
        "face_height": vertical,
        "temple_width": _clip(width * 0.55 + rng.uniform(-0.35, 0.35)),
        "cheekbone_width": _clip(width * 0.65 + rng.uniform(-0.45, 0.45)),
        "jaw_width": _clip(width * 0.45 + lower * 0.55 + rng.uniform(-0.25, 0.25)),
        "jaw_angle": _clip(lower * 0.70 + rng.uniform(-0.30, 0.30)),
        "chin_width": _clip(lower * 0.55 + rng.uniform(-0.40, 0.40)),
        "chin_projection": _clip(depth * 0.35 + lower * 0.25 + rng.uniform(-0.45, 0.45)),
        "midface_depth": depth,
        "brow_ridge": _clip(depth * 0.35 + rng.uniform(-0.55, 0.55)),
        "orbital_spacing": orbital,
        "eye_fissure_length": _clip(orbital * 0.30 + rng.uniform(-0.70, 0.70)),
        "eye_tilt": rng.uniform(-0.75, 0.75),
        "nasal_root_width": nasal,
        "nasal_bridge_projection": _clip(depth * 0.45 + rng.uniform(-0.55, 0.55)),
        "alar_width": _clip(nasal * 0.55 + rng.uniform(-0.50, 0.50)),
        "nose_tip_projection": _clip(depth * 0.40 + rng.uniform(-0.60, 0.60)),
        "philtrum_length": rng.uniform(-0.75, 0.75),
        "mouth_width": mouth,
        "hairline_height": rng.uniform(-0.70, 0.70),
        "forehead_slope": rng.uniform(-0.70, 0.70),
        "cheekbone_height": _clip(-vertical * 0.20 + rng.uniform(-0.65, 0.65)),
        "orbital_height": rng.uniform(-0.70, 0.70),
        "nose_length": _clip(vertical * 0.25 + rng.uniform(-0.65, 0.65)),
        "nose_tip_rotation": rng.uniform(-0.65, 0.65),
        "chin_height": _clip(vertical * 0.20 + lower * 0.30 + rng.uniform(-0.55, 0.55)),
        "mandibular_length": _clip(lower * 0.45 + rng.uniform(-0.55, 0.55)),
        "mouth_projection": _clip(depth * 0.30 + rng.uniform(-0.60, 0.60)),
    })
    s.update({
        "upper_lid_weight": rng.uniform(-0.75, 0.75),
        "lower_lid_fullness": rng.uniform(-0.65, 0.65),
        "cheek_fullness": _clip(-depth * 0.20 + rng.uniform(-0.70, 0.70)),
        "nasolabial_softness": rng.uniform(-0.60, 0.60),
        "upper_lip_volume": _clip(mouth * 0.20 + rng.uniform(-0.70, 0.70)),
        "lower_lip_volume": _clip(mouth * 0.15 + rng.uniform(-0.70, 0.70)),
        "under_chin_softness": rng.uniform(-0.55, 0.55),
    })
    for key in asym:
        asym[key] = rng.uniform(-0.22, 0.22)
    recipe["continuity"]["lock_state"] = "candidate"
    return _refresh_fingerprint(recipe, set_master=True)


def generate_variants(n: int, seed: int = 0, min_distance: float = 0.10) -> list[dict]:
    """Generate diverse candidates with a maximin selection pass."""
    if n < 1:
        return []
    if not 0 <= min_distance <= 0.35:
        raise ValueError("min_distance must be within 0..0.35")
    rng = random.Random(seed)
    pool = []
    target_pool = max(240, n * 36)
    attempts = 0
    while len(pool) < target_pool and attempts < target_pool * 8:
        attempts += 1
        c = _candidate(rng, len(pool) + 1)
        if not validate_recipe(c):
            pool.append(c)
    if len(pool) < n:
        raise RuntimeError("insufficient valid candidate pool")

    neutral = default_recipe("neutral")
    first = max(pool, key=lambda c: identity_distance(c, neutral))
    selected = [first]
    remaining = [c for c in pool if c is not first]
    while len(selected) < n and remaining:
        scored = []
        for c in remaining:
            nearest = min(identity_distance(c, s) for s in selected)
            spread = identity_distance(c, neutral)
            scored.append((nearest, spread, c))
        scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
        nearest, _spread, chosen = scored[0]
        if nearest < min_distance:
            break
        selected.append(chosen)
        remaining.remove(chosen)
    if len(selected) < n:
        raise RuntimeError(f"could only generate {len(selected)}/{n} variants at min_distance={min_distance}")

    for idx, item in enumerate(selected, 1):
        item["character_id"] = f"candidate-{idx:03d}"
        _refresh_fingerprint(item, set_master=True)
    return selected


def diversity_report(variants: list[dict], near_duplicate_threshold: float = 0.10) -> dict:
    if not variants:
        return {"count": 0, "pair_count": 0, "near_duplicate_pairs": 0, "axis_span": {}}
    distances = [identity_distance(variants[i], variants[j]) for i in range(len(variants)) for j in range(i)]
    axes = ["face_width", "face_height", "jaw_width", "cheekbone_width", "orbital_spacing", "nasal_root_width", "mouth_width", "midface_depth", "cheekbone_height", "orbital_height", "nose_length", "chin_height", "mandibular_length", "mouth_projection"]
    spans = {}
    for axis in axes:
        vals = [float(v["identity"]["geometry"][axis]) for v in variants]
        spans[axis] = round(max(vals) - min(vals), 6)
    return {
        "count": len(variants),
        "pair_count": len(distances),
        "min_pair_distance": min(distances) if distances else 0.0,
        "median_pair_distance": statistics.median(distances) if distances else 0.0,
        "max_pair_distance": max(distances) if distances else 0.0,
        "near_duplicate_pairs": sum(1 for d in distances if d < near_duplicate_threshold),
        "near_duplicate_threshold": near_duplicate_threshold,
        "axis_span": spans,
    }


def lock_candidate(variants: list[dict], candidate_id: str | None = None, index: int | None = None, new_character_id: str = "character-001") -> dict:
    if candidate_id is None and index is None:
        raise ValueError("candidate_id or index is required")
    chosen = None
    if candidate_id is not None:
        chosen = next((v for v in variants if v.get("character_id") == candidate_id), None)
        if chosen is None:
            raise ValueError(f"candidate not found: {candidate_id}")
    else:
        if index is None or index < 0 or index >= len(variants):
            raise ValueError("candidate index out of range")
        chosen = variants[index]
    recipe = copy.deepcopy(chosen)
    recipe["character_id"] = new_character_id
    recipe["continuity"]["lock_state"] = "locked-master"
    recipe["continuity"]["master_identity_snapshot"] = copy.deepcopy(recipe["identity"])
    recipe["provenance"] = {"kind": "selected-generated-candidate", "source_candidate": chosen.get("character_id", "")}
    return _refresh_fingerprint(recipe, set_master=True)


def _resolve_path(doc: dict, dotted: str):
    parts = dotted.split(".")
    if len(parts) < 2:
        raise ValueError(f"invalid edit path: {dotted}")
    cur = doc
    for part in parts[:-1]:
        if not isinstance(cur, dict) or part not in cur:
            raise ValueError(f"unknown edit path: {dotted}")
        cur = cur[part]
    leaf = parts[-1]
    if leaf not in cur:
        raise ValueError(f"unknown edit path: {dotted}")
    return cur, leaf


def _master_from_snapshot(recipe: dict) -> dict | None:
    snapshot = recipe.get("continuity", {}).get("master_identity_snapshot")
    if not snapshot:
        return None
    master = copy.deepcopy(recipe)
    master["identity"] = copy.deepcopy(snapshot)
    _refresh_fingerprint(master, set_master=True)
    return master


def apply_edits(recipe: dict, edits: dict[str, float], master: dict | None = None) -> tuple[dict, dict]:
    out = copy.deepcopy(recipe)
    for path, raw_value in edits.items():
        parent, leaf = _resolve_path(out, path)
        if not isinstance(parent[leaf], (int, float)):
            raise ValueError(f"edit target is not numeric: {path}")
        value = float(raw_value)
        if path.startswith("identity.") and not -1.0 <= value <= 1.0:
            raise ValueError(f"identity edit out of [-1,1]: {path}={value}")
        if path.startswith("realism.") and not 0.0 <= value <= 1.0:
            raise ValueError(f"realism edit out of [0,1]: {path}={value}")
        if path.startswith("variation.") and not -1.0 <= value <= 1.0:
            raise ValueError(f"variation edit out of [-1,1]: {path}={value}")
        parent[leaf] = value
    _refresh_fingerprint(out, set_master=False)
    errors = validate_recipe(out)
    if errors:
        raise ValueError("; ".join(errors))
    master_recipe = master or _master_from_snapshot(recipe) or recipe
    report = compare_recipes(master_recipe, out)
    return out, report


def _trait_label(value: float, labels: tuple[str, str, str]) -> str:
    if value <= -0.35:
        return labels[0]
    if value >= 0.35:
        return labels[2]
    return labels[1]


def compile_face_spec(recipe: dict) -> str:
    """Compile identity parameters into a neutral morphology contract."""
    identity = recipe["identity"]
    lines = [f"character_id={recipe['character_id']}", "IDENTITY MORPHOLOGY:"]
    for group_name in ("geometry", "soft_tissue"):
        for key, value in identity[group_name].items():
            if key in FACE_LABELS:
                lines.append(f"- {key}: {_trait_label(float(value), FACE_LABELS[key])} ({float(value):+.2f})")
    asym = identity["natural_asymmetry"]
    lines.append("NATURAL ASYMMETRY: preserve the small persistent left-right offsets; never mirror-correct the face into bilateral perfection.")
    lines.append("ASYMMETRY VALUES: " + ", ".join(f"{k}={float(v):+.2f}" for k, v in asym.items()))
    lines.append("PRESERVATION RULE: preserve these relative proportions across angle, expression, grooming and lighting; do not beautify or average the face toward a generic model-like template.")
    return "\n".join(lines)


def compile_realism_contract(recipe: dict) -> str:
    """Model-neutral photorealism contract grounded in observable human material behavior."""
    return (
        "Treat the subject as an ordinary photographed adult human rather than an illustration, render, mannequin or beauty-filter composite. "
        "Skin microstructure must vary by facial region and spatial scale: pores are irregular rather than stamped, fine vellus hair appears only where light reveals it, "
        "and tiny color variation sits beneath the surface instead of becoming decorative freckles or noise. Separate base skin color from illumination: shadows and warm/cool light must not repaint the underlying complexion. "
        "Specular response must vary with local roughness and sebum zones; forehead, nose, inner cheek, eyelid and lip surfaces should not share one uniform gloss. "
        "Retain subtle under-eye translucency, fine lip surface breaks, soft tissue compression, natural contact shadows and slight stable left-right asymmetry. "
        "Eyes require off-white sclera, restrained vessel/color variation, a narrow wet tear line, non-repeating iris detail and catchlights consistent with the actual scene light. "
        "Hair needs mass, clumps and a small number of independent flyaways; the hairline must transition through changing density rather than a hard mask edge. "
        "Use plausible everyday optics and available light: window/room/street/overcast sources when appropriate, ordinary lens depth behavior, minor pose and framing imperfection, clothing creases and coherent background interaction. "
        "Reject waxy skin, pore grids, uniform gloss, porcelain sclera, duplicated lashes or hair strands, edge halos, excessive local sharpening, mirrored texture, plastic lips/teeth and studio-beauty lighting that appears without a source."
    )


def compile_identity_contract(recipe: dict) -> str:
    def fmt(group):
        return ", ".join(f"{k}={float(v):+.2f}" for k, v in group.items())
    ident = recipe["identity"]
    return (
        f"character_id={recipe['character_id']}\n"
        f"identity_fingerprint={fingerprint_identity(recipe)}\n"
        f"GEOMETRY: {fmt(ident['geometry'])}\n"
        f"SOFT_TISSUE: {fmt(ident['soft_tissue'])}\n"
        f"NATURAL_ASYMMETRY: {fmt(ident['natural_asymmetry'])}\n"
        "RULE: scene, lens, grooming and expression are reversible state; they must not silently rewrite identity geometry."
    )


def atlas_spec() -> list[dict]:
    return [
        {"id": "front-neutral", "yaw": 0, "pitch": 0, "expression": "neutral", "purpose": "primary identity anchor"},
        {"id": "left-30", "yaw": -30, "pitch": 0, "expression": "neutral", "purpose": "near-angle continuity"},
        {"id": "right-30", "yaw": 30, "pitch": 0, "expression": "neutral", "purpose": "near-angle continuity"},
        {"id": "left-45", "yaw": -45, "pitch": 0, "expression": "neutral", "purpose": "cross-angle recovery"},
        {"id": "right-45", "yaw": 45, "pitch": 0, "expression": "neutral", "purpose": "cross-angle recovery"},
        {"id": "left-profile", "yaw": -90, "pitch": 0, "expression": "neutral", "purpose": "silhouette/nose/chin validation"},
        {"id": "right-profile", "yaw": 90, "pitch": 0, "expression": "neutral", "purpose": "silhouette/asymmetry validation"},
        {"id": "up-15", "yaw": 0, "pitch": 15, "expression": "neutral", "purpose": "jaw/nostril/orbit validation"},
        {"id": "down-15", "yaw": 0, "pitch": -15, "expression": "neutral", "purpose": "forehead/lid/cheek validation"},
        {"id": "front-soft-smile", "yaw": 0, "pitch": 0, "expression": "soft-smile", "purpose": "expression deformation anchor"},
        {"id": "front-squint", "yaw": 0, "pitch": 0, "expression": "mild-squint", "purpose": "eyelid identity stress test"},
    ]


def build_asset_bundle(recipe: dict, out_dir: str | Path) -> dict:
    errors = validate_recipe(recipe)
    if errors:
        raise ValueError("invalid recipe: " + "; ".join(errors))
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    recipe = copy.deepcopy(recipe)
    _refresh_fingerprint(recipe, set_master=False)
    if recipe["continuity"].get("lock_state") == "draft":
        recipe["continuity"]["lock_state"] = "locked-master"
        recipe["continuity"]["master_fingerprint"] = recipe["identity_fingerprint"]
        recipe["continuity"]["master_identity_snapshot"] = copy.deepcopy(recipe["identity"])

    (out / "character_recipe.json").write_text(json.dumps(recipe, ensure_ascii=False, indent=2) + "\n", "utf-8")
    (out / "identity_contract.txt").write_text(compile_identity_contract(recipe) + "\n", "utf-8")
    (out / "face_spec.txt").write_text(compile_face_spec(recipe) + "\n", "utf-8")
    (out / "realism_contract.txt").write_text(compile_realism_contract(recipe) + "\n", "utf-8")
    (out / "atlas_spec.json").write_text(json.dumps(atlas_spec(), ensure_ascii=False, indent=2) + "\n", "utf-8")
    master_recipe = _master_from_snapshot(recipe) or recipe
    continuity_eval = compare_recipes(master_recipe, recipe)
    continuity = {
        "character_id": recipe["character_id"],
        "master_fingerprint": recipe["continuity"]["master_fingerprint"],
        "current_fingerprint": recipe["identity_fingerprint"],
        "distance_from_master": continuity_eval["distance"],
        "gate": continuity_eval["gate"],
        "group_contributions": continuity_eval["group_contributions"],
        "rule": "warn or branch states reanchor from the approved master asset before further chaining",
    }
    (out / "continuity_report.json").write_text(json.dumps(continuity, ensure_ascii=False, indent=2) + "\n", "utf-8")
    packet = {
        "character_id": recipe["character_id"],
        "schema_version": recipe["schema_version"],
        "identity_fingerprint": recipe["identity_fingerprint"],
        "files": {
            "recipe": "character_recipe.json",
            "identity_contract": "identity_contract.txt",
            "face_spec": "face_spec.txt",
            "realism_contract": "realism_contract.txt",
            "atlas_spec": "atlas_spec.json",
            "continuity_report": "continuity_report.json",
        },
        "reference_images": {view["id"]: "" for view in atlas_spec()},
        "status": "awaiting-rendered-reference-images",
    }
    (out / "asset_packet.json").write_text(json.dumps(packet, ensure_ascii=False, indent=2) + "\n", "utf-8")
    return packet


def _load_json(path: str | Path):
    return json.loads(Path(path).read_text("utf-8"))


def _write_json(path: str | Path, data):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", "utf-8")


def _parse_edit(items: list[str]) -> dict[str, float]:
    edits = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"edit must be path=value: {item}")
        path, value = item.split("=", 1)
        edits[path.strip()] = float(value)
    return edits


def main(argv=None):
    parser = argparse.ArgumentParser(description="Photoreal face asset recipe engine")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_new = sub.add_parser("new", help="create a neutral editable recipe")
    p_new.add_argument("--id", required=True)
    p_new.add_argument("--out", required=True)

    p_var = sub.add_parser("variants", help="generate high-separation candidate faces")
    p_var.add_argument("--count", type=int, default=12)
    p_var.add_argument("--seed", type=int, default=0)
    p_var.add_argument("--min-distance", type=float, default=0.10)
    p_var.add_argument("--out", required=True)

    p_lock = sub.add_parser("lock", help="lock a selected candidate as a master identity")
    p_lock.add_argument("--candidates", required=True)
    pick = p_lock.add_mutually_exclusive_group(required=True)
    pick.add_argument("--candidate-id")
    pick.add_argument("--index", type=int)
    p_lock.add_argument("--id", required=True)
    p_lock.add_argument("--out", required=True)

    p_edit = sub.add_parser("edit", help="edit sliders using dotted paths and report identity cost")
    p_edit.add_argument("--recipe", required=True)
    p_edit.add_argument("--master")
    p_edit.add_argument("--set", action="append", required=True, dest="edits")
    p_edit.add_argument("--out", required=True)
    p_edit.add_argument("--report")

    p_cmp = sub.add_parser("compare", help="compare identity recipes")
    p_cmp.add_argument("--master", required=True)
    p_cmp.add_argument("--candidate", required=True)
    p_cmp.add_argument("--out")

    p_spec = sub.add_parser("spec", help="compile neutral morphology contract")
    p_spec.add_argument("--recipe", required=True)
    p_spec.add_argument("--out")

    p_real = sub.add_parser("realism", help="compile photoreal material contract")
    p_real.add_argument("--recipe")
    p_real.add_argument("--out")

    p_atlas = sub.add_parser("atlas", help="write multi-view asset specification")
    p_atlas.add_argument("--out", required=True)

    p_bundle = sub.add_parser("bundle", help="build a self-contained character asset packet")
    p_bundle.add_argument("--recipe", required=True)
    p_bundle.add_argument("--out-dir", required=True)

    p_div = sub.add_parser("diversity", help="measure candidate separation and axis coverage")
    p_div.add_argument("--candidates", required=True)
    p_div.add_argument("--out")

    args = parser.parse_args(argv)

    if args.cmd == "new":
        _write_json(args.out, default_recipe(args.id))
    elif args.cmd == "variants":
        _write_json(args.out, generate_variants(args.count, args.seed, args.min_distance))
    elif args.cmd == "lock":
        variants = _load_json(args.candidates)
        _write_json(args.out, lock_candidate(variants, args.candidate_id, args.index, args.id))
    elif args.cmd == "edit":
        recipe = _load_json(args.recipe)
        master = _load_json(args.master) if args.master else None
        edited, report = apply_edits(recipe, _parse_edit(args.edits), master)
        _write_json(args.out, edited)
        if args.report:
            _write_json(args.report, report)
        else:
            print(json.dumps(report, ensure_ascii=False, indent=2))
    elif args.cmd == "compare":
        report = compare_recipes(_load_json(args.master), _load_json(args.candidate))
        if args.out:
            _write_json(args.out, report)
        else:
            print(json.dumps(report, ensure_ascii=False, indent=2))
    elif args.cmd == "spec":
        text = compile_face_spec(_load_json(args.recipe))
        if args.out:
            Path(args.out).write_text(text + "\n", "utf-8")
        else:
            print(text)
    elif args.cmd == "realism":
        recipe = default_recipe("character-001") if not args.recipe else _load_json(args.recipe)
        text = compile_realism_contract(recipe)
        if args.out:
            Path(args.out).write_text(text + "\n", "utf-8")
        else:
            print(text)
    elif args.cmd == "atlas":
        _write_json(args.out, atlas_spec())
    elif args.cmd == "bundle":
        packet = build_asset_bundle(_load_json(args.recipe), args.out_dir)
        print(json.dumps(packet, ensure_ascii=False, indent=2))
    elif args.cmd == "diversity":
        report = diversity_report(_load_json(args.candidates))
        if args.out:
            _write_json(args.out, report)
        else:
            print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
