#!/usr/bin/env python3
import json
import tempfile
from pathlib import Path

from face_lattice import (
    apply_edits,
    build_asset_bundle,
    compile_realism_contract,
    diversity_report,
    generate_variants,
    lock_candidate,
    validate_recipe,
)


def run():
    variants = generate_variants(32, seed=20260909, min_distance=0.10)
    diversity = diversity_report(variants)
    errors = [err for recipe in variants for err in validate_recipe(recipe)]
    locked = lock_candidate(variants, candidate_id=variants[7]["character_id"], new_character_id="stress-character")
    edited, edit_report = apply_edits(
        locked,
        {
            "identity.geometry.jaw_angle": 0.20,
            "identity.soft_tissue.cheek_fullness": -0.12,
            "variation.expression.smile": 0.45,
        },
    )
    with tempfile.TemporaryDirectory() as td:
        packet = build_asset_bundle(edited, Path(td) / "asset")
        bundle_files = sorted(p.name for p in (Path(td) / "asset").iterdir() if p.is_file())
    report = {
        "candidate_diversity": diversity,
        "validation_errors": errors,
        "locked_fingerprint_stable": locked["continuity"]["master_fingerprint"] == locked["identity_fingerprint"],
        "edit_report": edit_report,
        "realism_contract_length": len(compile_realism_contract(edited)),
        "bundle_character_id": packet["character_id"],
        "bundle_files": bundle_files,
    }
    report["status"] = "pass" if (
        not errors
        and diversity["min_pair_distance"] >= 0.10
        and diversity["near_duplicate_pairs"] == 0
        and report["locked_fingerprint_stable"]
        and len(bundle_files) >= 7
    ) else "fail"
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(run())
