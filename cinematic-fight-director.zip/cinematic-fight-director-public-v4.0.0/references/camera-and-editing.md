# Camera and Editing for Fight Readability

## 1. Camera serves proof

Each shot should prove one primary fact.

| Shot job | What the audience must understand | Reliable choices |
|---|---|---|
| Establish | positions, exits, obstacles, scale | wide/full, elevated or lateral |
| Follow | direction and speed of movement | side track, rear 3/4 follow, low track |
| Contact | whether and where action lands | side medium/full, short push, match cut |
| Reversal | who took initiative and why | reaction close/medium then two-shot |
| Impact | force direction and consequence | medium/full + brief accent |
| Result | final positions, damage, open route | pullback, rise, stable wide |

## 2. Action axis and screen direction

Before rapid editing, establish left/right geography. Preserve it through adjacent cuts. Cross the axis only through a shot that visually explains the camera's movement or through a neutral/overhead transition.

Record:

- A screen side,
- B screen side,
- each facing direction,
- dominant travel vector,
- camera side of axis.

## 3. Lens strategy

- 24–35mm equivalent: spatially kinetic, good for full-body and close proximity; beware distortion.
- 40–55mm: balanced general fight coverage.
- 70–100mm: compressed pursuit, reaction detail, projectile relationships; harder to read close grappling.

Lens feel should serve staging. Do not switch focal behavior randomly every half-second unless the edit is intentionally aggressive.

## 4. Camera movement hierarchy

A useful priority order during complex action:

1. keep bodies and contact readable;
2. preserve motion direction;
3. preserve identity;
4. then add camera spectacle.

If a complex orbit breaks 1–3, replace it with simpler lateral tracking or a short reposition.

## 5. Lag-and-catch technique

For extreme speed, a camera that follows perfectly can paradoxically reduce perceived velocity. Let the subject burst a fraction ahead, then let the camera whip/catch and settle. This creates speed while preserving a readable endpoint.

## 6. Impact punctuation options

Pick one primary accent for a hero impact:

- 5–15cm-feel micro-jolt;
- tiny snap push-in;
- whip pan that lands exactly at contact;
- action-match cut from wind-up to result;
- very brief hit-stop impression;
- abrupt audio transient followed by a half-beat of environmental clarity.

Do not apply all six to every punch.

## 7. Cut timing

Cut on one of these:

- just before contact to a clearer angle;
- exactly on contact for a match-action punch;
- immediately after contact to show consequence;
- during a fast occlusion or whip for invisible spatial repositioning.

Avoid cutting repeatedly in the middle of limb trajectories when the viewer still has not seen any result.

## 8. Close-up discipline

Close-ups are expensive in action because they remove space. Use them for:

- one decisive hand/weapon change,
- eye-line recognizing a threat,
- injury or grip failure that causes the next beat,
- one hero contact detail.

Return to a wider relation shot before another complex exchange.

## 9. One-take fights

A one-take should not mean constant orbiting. Divide camera behavior into phases: establish → track → short lateral reposition → whip to new threat → pull/rise for result. The movement remains continuous, but each phase has one job.

## 10. Shaky-cam limit

Persistent shake makes AI anatomy and contact harder to evaluate and often reads as camouflage. Prefer stable tracking with short impact jolts. If documentary chaos is desired, preserve at least one stable landmark or horizon cue.
