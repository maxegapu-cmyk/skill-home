# Style and VFX Layer

## Rule

Style is a layer over choreography, not a substitute for it.

## 1. Build style from physical choices

Specify:

- capture texture: digital clean, 35mm negative, 16mm, anamorphic, documentary sensor;
- palette: dominant hues, saturation, black level, highlight behavior;
- light source: windows, sodium lamps, moon, fluorescent tubes, fire, practicals;
- atmosphere: rain, mist, dust, smoke, snow, ash;
- lens/depth: wide/deep vs longer/shallow;
- movement texture: crisp shutter, natural blur, smeared whip-pan, stylized afterimage;
- finishing: grain, halation, bloom, gate weave if desired.

Avoid “cinematic, masterpiece, 8K” as the main style instruction.

## 2. Dark Eastern fantasy preset

Use this as a configurable preset, not a fixed prompt:

- dark Eastern-fantasy realism;
- cool cyan/ink-blue dominant grade, low saturation, deep shadows;
- neutral highlights with isolated warm practical lamps or fire;
- 35mm negative-like texture, fine even grain, restrained halation;
- shallow depth only when it will not hide contact;
- wet stone, rain/mist or airborne particles to reveal movement;
- hard physical strikes; supernatural effects only when story powers require them.

## 3. Speed VFX

For fast action:

- directional motion blur aligned with movement;
- a short trailing silhouette/weapon echo for extreme bursts;
- practical light streaks during whip pans;
- displaced rain/dust/sparks showing the route;
- preserve one sharp anchor: face, weapon, or impact point.

## 4. Spectacle budget

Use a limited number of signature effects per 10–15 seconds. Examples:

- one major wall break;
- one dramatic water fan;
- one strong hero-impact camera accent;
- one unusual overhead or under-object angle.

Too many signature beats flatten hierarchy and increase generation instability.
