# Cinematic Fight Director v4.0 — Public Edition

A clean-room public Skill for writing cinematic fight prompts for Seedance 2.5 and similar video generators.

## What changed versus a generic martial-arts prompt guide

This edition centers the fight on a causal state engine rather than style adjectives or fixed move templates. It adds:

- Action Packet choreography;
- momentum continuity and no-neutral-reset logic;
- impact hierarchy instead of maximum effects on every hit;
- grounded airborne-motion rules;
- multi-enemy Threat Queue state tracking;
- action-axis and screen-direction continuity;
- camera-job grammar;
- environment-as-force-witness rules;
- hyperdense action mode with stability safeguards;
- prompt contracts for short bursts, duels, mobs, weapons and creatures;
- diagnostics that repair one variable family at a time;
- explicit final-state handoff for video extension.

## Recommended use

Install the folder as a Skill directory, then ask for a fight prompt with target model, duration, references, fighters and desired tone. The Skill defaults to a paste-ready prompt and chooses conservative assumptions for minor missing details.

## File map

- `SKILL.md` — entry point and routing logic.
- `references/action-packets.md` — causal choreography engine.
- `references/impact-physics.md` — hit, knockback, airborne and environment physics.
- `references/multi-enemy.md` — one-vs-many threat state machine.
- `references/camera-and-editing.md` — axis, shot jobs, impact punctuation and cut logic.
- `references/style-and-vfx.md` — visual treatment without sacrificing readability.
- `references/prompt-contracts.md` — reusable output contracts.
- `references/diagnostics.md` — failure analysis and minimal repairs.
- `examples/` — original public examples.
- `SOURCES.md` — public research references.
- `tests/selftest.py` — package integrity checks.

## Notes on timing

Seedance 2.5 supports timeline-based prompting, but microsecond or sub-second labels should be treated as authoring intent rather than deterministic frame control. The Skill therefore uses simple top-level time blocks and can describe faster microbeats inside them.
