# Public Research Sources

This package is a clean-room synthesis. The sources below informed compatibility checks and general public action-prompting principles. No source prompt is reproduced in full.

1. ByteDance Seed Team — “One-take Creation, Flexible Referencing: Introducing Seedance 2.5” (2026-07-31)
   - https://seed.bytedance.com/en/blog/one-take-creation-flexible-referencing-introducing-seedance-2-5
   - Used to verify current Seedance 2.5 positioning around 30-second generation, multimodal reference and editing/continuity capabilities.

2. allenGKC/Seedance-2.5 — prompting reference
   - https://github.com/allenGKC/Seedance-2.5/blob/main/skill/seedance-25/references/prompting.md
   - Informed current public guidance on reference assignment, observable endpoints, camera intent, sound intent and continuity-oriented prompting.

3. woodfantasy/Seedance-ShotDesign-Skills — prompt contracts
   - https://github.com/woodfantasy/Seedance-ShotDesign-Skills/blob/main/references/prompt-contracts.md
   - Cross-check for public 2.5 prompt organization: asset roles, concept, timeline, sound and continuity constraints.

4. irenerachel/fight-prompt-director
   - https://github.com/irenerachel/fight-prompt-director
   - Public action-prompt project emphasizing cause/effect exchanges, character-specific motion, spatial direction and continuity.

5. HuyLe82US/awesome-seedance-prompts
   - https://github.com/HuyLe82US/awesome-seedance-prompts
   - Public examples used only to observe common action-video vocabulary and the need to combine choreography, camera and environmental response.

6. whoizerwin/seedance-2.0-skills — camera/reference workflow
   - https://github.com/whoizerwin/seedance-2.0-skills
   - Cross-check for role-based media references, one-take prompting and simple camera movement grammar.

7. imagineVid/Awesome-wan-3-0-prompts-and-skills
   - https://github.com/imagineVid/Awesome-wan-3-0-prompts-and-skills
   - Cross-model public evidence that explicit screen direction, continuity and hit punctuation are useful in dense action prompting.

## Originality note

The example fight scenes, terminology arrangement, diagnostic tables and prose in this package were newly written for this public edition. The supplied source package and the user's reference prompt were analyzed for shortcomings and structural ideas, but their text is not bundled or reproduced here.
