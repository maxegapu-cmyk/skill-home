# 静态检查器说明

`inspect_skill.py` 检查以下内容：

- `SKILL.md` 与 YAML frontmatter 是否可解析。
- `name`、`description` 和 metadata 基础字段是否合法。
- `SKILL.md` 中引用的本地文件是否存在且未逃逸目录。
- 是否存在空目录、危险符号链接、异常大文件或临时文件。
- `tests/scenarios.json` 是否为严格结构，并覆盖六类场景。
- maturity 声明是否与可观察证据相容。

它不检查：

- 模型是否真的按规则执行。
- description 在具体平台上的真实触发率。
- 内容事实是否正确。
- Skill 是否达到“生产级”。

## 依赖

需要 Python 3.10+ 与 PyYAML：

```bash
python -m pip install -r requirements.txt
```

## 退出码

- `0`：没有错误；非严格模式允许警告。
- `1`：发现错误，或严格模式下存在警告。
- `2`：调用方式、依赖或目标路径错误。
