# 文件结构选择

## 最小结构

```text
my-skill/
└── SKILL.md
```

当主流程、边界和自检可以清楚容纳在一个文件中时停止拆分。

## 引用结构

```text
my-skill/
├── SKILL.md
└── references/
    ├── domain-rules.md
    └── special-cases.md
```

满足任一条件时增加 reference：

- 内容只在少数场景需要。
- 长表格或领域知识会干扰主流程。
- 某一专题需要独立维护。

每个 reference 开头写明“何时读取”和“解决什么问题”。

## 脚本结构

```text
my-skill/
├── SKILL.md
└── scripts/
    └── verify_output.py
```

只有当工作满足“确定、重复、程序比自然语言更可靠”时写脚本。脚本应：

- 接受清楚参数。
- 默认只读或写入新位置。
- 对错误返回非零状态。
- 不吞掉异常。
- 输出人能理解的结果。
- 声明依赖和支持环境。

## 资产结构

```text
my-skill/
├── SKILL.md
└── assets/
    └── report-template.md
```

资产是会被复制、填写或直接进入产物的文件。操作说明属于 reference，不属于 asset。

## 混合结构

仅在每类目录都有独立职责时使用。不要为了“完整”创建空目录、占位文件或无效 README。

## 命名

- 目录名使用小写 kebab-case。
- 文件名反映用途，不使用 `misc`、`other`、`final-final`。
- 一个事实只设一个权威位置。
- 避免 reference 互相形成多层跳转；优先由 `SKILL.md` 直接指向。
