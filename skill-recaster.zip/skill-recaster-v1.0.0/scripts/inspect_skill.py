#!/usr/bin/env python3
"""Static, honest inspection for Agent Skill directories.

Checks structure and declared evidence. It does not execute an Agent or certify quality.
Exit codes: 0 clean/warnings, 1 errors (or warnings with --strict), 2 usage/dependency error.
"""
import argparse
import json
import os
import re
import sys
import pathlib
from typing import Any

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML is required. Run: python -m pip install PyYAML>=6.0.2", file=sys.stderr)
    raise SystemExit(2)

NAME_RE = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")
LOCAL_REF_RE = re.compile(r"(?<![A-Za-z0-9_-])((?:references|scripts|assets|tests)/[A-Za-z0-9_.\-/]+)")
REQUIRED_CATEGORIES = {"normal", "missing", "ambiguous", "neighbor", "conflict", "stress"}
VALID_ROUTES = {
    "execute", "assume_or_ask", "disambiguate", "do_not_trigger",
    "surface_conflict", "execute_with_tracking", "stop", "redirect"
}
VALID_MATURITY = {"drafted", "static_ok", "scenario_reviewed", "field_used", "stable-draft"}
TEMP_NAMES = {".ds_store", "thumbs.db", "desktop.ini", "__pycache__", ".pytest_cache"}
MAX_FILE_BYTES = 2_000_000


class Report:
    def __init__(self) -> None:
        self.ok: list[str] = []
        self.warn: list[str] = []
        self.err: list[str] = []

    def add_ok(self, msg: str) -> None: self.ok.append(msg)
    def add_warn(self, msg: str) -> None: self.warn.append(msg)
    def add_err(self, msg: str) -> None: self.err.append(msg)

    def print(self) -> None:
        for msg in self.ok: print(f"[OK] {msg}")
        for msg in self.warn: print(f"[WARN] {msg}")
        for msg in self.err: print(f"[ERROR] {msg}")
        print(f"\nSummary: {len(self.ok)} ok, {len(self.warn)} warnings, {len(self.err)} errors")


def load_skill(path: pathlib.Path, report: Report) -> tuple[dict[str, Any] | None, str]:
    skill_md = path / "SKILL.md"
    if not skill_md.is_file():
        report.add_err("SKILL.md is missing")
        return None, ""
    try:
        with skill_md.open("r", encoding="utf-8", newline="") as handle:
            text = handle.read()
    except UnicodeDecodeError:
        report.add_err("SKILL.md is not valid UTF-8")
        return None, ""
    if not text.startswith("---\n"):
        report.add_err("SKILL.md must start with YAML frontmatter")
        return None, text
    end = text.find("\n---\n", 4)
    if end < 0:
        report.add_err("YAML frontmatter is not closed")
        return None, text
    raw = text[4:end]
    body = text[end + 5:]
    try:
        meta = yaml.safe_load(raw)
    except (yaml.parser.ParserError, yaml.scanner.ScannerError, yaml.constructor.ConstructorError) as exc:
        report.add_err(f"frontmatter YAML cannot be parsed: {exc}")
        return None, body
    if not isinstance(meta, dict):
        report.add_err("frontmatter must be a YAML mapping")
        return None, body
    report.add_ok("SKILL.md and frontmatter parsed")
    return meta, body


def validate_meta(meta: dict[str, Any], report: Report) -> None:
    name = meta.get("name")
    desc = meta.get("description")
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        report.add_err("name must be lowercase kebab-case")
    elif len(name) > 64:
        report.add_err("name exceeds 64 characters")
    else:
        report.add_ok(f"name is valid: {name}")

    if not isinstance(desc, str) or not desc.strip():
        report.add_err("description must be a non-empty string")
    else:
        length = len(desc.strip())
        if length < 60:
            report.add_warn("description may be too vague (under 60 characters)")
        if length > 1200:
            report.add_err("description exceeds 1200 characters")
        if length <= 1200:
            report.add_ok(f"description length accepted: {length}")

    metadata = meta.get("metadata", {})
    if metadata is not None and not isinstance(metadata, dict):
        report.add_err("metadata must be a mapping")
        return
    if isinstance(metadata, dict):
        maturity = metadata.get("maturity")
        if maturity is not None and maturity not in VALID_MATURITY:
            report.add_warn(f"unrecognized maturity label: {maturity}")


def safe_local_ref(ref: str) -> bool:
    p = pathlib.PurePosixPath(ref)
    return not p.is_absolute() and ".." not in p.parts and p.parts[0] in {"references", "scripts", "assets", "tests"}


def validate_refs(root: pathlib.Path, body: str, report: Report) -> None:
    refs = sorted(set(LOCAL_REF_RE.findall(body)))
    for ref in refs:
        cleaned = ref.rstrip(".,;:)]}`\"")
        if not safe_local_ref(cleaned):
            report.add_err(f"unsafe local reference: {cleaned}")
            continue
        target = root / cleaned
        if not target.exists():
            report.add_err(f"referenced path does not exist: {cleaned}")
        else:
            report.add_ok(f"reference exists: {cleaned}")
    if not refs:
        report.add_warn("SKILL.md contains no local conditional references")


def validate_tree(root: pathlib.Path, report: Report) -> None:
    for current, dirs, files in os.walk(root, followlinks=False):
        current_path = pathlib.Path(current)
        for name in list(dirs) + list(files):
            p = current_path / name
            if p.is_symlink():
                report.add_err(f"symbolic link is not allowed: {p.relative_to(root)}")
            if name.lower() in TEMP_NAMES or name.endswith((".tmp", ".bak", "~")):
                report.add_warn(f"temporary/generated artifact present: {p.relative_to(root)}")
        if current_path != root and not dirs and not files:
            report.add_warn(f"empty directory: {current_path.relative_to(root)}")
        for name in files:
            p = current_path / name
            try:
                size = p.stat().st_size
            except OSError as exc:
                report.add_err(f"cannot stat {p.relative_to(root)}: {exc}")
                continue
            if size > MAX_FILE_BYTES:
                report.add_warn(f"large file ({size} bytes): {p.relative_to(root)}")


def validate_scenarios(root: pathlib.Path, report: Report) -> None:
    path = root / "tests" / "scenarios.json"
    if not path.exists():
        report.add_warn("tests/scenarios.json is missing; scenario maturity cannot be claimed")
        return
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        report.add_err(f"scenarios.json cannot be parsed: {exc}")
        return
    if not isinstance(data, dict):
        report.add_err("scenarios.json root must be an object")
        return
    if data.get("schema_version") != 1:
        report.add_err("scenarios.json schema_version must be 1")
    if not isinstance(data.get("skill"), str) or not data["skill"]:
        report.add_err("scenarios.json skill must be a non-empty string")
    cases = data.get("cases")
    if type(cases) is not list or len(cases) == 0:
        report.add_err("scenarios.json cases must be a non-empty array")
        return
    seen_ids: set[str] = set()
    categories: set[str] = set()
    required_fields = {"id", "category", "input", "expected_route", "must", "must_not", "review"}
    for idx, case in enumerate(cases):
        label = f"case #{idx + 1}"
        if not isinstance(case, dict):
            report.add_err(f"{label} must be an object")
            continue
        missing = required_fields - set(case)
        if missing:
            report.add_err(f"{label} missing fields: {sorted(missing)}")
            continue
        cid = case["id"]
        if not isinstance(cid, str) or not cid:
            report.add_err(f"{label} id must be a non-empty string")
        elif cid in seen_ids:
            report.add_err(f"duplicate scenario id: {cid}")
        else:
            seen_ids.add(cid)
        category = case["category"]
        if category not in REQUIRED_CATEGORIES:
            report.add_err(f"{label} category is invalid: {category}")
        else:
            categories.add(category)
        if not isinstance(case["input"], str) or not case["input"].strip():
            report.add_err(f"{label} input must be a non-empty string")
        if case["expected_route"] not in VALID_ROUTES:
            report.add_warn(f"{label} uses custom expected_route: {case['expected_route']}")
        for field in ("must", "must_not", "review"):
            value = case[field]
            if not isinstance(value, list) or any(not isinstance(x, str) for x in value):
                report.add_err(f"{label} {field} must be an array of strings")
    missing_categories = REQUIRED_CATEGORIES - categories
    if missing_categories:
        report.add_err(f"scenario categories missing: {sorted(missing_categories)}")
    else:
        report.add_ok("all six scenario categories are present")
    if not report.err:
        report.add_ok(f"scenario structure is valid: {len(cases)} cases")


def validate_maturity(meta: dict[str, Any], root: pathlib.Path, report: Report) -> None:
    metadata = meta.get("metadata") if isinstance(meta.get("metadata"), dict) else {}
    maturity = str(metadata.get("maturity", "drafted")).lower()
    if maturity in {"scenario_reviewed", "field_used"}:
        evidence = root / "tests" / "runs"
        if not evidence.is_dir() or not any(evidence.iterdir()):
            report.add_err(f"maturity '{maturity}' requires non-empty tests/runs evidence")
    elif maturity == "static_ok":
        report.add_warn("maturity says static_ok; confirm this file was updated after the latest inspection")


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect an Agent Skill directory without certifying behavior")
    parser.add_argument("skill_dir", help="path to the target Skill directory")
    parser.add_argument("--strict", action="store_true", help="treat warnings as failure")
    args = parser.parse_args()
    root = pathlib.Path(args.skill_dir).expanduser().resolve()
    if not root.is_dir():
        print(f"ERROR: not a directory: {root}", file=sys.stderr)
        return 2

    report = Report()
    meta, body = load_skill(root, report)
    if meta is not None:
        validate_meta(meta, report)
        validate_refs(root, body, report)
        validate_scenarios(root, report)
        validate_maturity(meta, root, report)
    validate_tree(root, report)
    report.print()
    return 1 if report.err or (args.strict and report.warn) else 0


if __name__ == "__main__":
    raise SystemExit(main())
