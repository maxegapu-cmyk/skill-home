# Skill Recaster v1.0.0

一个通用的 Agent Skill 设计与重构元技能。它将模糊需求、旧提示词、SOP 或已有 Skill 转换为任务契约清楚、路径可执行、结构适量、边界诚实的 Skill。

## 核心路线

```text
任务契约 → 决策地图 → 行为路径 → 承载结构 → 场景攻防 → 成熟度标注
```

它不依赖“先制造失败”的开发方法，也不依赖冻结蓝图或模板物化。所有正文、脚本、模板和方法均为本项目独立实现。

## 安装

把整个 `skill-recaster` 目录复制到支持 Agent Skills 的项目级或用户级技能目录。不同客户端的技能目录位置可能不同，以实际平台说明为准。

## 使用

典型请求：

- “把这套 SOP 做成一个能长期复用的 Skill。”
- “检查这个 SKILL.md 为什么经常误触发。”
- “把我以前的长提示词重构为 references、scripts 和 assets 合理分工的 Skill。”
- “给这个 Skill 建立六类场景检查，但不要假装已经实测。”

## 静态检查

```bash
python -m pip install -r requirements.txt
python scripts/inspect_skill.py . --strict
```

静态检查不执行模型，不代表行为能力认证。

## 测试

```bash
python -m unittest -v tests.test_inspector
```

## 许可证

MIT。见 `LICENSE`。
