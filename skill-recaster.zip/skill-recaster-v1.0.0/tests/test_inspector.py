import json
import subprocess
import sys
import tempfile
import unittest
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "inspect_skill.py"


class InspectorTests(unittest.TestCase):
    def run_tool(self, target: pathlib.Path):
        return subprocess.run([sys.executable, str(SCRIPT), str(target)], text=True, capture_output=True)

    def test_self_passes(self):
        result = self.run_tool(ROOT)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_bad_yaml_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d)
            (p / "SKILL.md").write_text("---\nname: [broken\n---\nbody", encoding="utf-8")
            result = self.run_tool(p)
            self.assertEqual(result.returncode, 1)
            self.assertIn("cannot be parsed", result.stdout)

    def test_wrong_scenario_types_fail(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d)
            (p / "tests").mkdir()
            (p / "SKILL.md").write_text(
                "---\nname: demo-skill\ndescription: This description is deliberately long enough to pass the minimum static length requirement for testing.\nmetadata:\n  maturity: drafted\n---\nBody",
                encoding="utf-8",
            )
            bad = {"schema_version": 1, "skill": "demo-skill", "cases": [{"id": "x", "category": "normal", "input": 4, "expected_route": "execute", "must": "x", "must_not": [], "review": []}]}
            (p / "tests" / "scenarios.json").write_text(json.dumps(bad), encoding="utf-8")
            result = self.run_tool(p)
            self.assertEqual(result.returncode, 1)
            self.assertIn("input must be a non-empty string", result.stdout)

    def test_fake_maturity_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d)
            (p / "SKILL.md").write_text(
                "---\nname: demo-skill\ndescription: This description is deliberately long enough to pass the minimum static length requirement for testing.\nmetadata:\n  maturity: field_used\n---\nBody",
                encoding="utf-8",
            )
            result = self.run_tool(p)
            self.assertEqual(result.returncode, 1)
            self.assertIn("requires non-empty tests/runs evidence", result.stdout)


if __name__ == "__main__":
    unittest.main()
