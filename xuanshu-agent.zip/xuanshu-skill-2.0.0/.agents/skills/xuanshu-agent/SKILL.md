---
name: xuanshu-agent
description: >-
  Use Xuanshu (玄枢) local metaphysics MCP tools correctly — 110 techniques: Western astrology natal
  chart, solar return, progressions, primary directions, horary, electional 择日, birth-time
  rectification, 八字 bazi, 紫微斗数 ziwei, 大六壬, 奇门遁甲 qimen, 太乙, 金口诀, 六爻, 梅花心易,
  河洛理数, 铁板神数, 塔罗 tarot, 天文地占 geomancy, 老黄历, AstroCartoGraphy, celebrity birth data,
  Chinese esoteric history. Trigger on 起盘 排盘 起课 起卦 算命 推运 看盘 合盘 卜卦 择日 生时校正,
  fortune-telling, divination, chart casting, or any Xuanshu/玄枢 reading. Never hand-calculate.
license: AGPL-3.0-only
dependencies:
  tools:
    - type: mcp
      name: xuanshu
      note: >-
        Local Xuanshu Skill MCP server (Python 3.12 + uv + offline runtime). Register with
        `uv run --directory <repo>/xuanshu-skill xuanshu-skill client config --format codex`
        (see examples/clients/codex.md for the full Codex setup, timeouts, and env whitelist).
---

# Xuanshu Agent Skill (Codex / agentskills.io entry)

Thin client-agnostic contract. The **single policy source** is
[`skills/xuanshu-agent/SKILL.md`](../../../skills/xuanshu-agent/SKILL.md) — read it
(and its `references/`) before deep work. Maintainer/repo law: `AGENTS.md`.

## Non-negotiable rules

1. **Never hand-calculate** any Xuanshu/玄枢 technique (no shell/Python/JS/web formulas, no memorized
   tables). Every 盘/课/卦/运 comes from a `xuanshu` MCP tool call (`xuanshu_astro_chart`,
   `xuanshu_cn_qimen`, `xuanshu_cn_liureng_gods`, …) or the `xuanshu-skill` CLI.
2. **Clarify before calling**: if a result-changing setting is missing (birth/event time, place,
   timezone, gender, house system, 起局方式, 贵人体系, target year), ask the user a short question
   with options first. Tools reject unconfirmed calls with `agent_guidance.required`; after the user
   answers, retry with `agent_confirmed_settings: true` (or `defaults_accepted: true` when they
   accept defaults) plus `clarification_notes`. Never self-confirm; never switch tools to bypass the
   gate. In non-interactive runs (`codex exec`), surface the question as your final answer instead
   of guessing.
3. **Read results only from `export_snapshot.export_text` / `.sections`** — that text is the chart.
   Do not restate numbers that are not in it, and do not invent sections it lacks.
4. If `xuanshu` tools are absent from the tool list: first turn after a cold start may simply be too
   early (Codex waits ~1s for optional servers; the runtime warms in ~45s) — retry next turn. Still
   absent → the server is not configured; point the user at `examples/clients/codex.md`.
5. Errors carry structured recovery: on `details.agent_recovery`, relay `prompt_to_user` verbatim
   and stop. On transport errors, suggest `xuanshu-skill doctor` / `xuanshu-skill selfcheck`.
6. **Compact surface.** Codex gets the 16 facade tools by default (`XUANSHU_MCP_COMPACT=1`); call any technique
   by name via `xuanshu_tool_run(tool_name="qimen", …)` — the catalogue is the `xuanshu://catalog/techniques`
   resource. A missing flat `xuanshu_*` name is not a missing technique.

7. **Plain-language users (小白).** Start with `xuanshu_beginner_guide` → `xuanshu_full_reading` (one-call beginner
   workbook); run `xuanshu_birth_check` before natal readings; gloss jargon with `xuanshu_explain`. Any tool accepts
   `place` (e.g. "湖南长沙") instead of lat/lon/zone.

## Shell-only agents (no MCP)

`codex exec` without MCP, CI bots, plain shell tools: the CLI carries the same contract. Parse **stdout only**
(exactly one JSON document; progress lines and error envelopes go to stderr). On Windows PowerShell 5.1 pass
payloads as `--input` / `--output` files, never through the pipe (it re-encodes bytes and mangles Chinese).

| Need | Command |
| --- | --- |
| Tool names + `aka:` aliases | `xuanshu-skill tool list` |
| What to confirm before a call | `xuanshu-skill agent guidance --tool qimen` |
| Run one technique | `xuanshu-skill tool run qimen --input payload.json --output result.json` |
| Natural-language routing | `xuanshu-skill dispatch --input query.json --output result.json` |
| Beginner guide / birth-time check / one-call reading | `xuanshu guide -q "…"` · `xuanshu birth-check --date … --time … --place …` · `xuanshu reading … --yes` |
| One-command onboarding on a fresh machine | `xuanshu-skill setup --client codex` (`uv run xuanshu-skill setup --client codex` inside a checkout) |

Exit 2 + stderr `code: "agent_guidance.required"` = ask the user with `details.agent_recovery.prompt_to_user`,
then rerun with `agent_confirmed_settings: true` + `clarification_notes` (or `defaults_accepted: true` only when
the user explicitly accepts defaults). Exit 0 with `ok: false` = a real engine error (`error.code`), not a missing
technique. Read results only from `data.export_snapshot.export_text`; quote `data.technique_card` afterwards.
