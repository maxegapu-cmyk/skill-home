# 玄枢 Xuanshu 2.0 · Core

`xuanshu-skill` 是这个仓库真正可运行的核心子项目。它把玄枢 / Xuanshu 的本地算法、AI 导出协议、离线 runtime、MCP 暴露层和本地数据管理统一进一个 Python 包里。

如果根目录 README 讲的是“这个项目是什么”，这里讲的是“这个包具体能做什么”。

## License / 许可证

这个子项目现在采用 `GNU AGPL-3.0-only` 许可证发布。完整文本见 [LICENSE](LICENSE)。

This subproject is distributed under `GNU AGPL-3.0-only`. See [LICENSE](LICENSE) for the full text.

## 2.0 新增

- **精度层**（`xuanshu_skill/precision/`）：离线地名库 `places.py`（GeoNames，约 1.8 万地点，含 IANA 时区）、真太阳时 `solar.py`（Meeus 均时差，±3 秒）、出生时间体检 `birth_check.py`（夏令时缺口 / 重复、固定时区冲突、时辰 / 节气 / 晚子时交界、候选四柱、A/B/C 评级）。所有技法载荷可直接传 `place`，由 `input_normalization._resolve_place_fields` 自动补齐经纬度与时区；28 个本命类技法起盘后自动体检并写入 `warnings`。
- **小白模式**（`xuanshu_skill/beginner/`）：16 类问事分类与技法看点 `matters.py`、问事向导 / 白话解释 / 报告骨架 `guide.py`、215 条术语词典与 27 张方法说明卡（`beginner/data/*.json`）。
- **5 个新门面**：`xuanshu_beginner_guide`、`xuanshu_full_reading`、`xuanshu_birth_check`、`xuanshu_place_lookup`、`xuanshu_explain`；对应 CLI：`xuanshu guide` / `reading` / `birth-check` / `place` / `explain`。
- **runtime 载荷兼容层** `payload_compat.py`：离线 runtime 内部写死的目录、脚本、JVM 属性、身份端点集中于此。

## 新增工程能力

- ken 后端统一（v0.6.0）：奇门 / 太乙 / 金口诀（及三式合一的奇门 + 太乙）由玄枢 `ken` 引擎（`kinqimen` / `kintaiyi` / `kinjinkou`）独占计算，headless JS 仅把 ken 结果重排成 `aiExport.js` section
- headless 引擎对齐（v0.6.2）：统摄法（`tongshefa.js`）与十年大运（`engine/decennials.py`）已与玄枢逐值对齐（京房八宫五行、`Math.round`/`Math.ceil` 一致），对照玄枢 `decennials.test.js` 金标
- tracing：本地 JSONL trace、`trace_id`、`group_id`
- benchmark：`XuanshuBench` 本地评测集
- provenance：知识库与导出协议都带来源字段
- release metadata：`server.json`、SBOM、GitHub release workflow

## 四条命令（v0.38.x）

- `uv run xuanshu-skill setup --client <claude-code|claude-desktop|cursor|vscode|codex|gemini|windsurf|cline|zed>` —— 探网 → 装离线 runtime → 写该客户端配置 → doctor → 回读 → 真起一次 stdio
- `uv run xuanshu-skill client config --format <client>` —— 只生成（不落盘）该客户端的配置块 / 注册命令
- `uv run xuanshu-skill client check` —— 体检本机各客户端**实际写着什么**（占位符、超时、路径、版本漂移）
- `uv run xuanshu-skill doctor --explain` —— 机器可读体检 + 6–10 行人话；`selfcheck` 起一张盘 → 存 → 读回

零安装（无 checkout）把 `uv run xuanshu-skill` 换成 `uvx --from "<发布页 wheel URL>" xuanshu-skill`（见根 README「快速开始」）。

## 其它常用命令

- `uv run xuanshu-skill benchmark run`
- `uv run xuanshu-skill benchmark run --skip-runtime`
- `uv run xuanshu-skill trace latest`
- `uv run xuanshu-skill client openclaw-config --format mcporter`
- `uv run xuanshu-skill client openclaw-check --workspace ~/.openclaw/workspace`

## 这个子项目包含什么

- 离线 runtime 安装与诊断
  - `install`
  - `doctor`
  - `serve`
  - `stop`
- MCP 服务层
  - Streamable HTTP
  - stdio
- JSON-first CLI
  - `tool run`
  - `tool list`，包含每个工具的 `input_contract`
  - `dispatch`
  - `ask`
  - `export registry`
  - `export parse`
  - `knowledge registry`
  - `knowledge read`
- 本地数据管理
  - SQLite
  - JSON artifacts
  - run manifest
  - AI answer write-back
- 结构化报告导出
  - report template
  - JSON / DOCX / PDF artifacts
  - report artifact 回写本地 manifest
- 玄枢 AI 导出协议机器建模
  - export registry
  - export snapshot parsing
  - per-tool `export_snapshot`
  - per-tool `export_format`

## 当前已经接进来的技法

完整双语能力矩阵请看根目录 [README.md](../README.md) 和 [README_EN.md](../README_EN.md)。这里保留运行层视角，强调“你在这个子项目里具体能调什么”。

### 核心星盘与派生盘

- `chart`：标准星盘
- `chart13`：13 宫扩展盘
- `hellen_chart`：希腊星盘
- `guolao_chart`：七政四余盘
- `india_chart`：印度盘
- `relative`：合盘 / 关系盘
- `germany`：量化盘 / 中点盘

### 推运与时运

- `solarreturn`：太阳返照
- `lunarreturn`：月返
- `solararc`：太阳弧推运
- `givenyear`：指定年推运
- `profection`：小限
- `pd`：主限 / 本初方向
- `pdchart`：主限盘
- `zr`：黄道释放
- `firdaria`：法达星限
- `decennials`：十年大运 / 十年星限

推运工具必须带目标输入，不允许只用本命资料直接调用：

- `solarreturn` / `lunarreturn`：本命资料 + `datetime` + `dirZone` + `dirLat` + `dirLon`，输出本命盘和返照盘。
- `givenyear`：本命资料 + 指定年/目标时间 `datetime` + `dir*`，输出本命盘和流年盘。
- `solararc` / `profection`：本命资料 + `datetime` + `dirZone`，输出本命盘和推运盘。
- `pd`：本命资料 + `pdtype` + `pdMethod` + `pdTimeKey` + `pdaspects`，输出真实主限表格。
- `pdchart`：本命资料 + `datetime` + `dirZone` + 主限方法字段，输出主限法盘星体表格和相位。
- `zr` / `firdaria` / `decennials`：本命资料 + 用户是否接受玄枢默认时间轴设置，输出对应时间轴。

完整说明见根目录 [`docs/INPUT_CONTRACTS.md`](../docs/INPUT_CONTRACTS.md)。审计推运类输出时不要只看短预览，因为正文通常先写本命盘，返照盘、推运盘、流年盘或主限表格在后续 section；按 `export_format.sections` 或 [`docs/EXPORT_AUDIT_GUIDE.md`](../docs/EXPORT_AUDIT_GUIDE.md) 检查完整内容。Agent 应先用 `uv run xuanshu-skill agent guidance --tool <tool>` 或 MCP `xuanshu_agent_guidance` 检查必问项，再调用真实工具。

### 中文术数与扩展技法

- `ziwei_birth`：紫微斗数命盘
- `ziwei_rules`：紫微规则库
- `bazi_birth`：八字命盘
- `bazi_direct`：八字直断
- `liureng_gods`：大六壬起课
- `liureng_runyear`：大六壬行年
- `qimen`：奇门遁甲（由玄枢 `ken` 后端 `kinqimen` 计算）
- `taiyi`：太乙神数（由玄枢 `ken` 后端 `kintaiyi` 计算）
- `jinkou`：金口诀（由玄枢 `ken` 后端 `kinjinkou` 计算）
- `tongshefa`：统摄法
- `sanshiunited`：三式合一（聚合 ken 的奇门 + 太乙与大六壬）
- `suzhan`：宿占 / 宿盘
- `sixyao`：六爻 / 易卦
- `otherbu`：西洋游戏 / 占星骰子
- `geomancy`：天文地占（4 母卦 → 16 图形，十二宫图形入宫 + 判官/见证，以起卦时刻确定性起卦）
- `tarot`：塔罗（韦特 78 牌，确定性抽牌 + 牌阵直断 / 细论 / 综合建议）
- `jieqi_year`：全年节气盘
- `nongli_time`：农历换算
- `gua_desc`：卦义说明
- `gua_meiyi`：梅易卦义

### 导出与调度

- `export_registry`：玄枢 AI 导出协议注册表
- `export_parse`：玄枢 AI 导出正文解析器
- `xuanshu_dispatch`：自然语言总调度器

### 玄枢悬浮知识库

- `knowledge_registry`：悬浮知识目录
- `knowledge_read`：悬浮知识读取器

已接入：

- 星盘悬浮：`planet`、`sign`、`house`、`lot`、`aspect`
- 大六壬悬浮：`shen`、`house`
- 奇门悬浮：`stem`、`door`、`star`、`god`

明确排除：

- `fengshui`

## 快速开始

```bash
cd xuanshu-skill
uv sync
uv run xuanshu-skill setup --client cursor   # 换成你的客户端；一条命令装 runtime + 写配置 + 体检 + 真起一次
uv run xuanshu-skill selfcheck               # 活体：起一张盘 → 存 → 读回
uv run xuanshu-skill client check            # 之后任何时候：看各客户端实际写着什么
```

只想手动分步：`install` → `doctor` → `serve`（HTTP）或 `client config --format <client>`（stdio）。

## 最短工作流

### 1. 安装 runtime

```bash
uv run xuanshu-skill install
uv run xuanshu-skill doctor
```

如果你主要是接 OpenClaw / mcporter，也可以直接生成当前路径版配置并做一次最小联通检查：

```bash
uv run xuanshu-skill client openclaw-config --format mcporter
uv run xuanshu-skill client openclaw-check --workspace ~/.openclaw/workspace
```

### 2. 直接让调度器选技法

```bash
echo '{
  "query":"请综合奇门、六壬和星盘分析当前状态",
  "birth":{"date":"1990-01-01","time":"12:00","zone":"8","lat":"31n14","lon":"121e28"},
  "save_result": true
}' | uv run xuanshu-skill ask --stdin
```

### 3. 查看某一次完整记录

```bash
uv run xuanshu-skill memory show <run_id>
```

### 4. 回写 AI 最终回答

```bash
echo '{
  "run_id":"<run_id>",
  "user_question":"我接下来事业走势如何？",
  "ai_answer":"先稳后升，宜先整理资源再扩张。",
  "ai_answer_structured":{"trend":"up_later"}
}' | uv run xuanshu-skill memory answer --stdin
```

### 5. 生成结构化报告

AI 客户端推荐先读取模板，再把自己的分析写回，最后让 Xuanshu Skill 本地渲染文件：

```bash
uv run xuanshu-skill report template --run-id <run_id> --tool chart
uv run xuanshu-skill report render --run-id <run_id> --tool chart --format docx
uv run xuanshu-skill report render --run-id <run_id> --tool chart --format pdf
```

也可以一次性调用某个技法并直接生成报告：

```bash
echo '{"date":"2028-04-06","time":"09:33","zone":"8","lat":"31n13","lon":"121e28"}' \
  | uv run xuanshu-skill report from-tool qimen --stdin --format pdf --question "请生成奇门结构化报告"
```

## 常用命令

### 列出工具

```bash
uv run xuanshu-skill tool list
```

### 直接运行单个方法

```bash
echo '{"date":"1990-01-01","time":"12:00","zone":"8","lat":"31n14","lon":"121e28"}' \
  | uv run xuanshu-skill tool run chart --stdin
```

### 运行本地 Phase 2 技法

```bash
echo '{"taiyin":"巽","taiyang":"坤","shaoyang":"震","shaoyin":"震"}' \
  | uv run xuanshu-skill tool run tongshefa --stdin
```

### 导出 registry

```bash
uv run xuanshu-skill export registry --technique qimen
```

### 解析玄枢 AI 导出正文

```bash
echo '{
  "technique":"qimen",
  "content":"[起盘信息]\n参数\n\n[八宫]\n八宫内容\n\n[演卦]\n演卦内容"
}' | uv run xuanshu-skill export parse --stdin
```

### 读取玄枢悬浮知识

```bash
echo '{"domain":"astro","category":"planet","key":"Sun"}' \
  | uv run xuanshu-skill knowledge read --stdin
```

## 本地记录系统会保存什么

每次 run 会持久化：

- run 元信息
- tool call 记录
- entity 索引
- JSON artifact
- run manifest
- query_text
- user_question
- ai_answer_text
- ai_answer_structured
- report_json / report_docx / report_pdf artifact
- artifact `exists` / `file_size` / `sha256` 元信息，方便确认文件仍可用
- 每条 run 的 `artifact_summary` 会汇总报告数量、类型计数和最新报告路径，AI 客户端不用自己遍历文件列表
- `report render` / `report from-tool` 入参里的 AI 分析会自动写回 `ai_answer_text` / `ai_answer_structured`，后续可按关键词检索

对应管理命令：

- `uv run xuanshu-skill memory query`
- `uv run xuanshu-skill memory query --text "事业走势" --artifact-kind report_pdf`
- `uv run xuanshu-skill memory show <run_id>`
- `uv run xuanshu-skill memory answer --stdin`
- `uv run xuanshu-skill report template --run-id <run_id>`
- `uv run xuanshu-skill report render --run-id <run_id> --format pdf`

## 环境变量

可以复制 `.env.example` 再按需覆盖：

```bash
cp .env.example .env
```

常见项：

- `XUANSHU_SERVER_ROOT`
- `XUANSHU_CHART_SERVER_ROOT`
- `XUANSHU_SKILL_DATA_DIR`
- `XUANSHU_SKILL_DB_PATH`
- `XUANSHU_SKILL_OUTPUT_DIR`
- `XUANSHU_RUNTIME_ROOT`
- `XUANSHU_RUNTIME_MANIFEST_URL`
- `XUANSHU_RUNTIME_RELEASE_REPO`
- `XUANSHU_RUNTIME_PLATFORM`
- `XUANSHU_RUNTIME_START_TIMEOUT_SECONDS`
- `XUANSHU_SKILL_HOST`
- `XUANSHU_SKILL_PORT`

## 相关文档

- [根目录中文首页](../README.md)
- [Root English README](../README_EN.md)
- [客户端配置示例](./examples/clients)
- [Runtime 发布说明](../docs/OFFLINE_RUNTIME_RELEASES.md)
- [算法覆盖矩阵](../docs/ALGORITHM_COVERAGE.md)
