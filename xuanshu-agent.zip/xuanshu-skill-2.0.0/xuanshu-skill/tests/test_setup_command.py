"""`xuanshu-skill setup --client <target>`（v0.38.0 B4）：一条命令接入的行为契约。

**为什么旧检查抓不到**：接入此前是四条命令 + 手动粘配置，没有任何一处验证「客户端将要执行的那条命令
真能起 server」——`client config` 只打印建议、`client check` 只看文件、进程内 MCP 测试绕开 spawn。
本文件锁：步骤顺序固定；第 3 步之前失败 `config_untouched: true`；dry-run 零副作用；幂等；写完回读；
真 stdio 探测数工具；失败包结构化写 stderr、退出码 2。
"""

from __future__ import annotations

from xuanshu_skill.surfaces.mcp_server import COMPACT_SURFACE_TOOL_COUNT
import json
import subprocess
import tarfile
import time
import tomllib
from pathlib import Path

import pytest
from typer.testing import CliRunner

from xuanshu_skill.surfaces import cli as cli_module
from xuanshu_skill.surfaces.cli import _SETUP_STEPS, app

runner = CliRunner()


@pytest.fixture(autouse=True)
def _isolated(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """每个用例自己的 runtime 根 / 数据目录 / 端口；managed 模式（不指向外部服务）；无镜像。"""
    monkeypatch.setenv("XUANSHU_RUNTIME_ROOT", str(tmp_path / "runtime-root"))
    monkeypatch.setenv("XUANSHU_SKILL_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("XUANSHU_RUNTIME_PLATFORM", "darwin-arm64")
    # 没人监听的端口：doctor 报 services:not_running（可接受），而不是把维护机上的真 runtime 当成本用例的
    monkeypatch.setenv("XUANSHU_LOCAL_BACKEND_PORT", "39997")
    monkeypatch.setenv("XUANSHU_LOCAL_CHART_PORT", "39898")
    for name in ("XUANSHU_SERVER_ROOT", "XUANSHU_CHART_SERVER_ROOT", "XUANSHU_RUNTIME_MIRROR", "XUANSHU_PORTS",
                 "XUANSHU_RUNTIME_MANIFEST_URL", "XUANSHU_MCP_COMPACT"):
        monkeypatch.delenv(name, raising=False)


def _run(*args: str):
    return runner.invoke(app, ["setup", *args])


def _stdout_json(result) -> dict:
    assert result.exit_code == 0, f"exit={result.exit_code}\nstdout={result.stdout}\nstderr={result.stderr}"
    return json.loads(result.stdout)


def _stderr_json(result) -> dict:
    """失败包在 stderr（前面还有逐步进度行）。"""
    assert result.exit_code == 2, f"exit={result.exit_code}\nstdout={result.stdout}\nstderr={result.stderr}"
    text = result.stderr
    return json.loads(text[text.index("{"):])


def _fake_archive(tmp_path: Path, *, drop: str | None = None) -> Path:
    """mac 布局的假载荷，manifest 显式写全路径（任何 CI OS 上 doctor 都按 manifest 查文件）。"""
    payload_root = tmp_path / "payload" / "runtime-payload"
    files = {
        "Horosa-Web/start_horosa_local.sh": "#!/usr/bin/env bash\nexit 0\n",
        "Horosa-Web/stop_horosa_local.sh": "#!/usr/bin/env bash\nexit 0\n",
        "xuanshu-core-js/bin/cli.mjs": "export {};\n",
        "runtime/mac/java/bin/java": "",
        "runtime/mac/python/bin/python3": "",
        "runtime/mac/node/bin/node": "",
        "runtime/mac/bundle/astrostudyboot.jar": "",
    }
    for relative, text in files.items():
        if relative == drop:
            continue
        target = payload_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    for directory in ("Horosa-Web/astropy", "Horosa-Web/flatlib-ctrad2/flatlib/resources/swefiles"):
        (payload_root / directory).mkdir(parents=True, exist_ok=True)
    manifest = {
        "version": "1.2.3",
        "platform": "darwin-arm64",
        "services": {"start_script": "Horosa-Web/start_horosa_local.sh", "stop_script": "Horosa-Web/stop_horosa_local.sh"},
        "runtimes": {"python": "runtime/mac/python/bin/python3", "java": "runtime/mac/java/bin/java", "node": "runtime/mac/node/bin/node"},
        "artifacts": {
            "horosa_web_root": "Horosa-Web", "astropy_root": "Horosa-Web/astropy",
            "flatlib_root": "Horosa-Web/flatlib-ctrad2/flatlib",
            "swefiles_root": "Horosa-Web/flatlib-ctrad2/flatlib/resources/swefiles",
            "boot_jar": "runtime/mac/bundle/astrostudyboot.jar", "xuanshu_core_js_root": "xuanshu-core-js",
        },
    }
    (payload_root / "runtime-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    archive = tmp_path / "runtime-payload.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        tar.add(payload_root, arcname="runtime-payload")
    return archive


# ---------------------------------------------------------------- shape


def test_dry_run_touches_nothing_and_reports_every_step(tmp_path: Path) -> None:
    config = tmp_path / "mcp.json"
    report = _stdout_json(_run("--client", "cursor", "--config", str(config), "--dry-run", "--no-probe-network"))

    assert report["ok"] is True and report["dry_run"] is True
    assert list(report["steps"]) == list(_SETUP_STEPS)
    assert not config.exists(), "dry-run 不许落盘"
    assert not (tmp_path / "runtime-root" / "current").exists(), "dry-run 不许装 runtime"
    for name in ("network_probe", "install", "config", "client_check", "stdio_probe"):
        assert report["steps"][name]["skipped"] is True, name
    assert report["steps"]["config"]["path"] == str(config.resolve())
    assert "xuanshu" in report["steps"]["config"]["server_block"]
    assert report["steps"]["doctor"]["advisory"] is True
    assert report["surface"] == "compact" and report["tools"] == COMPACT_SURFACE_TOOL_COUNT


def test_unknown_client_is_rejected_before_anything_happens(tmp_path: Path) -> None:
    config = tmp_path / "mcp.json"
    result = _run("--client", "nope", "--config", str(config), "--no-probe-network")
    assert result.exit_code == 2
    assert not config.exists()


def test_no_write_prints_the_block_and_skips_the_readback(tmp_path: Path) -> None:
    config = tmp_path / "settings.json"
    report = _stdout_json(_run("--client", "zed", "--config", str(config), "--no-write", "--skip-install",
                               "--no-probe-network", "--no-stdio-probe"))
    assert report["steps"]["config"]["skipped"] is True
    assert "xuanshu" in report["steps"]["config"]["server_block"]
    assert report["steps"]["client_check"]["skipped"] is True
    assert not config.exists()


# ---------------------------------------------------------------- the full offline flow


def test_full_offline_flow_is_idempotent(tmp_path: Path) -> None:
    archive = _fake_archive(tmp_path)
    config = tmp_path / "mcp.json"
    args = ("--client", "cursor", "--config", str(config), "--archive", str(archive), "--no-probe-network", "--no-stdio-probe")

    first = _stdout_json(_run(*args))
    assert first["ok"] is True
    assert first["steps"]["network_probe"]["skipped"] is True  # --archive → 不上网
    assert first["steps"]["install"]["changed"] is True
    assert first["steps"]["install"]["version"] == "1.2.3"
    assert first["steps"]["config"]["mode"] == "merge" and first["steps"]["config"]["backup"] is None
    assert first["steps"]["doctor"]["ready"] is True, first["steps"]["doctor"]
    assert first["steps"]["client_check"]["configured"] is True and first["steps"]["client_check"]["problems"] == 0
    written = json.loads(config.read_text(encoding="utf-8"))
    assert "stdio" in written["mcpServers"]["xuanshu"]["args"]
    assert written["mcpServers"]["xuanshu"]["env"] == {"XUANSHU_MCP_COMPACT": "1"}
    first_bytes = config.read_bytes()

    second = _stdout_json(_run(*args))
    assert second["ok"] is True
    assert second["steps"]["install"]["changed"] is False, "同一载荷第二次不该重装"
    assert config.read_bytes() == first_bytes, "第二次写出的配置必须逐字节相同"
    assert config.with_name("mcp.json.xuanshu-bak").exists(), "覆盖前必须备份"
    assert second["steps"]["config"]["backup"].endswith("mcp.json.xuanshu-bak")


def test_merge_keeps_the_users_other_keys(tmp_path: Path) -> None:
    config = tmp_path / "settings.json"
    config.write_text(json.dumps({"theme": "dark", "context_servers": {"other": {"command": "x"}}}), encoding="utf-8")
    _stdout_json(_run("--client", "zed", "--config", str(config), "--skip-install", "--no-probe-network", "--no-stdio-probe"))
    merged = json.loads(config.read_text(encoding="utf-8"))
    assert merged["theme"] == "dark"
    assert set(merged["context_servers"]) == {"other", "xuanshu"}


def test_codex_writes_toml_that_passes_its_own_check(tmp_path: Path) -> None:
    config = tmp_path / "config.toml"
    report = _stdout_json(_run("--client", "codex", "--config", str(config), "--skip-install",
                               "--no-probe-network", "--no-stdio-probe"))
    doc = tomllib.loads(config.read_text(encoding="utf-8"))
    assert doc["mcp_servers"]["xuanshu"]["startup_timeout_sec"] == 120
    assert doc["mcp_servers"]["xuanshu"]["tool_timeout_sec"] == 600
    assert report["steps"]["config"]["written"]["format"] == "toml"
    assert report["steps"]["client_check"]["problems"] == 0


# ---------------------------------------------------------------- failure envelopes


def test_install_failure_leaves_the_config_untouched(tmp_path: Path) -> None:
    config = tmp_path / "mcp.json"
    original = json.dumps({"mcpServers": {"other": {"command": "x"}}, "theme": "dark"}).encode("utf-8")
    config.write_bytes(original)

    result = _run("--client", "cursor", "--config", str(config), "--archive", str(tmp_path / "missing.tar.gz"),
                  "--no-probe-network", "--no-stdio-probe")

    failure = _stderr_json(result)
    assert failure["ok"] is False and failure["step"] == "install"
    assert failure["code"].startswith("runtime."), failure["code"]
    assert failure["config_untouched"] is True and failure["backup_path"] is None
    assert "setup --client cursor" in failure["retry_command"]
    assert list(failure["steps"]) == ["network_probe"], "失败前已完成的步骤原样带上"
    assert config.read_bytes() == original, "第 3 步之前失败，用户配置一个字节都不能动"
    assert result.stdout.strip() == "", "失败包只走 stderr，stdout 保持空（脚本用户按退出码判）"


def test_network_probe_failure_is_fast_and_names_the_way_out(tmp_path: Path) -> None:
    config = tmp_path / "mcp.json"
    started = time.perf_counter()
    result = _run("--client", "cursor", "--config", str(config),
                  "--manifest-url", "http://127.0.0.1:9/runtime-manifest.json", "--no-stdio-probe")
    elapsed = time.perf_counter() - started

    failure = _stderr_json(result)
    assert failure["step"] == "network_probe" and failure["code"] == "setup.network_unreachable"
    assert failure["config_untouched"] is True
    assert "--no-probe-network" in failure["retry_command"]
    assert "XUANSHU_RUNTIME_MIRROR" in failure["details"]["next_action"]
    assert failure["details"]["attempts"] and failure["details"]["attempts"][0]["ok"] is False
    assert elapsed < 30, f"探针必须快（{elapsed:.1f}s）——它存在的意义就是别等下载超时"
    assert not config.exists()


def test_doctor_failure_after_the_write_reports_the_backup(tmp_path: Path) -> None:
    """装上了但载荷缺件 → doctor 不通过 → 失败包要说明配置已写、备份在哪。"""
    archive = _fake_archive(tmp_path, drop="runtime/mac/bundle/astrostudyboot.jar")
    config = tmp_path / "mcp.json"
    config.write_text(json.dumps({"mcpServers": {}}), encoding="utf-8")

    result = _run("--client", "cursor", "--config", str(config), "--archive", str(archive),
                  "--no-probe-network", "--no-stdio-probe")

    failure = _stderr_json(result)
    assert failure["step"] == "doctor" and failure["code"] == "setup.doctor_not_ready"
    assert "missing:boot_jar" in failure["details"]["issues"]
    assert failure["config_untouched"] is False
    assert failure["backup_path"].endswith("mcp.json.xuanshu-bak") and Path(failure["backup_path"]).exists()
    assert "xuanshu" in json.loads(config.read_text(encoding="utf-8"))["mcpServers"]


# ---------------------------------------------------------------- launcher / mirror


def test_uvx_wheel_launcher_honours_the_mirror(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XUANSHU_RUNTIME_MIRROR", "https://mirror.example/gh/")
    config = tmp_path / "mcp.json"
    report = _stdout_json(_run("--client", "cursor", "--config", str(config), "--launcher", "uvx-wheel",
                               "--dry-run", "--no-probe-network"))
    assert report["launcher"]["kind"] == "uvx-wheel"
    assert report["launcher"]["wheel_url"].startswith("https://mirror.example/gh/")
    args = report["steps"]["config"]["server_block"]["xuanshu"]["args"]
    assert "--from" in args and args[args.index("--from") + 1] == report["launcher"]["wheel_url"]
    assert "xuanshu-skill setup --client cursor" in report["recheck_command"] or report["recheck_command"].startswith("xuanshu-skill ")


def test_default_launcher_is_uv_inside_a_checkout_and_uvx_wheel_elsewhere(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    assert cli_module._default_setup_launcher(None) == "uv"
    assert cli_module._default_setup_launcher(tmp_path) == "uvx-wheel"
    monkeypatch.setattr(cli_module, "_package_root", lambda: tmp_path)
    assert cli_module._default_setup_launcher(None) == "uvx-wheel", "wheel 装出来的包旁边没有 pyproject.toml"


# ---------------------------------------------------------------- claude-code scopes


def test_claude_code_project_scope_writes_the_projects_mcp_json(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    report = _stdout_json(_run("--client", "claude-code", "--scope", "project", "--skip-install",
                               "--no-probe-network", "--no-stdio-probe"))
    assert report["config_mode"] == "merge"
    assert Path(report["config_path"]) == (tmp_path / ".mcp.json").resolve()
    written = json.loads((tmp_path / ".mcp.json").read_text(encoding="utf-8"))
    assert "stdio" in written["mcpServers"]["xuanshu"]["args"]
    assert report["steps"]["client_check"]["configured"] is True


def test_claude_code_auto_scope_picks_the_project_file_when_present(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mcp.json").write_text(json.dumps({"mcpServers": {"other": {"command": "x"}}}), encoding="utf-8")
    report = _stdout_json(_run("--client", "claude-code", "--skip-install", "--no-probe-network", "--no-stdio-probe"))
    assert report["config_mode"] == "merge"
    merged = json.loads((tmp_path / ".mcp.json").read_text(encoding="utf-8"))
    assert set(merged["mcpServers"]) == {"other", "xuanshu"}


def test_claude_code_user_scope_runs_claude_mcp_add(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)  # 没有 .mcp.json → auto = user scope
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    fake_claude = tmp_path / "claude"
    real_which = cli_module.shutil.which
    monkeypatch.setattr(cli_module.shutil, "which", lambda name, *a, **k: str(fake_claude) if name == "claude" else real_which(name, *a, **k))
    seen: dict[str, list[str]] = {}

    def fake_add(command: list[str]):
        seen["command"] = command
        # 模拟 claude 把用户级条目写进 ~/.claude.json
        server = command[command.index("--") + 1:]
        (tmp_path / ".claude.json").write_text(
            json.dumps({"mcpServers": {"xuanshu": {"command": server[0], "args": server[1:]}}}), encoding="utf-8"
        )
        return subprocess.CompletedProcess(command, 0, stdout="Added stdio MCP server xuanshu", stderr="")

    monkeypatch.setattr(cli_module, "_claude_mcp_add", fake_add)

    report = _stdout_json(_run("--client", "claude-code", "--skip-install", "--no-probe-network", "--no-stdio-probe"))

    assert report["config_mode"] == "claude-mcp-add"
    assert seen["command"][:6] == [str(fake_claude), "mcp", "add", "--scope", "user", "xuanshu"]
    assert seen["command"][6] == "--" and "stdio" in seen["command"][7:]
    assert report["steps"]["config"]["executed"] is True
    assert report["steps"]["config"]["rollback"] == "claude mcp remove --scope user xuanshu"
    assert report["steps"]["client_check"]["configured"] is True, "回读的是 claude 真写的 ~/.claude.json"


def test_claude_code_without_claude_on_path_prints_the_command(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    real_which = cli_module.shutil.which
    monkeypatch.setattr(cli_module.shutil, "which", lambda name, *a, **k: None if name == "claude" else real_which(name, *a, **k))
    calls: list[list[str]] = []
    monkeypatch.setattr(cli_module, "_claude_mcp_add", lambda command: calls.append(command))

    report = _stdout_json(_run("--client", "claude-code", "--skip-install", "--no-probe-network", "--no-stdio-probe"))

    assert calls == [], "claude 不在 PATH 就绝不能去跑"
    assert report["config_mode"] == "printed"
    assert report["steps"]["config"]["executed"] is False
    assert report["steps"]["config"]["command"].startswith("claude mcp add --scope user xuanshu -- ")
    assert report["steps"]["client_check"]["skipped"] is True
    assert report["next_steps"][0].startswith("先执行：claude mcp add")


# ---------------------------------------------------------------- the real stdio probe


def test_stdio_probe_spawns_the_client_shaped_command_and_counts_tools(tmp_path: Path) -> None:
    """真 spawn：`<uv> run --directory <checkout> xuanshu-skill serve --transport stdio --skip-runtime-start`，
    并读 xuanshu://runtime/status 与宿主比对（v0.38.1 C14）。"""
    config = tmp_path / "mcp.json"
    report = _stdout_json(_run("--client", "cursor", "--config", str(config), "--skip-install", "--no-probe-network"))
    probe = report["steps"]["stdio_probe"]
    assert probe["ok"] is True and probe["tools"] == COMPACT_SURFACE_TOOL_COUNT == probe["expected_tools"], probe
    assert probe["command"].endswith("serve --transport stdio --skip-runtime-start")
    assert probe["server_name"] == "Xuanshu Skill"
    assert probe["env_shape"] == "inherit" and Path(probe["cwd"]).is_dir()
    status = probe["runtime_status"]
    assert isinstance(status, dict) and status["installed"] == report["steps"]["doctor"]["installed"], probe
    assert "runtime_mismatch" not in probe
    assert report["ok"] is True


def test_stdio_probe_failure_carries_the_stderr_tail() -> None:
    import sys

    probe = cli_module._stdio_probe(
        command=sys.executable, args=["-c", "import sys; sys.stderr.write('boom: no such server\\n'); sys.exit(3)"],
        env={"PATH": "/usr/bin"}, timeout=30,
    )
    assert probe["ok"] is False
    assert "boom: no such server" in probe["stderr_tail"]


def test_manifest_probe_handles_file_urls_without_network(tmp_path: Path) -> None:
    manifest = tmp_path / "runtime-manifest.json"
    assert cli_module._probe_manifest_url(manifest.resolve().as_uri())["ok"] is False
    manifest.write_text("{}", encoding="utf-8")
    assert cli_module._probe_manifest_url(manifest.resolve().as_uri())["ok"] is True


# ---------------------------------------------------------------- v0.38.1 C14 / C15


def test_codex_probe_env_is_minimal_and_carries_only_the_configured_xuanshu_vars(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XUANSHU_RUNTIME_ROOT", "/from/shell")
    monkeypatch.setenv("XUANSHU_MCP_TOKEN", "secret")
    codex = cli_module._client_probe_env("codex", {"XUANSHU_RUNTIME_ROOT": "/from/config"})
    assert codex["XUANSHU_RUNTIME_ROOT"] == "/from/config" and "XUANSHU_MCP_TOKEN" not in codex and "PATH" in codex
    inherit = cli_module._client_probe_env("cursor", {"XUANSHU_MCP_COMPACT": "1"})
    assert inherit["XUANSHU_MCP_TOKEN"] == "secret" and inherit["XUANSHU_MCP_COMPACT"] == "1"


def test_runtime_mismatch_is_detected_when_the_server_computes_another_root(tmp_path: Path) -> None:
    """负向对照：Codex 形状的环境里没有 XUANSHU_RUNTIME_ROOT，而宿主用了非默认根 → server 报默认根 → 不一致。"""
    from xuanshu_skill.config import Settings

    settings = Settings(runtime_root=tmp_path / "custom-root", db_path=tmp_path / "m.db", output_dir=tmp_path / "runs")
    probe = {"ok": True, "runtime_status": {"installed": False, "runtime_root": str(tmp_path / "default-root")}}
    detail = cli_module._probe_runtime_mismatch(probe, settings)
    assert detail and "custom-root" in detail and "default-root" in detail
    same = {"ok": True, "runtime_status": {"installed": False, "runtime_root": str(tmp_path / "custom-root")}}
    assert cli_module._probe_runtime_mismatch(same, settings) is None
    assert cli_module._probe_runtime_mismatch({"ok": True, "runtime_status": None}, settings) is None, "老 server 没有该资源 → 不判"


def _fake_wheel_bytes(version: str, *, good: bool = True) -> bytes:
    import io
    import zipfile

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr("xuanshu_skill/__init__.py", "")
        archive.writestr(f"xuanshu_skill-{version}.dist-info/METADATA", f"Name: xuanshu-skill\nVersion: {version if good else '0.0.1'}\n")
    return buffer.getvalue()


def test_cache_wheel_downloads_validates_and_records_a_digest(tmp_path: Path) -> None:
    from xuanshu_skill import __version__

    calls: list[str] = []

    def fetch(url: str, dest: Path) -> None:
        calls.append(url)
        dest.write_bytes(_fake_wheel_bytes(__version__))

    path, warning = cli_module._cache_wheel("https://example.invalid/x.whl", dest_dir=tmp_path, fetch=fetch)
    assert warning is None and path == tmp_path / f"xuanshu_skill-{__version__}-py3-none-any.whl" and path.is_file()
    assert (tmp_path / f"{path.name}.sha256").read_text(encoding="utf-8").split()[1] == path.name
    again, _ = cli_module._cache_wheel("https://example.invalid/x.whl", dest_dir=tmp_path, fetch=fetch)
    assert again == path and calls == ["https://example.invalid/x.whl"], "已有合法缓存不再下载"


def test_cache_wheel_rejects_a_wrong_version_and_falls_back_to_the_url(tmp_path: Path) -> None:
    from xuanshu_skill import __version__

    def fetch(url: str, dest: Path) -> None:
        dest.write_bytes(_fake_wheel_bytes(__version__, good=False))

    path, warning = cli_module._cache_wheel("https://example.invalid/x.whl", dest_dir=tmp_path, fetch=fetch)
    assert path is None and warning and "URL" in warning
    assert not list(tmp_path.glob("*.whl")), "坏文件不留在缓存目录"

    def boom(url: str, dest: Path) -> None:
        raise OSError("offline")

    path, warning = cli_module._cache_wheel("https://example.invalid/x.whl", dest_dir=tmp_path, fetch=boom)
    assert path is None and "offline" in (warning or "")


def test_uvx_wheel_payload_uses_the_cached_wheel_when_given(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(cli_module, "resolve_uvx_command", lambda: ["/opt/uv/bin/uvx"])
    wheel = tmp_path / "xuanshu_skill-x.whl"
    payload, command, _ = cli_module._build_client_config_payload(
        format_name="cursor", skill_root=Path.cwd(), server_name="xuanshu", launcher="uvx-wheel", surface="auto", wheel_source=str(wheel),
    )
    assert command[:3] == ["/opt/uv/bin/uvx", "--from", str(wheel)] and payload["launcher"]["wheel_cached_path"] == str(wheel)
    assert payload["launcher"]["wheel_url"].startswith("https://")



# ---------------------------------------------------------------- Windows: a running xuanshu session holds the venv exe

_WINDOWS_FILE_LOCK_STDERR = (
    "   Building xuanshu-skill @ file:///C:/Users/me/src/xuanshu-skill\n"
    "      Built xuanshu-skill @ file:///C:/Users/me/src/xuanshu-skill\n"
    "error: failed to remove file `C:\\Users\\me\\src\\xuanshu-skill\\.venv\\Lib\\site-packages\\../../Scripts/xuanshu-skill.exe`: "
    "The process cannot access the file because it is being used by another process. (os error 32)\n"
)


def test_probe_stderr_diagnosis_recognises_the_windows_file_lock() -> None:
    """v0.39.0 Windows 维护机：挂着的 xuanshu MCP 会话占着 venv 的 xuanshu-skill.exe，客户端的 `uv run` 同步 venv 删不掉它。"""
    import re

    diagnosis = cli_module._diagnose_probe_stderr(_WINDOWS_FILE_LOCK_STDERR)
    assert diagnosis is not None and diagnosis["cause"] == "windows_file_in_use"
    assert diagnosis["locked_file"] == "C:\\Users\\me\\src\\xuanshu-skill\\.venv\\Scripts\\xuanshu-skill.exe"
    for text in (diagnosis["explanation"], diagnosis["next_action"]):
        assert re.search(r"[\u4e00-\u9fff]", text) and re.search(r"[A-Za-z]{4}", text), f"必须中英双语：{text}"
    localized = _WINDOWS_FILE_LOCK_STDERR.replace(
        "The process cannot access the file because it is being used by another process.", "另一个程序正在使用此文件，进程无法访问。"
    )
    assert cli_module._diagnose_probe_stderr(localized)["cause"] == "windows_file_in_use", "中文 Windows：中间那句本地化，两头不变"
    pyd = "error: failed to remove file `C:\\v\\Lib\\site-packages\\pydantic_core\\_core.pyd`: in use (os error 32)"
    assert cli_module._diagnose_probe_stderr(pyd)["locked_file"].endswith("_core.pyd"), "已加载的扩展模块同理"
    assert cli_module._diagnose_probe_stderr("boom: no such server\n") is None
    assert cli_module._diagnose_probe_stderr("error: failed to remove file `C:\\x.exe`: Access is denied. (os error 5)") is None, "权限/杀软是另一类"
    assert cli_module._diagnose_probe_stderr("") is None


def test_setup_names_the_windows_file_lock_when_the_probe_dies_on_it(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = tmp_path / "mcp.json"
    monkeypatch.setattr(
        cli_module,
        "_stdio_probe",
        lambda **kwargs: {"ok": False, "error": "ExceptionGroup: unhandled errors in a TaskGroup (1 sub-exception)",
                          "stderr_tail": _WINDOWS_FILE_LOCK_STDERR},
    )
    failure = _stderr_json(_run("--client", "cursor", "--config", str(config), "--skip-install", "--no-probe-network"))
    assert failure["step"] == "stdio_probe" and failure["code"] == "setup.stdio_probe_failed"
    diagnosis = failure["details"]["diagnosis"]
    assert diagnosis["cause"] == "windows_file_in_use" and diagnosis["locked_file"].endswith("xuanshu-skill.exe")
    assert failure["message"] == diagnosis["explanation"], "认出来就换成人话，而不是通用那句"
    assert failure["steps"]["stdio_probe"]["diagnosis"] == diagnosis, "步骤记录里也带上（lane 报告读的是它）"
    assert failure["details"]["stderr_tail"] == _WINDOWS_FILE_LOCK_STDERR, "原始 stderr 仍原样保留"
