"""玄枢 2.0 精度层：离线地名库、真太阳时、出生时间体检、地名自动解析进起盘载荷。"""
from __future__ import annotations

from datetime import UTC, datetime

import pytest

from xuanshu_skill.input_normalization import normalize_request_payload
from xuanshu_skill.precision import birth_check, equation_of_time_minutes, lookup_place
from xuanshu_skill.precision.birth_check import minutes_to_shichen_boundary, shichen_index


# ── 均时差：与天文年历对照（±0.3 分钟）──────────────────────────────────────────
@pytest.mark.parametrize(
    ("day", "expected"),
    [("2024-02-11", -14.2), ("2024-05-14", 3.6), ("2024-07-26", -6.5), ("2024-11-03", 16.4), ("2024-12-25", 0.0)],
)
def test_equation_of_time_matches_almanac(day: str, expected: float) -> None:
    value = equation_of_time_minutes(datetime.fromisoformat(f"{day}T12:00:00").replace(tzinfo=UTC))
    assert abs(value - expected) < 0.35, value


# ── 地名库 ──────────────────────────────────────────────────────────────────────
def test_place_lookup_city_with_province() -> None:
    result = lookup_place("湖南长沙")
    assert result["ok"]
    best = result["best"]
    assert best["name"] == "Changsha" and best["province"] == "湖南省"
    assert best["timezone"] == "Asia/Shanghai"
    assert abs(best["lat"] - 28.2) < 0.1 and abs(best["lon"] - 112.97) < 0.1


def test_place_lookup_falls_back_to_parent_city_with_note() -> None:
    result = lookup_place("湖南邵阳隆回")
    assert result["ok"] and result["best"]["name"] == "Shaoyang"
    assert any("隆回" in note for note in result["notes"])
    assert result["best"]["true_solar_uncertainty_minutes"] >= 2


def test_place_lookup_province_only_uses_capital_and_warns() -> None:
    result = lookup_place("湖南")
    assert result["best"]["precision"] == "province"
    assert result["best"]["name"] == "Changsha"
    assert any("省级" in note for note in result["notes"])


@pytest.mark.parametrize(
    ("query", "tz"),
    [("New York", "America/New_York"), ("纽约", "America/New_York"), ("伦敦", "Europe/London"),
     ("台北", "Asia/Taipei"), ("新疆喀什", "Asia/Urumqi"), ("温哥华", "America/Vancouver")],
)
def test_place_lookup_world_and_timezones(query: str, tz: str) -> None:
    result = lookup_place(query)
    assert result["ok"], result
    assert result["best"]["timezone"] == tz


def test_place_lookup_accepts_raw_coordinates() -> None:
    result = lookup_place("28.2, 112.97")
    assert result["ok"] and result["best"]["precision"] == "coordinates"
    assert result["best"]["timezone"] == "Asia/Shanghai"


def test_place_lookup_unknown_place_asks_user() -> None:
    result = lookup_place("某某不存在的地方哈哈")
    assert not result["ok"] and result["ask_user"]


# ── 时辰工具函数 ────────────────────────────────────────────────────────────────
def test_shichen_index_and_boundary() -> None:
    assert shichen_index(23, 30) == 0 and shichen_index(0, 30) == 0 and shichen_index(1, 0) == 1
    assert shichen_index(12, 59) == 6 and shichen_index(13, 0) == 7
    gap, label = minutes_to_shichen_boundary(datetime(2000, 1, 1, 12, 55))
    assert gap == 5 and label == "午时/未时"
    gap, label = minutes_to_shichen_boundary(datetime(2000, 1, 1, 23, 4))
    assert gap == 4 and label == "亥时/子时"


# ── 出生时间体检 ────────────────────────────────────────────────────────────────
def test_lichun_boundary_flags_year_and_month_pillar() -> None:
    report = birth_check(date="1990-02-04", time="10:00", place="北京")
    assert report["reference_pillars"]["year"] == "己巳"  # 立春 10:14 之前
    assert report["grade"] == "C"
    assert any(f["code"] == "jieqi.boundary" and f["level"] == "risk" for f in report["findings"])
    assert any(alt["pillars"]["year"] == "庚午" for alt in report["alternatives"])
    assert report["reference_pillars"]["zodiac_by_lichun"] == "蛇"
    assert report["reference_pillars"]["zodiac_by_lunar_new_year"] == "马"


def test_china_dst_is_applied_and_fixed_zone_mismatch_flagged() -> None:
    report = birth_check(date="1988-07-15", time="14:30", place="湖南长沙", zone="+08:00")
    assert report["utc_offset"] == "+09:00"
    codes = {f["code"] for f in report["findings"]}
    assert {"zone.mismatch", "dst.active"} <= codes
    assert report["payload_fields"]["zone"] == "Asia/Shanghai"
    assert report["true_solar"]["breakdown"]["daylight_saving_minutes"] == -60.0


def test_fixed_zone_can_be_kept_on_request() -> None:
    report = birth_check(date="1991-06-01", time="12:00", place="北京", zone="+08:00", prefer_fixed_zone=True)
    assert report["utc_offset"] == "+08:00"
    assert any(f["code"] == "zone.mismatch" for f in report["findings"])


def test_dst_gap_and_ambiguous_hours() -> None:
    gap = birth_check(date="1988-04-17", time="02:30", place="上海")
    assert any(f["code"] == "dst.gap" for f in gap["findings"])
    ambiguous = birth_check(date="2021-11-07", time="01:30", place="New York")
    assert any(f["code"] == "dst.ambiguous" for f in ambiguous["findings"])


def test_shichen_boundary_offers_candidate_pillars() -> None:
    report = birth_check(date="1995-08-08", time="23:20", place="广东广州")
    assert report["shichen"]["by_true_solar"] == "亥时"
    assert report["shichen"]["by_clock"] == "子时"
    assert any(f["code"] == "shichen.boundary" for f in report["findings"])
    assert report["alternatives"] and report["alternatives"][0]["pillars"]["time"].endswith("子")


def test_late_zi_gives_both_day_pillar_conventions() -> None:
    report = birth_check(date="2000-03-10", time="23:50", lat=31.23, lon=121.47, zone="Asia/Shanghai")
    assert report["shichen"]["by_true_solar"] == "子时"
    assert any(f["code"] == "zi.late" for f in report["findings"])
    days = {report["reference_pillars"]["day"], *(a["pillars"]["day"] for a in report["alternatives"])}
    assert len(days) == 2


def test_clean_birth_gets_grade_a() -> None:
    report = birth_check(date="1995-05-20", time="10:00", place="上海")
    assert report["grade"] == "A", report["findings"]
    assert report["payload_fields"]["lat"] and report["payload_fields"]["zone"] == "Asia/Shanghai"
    assert "出生时间体检" in report["plain_summary"]


def test_missing_place_asks_and_assumes_beijing() -> None:
    report = birth_check(date="1990-05-15", time="14:30")
    assert report["ask_user"]
    assert any(f["code"] == "zone.assumed" for f in report["findings"])


def test_invalid_datetime_is_reported_not_raised() -> None:
    report = birth_check(date="1990-13-45", time="25:99")
    assert not report["ok"] and report["ask_user"]


# ── 起盘载荷：地名自动解析 ─────────────────────────────────────────────────────
def test_normalize_payload_resolves_place_into_coordinates_and_zone() -> None:
    payload = normalize_request_payload({"date": "1988-07-15", "time": "14:30", "place": "湖南长沙", "gender": "女"})
    assert payload["lat"] == "28n12" and payload["lon"] == "112e58"
    assert payload["zone"] == "+09:00"  # 1988 年夏令时，按 Asia/Shanghai 当日折算
    assert payload["pos"] == "长沙" and payload["gender"] == 0
    assert "湖南长沙" in payload["placeResolved"]


def test_normalize_payload_never_overrides_explicit_coordinates() -> None:
    payload = normalize_request_payload({"date": "2000-01-01", "time": "12:00", "zone": "+08:00", "lat": "31n13", "lon": "121e28", "place": "北京"})
    assert payload["lat"] == "31n13" and payload["lon"] == "121e28" and payload["zone"] == "+08:00"
    assert "placeResolved" not in payload


def test_tool_run_appends_precision_warnings() -> None:
    from xuanshu_skill.service import _birth_precision_notes, _place_resolution_notes

    normalized = normalize_request_payload({"date": "1990-02-04", "time": "10:00", "place": "北京"})
    notes = _birth_precision_notes("bazi_birth", normalized)
    assert any("立春" in n for n in notes)
    assert any("候选四柱" in n for n in notes)
    assert _birth_precision_notes("tarot", normalized) == []
    assert _place_resolution_notes(normalized)
