from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from xuanshu_skill import payload_compat as _payload

# 离线 runtime / wheel 的发布仓库（GitHub owner/repo）。这是占位值：把 runtime 包上传到你自己仓库的
# Releases 后改这里，或在用户侧设环境变量 XUANSHU_RUNTIME_RELEASE_REPO=<owner/repo>
# （也可用 XUANSHU_RUNTIME_MANIFEST_URL 直接指向 runtime-manifest.json 的完整地址）。
DEFAULT_RELEASE_REPO = "xuanshu-project/xuanshu-skill"

logger = logging.getLogger(__name__)

# ── env 旗标生命周期注册表（v0.33.0 批 II-1/II-3）────────────────────────────────
# 单一真值源：每个 XUANSHU_* 旗标在此登记生命周期档（stable=文档化用户面 / experimental=试验 /
# internal=构建机·脚本·runtime 机务，用户一般不设 / deprecated=保留但劝退）。前向兼容纪律：
# **未知旗标 warn-and-ignore**（一次性告警，绝不硬拒——codex 0.112.0 因未知 key 硬拒配置直接
# 起不来的反面教材）；只有显式 XUANSHU_STRICT_CONFIG=1 才升级为报错。removed 档=接受并忽略+
# 指路替代（删旗标不删兼容）。
ENV_FLAG_REGISTRY: dict[str, str] = {
    # v0.37.0 运行时安全：mac 启动器的「只杀自己人」补丁开关（设 0 会失去误杀保护），
    # 以及 AppCDS 训练 JVM 的端口（上游硬编码 39997，与别的程序撞车时是静默降级）。
    "XUANSHU_MCP_MAX_CONCURRENT_TOOLS": "stable",
    # 2.0 轻量引擎调度：auto（缺省，完整引擎不可用时回退轻量）| lite | full
    "XUANSHU_ENGINE": "stable",
    "XUANSHU_RUNTIME_LAUNCHER_PATCH": "experimental",
    "XUANSHU_RUNTIME_TRUST_PORTS": "experimental",
    "XUANSHU_PORTS": "stable",
    "XUANSHU_CDS_TRAIN_PORT": "experimental",
    "XUANSHU_STRICT_CONFIG": "stable",
    "XUANSHU_CLARIFY": "stable",
    "XUANSHU_SERVER_ROOT": "stable",
    "XUANSHU_CHART_SERVER_ROOT": "stable",
    "XUANSHU_SKILL_DATA_DIR": "stable",
    "XUANSHU_SKILL_DB_PATH": "stable",
    "XUANSHU_SKILL_OUTPUT_DIR": "stable",
    # v0.40.0 P0：报告类工具 output_path 只许落在输出目录内；本变量（os.pathsep 分隔）加白名单根。
    "XUANSHU_REPORT_OUTPUT_ROOTS": "stable",
    "XUANSHU_RUNTIME_ROOT": "stable",
    "XUANSHU_RUNTIME_MANIFEST_URL": "stable",
    "XUANSHU_RUNTIME_PLATFORM": "stable",
    "XUANSHU_RUNTIME_RELEASE_REPO": "stable",
    "XUANSHU_RUNTIME_MIRROR": "stable",
    # v0.38.0 B6 下载旋钮：慢网 / 企业代理下 120 s 读超时与 3 次重试不够时可调（每个镜像各算一轮）。
    "XUANSHU_RUNTIME_DOWNLOAD_TIMEOUT_SECONDS": "stable",
    "XUANSHU_RUNTIME_DOWNLOAD_ATTEMPTS": "stable",
    "XUANSHU_LOCAL_BACKEND_PORT": "stable",
    "XUANSHU_LOCAL_CHART_PORT": "stable",
    "XUANSHU_RUNTIME_START_TIMEOUT_SECONDS": "stable",
    "XUANSHU_RUNTIME_CALL_WAIT_SECONDS": "stable",
    "XUANSHU_RUNTIME_JAVA_RETRY_COOLDOWN_SECONDS": "stable",
    "XUANSHU_MCP_COMPACT": "stable",
    "XUANSHU_MCP_ELICIT": "stable",
    "XUANSHU_MCP_ELICIT_TIMEOUT_SECONDS": "stable",
    "XUANSHU_MCP_TOKEN": "stable",
    "XUANSHU_MCP_ALLOWED_HOSTS": "stable",
    "XUANSHU_TOOLSETS": "stable",
    "XUANSHU_JS_ENGINE_TIMEOUT_SECONDS": "stable",
    "XUANSHU_SKILL_HOST": "stable",
    "XUANSHU_SKILL_PORT": "stable",
    "XUANSHU_SKILL_LOG_LEVEL": "stable",
    "XUANSHU_TRACE_ENABLED": "stable",
    "XUANSHU_TRACE_DIR": "stable",
    "XUANSHU_TRACE_CAPTURE_PAYLOADS": "stable",
    "XUANSHU_TRACE_CAPTURE_AI_ANSWERS": "stable",
    "XUANSHU_TRACE_OTLP_ENDPOINT": "stable",
    "XUANSHU_TECHNIQUE_CARD": "stable",
    "XUANSHU_OUTPUT_SCHEMA": "stable",
    "XUANSHU_ASTRODATA_DB": "stable",
    "XUANSHU_NODE_BIN": "stable",
    "XUANSHU_CORE_JS_ROOT": "experimental",
    "XUANSHU_UV_BIN": "internal",
    "XUANSHU_UVX_BIN": "internal",
    "XUANSHU_MCPORTER_BIN": "internal",
    _payload.ENV_SERVER_PORT: "internal",
    _payload.ENV_CHART_PORT: "internal",
    "XUANSHU_BACKEND_PORT": "internal",
    "XUANSHU_ROOT": "internal",
    "XUANSHU_LOG_ROOT": "internal",
    "XUANSHU_SOURCE_ROOT": "internal",
    "XUANSHU_WINDOWS_SOURCE_ROOT": "internal",
    "XUANSHU_LINUX_JAVA_HOME": "internal",
    "XUANSHU_LINUX_PYTHON_HOME": "internal",
    "XUANSHU_LINUX_SKIP_DOWNLOAD": "internal",
    "XUANSHU_RUNTIME_RELEASE_BASE_URL": "internal",
    "XUANSHU_SKILL_PYPROJECT": "internal",
    _payload.ENV_LAUNCH_NONCE: "internal",
    # v0.38.1 C7：宿主（Claude Code 插件 / MCPB）告诉我们「你是从哪个目录被启动的」，
    # runtime.not_installed 的修复命令据此写成 `uv run --directory <该目录> …`（用户能直接复制）。
    "XUANSHU_INSTALL_CONTEXT": "stable",
    "XUANSHU_PLUGIN_ROOT": "stable",
    # v0.39.0 可选云端决策层（TypeSafe Jev）：缺省 off = 零字节变化；语义见 decisions/policy.py。
    "XUANSHU_JEV": "experimental",
    "XUANSHU_JEV_API_KEY": "experimental",
    "XUANSHU_JEV_SCOPE": "experimental",
    "XUANSHU_JEV_SURFACES": "experimental",
    "XUANSHU_JEV_MODEL": "experimental",
    "XUANSHU_JEV_BASE_URL": "experimental",
    "XUANSHU_JEV_TIMEOUT_MS": "experimental",
    "XUANSHU_JEV_LEDGER": "experimental",
    "XUANSHU_JEV_LIVE": "internal",
}
# removed 档：曾存在于历史版本、现已删除的旗标 → 接受并忽略 + 指路。删代码不删兼容。
REMOVED_ENV_FLAGS: dict[str, str] = {}

_ENV_AUDIT_DONE = False


def audit_env_flags(*, force: bool = False) -> list[str]:
    """扫描 XUANSHU_* 环境变量：未知 → warn-and-ignore（返回并记日志，进程内只告警一次）；
    XUANSHU_STRICT_CONFIG=1 时未知升级为 ValueError（显式选择加入的严格档）。"""
    global _ENV_AUDIT_DONE
    warnings: list[str] = []
    for key in sorted(os.environ):
        if not key.startswith("XUANSHU_"):
            continue
        if key in ENV_FLAG_REGISTRY:
            continue
        if key in REMOVED_ENV_FLAGS:
            warnings.append(f"环境变量 {key} 已在新版移除：{REMOVED_ENV_FLAGS[key]}（本次忽略）")
            continue
        warnings.append(f"未知环境变量 {key}（拼写有误？或来自更新版本的 skill）——已忽略，不影响运行。")
    if warnings and (os.environ.get("XUANSHU_STRICT_CONFIG", "").strip().lower() in {"1", "true", "yes"}):
        raise ValueError("XUANSHU_STRICT_CONFIG=1：" + "；".join(warnings))
    if warnings and (force or not _ENV_AUDIT_DONE):
        for line in warnings:
            # 启动期环境审计，没有工具调用可告知——不是降级点（verify_silent_degrades 只盯 logger.warning）。
            logger.log(logging.WARNING, "%s", line)
    _ENV_AUDIT_DONE = True
    return warnings


def _default_home_dir() -> Path:
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "XuanshuSkill"
    return Path.home() / ".xuanshu-skill"


DEFAULT_START_TIMEOUT_SECONDS = 45.0
# v0.38.1 R11：仿真宿主（Windows on ARM 跑 x64 载荷 / Rosetta 下的 x64 Python）冷启动实测 59.6 s（真机矩阵 ARM lane），
# 45 s 的出厂预算会让 `selfcheck` / `runtime start` 在健康机器上以 starting 收场。仿真时缺省放大到 120 s；
# 用户显式设 XUANSHU_RUNTIME_START_TIMEOUT_SECONDS 时永远以用户为准。
EMULATED_START_TIMEOUT_SECONDS = 120.0


def _host_runs_emulated() -> bool:
    try:
        from xuanshu_skill.runtime import manager as _manager

        if _manager.arch_report().get("emulated") is True:
            return True
        return _manager._platform_key() in _manager.PLATFORM_FALLBACKS
    except Exception:  # noqa: BLE001 - 探测失败就按原生算，绝不让配置加载失败
        return False


def _default_start_timeout_seconds() -> float:
    return EMULATED_START_TIMEOUT_SECONDS if _host_runs_emulated() else DEFAULT_START_TIMEOUT_SECONDS


def _default_runtime_root() -> Path:
    if os.name == "nt":
        local_appdata = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if local_appdata:
            return Path(local_appdata) / "Xuanshu" / "runtime"
    return Path.home() / ".xuanshu" / "runtime"


# 未展开的模板占位符：`${user_config.runtimeRoot}` / `${CLAUDE_PLUGIN_ROOT}` 这类。
# 🔴 不锚定：`${workspaceFolder}/xuanshu`、`${env:HOME}/.xuanshu` 这种**部分**模板（VS Code / Cline / Zed
# 用户最常写的形状）此前会漏过 `^…$` 的判定，一路走到 ensure_dirs 在 CWD 里 mkdir 出一个名叫
# `${workspaceFolder}` 的真目录。宿主没替换占位符 = 整个值都不能当路径用。
_UNEXPANDED_TEMPLATE = re.compile(r"\$\{[^}]*\}")
_warned_unexpanded: set[str] = set()
# 本进程内见过的未展开占位符：{env 名: 字面量}。doctor 会把它读出来当面告诉用户
# —— 这条通知发生在**任何工具调用之前**（Settings.from_env），没有 envelope 可挂，
# 但它绝不能只活在日志里：宿主没替换占位符时，用户看到的是「装了却全是 not_installed」。
_unexpanded_templates: dict[str, str] = {}


def unexpanded_env_templates() -> dict[str, str]:
    """本进程启动时被当作「未设置」处理的未展开占位符（供 doctor / 诊断输出）。"""
    return dict(_unexpanded_templates)


def _env_text(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return default
    stripped = value.strip()
    if not stripped:
        return default
    if _UNEXPANDED_TEMPLATE.search(stripped):
        # 🔴 宿主没展开占位符时，值是**字面量**而不是路径。照单全收的后果实测过两次：
        # `XUANSHU_RUNTIME_ROOT='${user_config.runtimeRoot}'` → 每个技法工具都回
        # `runtime.not_installed`，而 `Settings.ensure_dirs()` 还会在 CWD 里 mkdir 出一个
        # 名叫 `${user_config.runtimeRoot}` 的真目录（仓里那几个 `${env:HOME:-…}` 目录同族）。
        # 当作未设置 → 回落默认值，是唯一不会把用户目录搞脏的解释。
        _unexpanded_templates[name] = stripped
        if name not in _warned_unexpanded:
            _warned_unexpanded.add(name)
            # 用 logger.log(WARNING) 而非 logger.warning：verify_silent_degrades 把包内的
            # 裸 logger.warning 定义为「只告诉了日志、没告诉调用方」的债。这条是**启动期配置
            # 通知**，那一刻还没有任何工具调用、没有 envelope 可挂；调用方要知道的那一份走
            # `unexpanded_env_templates()` → doctor，比 warnings 列表更早也更该出现在那儿。
            logger.log(
                logging.WARNING,
                "%s 的值是未展开的模板占位符 %r（宿主没有替换它）——按未设置处理，回落默认值。",
                name, stripped,
            )
        return default
    return stripped


def _env_path(name: str, default: Path) -> Path:
    raw_value = _env_text(name)
    if raw_value is None:
        return default
    return Path(raw_value).expanduser()


def _env_int(name: str, default: int, *, minimum: int | None = None, maximum: int | None = None) -> int:
    raw_value = _env_text(name)
    if raw_value is None:
        return default
    try:
        value = int(raw_value)
    except ValueError:
        return default
    if minimum is not None and value < minimum:
        return default
    if maximum is not None and value > maximum:
        return default
    return value


def _env_float(name: str, default: float, *, minimum: float | None = None) -> float:
    raw_value = _env_text(name)
    if raw_value is None:
        return default
    try:
        value = float(raw_value)
    except ValueError:
        return default
    if minimum is not None and value < minimum:
        return default
    return value


def _env_bool(name: str, default: bool) -> bool:
    raw_value = _env_text(name)
    if raw_value is None:
        return default
    normalized = raw_value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    return default


# 自动挑端口的备用区间：默认口被占时从这里往上找。避开常见开发端口（3000/5000/8000/8080）。
_AUTO_BACKEND_BASE = 19999
_AUTO_CHART_BASE = 18899
_AUTO_SPAN = 100


def _auto_ports(runtime_root: Path, backend_default: int, chart_default: int) -> tuple[int, int]:
    """`XUANSHU_PORTS=auto`：挑一对能用的端口。

    顺序：① 注册表里记着的那对（这份 runtime 上次就跑在那儿；正在跑的话必须复用，否则每个新
    客户端都会另起一套）→ ② 默认口若空闲就用默认 → ③ 从备用区间往上探。
    挑出来只是**候选**：`start_local_services` 仍会做归属判定，占着的若不是我们的照样报冲突。
    """
    from xuanshu_skill.runtime.ports import find_free_port, port_bindable

    recorded: dict[str, Any] = {}
    try:
        raw = (runtime_root / "runtime-state.json").read_text(encoding="utf-8")
        state = json.loads(raw)
        if isinstance(state, dict) and isinstance(state.get("ports"), dict):
            recorded = state["ports"]
    except (OSError, ValueError):
        recorded = {}

    def _pick(recorded_key: str, default_port: int, base: int) -> int:
        candidate = recorded.get(recorded_key)
        if isinstance(candidate, int) and 0 < candidate < 65536:
            # 空闲（可重用）或正被占（很可能就是我们上次起的那份）都直接复用。
            return candidate
        if port_bindable(default_port):
            return default_port
        return find_free_port(base, span=_AUTO_SPAN)

    return (
        _pick("backend", backend_default, _AUTO_BACKEND_BASE),
        _pick("chart", chart_default, _AUTO_CHART_BASE),
    )


# 字段 ↔ env 旗标映射（provenance 用；新增 env 驱动字段须同步登记，测试锁步）。
FIELD_ENV_MAP = {
    "server_root": "XUANSHU_SERVER_ROOT",
    "chart_server_root": "XUANSHU_CHART_SERVER_ROOT",
    "data_dir": "XUANSHU_SKILL_DATA_DIR",
    "db_path": "XUANSHU_SKILL_DB_PATH",
    "output_dir": "XUANSHU_SKILL_OUTPUT_DIR",
    "report_output_roots": "XUANSHU_REPORT_OUTPUT_ROOTS",
    "runtime_root": "XUANSHU_RUNTIME_ROOT",
    "runtime_manifest_url": "XUANSHU_RUNTIME_MANIFEST_URL",
    "runtime_platform": "XUANSHU_RUNTIME_PLATFORM",
    "runtime_release_repo": "XUANSHU_RUNTIME_RELEASE_REPO",
    "local_backend_port": "XUANSHU_LOCAL_BACKEND_PORT",
    "local_chart_port": "XUANSHU_LOCAL_CHART_PORT",
    "runtime_start_timeout_seconds": "XUANSHU_RUNTIME_START_TIMEOUT_SECONDS",
    "runtime_download_timeout_seconds": "XUANSHU_RUNTIME_DOWNLOAD_TIMEOUT_SECONDS",
    "runtime_download_attempts": "XUANSHU_RUNTIME_DOWNLOAD_ATTEMPTS",
    "runtime_java_retry_cooldown_seconds": "XUANSHU_RUNTIME_JAVA_RETRY_COOLDOWN_SECONDS",
    "mcp_compact": "XUANSHU_MCP_COMPACT",
    "js_engine_timeout_seconds": "XUANSHU_JS_ENGINE_TIMEOUT_SECONDS",
    "host": "XUANSHU_SKILL_HOST",
    "port": "XUANSHU_SKILL_PORT",
    "log_level": "XUANSHU_SKILL_LOG_LEVEL",
    "trace_enabled": "XUANSHU_TRACE_ENABLED",
    "trace_dir": "XUANSHU_TRACE_DIR",
    "trace_capture_payloads": "XUANSHU_TRACE_CAPTURE_PAYLOADS",
    "trace_capture_ai_answers": "XUANSHU_TRACE_CAPTURE_AI_ANSWERS",
    "trace_otlp_endpoint": "XUANSHU_TRACE_OTLP_ENDPOINT",
}


class Settings(BaseModel):
    server_root: str = Field(default="http://127.0.0.1:9999")
    chart_server_root: str = Field(default="http://127.0.0.1:8899")
    data_dir: Path = Field(default_factory=_default_home_dir)
    runtime_root: Path = Field(default_factory=_default_runtime_root)
    db_path: Path | None = None
    output_dir: Path | None = None
    # 报告类工具 output_path 的额外白名单根（v0.40.0 P0；输出目录恒在白名单内）。
    report_output_roots: list[Path] = Field(default_factory=list)
    runtime_manifest_url: str | None = None
    runtime_platform: str | None = None
    runtime_release_repo: str = DEFAULT_RELEASE_REPO
    local_backend_port: int = 9999
    local_chart_port: int = 8899
    # 冷启动等待：Java(Spring Boot fat jar)+Python(星历重导入) 后端首启常超 15s，45s 覆盖常见机器。
    runtime_start_timeout_seconds: float = 45.0
    # 归档下载：读超时（每块 1 MiB 之间的等待）与每个镜像的重试次数（v0.38.0 B6，此前写死 120 s / 3 次）。
    runtime_download_timeout_seconds: float = 120.0
    runtime_download_attempts: int = 3
    # Java 后端起不来（degraded_chart_only）后的重试冷却：冷却期内碰 Java 的调用快速失败
    # （runtime.java_backend_unavailable），不再为了再试 Java 先杀掉健康的 chart 服务再全量重启；0 = 关闭冷却。
    runtime_java_retry_cooldown_seconds: float = 120.0
    # MCP 精简工具面：True 时只暴露 16 个门面工具（dispatch/guidance/memory/report 等 + 通用直呼
    # xuanshu_tool_run），技法工具不平铺（省 tools/list 上下文预算）；默认 False 保持 97 工具全量平铺。
    mcp_compact: bool = False
    js_engine_timeout_seconds: float = 60.0
    host: str = "127.0.0.1"
    port: int = 8765
    log_level: str = "INFO"
    trace_enabled: bool = True
    trace_dir: Path | None = None
    trace_capture_payloads: bool = False
    trace_capture_ai_answers: bool = False
    trace_otlp_endpoint: str | None = None
    # Settings provenance（v0.33.0 批 II-3）：每字段的取值来源（env:<NAME> / derived:<字段> / default），
    # doctor 三列（字段/值/来源）据此呈现——「这项配置为什么是这个值」一眼可答。exclude 不入序列化。
    settings_provenance: dict[str, str] = Field(default_factory=dict, exclude=True)

    @classmethod
    def from_env(cls) -> "Settings":
        audit_env_flags()
        data_dir = _env_path("XUANSHU_SKILL_DATA_DIR", _default_home_dir())
        runtime_root = _env_path("XUANSHU_RUNTIME_ROOT", _default_runtime_root())
        backend_port = _env_int("XUANSHU_LOCAL_BACKEND_PORT", 9999, minimum=1, maximum=65535)
        chart_port = _env_int("XUANSHU_LOCAL_CHART_PORT", 8899, minimum=1, maximum=65535)
        ports_mode = (_env_text("XUANSHU_PORTS", "") or "").strip().lower()
        if ports_mode == "auto":
            backend_port, chart_port = _auto_ports(runtime_root, backend_port, chart_port)
        # 🔴 URL 必须跟着端口走。旧实现里 server_root 与 local_backend_port 是两个互不相干的字段：
        # 只设 XUANSHU_LOCAL_BACKEND_PORT=19999 时，启动器听 19999，而探针、客户端、doctor 全都还
        # 打 9999 —— 用户「换个端口避开占用」的正常操作，结果是「服务起来了却一个技法都用不了」。
        server_root_env = _env_text("XUANSHU_SERVER_ROOT")
        chart_root_env = _env_text("XUANSHU_CHART_SERVER_ROOT")
        db_path_env = _env_text("XUANSHU_SKILL_DB_PATH")
        output_dir_env = _env_text("XUANSHU_SKILL_OUTPUT_DIR")
        trace_dir_env = _env_text("XUANSHU_TRACE_DIR")
        start_timeout_default_source = (
            "default:emulated_host" if _env_text("XUANSHU_RUNTIME_START_TIMEOUT_SECONDS") is None and _host_runs_emulated() else None
        )
        return cls(
            server_root=server_root_env or f"http://127.0.0.1:{backend_port}",
            chart_server_root=chart_root_env or f"http://127.0.0.1:{chart_port}",
            data_dir=data_dir,
            db_path=Path(db_path_env).expanduser() if db_path_env else data_dir / "memory.db",
            output_dir=Path(output_dir_env).expanduser() if output_dir_env else data_dir / "runs",
            report_output_roots=[Path(p.strip()).expanduser() for p in (_env_text("XUANSHU_REPORT_OUTPUT_ROOTS", "") or "").split(os.pathsep) if p.strip()],
            runtime_root=runtime_root,
            runtime_manifest_url=_env_text("XUANSHU_RUNTIME_MANIFEST_URL"),
            runtime_platform=_env_text("XUANSHU_RUNTIME_PLATFORM"),
            runtime_release_repo=_env_text("XUANSHU_RUNTIME_RELEASE_REPO", DEFAULT_RELEASE_REPO) or DEFAULT_RELEASE_REPO,
            local_backend_port=backend_port,
            local_chart_port=chart_port,
            runtime_start_timeout_seconds=_env_float("XUANSHU_RUNTIME_START_TIMEOUT_SECONDS", _default_start_timeout_seconds(), minimum=0.1),
            runtime_download_timeout_seconds=_env_float("XUANSHU_RUNTIME_DOWNLOAD_TIMEOUT_SECONDS", 120.0, minimum=1.0),
            runtime_download_attempts=_env_int("XUANSHU_RUNTIME_DOWNLOAD_ATTEMPTS", 3, minimum=1, maximum=20),
            runtime_java_retry_cooldown_seconds=_env_float("XUANSHU_RUNTIME_JAVA_RETRY_COOLDOWN_SECONDS", 120.0, minimum=0.0),
            mcp_compact=_env_bool("XUANSHU_MCP_COMPACT", False),
            js_engine_timeout_seconds=_env_float("XUANSHU_JS_ENGINE_TIMEOUT_SECONDS", 60.0, minimum=0.1),
            host=_env_text("XUANSHU_SKILL_HOST", "127.0.0.1") or "127.0.0.1",
            port=_env_int("XUANSHU_SKILL_PORT", 8765, minimum=1, maximum=65535),
            log_level=(_env_text("XUANSHU_SKILL_LOG_LEVEL", "INFO") or "INFO").upper(),
            trace_enabled=_env_bool("XUANSHU_TRACE_ENABLED", True),
            trace_dir=Path(trace_dir_env).expanduser() if trace_dir_env else data_dir / "traces",
            trace_capture_payloads=_env_bool("XUANSHU_TRACE_CAPTURE_PAYLOADS", False),
            trace_capture_ai_answers=_env_bool("XUANSHU_TRACE_CAPTURE_AI_ANSWERS", False),
            trace_otlp_endpoint=_env_text("XUANSHU_TRACE_OTLP_ENDPOINT"),
            settings_provenance={
                field: (f"env:{env_name}" if _env_text(env_name) is not None else (
                    # 三个路径字段无独立 env 时由 data_dir 派生（而非模型默认）
                    "derived:data_dir" if field in {"db_path", "output_dir", "trace_dir"}
                    # 两个 URL 无独立 env 时由端口派生（auto 模式下端口本身也是探出来的）
                    else "derived:local_backend_port" if field == "server_root"
                    else "derived:local_chart_port" if field == "chart_server_root"
                    else "auto:XUANSHU_PORTS" if ports_mode == "auto" and field in {
                        "local_backend_port", "local_chart_port"
                    }
                    else "default"
                ))
                for field, env_name in FIELD_ENV_MAP.items()
            } | ({"runtime_start_timeout_seconds": start_timeout_default_source} if start_timeout_default_source else {}),
        )

    def ensure_dirs(self) -> None:
        # 二次防御：任何一段路径里还留着 `${…}` 就拒绝 mkdir —— 宁可报错，也不在用户的工作目录里
        # 造出字面量目录（v0.37.0 清理过三处 `${env:HOME…}`，同族）。
        for label, path in (("data_dir", self.data_dir), ("runtime_root", self.runtime_root),
                            ("output_dir", self.output_dir), ("trace_dir", self.trace_dir)):
            if path is not None and "${" in str(path):
                from xuanshu_skill.errors import ToolValidationError, bilingual

                raise ToolValidationError(
                    bilingual(
                        f"{label} 里还留着未展开的占位符：{path}",
                        f"{label} still contains an unexpanded placeholder: {path}",
                    ),
                    code="config.unexpanded_template",
                    details={"field": label, "value": str(path),
                             "next_action": "在客户端的扩展设置里填上真实路径，或删掉该环境变量用默认路径。"},
                )
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.runtime_root.mkdir(parents=True, exist_ok=True)
        assert self.db_path is not None
        assert self.output_dir is not None
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        if self.trace_dir is not None:
            self.trace_dir.mkdir(parents=True, exist_ok=True)

    @property
    def runtime_current_dir(self) -> Path:
        return self.runtime_root / "current"

    @property
    def runtime_state_path(self) -> Path:
        return self.runtime_root / "runtime-state.json"

    @property
    def default_runtime_manifest_url(self) -> str:
        return f"https://github.com/{self.runtime_release_repo}/releases/latest/download/runtime-manifest.json"
