"""玄枢 2.0 小白模式：问事向导、白话解释、术语标注、白话报告骨架。

设计原则：
* 用户只需要说人话（「我今年适合换工作吗」「我出生在湖南邵阳」），技术参数由向导补齐或明确追问；
* 每个推荐都说清「为什么用它、它看盘上哪里」，让用户和 AI 都知道结论从哪来；
* 结果解读遵循统一的白话规范：先结论、术语随文解释、有依据、给时间节点和行动建议、说明不确定性。
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Any

from xuanshu_skill.beginner.matters import (
    MATTERS,
    Matter,
    classify_matter,
    focus_points,
    list_matters,
    sixyao_ask_type,
    suggest_mode,
    tools_for,
)

_DATA = Path(__file__).resolve().parent / "data"

BEGINNER_SCHEMA = "xuanshu.skill.beginner_guide.v1"
EXPLAIN_SCHEMA = "xuanshu.skill.explain.v1"
FULL_READING_SCHEMA = "xuanshu.skill.full_reading.v1"

# 白话解读规范：小白模式下 AI 写解读必须遵守（也写进 SKILL.md）。
READING_STYLE_RULES: tuple[str, ...] = (
    "第一句直接回答用户的问题（能/不能、好/一般/需注意、大概什么时候），再展开理由。",
    "每个专业术语第一次出现时，紧跟括号用一句白话解释，例如「七杀（八字里代表压力和挑战的一种力量）」；可直接引用 glossary 里的解释。",
    "每条判断都要指明依据来自盘面的哪一段、哪一项（如「八字[大运]段显示……」），盘上没有的内容不能编。",
    "按『盘面要点 → 分项详解 → 时间节点 → 行动建议 → 注意事项』的顺序写，每部分用小标题，段落要短。",
    "时间节点要具体到年份或月份区间，并说明是从哪个技法的哪一项推出来的。",
    "行动建议给 3–5 条用户今天就能做的具体事情，不要只说「保持积极心态」这类空话。",
    "多个技法结论一致时说明「几种方法都指向……」；不一致时如实列出分歧和可能原因，不要只挑好听的说，也不要取平均。",
    "出生时间体检不是 A 级时，要在开头或结尾说明「哪些结论受出生时间影响、影响多大」。",
    "不用恐吓和宿命论的说法（如克夫、短命、血光之灾、注定离婚），不利的信息用「需要留意……可以这样应对……」的方式表达。",
    "涉及健康、法律、投资、心理危机时，明确建议寻求医生、律师、持牌顾问或专业心理援助，术数只作参考。",
    "最后附「本次用到的术语」小词典，列出解读中出现过的术语及白话解释。",
)

REPORT_SECTIONS: tuple[tuple[str, str], ...] = (
    ("一句话结论", "直接回答用户的问题，一到两句。"),
    ("我们怎么看的", "用了哪几种方法、为什么选它们、各自看盘上的哪里；如有出生时间体检，说明等级。"),
    ("盘面要点", "每个技法 3–5 条最关键的盘面事实，用白话转述并标出处。"),
    ("分项详解", "按本事项的看点逐条展开：盘上是什么 → 意味着什么 → 对用户的问题有什么影响。"),
    ("时间节点", "有利的时间段、需要留意的时间段，具体到年或月，并标明依据。"),
    ("行动建议", "3–5 条具体可执行的建议。"),
    ("注意事项与可信度", "口径差异、出生时间风险、技法分歧、需要寻求专业帮助的地方。"),
    ("本次用到的术语", "术语 + 一句白话解释。"),
)


@lru_cache(maxsize=1)
def load_glossary() -> dict[str, tuple[str, str]]:
    data = json.loads((_DATA / "glossary.json").read_text(encoding="utf-8"))
    return {term: (entry[0], entry[1]) for term, entry in data["terms"].items()}


@lru_cache(maxsize=1)
def load_technique_cards() -> dict[str, dict[str, Any]]:
    data = json.loads((_DATA / "techniques.json").read_text(encoding="utf-8"))
    return dict(data["techniques"])


def _bare_term(term: str) -> str:
    return re.sub(r"（.*?）$", "", term)


@lru_cache(maxsize=1)
def _term_matchers() -> list[tuple[str, str]]:
    """(在正文里匹配用的字面, 词条键)，长词优先；单字词条（合、冲、刑、害、节）不做自动匹配，误报太多。"""
    pairs = []
    for term in load_glossary():
        bare = _bare_term(term)
        if len(bare) >= 2:
            pairs.append((bare, term))
    pairs.sort(key=lambda item: -len(item[0]))
    return pairs


def annotate_terms(text: str, *, limit: int = 40) -> list[dict[str, str]]:
    """找出正文里出现的术语，返回白话解释（按首次出现顺序）。"""
    if not text:
        return []
    glossary = load_glossary()
    found: dict[str, int] = {}
    masked = text
    for literal, term in _term_matchers():
        pos = masked.find(literal)
        if pos >= 0 and term not in found:
            found[term] = pos
            masked = masked.replace(literal, "\u0000" * len(literal))
    ordered = sorted(found.items(), key=lambda item: item[1])[:limit]
    return [{"term": _bare_term(term), "domain": glossary[term][0], "plain": glossary[term][1]} for term, _ in ordered]


def technique_card(tool: str) -> dict[str, Any] | None:
    card = load_technique_cards().get(tool)
    if card is None:
        return None
    from xuanshu_skill.engine.registry import TOOL_DEFINITIONS

    definition = TOOL_DEFINITIONS.get(tool)
    return {"tool": tool, "mcp_name": definition.mcp_name if definition else None, **card}


def explain(query: str | None = None, *, tool: str | None = None, text: str | None = None) -> dict[str, Any]:
    """白话解释：技法（tool 名或中文名）、术语，或一段盘面文字里的全部术语。"""
    result: dict[str, Any] = {"ok": True, "schema": EXPLAIN_SCHEMA}
    cards = load_technique_cards()
    glossary = load_glossary()
    if tool:
        card = technique_card(tool)
        if card is None:
            return {"ok": False, "schema": EXPLAIN_SCHEMA, "reason": "unknown_tool", "available": sorted(cards)}
        result["technique"] = card
        return result
    if text:
        result["terms"] = annotate_terms(text, limit=80)
        return result
    q = (query or "").strip()
    if not q:
        result["techniques"] = [{"tool": k, "name": v["name"], "kind": v["kind"], "one_liner": v["one_liner"]} for k, v in cards.items()]
        result["matters"] = list_matters()
        return result
    for key, card in cards.items():
        if q == key or q in card["name"] or card["name"].split("（")[0] in q:
            result["technique"] = technique_card(key)
            break
    exact = [t for t in glossary if _bare_term(t) == q]
    if exact:
        term = exact[0]
        result["term"] = {"term": _bare_term(term), "domain": glossary[term][0], "plain": glossary[term][1]}
        related = [_bare_term(t) for t in glossary if t != term and glossary[t][0] == glossary[term][0]][:12]
        result["related_terms"] = related
    elif "technique" not in result:
        hits = annotate_terms(q)
        if hits:
            result["terms"] = hits
        else:
            fuzzy = [
                {"term": _bare_term(t), "domain": d, "plain": p}
                for t, (d, p) in glossary.items()
                if any(ch in _bare_term(t) for ch in q if "一" <= ch <= "鿿")
            ][:10]
            result["ok"] = bool(fuzzy)
            result["suggestions"] = fuzzy
            if not fuzzy:
                result["reason"] = "not_found"
    return result


# ── 问事向导 ────────────────────────────────────────────────────────────────────
_SINGLE_DAY_RE = re.compile(r"(今天|明天|后天|这天|当天|\d{4}[-/年]\d{1,2}[-/月]\d{1,2})")


def _has(value: Any) -> bool:
    return value not in (None, "", [], {})


def beginner_guide(
    *,
    question: str | None = None,
    matter: str | None = None,
    mode: str | None = None,
    birth: dict[str, Any] | None = None,
    partner_birth: dict[str, Any] | None = None,
    location: str | None = None,
    max_tools: int = 3,
    available: set[str] | None = None,
) -> dict[str, Any]:
    birth = dict(birth or {})
    has_birth_datetime = _has(birth.get("date")) and _has(birth.get("time"))
    item: Matter = classify_matter(question, matter)
    chosen_mode = mode if mode in {"natal", "event", "date"} else suggest_mode(question, item, has_birth_datetime)
    mode_decided = mode in {"natal", "event", "date"} or item.default_mode in {"natal", "event", "date"} or (
        suggest_mode(question, item, True) == suggest_mode(question, item, False)
    )
    tools = tools_for(item, chosen_mode, max_tools=max_tools)
    if chosen_mode == "date" and question and _SINGLE_DAY_RE.search(question) and "huangli" in item.natal_tools + item.event_tools:
        tools = ["huangli", *[t for t in tools if t != "huangli"]][:max_tools]
    if item.key == "match" and chosen_mode == "natal" and not partner_birth:
        tools = [t for t in tools if t != "relative"] or tools
    limited_note = ""
    if available is not None:
        wanted = list(tools)
        tools = [t for t in tools if t in available]
        fallback = {"event": ("sixyao", "tarot", "xiaoliuren"), "date": ("huangli", "huanglizeri"),
                    "natal": ("bazi_birth", "ziwei_birth", "chart")}[chosen_mode]
        for t in fallback:
            if len(tools) >= max_tools:
                break
            if t in available and t not in tools:
                tools.append(t)
        dropped = [t for t in wanted if t not in tools]
        if dropped:
            names = "、".join((technique_card(t) or {}).get("name", t) for t in dropped)
            limited_note = (f"当前使用轻量引擎（未安装完整离线引擎），{names}暂不可用，已换成可用的方法；"
                            "需要时可运行 uv run xuanshu install 安装完整引擎。")

    missing: list[dict[str, str]] = []
    if chosen_mode == "natal" or (chosen_mode == "date" and item.key == "date"):
        need_birth = chosen_mode == "natal"
        if need_birth:
            if not _has(birth.get("date")):
                missing.append({"field": "birth.date", "ask": "你的公历出生日期是哪天？（如果只记得农历，也可以说农历，我来换算）",
                                "why": "所有命盘都从出生日期起算。"})
            if not _has(birth.get("time")):
                missing.append({"field": "birth.time", "ask": "出生时间大概是几点几分？如果不确定，说个大概范围也行（比如「早上七八点」）。",
                                "why": "出生时间决定时柱、命宫、上升星座，是最影响准确度的一项。"})
            if not (_has(birth.get("place")) or (_has(birth.get("lat")) and _has(birth.get("lon")))):
                missing.append({"field": "birth.place", "ask": "出生在哪个城市？最好具体到区县，海外请写国家和城市。",
                                "why": "出生地决定真太阳时和宫位，偏西的地方可能差一两个时辰。"})
            if any(t in tools for t in ("bazi_birth", "ziwei_birth", "heluo", "tieban")) and not _has(birth.get("gender")):
                missing.append({"field": "birth.gender", "ask": "性别是男还是女？", "why": "八字大运和紫微大限的顺逆排法与性别有关。"})
    if chosen_mode in {"event", "date"} and not _has(question):
        missing.append({"field": "question", "ask": "想问的具体是什么事？请用一句话说清楚，比如「这次去 A 公司的面试能拿到 offer 吗」。",
                        "why": "占卜类方法一事一问，问题越具体越准。"})
    if chosen_mode == "event" and not (_has(location) or _has(birth.get("place")) or (_has(birth.get("lat")) and _has(birth.get("lon")))):
        missing.append({"field": "location", "ask": "你现在人在哪个城市？（起卦用当下所在地的时间）",
                        "why": "六壬、奇门按真太阳时起课，需要知道所在地。"})
    if item.key == "match" and not partner_birth:
        missing.append({"field": "partner_birth", "ask": "对方的出生日期、时间和出生地是？",
                        "why": "合盘需要两个人的出生信息。"})

    recommended = []
    for tool in tools:
        card = technique_card(tool) or {"tool": tool, "name": tool}
        recommended.append({
            "tool": tool,
            "mcp_name": card.get("mcp_name"),
            "name": card.get("name", tool),
            "why": card.get("one_liner", ""),
            "look_at": focus_points(item, tool),
            "needs": card.get("needs", []),
            "beginner_tip": card.get("beginner_tip", ""),
        })

    precision: dict[str, Any] | None = None
    if chosen_mode == "natal" and has_birth_datetime and (_has(birth.get("place")) or (_has(birth.get("lat")) and _has(birth.get("lon")))):
        try:
            from xuanshu_skill.precision.birth_check import birth_check

            precision = birth_check(
                date=str(birth["date"]), time=str(birth["time"]), zone=birth.get("zone"),
                place=birth.get("place"), lat=birth.get("lat"), lon=birth.get("lon"),
            )
        except Exception as exc:  # noqa: BLE001
            precision = {"ok": False, "reason": f"birth_check_failed: {exc}"}

    mode_label = {"natal": "看命盘（长期格局与运程，需要出生信息）", "event": "起卦占问（一件具体的事，用现在的时间起卦）",
                  "date": "择日（挑选办事的日子和时辰）"}[chosen_mode]
    names = "、".join(r["name"] for r in recommended)
    plain = [
        f"你的问题属于「{item.label}」，建议的看法是：{mode_label}。",
        f"推荐用 {names} 一起看，几种方法互相印证会更可靠。",
    ]
    if chosen_mode == "event" and item.natal_tools:
        plain.append("如果你更想知道长期趋势（比如这几年整体怎么样），也可以改成看命盘，需要提供出生信息。")
    if chosen_mode == "natal" and item.event_tools:
        plain.append("如果你问的是眼前某一件具体的事，起卦占问往往更直接。")
    if limited_note:
        plain.append(limited_note)
    plain.extend(item.cautions)

    ready = not missing
    next_step: dict[str, Any] = {
        "tool": "xuanshu_full_reading",
        "ready": ready,
        "payload": {
            "question": question,
            "matter": item.key,
            "mode": chosen_mode,
            "tools": tools,
            "birth": birth or None,
            "partner_birth": partner_birth or None,
            "location": location,
        },
        "note": "补齐 missing 里的信息、并与用户确认使用玄枢默认口径后，带上 defaults_accepted=true 调用一键全面解读。"
        if not ready else "信息已齐。与用户确认使用玄枢默认口径后，带上 defaults_accepted=true 调用一键全面解读。",
    }
    if item.key in {"love"} and chosen_mode == "event":
        ask_type = sixyao_ask_type(item, birth.get("gender"))
        if ask_type:
            next_step["payload"]["sixyao_ask_type"] = ask_type

    return {
        "ok": True,
        "schema": BEGINNER_SCHEMA,
        "matter": {"key": item.key, "label": item.label},
        "mode": chosen_mode,
        "plain_explanation": plain,
        "recommended": recommended,
        "missing_info": missing,
        "ask_user": [m["ask"] for m in missing] + (
            [q for q in item.ask if not (mode_decided and ("看命盘" in q or "起卦" in q))] if not ready else []
        ),
        "birth_precision": precision,
        "next_step": next_step,
        "reading_style": list(READING_STYLE_RULES),
        "all_matters": list_matters(),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }


def report_skeleton(item: Matter, tools: list[str]) -> dict[str, Any]:
    """白话报告骨架：AI 按此结构填写（与 READING_STYLE_RULES 配套）。"""
    return {
        "sections": [{"title": title, "guide": guide, "content": ""} for title, guide in REPORT_SECTIONS],
        "detail_checklist": [
            {"tool": tool, "name": (technique_card(tool) or {}).get("name", tool), "look_at": focus_points(item, tool), "finding": ""}
            for tool in tools
        ],
    }


__all__ = [
    "BEGINNER_SCHEMA",
    "EXPLAIN_SCHEMA",
    "FULL_READING_SCHEMA",
    "MATTERS",
    "READING_STYLE_RULES",
    "REPORT_SECTIONS",
    "annotate_terms",
    "beginner_guide",
    "explain",
    "load_glossary",
    "load_technique_cards",
    "report_skeleton",
    "technique_card",
]
