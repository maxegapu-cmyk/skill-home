"""玄枢 2.0 轻量引擎：不下载离线 runtime 也能用的纯 Python 计算层。

覆盖小白最常用的技法：八字、紫微斗数、西洋本命盘、太阳返照、小限、六爻、小六壬、老黄历、农历换算、出生节气窗。
依赖只有 lunar_python / iztro-py / astronomy-engine（均为 MIT、纯 Python、合计约数 MB）。

调度策略（XUANSHU_ENGINE）：
* auto（缺省）：先走完整引擎；完整引擎不可用（runtime 未安装 / 平台无载荷 / 起不来 / 无 Node）时自动改用轻量引擎；
* lite：一律用轻量引擎（有轻量实现的技法）；
* full：只用完整引擎，不回退。
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any, Callable

from xuanshu_skill.lite import almanac, astro, bazi, liuyao, ziwei

LiteRunner = Callable[[dict[str, Any]], dict[str, Any]]

RUNNERS: dict[str, LiteRunner] = {
    "bazi_birth": bazi.run,
    "bazi_direct": bazi.run,
    "ziwei_birth": ziwei.run,
    "chart": astro.run_chart,
    "solarreturn": astro.run_solarreturn,
    "profection": astro.run_profection,
    "sixyao": liuyao.run,
    "xiaoliuren": almanac.run_xiaoliuren,
    "huangli": almanac.run_huangli,
    "nongli_time": almanac.run_nongli,
    "jieqi_birth": almanac.run_jieqi_birth,
}

# 这些错误码说明「完整引擎此刻不可用」，而不是「输入错了」——只有它们触发回退。
FALLBACK_CODES = frozenset({
    "runtime.not_installed", "runtime.platform_unsupported", "runtime.start_failed", "runtime.start_timeout",
    "runtime.java_backend_unavailable", "runtime.starting", "runtime.start_blocked_quarantine",
    "runtime.start_script_missing", "runtime.path_not_ascii", "runtime.manifest_invalid",
    "transport.connection_error", "js_engine.node_unavailable", "js_engine.cli_missing",
})


def engine_mode() -> str:
    mode = os.environ.get("XUANSHU_ENGINE", "auto").strip().lower()
    return mode if mode in {"auto", "lite", "full"} else "auto"


def has_lite(tool_name: str) -> bool:
    return tool_name in RUNNERS


def should_fallback(code: str | None) -> bool:
    return engine_mode() == "auto" and bool(code) and code in FALLBACK_CODES


def full_runtime_installed(runtime_root: Path | None) -> bool:
    if os.environ.get("XUANSHU_SERVER_ROOT") or os.environ.get("XUANSHU_CHART_SERVER_ROOT"):
        return True  # 网关模式：指向别处的完整引擎
    if runtime_root is None:
        return False
    return (Path(runtime_root) / "current" / "runtime-manifest.json").exists()


def node_available() -> bool:
    override = os.environ.get("XUANSHU_NODE_BIN")
    return bool((override and Path(override).exists()) or shutil.which("node"))


# 不装完整 runtime 时，靠本机 Node 也能跑的 JS 技法（headless 引擎随包分发）
NODE_ONLY_TOOLS = frozenset({
    "tarot", "lingqi", "xiaoliuren", "huangli", "tongshu", "huanglizeri", "bazizeri", "bazi_birth", "bazi_direct",
    "heluo", "canping", "yizhangjing", "tongshefa", "feigong", "xiaochengtu", "guice", "astrodata",
})


def available_tools(runtime_root: Path | None) -> set[str] | None:
    """当前机器上能出结果的技法集合；None 表示完整引擎可用（全部可用）。"""
    if engine_mode() != "lite" and full_runtime_installed(runtime_root):
        return None
    tools = set(RUNNERS)
    if engine_mode() != "lite" and node_available():
        tools |= NODE_ONLY_TOOLS
    return tools


def run(tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    return RUNNERS[tool_name](payload)


__all__ = [
    "FALLBACK_CODES", "NODE_ONLY_TOOLS", "RUNNERS", "available_tools", "engine_mode", "full_runtime_installed",
    "has_lite", "node_available", "run", "should_fallback",
]
