"""轻量引擎 · 六爻纳甲（京房八宫 + 纳甲 + 六亲 + 世应 + 六神 + 旬空 + 月建日辰 + 动变）。

起卦方式：
* 时间起卦（缺省）：梅花易数时间法——(年支数+农历月+农历日) 定上卦、再加时支数定下卦、总数除六余为动爻；
* 报数起卦：nums=[上卦数, 下卦数, 动爻数]（或任意两数 + 时支）；
* 摇卦录入：lines=[初爻…上爻]，每爻 6 老阴（动）/ 7 少阳 / 8 少阴 / 9 老阳（动）。
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from lunar_python import Solar

from xuanshu_skill.lite.common import BRANCHES, build_snapshot, parse_local, table

# 先天八卦数与三爻（自下而上，1=阳）
TRIGRAMS = {
    "乾": (1, 1, 1), "兑": (1, 1, 0), "离": (1, 0, 1), "震": (1, 0, 0),
    "巽": (0, 1, 1), "坎": (0, 1, 0), "艮": (0, 0, 1), "坤": (0, 0, 0),
}
XIANTIAN = ["坤", "乾", "兑", "离", "震", "巽", "坎", "艮"]  # 余数 0→坤(8)，1→乾 … 7→艮
TRIGRAM_IMAGE = {"乾": "天", "兑": "泽", "离": "火", "震": "雷", "巽": "风", "坎": "水", "艮": "山", "坤": "地"}
TRIGRAM_WX = {"乾": "金", "兑": "金", "离": "火", "震": "木", "巽": "木", "坎": "水", "艮": "土", "坤": "土"}
NAJIA = {
    "乾": ("甲子", "甲寅", "甲辰", "壬午", "壬申", "壬戌"),
    "坤": ("乙未", "乙巳", "乙卯", "癸丑", "癸亥", "癸酉"),
    "震": ("庚子", "庚寅", "庚辰", "庚午", "庚申", "庚戌"),
    "巽": ("辛丑", "辛亥", "辛酉", "辛未", "辛巳", "辛卯"),
    "坎": ("戊寅", "戊辰", "戊午", "戊申", "戊戌", "戊子"),
    "离": ("己卯", "己丑", "己亥", "己酉", "己未", "己巳"),
    "艮": ("丙辰", "丙午", "丙申", "丙戌", "丙子", "丙寅"),
    "兑": ("丁巳", "丁卯", "丁丑", "丁亥", "丁酉", "丁未"),
}
GUA_NAMES = {
    "乾": {"乾": "乾为天", "兑": "天泽履", "离": "天火同人", "震": "天雷无妄", "巽": "天风姤", "坎": "天水讼", "艮": "天山遁", "坤": "天地否"},
    "兑": {"乾": "泽天夬", "兑": "兑为泽", "离": "泽火革", "震": "泽雷随", "巽": "泽风大过", "坎": "泽水困", "艮": "泽山咸", "坤": "泽地萃"},
    "离": {"乾": "火天大有", "兑": "火泽睽", "离": "离为火", "震": "火雷噬嗑", "巽": "火风鼎", "坎": "火水未济", "艮": "火山旅", "坤": "火地晋"},
    "震": {"乾": "雷天大壮", "兑": "雷泽归妹", "离": "雷火丰", "震": "震为雷", "巽": "雷风恒", "坎": "雷水解", "艮": "雷山小过", "坤": "雷地豫"},
    "巽": {"乾": "风天小畜", "兑": "风泽中孚", "离": "风火家人", "震": "风雷益", "巽": "巽为风", "坎": "风水涣", "艮": "风山渐", "坤": "风地观"},
    "坎": {"乾": "水天需", "兑": "水泽节", "离": "水火既济", "震": "水雷屯", "巽": "水风井", "坎": "坎为水", "艮": "水山蹇", "坤": "水地比"},
    "艮": {"乾": "山天大畜", "兑": "山泽损", "离": "山火贲", "震": "山雷颐", "巽": "山风蛊", "坎": "山水蒙", "艮": "艮为山", "坤": "山地剥"},
    "坤": {"乾": "地天泰", "兑": "地泽临", "离": "地火明夷", "震": "地雷复", "巽": "地风升", "坎": "地水师", "艮": "地山谦", "坤": "坤为地"},
}
BRANCH_WX = {"子": "水", "丑": "土", "寅": "木", "卯": "木", "辰": "土", "巳": "火", "午": "火", "未": "土", "申": "金", "酉": "金", "戌": "土", "亥": "水"}
GEN = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}
CTRL = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}
LIUSHEN = ["青龙", "朱雀", "勾陈", "螣蛇", "白虎", "玄武"]
LIUSHEN_START = {"甲": 0, "乙": 0, "丙": 1, "丁": 1, "戊": 2, "己": 3, "庚": 4, "辛": 4, "壬": 5, "癸": 5}
POS_NAMES = ["初爻", "二爻", "三爻", "四爻", "五爻", "上爻"]
SHI_POS = [6, 1, 2, 3, 4, 5, 4, 3]  # 本宫、一世…五世、游魂、归魂
STAGE = ["本宫卦（六冲之本）", "一世卦", "二世卦", "三世卦", "四世卦", "五世卦", "游魂卦", "归魂卦"]

ASK_YONG = {
    "career": ("官鬼", "求职、升迁、功名以官鬼为用神"), "wealth": ("妻财", "求财以妻财为用神"),
    "study": ("父母", "考试、文书、证件以父母为用神"), "home": ("父母", "房屋、家宅以父母为用神"),
    "illness": ("官鬼", "病情以官鬼为病，子孙为医药"), "marriage_m": ("妻财", "男问女以妻财为用神"),
    "marriage_f": ("官鬼", "女问男以官鬼为用神"), "lost": ("妻财", "失物多以妻财为用神"),
    "lawsuit": ("官鬼", "官司以官鬼为官府，世为我、应为对方"), "children": ("子孙", "子女以子孙为用神"),
    "parents": ("父母", "父母以父母爻为用神"), "sibling": ("兄弟", "兄弟朋友以兄弟为用神"),
}


def _palace_table() -> dict[tuple[int, ...], tuple[str, int]]:
    """六十四卦 → (所属宫, 第几变)。按京房八宫：自初爻起逐爻变至五爻，游魂变回四爻，归魂内卦复本宫。"""
    out: dict[tuple[int, ...], tuple[str, int]] = {}
    for name, tri in TRIGRAMS.items():
        lines = list(tri + tri)
        out[tuple(lines)] = (name, 0)
        cur = lines[:]
        for k in range(5):
            cur[k] ^= 1
            out[tuple(cur)] = (name, k + 1)
        you = cur[:]
        you[3] ^= 1
        out[tuple(you)] = (name, 6)
        gui = you[:]
        gui[0:3] = list(tri)
        out[tuple(gui)] = (name, 7)
    return out


PALACE = _palace_table()


def _tri_of(bits: tuple[int, int, int]) -> str:
    return next(k for k, v in TRIGRAMS.items() if v == bits)


def liuqin(gong_wx: str, line_wx: str) -> str:
    if line_wx == gong_wx:
        return "兄弟"
    if GEN[line_wx] == gong_wx:
        return "父母"
    if GEN[gong_wx] == line_wx:
        return "子孙"
    if CTRL[gong_wx] == line_wx:
        return "妻财"
    return "官鬼"


def wangshuai(month_branch: str, line_branch: str) -> str:
    m, x = BRANCH_WX[month_branch], BRANCH_WX[line_branch]
    if m == x:
        return "旺"
    if GEN[m] == x:
        return "相"
    if GEN[x] == m:
        return "休"
    if CTRL[x] == m:
        return "囚"
    return "死"


def _clash(a: str, b: str) -> bool:
    return (BRANCHES.index(a) - BRANCHES.index(b)) % 12 == 6


def describe(bits: list[int]) -> dict[str, Any]:
    lower, upper = _tri_of(tuple(bits[0:3])), _tri_of(tuple(bits[3:6]))
    gong, stage = PALACE[tuple(bits)]
    najia = NAJIA[lower][0:3] + NAJIA[upper][3:6]
    shi = SHI_POS[stage]
    ying = (shi + 2) % 6 + 1
    return {"name": GUA_NAMES[upper][lower], "upper": upper, "lower": lower, "gong": gong, "gong_wx": TRIGRAM_WX[gong],
            "stage": STAGE[stage], "najia": najia, "shi": shi, "ying": ying}


def cast(inp: dict[str, Any]) -> dict[str, Any]:
    lines_in = inp.get("lines") or inp.get("yao")
    when = parse_local(inp.get("date") or datetime.now().strftime("%Y-%m-%d"), inp.get("time") or datetime.now().strftime("%H:%M"))
    lunar = Solar.fromYmdHms(when.year, when.month, when.day, when.hour, when.minute, 0).getLunar()
    if isinstance(lines_in, (list, tuple)) and len(lines_in) == 6 and all(str(x) in {"6", "7", "8", "9"} for x in lines_in):
        vals = [int(x) for x in lines_in]
        bits = [1 if v in (7, 9) else 0 for v in vals]
        moving = [i for i, v in enumerate(vals) if v in (6, 9)]
        how = "摇卦录入（自初爻至上爻）：" + " ".join(str(v) for v in vals)
    else:
        nums = inp.get("nums")
        year_no = BRANCHES.index(lunar.getYearZhiExact()) + 1
        time_no = BRANCHES.index(lunar.getTimeZhi()) + 1
        if isinstance(nums, (list, tuple)) and len(nums) >= 2 and all(str(n).isdigit() for n in nums[:3]):
            a, b = int(nums[0]), int(nums[1])
            c = int(nums[2]) if len(nums) > 2 else a + b + time_no
            how = f"报数起卦：{a}、{b}" + (f"、{nums[2]}" if len(nums) > 2 else f"（动爻加时支数 {time_no}）")
        else:
            a = year_no + abs(lunar.getMonth()) + lunar.getDay()
            b = a + time_no
            c = b
            how = (f"时间起卦：农历{lunar.getYearZhiExact()}年({year_no}) {abs(lunar.getMonth())}月 {lunar.getDay()}日 "
                   f"{lunar.getTimeZhi()}时({time_no})；上卦数 {a}，下卦数 {b}，动爻数 {c}")
        up, low = XIANTIAN[a % 8], XIANTIAN[b % 8]
        bits = list(TRIGRAMS[low] + TRIGRAMS[up])
        moving = [(c - 1) % 6]
    ec = lunar.getEightChar()
    return {"bits": bits, "moving": moving, "how": how, "when": when, "lunar": lunar,
            "month_gz": lunar.getMonthInGanZhiExact(), "day_gz": lunar.getDayInGanZhi(), "xunkong": ec.getDayXunKong(),
            "year_gz": lunar.getYearInGanZhiExact(), "time_gz": lunar.getTimeInGanZhi()}


def run(inp: dict[str, Any]) -> dict[str, Any]:
    c = cast(inp)
    bits, moving = c["bits"], c["moving"]
    ben = describe(bits)
    changed_bits = [b ^ 1 if i in moving else b for i, b in enumerate(bits)]
    bian = describe(changed_bits) if moving else None
    hu_bits = bits[1:4] + bits[2:5]
    hu = GUA_NAMES[_tri_of(tuple(hu_bits[3:6]))][_tri_of(tuple(hu_bits[0:3]))]
    month_b, day_gz = c["month_gz"][1], c["day_gz"]
    day_s, day_b = day_gz[0], day_gz[1]
    start = LIUSHEN_START[day_s]
    question = inp.get("question") or inp.get("askEvent") or ""
    ask_type = str(inp.get("askType") or "")

    rows, lines_data = [], []
    for i in range(6):
        gz = ben["najia"][i]
        br = gz[1]
        qin = liuqin(ben["gong_wx"], BRANCH_WX[br])
        mark = "世" if ben["shi"] == i + 1 else ("应" if ben["ying"] == i + 1 else "")
        status = [wangshuai(month_b, br)]
        if _clash(month_b, br):
            status.append("月破")
        if br in c["xunkong"]:
            status.append("旬空")
        if _clash(day_b, br):
            status.append("日冲" + ("（暗动）" if i not in moving else ""))
        if br == day_b:
            status.append("临日")
        change = ""
        if i in moving and bian:
            cgz = bian["najia"][i]
            cqin = liuqin(ben["gong_wx"], BRANCH_WX[cgz[1]])
            rel = ""
            if GEN[BRANCH_WX[cgz[1]]] == BRANCH_WX[br]:
                rel = "回头生"
            elif CTRL[BRANCH_WX[cgz[1]]] == BRANCH_WX[br]:
                rel = "回头克"
            elif _clash(cgz[1], br):
                rel = "化冲"
            change = f"→ {cqin}{cgz}{'（' + rel + '）' if rel else ''}"
        symbol = ("⚊" if bits[i] else "⚋") + ("○" if bits[i] and i in moving else "×" if i in moving else "")
        lines_data.append({"pos": i + 1, "branch": br, "liuqin": qin, "moving": i in moving, "status": status})
        rows.append([POS_NAMES[i], LIUSHEN[(start + i) % 6], symbol, f"{qin}{gz}{BRANCH_WX[br]}", mark, "、".join(status), change])
    rows.reverse()

    sections: list[tuple[str, str]] = []
    sections.append(("起卦信息", "\n".join([
        f"所问：{question or '（未说明）'}",
        c["how"],
        f"起卦时间：{c['when']:%Y-%m-%d %H:%M}　干支：{c['year_gz']}年 {c['month_gz']}月 {c['day_gz']}日 {c['time_gz']}时",
        f"月建：{month_b}　日辰：{day_b}　旬空：{c['xunkong']}",
    ])))
    gua_lines = [
        f"本卦：{ben['name']}（{ben['gong']}宫·{ben['gong_wx']}，{ben['stage']}，上{ben['upper']}{TRIGRAM_IMAGE[ben['upper']]}下{ben['lower']}{TRIGRAM_IMAGE[ben['lower']]}）",
        f"互卦：{hu}",
        f"变卦：{bian['name']}（{bian['gong']}宫）" if bian else "变卦：无（静卦）",
        "动爻：" + ("、".join(POS_NAMES[i] for i in moving) if moving else "无"),
        f"世爻在{POS_NAMES[ben['shi'] - 1]}，应爻在{POS_NAMES[ben['ying'] - 1]}",
    ]
    sections.append(("卦象", "\n".join(gua_lines)))
    sections.append(("六爻排盘", table(["爻位", "六神", "爻象", "六亲纳甲", "世应", "旺衰与状态", "动变"], rows)
                     + "\n爻象：⚊ 阳爻 ⚋ 阴爻；○ 老阳动、× 老阴动。旺衰按月建：旺 > 相 > 休 > 囚 > 死。"))

    yong, why = ASK_YONG.get(ask_type, ("世爻", "未指定事项时以世爻（自己）为主，结合所问取用神"))
    analysis = [f"用神：{yong}（{why}）"]
    targets = [d for d in lines_data if (d["pos"] == ben["shi"] if yong == "世爻" else d["liuqin"] == yong)]
    if not targets and yong != "世爻":
        analysis.append(f"卦中不见{yong}，用神伏藏，需看伏神（轻量引擎未展开伏神，可安装完整引擎查看）。")
    for d in targets:
        analysis.append(f"{POS_NAMES[d['pos'] - 1]}{d['liuqin']}{d['branch']}：{'、'.join(d['status'])}" + ("，发动" if d["moving"] else "，安静"))
    shi = next(d for d in lines_data if d["pos"] == ben["shi"])
    analysis.append(f"世爻（自己）{POS_NAMES[shi['pos'] - 1]}{shi['liuqin']}{shi['branch']}：{'、'.join(shi['status'])}")
    hints = ["断卦要点：用神旺相、不空不破、得日月生扶为吉；用神休囚、旬空、月破、被动爻克为凶；"
             "动爻化回头生主转好，化回头克主反复或落空；旬空之爻出空（逢冲或到该地支的日子）时应验。"]
    sections.append(("用神分析", "\n".join(analysis)))
    sections.append(("断卦提示", "\n".join(hints)))
    data = {"ben": ben["name"], "bian": bian["name"] if bian else None, "moving": [i + 1 for i in moving], "lines": lines_data}
    return build_snapshot("sixyao", "六爻", sections, data)


__all__ = ["PALACE", "cast", "describe", "liuqin", "run"]
