"""轻量引擎 · 黄历 / 农历换算 / 出生节气窗 / 小六壬（lunar_python）。"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from lunar_python import Solar

from xuanshu_skill.lite.common import BRANCHES, build_snapshot, parse_local, resolve_moment, table

BEIJING = timezone(timedelta(hours=8))


def _lunar(dt: datetime):
    return Solar.fromYmdHms(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second).getLunar()


def run_huangli(inp: dict[str, Any]) -> dict[str, Any]:
    day = parse_local(inp.get("date"), "12:00")
    lunar = _lunar(day)
    sections = [
        ("日期", "\n".join([
            f"公历：{day:%Y-%m-%d}　星期{'一二三四五六日'[day.weekday()]}",
            f"农历：{lunar.toString()}",
            f"干支：{lunar.getYearInGanZhiExact()}年 {lunar.getMonthInGanZhiExact()}月 {lunar.getDayInGanZhi()}日",
            f"生肖：{lunar.getYearShengXiaoExact()}　节气：{lunar.getJieQi() or '（非交节日）'}　月相：{lunar.getYueXiang()}",
        ])),
        ("今日宜忌", f"宜：{'、'.join(lunar.getDayYi()) or '诸事不宜'}\n忌：{'、'.join(lunar.getDayJi()) or '无'}"),
        ("值神值宿", "\n".join([
            f"建除十二神：{lunar.getZhiXing()}",
            f"黄道黑道：{lunar.getDayTianShen()}（{lunar.getDayTianShenType()}·{lunar.getDayTianShenLuck()}）",
            f"二十八宿：{lunar.getXiu()}{lunar.getZheng()}{lunar.getAnimal()}（{lunar.getXiuLuck()}）",
        ])),
        ("冲煞·胎神·方位", "\n".join([
            f"冲煞：冲{lunar.getDayChongDesc()}，煞{lunar.getDaySha()}",
            f"胎神：{lunar.getDayPositionTai()}",
            f"喜神：{lunar.getDayPositionXiDesc()}　福神：{lunar.getDayPositionFuDesc()}　财神：{lunar.getDayPositionCaiDesc()}",
        ])),
        ("彭祖百忌", f"{lunar.getPengZuGan()}　{lunar.getPengZuZhi()}"),
        ("吉神凶煞", f"吉神宜趋：{'、'.join(lunar.getDayJiShen()) or '无'}\n凶煞宜忌：{'、'.join(lunar.getDayXiongSha()) or '无'}"),
    ]
    rows = []
    for t in lunar.getTimes()[:12]:
        rows.append([t.getZhi() + "时", f"{t.getMinHm()}–{t.getMaxHm()}", t.getGanZhi(), f"{t.getTianShen()}（{t.getTianShenLuck()}）",
                     f"冲{t.getChongDesc()}"])
    sections.append(("时辰吉凶", table(["时辰", "时间", "干支", "值神", "冲"], rows)))
    return build_snapshot("huangli", "老黄历", sections, {"date": f"{day:%Y-%m-%d}"})


def run_nongli(inp: dict[str, Any]) -> dict[str, Any]:
    m = resolve_moment(inp, use_true_solar=False)
    lunar = _lunar(m["civil"])
    ec = lunar.getEightChar()
    sections = [("农历换算", "\n".join([
        f"公历：{m['civil']:%Y-%m-%d %H:%M}",
        f"农历：{lunar.toString()}{'（闰月）' if lunar.getMonth() < 0 else ''}",
        f"干支：{ec.getYear()}年 {ec.getMonth()}月 {ec.getDay()}日 {ec.getTime()}时",
        f"生肖：{lunar.getYearShengXiaoExact()}（立春换年）／{lunar.getYearShengXiao()}（春节换年）",
        f"星座：{lunar.getSolar().getXingZuo()}座",
    ]))]
    return build_snapshot("nongli_time", "农历时间", sections)


def run_jieqi_birth(inp: dict[str, Any]) -> dict[str, Any]:
    m = resolve_moment(inp, use_true_solar=False)
    bj = m["instant"].astimezone(BEIJING).replace(tzinfo=None)
    lunar = _lunar(bj)
    rows = []
    for jq in (lunar.getPrevJieQi(), lunar.getNextJieQi()):
        s = jq.getSolar()
        at = datetime(s.getYear(), s.getMonth(), s.getDay(), s.getHour(), s.getMinute(), s.getSecond())
        hours = (at - bj).total_seconds() / 3600
        rows.append([jq.getName(), "节" if jq.isJie() else "气", at.strftime("%Y-%m-%d %H:%M:%S"), f"{hours:+.1f} 小时"])
    jie_prev, jie_next = lunar.getPrevJie(), lunar.getNextJie()
    body = table(["节气", "类别", "交接时刻（北京时间）", "距出生"], rows)
    body += f"\n出生所在节令区间：{jie_prev.getName()} → {jie_next.getName()}（月柱 {lunar.getMonthInGanZhiExact()}）"
    return build_snapshot("jieqi_birth", "出生节气窗", [("出生节气窗", body)])


# 小六壬：主流六宫（大安 留连 速喜 赤口 小吉 空亡），三数起三传
LIUGONG = ["大安", "留连", "速喜", "赤口", "小吉", "空亡"]
LIUGONG_MEANING = {
    "大安": "身未动时，属木青龙，主安稳、吉利，宜静守，失物在家中，行人未动。",
    "留连": "事难成，属水玄武，主拖延、纠缠，宜耐心等待，谋事迟缓。",
    "速喜": "喜来临，属火朱雀，主喜讯快到，求事速成，行人即至。",
    "赤口": "主口舌，属金白虎，主是非争执、官非，宜谨言慎行。",
    "小吉": "最吉昌，属木六合，主小有吉利、人和顺遂，求财有望。",
    "空亡": "事不祥，属土勾陈，主落空、虚耗，谋事难成，宜另作打算。",
}


def run_xiaoliuren(inp: dict[str, Any]) -> dict[str, Any]:
    nums = inp.get("nums")
    if isinstance(nums, (list, tuple)) and len(nums) == 3 and all(str(n).isdigit() and int(n) > 0 for n in nums):
        a, b, c = (int(n) for n in nums)
        how = f"报数起课：{a}、{b}、{c}"
    else:
        dt = parse_local(inp.get("date") or datetime.now().strftime("%Y-%m-%d"), inp.get("time") or datetime.now().strftime("%H:%M"))
        lunar = _lunar(dt)
        a, b = abs(lunar.getMonth()), lunar.getDay()
        c = BRANCHES.index(lunar.getTimeZhi()) + 1
        how = f"占时起课：农历{abs(lunar.getMonth())}月{lunar.getDay()}日{lunar.getTimeZhi()}时（{a}、{b}、{c}）"
    p1 = (a - 1) % 6
    p2 = (p1 + b - 1) % 6
    p3 = (p2 + c - 1) % 6
    chain = [LIUGONG[p1], LIUGONG[p2], LIUGONG[p3]]
    ask = inp.get("askEvent") or inp.get("question") or ""
    body = "\n".join([
        how,
        f"所问：{ask or '（未说明）'}",
        f"初传（起因）：{chain[0]}　中传（经过）：{chain[1]}　末传（结果）：{chain[2]}",
    ])
    meaning = "\n".join(f"{name}：{LIUGONG_MEANING[name]}" for name in dict.fromkeys(chain))
    return build_snapshot("xiaoliuren", "小六壬", [("起课", body), ("三传断语", meaning),
                                                   ("说明", "小六壬只适合日常小事的快速参考，以末传为主要结论。")],
                          {"chain": chain})


__all__ = ["run_huangli", "run_jieqi_birth", "run_nongli", "run_xiaoliuren"]
