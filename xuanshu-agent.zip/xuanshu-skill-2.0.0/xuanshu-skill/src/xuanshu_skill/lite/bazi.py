"""轻量引擎 · 八字（lunar_python，寿星天文历算法）。

口径与完整引擎一致：年柱 / 月柱按出生**绝对时刻**与节气交接比较（换算北京时间对节气表），日柱 / 时柱按
**真太阳时**；晚子时缺省算次日（after23NewDay=1）。
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from lunar_python import Solar
from lunar_python.util import LunarUtil as L

from xuanshu_skill.lite.common import BRANCHES, STEMS, build_snapshot, gender_of, resolve_moment, table

BEIJING = timezone(timedelta(hours=8))
CHANG_SHENG = ["长生", "沐浴", "冠带", "临官", "帝旺", "衰", "病", "死", "墓", "绝", "胎", "养"]
_CS_START = {"甲": "亥", "乙": "午", "丙": "寅", "丁": "酉", "戊": "寅", "己": "酉", "庚": "巳", "辛": "子", "壬": "申", "癸": "卯"}
WX_GAN = {g: L.WU_XING_GAN[g] for g in STEMS}
WX_ZHI = {z: L.WU_XING_ZHI[z] for z in BRANCHES}
_GENERATES = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}
_CONTROLS = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}

TIANYI = {"甲": "丑未", "戊": "丑未", "庚": "丑未", "乙": "子申", "己": "子申", "丙": "亥酉", "丁": "亥酉", "辛": "寅午", "壬": "卯巳", "癸": "卯巳"}
WENCHANG = {"甲": "巳", "乙": "午", "丙": "申", "丁": "酉", "戊": "申", "己": "酉", "庚": "亥", "辛": "子", "壬": "寅", "癸": "卯"}
LU = {"甲": "寅", "乙": "卯", "丙": "巳", "丁": "午", "戊": "巳", "己": "午", "庚": "申", "辛": "酉", "壬": "亥", "癸": "子"}
YANGREN = {"甲": "卯", "丙": "午", "戊": "午", "庚": "酉", "壬": "子"}
_SANHE = {"申": 0, "子": 0, "辰": 0, "寅": 1, "午": 1, "戌": 1, "巳": 2, "酉": 2, "丑": 2, "亥": 3, "卯": 3, "未": 3}
TAOHUA = ["酉", "卯", "午", "子"]
YIMA = ["寅", "申", "亥", "巳"]
HUAGAI = ["辰", "戌", "丑", "未"]


def shishen(day_stem: str, other: str) -> str:
    return L.SHI_SHEN.get(day_stem + other, "")


def changsheng(stem: str, branch: str) -> str:
    start = BRANCHES.index(_CS_START[stem])
    idx = BRANCHES.index(branch)
    yang = STEMS.index(stem) % 2 == 0
    step = (idx - start) % 12 if yang else (start - idx) % 12
    return CHANG_SHENG[step]


def relation(day_wx: str, other_wx: str) -> str:
    if other_wx == day_wx:
        return "同类帮扶"
    if _GENERATES[other_wx] == day_wx:
        return "生扶日主"
    if _GENERATES[day_wx] == other_wx:
        return "泄日主之气"
    if _CONTROLS[day_wx] == other_wx:
        return "为日主所克（耗）"
    return "克制日主"


def _eight_char(dt: datetime, *, sect: int = 1):
    lunar = Solar.fromYmdHms(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second).getLunar()
    ec = lunar.getEightChar()
    ec.setSect(sect)
    return lunar, ec


def compute(inp: dict[str, Any]) -> dict[str, Any]:
    m = resolve_moment(inp)
    sect = 2 if str(inp.get("after23NewDay", 1)) == "0" else 1
    bj = m["instant"].astimezone(BEIJING).replace(tzinfo=None)
    lunar_bj, ec_bj = _eight_char(bj, sect=sect)
    lunar_t, ec_t = _eight_char(m["local"], sect=sect)
    pillars = {"年": ec_bj.getYear(), "月": ec_bj.getMonth(), "日": ec_t.getDay(), "时": ec_t.getTime()}
    day_stem = pillars["日"][0]
    gender = gender_of(inp)
    return {"moment": m, "pillars": pillars, "day_stem": day_stem, "lunar_bj": lunar_bj, "ec_bj": ec_bj,
            "lunar_t": lunar_t, "ec_t": ec_t, "gender": gender, "sect": sect}


def run(inp: dict[str, Any]) -> dict[str, Any]:
    c = compute(inp)
    m, P, ds = c["moment"], c["pillars"], c["day_stem"]
    gender = c["gender"]
    lunar_t, ec_t, lunar_bj = c["lunar_t"], c["ec_t"], c["lunar_bj"]
    sections: list[tuple[str, str]] = []

    info = [
        f"公历（钟表）：{m['civil']:%Y-%m-%d %H:%M}（UTC{inp.get('zone') or '+08:00'}）",
        f"起盘时间：{m['local']:%Y-%m-%d %H:%M}（{m['basis']}）",
        f"农历：{lunar_t.toString()}　生肖：{lunar_bj.getYearShengXiaoExact()}（立春换年）",
        f"性别：{'男' if gender == 1 else '女' if gender == 0 else '未提供（大运顺逆无法确定）'}",
        f"晚子时口径：{'23 点后日柱算次日' if c['sect'] == 1 else '23 点后日柱仍算当天'}",
        "年柱、月柱按出生绝对时刻对照节气交接；日柱、时柱按真太阳时。",
    ]
    if inp.get("pos") or inp.get("name"):
        info.insert(0, f"{inp.get('name') or ''} {inp.get('pos') or ''}".strip())
    sections.append(("起盘信息", "\n".join(info)))

    rows = []
    for col in ("年", "月", "日", "时"):
        gz = P[col]
        g, z = gz[0], gz[1]
        hide = L.ZHI_HIDE_GAN[z]
        rows.append([
            f"{col}柱", g, z,
            "日主" if col == "日" else shishen(ds, g),
            "、".join(f"{h}({shishen(ds, h)})" for h in hide),
            L.NAYIN.get(gz, ""),
            changsheng(ds, z),
        ])
    sections.append(("四柱", table(["柱", "天干", "地支", "天干十神", "地支藏干（十神）", "纳音", "日主长生"], rows)
                     + f"\n日主：{ds}（{WX_GAN[ds]}）　日柱旬空：{ec_t.getDayXunKong()}"))

    count = {k: 0 for k in "木火土金水"}
    for gz in P.values():
        count[WX_GAN[gz[0]]] += 1
        count[WX_ZHI[gz[1]]] += 1
    hidden = {k: 0 for k in "木火土金水"}
    for gz in P.values():
        for h in L.ZHI_HIDE_GAN[gz[1]]:
            hidden[WX_GAN[h]] += 1
    month_branch = P["月"][1]
    wx_lines = [
        "八字五行个数（天干+地支本气）：" + "　".join(f"{k}{v}" for k, v in count.items()),
        "含藏干的五行个数：" + "　".join(f"{k}{v}" for k, v in hidden.items()),
        f"月令 {month_branch}（{WX_ZHI[month_branch]}）对日主 {ds}（{WX_GAN[ds]}）：{relation(WX_GAN[ds], WX_ZHI[month_branch])}",
        "缺失的五行：" + ("、".join(k for k, v in hidden.items() if v == 0) or "无"),
    ]
    sections.append(("五行统计", "\n".join(wx_lines)))

    ss_count: dict[str, int] = {}
    for col, gz in P.items():
        if col != "日":
            ss_count[shishen(ds, gz[0])] = ss_count.get(shishen(ds, gz[0]), 0) + 1
        for h in L.ZHI_HIDE_GAN[gz[1]][:1]:
            ss_count[shishen(ds, h)] = ss_count.get(shishen(ds, h), 0) + 1
    sections.append(("十神分布", "按天干与地支本气计：" + "　".join(f"{k}{v}" for k, v in sorted(ss_count.items(), key=lambda kv: -kv[1]))))

    shensha: list[str] = []
    year_branch, day_branch = P["年"][1], P["日"][1]
    branches = {col: gz[1] for col, gz in P.items()}

    def where(targets: str) -> str:
        hits = [f"{col}柱" for col, z in branches.items() if z in targets]
        return "、".join(hits) if hits else "（四柱未见）"

    shensha.append(f"天乙贵人（日干 {ds} 见 {TIANYI[ds]}）：{where(TIANYI[ds])}")
    shensha.append(f"文昌（{WENCHANG[ds]}）：{where(WENCHANG[ds])}")
    shensha.append(f"禄神（{LU[ds]}）：{where(LU[ds])}")
    if ds in YANGREN:
        shensha.append(f"羊刃（{YANGREN[ds]}）：{where(YANGREN[ds])}")
    for name, tbl in (("桃花", TAOHUA), ("驿马", YIMA), ("华盖", HUAGAI)):
        for basis, br in (("年支", year_branch), ("日支", day_branch)):
            target = tbl[_SANHE[br]]
            shensha.append(f"{name}（按{basis} {br} 取 {target}）：{where(target)}")
    sections.append(("常用神煞", "\n".join(shensha) + "\n神煞只作辅助参考，不能单凭神煞论吉凶。"))

    sections.append(("命宫胎元", f"命宫：{ec_t.getMingGong()}　身宫：{ec_t.getShenGong()}　胎元：{ec_t.getTaiYuan()}"))

    if gender is not None:
        yun = c["ec_bj"].getYun(gender)
        start = f"出生后 {yun.getStartYear()} 年 {yun.getStartMonth()} 个月 {yun.getStartDay()} 天起运（约 {yun.getStartSolar().toYmd()}），{'顺排' if yun.isForward() else '逆排'}"
        dy_rows = []
        for d in yun.getDaYun()[1:10]:
            gz = d.getGanZhi()
            dy_rows.append([f"{d.getStartAge()}–{d.getEndAge()} 岁", f"{d.getStartYear()}–{d.getEndYear()}", gz,
                            shishen(ds, gz[0]), shishen(ds, L.ZHI_HIDE_GAN[gz[1]][0])])
        sections.append(("大运", start + "\n" + table(["年龄", "年份", "大运", "天干十神", "地支本气十神"], dy_rows)))
    else:
        sections.append(("大运", "未提供性别，无法确定大运顺逆。请补充性别后重新起盘。"))

    this_year = int(inp.get("currentYear") or datetime.now().year)
    ln_rows = []
    for y in range(this_year - 1, this_year + 4):
        gz = Solar.fromYmd(y, 6, 1).getLunar().getYearInGanZhiExact()
        notes = []
        for col, pg in P.items():
            if (BRANCHES.index(gz[1]) - BRANCHES.index(pg[1])) % 12 == 6:
                notes.append(f"冲{col}支")
            if gz == pg:
                notes.append(f"伏吟{col}柱")
        ln_rows.append([y, gz, shishen(ds, gz[0]), shishen(ds, L.ZHI_HIDE_GAN[gz[1]][0]), "、".join(notes) or "—"])
    sections.append(("流年", table(["年份", "流年", "天干十神", "地支本气十神", "与四柱"], ln_rows)))

    data = {"pillars": P, "day_master": ds, "five_elements": count, "five_elements_with_hidden": hidden,
            "true_solar_local": m["local"].strftime("%Y-%m-%d %H:%M"), "gender": gender}
    return build_snapshot("bazi_birth", "八字命盘", sections, data)


__all__ = ["compute", "run", "shishen", "changsheng"]
