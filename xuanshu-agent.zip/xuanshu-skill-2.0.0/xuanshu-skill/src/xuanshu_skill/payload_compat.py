"""离线 runtime 载荷的内部标识（单一来源）。

玄枢 2.0 的 Python / JS 层已经全部换成自己的命名，但离线 runtime（Java 后端 jar、Python 星历服务、
启动脚本）是预先编译打包好的二进制载荷，里面的目录名、启动脚本名、JVM 系统属性、身份端点和
进程标记都是在打包时写死的。下面这些字符串必须与**载荷里的实际值**逐字一致，否则安装、启动、
身份识别都会失败。

它们只出现在这一个文件里。将来用新名字重新打包 runtime 时，改这里一处即可，其余代码全部引用本模块。
"""
from __future__ import annotations

# ── 载荷目录布局 ────────────────────────────────────────────────────────────────
PAYLOAD_WEB_DIR = "Horosa-Web"
START_SCRIPT_SH = f"{PAYLOAD_WEB_DIR}/start_horosa_local.sh"
STOP_SCRIPT_SH = f"{PAYLOAD_WEB_DIR}/stop_horosa_local.sh"
START_SCRIPT_PS1_NAME = "start_horosa_local.ps1"
STOP_SCRIPT_PS1_NAME = "stop_horosa_local.ps1"
START_SCRIPT_PS1 = f"{PAYLOAD_WEB_DIR}/{START_SCRIPT_PS1_NAME}"
STOP_SCRIPT_PS1 = f"{PAYLOAD_WEB_DIR}/{STOP_SCRIPT_PS1_NAME}"
ASTROPY_DIR = f"{PAYLOAD_WEB_DIR}/astropy"
FLATLIB_DIR = f"{PAYLOAD_WEB_DIR}/flatlib-ctrad2/flatlib"
SWEFILES_DIR = f"{FLATLIB_DIR}/resources/swefiles"
ASTRODATA_SQLITE_GZ = f"{PAYLOAD_WEB_DIR}/astrostudyui/dist-file/astrodata/astrodata-aa.sqlite.gz"

# runtime-manifest.json 的 artifacts 键名（载荷清单里写死）
MANIFEST_WEB_ROOT_KEY = "horosa_web_root"

# ── 载荷写出的日志目录 ──────────────────────────────────────────────────────────
# macOS 载荷自带启动脚本把 jar 的 stdout/stderr 写到 <Web 根>/<此目录>/<run>/
LAUNCHER_LOG_DIR = ".horosa-local-logs"
# 载荷 log4j 配置里写死的日志根占位（Windows 补丁要把它改写成真实路径）
LOG4J_LOG_PLACEHOLDERS = (
    "${env:HOME:-${sys:user.home}}/.horosa-logs/astrostudyboot",
    "${env:HOME}/.horosa-logs/astrostudyboot",
)

# ── JVM 系统属性 / Java 类 ──────────────────────────────────────────────────────
JVM_PROP_RUNTIME_ROOT = "horosa.runtime.root"
JVM_PROP_RUNTIME_OWNER = "horosa.runtime.owner"
WINDOWS_LOCAL_CACHE_FACTORY = "horosa.offline.LocalCacheFactory"

# ── 身份协议 ────────────────────────────────────────────────────────────────────
IDENTITY_PATH = "/horosaIdentity"
APP_MARKERS = frozenset({"horosa-chart", "horosa-backend", "horosa-web", "horosa"})

# ── 载荷启动脚本读取的环境变量 ──────────────────────────────────────────────────
ENV_SERVER_PORT = "HOROSA_SERVER_PORT"
ENV_CHART_PORT = "HOROSA_CHART_PORT"
ENV_LAUNCH_NONCE = "HOROSA_LAUNCH_NONCE"

__all__ = [name for name in dir() if name.isupper()]
