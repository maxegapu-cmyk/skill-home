from __future__ import annotations

import re
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

_COMPACT_COORD_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([NSEWnsew])\s*(\d+(?:\.\d+)?)\s*$")
_DECIMAL_RE = re.compile(r"^[+-]?\d+(?:\.\d+)?$")
_ZONE_HM_RE = re.compile(r"^(?P<sign>[+-]?)(?P<hours>\d{1,2})(?::(?P<minutes>\d{1,2}))?$")
_DATE_RE = re.compile(r"^(?P<year>\d{4})(?P<sep>[-/])(?P<month>\d{1,2})(?P=sep)(?P<day>\d{1,2})$")
_TIME_RE = re.compile(r"^(?P<hour>\d{1,2}):(?P<minute>\d{1,2})(?::(?P<second>\d{1,2}))?$")
_DATETIME_RE = re.compile(
    r"^(?P<date>\d{4}[-/]\d{1,2}[-/]\d{1,2})(?P<sep>[T\s]+)(?P<time>\d{1,2}:\d{1,2}(?::\d{1,2})?)$"
)


def normalize_request_payload(payload: Any) -> Any:
    if isinstance(payload, list):
        return [normalize_request_payload(item) for item in payload]
    if not isinstance(payload, dict):
        return payload

    normalized = {key: normalize_request_payload(value) for key, value in payload.items()}
    _resolve_place_fields(normalized)
    _normalize_date_like_fields(normalized)
    _normalize_zone_fields(normalized)
    _normalize_coordinate_fields(normalized)
    _normalize_gender_field(normalized)
    return normalized


# 2.0：出生地/起盘地可以直接写地名（place / birthplace / city），缺 lat/lon 时查离线地名库补齐
# 经纬度、IANA 时区（随日期自动折算历史夏令时）与显示名 pos。已给的字段一律不覆盖。
# 解析结果留在 placeResolved（人读一行）/ placeAdvisory（精度提示），service 把它们写进 warnings。
_PLACE_KEYS = ("place", "birthplace", "birth_place", "city", "location_name")


def _resolve_place_fields(payload: dict[str, Any]) -> None:
    place = next((payload.get(k) for k in _PLACE_KEYS if isinstance(payload.get(k), str) and payload.get(k).strip()), None)
    if place is None:
        return
    if payload.get("lat") not in (None, "") and payload.get("lon") not in (None, ""):
        return
    try:
        from xuanshu_skill.precision.places import lookup_place

        result = lookup_place(place)
    except Exception:  # noqa: BLE001 — 地名库只是便利层，任何异常都不能挡住起盘
        return
    if not result.get("ok"):
        payload["placeAdvisory"] = result.get("ask_user") or f"地名「{place}」未能识别，请改给经纬度。"
        return
    best = result["best"]
    payload["lat"] = best["lat"]
    payload["lon"] = best["lon"]
    if payload.get("zone") in (None, ""):
        payload["zone"] = best["timezone"]
    if payload.get("pos") in (None, ""):
        payload["pos"] = best.get("name_zh") or best.get("name")
    where = f"{best.get('province') or ''}{best.get('name_zh') or best.get('name')}"
    payload["placeResolved"] = (
        f"{place} → {where}（纬度 {best['lat']}，经度 {best['lon']}，时区 {best['timezone']}，"
        f"精度：{best['precision']}，真太阳时误差约 ±{best['true_solar_uncertainty_minutes']:g} 分钟）"
    )
    notes = [n for n in result.get("notes", []) if n]
    if notes:
        payload["placeAdvisory"] = "；".join(notes)


# 性别标签 → 0(女)/1(男)。八字链（bazi/canping/heluo/yizhangjing）下游按 0/1 判大运/大限顺逆；
# 若字符串标签（'女'/'Female'/'F'…）原样进 JS，Number(...) 得 NaN → 恒判男 → 女命方向反转。
# 只归一「可识别的字符串标签」，int/None/未识别值一律不动（零回归：既有 0/1 调用不受影响）。
_GENDER_MALE_LABELS = {"男", "male", "m", "boy", "man", "nan", "男性", "乾", "1"}
_GENDER_FEMALE_LABELS = {"女", "female", "f", "girl", "woman", "nv", "女性", "坤", "0"}


def _normalize_gender_field(payload: dict[str, Any]) -> None:
    value = payload.get("gender")
    if isinstance(value, bool):
        # Java 后端读 1/0；bool 直传会变成 JSON true/false（v0.36.0，PR #17）
        payload["gender"] = 1 if value else 0
        return
    if not isinstance(value, str):
        return
    key = value.strip().lower()
    if key in _GENDER_MALE_LABELS:
        payload["gender"] = 1
    elif key in _GENDER_FEMALE_LABELS:
        payload["gender"] = 0


def _normalize_date_like_fields(payload: dict[str, Any]) -> None:
    for key in ("date", "datetime", "guaDate", "guaTime", "time"):
        if key not in payload:
            continue
        normalized = _normalize_date_like_value(key, payload.get(key))
        if normalized is not None:
            payload[key] = normalized


def _normalize_date_like_value(key: str, value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return text

    if key in {"date", "guaDate"}:
        return _normalize_date_value(text)
    if key in {"time", "guaTime"}:
        return _normalize_time_value(text)
    if key == "datetime":
        return _normalize_datetime_value(text)
    return text


def _normalize_date_value(text: str) -> str:
    match = _DATE_RE.match(text)
    if not match:
        return text
    return f"{int(match.group('year')):04d}-{int(match.group('month')):02d}-{int(match.group('day')):02d}"


def _normalize_time_value(text: str) -> str:
    match = _TIME_RE.match(text)
    if not match:
        return text
    second = int(match.group("second") or "0")
    return f"{int(match.group('hour')):02d}:{int(match.group('minute')):02d}:{second:02d}"


def _normalize_datetime_value(text: str) -> str:
    match = _DATETIME_RE.match(text)
    if not match:
        return text
    date_text = _normalize_date_value(match.group("date"))
    time_text = _normalize_time_value(match.group("time"))
    separator = "T" if "T" in match.group("sep") else " "
    return f"{date_text}{separator}{time_text}"


def _normalize_zone_fields(payload: dict[str, Any]) -> None:
    for key in ("zone", "dirZone", "guaZone"):
        if key not in payload:
            continue
        normalized = _normalize_zone_value(payload.get(key), payload=payload, key=key)
        if normalized is not None:
            payload[key] = normalized


def _normalize_coordinate_fields(payload: dict[str, Any]) -> None:
    for value_key, gps_key, axis in (
        ("lat", "gpsLat", "lat"),
        ("lon", "gpsLon", "lon"),
        ("dirLat", None, "lat"),
        ("dirLon", None, "lon"),
        ("guaLat", None, "lat"),
        ("guaLon", None, "lon"),
    ):
        raw_value = payload.get(value_key)
        raw_decimal = _coerce_coordinate_decimal(raw_value)
        if raw_decimal is not None:
            payload[value_key] = _format_compact_coordinate(raw_decimal, axis=axis)

        if not gps_key:
            continue

        gps_value = payload.get(gps_key)
        gps_decimal = _coerce_coordinate_decimal(gps_value)
        if gps_decimal is None and raw_decimal is not None:
            payload[gps_key] = round(raw_decimal, 6)
        elif gps_decimal is not None:
            payload[gps_key] = round(gps_decimal, 6)
            if raw_value is None:
                payload[value_key] = _format_compact_coordinate(gps_decimal, axis=axis)


def _normalize_zone_value(value: Any, *, payload: dict[str, Any] | None = None, key: str = "zone") -> str | None:
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return _format_zone_offset(float(value))

    text = str(value).strip()
    if not text:
        return text

    iana_offset = _normalize_iana_zone_value(text, payload=payload, key=key)
    if iana_offset is not None:
        return iana_offset

    offset_text = text.upper().replace("UTC", "").replace("GMT", "").strip()
    if offset_text in ("", "Z"):
        # Bare UTC / GMT / Z (and "UTC"/"GMT" alone) -> canonical zero offset.
        return "+00:00"
    if ":" not in offset_text:
        compact_match = re.fullmatch(r"(?P<sign>[+-]?)(?P<digits>\d{3,4})", offset_text)
        if compact_match:
            sign = compact_match.group("sign") or "+"
            digits = compact_match.group("digits")
            hours = int(digits[:-2])
            minutes = int(digits[-2:])
            if minutes < 60:
                return _format_zone_offset((-1 if sign == "-" else 1) * (hours + minutes / 60))
    match = _ZONE_HM_RE.match(offset_text)
    if not match:
        if _DECIMAL_RE.match(offset_text):
            return _format_zone_offset(float(offset_text))
        return str(value)

    sign = -1 if match.group("sign") == "-" else 1
    hours = int(match.group("hours"))
    minutes = int(match.group("minutes") or "0")
    if minutes >= 60:
        return str(value)
    total_hours = sign * (hours + minutes / 60)
    return _format_zone_offset(total_hours)


# 中国大陆统一北京时间口径（上游 utils/timezone.js:124-151 unifyCnZone，xuanshu_tz_cn_unified_v1）：IANA 把新疆
# 划为 Asia/Urumqi（+06:00，民间「新疆时间」），而出生证/户籍/医院记录一律按法定北京时间。统一时间起点
# （1949-10-01）之后 Asia/Urumqi → Asia/Shanghai，**只做 IANA 名归并、不写死偏移**（1986–1991 夏令时照常
# 得 +09:00；统一前的新疆出生仍按 +06:00）。归并时在载荷里留 geoZone（原地理时区）+ zoneAdvisory='cn-unified'，
# 技法卡与 warnings 据此回显。退出口：cnUnifiedZone=false（上游 kill-switch 是 localStorage 'xuanshu.tz.cnUnified'='0'），
# 或直接给偏移 "+06:00"（偏移不归并）。
CN_UNIFIED_ZONE_SINCE = "1949-10-01"
_CN_UNIFIED_SINCE_YMD = (1949, 10, 1)
_CN_UNIFY = {"Asia/Urumqi": "Asia/Shanghai"}
_OPT_OUT_VALUES = (False, 0, "0", "false", "False", "no", "off")


def _cn_unified_enabled(payload: dict[str, Any]) -> bool:
    return payload.get("cnUnifiedZone") not in _OPT_OUT_VALUES


def _normalize_iana_zone_value(text: str, *, payload: dict[str, Any] | None, key: str) -> str | None:
    if "/" not in text:
        return None
    reference = _reference_datetime_for_zone(payload or {}, key)
    unified_from: str | None = None
    target = _CN_UNIFY.get(text)
    # 上游：只有能解析出 YYYY-MM-DD 且早于起点才不归并（日期缺失照样归并——但缺日期本仓也算不出偏移，
    # 下面 reference 为 None 时原样返回 None，不改 zone）。按 (年, 月, 日) 比较：strftime('%Y') 对四位以下的年
    # 不补零（平台相关），字符串比较会把公元 100 年判成「晚于 1949」。
    if (
        target
        and payload is not None
        and _cn_unified_enabled(payload)
        and reference is not None
        and (reference.year, reference.month, reference.day) >= _CN_UNIFIED_SINCE_YMD
    ):
        unified_from, text = text, target
    try:
        zone = ZoneInfo(text)
    except (ZoneInfoNotFoundError, ValueError):
        return None

    if reference is None:
        return None
    if unified_from is not None and payload is not None:
        payload.setdefault("geoZone", unified_from)
        payload["zoneAdvisory"] = "cn-unified"
    offset = reference.replace(tzinfo=zone).utcoffset()
    if offset is None:
        return None
    return _format_zone_offset(offset.total_seconds() / 3600)


def _reference_datetime_for_zone(payload: dict[str, Any], key: str) -> datetime | None:
    if key == "guaZone":
        reference = _combine_date_time(payload.get("guaDate"), payload.get("guaTime"))
        if reference is not None:
            return reference
    if key == "dirZone":
        reference = _parse_datetime_text(payload.get("datetime"))
        if reference is not None:
            return reference
    return _combine_date_time(payload.get("date"), payload.get("time")) or _parse_datetime_text(payload.get("datetime"))


def _combine_date_time(date_value: Any, time_value: Any) -> datetime | None:
    if date_value is None or time_value is None:
        return None
    date_text = str(date_value).strip()
    time_text = str(time_value).strip()
    date_match = _DATE_RE.match(date_text)
    time_match = _TIME_RE.match(time_text)
    if not date_match or not time_match:
        return None
    try:
        return datetime(
            int(date_match.group("year")),
            int(date_match.group("month")),
            int(date_match.group("day")),
            int(time_match.group("hour")),
            int(time_match.group("minute")),
            int(time_match.group("second") or "0"),
        )
    except ValueError:
        # The regexes accept digit-shaped but calendar-invalid values (month 13, day 45,
        # hour 99, ...). Degrade like a regex miss instead of crashing normalization — the
        # backend will reject the bad date with a structured param error.
        return None


def _parse_datetime_text(value: Any) -> datetime | None:
    if value is None:
        return None
    text = str(value).strip()
    match = _DATETIME_RE.match(text)
    if not match:
        return None
    return _combine_date_time(match.group("date"), match.group("time"))


def _format_zone_offset(offset_hours: float) -> str:
    sign = "+" if offset_hours >= 0 else "-"
    total_minutes = round(abs(offset_hours) * 60)
    hours, minutes = divmod(total_minutes, 60)
    return f"{sign}{hours:02d}:{minutes:02d}"


def _coerce_coordinate_decimal(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)

    text = str(value).strip()
    if not text:
        return None

    compact_match = _COMPACT_COORD_RE.match(text)
    if compact_match:
        degrees = float(compact_match.group(1))
        hemisphere = compact_match.group(2).lower()
        minutes = float(compact_match.group(3))
        decimal = degrees + minutes / 60
        if hemisphere in {"s", "w"}:
            decimal *= -1
        return decimal

    if _DECIMAL_RE.match(text):
        return float(text)
    return None


def _format_compact_coordinate(decimal_value: float, *, axis: str) -> str:
    hemisphere_positive = "n" if axis == "lat" else "e"
    hemisphere_negative = "s" if axis == "lat" else "w"
    hemisphere = hemisphere_positive if decimal_value >= 0 else hemisphere_negative
    absolute = abs(decimal_value)
    degrees = int(absolute)
    minutes = round((absolute - degrees) * 60)
    if minutes == 60:
        degrees += 1
        minutes = 0
    return f"{degrees}{hemisphere}{minutes:02d}"
