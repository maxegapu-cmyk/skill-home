# 第三方组件与数据声明 / Third-party notices

玄枢 Xuanshu 2.0 按 [GNU AGPL-3.0-only](./LICENSE) 授权。以下第三方组件与数据随本项目或其离线 runtime 一起分发，各自的许可证要求保留下列声明。

| 组件 / 数据 | 用途 | 许可证 | 来源 |
| --- | --- | --- | --- |
| kinqimen | 奇门遁甲排盘引擎（随离线 runtime 分发） | MIT | <https://github.com/kentang2017/kinqimen> |
| kintaiyi | 太乙神数排盘引擎（随离线 runtime 分发） | MIT | <https://github.com/kentang2017/kintaiyi> |
| kinjinkou | 金口诀排盘引擎（随离线 runtime 分发） | MIT | <https://github.com/kentang2017/kinjinkou> |
| lunar_python | 节气交接时刻、四柱与农历换算（出生时间体检） | MIT | <https://github.com/6tail/lunar-python> |
| iztro-py | 轻量引擎的紫微斗数排盘 | MIT | <https://pypi.org/project/iztro-py/> |
| astronomy-engine | 轻量引擎的星体位置与太阳返照 | MIT | <https://github.com/cosinekitty/astronomy> |
| lunar-javascript | JS 引擎中的农历与节气计算 | MIT | <https://github.com/6tail/lunar-javascript> |
| GeoNames | 离线地名库 `places.json.gz` 的地名、坐标与时区 | CC BY 4.0 | <https://www.geonames.org/> |
| Swiss Ephemeris（经 flatlib） | 星历计算（随离线 runtime 分发） | AGPL-3.0 / Swiss Ephemeris 授权 | <https://www.astro.com/swisseph/> |

上述 MIT 组件的完整版权与许可证文本随离线 runtime 中各自的 `LICENSE` 文件一并分发。传统术数体系本身（京房八宫、希腊十年星限、二十八宿等）属公共知识，不构成第三方版权。
