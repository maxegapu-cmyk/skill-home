---
name: fengyun-jue-rebuilder
description: Use when recreating or restaging Feng Yun Jue / Storm Rider: Clash of the Evils characters, story scenes, fights, trailers, or music-driven sequences while preserving identity, choreography, narrative continuity, and a separately defined target visual style.
---

# Feng Yun Jue Rebuilder 2.0

## Core contract

Rebuild through three independent engines that meet only at the shot package:

- `NARRATIVE_ENGINE`: why the scene exists and what state changes.
- `COMBAT_ENGINE`: who moves where, why contact happens, and what force/effect follows.
- `STYLE_ENGINE`: how forms are drawn, colored, lit, textured, and composited.

Identity is a fourth invariant, not a style. Never let a style or motion donor redefine a character.

## Modes

`CHARACTER_ASSET`, `SHOT_REPLICA`, `NARRATIVE_REBUILD`, `COMBAT_REBUILD`, `MUSIC_REBUILD`, `TRAILER_REBUILD`.
Legacy aliases `SEQUENCE_REPLICA` and `MV_REBUILD` remain valid.

## Required objects

Before final generation, build or inherit:

`SOURCE_MAP` → `CHARACTER_LOCK` → `STYLE_FINGERPRINT` (`STYLE_LOCK` legacy alias) → `SCENE_STATE` → `SHOT_GRAPH` → `REFERENCE_ROUTER` → `CONTINUITY_STATE`.

Combat shots additionally require `FIGHT_MAP` and at least one explicit `contact event` when physical contact occurs.

## Operating sequence

1. **Forensics.** Read `references/source-forensics.md`. Mark subtitles, danmaku, player UI, logos, watermarks, compression damage, and uncertain details as non-diegetic or low-confidence evidence.
2. **Character anchor.** Build one canonical identity pack per actor. Use stable `actor_id` / `role_id`; never infer identity from screen position alone.
3. **Style fingerprint.** Extract recurrent rendering behavior across multiple target references. Content, costume, pose, camera, and identity do not belong to style.
4. **Narrative spine.** For scenes, record `scene goal`, obstacle, decision, causal consequence, emotional turn, and `state change`. A scene with no meaningful change is either connective tissue or expendable.
5. **Fight map.** Separate `camera trajectory` from every `subject trajectory`. Record arena, axis, distances, attacks, defenses, contact, recoil, damage and power-effect causality.
6. **Shot graph.** Each shot declares predecessor, successor, first state, end state, and handoff contract. Accepted end state becomes the next shot's opening evidence.
7. **Reference routing.** Assign each reference exactly one primary job: identity, costume, style, environment, pose, depth, canny, motion, camera, first frame, last frame, or accepted continuity. Never use “all references for everything.”
8. **Keyframe gate.** Identity and staging pass before video. Do not spend motion generations fixing a bad still.
9. **Video.** Prefer atomic shots for dense action. Camera motion, subject motion, secondary motion, effects, and end-state must be stated separately.
10. **Continuity + QA.** Update ledger after each accepted shot. Diagnose failures by code and repair only the broken layer.

## Routing rules

- Need exact identity/style but new action → canonical image + action/motion control.
- Need exact choreography/camera but different actors/look → transfer pose/depth/canny or motion role only; exclude donor identity/style.
- Need a local fix in an otherwise good clip → edit the failed region/beat instead of regenerating the sequence.
- Need long action → decompose to 1.5–4 s shots unless a tested model reliably supports the planned complexity.
- Need dialogue/reaction → do not force a motion-control stack that adds instability without benefit.

## Approval gates

A shot cannot advance with `ID_DRIFT`, `ROLE_SWAP`, `ACTION_BREAK`, `CONTACT_FLOAT`, `AXIS_BREAK`, `STYLE_DRIFT`, `EFFECT_PRECAUSE`, `STATE_RESET`, or another fatal blocker defined in `references/qa-rubric.md`.

When a layer fails, freeze all layers already correct. Do not solve a face problem with more style words, or a choreography problem by changing the character anchor.
