# Changelog

## 2.0.0
- split orchestration into narrative, combat and style engines;
- added source overlay forensics;
- added stable actor/role/screen-slot identity contract;
- added style fingerprint and reference router;
- added scene causal/state-change contract;
- added fight map, contact-event contract, occlusion/re-entry protocol;
- separated camera trajectory from subject trajectories;
- added shot graph + first/end-state handoff invariant;
- added failure-code diagnosis and local-repair routing;
- added sequence/project linters, QA scorer, SHA-256 generation manifest;
- added scenario pressure tests and public research notes.
