from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def test_validator_passes():
    p = subprocess.run([sys.executable, str(ROOT / "scripts" / "validate_skill.py")], capture_output=True, text=True)
    assert p.returncode == 0, p.stdout + p.stderr
    assert "PASS" in p.stdout

def test_prompt_templates_separate_layers():
    image_prompt = (ROOT / "templates" / "image-prompt.md").read_text(encoding="utf-8")
    for term in ["CHARACTER_LOCK", "SHOT_LOCK", "STYLE_LOCK", "PRESERVE", "TRANSFORM"]:
        assert term in image_prompt

def test_video_prompt_has_handoff_state():
    video_prompt = (ROOT / "templates" / "video-prompt.md").read_text(encoding="utf-8")
    assert "FIRST FRAME STATE" in video_prompt
    assert "END FRAME STATE" in video_prompt
    assert "CONTINUITY" in video_prompt
