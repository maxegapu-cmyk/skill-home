# Pressure cases v2

These are scenario tests for human/model review. Structural tests cover the contracts mechanically; these cases test judgment.

1. **Dirty Bilibili screenshot** — subtitles, danmaku and watermark cross a face. Pass only if they are masked from style/geometry evidence and hidden features remain UNKNOWN or sourced elsewhere.
2. **Style donor contains another handsome wuxia hero** — pass only if line/color/material transfer while donor identity/costume are explicitly excluded.
3. **Two similar male heroes cross during a fight** — pass only with stable actor_id/role_id/screen_slot, separate trajectories and re-entry contract.
4. **12-second one-take duel request** — pass only if complexity is evaluated and split into atomic shots when contact/occlusion/effects exceed reliable control.
5. **Hero vanishes behind smoke and returns** — pass only if re-entry retains same actor identity, costume damage, weapon hand and motion state.
6. **Palm effect appears before palm acceleration** — must diagnose EFFECT_PRECAUSE rather than “make VFX prettier.”
7. **Punch misses by 20 cm but defender flies away** — must diagnose CONTACT_FLOAT and rebuild the contact event/impact window.
8. **Camera orbits across the action axis** — intentional cross is allowed only with visible travel/spatial reset; otherwise AXIS_BREAK.
9. **Unknown back of costume** — do not invent confidently from a frontal screenshot; seek additional evidence or mark UNKNOWN.
10. **MV chorus is all maximum-scale shots** — restructure energy curve; do not cut every beat or peak from second one.
11. **Quiet reaction shot** — do not add pose/depth/canny stack just because it exists; simplest stable route wins.
12. **Accepted clip is good except one sleeve mutation** — local edit costume layer; freeze face, camera, story beat and motion.
13. **Previous clip opening state conflicts with canonical face anchor** — transient continuity owns pose/damage; canonical anchor still owns identity.
14. **Three fighters and a moving camera swap identities** — decompose or simplify local exchanges; no “epic chaotic battle” free generation.
15. **Scene has beautiful shots but no change** — diagnose NARRATIVE_FLAT; add a decision/consequence or remove the scene.
16. **Repro failure weeks later** — accepted shot must have manifest with model/provider, seed where supported, prompt version, parent and asset hashes.
