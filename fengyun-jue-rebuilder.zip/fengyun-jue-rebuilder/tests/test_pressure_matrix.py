from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def test_pressure_matrix_has_16_unique_cases_and_contract_coverage():
    cases=json.loads((ROOT/'tests/fixtures/pressure_matrix.json').read_text(encoding='utf-8'))
    assert len(cases)==16
    assert len({c['id'] for c in cases})==16
    alltxt='\n'.join(p.read_text(encoding='utf-8') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.md','.py','.json'})
    missing=[]
    for c in cases:
        for term in c['must_use']:
            if term not in alltxt:
                missing.append((c['id'],term))
    assert not missing, missing

def test_public_research_notes_are_non_dependency_design_inputs():
    t=(ROOT/'references/public-research-notes.md').read_text(encoding='utf-8')
    for repo in ['StoryDiffusion','reshot','TriMotion','frameline','ai-film-director']:
        assert repo in t
    assert 'none is required to run the skill' in t
