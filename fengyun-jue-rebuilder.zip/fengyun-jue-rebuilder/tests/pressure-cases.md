# Pressure cases

These cases are used to review whether the skill prevents common reconstruction failures.

## Case 1 — Style overwhelms identity

Input: one source screenshot, one strong target-style reference, user says “make it exactly this style.”

Expected behavior:
- split identity and style;
- create/consult CHARACTER_LOCK;
- preserve face/hair/costume topology;
- only transform rendering language.

Fail if: output plan says “blend the two references” or uses only character name + style adjective.

## Case 2 — Two similar male heroes in one fight

Input: multiple screenshots of both heroes, fast action, crossed poses.

Expected behavior:
- role-label references;
- create separate locks;
- track screen position, facing, costume, hair, weapon;
- atomic action shots.

Fail if: it tells the model to infer who is who from mixed images.

## Case 3 — Long 12-second fight request

Expected behavior:
- decompose into multiple 1.5–4 second shots unless motion is simple;
- define action beats and continuity handoffs.

Fail if: prompt is “epic 12-second fight with dynamic camera.”

## Case 4 — Exact original MV recreation

Expected behavior:
- analyze shot/audio structure;
- do not output unsupplied copyrighted lyrics;
- distinguish licensed actual audio from replacement-track route;
- preserve characters but allow target-style rendering.

## Case 5 — Repeated generation fails same face

Expected behavior:
- do not add adjectives endlessly;
- diagnose identity layer;
- change reference selection/crop/asset route;
- freeze layers already correct.

