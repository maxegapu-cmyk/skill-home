# Stress test report — v2.0.0

## Baseline v1 gap test
- 12/12 new v2 contracts were absent in v1 before modification.

## v2 positive suite
- validate_skill.py: PASS
- pytest: 16 passed
- good combat sequence lint: PASS
- good score gate: PASS

## v2 negative-path checks
Bad combat fixture must be rejected with multiple independent reasons:
```
FAIL
- missing style_fingerprint
- scene SCX missing scene_goal
- scene SCX missing causal_consequence
- scene SCX missing state_change
- shot S1 missing subject_trajectories
- shot S1 missing reference_router
- shot S1 duplicate actor_id
- shot S1 successor missing: S2
- combat shot S1 missing fight_map_id
- combat shot S1 missing contact event
- shot S1 occlusion missing re-entry contract
```

High numerical score with fatal ROLE_SWAP must still be rejected:
```
FAIL weighted=9.14
- fatal blocker: ROLE_SWAP
```

## Scope
These tests validate workflow contracts, state handoffs, failure gates, reproducibility metadata and negative-path rejection. They do not claim that any external image/video model will always obey a prompt; visual output still requires representative renders on the chosen model.
