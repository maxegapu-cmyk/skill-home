from pathlib import Path
import importlib.util
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

def load_module(name, path):
    spec=importlib.util.spec_from_file_location(name, path)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

seq=load_module('sequence_lint', ROOT/'scripts'/'sequence_lint.py')
gate=load_module('gate_score', ROOT/'scripts'/'gate_score.py')

def read(rel): return (ROOT/rel).read_text(encoding='utf-8')

def test_skill_version_and_core_engines():
    assert read('VERSION').strip()=='2.0.0'
    skill=read('SKILL.md')
    for t in ['NARRATIVE_ENGINE','COMBAT_ENGINE','STYLE_ENGINE','REFERENCE_ROUTER','SHOT_GRAPH']:
        assert t in skill

def test_source_forensics_excludes_overlays():
    t=read('references/source-forensics.md').lower()
    for word in ['overlay','watermark','subtitle','danmaku','player ui']:
        assert word in t
    assert 'exclusion masks' in t

def test_story_requires_goal_consequence_state_change():
    t=read('references/narrative-engine.md')
    for k in ['scene goal','causal','consequence','state change','INFERRED_CONNECTIVE_TISSUE']:
        assert k in t

def test_combat_has_contact_occlusion_and_separate_trajectories():
    t=read('references/combat-engine.md')
    for k in ['contact event','impact frame','camera trajectory','subject trajectory','occlusion','re-entry','identity swap','pose','depth','canny']:
        assert k in t

def test_style_fingerprint_isolated_from_identity():
    t=read('references/style-engine.md')
    for k in ['STYLE_FINGERPRINT','shape language','edge hierarchy','does not own character identity']:
        assert k in t

def test_failure_codes_cover_major_breaks():
    t=read('references/failure-codes.md')
    for k in ['ID_DRIFT','ROLE_SWAP','ACTION_BREAK','CONTACT_FLOAT','AXIS_BREAK','STYLE_DRIFT','EFFECT_PRECAUSE','STATE_RESET','OVERLAY_LEAK','REF_CONFLICT']:
        assert k in t

def test_good_sequence_passes_lint():
    d=json.loads(read('tests/fixtures/good_combat_sequence.json'))
    assert seq.lint(d)==[]

def test_bad_sequence_fails_multiple_contracts():
    d=json.loads(read('tests/fixtures/bad_combat_sequence.json'))
    errors=seq.lint(d)
    joined='\n'.join(errors)
    assert len(errors)>=8
    assert 'missing style_fingerprint' in joined
    assert 'duplicate actor_id' in joined
    assert 'missing contact event' in joined
    assert 're-entry contract' in joined

def test_gate_score_pass_and_fatal_blocker():
    good=json.loads(read('tests/fixtures/good_score.json'))
    bad=json.loads(read('tests/fixtures/bad_score.json'))
    ok,total,reasons=gate.score(good)
    assert ok and total>=8.8 and not reasons
    ok,total,reasons=gate.score(bad)
    assert not ok and any('ROLE_SWAP' in x for x in reasons)

def test_manifest_script_hashes_assets(tmp_path):
    asset=tmp_path/'identity.bin'; asset.write_bytes(b'anchor')
    out=tmp_path/'manifest.json'
    p=subprocess.run([sys.executable,str(ROOT/'scripts'/'make_manifest.py'),'--shot-id','S1','--project','demo','--seed','42','--asset',f'IDENTITY={asset}','--out',str(out)],capture_output=True,text=True)
    assert p.returncode==0, p.stdout+p.stderr
    d=json.loads(out.read_text())
    assert d['seed']==42
    assert len(d['assets'][0]['sha256'])==64

def test_v1_baseline_requirements_now_present():
    alltxt='\n'.join(p.read_text(encoding='utf-8') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.md','.json','.py'})
    groups=[
        ['overlay','watermark','subtitle'], ['causal','scene goal','state change'], ['contact event','attacker','defender','impact frame'],
        ['occlusion','re-entry','identity swap'], ['camera trajectory','subject trajectory'], ['STYLE_FINGERPRINT','shape language','edge hierarchy'],
        ['REFERENCE_ROUTER','pose','depth','canny'], ['SHOT_GRAPH','predecessor','successor'], ['ID_DRIFT','ACTION_BREAK','STYLE_DRIFT'],
        ['manifest','seed','hash'], ['role_id','actor_id','screen_slot'], ['NARRATIVE_REBUILD','MUSIC_REBUILD']]
    for group in groups:
        assert all(k in alltxt for k in group), group
