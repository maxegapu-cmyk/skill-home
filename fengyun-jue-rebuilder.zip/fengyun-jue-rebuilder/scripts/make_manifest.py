#!/usr/bin/env python3
import argparse, hashlib, json
from pathlib import Path

def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--shot-id', required=True)
    ap.add_argument('--project', required=True)
    ap.add_argument('--seed', type=int)
    ap.add_argument('--asset', action='append', default=[], help='ROLE=PATH')
    ap.add_argument('--out', required=True)
    a=ap.parse_args()
    assets=[]
    for spec in a.asset:
        role,path=spec.split('=',1); p=Path(path)
        assets.append({'path':str(p),'role':role,'sha256':sha256(p)})
    out={'project':a.project,'skill_version':'2.0.0','shot_id':a.shot_id,'seed':a.seed,'assets':assets}
    Path(a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS:',a.out)
if __name__=='__main__': main()
