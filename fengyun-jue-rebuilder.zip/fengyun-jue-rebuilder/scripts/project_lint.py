#!/usr/bin/env python3
import json, sys
from pathlib import Path

VALID_MODES={"CHARACTER_ASSET","SHOT_REPLICA","NARRATIVE_REBUILD","COMBAT_REBUILD","MUSIC_REBUILD","TRAILER_REBUILD","SEQUENCE_REPLICA","MV_REBUILD"}

def lint(data):
    e=[]
    for k in ("project_name","mode","target_style_source","characters_in_scope"):
        if not data.get(k): e.append(f"missing/empty: {k}")
    if data.get("mode") not in VALID_MODES: e.append("invalid mode")
    if data.get("mode") in {"MUSIC_REBUILD","MV_REBUILD"} and data.get("audio_source")=="licensed existing" and not data.get("audio_rights_confirmed",False):
        e.append("licensed existing audio selected but audio_rights_confirmed is false")
    return e

def main():
    if len(sys.argv)!=2:
        print("usage: project_lint.py project.json"); return 2
    data=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    e=lint(data)
    if e:
        print("FAIL"); [print("-",x) for x in e]; return 1
    print("PASS: project contract")
    return 0

if __name__=="__main__": raise SystemExit(main())
