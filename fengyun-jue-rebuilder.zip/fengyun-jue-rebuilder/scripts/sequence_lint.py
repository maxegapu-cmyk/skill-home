#!/usr/bin/env python3
import json, sys
from pathlib import Path

FIGHT_MODES={"COMBAT_REBUILD"}

def lint(d):
    e=[]
    if not d.get("style_fingerprint"): e.append("missing style_fingerprint")
    scenes=d.get("scenes",[]); shots=d.get("shots",[])
    if not scenes: e.append("no scenes")
    if not shots: e.append("no shots")
    for s in scenes:
        for k in ("scene_id","scene_goal","causal_consequence","state_change"):
            if not s.get(k): e.append(f"scene {s.get('scene_id','?')} missing {k}")
    ids=[s.get("shot_id") for s in shots]
    if len(ids)!=len(set(ids)): e.append("duplicate shot_id")
    by={s.get("shot_id"):s for s in shots}
    for i,s in enumerate(shots):
        sid=s.get("shot_id","?")
        for k in ("first_state","end_state","camera_trajectory","subject_trajectories","reference_router"):
            if not s.get(k): e.append(f"shot {sid} missing {k}")
        actors=s.get("actors",[])
        if actors:
            for a in actors:
                for k in ("actor_id","role_id","screen_slot"):
                    if not a.get(k): e.append(f"shot {sid} actor missing {k}")
            aids=[a.get("actor_id") for a in actors]
            if len(aids)!=len(set(aids)): e.append(f"shot {sid} duplicate actor_id")
        pred=s.get("predecessor"); succ=s.get("successor")
        if pred is not None and pred not in by: e.append(f"shot {sid} predecessor missing: {pred}")
        if succ is not None and succ not in by: e.append(f"shot {sid} successor missing: {succ}")
        if succ in by and by[succ].get("predecessor")!=sid: e.append(f"shot {sid}->{succ} graph mismatch")
        if succ in by and s.get("end_state") != by[succ].get("first_state") and not s.get("handoff_explanation"):
            e.append(f"shot {sid}->{succ} handoff mismatch without explanation")
        refs=s.get("reference_router",[])
        seen_refs=set()
        for r in refs:
            if not r.get("ref_id") or not r.get("role"): e.append(f"shot {sid} malformed reference_router entry")
            if r.get("ref_id") in seen_refs: e.append(f"shot {sid} duplicate ref_id {r.get('ref_id')}")
            seen_refs.add(r.get("ref_id"))
        if s.get("is_combat"):
            if not s.get("fight_map_id"): e.append(f"combat shot {sid} missing fight_map_id")
            if s.get("physical_contact") and not s.get("contact_events"): e.append(f"combat shot {sid} missing contact event")
            for c in s.get("contact_events",[]):
                for k in ("attacker","defender","impact_frame","state_delta"):
                    if not c.get(k): e.append(f"shot {sid} contact event missing {k}")
        if s.get("occlusion") and not s.get("re_entry_contract"): e.append(f"shot {sid} occlusion missing re-entry contract")
    return e

def main():
    if len(sys.argv)!=2:
        print("usage: sequence_lint.py sequence.json"); return 2
    d=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    e=lint(d)
    if e:
        print("FAIL"); [print("-",x) for x in e]; return 1
    print("PASS: sequence contracts")
    return 0

if __name__=="__main__": raise SystemExit(main())
