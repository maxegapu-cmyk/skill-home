#!/usr/bin/env python3
import json, sys
from pathlib import Path
WEIGHTS={"identity":20,"costume_prop":10,"action_readability":15,"combat_contact":10,"camera":10,"style":15,"light_environment":5,"continuity":10,"narrative":5}
FLOORS={"identity":9.0,"costume_prop":9.0,"action_readability":8.5,"combat_contact":8.5,"camera":8.5,"style":8.5,"light_environment":8.0,"continuity":8.5,"narrative":8.0}
FATAL={"OVERLAY_LEAK","ID_DRIFT","ROLE_SWAP","PROP_SWAP","ACTION_BREAK","CONTACT_FLOAT","AXIS_BREAK","STYLE_DRIFT","EFFECT_PRECAUSE","STATE_RESET"}

def score(d):
    scores=d.get("scores",{}); blockers=set(d.get("blockers",[]))
    unknown=set(WEIGHTS)-set(scores)
    if unknown: return False,0,[f"missing score: {x}" for x in sorted(unknown)]
    total=sum(float(scores[k])*w for k,w in WEIGHTS.items())/100
    reasons=[]
    for k,f in FLOORS.items():
        if float(scores[k])<f: reasons.append(f"{k} below floor {f}")
    for b in sorted(blockers & FATAL): reasons.append(f"fatal blocker: {b}")
    if total<8.8: reasons.append("weighted score below 8.8")
    return not reasons,total,reasons

def main():
    if len(sys.argv)!=2: print("usage: gate_score.py score.json"); return 2
    d=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    ok,total,reasons=score(d)
    print(("PASS" if ok else "FAIL"), f"weighted={total:.2f}")
    [print("-",r) for r in reasons]
    return 0 if ok else 1
if __name__=="__main__": raise SystemExit(main())
