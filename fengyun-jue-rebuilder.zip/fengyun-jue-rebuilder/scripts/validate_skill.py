from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
required_files=[
"VERSION","SKILL.md","README.md",
"references/master-workflow.md","references/source-forensics.md","references/source-analysis.md","references/narrative-engine.md","references/style-engine.md","references/combat-engine.md","references/shot-graph.md","references/reference-routing.md","references/continuity-engine.md","references/render-routing.md","references/failure-codes.md","references/mv-workflow.md","references/qa-rubric.md","references/public-research-notes.md","references/seedance-2x-adapter.md",
"templates/project-brief.md","templates/sequence-plan.md","templates/character-card.md","templates/style-fingerprint.md","templates/scene-card.md","templates/fight-map.md","templates/shot-card.md","templates/continuity-ledger.md","templates/image-prompt.md","templates/video-prompt.md",
"scripts/project_lint.py","scripts/sequence_lint.py","scripts/gate_score.py","scripts/make_manifest.py",
"schemas/project.schema.json","schemas/sequence.schema.json"]
terms=["NARRATIVE_ENGINE","COMBAT_ENGINE","STYLE_ENGINE","CHARACTER_LOCK","STYLE_FINGERPRINT","SCENE_STATE","SHOT_GRAPH","REFERENCE_ROUTER","CONTINUITY_STATE","contact event","camera trajectory","subject trajectory","ID_DRIFT","ROLE_SWAP","ACTION_BREAK","STYLE_DRIFT"]
errors=[]
for rel in required_files:
    if not (ROOT/rel).exists(): errors.append('missing file: '+rel)
text=(ROOT/'SKILL.md').read_text(encoding='utf-8') if (ROOT/'SKILL.md').exists() else ''
if not text.startswith('---\n'): errors.append('SKILL.md missing YAML frontmatter')
if 'description: Use when' not in text: errors.append("description must start with 'Use when'")
alltxt='\n'.join(p.read_text(encoding='utf-8') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.md','.py','.json'})
for t in terms:
    if t not in alltxt: errors.append('missing contract term: '+t)
if errors:
    print('FAIL'); [print('-',e) for e in errors]; sys.exit(1)
print('PASS: v2 skill structure and contracts present')
