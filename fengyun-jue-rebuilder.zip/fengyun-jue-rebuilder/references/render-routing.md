# Render routing

Choose the least complex path that can preserve the required invariants.

| Problem | Preferred route |
|---|---|
| face/style wrong, pose/composition already right | image edit / local edit |
| exact identity, new simple motion | canonical image -> image-to-video |
| exact first and last pose/state | first/last-frame interpolation if supported |
| exact choreography, new actor/look | motion/pose/depth/canny donor + canonical identity |
| exact camera path, new subject | camera control / camera donor only |
| long multi-shot sequence | approved storyboard/anchors + per-shot generation + edit |
| small defect in accepted video | local video edit; freeze unaffected beats |
| dialogue/reaction | simple reference-to-video or edit; avoid unnecessary motion controls |

A control stack is not automatically better. Every extra controller can create reference conflict. Add one only when it owns a failure that text/reference alone cannot reliably constrain.

For Seedance-like multimodal systems, map canonical identity, motion donor, style reference, and accepted previous clip to distinct reference roles. Provider syntax and limits change; verify the active product before hard-coding counts or tags.
