# Narrative engine

## Purpose
Reconstruction is not a gallery of pretty frames. Every retained scene must carry information, alter a relationship, change tactical state, or change the audience's expectation.

## Scene causal contract
Every `NARRATIVE_REBUILD` scene records:
1. BEFORE — relevant state entering the scene;
2. scene goal — what a principal actor wants now;
3. obstacle — what blocks that goal;
4. decision — the meaningful choice;
5. action — what the choice causes;
6. consequence — immediate causal result;
7. emotional turn — whose interpretation changes;
8. `state change` — what is objectively different AFTER.

Use explicit `causal` links: event B occurs because of A, not merely after A.

## Fidelity levels
- `EXACT`: reconstruct the observed scene order and intent; invented connective detail must be visually conservative.
- `COMPRESSED`: preserve causal spine while removing redundant beats.
- `RESTAGED`: preserve character/objective/consequence but redesign shot language.
- `MUSIC`: visual order may follow musical architecture, but character and event continuity must remain internally coherent.

Never present inferred missing canon as verified source fact. Tag it `INFERRED_CONNECTIVE_TISSUE`.

## Scene-to-shot rule
A shot must do at least one job: establish, reveal, decide, act, react, transition, or resolve. If it does none, cut it.

For action scenes, story objective owns choreography: characters fight to get, protect, escape, delay, test, punish, or survive something. Choreography without objective becomes demo-reel motion.
