# Feng Yun Jue — source analysis for reconstruction

## Verified production traits

Public production interviews and archive material consistently describe the film as a realism-leaning wuxia animation built primarily from 2D drawing with selected 3D backgrounds/effects.

Useful reconstruction implications:

- Human anatomy is grounded rather than super-deformed.
- Production staff cited roughly 7.5–8.5 heads for hero proportions.
- Character likeness had to survive strong perspective changes.
- Action was often staged by real martial performers, filmed, then used as drawing reference.
- The film favors dense action coverage and many camera angles rather than one long generic action shot.
- Character expressions remain controlled; identity is strongly carried by brow, face shape, hair silhouette, costume silhouette, and posture.
- 2D characters and 3D environments/effects were integrated through matched light, color, depth, and perspective.

## Character reconstruction logic

The film's heroes should not be reduced to generic labels such as “handsome ancient Chinese warrior.” Their recognizability comes from specific design topology.

For each character build a reference set containing, when available:

- official design image;
- neutral close-up;
- 3/4 close-up;
- profile;
- full body;
- action pose;
- one high-emotion frame;
- outfit-specific shot.

Do not infer hidden costume details from one frame if another official frame shows them.

## Observed visual identity cues from supplied/user references and public stills

These are not complete character sheets; they are examples of what to lock.

### White/silver-haired hero configuration

- very high-value long hair with large flowing trailing mass;
- strong dark eyebrow / eye contrast;
- layered cool blue/gray clothing;
- red scarf/ribbon accent appears as a major silhouette/color cue in some designs;
- long fabric and hair create large directional motion arcs.

### Dark/blue-haired hero configuration

- compact, angular hair silhouette;
- heavier warm/cool costume block contrast;
- strong shoulder/chest silhouette;
- controlled severe brow and jaw structure;
- costume accents must not be borrowed from the silver-haired hero.

### Antagonist / supporting designs

Keep them isolated by hair topology, face geometry, costume silhouette, and color-block map. Never rely on hair color alone.

## Scene-language traits worth preserving in reconstruction

- martial action remains readable at the contact point;
- attacks have anticipation and recoil;
- cloth, hair, cloud, water, wind, debris, and weapon arcs amplify movement;
- backgrounds often provide depth planes for speed and scale;
- supernatural effects extend a physical action rather than replacing it;
- big techniques frequently receive a setup shot, release shot, impact shot, and reaction/aftermath shot.

## Public source trail used for this analysis

- Hong Kong Film Archive programme entry for Feng Yun Jue / Storm Rider: Clash of the Evils.
- Sina Entertainment 2008 Feng Yun Jue archive: character design images and production interviews.
- Interviews with animation/action directors Wu Zhixing and Huang Licheng describing live-action martial reference, anatomy, perspective, and drawing workflow.
- Contemporary feature coverage discussing 2D drawing plus 3D backgrounds/effects and dense action coverage.

