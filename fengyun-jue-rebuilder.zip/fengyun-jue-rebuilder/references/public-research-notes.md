# Public research notes — principles absorbed, not dependencies

This skill is original orchestration. The following public projects/papers were reviewed for useful production ideas; none is required to run the skill.

- HVision-NKU/StoryDiffusion — long-range character consistency suggests treating sequence identity as a persistent constraint, not a per-shot prompt accident.
  https://github.com/HVision-NKU/StoryDiffusion
- maosika-ai/reshot — useful separation of motion/camera/spatial structure from actor identity/style through depth/pose/canny control videos.
  https://github.com/maosika-ai/reshot
- seunghyuns98/TriMotion — reinforces camera control as a distinct condition rather than an adjective mixed into action prose.
  https://github.com/seunghyuns98/TriMotion
- tkottke90/comfyui-character-workflow — useful anchor/gate concept: canonical hero image, face crop, view expansion, human gates.
  https://github.com/tkottke90/comfyui-character-workflow
- artokun/comfyui-mcp director skill — practical hero/reference/edit-chain pattern for multi-shot consistency.
  https://github.com/artokun/comfyui-mcp
- divolleggett/awesome-character-consistency — useful storyboard-first reference strategy and survey of consistency methods.
  https://github.com/divolleggett/awesome-character-consistency
- chaojie/ComfyUI-MotionCtrl — demonstrates separate camera and trajectory control concepts in video workflows.
  https://github.com/chaojie/ComfyUI-MotionCtrl

Adopted principle: references have roles, motion is separable from appearance, and long sequences need persistent state plus gates. Model-specific claims are kept out of the core workflow.

- Emily2040/seedance-2.0 and fal-ai/seedance-2.0-api — current public reference-role and multimodal routing examples informed the optional Seedance adapter, not the core contracts.
  https://github.com/Emily2040/seedance-2.0
  https://github.com/fal-ai/seedance-2.0-api
- zetagao/frameline — useful scene-level shot-table and overhead blocking/floor-plan idea; v2 applies the same production principle to fight arena maps.
  https://github.com/zetagao/frameline
- BitraAI/ai-film-director — reinforces stage IDs/schemas and validation boundaries across story -> assets -> storyboard -> video.
  https://github.com/BitraAI/ai-film-director
