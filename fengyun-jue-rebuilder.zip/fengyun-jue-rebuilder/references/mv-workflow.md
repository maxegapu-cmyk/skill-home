# MUSIC_REBUILD / MV workflow

Legacy alias: `MV_REBUILD`.

Build four maps before selecting shots:
1. audio structure: sections, phrase boundaries, energy, rests;
2. narrative map: what the audience learns or feels in each section;
3. character map: whose POV/relationship owns the section;
4. visual map: shot size, motion intensity, action density, motif, transition.

Do not cut every beat. Use phrase-level rhythm and deliberate counterpoint.

A chorus peak should be earned by prior visual restraint. Reserve the largest effects, fastest camera, widest scale, or signature technique for a planned peak rather than spending them in the intro.

If using an existing copyrighted track, use audio only when the user has appropriate rights for the intended release. Analyze timing/structure from supplied audio without reproducing unsupplied lyrics.

`MUSIC_REBUILD` may reorder images for musical logic, but continuity within any presented fight or story micro-sequence still follows actor/state locks.
