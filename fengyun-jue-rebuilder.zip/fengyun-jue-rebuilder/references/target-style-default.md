# Default target style

Use only when the user does not supply a newer target reference. It is deliberately generic and replaceable.

- hand-drawn 2D illustration / animation finish;
- fine tapered non-uniform contours; stronger silhouette/overlap edges than internal detail;
- matte watercolor/marker-like fills with restrained cel-shadow grouping;
- chromatic darks, controlled saturation, no universal crushed black;
- material-specific highlights instead of plastic/wet shine everywhere;
- modest texture/grain and slight hand-drawn asymmetry;
- no generic HDR bloom, oversharpening, greasy AI sheen, or sterile vector finish.

This file never owns identity, camera, story, costume, weather, or scene lighting direction.
