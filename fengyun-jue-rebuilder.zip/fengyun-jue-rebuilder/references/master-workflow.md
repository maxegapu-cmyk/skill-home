# Master workflow — story × combat × style

## Ownership law
Four owners prevent prompt conflict:
- **Identity owner**: CHARACTER_LOCK owns who the actor is.
- **Narrative owner**: NARRATIVE_ENGINE owns why the scene/beat happens and what changes.
- **Combat owner**: COMBAT_ENGINE owns physical action, spacing, contact, force and tactical consequence.
- **Style owner**: STYLE_ENGINE owns rendering language only.

Camera is negotiated between narrative readability and combat spatial clarity; it never owns identity or action outcome.

## Production passes

### Pass 0 — Brief / fidelity
Choose mode and fidelity: EXACT, COMPRESSED, RESTAGED, or MUSIC. Define aspect ratio, duration, public/private use and target-style source.

### Pass 1 — Source forensics
Build SOURCE_MAP. Remove non-diegetic overlay evidence. Separate certain/probable/unknown facts. Create clean crops/contact sheet when useful.

**Gate:** no contaminated screenshot may become the only authority for a hidden face/costume detail.

### Pass 2 — Canonical cast / props
Build CHARACTER_LOCK per actor plus costume/prop cards. Assign immutable actor_id and role_id. Pick canonical hero, face crop, full body and silhouette references.

**Gate:** front/3-4/profile + full-body + one difficult expression/action view must remain recognizably the same actor.

### Pass 3 — STYLE_FINGERPRINT
Extract recurring style behavior from multiple target references. Separate content from rendering. Define what must never transfer from style donors.

**Gate:** target look can be described without mentioning the donor character's identity, costume or pose.

### Pass 4 — Story spine
For each scene write BEFORE, scene goal, obstacle, decision, causal consequence, emotional turn and state change. Mark unverified connective material as inference.

**Gate:** every non-connective scene changes information, relationship, tactic, emotion or physical state.

### Pass 5 — Previsualization / floor plan
For dialogue/action scenes, draw or describe an overhead blocking map: arena/set boundaries, actor positions, line of action, entrances/exits, hazards, camera zones.

**Gate:** someone reading the map can answer “where is everybody and which way are they facing?” before images are generated.

### Pass 6 — Fight design
For combat, create FIGHT_MAP: objectives, distance graph, trajectories, beats, contact events, recoil, damage, occlusion/re-entry and VFX cause path.

**Gate:** every major hit has a believable pre-contact path and post-contact consequence.

### Pass 7 — SHOT_GRAPH
Convert scene/fight beats to shots. Each node has predecessor/successor, narrative job, first/end state, camera trajectory, subject trajectories and handoff contract.

**Gate:** adjacent end/first states match or have an explicit explanation.

### Pass 8 — REFERENCE_ROUTER + render route
Assign one primary role to every reference. Choose simplest render path that can preserve the required invariants. Add pose/depth/canny/camera control only when it solves a known control problem.

**Gate:** no unresolved reference ownership conflict.

### Pass 9 — Keyframe proof
Generate/construct the still before motion. Test identity, costume/prop, pose, composition, environment and style in that order.

**Gate:** still passes visual QA; video is not used to hide a bad keyframe.

### Pass 10 — Atomic video
Generate the smallest coherent action unit. Separate subject trajectories, camera trajectory, secondary motion and effect causality. Record exact end state.

**Gate:** required contact and identity survive motion; no fatal blocker.

### Pass 11 — Continuity / edit
Update CONTINUITY_STATE. Chain accepted end state forward. Repair local failures locally. Assemble shots with screen-direction, eyeline, energy and shot-size rhythm checks.

### Pass 12 — Final sequence audit
Audit story clarity, identity persistence, combat readability, style consistency, effect timing and continuity. Store manifest with accepted parent, model/provider, prompt version, seed if available and asset SHA-256 hashes.

## Arbitration when engines disagree
1. Canonical source fact beats inferred restaging.
2. Identity/design invariants beat style donor content.
3. Narrative outcome beats decorative choreography.
4. Physical continuity beats flashy camera motion.
5. A readable contact beats denser VFX.
6. Accepted continuity state beats a fresh random variation.
7. Local repair beats full reroll when only one layer is broken.
