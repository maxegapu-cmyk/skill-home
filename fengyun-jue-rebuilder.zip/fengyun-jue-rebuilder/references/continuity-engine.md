# Continuity engine

`CONTINUITY_STATE` is a persistent ledger, not prose memory.

Track by actor and environment:
- `actor_id`, current `role_id`, screen_slot, facing, location;
- pose/action phase and velocity;
- expression/emotional state;
- costume state and damage;
- weapon/prop hand, orientation and damage;
- hair wetness/disarray;
- blood/dirt/water/scratches if present;
- injuries and mobility changes;
- effect residue;
- environment breakage, debris, fire/water/wind state;
- camera phase if continuing the same shot;
- unresolved story promises.

After an accepted shot, write only state deltas plus a full resolved snapshot. The next shot inherits the snapshot.

If a later shot must intentionally reset state (flashback, dream, costume change, time jump), state the transition explicitly; otherwise a reset is `STATE_RESET`.
