# Shot graph and handoff contracts

## SHOT_GRAPH
Each shot node contains:
- `shot_id`;
- `predecessor` and `successor`;
- narrative job;
- first state;
- end state;
- camera trajectory;
- subject trajectories;
- reference assignments;
- continuity in/out;
- accepted parent / anchor frame.

## Handoff invariant
For consecutive shots A -> B:
`A.end_state == B.first_state` for all unchanged facts.
Permitted differences must be explained by the cut or by an on-screen event.

Track at minimum:
- actor presence, `actor_id`, screen side and facing;
- pose phase and velocity;
- weapon hand/state;
- injury/dirt/wetness/damage;
- hair/clothing state;
- environment state;
- effect residue;
- time/light;
- emotional state.

A continuity reset with no cause is `STATE_RESET`.

## Anchor strategy
Use a canonical hero frame for immutable design. Use accepted previous footage/frame for transient state. The transient anchor cannot overwrite immutable identity.

For alternative takes, branch from the same accepted predecessor. Once an edit is chosen, the final cut becomes linear and the ledger follows that branch only.
