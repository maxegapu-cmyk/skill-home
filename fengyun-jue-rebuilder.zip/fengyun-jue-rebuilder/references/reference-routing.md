# REFERENCE_ROUTER

Assign every asset one primary role before writing a generation prompt.

Allowed roles:
- `IDENTITY`: face, hair silhouette, body identity;
- `COSTUME`: garment/armor topology and color blocks;
- `PROP`: weapon or object geometry;
- `STYLE`: rendering behavior only;
- `ENVIRONMENT`: location geometry / atmosphere;
- `POSE`: body/joint arrangement;
- `DEPTH`: spatial geometry / camera-relative depth;
- `CANNY`: coarse edge/composition control;
- `MOTION`: choreography / gesture timing;
- `CAMERA`: camera trajectory / pace;
- `FIRST_FRAME`, `LAST_FRAME`;
- `CONTINUITY`: accepted previous output state;
- `AUDIO_TIMING`: rhythm / time structure.

## Conflict rule
If two references claim the same property, choose an owner. Do not average.

Examples:
- identity image owns face; motion video owns choreography;
- target-style frame owns line/color; source shot owns camera/blocking;
- previous accepted clip owns opening transient state; canonical identity pack still owns face/costume identity.

## REFERENCE_ROUTER output
For every asset: `ref_id`, primary role, allowed transfer, forbidden transfer, confidence, crop/mask, and whether it is canonical or transient.
