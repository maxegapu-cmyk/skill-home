# QA rubric 2.0

## Fatal blockers
Any one blocks approval:
`OVERLAY_LEAK`, `ID_DRIFT` on a hero, `ROLE_SWAP`, `PROP_SWAP` affecting action, impossible anatomy, `ACTION_BREAK`, `CONTACT_FLOAT` at a required hit, unintended `AXIS_BREAK`, severe `STYLE_DRIFT`, `EFFECT_PRECAUSE`, unexplained `STATE_RESET`, or a source-fidelity claim based only on unverified inference.

## Shot score
| Dimension | Weight | Floor |
|---|---:|---:|
| Character identity | 20 | 9.0 |
| Costume / prop | 10 | 9.0 |
| Pose / action readability | 15 | 8.5 |
| Combat contact/physics when applicable | 10 | 8.5 |
| Composition / camera | 10 | 8.5 |
| Target style | 15 | 8.5 |
| Light / environment | 5 | 8.0 |
| Continuity / handoff | 10 | 8.5 |
| Narrative function | 5 | 8.0 |

Target weighted score >= 8.8 and no fatal blocker.

## Sequence gates
- no unresolved shot-graph handoff mismatch;
- no unexplained actor disappearance/re-entry;
- no identity swap after occlusion;
- action objective remains understandable;
- energy curve has contrast rather than permanent maximum intensity;
- style variance stays inside fingerprint tolerance;
- story scenes have a meaningful state change or are intentionally marked connective.

## Failure diagnosis
Return:
1. failure code;
2. visible symptom;
3. owning layer;
4. smallest correction;
5. frozen layers;
6. whether regeneration is required or a local edit is enough.
