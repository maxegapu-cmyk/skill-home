# Style engine

## STYLE_FINGERPRINT
Extract style as repeated rendering behavior, not subject matter. Use 6–12 target frames when possible and record consensus plus variance.

Dimensions:
- `shape language`: angular/rounded, proportion tendencies, silhouette simplification;
- `edge hierarchy`: silhouette vs overlap vs internal-detail strength;
- line cadence: tapered, broken, clean, dry, pencil-like, brush-like;
- value design: number/width of value groups, black-point behavior;
- palette relationships: temperature, chroma, neutral strategy;
- shadow design: hard/soft, grouped/graded, local occlusion;
- material response: matte/satin/specular by material class;
- environment abstraction: painted detail vs simplified planes;
- VFX vocabulary: cloud, wind, water, particles, glow, streaks, smears;
- atmospheric depth;
- texture / grain;
- detail zoning: face/hands/weapon/background priority;
- motion marks / smear language;
- compositing finish.

## Isolation rules
STYLE_FINGERPRINT does not own character identity, costume, pose, camera, weather, location, story state, or weapon geometry.

If a style reference contains a different character, that character's face, hair and clothes are explicitly excluded from transfer.

## Edge test
Thumbnail the frame. Character recognition should survive even if color is removed. Then blur internal details. If identity disappears, the character lock is weak; do not blame style.

## Drift repair
`STYLE_DRIFT` → compare the failed shot against two accepted shots and the fingerprint. Correct only the failing dimensions. Do not rewrite identity or blocking.
