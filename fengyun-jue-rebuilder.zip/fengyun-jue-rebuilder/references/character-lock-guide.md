# Character lock guide

A character must survive front/3-4/profile, close/full body, calm/high emotion, foreshortening, occlusion/re-entry and style transfer.

Lock geometry relationships, hair silhouette, body proportions, costume topology, props and a drift blacklist. Use a stable `actor_id` and `role_id`; `screen_slot` is transient and never defines identity. Canonical identity references are immutable; accepted previous frames/clips own only transient continuity state.
