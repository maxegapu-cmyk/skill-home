# Combat engine

## Principle
A fight is a causal exchange of intentions, trajectories, contacts and consequences. Supernatural effects extend physical action; they do not replace readable action.

## FIGHT_MAP
Record:
- arena geometry and hazards;
- `actor_id`, `role_id`, `screen_slot` for every participant;
- objective and tactical constraint for each actor;
- facing, lead side, stance, current velocity;
- weapon/prop state;
- camera side of axis;
- distance graph between actors;
- technique / power state;
- injury/fatigue state.

## Atomic beat
`read/intend -> weight shift -> initiation -> acceleration -> contact/evasion -> force transfer -> recoil -> recovery -> next intention`.

Not every shot shows all stages, but the sequence must make the chain inferable.

## Contact event contract
Every physical `contact event` states:
- attacker `actor_id` and attacking limb/weapon;
- defender `actor_id` and target region;
- pre-contact distance / approach vector;
- `impact frame` or impact window;
- defender response and displacement vector;
- attacker recoil/follow-through;
- damage / state delta;
- debris, cloth, hair, water or environment response after contact.

If a hit looks like two independent animations crossing, mark `CONTACT_FLOAT`.

## Camera / subject separation
Record one `camera trajectory` and one `subject trajectory` per actor. Camera movement never substitutes for actor motion. Do not write “dynamic camera and fast action” as one instruction.

## Axis handling
An axis crossing is allowed only when motivated and legible. Bridge it with neutral angle, visible camera travel, or an unmistakable spatial reset. Accidental left/right reversal is `AXIS_BREAK`.

## Occlusion and re-entry
Before occlusion, retain actor identity by `actor_id`, costume, silhouette and trajectory. On `re-entry`, restore the same actor to the predicted trajectory/state. A character returning with the other character's face/costume is `identity swap` / `ROLE_SWAP`.

## Motion-donor route
When a donor clip has the desired fight or camera:
- extract or transfer `pose`, `depth`, `canny`, trajectory, or timing when supported;
- the donor controls motion/staging only;
- explicitly exclude donor face, costume, environment, lighting and style unless separately authorized;
- prefer simple, readable donor motion to noisy multi-person footage.

## Power / VFX causality
Body or weapon cause first; effect growth second; travel third; impact fourth; residue last. Effect visible before its cause is `EFFECT_PRECAUSE`.

## Complexity rule
Two-character fast exchanges default to 1.5–4 s atomic shots. Three-plus fighters are decomposed into readable local exchanges unless the model has been proven on the exact complexity.
