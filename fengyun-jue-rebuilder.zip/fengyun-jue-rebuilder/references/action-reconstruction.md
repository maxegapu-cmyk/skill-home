# Action reconstruction — compatibility entry

The v2 combat authority is `combat-engine.md` plus `shot-graph.md` and `continuity-engine.md`.

Minimum action contract: intention -> weight shift -> initiation -> acceleration -> contact/evasion -> force transfer -> recoil -> recovery. For physical hits, use an explicit `contact event`. Keep `camera trajectory` separate from each `subject trajectory`. Effects follow physical cause.
