# Seedance 2.x adapter — optional

The core skill is model-agnostic. Use this adapter when the active Seedance 2.x surface supports multimodal references.

## Asset-role translation
- canonical character image -> identity reference;
- outfit/weapon detail -> costume/prop reference;
- approved first frame -> first-frame / opening-state reference;
- target-style image -> style reference only;
- donor video -> choreography OR camera role, explicitly named;
- pose/depth/canny control video -> geometry/motion role only;
- previous accepted clip -> continuity / extend / edit source;
- audio -> timing/energy only unless dialogue/voice is intentionally owned.

## Prompt contract
State each reference's job next to the reference token used by the current provider. Example logic:

`identity-image owns face/hair/costume; motion-video owns choreography only; style-image owns line/color/material only; previous accepted clip owns transient opening state.`

Then state forbidden transfer from each donor. Never write “use all references for style.”

## Fight route
1. approve a clean identity keyframe;
2. if choreography is hard to describe, use a simple donor or extracted pose/depth/canny clip;
3. keep camera role separate from body motion when possible;
4. generate one atomic exchange, not the whole duel;
5. accept/reject at the contact event and end-state gate;
6. feed the accepted end state to the next shot.

## Edit/extend route
When the active endpoint supports edit or extend, prefer it for a local defect or a continuous extension. Preserve good regions/beats and name only the failed property. Do not regenerate a whole accepted sequence to fix one sleeve, face frame, or VFX timing error.

## Version caution
Reference counts, token syntax, duration limits and endpoint names vary by provider and release. Verify the active UI/API before hard-coding them into a project manifest.
