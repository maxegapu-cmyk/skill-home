# Source forensics

## Goal
Separate evidence that belongs to the film image from contamination introduced by playback, upload, compression, fan edits, or screenshots.

## SOURCE_MAP fields
For every source frame record:
- source_id, scene/shot estimate, time if known;
- characters and `actor_id` confidence;
- angle and crop;
- diegetic content confidence;
- `overlay` regions: subtitle, danmaku, watermark, logo, player UI, timestamp, reaction sticker;
- compression / scaling / sharpening artifacts;
- color reliability: HIGH / MEDIUM / LOW;
- geometry reliability: HIGH / MEDIUM / LOW;
- notes on occlusion.

## Overlay rule
Non-diegetic `overlay`, `watermark`, `subtitle`, danmaku, UI and platform text are exclusion masks. They are not typography, composition, line art, palette, texture, or lighting evidence unless the user explicitly asks to reproduce them.

When an overlay covers a face, costume edge or weapon, do not hallucinate the hidden shape from that frame. Use a cleaner source or mark it `UNKNOWN`.

## Evidence order
`official design / clean canonical still > clean same-sequence frame > clean promotional image > contaminated screenshot > textual inference > model guess`.

Conflicts are logged, not averaged. A low-confidence screenshot cannot overwrite a canonical anchor.
