# Failure codes

| Code | Meaning | Repair first |
|---|---|---|
| `OVERLAY_LEAK` | subtitle/danmaku/watermark treated as scene/style | source mask / forensics |
| `REF_CONFLICT` | two assets own the same property | reference router |
| `ID_DRIFT` | face/hair/body identity changes | canonical identity anchor |
| `FACE_MORPH` | identity deforms during motion | shorter shot / stronger first-state identity |
| `COSTUME_DRIFT` | garment topology/colors mutate | costume owner / edit |
| `PROP_SWAP` | weapon/object changes hand or form | prop state / continuity |
| `ROLE_SWAP` | actors exchange identity/role | actor_id + re-entry protocol |
| `ACTION_BREAK` | motion chain becomes discontinuous | atomic beats / shorter shot |
| `CONTACT_FLOAT` | hit has no believable contact/force transfer | contact event contract |
| `AXIS_BREAK` | spatial direction flips unintentionally | axis / bridge shot |
| `CAMERA_TELEPORT` | camera position changes without travel/cut | camera trajectory |
| `STYLE_DRIFT` | rendering language changes | style fingerprint only |
| `LIGHT_DRIFT` | scene illumination changes without cause | shot/environment light state |
| `EFFECT_PRECAUSE` | VFX precedes physical cause | effect timing |
| `STATE_RESET` | damage/pose/weapon/environment resets | continuity ledger |
| `NARRATIVE_FLAT` | scene looks good but changes nothing | narrative engine |

Repair the smallest owning layer and freeze the rest.
