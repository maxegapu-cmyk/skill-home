# Feng Yun Jue Rebuilder v2.0.0

A production-oriented skill for rebuilding *Feng Yun Jue* character assets, story scenes, fights, trailers and music-driven sequences while keeping identity, choreography, story causality and target style independent enough to diagnose and repair.

Read `references/master-workflow.md` first.

## Recommended production path

1. `SOURCE_MAP`: clean evidence; mask subtitle/danmaku/watermark/UI contamination.
2. `CHARACTER_LOCK`: canonical actor identity + costume/prop anchors.
3. `STYLE_FINGERPRINT`: rendering behavior only.
4. `SCENE_STATE`: BEFORE -> goal -> obstacle -> decision -> consequence -> state change.
5. `FIGHT_MAP` for combat: arena, actor trajectories, contact events, effect causality.
6. `SHOT_GRAPH`: predecessor/successor + first/end-state handoffs.
7. `REFERENCE_ROUTER`: one primary job per reference.
8. still keyframe gate -> video -> continuity ledger -> edit.
9. QA by failure code; repair only the owning layer.
10. write a generation manifest with input hashes for accepted shots.

## Core commands

```bash
python scripts/validate_skill.py
python -m pytest tests -q
python scripts/sequence_lint.py tests/fixtures/good_combat_sequence.json
python scripts/gate_score.py tests/fixtures/good_score.json
```

## Why v2 exists

v1 separated identity/staging from style, but lacked explicit story causality, contact-event physics, occlusion/re-entry identity protection, camera-vs-subject trajectories, reference-role routing, shot dependency graphs, failure codes and reproducibility manifests. v2 adds those contracts without tying the workflow to a single generation platform.

Optional platform adapter: `references/seedance-2x-adapter.md`. The core workflow remains platform-agnostic.
