# CHARACTER_LOCK — {{character_name}}

actor_id: {{stable id}}
role_id: {{story role id}}
status: DRAFT | LOCKED
canonical_refs: {{}}
face_crop_ref: {{}}
fullbody_ref: {{}}
silhouette_ref: {{}}

identity:
  face_shape: {{}}
  jaw_chin: {{}}
  eyes_spacing_tilt: {{}}
  brows: {{}}
  nose: {{}}
  mouth: {{}}
  hair_silhouette: {{}}
  hair_internal_structure: {{}}
  skin_value_chroma: {{}}

body:
  apparent_head_ratio: {{}}
  shoulder_waist: {{}}
  habitual_posture: {{}}

costume_default:
  silhouette: {{}}
  color_blocks: {{}}
  collar_scarf: {{}}
  sleeves_cuffs: {{}}
  waist: {{}}
  footwear: {{}}

signature_prop:
  type: {{}}
  geometry: {{}}
  carry_rule: {{}}

forbidden_drift:
  - {{}}

confidence:
  certain: {{}}
  probable: {{}}
  unknown: {{}}
