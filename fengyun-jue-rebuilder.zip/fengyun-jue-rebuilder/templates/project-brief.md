# Project brief

project_name: {{}}
mode: CHARACTER_ASSET | SHOT_REPLICA | NARRATIVE_REBUILD | COMBAT_REBUILD | MUSIC_REBUILD | TRAILER_REBUILD
legacy_alias_if_any: SEQUENCE_REPLICA | MV_REBUILD | none
source: Feng Yun Jue (2008)
fidelity_level: EXACT | COMPRESSED | RESTAGED | MUSIC
target_style_source: {{}}
aspect_ratio: {{}}
resolution: {{}}
frame_rate: {{}}
characters_in_scope: {{}}
sequence_in_scope: {{}}
audio_source: licensed existing | supplied analysis only | replacement | none
release_context: private study | portfolio | public upload | other

success_criteria:
  identity: {{}}
  story: {{}}
  combat: {{}}
  style: {{}}
  continuity: {{}}
  duration: {{}}
