# Video prompt assembly 2.0

## SHOT INTENT
{{one sentence; narrative job + action result}}

## REFERENCES
{{REFERENCE_ROUTER assignments}}

## FIRST FRAME STATE
{{exact inherited state}}

## SUBJECT TRAJECTORIES
{{one per actor_id}}

## ACTION BEATS / CONTACT EVENTS
{{timed intentions, initiation, impact frame/window, force transfer, recoil, state delta}}

## CAMERA TRAJECTORY
{{camera position/path/speed/target; separate from subjects}}

## SECONDARY MOTION
{{hair, cloth, weapon inertia, debris, water, cloud}}

## LIGHT / EFFECT CAUSALITY
{{physical cause -> effect growth -> travel -> impact -> residue}}

## OCCLUSION / RE-ENTRY
{{who can disappear behind what; predicted re-entry state; no identity swap}}

## END FRAME STATE
{{exact handoff target}}

## CONTINUITY
{{CONTINUITY_STATE inherited + allowed deltas}}

## FORBIDDEN FAILURES
No ID_DRIFT, ROLE_SWAP, ACTION_BREAK, CONTACT_FLOAT, AXIS_BREAK, CAMERA_TELEPORT, STYLE_DRIFT, EFFECT_PRECAUSE, STATE_RESET, prop switching, rubber limbs, or unexplained spatial reversal.
