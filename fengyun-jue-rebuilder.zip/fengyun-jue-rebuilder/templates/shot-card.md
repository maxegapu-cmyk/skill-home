# SHOT_LOCK — {{shot_id}}

predecessor: {{shot_id|null}}
successor: {{shot_id|null}}
scene_id: {{}}
narrative_job: establish | reveal | decide | act | react | transition | resolve
source_time: {{}}
duration_target: {{}}

first_state: {{}}
end_state: {{}}
handoff_contract: {{facts that successor must inherit}}

camera:
  shot_size: {{}}
  height_pitch_yaw: {{}}
  camera trajectory: {{}}
  axis_side: {{}}

characters:
  - actor_id: {{}}
    role_id: {{}}
    screen_slot: {{}}
    facing: {{}}
    subject trajectory: {{}}
    pose_start: {{}}
    pose_end: {{}}
    expression: {{}}
    costume_state: {{}}
    prop_state: {{}}

action_beats: {{}}
contact_events: {{}}
secondary_motion: {{}}
lighting_environment: {{}}
reference_assignments: {{}}
must_preserve: {{}}
must_not_change: {{}}
