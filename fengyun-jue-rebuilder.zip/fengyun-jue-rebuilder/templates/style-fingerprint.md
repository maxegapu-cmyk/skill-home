# STYLE_FINGERPRINT

source_refs: {{}}
confidence: {{}}
shape_language: {{}}
edge_hierarchy: {{}}
line_cadence: {{}}
value_design: {{}}
palette_relationships: {{}}
shadow_design: {{}}
material_response: {{}}
environment_abstraction: {{}}
vfx_vocabulary: {{}}
atmospheric_depth: {{}}
texture_grain: {{}}
detail_zoning: {{}}
motion_marks: {{}}
compositing_finish: {{}}

content_to_exclude_from_transfer:
  - face / identity of style-reference subjects
  - their costume and props
  - their pose and camera unless separately assigned
  - {{}}
