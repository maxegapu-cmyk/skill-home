# SCENE_STATE — {{scene_id}}

fidelity_level: EXACT | COMPRESSED | RESTAGED | MUSIC
before: {{}}
scene goal: {{}}
obstacle: {{}}
decision: {{}}
action: {{}}
causal consequence: {{}}
emotional turn: {{}}
state change: {{}}
after: {{}}
canon_status: OBSERVED | VERIFIED_EXTERNAL | INFERRED_CONNECTIVE_TISSUE
must_preserve: {{}}
may_restage: {{}}
