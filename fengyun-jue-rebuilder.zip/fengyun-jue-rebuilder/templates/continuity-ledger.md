# CONTINUITY_STATE — after {{shot_id}}

actors:
  {{actor_id}}:
    role_id: {{}}
    screen_slot: {{}}
    facing: {{}}
    pose_motion_phase: {{}}
    expression_emotion: {{}}
    costume_state: {{}}
    prop_hand_orientation_state: {{}}
    hair_state: {{}}
    injury_dirt_wetness: {{}}

environment:
  damage_debris: {{}}
  effect_residue: {{}}
  light_time_weather: {{}}

unresolved_motion: {{}}
unresolved_story_promises: {{}}
next_shot_required_first_state: {{}}
