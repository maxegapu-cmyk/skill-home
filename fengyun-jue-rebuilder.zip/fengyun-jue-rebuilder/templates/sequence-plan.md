# Sequence production plan

sequence_id: {{}}
mode: NARRATIVE_REBUILD | COMBAT_REBUILD | MUSIC_REBUILD | TRAILER_REBUILD
fidelity_level: {{}}

story_spine:
  before: {{}}
  objective: {{}}
  conflict: {{}}
  decision: {{}}
  consequence: {{}}
  state_change: {{}}

visual_spine:
  target_style_fingerprint: {{}}
  recurring_motif: {{}}
  lighting_progression: {{}}
  scale_progression: {{}}

combat_spine_if_any:
  fight_map_id: {{}}
  tactical_turns: {{}}
  signature_contacts: {{}}
  injury_resource_changes: {{}}

shot_graph:
  - shot_id: {{}}
    predecessor: {{}}
    successor: {{}}
    narrative_job: {{}}
    duration: {{}}
    first_state: {{}}
    end_state: {{}}
    render_route: {{}}

acceptance:
  identity_floor: 9.0
  style_floor: 8.5
  action_floor: 8.5
  sequence_weighted_floor: 8.8
