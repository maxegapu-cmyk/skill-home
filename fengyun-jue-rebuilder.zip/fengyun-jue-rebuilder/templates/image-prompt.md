# Image prompt assembly 2.0

## TASK
Reconstruct the planned shot while preserving immutable identity/design and shot facts, then render through STYLE_FINGERPRINT.

## REFERENCE_ROUTER
{{ref_id -> primary role -> allowed transfer -> forbidden transfer}}

## CHARACTER_LOCK
{{one per actor}}

## SHOT_LOCK
{{composition, actor_id/role_id/screen_slot, pose, camera, environment}}

## STYLE_FINGERPRINT / STYLE_LOCK
`STYLE_LOCK` is the legacy alias; v2 canonical name is `STYLE_FINGERPRINT`.
{{rendering behavior only}}

## PRESERVE
Identity geometry; hair silhouette; costume/prop topology; actor roles; pose/blocking; camera relation; scene facts; environmental anchors.

## TRANSFORM
Only the dimensions owned by STYLE_FINGERPRINT.

## EXCLUDE
Non-diegetic overlay, watermark, subtitle, danmaku, player UI, reference-character identity from style donors, and motion-donor appearance.

## FAILURE GUARDS
No identity averaging, role swap, costume fusion, prop swap, generic wuxia redesign, anatomy stretch, accidental camera change, or overlay leakage.
