# FIGHT_MAP — {{fight_id}}

arena: {{}}
axis: {{}}
camera_side: {{}}

actors:
  - actor_id: {{}}
    role_id: {{}}
    screen_slot: LEFT | CENTER | RIGHT | DEPTH
    objective: {{}}
    facing: {{}}
    stance: {{}}
    lead_side: {{}}
    subject trajectory: {{}}
    weapon_state: {{}}
    injury_state: {{}}

distance_graph: {{}}
camera trajectory: {{}}

beats:
  - beat_id: {{}}
    attacker: {{actor_id}}
    defender: {{actor_id}}
    intent: {{}}
    initiation: {{}}
    approach_vector: {{}}
    contact event: {{yes/no + details}}
    impact frame: {{}}
    defender_response: {{}}
    recoil: {{}}
    state_delta: {{}}
    vfx_cause_path_aftermath: {{}}

occlusion_re-entry_rules: {{}}
