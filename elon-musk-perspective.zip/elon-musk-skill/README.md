# 马斯克.skill

本目录整理自公开仓库：`alchaincyf/elon-musk-skill`。

项目定位：Elon Musk 的认知操作系统，由女娲.skill生成。核心运行入口为 `SKILL.md`，调研材料位于 `references/`，示例位于 `examples/`。

原仓库： https://github.com/alchaincyf/elon-musk-skill

许可证：MIT，详见 `LICENSE`。
