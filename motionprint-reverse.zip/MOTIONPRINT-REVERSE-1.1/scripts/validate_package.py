#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md", "README.md", "QUICKSTART.md", "VERSION.md",
    "CHANGELOG.md", "QUALITY-CHECKLIST.md", "PACKAGING.md",
    "evals/evals.json", "PACKAGE-MANIFEST.json", "SHA256SUMS.txt",
]
REQUIRED_SECTIONS = [
    "七枚动态指纹", "Prompt Budget", "Compare & Patch",
    "运动冲突检查", "出厂质量闸",
]

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

errors = []
for rel in REQUIRED:
    if not (ROOT / rel).exists():
        errors.append(f"missing {rel}")

try:
    evals = json.loads((ROOT / "evals/evals.json").read_text(encoding="utf-8"))
    cases = evals.get("cases", [])
    if len(cases) < 10:
        errors.append("eval cases < 10")
    for index, case in enumerate(cases):
        if not isinstance(case, dict) or not case.get("id"):
            errors.append(f"invalid eval case at index {index}")
except Exception as exc:
    errors.append(f"evals invalid: {exc}")

skill_path = ROOT / "SKILL.md"
if skill_path.exists():
    text = skill_path.read_text(encoding="utf-8", errors="ignore")
    for section in REQUIRED_SECTIONS:
        if section not in text:
            errors.append(f"missing skill section: {section}")

manifest_path = ROOT / "PACKAGE-MANIFEST.json"
if manifest_path.exists():
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest.get("files", []):
            p = ROOT / item["path"]
            if not p.exists():
                errors.append(f"manifest missing {item['path']}")
            elif sha256(p) != item["sha256"]:
                errors.append(f"hash mismatch {item['path']}")
    except Exception as exc:
        errors.append(f"manifest invalid: {exc}")

if errors:
    print("FAIL")
    for error in errors:
        print("-", error)
    sys.exit(1)

print("PASS: package structure, content checks, evals, and manifest hashes validated")
