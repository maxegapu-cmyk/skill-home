# 单镜完整反推模板

## 时间线

| 时间 | 阶段 | 主动作 | 摄影机 | 响应 | 结果 |
|---|---|---|---|---|---|

## 七枚指纹

- Scene：
- Subject：
- Motion：
- Camera：
- Rhythm：
- Response：
- Look：

## P0 / P1 / P2

- P0：
- P1：
- P2：

## Core Prompt

## Directed Prompt

## 不确定项
