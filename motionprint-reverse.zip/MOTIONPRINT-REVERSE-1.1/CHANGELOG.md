# Changelog

## 1.1.0

- 强化出厂质量闸：动作闭环、镜头兼容、时间容量、环境因果与提示词负载。
- 优化快速使用卡和产品说明。
- 简化发布检查与包验证信息。
- 保持七枚动态指纹、Prompt Budget 和 Compare & Patch 核心工作流。

## 1.0.0

- 建立七枚动态指纹。
- 建立 P0/P1/P2 Prompt Budget。
- 建立单镜、多镜、快速、完整与对比修补模式。
- 建立运动冲突检查。
- 建立 Core Prompt / Directed Prompt 双输出。
