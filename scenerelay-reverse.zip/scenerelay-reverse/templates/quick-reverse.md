# 快速反推模板

## 状态骨架

A → B → C

## Compact Prompt

[填写]

## 稳定性限制

- [填写]
- [填写]

## 不确定项

- [填写]

本模板用于原片分析或其他模型的通用输出。Seedance 2.5 最终提示词使用 [专用模板](seedance-2-5-prompt.md)；分轮改编使用 [项目记录](project-state.md)，逐镜保留源 ID 与证据时间码。
