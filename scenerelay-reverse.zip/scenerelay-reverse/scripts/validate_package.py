#!/usr/bin/env python3
"""Validate package structure and integrity only; never run creative evals."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
INDEXES = {'PACKAGE-MANIFEST.json', 'SHA256SUMS.txt'}
REQUIRED = {
    'SKILL.md', 'README.md', 'QUICKSTART.md', 'PACKAGING.md',
    'references/video-reading.md', 'references/story-adaptation.md',
    'references/asset-images.md', 'references/reference-pack.md',
    'references/adaptation-ripple.md', 'references/final-delivery-contract.md',
    'references/seedance-2-5-capabilities.md', 'references/seedance-2-5.md',
    'templates/project-state.md', 'templates/reference-upload-board.md',
    'templates/final-production-delivery.md', 'templates/seedance-2-5-prompt.md',
    'templates/quick-reverse.md', 'templates/full-reverse.md',
    'templates/multi-shot.md', 'templates/compare-repair.md',
    'examples/replacement-workflow.md', 'examples/direct-delivery-workflow.md',
    'scripts/run_acceptance_checks.py', 'evals/evals.json', *INDEXES,
}
errors = []
actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
errors.extend(f'missing: {name}' for name in sorted(REQUIRED - actual))
for p in ROOT.rglob('*'):
    if p.is_symlink():
        errors.append(f'symlink not allowed in package: {p.relative_to(ROOT)}')

try:
    manifest = json.loads((ROOT / 'PACKAGE-MANIFEST.json').read_text())
    entries = manifest['files']
    listed = [entry['path'] for entry in entries]
    if len(listed) != len(set(listed)) or manifest['file_count'] != len(entries):
        errors.append('manifest duplicates or file_count mismatch')
    if set(listed) != actual - INDEXES:
        errors.append('manifest file set mismatch')
    expected_sums = {}
    for entry in entries:
        name = entry['path']
        rel = PurePosixPath(name)
        if rel.is_absolute() or '..' in rel.parts:
            errors.append(f'unsafe manifest path: {name}')
            continue
        p = ROOT / name
        if not p.is_file() or not p.resolve().is_relative_to(ROOT):
            errors.append(f'invalid manifest file: {name}')
            continue
        data = p.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if len(data) != entry['size'] or digest != entry['sha256']:
            errors.append(f'size/hash mismatch: {name}')
        expected_sums[name] = entry['sha256']
    lines = (ROOT / 'SHA256SUMS.txt').read_text().splitlines()
    sums = {}
    for line in lines:
        digest, name = line.split('  ', 1)
        if name in sums:
            errors.append(f'duplicate checksum: {name}')
        sums[name] = digest
    if sums != expected_sums:
        errors.append('SHA256SUMS does not match manifest')
    evals = json.loads((ROOT / 'evals/evals.json').read_text())
    cases = evals['cases']
    ids = [case['id'] for case in cases]
    if not cases or len(ids) != len(set(ids)):
        errors.append('empty evals or duplicate case ids')
    if evals['version'] != manifest['version']:
        errors.append('eval/manifest version mismatch')
    skill = (ROOT / 'SKILL.md').read_text()
    version = re.search(r'^  version: "([^"]+)"$', skill, re.M)
    if not version or version.group(1) != manifest['version']:
        errors.append('skill/manifest version mismatch')
except (OSError, ValueError, KeyError, TypeError) as exc:
    errors.append(f'invalid package metadata: {exc}')

for p in ROOT.rglob('*.md'):
    content = p.read_text()
    for target in re.findall(r'\]\(([^)]+)\)', content):
        if '://' in target or target.startswith('#'):
            continue
        target = target.split('#', 1)[0]
        resolved = (p.parent / target).resolve()
        if not resolved.is_relative_to(ROOT) or not resolved.exists():
            errors.append(f'broken/outside link in {p.relative_to(ROOT)}: {target}')

if errors:
    print('FAIL')
    for error in errors:
        print('-', error)
    sys.exit(1)
print(f'PASS: {len(actual) - len(INDEXES)} payload files; structure, links, versions, sizes and checksums valid.')
print('Creative evals and live image/video generation were NOT executed by this validator.')
