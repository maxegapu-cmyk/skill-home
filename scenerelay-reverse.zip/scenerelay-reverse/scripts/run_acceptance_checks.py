#!/usr/bin/env python3
"""Static acceptance checks for the production contract. No model/media generation."""
from pathlib import Path
import json, sys

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
errors=[]

def text(rel):
    return (ROOT/rel).read_text(encoding='utf-8')

skill=text('SKILL.md')
seed=text('references/seedance-2-5.md')
cap=text('references/seedance-2-5-capabilities.md')
ref=text('references/reference-pack.md')
final=text('references/final-delivery-contract.md')
asset=text('references/asset-images.md')

required_skill=[
    '替换涟漪','L0 外观替换','L3 故事功能替换','参考素材包',
    'CHARACTER-ID','SCENE-MASTER','SHOT-START','可直接复制','30 秒'
]
for token in required_skill:
    if token not in skill:
        errors.append(f'SKILL missing production contract token: {token}')

for token in ['30 张图片','10 段视频','10 段音频','2026-09-07']:
    if token not in cap:
        errors.append(f'capability baseline missing: {token}')

for token in ['最小充分集','控制缺口','CONTACT-STATE','SHOT-END','九宫格']:
    if token not in ref:
        errors.append(f'reference pack missing: {token}')

asset_contract = asset + '\n' + ref
for token in ['实际生成','单张独立大图','验看']:
    if token not in asset_contract:
        errors.append(f'asset production missing: {token}')

for token in ['可直接添加的参考素材包','Seedance 2.5 上传与绑定','直接复制正文']:
    if token not in final:
        errors.append(f'final delivery contract missing: {token}')

for token in ['不要按镜头数机械','最小充分集','原视频','准确界面标签']:
    if token not in seed:
        errors.append(f'Seedance compiler missing: {token}')


# 3.1 DIRECT-DELIVERY hard gates.
direct = skill + '\n' + final + '\n' + ref + '\n' + asset
for token in [
    'DIRECT-DELIVERY', '默认不展示长篇分析', '必须实际调用',
    '真实图片产物', '工具边界', '失败图', '先展示实际参考图',
    '不反问用户选图', '派生', '不得让用户二次改写提示词'
]:
    if token not in direct:
        errors.append(f'3.1 direct-delivery contract missing: {token}')

# DIRECT-DELIVERY output-shape checks, not just keyword presence.
if 'references/direct-delivery-mode.md' not in skill:
    errors.append('SKILL does not route to direct-delivery-mode.md')
sections = ['## B. 可直接添加的参考素材包', '## C. Seedance 2.5 上传与绑定', '## D. 直接复制正文']
positions = [final.find(x) for x in sections]
if any(x < 0 for x in positions) or positions != sorted(positions):
    errors.append('final delivery order is not images -> binding -> prompt')
direct_file = text('references/direct-delivery-mode.md')
for token in ['完成定义','图像工具硬闸','参考图视觉 QA','不给用户制造中间选择题','最终输出形状']:
    if token not in direct_file:
        errors.append(f'direct-delivery mode missing section: {token}')

# Privacy/source leakage gate.
banned=['universal-tvc-impact-director','TVC 技能','TVC 来源','用户本地 `universal']
for p in ROOT.rglob('*'):
    if p.name == 'run_acceptance_checks.py':
        continue
    if p.is_file() and p.suffix.lower() in {'.md','.json','.py','.txt'}:
        s=p.read_text(encoding='utf-8',errors='ignore')
        for token in banned:
            if token in s:
                errors.append(f'private/source leakage token {token!r} in {p.relative_to(ROOT)}')

# Eval coverage.
evals=json.loads(text('evals/evals.json'))
if evals.get('version')!='3.1.0':
    errors.append('eval version is not 3.1.0')
if len(evals.get('cases',[])) < 44:
    errors.append('expected at least 44 acceptance cases')
required_ids={'E21','E24','E26','E28','E30','E32','E36','E37','E38','E39','E40','E41','E42','E43','E44'}
ids={c.get('id') for c in evals.get('cases',[])}
if not required_ids.issubset(ids):
    errors.append('missing 3.1 critical eval cases')

if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print(f'PASS: production contract static checks; {len(evals["cases"])} acceptance scenarios present.')
print('Live video reading, image generation and Seedance generation are NOT executed by this script.')
