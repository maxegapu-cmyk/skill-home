# Packaging

- 包名：SceneRelay Reverse
- 版本：3.1.0
- 根目录：`scenerelay-reverse`
- 安装入口：`SKILL.md`
- 校验：`python scripts/validate_package.py .`
- 静态验收：`python scripts/run_acceptance_checks.py .`

打包前必须重新生成 `PACKAGE-MANIFEST.json` 与 `SHA256SUMS.txt`，再从新的临时目录解压最终 ZIP，并以 ZIP 内成品为对象重新执行两项校验。

结构校验不等于真实视频读取、图片生成或 Seedance 成片测试；测试报告必须分开说明。
