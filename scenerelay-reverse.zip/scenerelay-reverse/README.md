# SceneRelay Reverse 3.1

把参考视频从“逐镜看懂”推进到“Seedance 2.5 可直接生产”：

**逐镜反推 → 人物/场景/道具替换 → 因果与动作重算 → 实际参考图/资产图 → 上传绑定板 → Seedance 2.5 直接复制正文 → 生成结果最早偏差修复。**

3.1 的核心变化是 **DIRECT-DELIVERY**：用户要完整制作时，逐镜分析默认转为内部生产步骤；系统自动决定最小充分参考集。有图像工具就必须把缺失参考图实际生成/编辑并验看，**先交真实参考图，再交 Seedance 2.5 完整正文**。只有宿主没有图像工具时才允许降级为参考图任务单。

Seedance 2.5 官方能力基线已按 2026-09-07 公开资料核验：单次最长 30 秒，支持延长；单次最多 30 张图片、10 段视频、10 段音频参考，并强化多模态参考和时间戳级编辑。平台 UI、分辨率、套餐、地区和素材标签仍以用户当前界面为准。

入口：[SKILL.md](SKILL.md)

关键模块：
- [DIRECT-DELIVERY](references/direct-delivery-mode.md)
- [替换涟漪](references/adaptation-ripple.md)
- [参考素材包](references/reference-pack.md)
- [Seedance 2.5 能力基线](references/seedance-2-5-capabilities.md)
- [Seedance 编译](references/seedance-2-5.md)
- [最终交付合同](references/final-delivery-contract.md)
- [直接交付示例](examples/direct-delivery-workflow.md)

本 Skill 不自带视频生成服务，也不把静态结构校验冒充真实成片测试。是否能实际生成/编辑图片、读取视频或提交到 Seedance，取决于运行环境当前拥有的工具与授权。
