# Version

- Package: SceneRelay Reverse
- Version: 3.1.0
- Release date: 2026-09-07
- Status: DIRECT-DELIVERY production release
- Primary target: Seedance 2.5 reference-driven story adaptation workflow
