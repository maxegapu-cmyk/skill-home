import importlib.util
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "validate_package.py"


def load_validator():
    spec = importlib.util.spec_from_file_location("validate_package", SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load package validator")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class PackageTests(unittest.TestCase):
    def test_package_contract_and_examples(self):
        v = load_validator()
        self.assertEqual([], v.validate_package(ROOT))


if __name__ == "__main__":
    unittest.main()
