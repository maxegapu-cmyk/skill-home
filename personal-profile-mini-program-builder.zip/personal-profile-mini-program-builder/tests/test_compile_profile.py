import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "compile_profile.py"


def load_module():
    spec = importlib.util.spec_from_file_location("compile_profile", SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load compiler")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class CompileProfileTests(unittest.TestCase):
    def test_minimal_profile_defaults_to_career(self):
        m = load_module()
        source = {"identity": {"name": "Lin", "headline": "Product Designer", "summary": "Builds useful products."}}
        out = m.compile_profile(source)
        self.assertEqual("career", out["mode"])
        self.assertEqual("executive", out["theme"])
        self.assertEqual("Lin", out["identity"]["name"])
        self.assertIn("home", [x["key"] for x in out["navigation"]])

    def test_portfolio_mode_auto_detects_rich_projects(self):
        m = load_module()
        source = {
            "identity": {"name": "Mira", "headline": "Visual Creator", "summary": "Creates films."},
            "projects": [
                {"title": "A", "summary": "a", "media": ["https://example.com/a.jpg"]},
                {"title": "B", "summary": "b", "media": ["https://example.com/b.jpg"]},
                {"title": "C", "summary": "c", "media": ["https://example.com/c.jpg"]},
            ],
        }
        out = m.compile_profile(source)
        self.assertEqual("portfolio", out["mode"])
        self.assertEqual("creator", out["theme"])
        self.assertEqual("projects", out["navigation"][1]["key"])

    def test_directed_mode_honors_allow_sections(self):
        m = load_module()
        source = {
            "meta": {"mode": "directed", "target": "client", "allow_sections": ["projects", "skills", "contact"]},
            "identity": {"name": "Kai", "headline": "Engineer", "summary": "Builds systems."},
            "experience": [{"company": "SecretCo", "role": "Engineer", "summary": "Internal."}],
            "projects": [{"title": "Public Work", "summary": "Delivered."}],
            "skills": [{"name": "Python"}],
        }
        out = m.compile_profile(source)
        self.assertEqual("directed", out["mode"])
        self.assertNotIn("experience", out["sections"])
        self.assertIn("projects", out["sections"])

    def test_hidden_and_gated_contacts_never_expose_raw_value(self):
        m = load_module()
        source = {
            "identity": {"name": "Ada", "headline": "Developer", "summary": "Builds apps."},
            "contacts": [
                {"kind": "email", "label": "Email", "value": "public@example.com", "visibility": "public"},
                {"kind": "wechat", "label": "WeChat", "value": "private_wechat_123", "visibility": "gated"},
                {"kind": "phone", "label": "Phone", "value": "13800000000", "visibility": "hidden"},
            ],
        }
        out = m.compile_profile(source)
        raw = json.dumps(out, ensure_ascii=False)
        self.assertIn("public@example.com", raw)
        self.assertNotIn("private_wechat_123", raw)
        self.assertNotIn("13800000000", raw)
        self.assertTrue(any(x["visibility"] == "gated" for x in out["contacts"]))

    def test_unknown_internal_fields_are_stripped_from_public_model(self):
        m = load_module()
        source = {
            "identity": {"name": "A", "headline": "B", "summary": "C", "internal_notes": "do-not-ship"},
            "experience": [{"company": "X", "role": "Y", "summary": "Z", "private_comment": "secret-exp"}],
            "projects": [{"title": "P", "summary": "S", "internal_client_note": "secret-project"}],
        }
        out = m.compile_profile(source)
        raw = json.dumps(out, ensure_ascii=False)
        self.assertNotIn("do-not-ship", raw)
        self.assertNotIn("secret-exp", raw)
        self.assertNotIn("secret-project", raw)

    def test_duplicate_project_ids_fail(self):
        m = load_module()
        source = {
            "identity": {"name": "A", "headline": "B", "summary": "C"},
            "projects": [
                {"id": "same", "title": "One", "summary": "1"},
                {"id": "same", "title": "Two", "summary": "2"},
            ],
        }
        with self.assertRaises(ValueError):
            m.compile_profile(source)

    def test_compiler_does_not_invent_metrics(self):
        m = load_module()
        source = {
            "identity": {"name": "A", "headline": "B", "summary": "C"},
            "experience": [{"company": "X", "role": "Y", "summary": "Improved onboarding."}],
        }
        out = m.compile_profile(source)
        text = json.dumps(out, ensure_ascii=False)
        for fabricated in ["%", "倍", "million", "百万", "增长了"]:
            self.assertNotIn(fabricated, text)


if __name__ == "__main__":
    unittest.main()
