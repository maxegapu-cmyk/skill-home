import importlib.util
import json
import tempfile
import unittest
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "validate_project.py"


def load_validator():
    spec = importlib.util.spec_from_file_location("validate_project", SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError("validator module cannot be loaded")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def write(path: Path, text: str = ""):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def page(root: Path, route: str):
    base = root / route
    write(base.with_suffix(".js"), "Page({})\n")
    write(base.with_suffix(".json"), "{}\n")
    write(base.with_suffix(".wxml"), "<view>ok</view>\n")
    write(base.with_suffix(".wxss"), "\n")


def make_project(base: Path, nested=False):
    source = base / "miniprogram" if nested else base
    source.mkdir(parents=True, exist_ok=True)
    cfg = {"appid": "touristappid", "compileType": "miniprogram"}
    if nested:
        cfg["miniprogramRoot"] = "miniprogram/"
    write(base / "project.config.json", json.dumps(cfg))
    write(source / "app.js", "App({})\n")
    write(source / "app.wxss", "\n")
    write(source / "app.json", json.dumps({"pages": ["pages/index/index"]}))
    page(source, "pages/index/index")
    return source


class ValidatorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_valid_root_project_passes(self):
        source = make_project(self.root)
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)
        self.assertEqual(source.resolve(), result.source_root.resolve())

    def test_valid_miniprogram_root_project_passes(self):
        source = make_project(self.root, nested=True)
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)
        self.assertEqual(source.resolve(), result.source_root.resolve())

    def test_missing_required_generated_page_file_fails(self):
        source = make_project(self.root)
        (source / "pages/index/index.wxml").unlink()
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("missing page file" in x for x in result.errors))

    def test_invalid_json_fails(self):
        source = make_project(self.root)
        write(source / "app.json", "{bad json")
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("invalid JSON" in x for x in result.errors))

    def test_tabbar_route_must_be_declared_and_exist(self):
        source = make_project(self.root)
        app = {"pages": ["pages/index/index"], "tabBar": {"list": [{"pagePath": "pages/missing/index", "text": "Missing"}]}}
        write(source / "app.json", json.dumps(app))
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("tabBar pagePath" in x for x in result.errors))

    def test_tabbar_icon_if_declared_must_exist(self):
        source = make_project(self.root)
        app = {"pages": ["pages/index/index"], "tabBar": {"list": [{"pagePath": "pages/index/index", "text": "Home", "iconPath": "assets/home.png"}]}}
        write(source / "app.json", json.dumps(app))
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("tabBar icon" in x for x in result.errors))

    def test_subpackage_page_is_validated(self):
        source = make_project(self.root)
        app = {"pages": ["pages/index/index"], "subPackages": [{"root": "pkgA", "pages": ["detail/index"]}]}
        write(source / "app.json", json.dumps(app))
        page(source, "pkgA/detail/index")
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)
        (source / "pkgA/detail/index.js").unlink()
        result = v.validate_project(self.root)
        self.assertTrue(any("pkgA/detail/index.js" in x for x in result.errors))

    def test_lowercase_subpackages_is_supported(self):
        source = make_project(self.root)
        app = {"pages": ["pages/index/index"], "subpackages": [{"root": "pkgB", "pages": ["detail/index"]}]}
        write(source / "app.json", json.dumps(app))
        page(source, "pkgB/detail/index")
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)

    def test_local_component_reference_must_exist(self):
        source = make_project(self.root)
        write(source / "pages/index/index.json", json.dumps({"usingComponents": {"x-card": "/components/x-card/index"}}))
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("component target" in x for x in result.errors))
        for ext, body in [(".js", "Component({})"), (".json", '{"component":true}'), (".wxml", "<view/>"), (".wxss", "")]:
            write(source / f"components/x-card/index{ext}", body)
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)

    def test_client_side_secret_literal_fails(self):
        source = make_project(self.root)
        write(source / "pages/index/index.js", 'const AppSecret = "0123456789abcdef0123456789abcdef"; Page({})')
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("possible client-side secret" in x for x in result.errors))

    def test_http_remote_url_warns_in_dev_and_fails_in_release(self):
        source = make_project(self.root)
        write(source / "pages/index/index.js", 'const url = "http://api.example.com/v1"; Page({})')
        v = load_validator()
        dev = v.validate_project(self.root, release=False)
        self.assertEqual([], dev.errors)
        self.assertTrue(any("insecure remote HTTP" in x for x in dev.warnings))
        release = v.validate_project(self.root, release=True)
        self.assertTrue(any("insecure remote HTTP" in x for x in release.errors))

    def test_declared_cloudfunction_root_must_exist(self):
        make_project(self.root, nested=True)
        cfg = json.loads((self.root / "project.config.json").read_text(encoding="utf-8"))
        cfg["cloudfunctionRoot"] = "cloudfunctions/"
        write(self.root / "project.config.json", json.dumps(cfg))
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("cloudfunctionRoot" in x for x in result.errors))
        (self.root / "cloudfunctions").mkdir()
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)

    def test_tabbar_cannot_point_to_subpackage_page(self):
        source = make_project(self.root)
        app = {
            "pages": ["pages/index/index"],
            "subPackages": [{"root": "pkgA", "pages": ["detail/index"]}],
            "tabBar": {"list": [{"pagePath": "pkgA/detail/index", "text": "Detail"}]}
        }
        write(source / "app.json", json.dumps(app))
        page(source, "pkgA/detail/index")
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("main-package" in x for x in result.errors))

    def test_npm_component_reference_is_not_misclassified_as_missing_local_file(self):
        source = make_project(self.root)
        write(source / "pages/index/index.json", json.dumps({"usingComponents": {"t-button": "tdesign-miniprogram/button/button"}}))
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertEqual([], result.errors)

    def test_page_route_cannot_escape_source_root(self):
        source = make_project(self.root)
        write(source / "app.json", json.dumps({"pages": ["../escape/index"]}))
        v = load_validator()
        result = v.validate_project(self.root)
        self.assertTrue(any("unsafe page route" in x for x in result.errors))

    def test_complex_common_project_shape_passes_release_validation(self):
        source = make_project(self.root, nested=True)
        app = {
            "pages": ["pages/index/index", "pages/profile/index"],
            "tabBar": {"list": [
                {"pagePath": "pages/index/index", "text": "首页"},
                {"pagePath": "pages/profile/index", "text": "我的"}
            ]},
            "subPackages": [{"root": "booking", "pages": ["detail/index"]}]
        }
        write(source / "app.json", json.dumps(app, ensure_ascii=False))
        page(source, "pages/profile/index")
        page(source, "booking/detail/index")
        write(source / "pages/index/index.json", json.dumps({
            "usingComponents": {
                "local-card": "/components/local-card/index",
                "t-button": "tdesign-miniprogram/button/button"
            }
        }))
        for ext, body in [(".js", "Component({})"), (".json", '{"component":true}'), (".wxml", "<view><slot/></view>"), (".wxss", "")]:
            write(source / f"components/local-card/index{ext}", body)
        write(source / "services/api.js", 'const BASE_URL = "https://api.example.com"; module.exports = { BASE_URL }')
        cfg = json.loads((self.root / "project.config.json").read_text(encoding="utf-8"))
        cfg["cloudfunctionRoot"] = "cloudfunctions/"
        write(self.root / "project.config.json", json.dumps(cfg))
        (self.root / "cloudfunctions").mkdir()
        v = load_validator()
        result = v.validate_project(self.root, release=True)
        self.assertEqual([], result.errors)
        self.assertEqual([], result.warnings)

    def test_private_or_gated_contact_value_cannot_leak_into_project(self):
        source = make_project(self.root)
        profile = {
            "identity": {"name": "A"},
            "contacts": [
                {"kind": "wechat", "value": "secret_wechat_7788", "visibility": "gated"},
                {"kind": "phone", "value": "13911112222", "visibility": "hidden"}
            ]
        }
        v = load_validator()
        clean = v.validate_project(self.root, release=True, profile_source=profile)
        self.assertEqual([], clean.errors)
        write(source / "pages/index/index.js", "const x='secret_wechat_7788'; Page({})")
        leaked = v.validate_project(self.root, release=True, profile_source=profile)
        self.assertTrue(any("private/gated contact leaked" in x for x in leaked.errors))


if __name__ == "__main__":
    unittest.main()
