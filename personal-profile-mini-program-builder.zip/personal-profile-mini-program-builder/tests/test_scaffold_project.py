import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"


def load(name):
    p = SCRIPTS / f"{name}.py"
    spec = importlib.util.spec_from_file_location(name, p)
    if spec is None or spec.loader is None:
        raise RuntimeError(name)
    m = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = m
    spec.loader.exec_module(m)
    return m


class ScaffoldTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def _source(self):
        return {
            "identity": {"name": "Ada", "headline": "AI Product Builder", "summary": "Builds useful AI products."},
            "contacts": [
                {"kind": "email", "label": "Email", "value": "ada@example.com", "visibility": "public"},
                {"kind": "phone", "label": "Phone", "value": "13800000000", "visibility": "hidden"},
            ],
            "skills": [{"name": "Product"}, {"name": "Python"}],
            "experience": [{"company": "Example", "role": "Builder", "period": "2024–Now", "summary": "Built products."}],
            "projects": [{"id": "alpha", "title": "Alpha", "summary": "A useful project.", "highlights": ["Shipped MVP"]}],
        }

    def test_scaffold_generates_importable_native_project(self):
        c = load("compile_profile")
        s = load("scaffold_project")
        compiled = c.compile_profile(self._source())
        project = self.root / "out"
        s.scaffold_project(compiled, project)
        self.assertTrue((project / "project.config.json").is_file())
        self.assertTrue((project / "miniprogram/app.json").is_file())
        app = json.loads((project / "miniprogram/app.json").read_text(encoding="utf-8"))
        self.assertIn("pages/home/index", app["pages"])
        for route in app["pages"]:
            base = project / "miniprogram" / route
            for ext in [".js", ".json", ".wxml", ".wxss"]:
                self.assertTrue(base.with_suffix(ext).is_file(), f"missing {route}{ext}")

    def test_hidden_contact_value_is_not_written_to_project(self):
        c = load("compile_profile")
        s = load("scaffold_project")
        compiled = c.compile_profile(self._source())
        project = self.root / "out"
        s.scaffold_project(compiled, project)
        all_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in project.rglob("*") if p.is_file())
        self.assertIn("ada@example.com", all_text)
        self.assertNotIn("13800000000", all_text)

    def test_generated_project_passes_release_validator(self):
        c = load("compile_profile")
        s = load("scaffold_project")
        v = load("validate_project")
        compiled = c.compile_profile(self._source())
        project = self.root / "out"
        s.scaffold_project(compiled, project)
        result = v.validate_project(project, release=True)
        self.assertEqual([], result.errors)
        self.assertEqual([], result.warnings)


if __name__ == "__main__":
    unittest.main()
