#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import re
import sys
import tempfile
from pathlib import Path

REQUIRED = [
    "SKILL.md",
    "schemas/profile.schema.json",
    "scripts/compile_profile.py",
    "scripts/scaffold_project.py",
    "scripts/validate_project.py",
    "references/01-intake-modes.md",
    "references/02-profile-contract.md",
    "references/03-information-architecture.md",
    "references/04-content-editor.md",
    "references/05-visual-system.md",
    "references/06-privacy-sharing.md",
    "references/07-engineering.md",
    "references/08-generation.md",
    "references/09-qa-repair.md",
    "references/10-public-sources.md",
    "examples/profile-career.json",
    "examples/profile-portfolio.json",
    "examples/profile-directed.json",
]
PLACEHOLDER_RE = re.compile(r"\b(?:TODO|TBD|FIXME)\b", re.I)
REF_RE = re.compile(r"`(references/[A-Za-z0-9._/-]+\.md)`")


def _load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    m = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = m
    spec.loader.exec_module(m)
    return m


def validate_package(root: str | Path) -> list[str]:
    root = Path(root).resolve()
    errors: list[str] = []
    for rel in REQUIRED:
        if not (root / rel).is_file():
            errors.append(f"missing required file: {rel}")

    skill = root / "SKILL.md"
    if skill.is_file():
        text = skill.read_text(encoding="utf-8")
        if not text.startswith("---\n") or "name: personal-profile-mini-program-builder" not in text[:500]:
            errors.append("SKILL.md frontmatter is invalid or skill name mismatch")
        for rel in REF_RE.findall(text):
            if not (root / rel).is_file():
                errors.append(f"broken SKILL reference: {rel}")

    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in {".md", ".py", ".json", ".yaml", ".yml"}:
            continue
        if p.name == "validate_package.py":
            continue
        text = p.read_text(encoding="utf-8", errors="ignore")
        if PLACEHOLDER_RE.search(text):
            errors.append(f"placeholder token found: {p.relative_to(root)}")

    for rel in ["schemas/profile.schema.json", "examples/profile-career.json", "examples/profile-portfolio.json", "examples/profile-directed.json"]:
        p = root / rel
        if p.is_file():
            try:
                json.loads(p.read_text(encoding="utf-8"))
            except Exception as exc:
                errors.append(f"invalid JSON {rel}: {exc}")

    if errors:
        return errors

    compiler = _load_module("pp_compile", root / "scripts/compile_profile.py")
    scaffold = _load_module("pp_scaffold", root / "scripts/scaffold_project.py")
    validator = _load_module("pp_validate", root / "scripts/validate_project.py")

    with tempfile.TemporaryDirectory() as td:
        temp = Path(td)
        for example in sorted((root / "examples").glob("profile-*.json")):
            source = json.loads(example.read_text(encoding="utf-8"))
            try:
                compiled = compiler.compile_profile(source)
            except Exception as exc:
                errors.append(f"compile failed for {example.name}: {exc}")
                continue
            out = temp / example.stem
            try:
                scaffold.scaffold_project(compiled, out)
            except Exception as exc:
                errors.append(f"scaffold failed for {example.name}: {exc}")
                continue
            result = validator.validate_project(out, release=True, profile_source=source)
            if result.errors or result.warnings:
                errors.append(f"release validation failed for {example.name}: errors={result.errors}, warnings={result.warnings}")
            project_text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in out.rglob("*") if p.is_file())
            for contact in source.get("contacts", []):
                if isinstance(contact, dict) and contact.get("visibility") in {"gated", "hidden"}:
                    value = str(contact.get("value", ""))
                    if value and value in project_text:
                        errors.append(f"privacy leak in generated project for {example.name}: {contact.get('kind', 'contact')}")
            if source.get("meta", {}).get("mode") == "directed":
                forbidden = "不应出现在此定向版本"
                if forbidden in project_text:
                    errors.append("directed projection leaked excluded experience")
    return errors


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    errors = validate_package(root)
    if errors:
        for e in errors:
            print(f"ERROR: {e}")
        print(f"result: FAIL ({len(errors)} errors)")
        return 1
    print("result: PASS")
    print("examples: 3 compiled -> scaffolded -> release-validated")
    print("privacy: gated/hidden contact leak checks PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
