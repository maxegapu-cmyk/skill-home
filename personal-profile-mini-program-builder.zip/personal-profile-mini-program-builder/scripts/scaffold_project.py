#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

try:
    from compile_profile import compile_profile
except ImportError:  # imported as package/file module in tests
    compile_profile = None

THEMES = {
    "executive": {"bg": "#F4F6F8", "card": "#FFFFFF", "text": "#111827", "muted": "#667085", "accent": "#175CD3", "soft": "#EAF2FF"},
    "minimal": {"bg": "#F7F7F5", "card": "#FFFFFF", "text": "#18181B", "muted": "#71717A", "accent": "#27272A", "soft": "#F0F0EE"},
    "creator": {"bg": "#F7F5FF", "card": "#FFFFFF", "text": "#17141F", "muted": "#6B6478", "accent": "#6941C6", "soft": "#F0EAFE"},
}


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _page(root: Path, route: str, js: str, wxml: str, wxss: str = "", title: str = "") -> None:
    base = root / route
    _write(base.with_suffix(".js"), js.rstrip() + "\n")
    _write(base.with_suffix(".json"), json.dumps({"navigationBarTitleText": title}, ensure_ascii=False, indent=2) + "\n")
    _write(base.with_suffix(".wxml"), wxml.rstrip() + "\n")
    _write(base.with_suffix(".wxss"), wxss.rstrip() + "\n")


def _js_data(compiled: dict[str, Any]) -> str:
    return "module.exports = " + json.dumps(compiled, ensure_ascii=False, indent=2) + ";\n"


def _app_wxss(theme: str) -> str:
    c = THEMES.get(theme, THEMES["executive"])
    return f"""page {{ background: {c['bg']}; color: {c['text']}; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif; }}
.container {{ padding: 32rpx; box-sizing: border-box; }}
.card {{ background: {c['card']}; border-radius: 28rpx; padding: 32rpx; margin-bottom: 24rpx; box-shadow: 0 10rpx 32rpx rgba(17,24,39,.06); }}
.eyebrow {{ color: {c['accent']}; font-size: 24rpx; font-weight: 600; letter-spacing: 2rpx; text-transform: uppercase; }}
.title-xl {{ font-size: 52rpx; line-height: 1.16; font-weight: 750; margin-top: 10rpx; }}
.title-lg {{ font-size: 34rpx; line-height: 1.3; font-weight: 700; }}
.body {{ font-size: 29rpx; line-height: 1.72; color: {c['text']}; }}
.muted {{ color: {c['muted']}; }}
.pill {{ display: inline-flex; background: {c['soft']}; color: {c['accent']}; padding: 10rpx 18rpx; border-radius: 999rpx; margin: 8rpx 10rpx 0 0; font-size: 24rpx; }}
.button {{ display: flex; align-items: center; justify-content: center; min-height: 88rpx; border-radius: 22rpx; background: {c['accent']}; color: white; font-size: 28rpx; font-weight: 650; margin-top: 20rpx; }}
.button.secondary {{ background: {c['soft']}; color: {c['accent']}; }}
.row {{ display: flex; align-items: center; justify-content: space-between; gap: 20rpx; }}
.stack > view + view {{ margin-top: 22rpx; }}
.divider {{ height: 1rpx; background: rgba(17,24,39,.08); margin: 24rpx 0; }}
.safe-bottom {{ padding-bottom: calc(36rpx + env(safe-area-inset-bottom)); }}
"""


def scaffold_project(compiled: dict[str, Any], project_dir: str | Path, overwrite: bool = False) -> Path:
    project = Path(project_dir).resolve()
    if project.exists() and any(project.iterdir()):
        if not overwrite:
            raise FileExistsError(f"output directory is not empty: {project}")
        shutil.rmtree(project)
    project.mkdir(parents=True, exist_ok=True)
    mini = project / "miniprogram"
    mini.mkdir()

    sections = set(compiled.get("sections", []))
    contacts = compiled.get("contacts", []) if isinstance(compiled.get("contacts"), list) else []
    pages = ["pages/home/index", "pages/profile/index"]
    if "experience" in sections:
        pages.append("pages/experience/index")
    if "projects" in sections:
        pages += ["pages/projects/index", "pages/project-detail/index"]
    if contacts:
        pages.append("pages/contact/index")

    nav = [x for x in compiled.get("navigation", []) if isinstance(x, dict)]
    tab_items = []
    for item in nav[:3]:
        route = item.get("route")
        if route in pages and route != "pages/project-detail/index":
            tab_items.append({"pagePath": route, "text": str(item.get("label", "导航"))[:6]})
    if len(tab_items) < 2:
        tab_items = [
            {"pagePath": "pages/home/index", "text": "首页"},
            {"pagePath": "pages/profile/index", "text": "资料"},
        ]

    project_cfg = {
        "appid": "touristappid",
        "compileType": "miniprogram",
        "miniprogramRoot": "miniprogram/",
        "setting": {"es6": True, "enhance": True, "postcss": True, "minified": True},
    }
    _write(project / "project.config.json", json.dumps(project_cfg, ensure_ascii=False, indent=2) + "\n")
    _write(mini / "app.js", "App({ globalData: {} })\n")
    _write(mini / "app.json", json.dumps({
        "pages": pages,
        "window": {"navigationBarTitleText": compiled.get("identity", {}).get("name", "个人资料"), "navigationBarBackgroundColor": "#FFFFFF", "navigationBarTextStyle": "black", "backgroundTextStyle": "light"},
        "tabBar": {"color": "#667085", "selectedColor": THEMES.get(compiled.get("theme", "executive"), THEMES["executive"])["accent"], "backgroundColor": "#FFFFFF", "borderStyle": "white", "list": tab_items},
        "sitemapLocation": "sitemap.json",
    }, ensure_ascii=False, indent=2) + "\n")
    _write(mini / "app.wxss", _app_wxss(str(compiled.get("theme", "executive"))))
    _write(mini / "sitemap.json", json.dumps({"desc": "personal profile", "rules": [{"action": "allow", "page": "*"}]}, ensure_ascii=False, indent=2) + "\n")
    _write(mini / "data/profile.js", _js_data(compiled))

    home_js = """const profile = require('../../data/profile.js');
Page({
  data: { profile, stats: [] },
  onLoad() {
    const stats = [];
    if (profile.experience && profile.experience.length) stats.push({ label: '经历', value: profile.experience.length });
    if (profile.projects && profile.projects.length) stats.push({ label: '项目/作品', value: profile.projects.length });
    if (profile.skills && profile.skills.length) stats.push({ label: '技能', value: profile.skills.length });
    this.setData({ stats });
  },
  go(e) { const url = e.currentTarget.dataset.url; if (url) wx.navigateTo({ url }); },
  onShareAppMessage() { return { title: `${profile.identity.name}｜${profile.identity.headline || '个人资料'}`, path: '/pages/home/index' }; }
});"""
    home_wxml = """<view class="container safe-bottom">
  <view class="card hero">
    <view class="eyebrow">{{profile.mode === 'portfolio' ? 'PORTFOLIO' : 'PROFILE'}}</view>
    <view class="title-xl">{{profile.identity.name}}</view>
    <view class="headline">{{profile.identity.headline}}</view>
    <view class="body muted summary" wx:if="{{profile.identity.summary}}">{{profile.identity.summary}}</view>
    <view class="stats" wx:if="{{stats.length}}">
      <view class="stat" wx:for="{{stats}}" wx:key="label"><text class="stat-value">{{item.value}}</text><text class="muted">{{item.label}}</text></view>
    </view>
  </view>
  <view class="card" wx:if="{{profile.highlights.length}}">
    <view class="title-lg">重点</view>
    <view class="stack body"><view wx:for="{{profile.highlights}}" wx:key="*this">• {{item}}</view></view>
  </view>
  <view class="card">
    <view class="title-lg">快速查看</view>
    <view class="button secondary" wx:if="{{profile.projects.length}}" data-url="/pages/projects/index" bindtap="go">项目 / 作品</view>
    <view class="button secondary" wx:if="{{profile.experience.length}}" data-url="/pages/experience/index" bindtap="go">经历</view>
    <view class="button secondary" data-url="/pages/profile/index" bindtap="go">完整资料</view>
    <view class="button" wx:if="{{profile.contacts.length}}" data-url="/pages/contact/index" bindtap="go">联系我</view>
  </view>
</view>"""
    home_wxss = """.hero { padding-top: 48rpx; padding-bottom: 42rpx; }.headline{font-size:30rpx;font-weight:600;margin-top:12rpx}.summary{margin-top:28rpx}.stats{display:flex;gap:16rpx;margin-top:34rpx}.stat{flex:1;padding:20rpx;border-radius:20rpx;background:rgba(127,127,127,.07);display:flex;flex-direction:column}.stat-value{font-size:36rpx;font-weight:750;margin-bottom:4rpx}"""
    _page(mini, "pages/home/index", home_js, home_wxml, home_wxss, "个人主页")

    profile_js = "const profile = require('../../data/profile.js');\nPage({ data: { profile } });"
    profile_wxml = """<view class="container safe-bottom">
  <view class="card"><view class="title-lg">关于</view><view class="body muted" wx:if="{{profile.identity.summary}}">{{profile.identity.summary}}</view></view>
  <view class="card" wx:if="{{profile.skills.length}}"><view class="title-lg">技能</view><view><text class="pill" wx:for="{{profile.skills}}" wx:key="name">{{item.name}}</text></view></view>
  <view class="card" wx:if="{{profile.education.length}}"><view class="title-lg">教育</view><view class="stack"><view wx:for="{{profile.education}}" wx:key="index"><view class="body">{{item.school || item.institution}}</view><view class="muted">{{item.degree}} {{item.period}}</view></view></view></view>
  <view class="card" wx:if="{{profile.certifications.length}}"><view class="title-lg">证书 / 荣誉</view><view class="stack body"><view wx:for="{{profile.certifications}}" wx:key="index">{{item.name || item.title}}</view></view></view>
</view>"""
    _page(mini, "pages/profile/index", profile_js, profile_wxml, "", "个人资料")

    if "experience" in sections:
        exp_js = "const profile = require('../../data/profile.js');\nPage({ data: { experience: profile.experience } });"
        exp_wxml = """<view class="container safe-bottom"><view class="card" wx:for="{{experience}}" wx:key="index"><view class="row"><view><view class="title-lg">{{item.role}}</view><view class="body">{{item.company}}</view></view><view class="muted">{{item.period}}</view></view><view class="divider"></view><view class="body muted">{{item.summary}}</view><view wx:if="{{item.highlights}}"><view class="body" wx:for="{{item.highlights}}" wx:key="*this">• {{item}}</view></view></view></view>"""
        _page(mini, "pages/experience/index", exp_js, exp_wxml, "", "经历")

    if "projects" in sections:
        proj_js = """const profile = require('../../data/profile.js');
Page({
  data: { projects: profile.projects },
  open(e) { wx.navigateTo({ url: `/pages/project-detail/index?id=${encodeURIComponent(e.currentTarget.dataset.id)}` }); }
});"""
        proj_wxml = """<view class="container safe-bottom"><view class="card project" wx:for="{{projects}}" wx:key="id" data-id="{{item.id}}" bindtap="open"><image wx:if="{{item.media && item.media[0]}}" class="cover" src="{{item.media[0]}}" mode="aspectFill"/><view class="title-lg">{{item.title}}</view><view class="body muted">{{item.summary}}</view><view><text class="pill" wx:for="{{item.tags}}" wx:key="*this">{{item}}</text></view></view></view>"""
        proj_wxss = ".project{overflow:hidden}.cover{width:100%;height:320rpx;border-radius:20rpx;margin-bottom:24rpx;background:#eee}"
        _page(mini, "pages/projects/index", proj_js, proj_wxml, proj_wxss, "项目 / 作品")

        detail_js = """const profile = require('../../data/profile.js');
Page({
  data: { project: null },
  onLoad(query) {
    const id = decodeURIComponent(query.id || '');
    const project = (profile.projects || []).find(x => x.id === id) || null;
    this.setData({ project });
    if (!project) wx.showToast({ title: '项目不存在', icon: 'none' });
  },
  copyLink(e) { const value = e.currentTarget.dataset.value; if (value) wx.setClipboardData({ data: value }); }
});"""
        detail_wxml = """<view class="container safe-bottom" wx:if="{{project}}"><view class="card"><view class="eyebrow">PROJECT</view><view class="title-xl">{{project.title}}</view><view class="body muted">{{project.summary}}</view><view class="divider"></view><view class="body" wx:for="{{project.highlights}}" wx:key="*this">• {{item}}</view><image wx:for="{{project.media}}" wx:key="*this" class="detail-image" src="{{item}}" mode="widthFix"/><view class="button secondary" wx:for="{{project.links}}" wx:key="url" data-value="{{item.url}}" bindtap="copyLink">复制{{item.label || '链接'}}</view></view></view><view class="container" wx:else><view class="card body muted">没有找到该项目。</view></view>"""
        detail_wxss = ".detail-image{width:100%;border-radius:18rpx;margin-top:20rpx;background:#eee}"
        _page(mini, "pages/project-detail/index", detail_js, detail_wxml, detail_wxss, "项目详情")

    if contacts:
        contact_js = """const profile = require('../../data/profile.js');
Page({
  data: { contacts: profile.contacts },
  act(e) {
    const item = e.currentTarget.dataset.item;
    if (!item) return;
    if (item.visibility === 'public' && item.value) {
      wx.setClipboardData({ data: item.value });
      return;
    }
    wx.showModal({ title: item.label || '联系', content: item.cta || '联系本人获取', showCancel: false });
  }
});"""
        contact_wxml = """<view class="container safe-bottom"><view class="card"><view class="title-lg">联系</view><view class="body muted">仅展示资料主人明确允许公开的联系方式。</view></view><view class="card row contact" wx:for="{{contacts}}" wx:key="index" data-item="{{item}}" bindtap="act"><view><view class="body">{{item.label}}</view><view class="muted">{{item.visibility === 'public' ? item.value : item.cta}}</view></view><view class="muted">›</view></view></view>"""
        _page(mini, "pages/contact/index", contact_js, contact_wxml, ".contact{min-height:76rpx}", "联系")

    return project


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a native WeChat Mini Program from compiled personal-profile JSON.")
    parser.add_argument("source", type=Path, help="source profile JSON or compiled profile JSON")
    parser.add_argument("output", type=Path)
    parser.add_argument("--compiled", action="store_true", help="source is already compiled")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    source = json.loads(args.source.read_text(encoding="utf-8"))
    if args.compiled:
        compiled = source
    else:
        if compile_profile is None:
            raise RuntimeError("compile_profile is unavailable")
        compiled = compile_profile(source)
    project = scaffold_project(compiled, args.output, overwrite=args.overwrite)
    print(f"generated: {project}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
