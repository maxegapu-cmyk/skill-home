#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
import re
from pathlib import Path
from typing import Any

VALID_MODES = {"auto", "career", "portfolio", "directed"}
VALID_THEMES = {"executive", "minimal", "creator"}
SECTION_KEYS = ["highlights", "experience", "projects", "skills", "education", "certifications", "contact"]


def _list(value: Any) -> list[Any]:
    return copy.deepcopy(value) if isinstance(value, list) else []


def _dict(value: Any) -> dict[str, Any]:
    return copy.deepcopy(value) if isinstance(value, dict) else {}


def _slug(text: str, fallback: str) -> str:
    text = text.strip().lower()
    ascii_slug = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return ascii_slug or fallback


def _pick(raw: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    return {k: copy.deepcopy(raw[k]) for k in keys if k in raw}


def _normalize_dict_list(items: list[Any], keys: tuple[str, ...]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for raw in items:
        if not isinstance(raw, dict):
            continue
        item = _pick(raw, keys)
        if item:
            out.append(item)
    return out


def _choose_mode(source: dict[str, Any]) -> str:
    meta = _dict(source.get("meta"))
    requested = str(meta.get("mode", "auto")).strip().lower()
    if requested not in VALID_MODES:
        raise ValueError(f"unsupported mode: {requested}")
    if requested != "auto":
        return requested
    projects = _list(source.get("projects"))
    rich_media = sum(1 for p in projects if isinstance(p, dict) and _list(p.get("media")))
    if len(projects) >= 3 and rich_media >= 2:
        return "portfolio"
    return "career"


def _normalize_projects(items: list[Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for idx, raw in enumerate(items, 1):
        if not isinstance(raw, dict):
            continue
        item = _pick(raw, ("id", "title", "summary", "role", "period", "tags", "highlights", "media", "links"))
        title = str(item.get("title", "")).strip()
        if not title:
            continue
        pid = str(item.get("id", "")).strip() or _slug(title, f"project-{idx}")
        if pid in seen:
            raise ValueError(f"duplicate project id: {pid}")
        seen.add(pid)
        item["id"] = pid
        item.setdefault("summary", "")
        item["highlights"] = [str(x) for x in _list(item.get("highlights")) if str(x).strip()]
        item["tags"] = [str(x) for x in _list(item.get("tags")) if str(x).strip()]
        item["media"] = [str(x) for x in _list(item.get("media")) if str(x).strip()]
        links = []
        for raw_link in _list(item.get("links")):
            if not isinstance(raw_link, dict):
                continue
            url = str(raw_link.get("url", "")).strip()
            if not url:
                continue
            links.append({"label": str(raw_link.get("label", "链接")).strip() or "链接", "url": url})
        item["links"] = links
        out.append(item)
    return out


def _normalize_contacts(items: list[Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for raw in items:
        if not isinstance(raw, dict):
            continue
        visibility = str(raw.get("visibility", "public")).strip().lower()
        if visibility not in {"public", "gated", "hidden"}:
            raise ValueError(f"unsupported contact visibility: {visibility}")
        if visibility == "hidden":
            continue
        item = {
            "kind": str(raw.get("kind", "other")).strip() or "other",
            "label": str(raw.get("label", raw.get("kind", "联系"))).strip() or "联系",
            "visibility": visibility,
        }
        if visibility == "public":
            value = str(raw.get("value", "")).strip()
            if value:
                item["value"] = value
        else:
            item["cta"] = str(raw.get("cta", "联系本人获取")).strip() or "联系本人获取"
        out.append(item)
    return out


def _section_order(mode: str, source: dict[str, Any], present: set[str]) -> list[str]:
    if mode == "portfolio":
        base = ["projects", "skills", "experience", "education", "certifications", "contact", "highlights"]
    elif mode == "directed":
        meta = _dict(source.get("meta"))
        allowed = [str(x) for x in _list(meta.get("allow_sections")) if str(x) in SECTION_KEYS]
        base = allowed or ["projects", "skills", "experience", "contact"]
    else:
        base = ["highlights", "experience", "projects", "skills", "education", "certifications", "contact"]
    return [x for x in base if x in present]


def _navigation(mode: str, sections: list[str], contacts: list[dict[str, Any]]) -> list[dict[str, str]]:
    nav = [{"key": "home", "label": "首页", "route": "pages/home/index"}]
    if mode == "portfolio" and "projects" in sections:
        nav.append({"key": "projects", "label": "作品", "route": "pages/projects/index"})
    elif "experience" in sections:
        nav.append({"key": "experience", "label": "经历", "route": "pages/experience/index"})
    elif "projects" in sections:
        nav.append({"key": "projects", "label": "项目", "route": "pages/projects/index"})
    nav.append({"key": "profile", "label": "资料", "route": "pages/profile/index"})
    if contacts and len(nav) < 4:
        nav.append({"key": "contact", "label": "联系", "route": "pages/contact/index"})
    return nav


def compile_profile(source: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(source, dict):
        raise ValueError("profile source must be an object")
    raw_identity = _dict(source.get("identity"))
    identity = _pick(raw_identity, ("name", "headline", "summary", "avatar", "location"))
    name = str(identity.get("name", "")).strip()
    if not name:
        raise ValueError("identity.name is required")
    identity["name"] = name
    identity["headline"] = str(identity.get("headline", "")).strip()
    identity["summary"] = str(identity.get("summary", "")).strip()
    if "avatar" in identity:
        identity["avatar"] = str(identity.get("avatar", "")).strip()
    if "location" in identity:
        identity["location"] = str(identity.get("location", "")).strip()

    mode = _choose_mode(source)
    meta = _dict(source.get("meta"))
    requested_theme = str(meta.get("theme", "")).strip().lower()
    theme = requested_theme if requested_theme in VALID_THEMES else {
        "career": "executive", "portfolio": "creator", "directed": "minimal"
    }[mode]

    projects = _normalize_projects(_list(source.get("projects")))
    contacts = _normalize_contacts(_list(source.get("contacts")))
    experience = _normalize_dict_list(_list(source.get("experience")), ("company", "role", "period", "summary", "highlights"))
    skills = _normalize_dict_list(_list(source.get("skills")), ("name", "group", "level_note"))
    education = _normalize_dict_list(_list(source.get("education")), ("school", "institution", "degree", "field", "period"))
    certifications = _normalize_dict_list(_list(source.get("certifications")), ("name", "title", "issuer", "period", "url"))
    highlights = [str(x) for x in _list(source.get("highlights")) if str(x).strip()]

    present: set[str] = set()
    if highlights: present.add("highlights")
    if experience: present.add("experience")
    if projects: present.add("projects")
    if skills: present.add("skills")
    if education: present.add("education")
    if certifications: present.add("certifications")
    if contacts: present.add("contact")
    sections = _section_order(mode, source, present)

    # Directed mode is a projection: data outside the allow list is removed, not merely hidden in UI.
    allowed = set(sections)
    if mode == "directed":
        if "experience" not in allowed: experience = []
        if "projects" not in allowed: projects = []
        if "skills" not in allowed: skills = []
        if "education" not in allowed: education = []
        if "certifications" not in allowed: certifications = []
        if "highlights" not in allowed: highlights = []
        if "contact" not in allowed: contacts = []

    return {
        "schema_version": "2.0",
        "mode": mode,
        "theme": theme,
        "target": str(meta.get("target", "")).strip(),
        "identity": identity,
        "highlights": highlights,
        "experience": experience,
        "projects": projects,
        "skills": skills,
        "education": education,
        "certifications": certifications,
        "contacts": contacts,
        "sections": sections,
        "navigation": _navigation(mode, sections, contacts),
        "privacy": {
            "visitor_log": False,
            "analytics": False,
            "collect_location": False,
            "raw_private_contacts_embedded": False,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Compile personal-profile source JSON into a safe public presentation model.")
    parser.add_argument("source", type=Path)
    parser.add_argument("-o", "--output", type=Path, required=True)
    args = parser.parse_args()
    source = json.loads(args.source.read_text(encoding="utf-8"))
    compiled = compile_profile(source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(compiled, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"compiled: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
