#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

TEXT_SUFFIXES = {".js", ".ts", ".json", ".wxml", ".wxss", ".md"}
PAGE_EXTS = (".js", ".json", ".wxml", ".wxss")
SECRET_PATTERNS = [
    re.compile(r"(?i)\b(?:appsecret|app_secret|client_secret|api[_-]?key|private[_-]?key|access[_-]?token)\b\s*[:=]\s*['\"][^'\"]{8,}['\"]"),
]
HTTP_RE = re.compile(r"http://(?!localhost\b|127\.0\.0\.1\b|0\.0\.0\.0\b)[^\s'\"<>]+", re.I)


@dataclass
class ValidationResult:
    project_root: Path
    source_root: Path
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


def _load_json(path: Path, errors: list[str]) -> Any | None:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        errors.append(f"missing JSON file: {path}")
    except json.JSONDecodeError as exc:
        errors.append(f"invalid JSON: {path} ({exc.msg} at line {exc.lineno}, column {exc.colno})")
    except OSError as exc:
        errors.append(f"cannot read JSON: {path} ({exc})")
    return None


def _resolve_source_root(project_root: Path, project_cfg: dict[str, Any], errors: list[str]) -> Path:
    rel = project_cfg.get("miniprogramRoot") or "."
    if not isinstance(rel, str):
        errors.append("project.config.json miniprogramRoot must be a string")
        return project_root
    source_root = (project_root / rel).resolve()
    try:
        source_root.relative_to(project_root.resolve())
    except ValueError:
        errors.append("miniprogramRoot escapes project directory")
        return project_root
    if not source_root.is_dir():
        errors.append(f"miniprogramRoot does not exist: {rel}")
    return source_root


def _normalize_route(route: str) -> str:
    return route.strip().strip("/").replace("\\", "/")


def _route_is_safe(route: str) -> bool:
    parts = [p for p in _normalize_route(route).split("/") if p]
    return bool(parts) and all(p not in {".", ".."} for p in parts)


def _declared_routes(app_cfg: dict[str, Any], errors: list[str]) -> list[str]:
    routes: list[str] = []
    pages = app_cfg.get("pages", [])
    if not isinstance(pages, list) or not all(isinstance(x, str) for x in pages):
        errors.append("app.json pages must be an array of strings")
        pages = []
    for item in pages:
        if not _route_is_safe(item):
            errors.append(f"unsafe page route: {item}")
            continue
        routes.append(_normalize_route(item))

    raw_subs = app_cfg.get("subPackages", app_cfg.get("subpackages", []))
    if raw_subs is None:
        raw_subs = []
    if not isinstance(raw_subs, list):
        errors.append("app.json subPackages/subpackages must be an array")
        raw_subs = []
    seen_roots: set[str] = set()
    for idx, sub in enumerate(raw_subs):
        if not isinstance(sub, dict):
            errors.append(f"subpackage #{idx + 1} must be an object")
            continue
        root = sub.get("root")
        spages = sub.get("pages")
        if not isinstance(root, str) or not root.strip():
            errors.append(f"subpackage #{idx + 1} root must be a non-empty string")
            continue
        root_n = _normalize_route(root)
        if root_n in seen_roots:
            errors.append(f"duplicate subpackage root: {root_n}")
        seen_roots.add(root_n)
        if not isinstance(spages, list) or not all(isinstance(x, str) for x in spages):
            errors.append(f"subpackage {root_n} pages must be an array of strings")
            continue
        for item in spages:
            full = f"{root_n}/{_normalize_route(item)}"
            if not _route_is_safe(root) or not _route_is_safe(item):
                errors.append(f"unsafe page route: {full}")
                continue
            routes.append(full)
    return routes


def _validate_page_files(source_root: Path, routes: list[str], errors: list[str]) -> None:
    seen: set[str] = set()
    for route in routes:
        if not route or route in seen:
            if route in seen:
                errors.append(f"duplicate page route: {route}")
            continue
        seen.add(route)
        base = source_root / route
        for ext in PAGE_EXTS:
            path = base.with_suffix(ext)
            if not path.is_file():
                errors.append(f"missing page file: {path.relative_to(source_root) if source_root in path.parents else path}")


def _validate_tabbar(source_root: Path, app_cfg: dict[str, Any], declared: set[str], errors: list[str]) -> None:
    tab = app_cfg.get("tabBar")
    if tab is None:
        return
    if not isinstance(tab, dict):
        errors.append("app.json tabBar must be an object")
        return
    items = tab.get("list", [])
    if not isinstance(items, list):
        errors.append("app.json tabBar.list must be an array")
        return
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"tabBar item #{idx + 1} must be an object")
            continue
        route = item.get("pagePath")
        if not isinstance(route, str):
            errors.append(f"tabBar item #{idx + 1} pagePath must be a string")
            continue
        route_n = _normalize_route(route)
        if route_n not in declared:
            errors.append(f"tabBar pagePath must be a declared main-package page: {route_n}")
        for key in ("iconPath", "selectedIconPath"):
            icon = item.get(key)
            if isinstance(icon, str) and icon.strip():
                icon_path = source_root / _normalize_route(icon)
                if not icon_path.is_file():
                    errors.append(f"tabBar icon does not exist: {icon}")


def _component_target_exists(source_root: Path, owner_json: Path, target: str) -> bool:
    if target.startswith("plugin://") or target.startswith("ext://"):
        return True
    if not target.startswith(("/", ".")):
        return True
    if target.startswith("/"):
        base = source_root / target.lstrip("/")
    else:
        base = owner_json.parent / target
    candidates = [base.with_suffix(ext) for ext in (".js", ".json", ".wxml")]
    return all(p.is_file() for p in candidates)


def _validate_components(source_root: Path, errors: list[str]) -> None:
    for json_path in source_root.rglob("*.json"):
        cfg = _load_json(json_path, errors)
        if not isinstance(cfg, dict):
            continue
        comps = cfg.get("usingComponents")
        if comps is None:
            continue
        if not isinstance(comps, dict):
            errors.append(f"usingComponents must be an object: {json_path.relative_to(source_root)}")
            continue
        for alias, target in comps.items():
            if not isinstance(target, str):
                errors.append(f"component path for {alias} must be a string: {json_path.relative_to(source_root)}")
                continue
            if not _component_target_exists(source_root, json_path, target):
                errors.append(f"component target missing for {alias}: {target} ({json_path.relative_to(source_root)})")


def _scan_text(source_root: Path, release: bool, errors: list[str], warnings: list[str]) -> None:
    for path in source_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = path.relative_to(source_root)
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                errors.append(f"possible client-side secret literal: {rel}")
                break
        if HTTP_RE.search(text):
            msg = f"insecure remote HTTP URL found: {rel}"
            (errors if release else warnings).append(msg)


def _private_contact_values(profile_source: str | Path | dict[str, Any] | None, errors: list[str]) -> list[str]:
    if profile_source is None:
        return []
    if isinstance(profile_source, dict):
        source = profile_source
    else:
        source = _load_json(Path(profile_source), errors)
        if not isinstance(source, dict):
            return []
    values: list[str] = []
    contacts = source.get("contacts", [])
    if isinstance(contacts, list):
        for item in contacts:
            if not isinstance(item, dict):
                continue
            visibility = str(item.get("visibility", "public")).strip().lower()
            value = str(item.get("value", "")).strip()
            if visibility in {"gated", "hidden"} and value:
                values.append(value)
    return values


def _scan_private_leaks(project_root: Path, values: list[str], errors: list[str]) -> None:
    if not values:
        return
    for path in project_root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for value in values:
            if value in text:
                errors.append(f"private/gated contact leaked into project: {path.relative_to(project_root)}")
                break


def validate_project(project_root: str | Path, release: bool = False, profile_source: str | Path | dict[str, Any] | None = None) -> ValidationResult:
    project_root = Path(project_root).resolve()
    errors: list[str] = []
    warnings: list[str] = []
    if not project_root.is_dir():
        return ValidationResult(project_root, project_root, [f"project directory does not exist: {project_root}"], [])

    cfg_path = project_root / "project.config.json"
    project_cfg = _load_json(cfg_path, errors)
    if not isinstance(project_cfg, dict):
        project_cfg = {}
    source_root = _resolve_source_root(project_root, project_cfg, errors)

    app_path = source_root / "app.json"
    app_cfg = _load_json(app_path, errors)
    if not isinstance(app_cfg, dict):
        app_cfg = {}

    for required in ("app.js", "app.wxss"):
        if not (source_root / required).is_file():
            errors.append(f"missing app file: {required}")

    routes = _declared_routes(app_cfg, errors)
    if not routes:
        errors.append("no pages declared in app.json")
    _validate_page_files(source_root, routes, errors)
    main_pages_raw = app_cfg.get("pages", []) if isinstance(app_cfg.get("pages", []), list) else []
    main_routes = {_normalize_route(x) for x in main_pages_raw if isinstance(x, str) and _route_is_safe(x)}
    _validate_tabbar(source_root, app_cfg, main_routes, errors)
    _validate_components(source_root, errors)

    cloud_root = project_cfg.get("cloudfunctionRoot")
    if cloud_root is not None:
        if not isinstance(cloud_root, str):
            errors.append("project.config.json cloudfunctionRoot must be a string")
        elif not (project_root / cloud_root).is_dir():
            errors.append(f"cloudfunctionRoot does not exist: {cloud_root}")

    _scan_text(source_root, release, errors, warnings)
    _scan_private_leaks(project_root, _private_contact_values(profile_source, errors), errors)
    return ValidationResult(project_root, source_root, errors, warnings)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a generated WeChat Mini Program project.")
    parser.add_argument("project", nargs="?", default=".", help="Project directory containing project.config.json")
    parser.add_argument("--release", action="store_true", help="Treat insecure remote HTTP endpoints as errors")
    parser.add_argument("--profile-source", help="Optional source profile JSON; gated/hidden contact values must not appear in the project")
    args = parser.parse_args()
    result = validate_project(args.project, release=args.release, profile_source=args.profile_source)
    print(f"project: {result.project_root}")
    print(f"source:  {result.source_root}")
    for item in result.warnings:
        print(f"WARN: {item}")
    for item in result.errors:
        print(f"ERROR: {item}")
    print(f"result: {'PASS' if result.ok else 'FAIL'} ({len(result.errors)} errors, {len(result.warnings)} warnings)")
    return 0 if result.ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
