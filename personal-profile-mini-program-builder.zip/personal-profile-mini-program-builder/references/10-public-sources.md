# Public Sources / Provenance

本包不捆绑第三方代码。设计与工程判断参考公开资料，使用时应优先核对最新官方文档：

- WeChat Mini Program official developer docs: https://developers.weixin.qq.com/miniprogram/dev/framework/
- WeChat Mini Program official demo repository: https://github.com/wechat-miniprogram/miniprogram-demo
- WeUI MiniProgram: https://github.com/wechat-miniprogram/weui-miniprogram
- Community resume Mini Program pattern reference: https://github.com/Princeling66/resume-miniprogram
- Community native resume Mini Program pattern reference: https://github.com/jackchen0120/wxResume

社区项目只用于观察常见页面/交互与工程形态，不复制其源码、品牌或内容。
