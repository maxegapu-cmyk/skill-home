# 原生工程与后端边界

## 默认工程

`project.config.json` + `miniprogram/`；页面使用原生 WXML/WXSS/JS/JSON。静态个人资料优先本地 `data/profile.js`，不依赖 npm，确保导入即能跑。

## 兼容

识别 `miniprogramRoot`、`cloudfunctionRoot`、`subPackages/subpackages`。tabBar 只能指向主包页面。本地 usingComponents 校验实际文件；npm/插件协议不误判成本地缺文件。

## 云开发

仅在远程更新、受控访问、管理后台等需求出现时引入。高权限写操作和私密字段放云端；数据库权限不允许客户端全表任意读写。不要把 AppSecret、私钥、长期 token 放小程序源码。

## 网络

生产远程接口使用 HTTPS。真实后端契约未知时只做明确的未配置状态，不伪造 API 成功。

## 当前平台规则

隐私接口、审核、业务域名、类目、基础库能力会变化；实现前核对微信官方开发文档与官方示例仓库。代码静态通过不等于平台审核通过。
