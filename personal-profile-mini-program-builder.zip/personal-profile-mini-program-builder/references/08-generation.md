# 生成契约

1. 先完成 source profile → compiled profile 的数据投影。
2. 写 project.config.json / app.json，再按路由生成页面四件套。
3. 首页必须在资料很少时也成立；无项目/无经历时不出现空导航。
4. 项目详情通过稳定 id 查找，不按数组索引当长期标识。
5. public 联系方式支持复制；gated 只显示 CTA；hidden 不存在于工程文本。
6. 默认不实现访客记录、登录、定位、相册、支付等无关能力。
7. 模拟数据与真实数据分离，禁止把示例当成用户事实。
8. 远程图片/链接失败必须不破坏基本阅读。
9. 发布前运行 validator；有 source profile 时额外跑隐私泄漏扫描。

`scaffold_project.py` 生成的是安全基线，可继续由执行模型重做视觉和页面，但修改后仍必须满足以上不变量。
