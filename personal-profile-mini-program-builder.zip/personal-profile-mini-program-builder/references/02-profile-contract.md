# Profile SSoT 合同

唯一真源采用 `schemas/profile.schema.json` 描述的 JSON。字段允许稀疏，不要求为了“看起来完整”硬填。

核心区：

- `meta`：mode、theme、target、allow_sections。
- `identity`：name、headline、summary、avatar、location。
- `highlights`：最重要的 1–5 条事实。
- `experience`：company、role、period、summary、highlights。
- `projects`：id、title、summary、role、period、tags、highlights、media、links。
- `skills`：name，可选 group/level_note；禁止凭空生成百分比熟练度。
- `education` / `certifications`。
- `contacts`：kind、label、value、visibility、cta。

## 数据真值

允许：压缩、排序、改写语序、合并重复、把用户已经给出的数字放到更醒目的地方。

禁止：补造百分比、营收、DAU、排名、客户名称、学历、职位、奖项、证书、合作品牌、年份、推荐语。缺少证据时宁可写“负责 X / 完成 Y”，不要写“提升 43%”。

## 项目 ID

用户未提供时可由标题生成稳定 slug；中文标题无法稳定拉丁化时使用 `project-N`。重复 ID 必须报错，不静默覆盖。
