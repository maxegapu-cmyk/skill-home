# QA 与修复

## A. 静态结构

`python scripts/validate_project.py /path/to/project --release`

有源资料时：

`python scripts/validate_project.py /path/to/project --release --profile-source /path/to/profile.json`

ERROR 不绕过。

## B. 开发者工具

导入、编译、首页、tabBar、所有路由、项目详情、复制联系方式、分享入口；控制台无未处理异常。

## C. 真机

至少验证窄屏/高屏、中文长文本、远程图失败、复制联系信息、返回/二次进入。若增加登录、位置、相册、订阅、云函数，必须跑真实权限拒绝和失败恢复。

## 修复优先级

1. 隐私/秘密泄漏与错误写操作。
2. 无法导入/编译。
3. 主流程死路、路由/项目详情错误。
4. 空数据/错误不可恢复。
5. 小屏和长文本。
6. 视觉细节。
