---
name: personal-profile-mini-program-builder
description: Use when creating, rebuilding, extending, repairing, or reviewing a personal resume, profile, portfolio, creator card, or targeted-introduction WeChat Mini Program from rough personal materials, structured profile data, or an existing Mini Program project.
---

# Personal Profile Mini Program Builder v2.0

把零散个人资料变成**可导入微信开发者工具、信息层级专业、隐私边界明确、可继续维护**的原生微信小程序。目标不是“把 PDF 简历搬上手机”，而是把同一份个人资料 SSoT 编译成适合微信场景的个人主页、职业简历、作品集或定向展示产品。

## 先做什么

1. 读 `references/01-intake-modes.md`，确认用途、受众与运行模式；信息不阻断时直接采用默认值，不把技术选型甩给用户。
2. 按 `references/02-profile-contract.md` 整理单一资料源。若用户给的是散文、旧简历、聊天记录或项目清单，先结构化；**不得编造公司、学历、数字、奖项、客户、职位或效果指标**。
3. 运行 `python scripts/compile_profile.py profile.json -o compiled.json`。编译层负责模式、章节、项目 ID 与隐私投影；需要更精细的人工判断时再按参考文件修订 compiled model。
4. 按 `references/03-information-architecture.md` 决定页面与顺序；按 `references/04-content-editor.md` 做内容压缩；按 `references/05-visual-system.md` 生成视觉层。
5. 默认原生 `WXML + WXSS + JavaScript + JSON`。工程与云开发边界按 `references/07-engineering.md`；生成规则按 `references/08-generation.md`。
6. 可用 `python scripts/scaffold_project.py compiled.json out --compiled` 生成一个安全、无第三方依赖的原生基线工程，再继续做定制 UI；它是可靠起点，不是限制设计上限的模板。
7. 完成后执行 `python scripts/validate_project.py <项目目录> --release`。若仍持有源资料，再加 `--profile-source profile.json` 检查隐藏/受限联系方式是否泄漏。按 `references/09-qa-repair.md` 修到通过。

## 三种模式

- `career`：职业名片 / 求职简历。优先身份定位、经历、成果证据、项目、技能、教育与联系。
- `portfolio`：设计师、开发者、导演、创作者、自由职业者作品集。优先项目/作品、角色与贡献、视觉证据、技能，再补经历。
- `directed`：面向特定客户、合作方、招聘方或场景的定向展示。只编译明确允许的章节；未允许内容从数据投影中移除，不靠 CSS 隐藏。
- `auto`：未指定时由资料特征裁定；普通资料默认 `career`，项目/媒体证据明显丰富时可进入 `portfolio`。

## 隐私硬规则

读取 `references/06-privacy-sharing.md`。默认：访客记录 OFF、行为分析 OFF、定位采集 OFF、无需登录即可浏览。联系方式必须标记 `public / gated / hidden`：

- `public` 可进入客户端并支持复制；
- `gated` 的原始值**不得进入静态客户端包**，只显示“联系本人获取”等安全 CTA；若真要解锁，必须设计受信后端和权限流程；
- `hidden` 完全从公开投影移除。

不要把手机号、邮箱、微信号、身份证、住址、生日、私钥、AppSecret、长期 token 等“先写进 JS 再隐藏”。视觉隐藏不等于数据隐藏。

## 内容裁决

- 首页第一屏回答三件事：**我是谁、我能解决什么、为什么值得继续看**。
- 每一条经历/项目尽量包含“场景 → 责任/动作 → 可验证结果或产物”。用户没给指标就不要补百分比。
- 不把十几项技能做成等权标签墙；只展示能支撑目标身份的技能。
- 作品集项目详情优先放：项目目标、本人角色、关键决策/工作、结果/产物、可公开链接与媒体。
- 长资料做删减和层级，不靠把所有字缩小塞进一页。

## UI 裁决

默认三套视觉方向仅是设计语言，不是固定皮肤：`executive`、`minimal`、`creator`。正文可读性、触控面积、窄屏适配、长中文、空数据、图片失败优先于装饰。不要做自动轮播、夸张首屏动画、技能百分比进度条、无意义数字滚动，除非用户的内容确实需要。

## 工程不变量

继承原生小程序工程级约束：页面四件套齐全；`app.json` 路由、tabBar、分包与实际文件一致；识别 `miniprogramRoot/cloudfunctionRoot`；本地组件、npm 组件和插件路径正确；远程接口发布使用 HTTPS；密钥不进客户端；加载、空数据、错误、权限拒绝、重复提交都有可恢复反馈。

用户已有项目时遵循原技术栈，不为了本 Skill 强制改回原生 JS。用户只要展示型资料时，**静态本地数据优先**；只有需要远程更新、受控解锁、访客后台等真实需求时才引入云开发/后端。

## 交付合同

每次完成至少交付：

1. 可导入微信开发者工具的工程目录；
2. 资料 SSoT 或结构化输入（若用户允许保存）；
3. 已实现页面与模式说明；
4. 未配置的 AppID、云环境、业务域名等外部事项；
5. `validate_project.py --release` 的真实输出；
6. 若有隐私字段，说明哪些进入客户端、哪些被剥离；
7. 对涉及隐私 API、云开发、审核、类目等易变平台能力，核对当前微信官方文档后再落地，不拿旧 API 记忆硬写。
