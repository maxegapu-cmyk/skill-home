# 改图一把过 v2.0.0 — TEST REPORT

测试日期：2026-10-02

## 实际执行结果
- `scripts/validate_package.py`：PASS。
- `evals/trials.yaml`：PyYAML 解析 PASS，13 条 trial，其中 2 条 should_trigger=false。
- `scripts/contact_sheet.py --selftest`：PASS；got=(760, 210)，expected=(760, 210)。
- `scripts/perspective_guides.py --selftest`（OpenCV）：PASS；expected=(470,210)，estimated=(470.0,209.6)，error=0.38px，limit=27.00px。
- `PIC_FIX_FORCE_NO_CV2=1 scripts/perspective_guides.py --selftest`：降级九宫格路径 PASS。
- Python `py_compile`：三个脚本 PASS。

## 文件树与行数
```text
CHANGELOG.md  [19 lines]
README.md  [27 lines]
SKILL.md  [113 lines]
TEST-REPORT.md  [56 lines]
assets/character-card.md  [21 lines]
assets/prop-card.md  [14 lines]
assets/quick-commands.md  [17 lines]
assets/report-template.md  [16 lines]
assets/scene-card.md  [13 lines]
assets/session-state-template.yaml  [20 lines]
evals/trials.yaml  [82 lines]
portable/chatgpt-instructions.md  [76 lines]
references/asset-cards.md  [26 lines]
references/checklists.md  [48 lines]
references/continuity.md  [26 lines]
references/failure-modes.md  [25 lines]
references/fix-playbook.md  [48 lines]
references/perspective.md  [48 lines]
references/platform-notes.md  [22 lines]
references/prompt-templates.md  [52 lines]
references/scoring-and-gates.md  [25 lines]
references/sources.md  [30 lines]
references/workflow.md  [56 lines]
scripts/contact_sheet.py  [64 lines]
scripts/perspective_guides.py  [142 lines]
scripts/validate_package.py  [41 lines]
```

## 干净解压复验
- 候选 ZIP `unzip -t`：PASS，无压缩数据错误。
- 在全新目录从 ZIP 解压后：`validate_package.py` PASS；三个脚本 `py_compile` PASS；contact sheet selftest PASS；透视 OpenCV selftest PASS；强制无 OpenCV 降级 selftest PASS；YAML 解析 PASS。

## 已验证范围
- 包结构、SKILL.md 行数、SKILL 对全部文件的引用、便携版长度、eval 数量与不触发条目数量。
- YAML 语法可解析。
- 两个辅助脚本的自测试；透视脚本同时覆盖 OpenCV 与无 OpenCV 降级路径。
- Python 语法编译。

## 没有验证的内容
- 没有对真实 ChatGPT、Gemini、即梦图片编辑接口做自动化端到端出图测试，因为本包不包含这些平台的调用凭据或统一图像编辑 API。
- 没有宣称真实图片上的透视/面貌判断达到测量级精度；这些仍是目测与辅助线结合的判断。
- 没有验证 Photoshop 不同版本的菜单文案完全一致；步骤按功能原理书写。
