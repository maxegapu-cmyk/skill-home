#!/usr/bin/env python3
import argparse
import json
import math
import sys
import os
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except Exception as e:
    print("错误：需要 Pillow。请先安装 pillow。", file=sys.stderr)
    raise SystemExit(2) from e

if os.environ.get("PIC_FIX_FORCE_NO_CV2") == "1":
    HAS_CV2 = False
else:
    try:
        import cv2
        import numpy as np
        HAS_CV2 = True
    except Exception:
        HAS_CV2 = False


def line_intersection(l1, l2):
    x1,y1,x2,y2=l1; x3,y3,x4,y4=l2
    den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)
    if abs(den) < 1e-9:
        return None
    px=((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/den
    py=((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/den
    return px,py


def estimate_vp_cv2(path):
    img=cv2.imread(str(path))
    if img is None:
        raise ValueError("无法读取图片")
    gray=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges=cv2.Canny(gray, 50, 150, apertureSize=3)
    lines=cv2.HoughLinesP(edges,1,np.pi/180,threshold=45,minLineLength=max(30,img.shape[1]//8),maxLineGap=12)
    if lines is None:
        return None, []
    filtered=[]
    for raw in lines[:,0,:]:
        x1,y1,x2,y2=map(float,raw)
        ang=abs(math.degrees(math.atan2(y2-y1,x2-x1)))
        if 5 < ang < 85 or 95 < ang < 175:
            filtered.append((x1,y1,x2,y2))
    pts=[]
    w=img.shape[1]; h=img.shape[0]
    for i in range(len(filtered)):
        for j in range(i+1,len(filtered)):
            p=line_intersection(filtered[i],filtered[j])
            if not p: continue
            x,y=p
            if -w <= x <= 2*w and -h <= y <= 2*h:
                a1=math.atan2(filtered[i][3]-filtered[i][1],filtered[i][2]-filtered[i][0])
                a2=math.atan2(filtered[j][3]-filtered[j][1],filtered[j][2]-filtered[j][0])
                da=abs((a1-a2+math.pi)%(2*math.pi)-math.pi)
                if math.radians(12) < da < math.radians(168):
                    pts.append((x,y))
    if len(pts) < 3:
        return None, filtered
    arr=np.array(pts,dtype=np.float32)
    med=np.median(arr,axis=0)
    d=np.linalg.norm(arr-med,axis=1)
    cutoff=np.percentile(d,35) if len(d)>5 else np.max(d)
    core=arr[d<=cutoff]
    if len(core)<3: core=arr
    vp=np.median(core,axis=0)
    return (float(vp[0]),float(vp[1])), filtered


def draw_overlay(image_path, out_path, horizon_y=None, vp=None, lines=None):
    im=Image.open(image_path).convert("RGB")
    d=ImageDraw.Draw(im)
    w,h=im.size
    for x in (w/3,2*w/3): d.line((x,0,x,h), fill=(255,255,0), width=2)
    for y in (h/3,2*h/3): d.line((0,y,w,y), fill=(255,255,0), width=2)
    if horizon_y is not None:
        d.line((0,horizon_y,w,horizon_y), fill=(0,255,255), width=3)
    if lines:
        for x1,y1,x2,y2 in lines[:40]: d.line((x1,y1,x2,y2), fill=(255,80,80), width=1)
    if vp:
        x,y=vp; r=8
        d.ellipse((x-r,y-r,x+r,y+r), outline=(0,255,0), width=3)
    im.save(out_path)


def selftest(tmp_dir):
    tmp=Path(tmp_dir); tmp.mkdir(parents=True,exist_ok=True)
    w,h=900,600; vp=(470,210)
    im=Image.new("RGB",(w,h),"white"); d=ImageDraw.Draw(im)
    bottoms=[40,120,200,280,360,440,520,600,680,760,840]
    for x in bottoms:
        d.line((x,h-10,vp[0],vp[1]), fill="black", width=4)
    for y in [300,360,430,500,570]: d.line((80,y,820,y), fill=(180,180,180), width=2)
    src=tmp/"synthetic-perspective.png"; im.save(src)
    if not HAS_CV2:
        out=tmp/"fallback-grid.png"; draw_overlay(src,out,horizon_y=vp[1])
        print("SELFTEST perspective_guides: SKIP-VP (OpenCV unavailable) | fallback grid PASS")
        return 0
    est, lines=estimate_vp_cv2(src)
    if est is None:
        print("SELFTEST perspective_guides: FAIL | 未估算出灭点")
        return 1
    err=math.hypot(est[0]-vp[0],est[1]-vp[1]); limit=w*0.03
    out=tmp/"overlay.png"; draw_overlay(src,out,horizon_y=vp[1],vp=est,lines=lines)
    ok=err < limit
    print(f"SELFTEST perspective_guides: {'PASS' if ok else 'FAIL'} | expected={vp} estimated=({est[0]:.1f},{est[1]:.1f}) error={err:.2f}px limit={limit:.2f}px")
    return 0 if ok else 1


def main():
    ap=argparse.ArgumentParser(description="画九宫格/视平线，并可用OpenCV估算主灭点。辅助用途，不是判决依据。")
    ap.add_argument("--image")
    ap.add_argument("--out", default="perspective-overlay.png")
    ap.add_argument("--json-out", default=None)
    ap.add_argument("--horizon-y", type=float, default=None)
    ap.add_argument("--selftest", action="store_true")
    args=ap.parse_args()
    if args.selftest:
        return selftest(Path(__file__).resolve().parent / "_selftest_perspective")
    if not args.image:
        ap.error("请提供 --image，或使用 --selftest。")
    vp=None; lines=[]; mode="fallback-grid"
    if HAS_CV2:
        try:
            vp, lines=estimate_vp_cv2(args.image); mode="opencv"
        except Exception as e:
            print(f"警告：OpenCV估算失败，降级为九宫格：{e}", file=sys.stderr)
    draw_overlay(args.image,args.out,args.horizon_y,vp,lines)
    result={"mode":mode,"vanishing_point":vp,"horizon_y":args.horizon_y,"note":"仅作辅助，需人工目测复核"}
    jout=args.json_out or str(Path(args.out).with_suffix('.json'))
    Path(jout).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"完成：{args.out}；数据：{jout}；模式：{mode}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
