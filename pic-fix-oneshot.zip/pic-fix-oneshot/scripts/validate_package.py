#!/usr/bin/env python3
import re
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REQUIRED=[
"SKILL.md","README.md","CHANGELOG.md","TEST-REPORT.md",
"references/workflow.md","references/checklists.md","references/perspective.md","references/fix-playbook.md","references/prompt-templates.md","references/asset-cards.md","references/continuity.md","references/platform-notes.md","references/sources.md","references/scoring-and-gates.md","references/failure-modes.md",
"assets/character-card.md","assets/prop-card.md","assets/scene-card.md","assets/report-template.md","assets/quick-commands.md","assets/session-state-template.yaml",
"scripts/perspective_guides.py","scripts/contact_sheet.py","scripts/validate_package.py",
"evals/trials.yaml","portable/chatgpt-instructions.md"]

fails=[]
for rel in REQUIRED:
    if not (ROOT/rel).exists(): fails.append(f"缺文件: {rel}")
skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
lines=skill.splitlines()
if len(lines)>300: fails.append(f"SKILL.md 超过300行: {len(lines)}")
for rel in REQUIRED:
    if rel=='SKILL.md': continue
    if rel not in skill: fails.append(f"SKILL.md 未提到: {rel}")

evals=(ROOT/'evals/trials.yaml').read_text(encoding='utf-8')
trial_count=len(re.findall(r'^\s*- id:',evals,re.M))
false_count=len(re.findall(r'^\s*should_trigger:\s*false\s*$',evals,re.M))
if trial_count<10: fails.append(f"evals 不足10条: {trial_count}")
if false_count<2: fails.append(f"不触发 eval 不足2条: {false_count}")
portable=(ROOT/'portable/chatgpt-instructions.md').read_text(encoding='utf-8')
if len(portable)>7500: fails.append(f"portable 超过7500字符: {len(portable)}")
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix in {'.md','.yaml','.py'} and p.name != 'validate_package.py':
        txt=p.read_text(encoding='utf-8',errors='ignore')
        if re.search(r'\b(TODO|TBD|FIXME)\b',txt): fails.append(f"残留未完成占位标记: {p.relative_to(ROOT)}")

print(f"文件数={sum(1 for p in ROOT.rglob('*') if p.is_file())} | SKILL行数={len(lines)} | evals={trial_count} | 不触发={false_count} | portable字符={len(portable)}")
if fails:
    print("VALIDATE: FAIL")
    for x in fails: print('-',x.rstrip())
    raise SystemExit(1)
print("VALIDATE: PASS")
