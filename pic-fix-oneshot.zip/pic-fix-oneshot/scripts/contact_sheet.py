#!/usr/bin/env python3
import argparse
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception as e:
    print("错误：需要 Pillow。请先安装 pillow。", file=sys.stderr)
    raise SystemExit(2) from e


def make_contact_sheet(paths, out_path, thumb_w=480, pad=16, label_h=44):
    images = []
    for p in paths:
        img = Image.open(p).convert("RGB")
        ratio = thumb_w / img.width
        h = max(1, round(img.height * ratio))
        images.append((Path(p).stem, img.resize((thumb_w, h))))
    max_h = max(img.height for _, img in images)
    canvas = Image.new("RGB", (pad + len(images) * (thumb_w + pad), pad * 2 + label_h + max_h), "white")
    draw = ImageDraw.Draw(canvas)
    for i, (label, img) in enumerate(images):
        x = pad + i * (thumb_w + pad)
        y = pad + label_h
        canvas.paste(img, (x, y))
        draw.text((x, pad + 8), label, fill="black")
    canvas.save(out_path)
    return canvas.size


def selftest(tmp_dir):
    tmp = Path(tmp_dir)
    tmp.mkdir(parents=True, exist_ok=True)
    sizes = [(120, 80), (120, 80), (120, 80)]
    paths=[]
    for i, size in enumerate(sizes):
        im=Image.new("RGB", size, (30+i*60, 60+i*30, 90+i*20))
        p=tmp/f"v{i}.png"; im.save(p); paths.append(p)
    out=tmp/"sheet.png"
    got=make_contact_sheet(paths, out, thumb_w=240, pad=10, label_h=30)
    expected=(10 + 3*(240+10), 10*2+30+160)
    ok = got == expected and out.exists()
    print(f"SELFTEST contact_sheet: {'PASS' if ok else 'FAIL'} | got={got} expected={expected} | out={out}")
    return 0 if ok else 1


def main():
    ap=argparse.ArgumentParser(description="把 v0…vn 图片并排拼成对比图。")
    ap.add_argument("images", nargs="*", help="输入图片，按版本顺序排列")
    ap.add_argument("--out", default="contact-sheet.png", help="输出PNG")
    ap.add_argument("--thumb-width", type=int, default=480)
    ap.add_argument("--selftest", action="store_true")
    args=ap.parse_args()
    if args.selftest:
        return selftest(Path(__file__).resolve().parent / "_selftest_contact")
    if not args.images:
        ap.error("请提供至少一张输入图片，或使用 --selftest。")
    size=make_contact_sheet(args.images, args.out, args.thumb_width)
    print(f"完成：{args.out}，尺寸 {size[0]}x{size[1]}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
