# 来源与核验记录

核验于 **2026-10-02**。这里只记录能支持本 Skill 设计原则的公开资料；“漫剧圈资产卡/连续性账本”属于实践方法，不冒充官方标准。

1. **OpenAI — Image prompting**  
   https://developers.openai.com/api/docs/guides/image-prompting  
   支持点：编辑时把“改变内容”和“必须保留内容”分开；明确 reference 的用途；一次有意识地改一个点并检查结果；迁移/升级图像模型时保存基线、对完整编辑链做验证。

2. **OpenAI Cookbook — GPT Image Generation Models Prompting Guide**  
   https://developers.openai.com/cookbook/examples/multimodal/image-gen-models-prompting-guide  
   支持点：编辑采用“change only X / keep everything else the same”，每轮重复 preserve list 以减少漂移；人物动作、物体交互、构图位置要写清。

3. **OpenAI — Image generation / Edit images**  
   https://developers.openai.com/api/docs/guides/image-generation  
   支持点：可用多张图片做参考；mask 可引导局部编辑但不保证精确遵循边界，因此不能把局部编辑当像素级工具。

4. **Google Developers Blog — How to prompt Gemini 2.5 Flash Image Generation for the best results**  
   https://developers.googleblog.com/en/how-to-prompt-gemini-2-5-flash-image-generation-for-the-best-results/  
   支持点：用一张或多张图片配合文字做编辑/组合/风格转换；局部编辑要明确改动目标并让修改融入原图风格、光线与透视。

5. **Google Developers Blog — Introducing Gemini 2.5 Flash Image**  
   https://developers.googleblog.com/introducing-gemini-2-5-flash-image/  
   支持点：角色/物体一致性、多图融合、自然语言定向编辑是模型能力重点，但“一致性”仍应复检而非默认成功。

6. **Google — 7 tips to get the most out of Nano Banana Pro**  
   https://blog.google/products-and-platforms/products/gemini/prompting-tips-nano-banana-pro/  
   支持点：多图输入应明确每张图角色；复杂编辑与图像融合可能产生不自然伪影；角色特征一致性仍可能变化。

7. **实践方法（非官方标准）**  
   漫剧/连载插画/电商连续图常见工程做法是把角色、道具、场景拆成可复用参考资产，固定可观察锚点，并维护跨镜头状态。v2.0 将其形式化为 Asset Lock、连续性账本和会话重启包。这里明确标注为工程实践，不声称由某一家官方定义。
