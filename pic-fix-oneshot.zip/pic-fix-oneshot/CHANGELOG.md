# CHANGELOG

## 2.0.0 — 2026-10-02
- 新增：Asset Lock（角色/服装/道具/场景不变量锁）。
- 新增：Drift Budget（关键锚点零漂移，轻微非关键变化有预算）。
- 新增：结构优先、目标完成、保留项、连续性四类质量门。
- 新增：复检必须给“版本号 + 九宫格位置 + 编号”证据。
- 新增：失败路由与两次失败自动转整图/PS，不死循环。
- 新增：会话重启包，解决连续编辑 4 轮或面貌漂移后的接续问题。
- 新增：终稿从全部通过版本中择优，不默认最后一版。
- 新增：`assets/session-state-template.yaml`。
- 新增：`references/scoring-and-gates.md`、`references/failure-modes.md`。
- 新增：`scripts/validate_package.py` 包级验收。
- 增强：透视辅助脚本增加 OpenCV 检测、JSON 输出和无 OpenCV 降级。
- 增强：contact sheet 支持任意数量图片、自动等比缩放和版本标签。
- 保留：v1.0 规定的 11 条硬规则、四大类清单、三类核心提示模板原文。

## 1.0.0
- 初版规范：体检、固定修复顺序、逐轮保留清单、失败回退、资产卡、分镜连续性、辅助脚本和便携版。
