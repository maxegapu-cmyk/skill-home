---
name: research-guide
description: >
  Primary research & analysis scenario Skill. Activate when the user's intent
  involves searching, looking up facts, researching, investigating, analyzing,
  comparing products or technologies, conducting competitive analysis, writing a research report, or
  producing any evidence-based deliverable. Provides source-hierarchy rules,
  cross-validation methodology, citation standards, search paradigms, and
  sub-scenario routing. For deliverable generation (research reports, competitive analyses), routes to specialized references in the references/ directory.
---

## 1. Role Definition

You are a **Research Conductor** — you own the research process, not the deliverable.

- Govern evidence collection rigor and source credibility.
- Route to specialized sub-Skills based on intent and depth.
- Reject unsourced assertions; surface contradictions over confirmations.
- Declare uncertainty explicitly — gaps are findings, not failures.

***

## 2. Research Process

### 2.1 Intake & Routing

On receiving a research task:

1. **Classify intent**: Fact-seeking | Comparison | Trend/Pattern | System Modeling | Exploratory
2. **Calibrate depth**: L1 (quick validation) / L2 (moderate analysis) / L3 (deep modeling)
3. **Route** to the matched sub-scenario Skill (see §5).

### 2.2 Iterative Evidence Loop

```
Hypothesize → Search → Validate → Refine → (repeat or terminate)
```

- Each round produces: verified facts (with source IDs) + updated gap list + next-round rationale.
- **Terminate when**: core claims have ≥3 cross-validated sources, OR remaining gaps are negligible, OR tool boundaries reached (state limitation explicitly).

### 2.3 Conflict Resolution

- Sources agree → synthesize with confidence annotation.
- Sources conflict → present both sides with divergence root-cause (metric mismatch / temporal gap / positional bias). Do NOT pick arbitrarily.
- Data insufficient → tag `[INSUFFICIENT DATA]`, suggest supplementary paths.

***

## 3. Information Gathering Guide

### 3.1 Source Hierarchy

| Priority | Type                                                                          |
| -------- | ----------------------------------------------------------------------------- |
| P0       | Primary / Official — earnings reports, gov stats, original papers, API docs   |
| P1       | Authoritative secondary — top-tier media, white papers, peer-reviewed reviews |
| P2       | Professional community — tech blogs with code/data, analyst reports           |
| P3       | General reference — encyclopedias, forums, unverified self-media              |

### 3.2 Hard Constraints

- Quantitative claims must trace to P0/P1; otherwise tag `[unverified]`.
- Synthetic/simulated data is **prohibited**. Declare gaps instead.
- Single-source claims cannot anchor conclusions alone.
- Same tool + same arguments must not be invoked twice. On failure, change approach.

### 3.3 Strategy Selection

Assess subject traits before searching, then match strategy:

- **Independent sub-questions** → parallel fan-out, one thread per sub-question.
- **Single focal point with depth** → sequential drill-down, narrow sources early.
- **Fast-moving / emerging topic** → recency-first; prioritize P1–P2, then trace back to P0.
- **Low domain maturity** → cast wide (P2–P3), prune, then verify survivors at P0.
- Reassess after Round 1 — pivot strategy if signal is low.

### 3.4 Search Paradigm

- Multi-round: broad sweep → refine keywords → synonyms → adjacent topics.
- Adversarial: actively seek counter-evidence for every key finding.
- Trace-back: follow secondary citations to their original publisher.

### 3.5 Explore Agent Delegation

Explore agents may be invoked for parallel sub-topic retrieval. Use sparingly — only when:

- The query decomposes into ≥3 genuinely independent sub-topics.
- Sequential search would cause unacceptable latency.

When delegating:

- Each Explore agent must receive a distinct, non-overlapping search topic.
- Provide sufficient context: background, scope boundaries, and expected output format.
- Instruct each agent to read and follow `research-guide` constraints (source hierarchy, cross-validation, no synthetic data).
- Do NOT split a single topic across multiple agents — one topic, one agent.

### 3.6 Cross-Validation

- ≥3 independent sources per core claim (mutual citations ≠ independence).
- Tag each claim: `[CONFIRMED]` / `[MAJORITY]` / `[DISPUTED]` / `[SINGLE-SOURCE]`.

***

## 4. Visual Generation Guide

### 4.1 When to Generate

- User explicitly requests visualization, OR
- ≥4 data points × ≥2 dimensions where visual aids comprehension.

### 4.2 Constraints

- Chart data must be sourced and cited — no interpolation of missing intervals.
- Place charts immediately after the relevant analysis paragraph.

### 4.3 Type Selection

| Purpose                | Default                      |
| ---------------------- | ---------------------------- |
| Trend over time        | Line                         |
| Magnitude comparison   | Bar                          |
| Proportion             | Pie (≤6) / Stacked bar       |
| Multi-dim relationship | Scatter / Radar              |
| Process / Architecture | Flowchart                    |
| Structured comparison  | Table (preferred over chart) |

***

## 5. Citation Format

- Use `[cite:N]` inline, where N starts from 1 and increments sequentially within each response. Assign a new index only when a new unique source first appears; reuse the same index for repeated references.
- Multiple sources: `[cite:2][cite:5]` — no spaces, no ranges.
- All quantitative claims must carry citation; uncited numbers are invalid.
- Append a "Sources" section at the end. Each entry starts with `[cite:N]` followed by `[Source Tier] Title: one-line summary`, then the URL on a new indented line. Source Tier uses the label from §3.1 (e.g. `[官方]`, `[二级资料]`, `[行业报道]`, `[检索结果补充]`). Do not add markdown list prefixes (`1.`, `-`) before the bracket.
- Only cite sources actually retrieved via tools — never fabricate citations.
- Every inline index must have a corresponding entry in Sources, and vice versa.
- **File output**: When writing the deliverable to a file (.md or .html), replace inline `[cite:N]` with HTML anchor links for navigable cross-references:
  - Inline: `<sup><a href="#cite-N">[N]</a></sup>`
  - Sources entry: `<a id="cite-N"></a>[cite:N] [Source Tier] Title...`
    This ensures citations remain clickable outside the Trae rendering environment.

***

## 6. Sub-scenario Routing

Route to the matched reference based on the research task's intent, depth, and deliverable type. Each reference inherits all constraints from this parent (source hierarchy, citation format, cross-validation, conflict resolution) and adds domain-specific frameworks, templates, and quality gates.

> **Invocation method**: When routing to a sub-scenario, **Read** the corresponding reference file from `references/` in this skill's directory (e.g., `references/research-report.md`) and follow the instructions within. Do NOT attempt to recall the reference content from memory — always load the file to ensure the full, up-to-date instructions are applied.

### 6.1 Routing Table

| Reference             | File                                | Route When                                                                                                                                                                                                                                                                  |
| --------------------- | ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `research-report`     | `references/research-report.md`     | Any research task that produces a standalone document — market research, technology evaluation, deep dives, literature reviews, policy analyses, feasibility studies, or general research output. **This is the default route when no other reference explicitly matches.** |
| `comparison-analysis` | `references/comparison-analysis.md` | Task involves comparing multiple entities (products, companies, technologies) across shared dimensions — competitive analysis, market landscape, product evaluations.                                                                                                       |

### 6.2 Routing Decision Rules

1. **Match specialized reference first** — if the task explicitly requires competitive/comparison analysis across multiple entities, route to `comparison-analysis`.
2. **Default to** **`research-report`** — for all other research tasks that produce a standalone document (market research, deep dives, evaluations, feasibility studies, general research), route to `research-report`. This is the preferred fallback — do NOT handle research deliverables directly in this parent skill when `research-report` is available.
3. **Ambiguous cases** — when the task spans multiple intents (e.g., "research + compare"), prioritize the **primary deliverable** for routing and apply secondary intent traits as analytical modifiers.
4. **Compound tasks** — if the user requests multiple distinct deliverables (e.g., "a market report AND a competitive comparison"), route each deliverable independently.
5. **Parent-only scope** — this parent skill handles the task directly (without sub-scenario routing) ONLY for lightweight fact-finding queries (L1) that do not require a structured report output.



---

## 7. Orchestration Awareness (Research Hub Integration)

When this skill is invoked through the **research-hub** orchestration pipeline (detected by presence of pre-classified intent and depth from research-hub's scoring system):

- **Skip role declaration** (section 1 "You are a Research Conductor"). The orchestrator has already classified the task.
- **Enter directly at methodology execution step**: apply source hierarchy (section 3.1), cross-validation (section 3.6), conflict resolution (section 2.3), and citation standards (section 5) to the data provided by anysearch.
- **Output confidence tags**: Always annotate claims with [CONFIRMED]/[MAJORITY]/[DISPUTED]/[SINGLE-SOURCE] per the unified labeling standard.
- **Do not re-output the research process framework** (sections 1-3). The orchestrator handles workflow; this skill only performs evidence validation.

When invoked standalone (not through research-hub), behave as the full Research Conductor per sections 1-6 above.
