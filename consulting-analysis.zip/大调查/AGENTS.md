# 大调查 --- 调研技能编排工具箱

## 这是什么

一套可移植的 TRAE 调研技能集，包含统一的编排入口、研究方法论、咨询级报告生成和实时搜索能力。

## 文件清单 & 部署方式

| 文件 | 用途 | 部署路径 |
|------|------|----------|
| research-hub.md | 统一入口，AI 打分+三通道编排 | 改名为 SKILL.md 放入 .trae-cn/skills/research-hub/ |
| research-guide.md | 研究方法论、信源验证 | 改名为 SKILL.md 放入 .trae-cn/builtin/work/default/skills/research-guide/ |
| consulting-analysis.md | 咨询级报告生成 Phase1+2 | 改名为 SKILL.md 放入 .trae-cn/skills/consulting-analysis/ |
| anysearch.md | 实时搜索引擎 | 改名为 SKILL.md 放入 .agents/skills/anysearch/ |
| anysearch_runtime.conf | 运行时配置 | 放入 .agents/skills/anysearch/ |
| anysearch_scripts/ | CLI 脚本(6个) | 放入 .agents/skills/anysearch/scripts/ |
| PLAN.md | 改造设计文档 | 按需查阅 |

## 部署步骤

1. 按上表将文件放入对应目录（%USERPROFILE% 开头的是Windows路径）
2. anysearch 无需 API Key（匿名可用）
3. 如需高额度：https://anysearch.com/console/api-keys 申请 Key
   写入 .agents/skills/anysearch/.env：ANYSEARCH_API_KEY=你的Key

## 架构

research-hub（统一入口）
  -> AI 意图打分（三维度0-2，总分定通道）
    -> 0-1分：快查通道
    -> 2-3分：半正式通道
    -> 4-6分：深研通道
  -> Grill-me 联动（>=2分时展示推荐路径让用户确认）
  -> 快查自动升级（信源不足/数据矛盾/新维度出现）
  -> 统一输出规范（标签/引用/结论结构）

## 三通道流程

快查(0-1分)：anysearch搜索 -> research-guide信源验证 -> 精简回答
半正式(2-3分)：anysearch搜索 -> research-guide验证 -> consulting-analysis轻量分析
深研(4-6分)：research-guide定框架 -> Phase1确认 -> anysearch逐章搜 -> Data Summary -> Phase2出报告

## 验证

在TRAE中用 Skill 工具加载对应名称即可。

## 注意

- research-guide 和 consulting-analysis 已加编排感知声明
- 统一标签：[CONFIRMED]/[MAJORITY]/[DISPUTED]/[SINGLE-SOURCE]
- 统一引用：[cite:N] 格式