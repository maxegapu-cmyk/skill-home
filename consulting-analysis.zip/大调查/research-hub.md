---
name: "research-hub"
description: "统一搜索研究入口，路由到 anysearch/research-guide/consulting-analysis/video-download/book-ingest/knowledge-search/knowledge-ingest 等子技能。当用户说搜索、查找、研究、调研、分析、报告、下载视频、导入书籍等时触发。"
---

# Research Hub - 统一搜索研究技能

## 定位

统一入口技能，根据用户输入自动路由到最合适的子技能。本技能不实现具体功能，只负责智能分发和编排调度。

## 子技能清单

| 子技能 | 功能 | 触发场景 | 路径 |
|--------|------|----------|------|
| anysearch | 通用搜索、垂直领域搜索、URL内容提取 | 搜索、查找、查询 | .agents/skills/anysearch |
| research-guide | 研究方法论、信源管理、交叉验证 | 调研、研究 | builtin/work/default/skills |
| consulting-analysis | 咨询级分析报告生成 | 分析报告、市场分析、竞品分析 | skills/consulting-analysis |
| video-download | 视频/音频/字幕下载 | 下载视频、YouTube、B站 | skills/video-download |
| book-ingest | 电子书转换并导入知识库 | 导入书籍、电子书 | skills/book-ingest |
| knowledge-search | 知识库内容搜索 | 搜索知识库、查找笔记 | skills/knowledge-search |
| knowledge-ingest | 内容导入知识库 | 导入文章、导入URL | skills/knowledge-ingest |

---

## A. 基础路由（非调研技能）

保留现有简单路由规则，仅处理 video-download / book-ingest / knowledge-search / knowledge-ingest。

### 优先级规则（从高到低）

```
优先级1: 具体资源URL/文件路径
  - 视频平台URL → video-download
  - 书籍文件路径（.epub/.pdf/.mobi）+ 导入动作 → book-ingest

优先级2: 明确动作词匹配
  - 下载 + 视频/音频/YouTube/B站 → video-download
  - 导入 + 书籍/电子书/EPUB/PDF → book-ingest

优先级3: 上下文语义判断
  - 知识库/笔记/Obsidian 相关 → knowledge-search / knowledge-ingest
  - 模糊输入 → 询问用户
```

### 触发词定义

#### 视频下载触发词
- 直接触发：下载视频、下载音频、下载字幕、下载播放列表
- 平台触发：YouTube、B站、bilibili、Vimeo、TikTok
- URL触发：包含 youtube.com、youtu.be、bilibili.com、vimeo.com、tiktok.com

#### 书籍导入触发词
- 动作词：导入书籍、导入电子书、书籍导入
- 格式词：EPUB、PDF导入、MOBI
- 文件路径：包含 .epub、.pdf、.mobi 扩展名

#### 知识库触发词
- 动作词：搜索知识库、查找笔记、导入知识库
- 工具词：知识库、Obsidian、笔记库

### 冲突解决规则

```
规则1：具体资源优先
  "搜索YouTube视频教程" → 检测到YouTube URL → video-download

规则2：歧义询问
  "这本书不错" → 无法判断意图 → 询问用户选项

规则3：链式需求拆分
  "下载这个视频并分析内容" → 拆分为两个子任务
    1. video-download 下载视频
    2. consulting-analysis 分析内容
```

---

## B. 调研技能编排（核心改动）

当用户输入命中"研究/调研/分析/报告/搜索/查找/查询"等调研类动作时，走以下编排逻辑。

### B1. AI 意图打分

从三个维度对用户请求打分（0-2分），总分决定通道：

| 维度 | 0 分 | 1 分 | 2 分 |
|------|------|------|------|
| **产出期望** | 几句话回答就行 | 需要结构化分析但不必正式文档 | 明确要正式报告/文档 |
| **问题复杂度** | 单一事实/数据查询 | 多维度交叉分析 | 跨领域（市场+竞争+战略等） |
| **信息来源需求** | 1-2 个源就能覆盖 | 需要跨源验证 | 需要多轮搜索+信源交叉验证 |

**通道规则：**
- 0-1 分 → 快查通道
- 2-3 分 → 半正式通道
- 4-6 分 → 深研通道

### B2. Grill-me 联动确认

当总分 >= 2 分时，AI 先向用户展示判断结果和推荐路径：

```
"我判断这个请求：
 - 产出期望：2 分（需要正式报告）
 - 问题复杂度：1 分（多维度分析）
 - 信息来源需求：2 分（需要交叉验证）
 -> 总分 5 分，推荐走深研通道（出完整分析报告）

直接开始还是调整？"
```

用户确认后走对应通道，用户调整则根据反馈重新判断。

### B3. 三条通道执行流程

#### 快查通道（0-1 分）

```
1. 调 anysearch 搜索 1-2 轮，获取核心数据
2. 调 research-guide 做信源验证：
   - 检查核心数据点是否有 >=2 个独立来源
   - 标注置信度：[CONFIRMED] / [SINGLE-SOURCE]
   - 标注矛盾：如果有 >30% 偏差的来源，标记 [DISPUTED]
3. 检查升级条件（见 B4）--满足任一则自动升级到半正式通道
4. 生成精简回答：核心数据 + 来源 + 置信度标签
```

**输出格式要求：** 对话直接回答，三要素：数据、来源、标签。不生成文件。

#### 半正式通道（2-3 分）

```
1. 调 anysearch 搜索 1-2 轮，收集数据和观点
2. 调 research-guide 做信源验证 + 矛盾标注
3. 调 consulting-analysis（轻量模式）：
   - 不走完整 Phase 1 框架文档
   - 直接用其分析逻辑（数据->原因->含义）写一段结构化分析
   - 产出：有标题、数据对比表、结论段落的 Markdown 分析
4. 不需要 Abstract / Introduction / Conclusion 完整结构
```

**输出格式要求：** Markdown 结构化分析段落。统一使用 [CONFIRMED]/[MAJORITY]/[DISPUTED]/[SINGLE-SOURCE] 标签。引用格式统一 [cite:N]。

#### 深研通道（4-6 分）

```
1. 加载 research-guide，按 section 6 路由到 references/research-report.md
2. 加载 consulting-analysis，执行 Phase 1 出分析框架文档
3. 暂停，展示框架给用户确认（Phase 1 output）
4. 用户确认后：
   a. 从 Phase 1 的 Data Requirements 提取 Search Keywords
   b. 调 anysearch 逐章节搜索，收集定量数据、定性信息、来源URL
   c. 将 anysearch 搜索结果按 consulting-analysis Phase 2 要求的格式
      整理成 Data Summary（每章节一个数据模块）
   d. 加载 consulting-analysis，传入 Data Summary，执行 Phase 2 出报告
5. 如果 anysearch 搜索过程中发现数据不足以支撑原框架，
   返回重新和用户确认调整分析方向
```

**Data Summary 模板（AI 手动整理 anysearch 结果时使用）：**

```markdown
## Data Summary

### 章节 1：[标题]

| 数据指标 | 数值 | 来源 | 置信度 |
|---------|------|------|-------|
| ... | ... | [url] | [CONFIRMED] |

### 章节 2：[标题]
...
```

**输出格式要求：** consulting-analysis Phase 2 完整报告（Abstract -> 引言 -> 正文 -> 结论 -> References）。统一使用 [cite:N] 格式引用。

### B4. 快查自动升级条件

快查通道满足以下任一条件时，自动升级到半正式通道：

| 触发条件 | 示例 |
|---------|------|
| **核心数据点信源不足 2 个** | 搜"XX 市场规模"，只有 1 个来源 |
| **关键数据存在明显矛盾（偏差 > 30%）** | 来源 A 说 500 亿，来源 B 说 800 亿 |
| **anysearch 结果中出现新的重要维度** | 搜索结果频繁提到新进入者/政策变化/技术突破，值得深挖 |

升级到半正式后，如果过程中发现信息量大到需要完整报告，再二次触发深研通道。

---

## C. 统一输出规范（所有调研通道通用）

### C1. 数据置信度标签体系

| 标签 | 含义 |
|------|------|
| [CONFIRMED] | >=3 个独立来源交叉验证一致 |
| [MAJORITY] | 多个来源中多数一致，但有个别差异 |
| [DISPUTED] | 不同来源存在实质性矛盾 |
| [SINGLE-SOURCE] | 仅有 1 个来源支撑，需谨慎引用 |
| [INSUFFICIENT DATA] | 数据不足以支撑结论 |

### C2. 引用格式

一律使用 `[cite:N]` 格式，N 从1开始递增。文件输出时用 HTML anchor：
- 行内：`<sup><a href="#cite-N">[N]</a></sup>`
- 末尾：[cite:N] 来源标题 URL

### C3. 结论结构

每个分析段落的结构：**数据现象 -> 归因分析 -> 业务含义**

---

## D. 子技能调用规范

### 调用前检查
1. 确认子技能存在（读取 SKILL.md）
2. 确认子技能可执行（检查依赖）
3. 不存在则报错并提供替代方案

### 错误处理
```
子技能不存在 -> 告知用户，建议安装或使用替代方案
子技能执行失败 -> 提供错误信息，建议手动操作
网络/依赖问题 -> 提供离线替代方案（如有）
```

### 链式任务规则
- 按顺序执行，前一步失败则停止
- 不掩盖错误，如实反馈给用户

---

## E. 使用示例

### 快查通道
```
用户："搜一下2025年AI游戏美术市场规模"
-> 打分：产出0 + 复杂度0 + 信源1 = 1分 -> 快查
-> anysearch 搜索 -> research-guide 验证 -> 精简回答
```

### 半正式通道
```
用户："对比一下Midjourney和Stable Diffusion的收费模式"
-> 打分：产出1 + 复杂度2 + 信源1 = 4分 -> 深研通道
-> Grill-me展示 -> 用户说"不用出报告，简要分析就行"
-> 调整为半正式通道执行
```

### 深研通道
```
用户："帮我做一份游戏美术外包市场的调研报告"
-> 打分：产出2 + 复杂度2 + 信源2 = 6分 -> 深研通道
-> Grill-me展示 -> 用户确认
-> research-guide + consulting-analysis Phase 1 -> 框架确认
-> anysearch 逐章搜索 -> Data Summary -> Phase 2 出报告
```

### 快查自动升级
```
用户："查一下今年短剧市场规模"
-> 快查执行 -> anysearch 只返回1个来源 ->
-> 触发升级条件（信源不足） -> 自动走半正式通道
```

---

## 注意事项

1. 非调研技能（video-download / book-ingest / knowledge-*）不走编排逻辑，保持简单路由
2. 深研通道 Phase 1 框架输出后必须等待用户确认再执行数据收集
3. 快查升级到半正式时不需用户确认，升级到深研需用户确认
4. 评分不是死规则，grill-me 联动阶段用户可以推翻 AI 的通道建议
5. 好过造：数据缺失时标注 [INSUFFICIENT DATA]，不虚构
