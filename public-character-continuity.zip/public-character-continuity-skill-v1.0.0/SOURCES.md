# Public research sources

This package was independently written after reviewing public image-prompting and character-consistency materials. It does not copy a private or proprietary workflow.

## Primary public references

1. Replicate Skills — `prompt-images` (Apache-2.0)
   https://github.com/replicate/skills/blob/main/skills/prompt-images/SKILL.md

   Public concepts consulted: reference images for character consistency; state what changes and what remains unchanged; split complex edits; iterate from simple edits.

2. OpenAI Codex — image generation sample prompts (Apache-2.0)
   https://github.com/openai/codex/blob/main/codex-rs/skills/src/assets/samples/imagegen/references/sample-prompts.md

   Public concepts consulted: identity-preserving image edits; preserve existing subject while changing scene/action; describe explicit constraints.

3. fofr/cog-consistent-character — public consistent-character workflow
   https://github.com/fofr/cog-consistent-character

   Consulted only as evidence that single-character reference-conditioned pose variation is a public workflow pattern. No code or workflow files are included here.

## Additional research note

GenielabsOpenSource/style-consistency-ai was reviewed as a public example of a dedicated character-consistency Agent Skill. Its repository uses PolyForm Noncommercial 1.0.0, so this package does not fork, reproduce, or redistribute its Skill text or reference files.
