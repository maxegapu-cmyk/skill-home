# Quick recipes

These are short operational patterns. Replace bracketed text with the user's request.

## New location

Keep the same established character from the reference image. Move them to [location]. They are [action]. Preserve the established character appearance and do not redesign them. Adapt lighting and shadows naturally to the new environment.

## New outfit

Keep the same established character. Replace only the clothing with [outfit]. Preserve the character's recognizable appearance, hair, and overall proportions. Keep the current pose and scene unless the user asks to change them.

## New expression

Keep the same established character. Change only the facial expression to [expression]. Keep the current clothing, scene, and camera view unless otherwise requested.

## New pose

Keep the same established character from the reference. Change the pose to [pose/action]. Preserve the character design and current outfit. Keep anatomy natural and suitable for the action.

## Camera change

Keep the same established character. Show them from [camera view / shot size]. Preserve the character's recognizable appearance and current design. Do not introduce a new face or alternate character design.

## Combined scene + action

Keep the same established character from the reference. Place them in [scene], [action]. Preserve the established character design. Change only what is necessary for the new scene and action.

## Retry after drift

Use the earlier accepted reference again. Keep the same character and make only this change: [change]. Do not inherit appearance changes from the failed version.
