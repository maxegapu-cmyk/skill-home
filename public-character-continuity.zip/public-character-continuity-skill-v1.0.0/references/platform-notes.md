# Platform notes

This skill is model-agnostic. Adapt the workflow to the controls actually offered by the image system.

## Reference-capable image models

Prefer the platform's native image reference or image editing input over prompt-only repetition when identity matters.

## Dedicated character / identity controls

If the platform provides a character-reference, identity, face-reference, or subject-reference control, use it according to that platform's current documentation. Do not invent parameter names or numerical settings.

## Seed controls

A fixed seed can make nearby generations more repeatable on some systems, but it should not be treated as a universal identity lock. Use a visual reference when available.

## Multiple-image input

More images are not automatically better. Use multiple references only when the model supports them and the images provide compatible information about the same character.

## Image editing vs. new generation

When the user already has an accepted character image and wants a limited change, prefer editing that image over starting a fresh text-to-image generation if the platform supports editing.
