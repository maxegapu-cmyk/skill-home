# Troubleshooting

## The face changes after a scene edit

Use the accepted reference again and reduce the request to the scene change only. Remove extra beauty, casting, or appearance language that may encourage a redesign.

## Outfit change creates a different person

Ask for an outfit replacement rather than describing a new person wearing the outfit. Keep the reference attached and leave unrelated appearance details alone.

## A side view looks unrelated

Use a reference that is closer to the desired view if one exists. If not, try a smaller viewpoint change before asking for a very different angle.

## The character drifts over several images

Do not continue from the latest image automatically. Return to the strongest accepted reference and generate the next shot from there.

## Too many references make the result unstable

Remove references that do not help answer the current request. A smaller set of relevant images is often easier for a model to follow than a mixed collection.

## The model keeps beautifying or restyling the character

Remove unnecessary appearance adjectives and style changes. Phrase the task as an edit of an existing person rather than creation of a new idealized character.

## Prompt-only consistency is weak

If the platform supports image references, character references, identity preservation, or image editing, use those features. Repeating a text description is not equivalent to conditioning on an accepted image.

## A large edit keeps failing

Split it. For example:

1. outfit change;
2. scene change;
3. action or camera change.

Keep the accepted result from each successful stage only when the character still looks correct.
