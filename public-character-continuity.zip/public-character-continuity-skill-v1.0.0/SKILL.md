---
name: public-character-continuity
description: Keep an established character recognizable across AI image generations and edits using reference images, concise change requests, and simple recovery steps. Use when a user wants the same character in a new scene, outfit, pose, expression, or camera view, or when a character begins to drift between images.
---

# Public Character Continuity

Use this skill for practical recurring-character image work. Keep the workflow lightweight and reference-led.

## Goal

Preserve the established character while changing only what the user asked to change.

Do not rebuild a character from text when a usable reference image already exists.

## Default workflow

1. **Find the best current reference.**
   - Prefer a clear image where the character is easy to recognize.
   - If several references exist, use the one closest to the requested camera view, pose, or outfit.

2. **Separate the request into two parts.**
   - Preserve: the established character and any elements the user did not ask to change.
   - Change: only the requested scene, action, expression, clothing, camera, lighting, or other edit.

3. **Write a concise edit instruction.**
   - Name the existing character as the subject.
   - State the requested change directly.
   - Add a short preservation clause.
   - Avoid re-describing the whole character unless no reference image is available.

4. **Keep difficult edits incremental.**
   - If a large combined edit drifts, split it into two or more edits.
   - Example: change the outfit first, then change the location.

5. **Recover from drift by returning to a good reference.**
   - Do not keep extending a visibly drifted result.
   - Reuse the last good character image, shorten the instruction, and retry the requested change.

## Prompt pattern

Use this form when a reference image is available:

> Keep the same established character from the reference image. Change only: [requested change]. Preserve the character's recognizable appearance and any unmentioned elements. Keep the result natural for the new scene.

For a scene change:

> Keep the same character from the reference. Place them in [new scene] doing [action]. Preserve their established appearance; do not redesign the character.

For an outfit edit:

> Keep the same character and replace only the current outfit with [new outfit]. Preserve the person's established appearance, hair, and overall proportions.

For an expression edit:

> Keep the same character and change only the expression to [expression]. Preserve the person's established appearance and current scene unless otherwise requested.

## When there is no reference image

Create one clean baseline image first. Keep the description focused on a few stable, visible characteristics and the intended visual style. Once the user accepts that image, treat it as the main reference for later edits instead of repeatedly regenerating from the original text description.

## Multiple references

When multiple usable references are available:

- prefer relevance over quantity;
- choose the image closest to the requested viewpoint or situation;
- do not attach unrelated references merely because they exist;
- if the tool supports several references well, use only those that clarify the same character rather than introducing competing designs.

## Sequence work

For a short sequence, keep the same accepted reference available across shots. Change the shot request, not the character definition.

If one shot drifts, restart that shot from a reliable earlier reference instead of treating the drifted frame as the new source.

## Troubleshooting order

When the user says the character no longer looks right, try these in order:

1. return to the clearest accepted reference;
2. remove unnecessary appearance or style wording;
3. make the requested change smaller;
4. use a reference closer to the requested view if one exists;
5. split a combined edit into separate passes;
6. if the platform offers a dedicated reference/identity feature, use it instead of prompt-only repetition.

Read `references/troubleshooting.md` for common failure cases. Read `references/quick-recipes.md` for ready-to-use prompt patterns.

## Output behavior

When helping a user:

- give the usable prompt first;
- keep explanations short unless they ask for theory;
- use the user's existing accepted image as the starting point whenever possible;
- do not claim perfect identity preservation: results depend on the image model and the quality of the reference.
