# Public Character Continuity Skill v1.0.0

A small Agent Skills-compatible package for recurring-character image generation and editing.

## What it does

- keeps an accepted character as the reference point;
- phrases edits as targeted changes rather than character re-creation;
- uses relevant references instead of large mixed reference sets;
- handles common drift with simple retry and rollback steps;
- works as a model-agnostic instruction layer.

## Install

Copy this folder into the skills directory used by your agent, or load `SKILL.md` as an Agent Skill instruction file.

## Files

- `SKILL.md` — main behavior
- `references/quick-recipes.md` — reusable prompt patterns
- `references/troubleshooting.md` — common failure recovery
- `references/platform-notes.md` — generic platform guidance
- `SOURCES.md` — public sources used for research

## Scope

This package is intentionally practical and lightweight. It does not require training, custom nodes, or a specific image provider.
