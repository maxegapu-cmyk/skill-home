from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
required = [
    root / "SKILL.md",
    root / "README.md",
    root / "SOURCES.md",
    root / "references" / "quick-recipes.md",
    root / "references" / "troubleshooting.md",
    root / "references" / "platform-notes.md",
]

missing = [str(p.relative_to(root)) for p in required if not p.exists()]
assert not missing, f"Missing files: {missing}"

text = (root / "SKILL.md").read_text(encoding="utf-8")
assert text.startswith("---\n"), "SKILL.md missing YAML frontmatter"
assert "name: public-character-continuity" in text
assert "description:" in text

# Distribution hygiene: no machine-local paths, secrets, or obvious placeholders.
all_text = "\n".join(p.read_text(encoding="utf-8") for p in root.rglob("*.md"))
for pattern in [r"/mnt/data", r"[A-Za-z]:\\", r"sk-[A-Za-z0-9_-]{20,}", r"TODO", r"FIXME"]:
    assert not re.search(pattern, all_text), f"Distribution hygiene failure: {pattern}"

print("PASS: package structure and distribution-hygiene checks")
