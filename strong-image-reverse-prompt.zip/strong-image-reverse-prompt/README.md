# Strong Image Reverse Prompt 1.1.0

A compact Skill for deriving controllable image-generation and editing prompts from reference images.

## Included capabilities

- Role assignment for multi-image inputs.
- Preserve, change, and exclude controls.
- Uncertainty handling for unreadable or obscured details.
- Prompt guidance for GPT Image, Midjourney, Flux, and SDXL.
- Product, layout, crop, and composition preservation.

## Install/use

Copy the `strong-image-reverse-prompt` folder into the target client's Skill directory, then start a new conversation so the client can discover it.

## Validation state

`STATIC_VERIFIED`: the package is structurally small, self-contained, and reviewed for its declared workflow. It has not yet received an independent fresh-conversation certification.
