---
name: strong-image-reverse-prompt
description: Turn one or more reference images into clear, high-control generation or editing prompts. Use this skill whenever the user wants to reverse a picture into a prompt, recreate a reference composition, preserve a product or identity while changing its setting, compare visual references, or prepare image prompts for GPT Image, Midjourney, Flux, SDXL, or similar tools.
metadata:
  title: Strong Image Reverse Prompt
  version: 1.1.0
  certification_status: STATIC_VERIFIED
---

# Strong Image Reverse Prompt

Convert visible image evidence into a controllable generation or editing prompt. The output is an estimate, never a claim that the source prompt has been recovered.

## Trigger and inputs

Use this workflow only when the requested result is a reusable generation, recreation, editing, layout, or style prompt. Do not use it for ordinary captions, OCR, or aesthetic criticism.

For each image, identify whether it is a **subject source**, **style source**, **layout source**, or **comparison reference**. When that role is unclear and it changes the outcome, ask one short question. Otherwise select the conservative interpretation and disclose it.

## Evidence pass

Inspect in this order:

1. **Anchor** — primary subject, action, and the feature that makes the image recognizable.
2. **Spatial grammar** — framing, camera height and distance, focal hierarchy, depth layers, negative space, and crop.
3. **Surface language** — medium, materials, texture, lighting direction, palette relationships, contrast, and atmosphere.
4. **Control locks** — elements that must survive a recreation or edit: identity, silhouette, product geometry, copy, logo placement, perspective, or layout grid.
5. **Uncertainty** — unreadable text, obscured details, ambiguous materials, or inferred camera choices. Never invent exact small text or claims.

Prioritize the main subject, composition, crop, and large color-light relationships before minor decoration. Separate observations from instructions. A visible trait becomes an instruction only when it supports the user's stated target.

## Choose the production path

Select one path:

- `rebuild`: create a new image inspired by the visual mechanics of the reference.
- `edit`: retain a supplied source image while changing named elements.
- `style-transfer`: carry lighting, material, palette, and rendering logic to a different subject.
- `layout-transfer`: carry the information hierarchy, framing, and empty-space strategy without copying the original subject.
- `product-lock`: preserve a specific product's silhouette, material, proportions, and readable branding while rebuilding its environment.
- `reference-merge`: assign one reference to each role and resolve conflicts by the user's priority.

Never treat a style reference as an instruction to reproduce an identifiable person, brand, or copyrighted character unless the user explicitly supplies that target and asks for it.

## Build the control map

Create a compact private map with these groups before writing the answer:

| Group | Capture |
| --- | --- |
| Subject | identity-neutral description, pose, interaction, scale |
| Scene | place, time, foreground/midground/background, props |
| Camera | shot size, lens character, angle, depth of field, crop |
| Composition | hierarchy, leading lines, balance, negative space, text zones |
| Image language | medium, material response, color relationships, light quality |
| Constraints | preserve, change, exclude, uncertainty |

For multiple references, state which image provides each group. If two references conflict, prioritize in this order unless the user says otherwise: explicit user instruction, required identity/product preservation, layout, subject action, visual styling.

## Deliverables

Use the lightest format that fulfills the request.

### Fast brief

Use for casual requests. Return:

```markdown
## Visual fingerprint
<five to eight concrete characteristics>

## Ready-to-use prompt
<a dense natural-language prompt in the user's language>

## Control notes
- Preserve: <only what matters>
- Change: <only if requested>
- Watch: <uncertainty or likely failure mode>
```

Keep the prompt specific and visual. State important relative positions, crop, and scale when they materially affect similarity. Avoid empty quality claims such as “masterpiece”, “best quality”, or “8K” unless the user asks for that aesthetic.

### Production brief

Use when the user asks for JSON, a specific model, image editing, bilingual output, product fidelity, a poster/layout, or multiple references. Return these sections:

1. `intent` — selected production path and intended usage.
2. `reference_roles` — what each supplied image contributes.
3. `creative_brief` — subject, scene, camera, composition, visual language.
4. `prompt` — tool-ready prose, adapted to the stated model.
5. `control_contract` — preserve/change/exclude lists.
6. `uncertainty_register` — only claims that could not be visually confirmed.
7. `structured_data` — valid JSON with the same controls for reuse.

The JSON must use this schema:

```json
{
  "path": "rebuild | edit | style-transfer | layout-transfer | product-lock | reference-merge",
  "output_goal": "",
  "reference_roles": [],
  "subject": {"description": "", "action": "", "scale": ""},
  "scene": {"setting": "", "foreground": "", "background": ""},
  "camera": {"shot": "", "angle": "", "lens_character": "", "focus": ""},
  "composition": {"hierarchy": "", "negative_space": "", "text_zone": ""},
  "visual_language": {"medium": "", "lighting": "", "palette": [], "materials": []},
  "preserve": [],
  "change": [],
  "exclude": [],
  "uncertainties": []
}
```

## Model adaptation

- For GPT Image-style models, use direct complete sentences and explicit layout or edit constraints.
- For Midjourney, foreground the subject, composition, medium, and lighting; keep parameters separate from the descriptive brief.
- For Flux or SDXL, turn the control contract into concise positive constraints and a short exclusion list; avoid contradictory tag piles.
- For an edit, begin with the retention requirements, then the precise change, and end with compositional continuity constraints.

## Failure prevention

Before delivery, verify:

- The prompt describes how to create the image, rather than merely naming what it contains.
- The main subject, composition, crop, and aspect ratio are not buried under minor details.
- Product or identity locks are explicit when the task needs fidelity.
- Any readable text is copied only when clearly visible; otherwise label it as unreadable.
- The aspect ratio is observed or stated as an estimate.
- The prompt does not silently merge conflicting reference roles.
- The user-requested language and requested output depth are respected.

## First-run handshake

1. Confirm that an image or unambiguous visual reference is present.
2. Name the selected production path in the first material output.
3. Ground the brief in at least one visually specific current-input observation before producing a final prompt.
