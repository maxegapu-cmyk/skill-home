import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("site_probe", ROOT / "scripts" / "site_probe.py")
sp = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(sp)


class SiteProbeTests(unittest.TestCase):
    def test_detects_public_frontend_signals(self):
        html = '<html><head><script src="/_next/static/chunks/app.js"></script></head><body><div data-radix-dialog-content></div></body></html>'
        found = sp.detect(html, {})
        self.assertIn("Next.js", found)
        self.assertIn("shadcn/ui 风格", found)

    def test_page_parser_collects_structure(self):
        html = '''<html lang="en"><head><title>Demo</title><meta name="description" content="desc"></head>
        <body><nav><a href="/pricing">Pricing</a></nav><h1>Hello</h1>
        <form action="/signup"><input name="email"><button>Go</button></form></body></html>'''
        p = sp.PageParser()
        p.feed(html)
        self.assertEqual(p.title.strip(), "Demo")
        self.assertEqual(p.lang, "en")
        self.assertTrue(any("Pricing" not in str(x) for x in p.nav_links) or p.nav_links)
        self.assertEqual(p.forms[0]["action"], "/signup")
        self.assertIn("input:email", p.forms[0]["fields"])


if __name__ == "__main__":
    unittest.main()
