import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("prompt_reverse", ROOT / "scripts" / "prompt_reverse.py")
pr = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(pr)


class PromptReverseTests(unittest.TestCase):
    def test_reference_family_passes(self):
        samples = [
            "一只橘猫坐在窗台上, 窗外下着小雨, 吉卜力风格, 柔和的晨光, 暖色调, 中景, 细节丰富, 8k --ar 3:4 --v 6",
            "一个穿红裙的小女孩在麦田里奔跑, 夕阳下的麦田, 吉卜力风格, 柔和的晨光, 暖色调, 中景, 细节丰富, 8k --ar 3:4 --v 6",
            "一只白色小狗趴在书桌上, 堆满书的房间, 吉卜力风格, 柔和的晨光, 暖色调, 中景, 细节丰富, 8k --ar 3:4 --v 6",
        ]
        r = pr.extract_template(samples, 1.0)
        self.assertEqual(r["verdict"], "PASS")
        self.assertIn("{{主体}}", r["template"])
        self.assertIn("{{场景}}", r["template"])
        self.assertEqual(r["metrics"]["average_lexical_f1"], 1.0)
        self.assertEqual(r["metrics"]["average_order_score"], 1.0)

    def test_reordered_constants_are_not_false_pass(self):
        samples = [
            "a woman, rainy street, cinematic, 35mm lens, soft backlight, teal and orange",
            "a man, desert road, teal and orange, cinematic, soft backlight, 35mm lens",
            "a child, snowy forest, soft backlight, 35mm lens, teal and orange, cinematic",
        ]
        r = pr.extract_template(samples, 1.0)
        self.assertEqual(r["metrics"]["average_lexical_f1"], 1.0)
        self.assertLess(r["metrics"]["constant_order_stability"], 0.85)
        self.assertNotEqual(r["verdict"], "PASS")
        self.assertTrue(any("顺序不稳定" in w for w in r["warnings"]))

    def test_multiline_negative_prompt_is_one_sample(self):
        raw = """Prompt: portrait of a woman, rainy street, cinematic lighting
Negative prompt: blurry, bad hands,
deformed fingers, watermark
"""
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "one.txt"
            p.write_text(raw, encoding="utf-8")
            samples = pr.read_samples([str(p)], None, "auto")
        self.assertEqual(len(samples), 1)
        a = pr.anatomy(samples[0])
        self.assertIn("deformed fingers", a["negative"])
        self.assertNotIn("deformed fingers", " ".join(sum(a["components"].values(), [])))

    def test_multiset_metric_does_not_drop_duplicates(self):
        precision, recall, f1 = pr.multiset_overlap(["cinematic"], ["cinematic", "cinematic"])
        self.assertEqual(precision, 1.0)
        self.assertEqual(recall, 0.5)
        self.assertLess(f1, 1.0)

    def test_explicit_block_separator(self):
        raw = "Prompt: cat\nNegative prompt: blur\n---\nPrompt: dog\nNegative prompt: noise"
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "two.txt"
            p.write_text(raw, encoding="utf-8")
            samples = pr.read_samples([str(p)], None, "auto")
        self.assertEqual(len(samples), 2)
        self.assertIn("Negative prompt", samples[0])


if __name__ == "__main__":
    unittest.main()
