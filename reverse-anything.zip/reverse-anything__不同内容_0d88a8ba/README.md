# reverse-anything 2.0 · 证据驱动万能逆向

把公开或用户提供的成品，变成可复用、可迁移、可验证的结构，而不是只写一份“看起来很懂”的分析。

2.0 重点修复了 1.x 最危险的问题：**文本能重新拼回去 ≠ 真正逆向成功。**

现在支持三条路线：

- 提示词 / 图片 / 视频：提炼母版、变量槽、风格锚点，并做迁移/消融验证。
- 网站 / 产品：拆公开功能、流程、技术信号，给自己的实现方案和 vibecoding 提示词包。
- 其他公开或用户提供的成品：走统一的“观察 → 假设 → 最小模型 → 留出/迁移/反事实验证”协议。

## 安装

```bash
# Hermes
mkdir -p ~/.hermes/skills/creative
unzip reverse-anything.zip -d ~/.hermes/skills/creative/

# Claude Code
mkdir -p ~/.claude/skills
unzip reverse-anything.zip -d ~/.claude/skills/
```

只依赖 Python 3.9+ 标准库。

## 提示词逆向

普通单行样本：

```bash
python3 scripts/prompt_reverse.py prompts.txt
```

多行 Prompt 推荐：

```text
Prompt: ...
Negative prompt: ...
---
Prompt: ...
Negative prompt: ...
```

脚本不会再把 `Negative prompt:` 的续行误当成第二个样本。

输出不再只有一个“覆盖率”，而是分别报告：

- 文本成分 F1
- 句序一致度
- 常量出现稳定度
- 常量顺序稳定度
- 槽位变化证据率
- PASS / PARTIAL / FAIL

例如三条真正同母版的样本可得到：

```text
{{主体}}，{{场景}}，吉卜力风格，柔和的晨光，暖色调，中景，细节丰富，8k --ar 3:4 --v 6
```

如果把固定风格词在不同样本里故意打乱顺序，即使所有词都能找到，脚本也会因为句序/常量顺序不稳定而降级为 `PARTIAL`，不再报一个误导性的“100% 成功”。

## 网站公开侦察

```bash
python3 scripts/site_probe.py https://example.com --pages 3
```

脚本只做公开侧证据采集；真实交互、动效、登录后自己有权访问的功能，需要用浏览器补看。

## 通用逆向

见 `references/universal-reverse.md`。核心原则：先定义要复现的性质，至少保留一个竞争解释，有条件时做 holdout / 新输入迁移 / 单变量反事实测试。

## 自测

```bash
python3 -m unittest discover -s tests -v
```

## 边界

只分析公开可见内容、用户提供材料或用户有权分析的系统。不绕过登录、付费墙、验证码或访问控制；不提取凭据/秘密；复刻产品价值和公开体验，不复制品牌、Logo、文案和受保护素材。
