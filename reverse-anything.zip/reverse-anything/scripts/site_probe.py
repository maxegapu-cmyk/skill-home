#!/usr/bin/env python3
"""网站公开信息侦察：从对标网站的公开页面推断技术栈、第三方服务、页面结构和功能线索。

只读取任何访客都能看到的公开内容（首页 HTML、响应头、robots.txt、sitemap），
遵守 robots.txt，不登录、不绕过任何限制。结论按证据强弱分级。

用法：
  site_probe.py https://example.com
  site_probe.py https://example.com --pages 5      # 额外抽样 5 个站内页面（间隔 1 秒）
  site_probe.py https://example.com --json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.request
import urllib.robotparser
from collections import Counter, OrderedDict
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

UA = "Mozilla/5.0 (compatible; reverse-anything-probe/1.0; public-page analysis)"

# (名称, 类别, 证据位置, 正则)；位置：html / header / script / cookie
SIGNATURES = [
    ("Next.js", "前端框架", "html", r"__NEXT_DATA__|/_next/static|next-route-announcer"),
    ("Nuxt", "前端框架", "html", r"__NUXT__|/_nuxt/"),
    ("React", "前端框架", "html", r"data-reactroot|react-dom|__reactFiber|_reactListening"),
    ("Vue", "前端框架", "html", r"data-v-[0-9a-f]{6,}|__vue__|vue(?:\.runtime)?(?:\.min)?\.js"),
    ("Svelte/SvelteKit", "前端框架", "html", r"svelte-[a-z0-9]{5,}|__sveltekit|/_app/immutable/"),
    ("Astro", "前端框架", "html", r"astro-island|/_astro/|data-astro-cid"),
    ("Remix", "前端框架", "html", r"__remixContext|__remixManifest"),
    ("Angular", "前端框架", "html", r"ng-version=|_nghost-|ng-app"),
    ("Gatsby", "前端框架", "html", r"___gatsby|/page-data/"),
    ("Vite", "构建工具", "html", r"/@vite/|/assets/index-[A-Za-z0-9_-]{6,}\.js"),
    ("Tailwind CSS", "样式", "html", r'class="[^"]*\b(?:flex|grid)\b[^"]*\b(?:px|py|mx|my|gap|text|bg)-[a-z0-9\[]'),
    ("shadcn/ui 风格", "样式", "html", r"data-radix-|radix-ui"),
    ("WordPress", "建站平台", "html", r"/wp-content/|/wp-includes/|wp-json"),
    ("Shopify", "建站平台", "html", r"cdn\.shopify\.com|Shopify\.theme"),
    ("Webflow", "建站平台", "html", r"webflow\.js|data-wf-page|assets\.website-files\.com"),
    ("Framer", "建站平台", "html", r"framerusercontent\.com|data-framer-"),
    ("Wix", "建站平台", "html", r"static\.wixstatic\.com|wix-code"),
    ("Squarespace", "建站平台", "html", r"squarespace\.com|static1\.squarespace"),
    ("Ghost", "建站平台", "html", r"ghost-(?:portal|sdk)|content=\"Ghost"),
    ("Vercel", "托管", "header", r"x-vercel-id|server:\s*vercel"),
    ("Netlify", "托管", "header", r"x-nf-request-id|server:\s*netlify"),
    ("Cloudflare", "CDN/托管", "header", r"cf-ray|server:\s*cloudflare"),
    ("AWS CloudFront", "CDN", "header", r"x-amz-cf-id|via:.*cloudfront"),
    ("Fly.io", "托管", "header", r"fly-request-id|server:\s*fly"),
    ("Render", "托管", "header", r"x-render-origin-server|rndr-id"),
    ("Google Analytics", "分析", "html", r"googletagmanager\.com/gtag|google-analytics\.com|gtag\("),
    ("Google Tag Manager", "分析", "html", r"googletagmanager\.com/gtm\.js"),
    ("Plausible", "分析", "html", r"plausible\.io/js"),
    ("PostHog", "分析", "html", r"posthog"),
    ("Mixpanel", "分析", "html", r"mixpanel"),
    ("Segment", "分析", "html", r"cdn\.segment\.com"),
    ("Hotjar", "分析", "html", r"hotjar"),
    ("百度统计", "分析", "html", r"hm\.baidu\.com"),
    ("Microsoft Clarity", "分析", "html", r"clarity\.ms"),
    ("Stripe", "支付", "html", r"js\.stripe\.com|stripe"),
    ("Paddle", "支付", "html", r"paddle\.(?:com|js)"),
    ("Lemon Squeezy", "支付", "html", r"lemonsqueezy"),
    ("Clerk", "认证", "html", r"clerk\.(?:com|accounts)|__clerk"),
    ("Auth0", "认证", "html", r"auth0"),
    ("Supabase", "后端服务", "html", r"supabase\.co"),
    ("Firebase", "后端服务", "html", r"firebaseapp\.com|firebase(?:-app)?\.js|firebaseio"),
    ("Intercom", "客服", "html", r"widget\.intercom\.io|intercomSettings"),
    ("Crisp", "客服", "html", r"client\.crisp\.chat"),
    ("Sentry", "监控", "html", r"sentry(?:-cdn)?\.(?:io|com)|Sentry\.init"),
    ("Algolia", "搜索", "html", r"algolia"),
    ("Mapbox", "地图", "html", r"mapbox"),
    ("Google Fonts", "字体", "html", r"fonts\.googleapis\.com"),
    ("Lottie", "动效", "html", r"lottie"),
    ("GSAP", "动效", "html", r"gsap|greensock"),
    ("Framer Motion", "动效", "html", r"framer-motion"),
    ("Three.js", "3D", "html", r"three(?:\.module)?(?:\.min)?\.js|THREE\."),
    ("Swiper", "组件", "html", r"swiper"),
]
FEATURE_HINTS = OrderedDict([
    ("账号体系", r"\b(?:log ?in|sign ?in|sign ?up|register|account)\b|登录|注册|账号"),
    ("定价/订阅", r"\bpricing\b|\bplans?\b|\bsubscribe\b|/month|per month|价格|定价|套餐|订阅|会员"),
    ("搜索", r'type="search"|\bsearch\b|搜索'),
    ("邮件订阅", r'newsletter|subscribe|type="email"|邮件订阅|订阅'),
    ("博客/内容", r"\bblog\b|/posts?/|\barticles?\b|博客|文章"),
    ("文档/帮助中心", r"\bdocs\b|documentation|help center|/help|文档|帮助中心"),
    ("多语言", r'hreflang=|lang-switch|language|语言切换'),
    ("深色模式", r"dark[- ]?mode|prefers-color-scheme|data-theme"),
    ("API/开发者", r"\bapi\b|developers?|sdk|开发者"),
    ("下载/客户端", r"download|app store|google play|下载"),
    ("社区", r"discord|community|forum|社区|论坛"),
    ("AI 功能", r"\bai\b|gpt|llm|generate|生成"),
])


class PageParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.title, self._in_title = "", False
        self.meta, self.links, self.scripts, self.styles = {}, [], [], []
        self.forms, self._form, self.headings, self._h = [], None, [], None
        self.nav_links, self._in_nav = [], 0
        self.lang = ""

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html":
            self.lang = a.get("lang", "")
        elif tag == "title":
            self._in_title = True
        elif tag == "meta":
            k = a.get("name") or a.get("property")
            if k and a.get("content"):
                self.meta[k.lower()] = a["content"]
        elif tag == "a" and a.get("href"):
            self.links.append(a["href"])
            if self._in_nav:
                self.nav_links.append(a["href"])
        elif tag == "script" and a.get("src"):
            self.scripts.append(a["src"])
        elif tag == "link" and a.get("rel") and "stylesheet" in a.get("rel", ""):
            self.styles.append(a.get("href", ""))
        elif tag in ("nav", "header"):
            self._in_nav += 1
        elif tag == "form":
            self._form = {"action": a.get("action", ""), "fields": []}
        elif tag in ("input", "select", "textarea") and self._form is not None:
            self._form["fields"].append(a.get("type", tag) + (":" + a["name"] if a.get("name") else ""))
        elif tag in ("h1", "h2"):
            self._h = [tag, ""]

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag in ("nav", "header") and self._in_nav:
            self._in_nav -= 1
        elif tag == "form" and self._form is not None:
            self.forms.append(self._form)
            self._form = None
        elif tag in ("h1", "h2") and self._h:
            if self._h[1].strip():
                self.headings.append(f"{self._h[0]}: {self._h[1].strip()[:80]}")
            self._h = None

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if self._h is not None:
            self._h[1] += data


def fetch(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read(3_000_000).decode(r.headers.get_content_charset() or "utf-8", "replace")
        return r.status, dict(r.headers.items()), body, r.geturl()


def allowed(robots, url):
    try:
        return robots.can_fetch(UA, url)
    except Exception:
        return True


def detect(html, headers):
    hdr = "\n".join(f"{k}: {v}" for k, v in headers.items()).lower()
    cookies = headers.get("Set-Cookie", "") + headers.get("set-cookie", "")
    found = OrderedDict()
    for name, cat, where, pat in SIGNATURES:
        src = hdr if where == "header" else html
        m = re.search(pat, src, flags=re.I)
        if m:
            found[name] = {"category": cat, "evidence": m.group(0)[:80], "where": where}
    gen = re.search(r'<meta[^>]+name="generator"[^>]+content="([^"]+)"', html, re.I)
    if gen:
        found[f"generator: {gen.group(1)}"] = {"category": "建站平台", "evidence": gen.group(0)[:80], "where": "html"}
    powered = headers.get("X-Powered-By") or headers.get("x-powered-by")
    if powered:
        found[f"X-Powered-By: {powered}"] = {"category": "后端", "evidence": powered, "where": "header"}
    if re.search(r"PHPSESSID", cookies):
        found["PHP 会话"] = {"category": "后端", "evidence": "PHPSESSID", "where": "cookie"}
    if re.search(r"csrftoken|sessionid", cookies) and "django" in cookies.lower() + html.lower():
        found["Django"] = {"category": "后端", "evidence": "csrftoken", "where": "cookie"}
    return found


def sitemap_urls(base, robots_txt, limit=2000):
    cands = re.findall(r"(?im)^\s*sitemap:\s*(\S+)", robots_txt or "") or [urljoin(base, "/sitemap.xml")]
    urls = []
    for sm in cands[:3]:
        try:
            _, _, body, _ = fetch(sm)
        except Exception:
            continue
        locs = re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body)
        if locs and all(l.endswith(".xml") for l in locs[:5]):
            for sub in locs[:5]:
                try:
                    _, _, b2, _ = fetch(sub)
                    urls += re.findall(r"<loc>\s*([^<]+?)\s*</loc>", b2)
                except Exception:
                    pass
        else:
            urls += locs
        if len(urls) >= limit:
            break
    return urls[:limit]


def page_types(urls):
    c = Counter()
    for u in urls:
        parts = [p for p in urlparse(u).path.split("/") if p]
        c["/" + parts[0] + "/" if len(parts) > 1 else ("/" + parts[0] if parts else "/")] += 1
    return c.most_common(15)


def probe(url, pages=0):
    if not re.match(r"https?://", url):
        url = "https://" + url
    origin = "{0.scheme}://{0.netloc}".format(urlparse(url))
    robots = urllib.robotparser.RobotFileParser()
    robots_txt = ""
    try:
        _, _, robots_txt, _ = fetch(origin + "/robots.txt")
        robots.parse(robots_txt.splitlines())
    except Exception:
        robots.parse([])
    if not allowed(robots, url):
        return {"url": url, "error": "robots.txt 不允许抓取该页面；请改用浏览器人工查看或截图分析"}
    status, headers, html, final = fetch(url)
    p = PageParser()
    p.feed(html)
    stack = detect(html, headers)
    text = re.sub(r"<[^>]+>", " ", html)
    features = {k: bool(re.search(v, html + " " + " ".join(p.links), re.I)) for k, v in FEATURE_HINTS.items()}
    internal = []
    for h in p.links:
        full = urljoin(final, h).split("#")[0]
        if urlparse(full).netloc == urlparse(final).netloc and full not in internal and full != final:
            internal.append(full)
    third = sorted({urlparse(urljoin(final, s)).netloc for s in p.scripts} - {urlparse(final).netloc, ""})
    sm = sitemap_urls(origin, robots_txt)
    samples = []
    for u in internal[:pages]:
        if not allowed(robots, u):
            continue
        time.sleep(1)
        try:
            _, h2, b2, _ = fetch(u)
            q = PageParser()
            q.feed(b2)
            samples.append({"url": u, "title": q.title.strip()[:100], "h": q.headings[:5],
                            "forms": q.forms, "new_stack": [k for k in detect(b2, h2) if k not in stack]})
        except Exception as e:
            samples.append({"url": u, "error": str(e)[:100]})
    return {
        "url": url, "final_url": final, "status": status, "title": p.title.strip(), "lang": p.lang,
        "description": p.meta.get("description") or p.meta.get("og:description", ""),
        "og": {k: v for k, v in p.meta.items() if k.startswith("og:") or k.startswith("twitter:")},
        "stack": stack, "third_party_script_hosts": third,
        "headings": p.headings[:20], "nav": [urljoin(final, x) for x in p.nav_links][:40],
        "forms": p.forms, "features": features,
        "internal_link_count": len(internal), "sitemap_count": len(sm), "page_types": page_types(sm or internal),
        "samples": samples, "html_bytes": len(html),
        "spa_shell": len(re.sub(r"\s+", "", text)) < 200 and bool(p.scripts),
    }


def to_md(r):
    if r.get("error"):
        return f"# 站点侦察：{r['url']}\n\n{r['error']}"
    out = [f"# 站点侦察：{r['title'] or r['url']}", "",
           f"- 地址：{r['final_url']}（HTTP {r['status']}，语言 {r['lang'] or '未声明'}）",
           f"- 描述：{r['description'] or '无'}",
           f"- 首屏是否为空壳 SPA：{'是，内容靠 JS 渲染，需用浏览器补看' if r['spa_shell'] else '否，服务端已输出内容'}", "",
           "## 技术栈信号（证据级）", "", "| 名称 | 类别 | 证据 | 位置 |", "| --- | --- | --- | --- |"]
    for k, v in r["stack"].items():
        out.append(f"| {k} | {v['category']} | `{v['evidence'].replace('|', '/')}` | {v['where']} |")
    if not r["stack"]:
        out.append("| （未识别） | | | |")
    out += ["", f"第三方脚本域名：{', '.join(r['third_party_script_hosts']) or '无'}", "",
            "## 功能线索（关键词命中，推断级）", ""]
    out += [f"- {k}：{'有' if v else '未发现'}" for k, v in r["features"].items()]
    out += ["", "## 页面结构", "", f"- 站内链接 {r['internal_link_count']} 个；sitemap 收录 {r['sitemap_count']} 个 URL",
            "- 页面类型分布（按路径首段）：" + "，".join(f"{p} ×{n}" for p, n in r["page_types"])]
    if r["headings"]:
        out += ["", "首页标题层级：", ""] + [f"- {h}" for h in r["headings"]]
    if r["forms"]:
        out += ["", "表单：", ""] + [f"- action={f['action'] or '（当前页）'}：{', '.join(f['fields'])}" for f in r["forms"]]
    if r["samples"]:
        out += ["", "## 抽样页面", ""]
        for s in r["samples"]:
            if s.get("error"):
                out.append(f"- {s['url']}：失败 {s['error']}")
            else:
                out.append(f"- {s['url']}：{s['title']}；{'；'.join(s['h'][:3])}"
                           + (f"；新增技术信号 {', '.join(s['new_stack'])}" if s['new_stack'] else ""))
    out += ["", "以上为证据级和推断级信息。交互细节、登录后功能和动效需用浏览器实际操作补充。"]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="对标网站公开信息侦察")
    ap.add_argument("url")
    ap.add_argument("--pages", type=int, default=0, help="额外抽样的站内页面数（默认 0，最多 10）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    try:
        r = probe(a.url, min(max(a.pages, 0), 10))
    except Exception as e:
        sys.exit(f"抓取失败：{e}。可改用浏览器打开页面后人工分析。")
    print(json.dumps(r, ensure_ascii=False, indent=2) if a.json else to_md(r))


if __name__ == "__main__":
    main()
