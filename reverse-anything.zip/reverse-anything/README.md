# reverse-anything · 万能逆向 skill

把别人做得好的东西，变成自己能批量复用的东西。

- **图片 / 视频**：有提示词和成品（或只有成品），反推背后的母版指令：固定骨架、变量槽、风格锚点、有效参数，并验证能否还原原提示词。
- **对标网站**：给一个网址，拆出定位、功能、用户流程、技术栈，给出 A/B/C 三套实现方案，以及一套可以直接交给 AI 编程工具执行的分步提示词。

## 安装

```bash
# Hermes
mkdir -p ~/.hermes/skills/creative
unzip reverse-anything.zip -d ~/.hermes/skills/creative/

# Claude Code
mkdir -p ~/.claude/skills
unzip reverse-anything.zip -d ~/.claude/skills/
```

只依赖 Python 3.9+ 标准库。

## 用法

直接对 agent 说：

- `/reverse-anything 逆向这几条提示词的母版`（附上提示词和图）
- `/reverse-anything 分析 https://xxx.com，我想做一个同类产品`

也可以单独运行脚本：

```bash
python3 scripts/prompt_reverse.py prompts.txt           # 每行一条，或用 --- 分隔
python3 scripts/prompt_reverse.py prompts.txt --threshold 0.6
python3 scripts/site_probe.py https://example.com --pages 3
```

## 示例

输入三条同系列提示词：

```
一只橘猫坐在窗台上, 窗外下着小雨, 吉卜力风格, 柔和的晨光, 暖色调, 中景, 细节丰富, 8k --ar 3:4 --v 6
一个穿红裙的小女孩在麦田里奔跑, 夕阳下的麦田, 吉卜力风格, 柔和的晨光, 暖色调, 中景, 细节丰富, 8k --ar 3:4 --v 6
一只白色小狗趴在书桌上, 堆满书的房间, 吉卜力风格, 柔和的晨光, 暖色调, 中景, 细节丰富, 8k --ar 3:4 --v 6
```

输出母版：

```
{{主体}}，{{场景}}，吉卜力风格，柔和的晨光，暖色调，中景，细节丰富，8k --ar 3:4 --v 6
```

并列出每个槽位的取值、风格常量和还原覆盖率（本例 100%）。

## 边界

只分析公开可见内容：不绕过登录、付费墙或访问限制，不调用对方内部接口，不批量抓取；复刻功能和体验，品牌、文案、图片用自己的。
