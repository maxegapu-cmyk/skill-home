# 资产卡示例集

以下为职场甜宠短剧《意外的上司》的完整资产卡示例，供参考。

---

## 人物资产卡示例

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 人物资产卡｜林晚晴（女主）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【基础信息】
姓名：林晚晴    性别：女    年龄：25岁    身份：新入职设计师

【外貌描述】
身材体型：纤细，约165cm，气质清爽
面部特征：圆脸，大眼睛，嘴角自然上扬，皮肤白皙，邻家感
发型发色：黑色，微卷，中长发，自然垂落

【服装造型】
主要造型：浅米色衬衫 + 高腰黑色西装裤 + 白色运动鞋
配饰：小圆耳钉，简约手表，米色帆布包
妆容：清透底妆，淡粉唇色，无眼影

【表情状态】
标志性表情：微微咬唇、眼神发亮的认真样
眼神特征：清亮，有神，偶尔无辜

【即梦参考图提示词】
中文版：
25岁中国女性，圆脸，大眼睛，黑色微卷中长发，浅米色衬衫，
黑色高腰西装裤，清透妆容，自然站立，微笑，邻家感，
全身，白色简约背景，电影质感，自然光，写实风格，高清

英文版（备用）：
25-year-old Chinese woman, round face, big eyes, black wavy medium hair,
beige shirt, black high-waist trousers, natural makeup, standing naturally,
soft smile, girl-next-door vibe, full body, white minimal background,
cinematic, natural lighting, photorealistic, high detail
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 人物资产卡｜顾辰（男主）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【基础信息】
姓名：顾辰    性别：男    年龄：32岁    身份：公司总监

【外貌描述】
身材体型：高挑挺拔，约183cm，宽肩窄腰，成熟感
面部特征：轮廓立体，薄唇，眼神锐利，偶尔嘴角微扬
发型发色：黑色，利落短发，侧分

【服装造型】
主要造型：深藏青色修身西装 + 白色衬衫 + 无领带
配饰：简约银色腕表，黑色皮质公文包
妆容：无，自然状态

【表情状态】
标志性表情：面无表情中带一丝审视，或若有所思地低头
眼神特征：深邃，冷静，偶尔一秒温柔

【即梦参考图提示词】
中文版：
32岁中国男性，轮廓立体，黑色侧分短发，深藏青色修身西装，
白色衬衫，成熟气质，冷峻表情，略带审视眼神，
全身，简约办公环境背景，电影质感，自然光，写实风格，高清

英文版（备用）：
32-year-old Chinese man, chiseled features, black side-parted short hair,
dark navy fitted suit, white shirt, mature aura, cool expression,
slightly piercing gaze, full body, minimal office background,
cinematic, natural lighting, photorealistic, high detail
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 道具资产卡示例

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎭 道具资产卡｜设计稿文件夹
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【道具信息】
名称：米白色皮质文件夹
出现场次：场景2（会议室）、场景4（走廊）
作用：女主上班第一天的标志物，意外被男主拿走导致相识

【视觉描述】
形态：A4大小，约2cm厚，有金属扣环
材质/质感：磨砂皮质，哑光，带细微纹理
状态：全新，干净
特殊细节：右下角有女主手写的"林晚晴 Studio"黑色签字笔字迹

【即梦参考图提示词】
中文版：
米白色皮质文件夹，A4大小，磨砂质感，金属扣环，
右下角有黑色手写"林晚晴 Studio"字样，全新状态，
产品摄影，白色背景，高清细节，写实风格，无阴影

英文版（备用）：
off-white leather folder, A4 size, matte texture, metal clasp,
handwritten "Lin Wanjing Studio" in black ink on bottom right,
brand new condition, product photography, white background,
high detail, photorealistic, clean shadows
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 场景资产卡示例

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎬 场景资产卡｜公司玻璃会议室
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【场景信息】
名称：玻璃会议室       INT/EXT：INT       时间段：白天（上午10点）
出现集次：第1集场景2、第2集场景1      主要情绪基调：职业感/压力/紧张

【空间描述】
整体风格：现代简约，北欧商务风
主要元素：长形白色会议桌，皮质高背椅（黑色），落地玻璃幕墙，投影屏幕
空间感：宽敞，高挑，通透感强

【光线氛围】
光源类型：自然光为主（落地窗），少量内嵌筒灯
光线质感：明亮漫射光，轻微逆光从窗外射入
色调倾向：冷白色调，带淡蓝感

【即梦参考图提示词】
中文版：
现代简约玻璃会议室，白色长条会议桌，黑色皮质高背椅，
落地玻璃幕墙，城市背景，白天自然光从窗外射入，
冷白色调，北欧商务风，无人物，广角摄影，电影感，
写实风格，高清细节，专业感

英文版（备用）：
modern minimalist glass conference room, white long meeting table,
black leather high-back chairs, floor-to-ceiling glass walls,
city view outside, daylight streaming in, cool white tone,
Nordic business style, no people, wide angle photography,
cinematic, photorealistic, high detail, professional atmosphere
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 视频提示词示例

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎥 视频提示词｜镜号 008
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【镜头信息】
场景：公司玻璃会议室       景别：近景       时长：5s       情绪：紧张→转机

【首帧描述】
25岁中国女性，圆脸大眼，黑色微卷中长发，米色衬衫，
站立于白色会议桌前，手抱文件夹，神情局促，低头，
现代玻璃会议室背景，自然光，冷白色调，电影感，写实，高清

【尾帧描述】
同一女性，抬头，眼神对上镜头外方向，嘴角微微张开呈惊讶状，
手中文件夹被对方接走，空手状态，场景同首帧，写实，高清

【视频提示词】
中文：
25岁中国女性，米色衬衫，手抱文件夹，站立于白色会议桌前，
从低头局促到抬头对视，近景，固定镜头，白天自然光，
冷白色调，现代会议室，职场感，电影质感，写实风格，
流畅运动，高清，无文字

英文（备用）：
25-year-old Chinese woman, beige shirt, holding folder, standing at white meeting table,
from looking down nervously to looking up making eye contact,
close-up shot, static camera, natural daylight, cool white tone,
modern conference room, professional atmosphere, cinematic quality,
photorealistic, smooth motion, high detail, no text

【运镜参数建议】
运镜类型：固定
速度：中速
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
