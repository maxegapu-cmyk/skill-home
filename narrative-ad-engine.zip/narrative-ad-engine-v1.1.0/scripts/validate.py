from pathlib import Path
import re, json, sys

ROOT = Path(__file__).resolve().parents[1]

required = [
    'SKILL.md','START-HERE.md','README.md','VERSION',
    'references/product-desire-map.md','references/hook-engine.md',
    'references/story-engine.md','references/recap-fusion-engine.md',
    'references/commercial-bridge.md','references/conversion-engine.md',
    'references/platform-production.md','references/quality-rubric.md',
    'references/compliance-notes.md','references/novice-playbook.md',
    'examples/cases.md','tests/fixtures.json'
]

errors=[]

for junk in list(ROOT.rglob('__pycache__')) + list(ROOT.rglob('*.pyc')):
    errors.append(f'release contains runtime cache: {junk.relative_to(ROOT)}')

for rel in required:
    p=ROOT/rel
    if not p.exists() or p.stat().st_size==0:
        errors.append(f'missing or empty: {rel}')

skill=(ROOT/'SKILL.md').read_text(encoding='utf-8') if (ROOT/'SKILL.md').exists() else ''
if not re.match(r'^---\nname:\s*narrative-ad-engine\n', skill):
    errors.append('SKILL.md frontmatter name invalid')
for needle in ['Hook Tournament','Commercial Bridge','Commercial Re-Hook','CREATE','RECAP','GRAFT','DIAGNOSE','recap-fusion-engine.md','novice-playbook.md']:
    if needle not in skill:
        errors.append(f'SKILL.md missing core concept: {needle}')

for rel in re.findall(r'`(references/[a-z0-9_-]+\.md)`', skill):
    if not (ROOT/rel).exists():
        errors.append(f'broken reference: {rel}')

for p in ROOT.rglob('*.md'):
    txt=p.read_text(encoding='utf-8')
    for token in ['TODO:', 'TBD:', 'FIXME:']:
        if token in txt:
            errors.append(f'{p.relative_to(ROOT)} contains {token}')
    if re.search(r'https?://',txt):
        errors.append(f'{p.relative_to(ROOT)} contains external link')

try:
    data=json.loads((ROOT/'tests/fixtures.json').read_text(encoding='utf-8'))
    if len(data)<16:
        errors.append('fixtures coverage < 16 categories')
    ids=[x['id'] for x in data]
    if len(ids)!=len(set(ids)):
        errors.append('duplicate fixture ids')
except Exception as e:
    errors.append(f'fixtures invalid json: {e}')

if errors:
    print('FAIL')
    for e in errors: print(' -', e)
    sys.exit(1)
print('PASS: package structure, routing, references, novice entry, recap fusion, link hygiene, and fixture coverage validated.')
