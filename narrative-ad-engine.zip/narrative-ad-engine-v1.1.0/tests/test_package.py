import json
import re
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class TestNarrativeAdEngine(unittest.TestCase):
    def test_version(self):
        self.assertRegex((ROOT/'VERSION').read_text().strip(), r'^1\.1\.0$')

    def test_core_is_not_reference_dump(self):
        core=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        refs=''.join(p.read_text(encoding='utf-8') for p in (ROOT/'references').glob('*.md'))
        self.assertLess(len(core), len(refs), 'Core should stay smaller than depth references')

    def test_novice_entry_exists(self):
        start=(ROOT/'START-HERE.md').read_text(encoding='utf-8')
        for x in ['最简单的用法','电影剧情解说','只想救前三秒','只想救“转广告就掉人”']:
            self.assertIn(x,start)

    def test_hook_engine_has_multimodal_open_and_rehook(self):
        txt=(ROOT/'references/hook-engine.md').read_text(encoding='utf-8')
        for x in ['Visual','Spoken','Text','H1','H12','Continuation Pressure','中段再起爆','Commercial Re-Hook']:
            self.assertIn(x,txt)

    def test_recap_engine_is_complete(self):
        txt=(ROOT/'references/recap-fusion-engine.md').read_text(encoding='utf-8')
        for x in ['RECAP-CREATE','三层留存曲线','Commercial Re-Hook','四种融合架构','接管点排名']:
            self.assertIn(x,txt)

    def test_bridge_has_multiple_mechanisms(self):
        txt=(ROOT/'references/commercial-bridge.md').read_text(encoding='utf-8')
        ids=set(re.findall(r'### (B\d+)',txt))
        self.assertGreaterEqual(len(ids),10)
        self.assertIn('Commercial Re-Hook',txt)

    def test_quality_has_recap_and_novice_checks(self):
        txt=(ROOT/'references/quality-rubric.md').read_text(encoding='utf-8')
        self.assertIn('不是对真实播放量',txt)
        self.assertIn('RECAP专项检查',txt)
        self.assertIn('小白交付完整度',txt)
        self.assertIn('Commercial Re-Hook',txt)

    def test_regulated_categories_covered(self):
        txt=(ROOT/'references/compliance-notes.md').read_text(encoding='utf-8')
        for x in ['金融','医疗','房产','教育']:
            self.assertIn(x,txt)

    def test_fixture_diversity(self):
        data=json.loads((ROOT/'tests/fixtures.json').read_text(encoding='utf-8'))
        self.assertGreaterEqual(len(data),16)
        products=' '.join(x['product'] for x in data)
        for x in ['住宅','AI','餐厅','SUV','RPG','保险','安全审计','女装','耳机','旅行','洗地机']:
            self.assertIn(x,products)

    def test_no_external_links_in_installable_text(self):
        for p in ROOT.rglob('*'):
            if p.is_file() and p.suffix.lower() in {'.md','.txt',''} and p.name != 'MANIFEST.sha256':
                try:
                    txt=p.read_text(encoding='utf-8')
                except UnicodeDecodeError:
                    continue
                self.assertNotRegex(txt, r'https?://', f'external link found in {p.relative_to(ROOT)}')

if __name__=='__main__':
    unittest.main()
