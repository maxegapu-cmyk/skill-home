#!/usr/bin/env python3
"""Smoke tests for package integrity and helper tools."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args: str) -> None:
    subprocess.run([sys.executable, *args], check=True, cwd=ROOT)


def main() -> int:
    required = [
        "SKILL.md", "README.md", "INSTALL.md", "QUICKSTART.md", "VERSION",
        "config/defaults.json", "schemas/batch-manifest.schema.json",
        "tools/init_project.py", "tools/make_manifest.py",
        "tools/validate_project.py", "tools/compile_report.py",
    ]
    for rel in required:
        path = ROOT / rel
        assert path.exists(), f"Missing {rel}"
        assert path.stat().st_size > 0, f"Empty {rel}"

    assert (ROOT / "VERSION").read_text(encoding="utf-8").strip() == "2.0.0"
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    assert skill.startswith("---\nname: viral-framework-analyzer")
    assert "不要让我填表" in skill
    assert "TOP / MID / LOW / UNKNOWN" in skill

    for rel in ["config/defaults.json", "schemas/batch-manifest.schema.json", "schemas/work-card.schema.json", "schemas/finding.schema.json"]:
        json.loads((ROOT / rel).read_text(encoding="utf-8"))

    with tempfile.TemporaryDirectory() as tmp:
        project = Path(tmp) / "test-project"
        run("tools/init_project.py", str(project))
        (project / "input" / "作品A").mkdir()
        (project / "input" / "作品A" / "script.txt").write_text("第1集：冲突", encoding="utf-8")
        run("tools/make_manifest.py", str(project / "input"), str(project / "batch-manifest.json"))
        run("tools/validate_project.py", str(project))
        (project / "output" / "01-summary.md").write_text("# Summary", encoding="utf-8")
        run("tools/compile_report.py", str(project / "output"), str(project / "final-report.md"))
        assert (project / "final-report.md").exists()

    print("All smoke tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
