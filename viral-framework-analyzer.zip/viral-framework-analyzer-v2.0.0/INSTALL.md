# 安装与使用

## 方式一：直接导入 ZIP

在支持自定义 Skill 的AI工具中，导入整个压缩包。确认系统识别到顶层 `SKILL.md` 后即可使用。

## 方式二：复制文件夹

把整个 `viral-framework-analyzer-v2.0.0` 文件夹复制到该工具的 Skills 目录，保持目录结构不变。

## 首次调用

上传待分析资料后发送：

> 直接分析我上传的全部作品。自动识别作品边界和数据，建立批次清单，不要让我填表。先全量快扫，再按表现分层做重点深拆，最后给我爆款核心框架、前三集模板、前十集升级路线、中后段衰减风险、横向矩阵和证据索引。

## 推荐素材组织

最省事的方式是“一部作品一个文件夹”，但不是强制要求：

```text
input/
├─ 作品A/
│  ├─ script.pdf
│  ├─ subtitles.srt
│  └─ metrics.csv
├─ 作品B/
│  ├─ episodes.docx
│  └─ cover.jpg
└─ ranking.xlsx
```

材料混在一起也可以，Skill会先自动盘点和归属。

## 本地辅助工具

本包内脚本仅用于整理项目文件，不负责代替AI分析：

```bash
python tools/init_project.py my-project
python tools/make_manifest.py my-project/input my-project/batch-manifest.json
python tools/validate_project.py my-project
python tools/compile_report.py my-project/output my-project/final-report.md
```

全部脚本只使用Python标准库。
