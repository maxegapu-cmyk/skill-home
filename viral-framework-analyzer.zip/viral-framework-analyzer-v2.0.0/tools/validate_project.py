#!/usr/bin/env python3
"""Validate the minimal integrity of a Viral Framework Analyzer project."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

TIERS = {"TOP", "MID", "LOW", "UNKNOWN"}


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {path}: {exc}") from exc


def validate_manifest(data: dict) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return ["Manifest must be an object"]
    if not data.get("batch_id"):
        errors.append("Missing batch_id")
    works = data.get("works")
    if not isinstance(works, list):
        return errors + ["works must be a list"]
    seen: set[str] = set()
    for idx, work in enumerate(works, 1):
        label = f"works[{idx}]"
        if not isinstance(work, dict):
            errors.append(f"{label} must be an object")
            continue
        wid = work.get("work_id")
        if not wid:
            errors.append(f"{label} missing work_id")
        elif wid in seen:
            errors.append(f"Duplicate work_id: {wid}")
        else:
            seen.add(wid)
        if not work.get("title"):
            errors.append(f"{label} missing title")
        tier = work.get("metrics", {}).get("tier") if isinstance(work.get("metrics"), dict) else None
        if tier and tier not in TIERS:
            errors.append(f"{label} invalid tier: {tier}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    args = parser.parse_args()
    manifest_path = args.project / "batch-manifest.json"
    if not manifest_path.exists():
        parser.error(f"Missing {manifest_path}")
    try:
        errors = validate_manifest(load_json(manifest_path))
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    if errors:
        print("Validation failed:")
        for error in errors:
            print(f"- {error}")
        return 1
    print("Validation passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
