#!/usr/bin/env python3
"""Initialize a workspace for Viral Framework Analyzer."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from datetime import datetime, timezone


def build_project(target: Path) -> None:
    if target.exists() and any(target.iterdir()):
        raise FileExistsError(f"Target is not empty: {target}")
    for name in ("input", "output", "output/work-cards", "output/deep-analysis", "state"):
        (target / name).mkdir(parents=True, exist_ok=True)

    manifest = {
        "batch_id": target.name,
        "goal": "",
        "success_metric": "auto",
        "platform_scope": [],
        "time_scope": "auto",
        "works": [],
    }
    state = {
        "batch_id": target.name,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "works": [],
    }
    (target / "batch-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (target / "state" / "analysis-state.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (target / "README.txt").write_text(
        "Put source materials in input/. Then run make_manifest.py and submit the project to the AI Skill.\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", type=Path, help="Project directory to create")
    args = parser.parse_args()
    try:
        build_project(args.target)
    except (OSError, FileExistsError) as exc:
        parser.error(str(exc))
    print(f"Initialized: {args.target.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
