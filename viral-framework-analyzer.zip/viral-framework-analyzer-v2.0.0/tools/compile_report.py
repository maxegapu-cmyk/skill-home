#!/usr/bin/env python3
"""Combine ordered Markdown report fragments into one report."""
from __future__ import annotations

import argparse
from pathlib import Path


def compile_markdown(source_dir: Path, output_file: Path) -> int:
    if not source_dir.is_dir():
        raise NotADirectoryError(source_dir)
    parts = sorted(p for p in source_dir.glob("*.md") if p.resolve() != output_file.resolve())
    if not parts:
        raise FileNotFoundError(f"No Markdown fragments found in {source_dir}")
    content = []
    for p in parts:
        text = p.read_text(encoding="utf-8").strip()
        if text:
            content.append(text)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text("\n\n---\n\n".join(content) + "\n", encoding="utf-8")
    return len(parts)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_dir", type=Path)
    parser.add_argument("output_file", type=Path)
    args = parser.parse_args()
    try:
        count = compile_markdown(args.source_dir, args.output_file)
    except OSError as exc:
        parser.error(str(exc))
    print(f"Compiled {count} fragments into {args.output_file.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
