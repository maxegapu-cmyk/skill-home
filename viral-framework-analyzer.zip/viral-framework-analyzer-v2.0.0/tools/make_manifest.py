#!/usr/bin/env python3
"""Create a draft batch manifest by scanning an input directory."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Iterable

SUPPORTED = {
    ".pdf", ".docx", ".txt", ".md", ".srt", ".vtt", ".csv", ".xlsx", ".json",
    ".png", ".jpg", ".jpeg", ".webp", ".mp4", ".mov", ".mkv"
}


def slug(index: int) -> str:
    return f"W{index:04d}"


def clean_title(value: str) -> str:
    value = re.sub(r"[_-]+", " ", value).strip()
    return value or "未命名作品"


def supported_files(folder: Path) -> Iterable[Path]:
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in SUPPORTED:
            yield p


def build_manifest(input_dir: Path) -> dict:
    if not input_dir.is_dir():
        raise NotADirectoryError(input_dir)

    works: list[dict] = []
    top_dirs = sorted([p for p in input_dir.iterdir() if p.is_dir()])
    loose_files = sorted([p for p in input_dir.iterdir() if p.is_file() and p.suffix.lower() in SUPPORTED])

    for folder in top_dirs:
        files = [str(p.relative_to(input_dir)) for p in supported_files(folder)]
        if not files:
            continue
        works.append({
            "work_id": slug(len(works) + 1),
            "title": clean_title(folder.name),
            "platform": "",
            "content_type": "",
            "genre": [],
            "files": files,
            "metrics": {},
        })

    for file in loose_files:
        works.append({
            "work_id": slug(len(works) + 1),
            "title": clean_title(file.stem),
            "platform": "",
            "content_type": "",
            "genre": [],
            "files": [str(file.relative_to(input_dir))],
            "metrics": {},
            "needs_boundary_review": True,
        })

    return {
        "batch_id": input_dir.parent.name or "batch",
        "goal": "",
        "success_metric": "auto",
        "platform_scope": [],
        "time_scope": "auto",
        "works": works,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_dir", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()
    try:
        manifest = build_manifest(args.input_dir)
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    except OSError as exc:
        parser.error(str(exc))
    print(f"Wrote {len(manifest['works'])} works to {args.output_json.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
