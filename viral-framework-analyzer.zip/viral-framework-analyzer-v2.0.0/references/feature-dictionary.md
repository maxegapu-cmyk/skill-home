# 特征词典

## 开篇特征

- `OPEN_AT_PEAK`：开篇直接进入核心矛盾或高价值事件；
- `ABSENT_POWER`：主角未正式出现，先用他人反应、声音、结果证明其力量；
- `CLEAR_DEBT`：开场迅速建立明确的亏欠、冤屈、危险或欲望；
- `FAST_FIRST_PAYOFF`：首集或前三集内完成第一次可验证兑现。

## 人物特征

- `STATUS_POWER_GAP`：外在身份低、实际能力高；
- `CUTE_MIND_GAP`：外在可爱/弱小与内在成熟吐槽或强能力反差；
- `SYMPATHY_ANCHOR`：通过被夺走、被误解、被牺牲或保护关系建立同情；
- `RELATIONSHIP_STAKE`：每次升级都会改变一段重要关系。

## 爽点与续航

- `REVENGE_ENGINE`：复仇对象和清算路径清楚；
- `IDENTITY_ENGINE`：身份信息分层揭晓并产生现实后果；
- `UPGRADE_ENGINE`：每次升级解锁新能力、新资源和新代价；
- `PAYOFF_VARIATION`：奖励功能发生变化，而不是只换一个被打脸者；
- `SECOND_ENGINE`：第一核心矛盾结束前已经建立第二条长期问题。

## 衰减特征

- `CONFLICT_DEFLATION`：新敌人名义更大，但情绪仇恨或现实代价更弱；
- `SPECTACLE_INFLATION`：奇观规模上升，人物选择和关系代价没有同步上升；
- `LORE_DRIFT`：世界观不断扩张，但主角欲望与观众关心的问题逐渐模糊；
- `PAYOFF_CLONING`：连续多次使用同一种奖励功能。

## 外部变量

- `IP_FRICTION_REDUCTION`：已有IP降低理解成本与铺垫成本；
- `FORMAT_ADVANTAGE`：AI、真人、漫剧、解说形态对特定题材的天然适配；
- `DISTRIBUTION_AMPLIFIER`：账号、投流、发行和平台窗口放大内容表现。
