#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md",
    "requirements.txt",
    "method/probe-catalog.md",
    "method/scoring-protocol.md",
    "method/reconstruction-language.md",
    "method/failure-modes.md",
    "method/worked-examples.md",
    "lab/make_probes.py",
    "lab/score_fragility.py",
    "lab/validate_package.py",
    "forms/ratings.csv",
    "forms/result-template.md",
    "tests/test_lab.py",
]

errors = []
if ROOT.name != "aesthetic-stress-extractor":
    errors.append(f"unexpected root folder: {ROOT.name}")
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f"missing: {rel}")

skill = ROOT / "SKILL.md"
if skill.exists():
    text = skill.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        errors.append("SKILL.md missing YAML frontmatter")
    if "name: aesthetic-stress-extractor" not in text:
        errors.append("SKILL.md name mismatch")
    if "version: 1.0.0" not in text:
        errors.append("SKILL.md version mismatch")
    if "counterfactual" not in text.lower() or "stress" not in text.lower():
        errors.append("core method not declared")

for p in ROOT.rglob("*"):
    if p.is_file():
        rel = p.relative_to(ROOT).as_posix()
        if rel.startswith("/") or ".." in Path(rel).parts or "\\" in rel:
            errors.append(f"unsafe path: {rel}")
        if p.suffix.lower() in {".md", ".py", ".csv", ".json", ".txt"}:
            try:
                p.read_text(encoding="utf-8")
            except Exception as e:
                errors.append(f"not valid UTF-8: {rel}: {e}")

if errors:
    print("VALIDATION FAIL")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("VALIDATION PASS")
for rel in REQUIRED:
    b = (ROOT / rel).read_bytes()
    print(hashlib.sha256(b).hexdigest(), rel)
