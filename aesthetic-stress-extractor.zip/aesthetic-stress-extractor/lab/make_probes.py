#!/usr/bin/env python3
"""Generate controlled counterfactual stress probes for a still image.

The reported dose is a mechanical image-change proxy, not an aesthetic score.
No network access and no model inference are used.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Callable, Dict, Tuple

import cv2
import numpy as np
from skimage.metrics import structural_similarity

SEED = 1337


def read_rgb(path: Path) -> np.ndarray:
    bgr = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if bgr is None:
        raise ValueError(f"Cannot read image: {path}")
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def write_rgb(path: Path, rgb: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    bgr = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(path), bgr):
        raise IOError(f"Cannot write image: {path}")


def gray_u8(rgb: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2GRAY)


def edge_map(rgb: np.ndarray) -> np.ndarray:
    g = gray_u8(rgb).astype(np.float32)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    mag = cv2.magnitude(gx, gy)
    p = float(np.percentile(mag, 99))
    if p <= 1e-6:
        return np.zeros_like(mag)
    return np.clip(mag / p, 0, 1)


def mechanical_dose(a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
    """Mechanical image-change diagnostics. Not an aesthetic or perceptual score."""
    a8 = a.astype(np.uint8)
    b8 = b.astype(np.uint8)
    lab_a = cv2.cvtColor(a8, cv2.COLOR_RGB2LAB).astype(np.float32)
    lab_b = cv2.cvtColor(b8, cv2.COLOR_RGB2LAB).astype(np.float32)
    per_pixel = np.linalg.norm(lab_a - lab_b, axis=2) / (255.0 * math.sqrt(3.0))
    flat = per_pixel.ravel()
    cut = max(0, int(flat.size * 0.90))
    active_lab = float(np.mean(np.partition(flat, cut)[cut:])) if flat.size else 0.0
    mean_lab = float(np.mean(per_pixel))

    ga = gray_u8(a8)
    gb = gray_u8(b8)
    ssim = float(structural_similarity(ga, gb, data_range=255))
    ssim_loss = max(0.0, 1.0 - ssim)

    ea = edge_map(a8)
    eb = edge_map(b8)
    ed = np.abs(ea - eb).ravel()
    ecut = max(0, int(ed.size * 0.90))
    active_edge = float(np.mean(np.partition(ed, ecut)[ecut:])) if ed.size else 0.0

    proxy = 0.50 * active_lab + 0.15 * mean_lab + 0.15 * ssim_loss + 0.20 * active_edge
    return {
        "mechanical_delta_proxy": float(proxy),
        "active_lab_delta_norm": active_lab,
        "mean_lab_delta_norm": mean_lab,
        "luma_ssim_loss": ssim_loss,
        "active_edge_delta": active_edge,
    }

def activity_map(rgb: np.ndarray) -> np.ndarray:
    g = gray_u8(rgb).astype(np.float32) / 255.0
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    grad = cv2.magnitude(gx, gy)
    mean = cv2.GaussianBlur(g, (0, 0), 5)
    var = cv2.GaussianBlur((g - mean) ** 2, (0, 0), 5)
    a = grad + 2.0 * np.sqrt(np.maximum(var, 0))
    p = float(np.percentile(a, 99))
    if p <= 1e-8:
        return np.zeros_like(a)
    return np.clip(a / p, 0, 1)


def visual_mass_centroid(rgb: np.ndarray) -> Tuple[float, float, float]:
    g = gray_u8(rgb).astype(np.float32) / 255.0
    a = activity_map(rgb)
    contrast = np.abs(g - float(np.mean(g)))
    w = a + 0.6 * contrast + 1e-6
    yy, xx = np.indices(w.shape)
    total = float(w.sum())
    cx = float((xx * w).sum() / total)
    cy = float((yy * w).sum() / total)
    h, wd = w.shape
    offset = math.hypot((cx - (wd - 1) / 2) / max(wd, 1), (cy - (h - 1) / 2) / max(h, 1))
    return cx, cy, offset


def p_chroma(rgb: np.ndarray, s: float) -> np.ndarray:
    hsv = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    hsv[:, :, 1] *= (1.0 - np.clip(s, 0, 1))
    return cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB)


def p_tone(rgb: np.ndarray, s: float) -> np.ndarray:
    lab = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    L = lab[:, :, 0]
    mean = float(np.mean(L))
    factor = 1.0 - 0.88 * np.clip(s, 0, 1)
    lab[:, :, 0] = np.clip(mean + (L - mean) * factor, 0, 255)
    return cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2RGB)


def p_recenter(rgb: np.ndarray, s: float) -> np.ndarray:
    h, w = rgb.shape[:2]
    cx, cy, _ = visual_mass_centroid(rgb)
    dx = ((w - 1) / 2 - cx) * np.clip(s, 0, 1)
    dy = ((h - 1) / 2 - cy) * np.clip(s, 0, 1)
    M = np.float32([[1, 0, dx], [0, 1, dy]])
    return cv2.warpAffine(rgb, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT_101)


def _noise_field(h: int, w: int, sigma: float = 2.5) -> np.ndarray:
    rng = np.random.default_rng(SEED)
    n = rng.normal(0, 1, (h, w)).astype(np.float32)
    n = cv2.GaussianBlur(n, (0, 0), sigma)
    n -= float(n.mean())
    sd = float(n.std())
    return n / (sd + 1e-6)


def p_quiet_contam(rgb: np.ndarray, s: float) -> np.ndarray:
    h, w = rgb.shape[:2]
    a = activity_map(rgb)
    q = float(np.quantile(a, 0.38))
    mask = (a <= q).astype(np.float32)
    mask = cv2.GaussianBlur(mask, (0, 0), max(2.0, min(h, w) / 80.0))
    noise = _noise_field(h, w, sigma=max(1.5, min(h, w) / 220.0))
    amp = 38.0 * np.clip(s, 0, 1)
    out = rgb.astype(np.float32) + (noise * mask * amp)[:, :, None]
    return np.clip(out, 0, 255).astype(np.uint8)


def p_detail_homogenize(rgb: np.ndarray, s: float) -> np.ndarray:
    h, w = rgb.shape[:2]
    a = activity_map(rgb)
    high = cv2.GaussianBlur(np.clip((a - 0.30) / 0.50, 0, 1), (0, 0), 2)
    low = cv2.GaussianBlur(np.clip((0.35 - a) / 0.35, 0, 1), (0, 0), 2)
    blur = cv2.GaussianBlur(rgb, (0, 0), 2.0).astype(np.float32)
    base = rgb.astype(np.float32)
    k = 0.75 * np.clip(s, 0, 1)
    out = base * (1 - high[:, :, None] * k) + blur * (high[:, :, None] * k)
    noise = _noise_field(h, w, sigma=1.2)
    out += (noise * low * (12.0 * np.clip(s, 0, 1)))[:, :, None]
    return np.clip(out, 0, 255).astype(np.uint8)


def p_attention_challenge(rgb: np.ndarray, s: float) -> np.ndarray:
    h, w = rgb.shape[:2]
    a = activity_map(rgb)
    yy, xx = np.indices((h, w))
    # Prefer quiet peripheral areas so the pulse actually challenges the existing hierarchy.
    center_penalty = 1.0 - np.clip(np.hypot((xx - w / 2) / max(w / 2, 1), (yy - h / 2) / max(h / 2, 1)), 0, 1)
    score = a + 0.35 * center_penalty
    idx = int(np.argmin(score))
    cy, cx = np.unravel_index(idx, score.shape)
    sigma = max(4.0, min(h, w) * 0.045)
    gauss = np.exp(-((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * sigma * sigma)).astype(np.float32)
    amp = 78.0 * np.clip(s, 0, 1)
    g = gray_u8(rgb).astype(np.float32)
    local = float(g[max(0, cy-2):min(h, cy+3), max(0, cx-2):min(w, cx+3)].mean())
    sign = 1.0 if local < 128 else -1.0
    out = rgb.astype(np.float32) + (sign * amp * gauss)[:, :, None]
    return np.clip(out, 0, 255).astype(np.uint8)


def p_crop(rgb: np.ndarray, s: float) -> np.ndarray:
    h, w = rgb.shape[:2]
    frac = 0.12 * np.clip(s, 0, 1)
    dx, dy = int(round(w * frac)), int(round(h * frac))
    if dx * 2 >= w - 2 or dy * 2 >= h - 2:
        return rgb.copy()
    crop = rgb[dy:h-dy, dx:w-dx]
    return cv2.resize(crop, (w, h), interpolation=cv2.INTER_CUBIC)


def p_hue(rgb: np.ndarray, s: float) -> np.ndarray:
    hsv = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.int16)
    shift = int(round(60 * np.clip(s, 0, 1)))  # OpenCV hue range 0..179
    hsv[:, :, 0] = (hsv[:, :, 0] + shift) % 180
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)


CORE: Dict[str, Callable[[np.ndarray, float], np.ndarray]] = {
    "chroma_withdrawal": p_chroma,
    "tonal_compression": p_tone,
    "balance_recenter": p_recenter,
    "quiet_zone_contamination": p_quiet_contam,
    "detail_homogenization": p_detail_homogenize,
    "attention_challenge": p_attention_challenge,
}
OPTIONAL = {"crop_pressure": p_crop, "hue_rotation": p_hue}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("image", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--preset", choices=["quick", "curve"], default="curve")
    ap.add_argument("--include-optional", action="store_true")
    ap.add_argument("--frame-id", default="frame-001")
    args = ap.parse_args()

    rgb = read_rgb(args.image)
    if min(rgb.shape[:2]) < 32:
        raise ValueError("Input image is too small for stable stress diagnostics; minimum dimension is 32 px")
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    variants_dir = out / "blind_variants"
    variants_dir.mkdir(exist_ok=True)

    levels = ["medium"] if args.preset == "quick" else ["light", "medium", "strong"]
    # Values are fractions of each operator's bounded safe range, not a universal perceptual dose.
    safe_strengths = {
        "chroma_withdrawal": {"light": 0.33, "medium": 0.66, "strong": 1.00},
        "tonal_compression": {"light": 0.25, "medium": 0.52, "strong": 0.82},
        "balance_recenter": {"light": 0.33, "medium": 0.66, "strong": 1.00},
        "quiet_zone_contamination": {"light": 0.22, "medium": 0.45, "strong": 0.72},
        "detail_homogenization": {"light": 0.22, "medium": 0.46, "strong": 0.72},
        "attention_challenge": {"light": 0.25, "medium": 0.50, "strong": 0.75},
        "crop_pressure": {"light": 0.25, "medium": 0.50, "strong": 0.75},
        "hue_rotation": {"light": 0.25, "medium": 0.50, "strong": 0.75},
    }
    probes = dict(CORE)
    if args.include_optional:
        probes.update(OPTIONAL)

    cx, cy, off = visual_mass_centroid(rgb)
    baseline = {
        "input": str(args.image),
        "width": int(rgb.shape[1]),
        "height": int(rgb.shape[0]),
        "visual_mass_centroid": [cx, cy],
        "visual_mass_offset_norm": off,
        "note": "operator_dose_norm is relative to each probe safe range; mechanical_delta_proxy is diagnostic only. Neither is an aesthetic score.",
    }

    records = []
    for probe, fn in probes.items():
        if probe == "balance_recenter" and off < 0.018:
            records.append({"probe": probe, "status": "NON_DIAGNOSTIC", "reason": "baseline visual mass already near center"})
            continue
        for level in levels:
            strength = float(safe_strengths[probe][level])
            variant = fn(rgb, strength)
            metrics = mechanical_dose(rgb, variant)
            # A very small mechanical delta means the operator had no useful range on this frame.
            status = "VALID" if metrics["mechanical_delta_proxy"] >= 0.0010 else "TOO_WEAK"
            records.append({
                "probe": probe,
                "dose_level": level,
                "operator_dose_norm": strength,
                "operator_strength": strength,
                "status": status,
                **metrics,
            })
            if status == "VALID":
                raw_name = f"{probe}__{level}.png"
                write_rgb(out / "operator_named" / raw_name, variant)

    valid = [r for r in records if r.get("status") == "VALID"]
    # Deterministic blind aliases based on input bytes + fixed seed.
    digest = hashlib.sha256(args.image.read_bytes()).hexdigest()
    rng = np.random.default_rng(int(digest[:8], 16) ^ SEED)
    order = list(range(len(valid)))
    rng.shuffle(order)
    alias_map = {}
    blind_rows = []
    frame_prefix = hashlib.sha1(args.frame_id.encode("utf-8")).hexdigest()[:4].upper()
    for n, idx in enumerate(order, 1):
        r = valid[idx]
        alias = f"{frame_prefix}-A{n:02d}"
        src = out / "operator_named" / f"{r['probe']}__{r['dose_level']}.png"
        dst = variants_dir / f"{alias}.png"
        dst.write_bytes(src.read_bytes())
        alias_map[alias] = {
            "probe": r["probe"],
            "dose_level": r["dose_level"],
            "operator_dose_norm": r["operator_dose_norm"],
            "mechanical_delta_proxy": r["mechanical_delta_proxy"],
            "operator_strength": r["operator_strength"],
        }
        blind_rows.append([alias, args.frame_id, f"{r['operator_dose_norm']:.6f}", f"{r['mechanical_delta_proxy']:.6f}", r["dose_level"], "", "no", ""])

    with (out / "ratings_blind.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["alias", "frame_id", "operator_dose_norm", "mechanical_delta_proxy", "dose_level", "survival_score", "confounded", "reason"])
        w.writerows(blind_rows)

    (out / "blind_map.json").write_text(json.dumps(alias_map, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "probe_metrics.json").write_text(json.dumps({"baseline": baseline, "records": records}, indent=2, ensure_ascii=False), encoding="utf-8")
    write_rgb(out / "baseline.png", rgb)

    print(f"Generated {len(valid)} valid blind variants in {out}")
    weak = sum(1 for r in records if r.get("status") == "TOO_WEAK")
    skipped = sum(1 for r in records if r.get("status") == "NON_DIAGNOSTIC")
    print(f"Too-weak variants: {weak}; non-diagnostic probes: {skipped}")


if __name__ == "__main__":
    main()
