#!/usr/bin/env python3
"""Combine blind survival ratings with the hidden operator map and summarize fragility."""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def tier(slope: float, median_survival: float) -> str:
    if slope >= 2.0 and median_survival <= 2.5:
        return "CRITICAL"
    if slope >= 1.0:
        return "IMPORTANT"
    if slope < 0.70:
        return "FLEXIBLE"
    return "MODERATE"


def fit(rows):
    doses = np.array([r["dose"] for r in rows], dtype=float)
    losses = np.array([r["loss"] for r in rows], dtype=float)
    denom = float(np.sum(doses * doses))
    slope = float(np.sum(doses * losses) / denom) if denom > 1e-12 else 0.0
    pred = slope * doses
    sse = float(np.sum((losses - pred) ** 2))
    sst = float(np.sum((losses - float(np.mean(losses))) ** 2))
    r2 = None if sst <= 1e-12 else float(1.0 - sse / sst)
    return slope, r2


def percentile_spread(vals):
    a = np.array(vals, dtype=float)
    return float(np.percentile(a, 25)), float(np.percentile(a, 75))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ratings", type=Path, nargs="+")
    ap.add_argument("--map", dest="map_paths", type=Path, nargs="+", required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    mapping = {}
    for mp in args.map_paths:
        data = json.loads(mp.read_text(encoding="utf-8"))
        overlap = set(mapping).intersection(data)
        if overlap:
            raise SystemExit(f"Duplicate blind aliases across maps: {sorted(overlap)[:5]}")
        mapping.update(data)
    by_frame_probe = defaultdict(list)
    rejected = []

    all_rows = []
    for rp in args.ratings:
        with rp.open("r", encoding="utf-8", newline="") as f:
            all_rows.extend(list(csv.DictReader(f)))

    for row in all_rows:
        alias = row["alias"].strip()
        if alias not in mapping:
            rejected.append({"alias": alias, "reason": "missing blind map entry"})
            continue
        conf = row.get("confounded", "no").strip().lower() in {"yes", "y", "true", "1"}
        if conf:
            rejected.append({"alias": alias, "reason": "confounded"})
            continue
        try:
            score = float(row["survival_score"])
        except Exception:
            rejected.append({"alias": alias, "reason": "missing survival score"})
            continue
        if not (0 <= score <= 4):
            rejected.append({"alias": alias, "reason": "survival score outside 0..4"})
            continue
        dose = float(mapping[alias]["operator_dose_norm"])
        loss = (4.0 - score) / 4.0
        item = {
            "alias": alias,
            "dose": dose,
            "score": score,
            "loss": loss,
            "dose_level": mapping[alias]["dose_level"],
        }
        by_frame_probe[(row["frame_id"].strip() or "frame-001", mapping[alias]["probe"])].append(item)

    frame_results = []
    per_probe_across_frames = defaultdict(list)
    for (frame, probe), rows in sorted(by_frame_probe.items()):
        slope, r2 = fit(rows)
        med = float(np.median([r["score"] for r in rows]))
        monotonic = True
        ordered = sorted(rows, key=lambda r: r["dose"])
        losses = [r["loss"] for r in ordered]
        for a, b in zip(losses, losses[1:]):
            if b + 0.10 < a:
                monotonic = False
        result = {
            "frame_id": frame,
            "probe": probe,
            "valid_points": len(rows),
            "fragility_slope": slope,
            "fit_r2": r2,
            "median_survival": med,
            "near_monotonic": monotonic,
            "tier": tier(slope, med),
        }
        frame_results.append(result)
        per_probe_across_frames[probe].append(result)

    set_summary = []
    for probe, rows in sorted(per_probe_across_frames.items()):
        slopes = [r["fragility_slope"] for r in rows]
        q1, q3 = percentile_spread(slopes)
        med = float(np.median(slopes))
        spread = q3 - q1
        stability = "STABLE" if len(slopes) == 1 or spread <= max(0.35, 0.35 * max(med, 0.1)) else "HETEROGENEOUS"
        set_summary.append({
            "probe": probe,
            "frames": len(rows),
            "median_fragility": med,
            "q1": q1,
            "q3": q3,
            "iqr": spread,
            "response": stability,
        })

    payload = {
        "warning": "Fragility is a heuristic sensitivity slope against operator-normalized safe-range strength. Mechanical image deltas are diagnostics only; this is not a physical law or universal style score.",
        "frame_results": sorted(frame_results, key=lambda r: (-r["fragility_slope"], r["probe"])),
        "set_summary": sorted(set_summary, key=lambda r: (-r["median_fragility"], r["probe"])),
        "rejected_rows": rejected,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {args.out}; valid frame/probe groups: {len(frame_results)}; rejected rows: {len(rejected)}")


if __name__ == "__main__":
    main()
