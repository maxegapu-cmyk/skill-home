---
name: aesthetic-stress-extractor
description: Extracts reusable cinematic aesthetics by controlled counterfactual stress testing. It asks which visual conditions can be weakened, displaced, contaminated, or neutralized before the image stops feeling aesthetically intact; ranks those sensitivities; then outputs a minimum survival set and a compact reconstruction brief. Use for film-frame aesthetic extraction, multi-frame look analysis, prompt reconstruction, style robustness diagnosis, or checking which visual relationships matter most. It does not infer real camera gear, authorship intent, or a whole film's universal style from one frame.
metadata:
  version: 1.0.0
---

# Aesthetic Stress Extractor v1.0.0

## 0. Core proposition

Do not begin by inventorying what the frame contains.

Ask a harder question:

> **What can be deliberately damaged before the aesthetic stops surviving?**

This Skill treats cinematic aesthetics as a **response to controlled perturbation**. A property matters not because it can be named, but because weakening it causes a repeatable loss.

The method is intentionally counterfactual:

`baseline frame -> isolated stress probe -> blind survival judgment -> sensitivity curve -> minimum survival set -> reconstruction brief`

A single frame supports a frame-level result only. Multiple frames support a set-level stress pattern only. Never promote either into a claim about an artist's complete career or a film's universal identity without broader evidence.

## 1. What the Skill returns

For a normal completed run, return four products:

1. **Fragility Ranking** — which controlled perturbations cause the steepest aesthetic loss.
2. **Minimum Survival Set** — the smallest set of conditions that must remain intact for the tested aesthetic to survive.
3. **Safe-to-Vary List** — dimensions that tolerated meaningful change and therefore should not consume prompt budget unless the user wants them.
4. **Reconstruction Brief** — short, observable instructions for rebuilding the surviving conditions in new content.

Optional fifth product when generated results are available:

5. **Failure Diagnosis** — identify which survival condition the generated result violated, instead of vaguely saying “the style is off.”

## 2. Non-negotiable scientific honesty

### 2.1 Mechanical disturbance is not aesthetic loss

Scripts may measure pixel, luminance, edge, or structural deltas. Those values are a **mechanical dose proxy** only.

They do not prove aesthetic damage.

Aesthetic survival must be judged separately by a human or vision-capable model under the blind protocol in `method/scoring-protocol.md`.

### 2.2 Never invent measurements

If the scripts did not run, do not fabricate dose values, percentages, centroids, entropy, edge density, or similarity scores.

Use qualitative labels instead:

- mild / moderate / strong disturbance
- survives / weakened / broken
- high / medium / low confidence

### 2.3 Never infer hidden production facts from appearance alone

Do not claim a specific camera, lens model, aperture, film stock, lighting fixture, LUT, focal length, or on-set technique unless the user supplied reliable production evidence.

Describe what is visible, not an imagined set report.

### 2.4 A stress probe must isolate one intended pressure

If a probe changes subject identity, story meaning, wardrobe, facial expression, scene semantics, or multiple major visual conditions at once, mark it `CONFOUNDED` and exclude it from ranking.

## 3. Run sizes

Choose the smallest run that can answer the request.

### Quick Sweep

Use when the user needs a fast diagnosis.

- 1 frame
- 6 core probes
- one calibrated middle dose per probe
- blind survival judgment
- ranked top 3 fragile conditions
- concise reconstruction brief

### Curve Run

Use when the user wants a serious extraction.

- 1 frame
- 6 core probes
- three dose levels per valid probe
- fit a sensitivity slope
- flag nonlinear or unstable responses
- derive minimum survival set and safe-to-vary list

### Set Run

Use for multiple frames from one desired body of work.

- run the same valid probes on each frame
- do not average away disagreement
- report median sensitivity and spread per probe
- distinguish shared weaknesses from scene-specific weaknesses
- if responses are heterogeneous, say so plainly

## 4. The six core probes

The core probes are **interventions**, not a static checklist of visual categories.

### P1 — Chroma Withdrawal

Gradually reduce chroma while preserving luminance as much as practical.

Question: does the aesthetic survive when color intensity is removed?

High sensitivity means chromatic relationships are load-bearing. Low sensitivity means color may be more flexible than it first appears.

### P2 — Tonal Compression

Compress luminance separation toward the frame mean while preserving geometry and content.

Question: how dependent is the aesthetic on its hierarchy of dark, middle, and bright regions?

### P3 — Balance Recenter

Move the image's measured visual-mass centroid toward frame center without redesigning the subject.

Question: is off-center balance or asymmetric weight distribution load-bearing?

If the baseline is already effectively centered, this probe is non-diagnostic and must be skipped rather than forced.

### P4 — Quiet-Zone Contamination

Find low-activity regions and inject controlled non-semantic texture into them without adding recognizable objects.

Question: does the frame depend on areas that remain visually quiet?

### P5 — Detail Homogenization

Reduce the contrast between high-detail and low-detail zones: soften concentrated detail while adding very mild non-semantic texture to sparse zones.

Question: does the aesthetic depend on **where** information is concentrated, rather than on total sharpness alone?

### P6 — Attention Challenge

Introduce a small, soft, non-semantic contrast event in a previously low-competition region.

Question: does the aesthetic depend on a strict hierarchy of attention, where competing hotspots are costly?

If the added event reads as a real object or changes story meaning, discard the probe as confounded.

## 5. Optional probes

Use only when the image makes them meaningful.

- **Crop Pressure** — small controlled inward crop to test edge tension and breathing room.
- **Hue Rotation** — rotate hue while approximately preserving luminance/chroma magnitude; useful only after Chroma Withdrawal indicates color is important.
- **Edge Weakening** — soften dominant boundaries without changing content; useful for silhouette-led frames.
- **Microtexture Injection** — add controlled fine grain/noise when the question is surface quietness rather than color or composition.

Do not activate every optional probe by default.

## 6. Dose calibration

Cross-probe pixel deltas are **not** a universal perceptual ruler. A tiny new hotspot can be aesthetically devastating while changing very few pixels, whereas desaturation can alter most pixels but leave composition intact.

Therefore v1.0 uses **operator-normalized dose** instead of pretending all probes can be matched by one global image-distance number.

Each probe has a bounded, non-semantic safe range. Curve Run samples light / medium / strong fractions of that operator's safe range. The scripts also report mechanical image-change proxies based on Lab delta, luminance structure, and edge-map change, but those numbers are diagnostics only.

A probe is `TOO_WEAK` if even its strong safe setting causes almost no measurable change, and `CONFOUNDED` if increasing strength changes scene meaning or identity. Neither is forced into the ranking.

This makes the final fragility ranking an **experimental sensitivity index**, not a claim that 0.5 of one operator is physically identical to 0.5 of another.

## 7. Blind survival judgment

Judges should not know which operator created which variant during first scoring.

For each variant, score **aesthetic survival**:

- `4` — survives strongly; still carries the same tested aesthetic experience
- `3` — mostly survives; noticeable weakening
- `2` — ambiguous / half survives
- `1` — mostly broken
- `0` — decisively broken

Also record:

- `confounded = yes/no`
- one short reason based on visible experience

Do not score technical correctness, prettiness, or fidelity to subject identity unless the perturbation accidentally broke them and therefore must be marked confounded.

## 8. Fragility calculation

For one valid observation:

`loss = (4 - survival_score) / 4`

`fragility = loss / operator_normalized_dose`

For three dose levels, fit the slope of aesthetic loss against the normalized strength of that same operator. A steep slope means the image loses its aesthetic quickly within that intervention family. Mechanical pixel deltas remain a separate sanity-check field and are never used as aesthetic truth.

Do not over-interpret tiny differences. Treat near-ties as a tier.

Recommended tiers:

- **Critical** — consistently steep response; protect first
- **Important** — clear response but not dominant
- **Flexible** — meaningful disturbance tolerated
- **Unresolved** — probe invalid, dose-limited, or judgments unstable

## 9. Deriving the Minimum Survival Set

Do not simply copy the top three probe names.

Translate each critical response into an observable condition.

Bad:

> P3 is critical.

Good:

> Keep the primary visual mass substantially left of center; do not rebalance the frame into a centered portrait.

Then remove redundancy. The Minimum Survival Set should usually contain **2–5 obligations**, not ten generic style adjectives.

Every obligation must answer:

- what must remain,
- what visible failure would violate it,
- whether it is frame-specific or shared across the tested set.

## 10. Safe-to-Vary List

Low fragility is useful information.

If moderate chroma withdrawal barely changes the aesthetic, do not waste half the final prompt demanding exact palette recreation unless the user explicitly wants color matching.

The Safe-to-Vary List may include things such as:

- exact hue family,
- fine grain amount,
- minor background detail,
- small crop changes,
- local sharpness,

but only when the stress run actually supports that flexibility.

## 11. Reconstruction Brief

The final production brief must be short and observable.

Preferred form:

1. subject/content sentence supplied by the user,
2. 2–5 Minimum Survival Set obligations,
3. one attention/space guardrail if critical,
4. optional flexible degrees of freedom,
5. explicit instruction not to introduce a competing visual event when attention hierarchy is fragile.

Avoid name-dropping filmmakers, films, cameras, lenses, or “cinematic” as a substitute for the discovered conditions.

Do not output analysis bureaucracy inside the generator-facing brief.

See `method/reconstruction-language.md`.

## 12. Multi-frame handling

A Set Run does **not** ask, “what properties appear most often?”

It asks:

> **Do different frames break under the same kinds of controlled pressure?**

For each probe across frames report:

- median fragility,
- interquartile spread,
- number of valid frames,
- whether response is stable or scene-dependent.

A shared weakness requires both:

- high enough median sensitivity,
- acceptably low disagreement.

If one group of frames is color-fragile and another is color-flexible, do not average them into a fake middle style. Report a split response.

## 13. Generated-result diagnosis

For a supplied generated result, do not automatically restart the full extraction.

Compare the generated image against the Minimum Survival Set:

- which obligation survives,
- which obligation fails,
- which new competing event appeared,
- which fragile relation was flattened or displaced.

Repair only the failed obligation first. Do not rewrite every parameter at once.

## 14. Failure conditions

Stop or downgrade confidence when:

- probes are not isolated,
- dose levels differ so much that ranking is meaningless,
- the frame contains dominant text/HUD/watermark that controls attention,
- the frame is too low-resolution for detail-based probes,
- the subject occupies nearly the entire frame and Balance Recenter has no meaningful range,
- multiple judges disagree strongly,
- multiple frames show incompatible sensitivity orderings,
- a single image is being used to support work-wide or author-wide claims.

## 15. Tool usage

When local execution is available:

```bash
python lab/make_probes.py INPUT_IMAGE --out RUN_DIR --preset curve
python lab/score_fragility.py RUN_DIR/ratings.csv --out RUN_DIR/summary.json
python lab/validate_package.py .
```

`make_probes.py` produces safe-range light/medium/strong variants, per-variant mechanical diagnostics, and a blind alias map.

The judge fills the ratings sheet after seeing blind variants.

`score_fragility.py` excludes confounded rows and computes sensitivity summaries.

Tools are optional. Without them, run a qualitative version and label all quantities as qualitative.

## 16. Quality bar

A completed extraction is useful only if it can answer all four questions:

1. What breaks first?
2. What survives surprisingly well?
3. What is the smallest observable set of conditions worth protecting?
4. Can those conditions be stated clearly enough to rebuild on totally new content?

If it cannot answer these, do not pad the response with more aesthetic vocabulary. The extraction failed.
