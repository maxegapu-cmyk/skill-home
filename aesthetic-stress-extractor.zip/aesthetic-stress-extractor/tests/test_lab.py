#!/usr/bin/env python3
from __future__ import annotations
import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MAKE = ROOT / "lab" / "make_probes.py"
SCORE = ROOT / "lab" / "score_fragility.py"


def make_synthetic(path: Path, left_heavy: bool = True):
    h, w = 240, 360
    img = np.full((h, w, 3), 28, dtype=np.uint8)
    # quiet wall
    img[:, :, 0] += np.linspace(0, 12, w, dtype=np.uint8)[None, :]
    x0 = 55 if left_heavy else 145
    cv2.rectangle(img, (x0, 65), (x0 + 75, 205), (70, 105, 170), -1)
    cv2.circle(img, (x0 + 38, 55), 30, (175, 160, 120), -1)
    cv2.rectangle(img, (300, 80), (330, 130), (230, 220, 170), -1)
    cv2.imwrite(str(path), img)


def run(cmd):
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode != 0:
        raise AssertionError(p.stdout)
    return p.stdout


def main():
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        src = d / "frame.png"
        make_synthetic(src, True)
        out = d / "run"
        text = run([sys.executable, str(MAKE), str(src), "--out", str(out), "--preset", "curve"])
        assert (out / "probe_metrics.json").exists(), text
        assert (out / "blind_map.json").exists()
        assert (out / "ratings_blind.csv").exists()
        mapping = json.loads((out / "blind_map.json").read_text())
        assert len(mapping) >= 12, f"too few valid variants: {len(mapping)}"
        assert any(v["probe"] == "balance_recenter" for v in mapping.values())

        # Fill deterministic synthetic ratings: tonal and balance are fragile, chroma flexible.
        rows = []
        with (out / "ratings_blind.csv").open(newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                probe = mapping[r["alias"]]["probe"]
                level = mapping[r["alias"]]["dose_level"]
                level_loss = {"light": 1, "medium": 2, "strong": 3}.get(level, 2)
                if probe in {"tonal_compression", "balance_recenter"}:
                    score = max(0, 4 - level_loss)
                elif probe == "chroma_withdrawal":
                    score = 4
                else:
                    score = max(1, 4 - max(1, level_loss - 1))
                r["survival_score"] = str(score)
                rows.append(r)
        rated = out / "ratings_filled.csv"
        with rated.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            w.writeheader(); w.writerows(rows)

        summary = out / "summary.json"
        run([sys.executable, str(SCORE), str(rated), "--map", str(out / "blind_map.json"), "--out", str(summary)])
        data = json.loads(summary.read_text())
        assert data["frame_results"], "no frame results"
        chroma = [r for r in data["frame_results"] if r["probe"] == "chroma_withdrawal"][0]
        assert chroma["tier"] == "FLEXIBLE", chroma

        # Near-centered frame should not force a balance probe if mass is sufficiently centered.
        src2 = d / "center.png"
        img = np.full((240,360,3), 40, np.uint8)
        cv2.rectangle(img,(140,50),(219,189),(180,180,180),-1)
        cv2.circle(img,(180,120),28,(220,220,220),-1)
        cv2.imwrite(str(src2),img)
        out2 = d / "center_run"
        run([sys.executable, str(MAKE), str(src2), "--out", str(out2), "--preset", "quick"])
        metrics = json.loads((out2 / "probe_metrics.json").read_text())
        rec = [r for r in metrics["records"] if r["probe"] == "balance_recenter"]
        assert rec and rec[0]["status"] in {"NON_DIAGNOSTIC", "TOO_WEAK"}, rec

        # Multi-frame merge: aliases must stay unique and set summary must be produced.
        src3 = d / "frame2.png"
        make_synthetic(src3, False)
        out3 = d / "run2"
        run([sys.executable, str(MAKE), str(src3), "--out", str(out3), "--preset", "curve", "--frame-id", "frame-002"])
        mapping2 = json.loads((out3 / "blind_map.json").read_text())
        assert not set(mapping).intersection(mapping2), "blind alias collision across frames"
        rows2 = []
        with (out3 / "ratings_blind.csv").open(newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                probe = mapping2[r["alias"]]["probe"]
                level = mapping2[r["alias"]]["dose_level"]
                # Make quiet-zone response intentionally different to exercise cross-frame spread.
                if probe == "quiet_zone_contamination":
                    score = 4
                elif probe == "tonal_compression":
                    score = {"light": 3, "medium": 2, "strong": 1}[level]
                else:
                    score = 3
                r["survival_score"] = str(score)
                rows2.append(r)
        rated2 = out3 / "ratings_filled.csv"
        with rated2.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=rows2[0].keys())
            w.writeheader(); w.writerows(rows2)
        combined = d / "combined.json"
        run([sys.executable, str(SCORE), str(rated), str(rated2), "--map", str(out / "blind_map.json"), str(out3 / "blind_map.json"), "--out", str(combined)])
        c = json.loads(combined.read_text())
        assert any(x["frames"] == 2 for x in c["set_summary"]), c["set_summary"]

        # Flat image: must degrade gracefully, not invent a balance diagnosis or crash.
        flat = d / "flat.png"
        cv2.imwrite(str(flat), np.full((120, 160, 3), 64, np.uint8))
        flat_out = d / "flat_run"
        run([sys.executable, str(MAKE), str(flat), "--out", str(flat_out), "--preset", "quick", "--frame-id", "flat"])
        flat_metrics = json.loads((flat_out / "probe_metrics.json").read_text())
        bal = [r for r in flat_metrics["records"] if r["probe"] == "balance_recenter"]
        assert bal and bal[0]["status"] == "NON_DIAGNOSTIC", bal
        assert any(r.get("status") == "TOO_WEAK" for r in flat_metrics["records"]), flat_metrics["records"]

        # Very small image: fail clearly instead of emitting unstable numbers.
        tiny = d / "tiny.png"
        cv2.imwrite(str(tiny), np.full((24, 24, 3), 80, np.uint8))
        tiny_out = d / "tiny_run"
        proc = subprocess.run([sys.executable, str(MAKE), str(tiny), "--out", str(tiny_out), "--preset", "quick"], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        assert proc.returncode != 0 and "too small" in proc.stdout.lower(), proc.stdout

    print("TESTS PASS")


if __name__ == "__main__":
    main()
