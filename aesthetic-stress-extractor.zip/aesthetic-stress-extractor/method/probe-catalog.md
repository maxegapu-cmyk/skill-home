# Probe Catalog

## Purpose

A probe is a controlled intervention designed to test one dependency. It is not a label for the original image.

## Isolation rule

A valid probe changes one intended pressure while preserving subject identity, scene meaning, and broad geometry as far as practical. If the probe adds a semantic object, changes facial identity, rewrites wardrobe, or changes narrative action, exclude it.

## Core operators

### Chroma Withdrawal

Mechanism: scale chroma toward neutral while preserving luminance.

Useful for distinguishing palette dependence from luminance/composition dependence.

Common confound: skin or colored emissive elements may lose material meaning at extreme strength. Stop before the content reads as a different material or story cue.

### Tonal Compression

Mechanism: compress luminance deviations around the mean.

Useful for testing reliance on dark/light hierarchy.

Common confound: extreme compression can erase subject visibility rather than aesthetics. Dose-limit before basic legibility collapses.

### Balance Recenter

Mechanism: estimate a visual-mass centroid from edge energy and luminance contrast, then translate the full frame partway toward geometric center using reflected borders.

Useful only when the baseline has measurable off-center mass.

Common confound: visible border repetition after translation. Reject if reflected padding becomes salient.

### Quiet-Zone Contamination

Mechanism: detect low-gradient / low-local-variance pixels, create a soft mask, inject low-amplitude band-limited texture there.

Useful for testing whether emptiness or low-information areas carry the composition.

Common confound: injected texture starts to look like rain, stars, fabric, dust, text, or another semantic material. Keep it non-semantic.

### Detail Homogenization

Mechanism: use a smooth activity mask to mildly blur already-busy zones while slightly increasing neutral micro-variation in quiet zones.

Useful for testing whether detail distribution matters more than total detail.

Common confound: face destruction or obvious artificial noise. Reject if identity or material category changes.

### Attention Challenge

Mechanism: place a small soft contrast pulse in a low-competition area chosen from the activity map.

Useful for testing whether the original image depends on one privileged attention chain.

Common confound: pulse resembles a lamp, moon, UI marker, sign, or object. Keep it abstract and soft.

## Optional operators

### Crop Pressure

Inward crop of 2–12%, resized back to baseline dimensions. Use to test breathing room and edge tension.

### Hue Rotation

Shift hue angle while preserving luminance approximately. Use only after Chroma Withdrawal demonstrates color dependence.

### Edge Weakening

Blend toward a mild bilateral/gaussian-softened version to reduce boundary authority without flattening global tone.

## Invalid comparison examples

- comparing a semantic object insertion against a non-semantic tone change;
- forcing a probe beyond its safe range just to match another probe's pixel delta;
- assuming a small changed area means a weak perceptual intervention.

Use the defined safe range inside each operator. Compare survival responses as a heuristic sensitivity experiment, and keep mechanical image delta as a separate diagnostic.
