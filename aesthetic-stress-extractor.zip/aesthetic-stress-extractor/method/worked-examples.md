# Worked Examples

These are synthetic reasoning examples, not claims about any named film or filmmaker.

## Example A — Off-center night interior

Baseline: one adult figure sits near frame-left in a dark room. Frame-right is a large plain wall. A small distant doorway is brighter than the face.

Observed stress response:

- Chroma Withdrawal: mostly survives.
- Tonal Compression: breaks strongly.
- Balance Recenter: breaks strongly.
- Quiet-Zone Contamination: breaks strongly.
- Detail Homogenization: moderate loss.
- Attention Challenge: strong loss if the new pulse appears on the empty wall.

Minimum Survival Set:

1. Keep dominant mass clearly left of center; no centered portrait rebalance.
2. Keep frame-right broadly quiet and low-information.
3. Keep the face below the brightest distant anchor; do not equalize the scene into midtones.
4. Avoid new competing hotspots on the quiet side.

Safe-to-Vary:

- exact hue family,
- mild grain amount,
- small material-detail changes.

## Example B — Strongly colored but structurally robust frame

Baseline: saturated red environment with a central figure and strong silhouette.

Stress result:

- Chroma Withdrawal: surprisingly small loss.
- Tonal Compression: high loss.
- Edge Weakening: high loss.
- other probes: moderate.

Lesson: strong visible color was not the main load-bearing condition. The silhouette/tonal separation was.

## Example C — Multi-frame split response

Six frames are tested.

Three dialogue interiors are highly sensitive to Quiet-Zone Contamination and Attention Challenge.

Three exterior action frames are flexible on those probes but highly sensitive to Tonal Compression.

Correct result:

> Two response families exist. Do not compress them into one middle-strength aesthetic profile.

Incorrect result:

> The work has medium sensitivity to both quiet space and tonal hierarchy.
