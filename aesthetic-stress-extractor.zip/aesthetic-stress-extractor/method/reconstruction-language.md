# Reconstruction Language

## Principle

Translate fragility into visible obligations, not probe jargon.

## Translation examples

### If Balance Recenter is critical

Weak:

> Preserve P3.

Useful:

> Keep the dominant figure and visual mass clearly left of center; do not rebalance the image into a centered portrait.

### If Quiet-Zone Contamination is critical

Useful:

> Preserve the broad low-information area on frame-right. Do not fill it with furniture, signage, texture, particles, secondary figures, or decorative light.

### If Tonal Compression is critical

Useful:

> Keep a strong separation between the dark environment and the limited brighter anchors. Do not lift the whole frame into evenly readable midtones.

### If Attention Challenge is critical

Useful:

> Maintain one dominant attention path. Avoid new high-contrast hotspots outside the established focal chain.

### If Detail Homogenization is critical

Useful:

> Concentrate fine detail around the subject and let peripheral regions fall to simpler, lower-frequency structure. Do not sharpen every surface equally.

### If Chroma Withdrawal is flexible

Useful:

> Exact hue matching is optional; preserve the spatial and tonal relationships first.

## Minimum Survival Set format

Use 2–5 bullets, ordered by fragility.

Each bullet contains:

- observable condition,
- forbidden failure state.

## Generator-facing brief

Keep it compact. A recommended structure:

```text
[NEW CONTENT]

Aesthetic obligations:
1. ...
2. ...
3. ...

Flexible:
- ...
- ...

Do not introduce competing focal events or fill protected quiet regions unless requested.
```

Do not include dose values, blind aliases, fragility formulas, score tables, or analysis procedure in the generator-facing prompt.
