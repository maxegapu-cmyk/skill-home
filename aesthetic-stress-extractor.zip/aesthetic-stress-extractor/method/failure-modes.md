# Failure Modes and Repairs

## F1 — False universal dose

Symptom: a localized attention pulse is declared “weak” only because it changes few pixels, or a global desaturation is declared “strong” only because it changes many.

Cause: global pixel distance was mistaken for perceptual intervention strength.

Repair: use operator-normalized light/medium/strong settings, keep mechanical delta as an audit field, and mark cross-probe ranking as an experimental sensitivity index rather than a physical scale.

## F2 — Semantic contamination

Symptom: Attention Challenge adds what looks like a lamp, moon, UI marker, or sign.

Cause: probe changed story content.

Repair: lower strength, move location, soften shape, or discard as confounded.

## F3 — Single-frame overclaim

Symptom: result says “this film always…” after one screenshot.

Repair: relabel as frame-level fragility only.

## F4 — Palette bait

Symptom: analysis assumes color is essential because the frame is strongly colored.

Repair: run Chroma Withdrawal. If the aesthetic survives, color is visually prominent but not necessarily load-bearing.

## F5 — Composition bait

Symptom: analysis assumes off-center framing is essential because the subject is off-center.

Repair: Balance Recenter must actually produce a large aesthetic loss before promoting that condition.

## F6 — Prompt inflation

Symptom: final prompt contains every observed property.

Repair: keep only the Minimum Survival Set plus user-requested content. Move low-fragility properties to Safe-to-Vary.

## F7 — Judge beauty bias

Symptom: a variant scores badly simply because it is uglier, even though the same aesthetic organization survives.

Repair: remind the judge to score aesthetic survival, not beauty preference.

## F8 — Tool authority inflation

Symptom: measured edge/SSIM/color deltas are treated as proof of aesthetic importance.

Repair: mechanical dose and aesthetic loss remain separate variables.

## F9 — Heterogeneous set

Symptom: different frames have opposite sensitivity orders.

Repair: report multiple response families. Do not manufacture one universal average.

## F10 — Low-resolution detail false positive

Symptom: Detail Homogenization looks destructive because the source was already compressed or tiny.

Repair: mark the detail probe unresolved and rely on other valid probes.
