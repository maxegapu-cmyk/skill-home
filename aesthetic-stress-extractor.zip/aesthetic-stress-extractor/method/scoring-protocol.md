# Blind Scoring Protocol

## Why blind scoring

If a judge knows “this is the color probe,” they may unconsciously search for color-related damage. The first score should therefore use blind aliases such as A07, B02, C11.

## Rating question

Show the baseline separately, then each blind variant.

Ask only:

> How much of the baseline's distinctive aesthetic experience survives in this variant?

Do not ask “is this prettier?” or “is it technically correct?”

## Scale

- 4 — strong survival
- 3 — mostly survives
- 2 — uncertain / mixed
- 1 — mostly broken
- 0 — clearly broken

## Confound flag

Set `confounded=yes` when the variant changes something outside the intended visual pressure, for example:

- face or body identity breaks,
- scene meaning changes,
- a non-semantic pulse looks like a real lamp/sign/object,
- border padding becomes visible,
- a probe makes text illegible when text itself is central content,
- basic subject visibility collapses.

Confounded rows are excluded from fragility ranking.

## Multi-judge handling

If two or more judges are available, keep individual scores first. Do not discuss before first scoring.

Report:

- median survival per variant,
- score range,
- high-disagreement variants.

A one-point difference is normal. A spread of three or four points means the probe is not a stable basis for a strong claim.

## Three-dose curve logic

At light, medium, and strong mechanical doses, aesthetic loss should usually be non-decreasing. If strong disturbance appears less damaging than light disturbance, inspect for:

- blind-order noise,
- a non-monotonic aesthetic effect,
- probe artifacts,
- judge inconsistency.

Do not force a clean curve when the data are messy.

## Confidence

High confidence requires:

- at least two valid dose levels for the critical probe,
- monotonic or near-monotonic loss,
- no major confound,
- reasonable judge agreement.

Single-dose Quick Sweep findings are provisional by design.
