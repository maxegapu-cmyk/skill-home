---
name: zhuangbi-portrait
description: Activate only when the user explicitly invokes $zhuangbi-portrait or clearly asks for 装逼写真、排面写真、有位置感、不靠炫富符号的权力写真、看起来本来就属于这里的人像。 Do not take over generic beauty portraits, ordinary lifestyle portraits, identity replacement, e-commerce try-on, image-to-prompt, batch portrait production, or broad ancient/fantasy portrait requests. Build the selected photograph through one memorable rumor, exactly two believable access passes, a delayed reaction to an off-frame interruption, deliberate visual silence, camera politics, facial distinction, and lived material traces.
---

# 装逼写真 Skill

版本：`1.2.2`

它只解决一个窄而明确的问题：让一个明确成年的人物在照片里显得**有位置、有权限、有故事，但不急着证明自己**。它不靠豪车、钻石、香槟、黑金大厅堆身份，而是让观众相信：这个人本来就属于这里。

## 门牌：什么时候才进入

只有满足以下任一条件时进入：

- 用户明确调用 `$zhuangbi-portrait`。
- 用户明确说“装逼写真”“排面写真”“有位置感”“有权力但不炫富”“像真正有决定权的人”。
- 用户给出的核心问题是：照片看起来租来的、用力过猛、像影楼、像短视频炫富模板，要求重做。

以下任务不主动接管：普通美女写真、清新生活照、电商试穿、身份替换、批量套系、以图反推提示词、纯古风或纯幻想写真、通用摄影问题。用户没有明确点名本 Skill 时，把这些任务留给其他工具。

进入前先读取 [cards/door-sign.md](cards/door-sign.md)。

## 核心方法：传闻、通行证、迟到反应、留白

每张照片只解决四件事：

1. **传闻**：旁观者看完会用哪一句话谈论这个人。
2. **通行证**：画面用哪两项事实证明她能够进入、使用或影响这个场面。
3. **迟到反应**：画外发生了一件小事，眼神先到，身体、手和衣料慢半拍。
4. **留白**：至少有一块区域不解释、不堆东西，让人物不显得急于证明自己。

这四项比“高级、电影感、女王、富贵”等形容词优先。任何元素不能服务这四项，就删掉。

## 使用顺序

1. 读取 [cards/rumor.md](cards/rumor.md)，写出唯一传闻。
2. 读取 [cards/access-passes.md](cards/access-passes.md)，选两张通行证，不超过两张。
3. 读取 [cards/interruption.md](cards/interruption.md)，设计被打断后的迟到反应。
4. 读取 [cards/camera-politics.md](cards/camera-politics.md)，决定镜头与人物谁更有主动权。
5. 人脸、美貌或成年女性气质是重点时，读取 [cards/face-distinction.md](cards/face-distinction.md)。
6. 服装、皮肤、头发、道具或空间容易显假时，读取 [cards/material-traces.md](cards/material-traces.md)。
7. 容易变成炫富模板、影楼或短视频硬照时，读取 [cards/anti-flex.md](cards/anti-flex.md)。
8. 使用授权参考图时，读取 [cards/authorized-remix.md](cards/authorized-remix.md)。
9. 交付前读取 [cards/delivery-shape.md](cards/delivery-shape.md) 和 [cards/red-team.md](cards/red-team.md)。
10. 人物年龄、授权或内容边界不清时，读取 [cards/boundaries.md](cards/boundaries.md)。

只读取本次需要的卡片。不要把全部卡片机械拼进提示词。

## 硬性纪律

- 人物必须明确成年；默认使用虚构成年人。
- 一张图只留下一个值得传播的传闻。
- 通行证固定为两张：一张承担身份，一张补可信度。第三张开始通常就是堆料。
- 人物不能正等摄影师口令。必须存在一个画外触发和一处迟到反应。
- 至少保留一块视觉安静区，不能每个角落都在喊“贵”。
- 可读品牌、价格标签、车标、证件正文和屏幕文字默认不出现。
- 美貌明确，但脸不能被磨成没有年龄、没有骨相、没有偏好的通用模板。
- 衣服必须回应动作和重力；空间必须有使用痕迹；光必须能找到来源。
- 用户明确给出的年龄、人物、服装、地点、画幅、机位、光线和禁止项必须兑现。
- 用户要求直接生成图片时，内部完成设计后调用可用图像能力，不公开内部工作笔记。

## 默认交付

用户没有限定格式时，返回：

- `画面传闻`：一句。
- `可复制描述`：一个完整、连续、同一时刻的提示词。
- `删减清单`：只列本场景最容易毁掉排面的具体东西。

用户说“只要提示词”时，只返回后两项。用户说“直接出图”时，直接调用图像能力。

## 最小输入也能工作

例如：

```text
使用 $zhuangbi-portrait：30岁成年东亚女性，像很有决定权的老板，停车楼顶，9:16，不要豪车和炫富感。
```

信息不足时，自动补齐传闻、两张通行证、迟到反应、镜头关系、现实光源和材质反应。只有成年性、真人授权或任务对象无法判断时才追问。
