# 装逼写真 Skill

`zhuangbi-portrait` 用于制作“有位置、但不急着证明”的成人写真提示词与授权参考图改造方案。

它的四个决定依次是：一句可传播的传闻、两张可信通行证、一次被打断后的迟到反应、一块故意不解释的留白。照片因此靠关系和行为成立，不靠名牌清单成立。

版本：`1.2.2`

## 调用边界

本 Skill 只在用户明确调用 `$zhuangbi-portrait`，或明确要求“装逼写真、排面写真、有位置感、不炫富的权力感”时启用。它不会自动接管普通美女写真、电商试穿、身份替换、批量套系、以图反推或纯古风幻想任务。

## 安装

把整个 `zhuangbi-portrait` 文件夹放入宿主的 Skills 目录。

调用示例：

```text
使用 $zhuangbi-portrait：
28岁成年东亚女性，闭馆后的展厅，像真正有决定权的策展人，4:5，不要影楼感。
```

```text
使用 $zhuangbi-portrait 直接出图：
古风月夜，明确成年东亚女性，旧宅临水亭，名门感，似笑非笑，服装完整得体。
```

## 文件

```text
SKILL.md
agents/openai.yaml
cards/
  door-sign.md
  rumor.md
  access-passes.md
  interruption.md
  camera-politics.md
  face-distinction.md
  material-traces.md
  anti-flex.md
  authorized-remix.md
  delivery-shape.md
  red-team.md
  boundaries.md
examples/three-scenes.md
tests/cases.md
tests/scorecard.md
VERSION
MANIFEST.sha256
```
