# Model Adaptation｜跨模型适配

> 快照核对日期：2026-09-20。平台功能变化很快，模型名、参数范围、按钮位置以最新官方文档为准。

本课程先教通用视觉原则，再做平台适配。不要把平台参数当成普遍规律。

## ChatGPT / GPT Image
当前 OpenAI 官方图像提示指南强调：先说明需要什么图，再明确主体、构图、风格和约束；编辑时明确“什么改变、什么保持”，并分步调整。当前官方 API 文档列出 GPT Image 2.5 系列，包括偏速度的 Flare 与偏质量的 Sunburst。

**课程映射：**
- 使用自然语言完整说明视觉 brief；
- 编辑任务优先写保持项/修改项；
- 多图时明确每张图的职责和空间关系；
- 不需要为了“像提示词”而强行关键词化。

## Midjourney
当前官方文档将 Text Prompt、Image Prompt、Style Reference 等控制分开；Prompt Basics 仍建议文本简洁、具体。Image Prompt 会影响内容/构图/颜色，Style Reference 更偏整体视觉风格。

**课程映射：**
- 内容/构图参考和风格参考分职责；
- 文本重点写最终想看到什么；
- Style Reference 已很强时，少堆冲突风格词；
- 参数范围和版本差异必须临时查官方文档。

## Adobe Firefly / Photoshop Generative
Adobe 当前将 Composition Reference 与 Style Reference 分成独立控制；Composition 更关注结构、轮廓与深度，Style Reference 更关注外观与视觉审美，并提供强度控制。

**课程映射：**
- 先区分“我要借构图”还是“我要借风格”；
- 商业任务先锁构图、产品结构和留白，再强化风格；
- Photoshop 局部生成时把选区范围也视为编辑约束的一部分。

## Google Gemini / Nano Banana
Google 当前官方文档将 Nano Banana 作为 Gemini 原生图像生成能力；截至本快照，Nano Banana 2（Gemini 3.1 Flash Image）是官方推荐的通用图像模型之一，并支持多参考输入与连续编辑等工作流。

**课程映射：**
- 用自然语言说明目标、主体、环境、构图、光线和约束；
- 多参考时仍执行职责分离；
- 连续编辑时保留“本轮只改什么”的记录。

## Stable Diffusion / 节点工作流
除文本外，还可能涉及 seed、CFG、采样器、ControlNet、LoRA、IP-Adapter 等控制。初学者先理解这些工具分别控制“身份、结构、姿态、风格、随机性”中的哪一层，不先背参数。

**课程映射：**
- 先用本课程的视觉 brief 定义目标；
- 再选择能解决目标问题的控制模块；
- 参数调优采用单变量实验，不一次同时改五个数值。

## 不变原则
平台变化后仍应保留：
**任务目标 → 主体与空间 → 成像 → 光色材质 → 风格 → 参考职责 → 诊断 → 小步迭代**。
