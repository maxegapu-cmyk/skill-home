# Public Sources｜公开资料来源

> 核对日期：2026-09-20。此 Skill 为独立课程设计，只吸收公开资料中可验证的通用原则，不复制任何私有方法。

## OpenAI
- Creating images with ChatGPT: https://openai.com/academy/image-generation/
- Image prompting guide: https://developers.openai.com/api/docs/guides/image-prompting
- Image generation guide: https://developers.openai.com/api/docs/guides/image-generation

**吸收的公开原则：**提示可以短而清楚；说明用途、主体、构图、风格和约束；编辑时区分“改变”和“保持”；分步迭代；多图时说明各图关系。

## Midjourney
- Prompt Basics: https://docs.midjourney.com/hc/en-us/articles/32023408776205-Prompt-Basics
- Image Prompts: https://docs.midjourney.com/hc/en-us/articles/32040250122381-Image-Prompts
- Style Reference: https://docs.midjourney.com/hc/en-us/articles/32180011136653-Style-Reference

**吸收的公开原则：**短而具体的文本；Image Prompt 可影响内容/构图/颜色；Style Reference 负责视觉风格；不同参考类型承担不同职责。

## Adobe Firefly / Photoshop
- Composition reference: https://helpx.adobe.com/firefly/web/work-with-images/generate-images/match-image-composition-to-reference-image.html
- Style reference: https://helpx.adobe.com/firefly/web/work-with-images/generate-images/set-styles-for-image-generation.html
- Reference image for generative fill: https://helpx.adobe.com/photoshop/desktop/create-open-import-images/create-images/use-reference-images-for-consistent-results.html

**吸收的公开原则：**把构图参考与风格参考拆开；构图关注结构、轮廓和深度；风格关注外观、颜色、纹理、灯光倾向；局部编辑时明确区域和参考对象。

## Google Gemini
- Nano Banana image generation: https://ai.google.dev/gemini-api/docs/image-generation
- Gemini models: https://ai.google.dev/gemini-api/docs/models

**吸收的公开原则：**原生多模态图像生成/编辑、自然语言连续迭代、多参考输入；模型选择与能力应按当前官方文档核对。

## Hugging Face
- Diffusion Course: https://huggingface.co/learn/diffusion-course/

**吸收的公开课程组织思路：**理论概念配合 hands-on 实验，再通过项目巩固；高级技术单独分层，不在零基础阶段一次灌入。
