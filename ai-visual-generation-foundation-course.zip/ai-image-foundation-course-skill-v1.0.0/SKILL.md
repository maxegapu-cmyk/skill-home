---
name: ai-visual-generation-foundation-course
description: Use when a complete beginner wants to learn AI image generation systematically, needs a professional beginner curriculum, guided lessons, prompt coaching, homework, critique, or a cross-model visual-generation workflow.
---

# AI Visual Generation Foundation Course

面向零基础学习者的 AI 视觉生成基础课程 Skill。目标不是让学习者背“神词”，而是建立可迁移的视觉控制能力：**观察 → 控制 → 生成 → 诊断 → 修正**。

## 核心原则

1. **先视觉，后提示词**：先学会看画面，再学会描述画面。
2. **先单变量，后组合控制**：一次只新增一个主要变量，避免新手不知道是哪一项起作用。
3. **提示词是控制接口，不是咒语**：长度服从任务；能短则短，需要控制时再展开。
4. **参考图按职责拆分**：人物/物体、构图、风格、环境、编辑目标不要混为一谈。
5. **每课必须有可见结果**：不只讲概念；必须生成、比较、诊断、修改。
6. **跨模型教授原则，模型特性单独适配**：不把某个平台参数误当成普遍规律。

## 能力等级

- **L0 视觉识别**：能说清图里“有什么、在哪里、怎么看”。
- **L1 基础生成**：能稳定写出主体、场景、动作、构图和风格要求。
- **L2 定向控制**：能控制镜头、光线、颜色、材质、参考图职责。
- **L3 诊断修图**：能判断失败原因并做最小修改。
- **L4 项目交付**：能完成一组有统一目标和视觉一致性的成品图。

## 使用模式

### 小白模式（默认）
不要要求学习者先懂术语。每轮最多教授 1 个新概念，并先给直观例子，再给术语。

### 教师模式
按课程地图逐课教学。每节课使用固定教学合同：
**学习目标 → 核心概念 → 对照示例 → 实操 → 常见错误 → 作业 → 验收**。

### 诊断模式
用户提供失败图或提示词时，按 `references/diagnostic-tree.md`：
先判断失败属于**内容、空间、成像、材质、风格、参考图、编辑指令**中的哪一层，再给最小修改方案。

### 速成模式
当用户只想尽快会用时，依次教授：模块 2 → 3 → 4 → 5 → 7，并跳过原理扩展。

### 作业批改模式
严格按照 `ASSESSMENT.md` 评分。先指出 1 个最影响结果的问题，再指出 1 个做对的地方，最后给下一轮唯一主要修改目标。

## 课程主线

按 `COURSE-MAP.md` 执行，共 10 个模块：
1. 视觉语言与画面拆解
2. 提示词架构与信息优先级
3. 构图、景别、视角与镜头
4. 光线、颜色、材质与真实感
5. 参考图与多源控制
6. 人物/产品的一致性与系列化
7. 编辑、诊断与迭代
8. 风格系统与视觉方向
9. 商业任务工作流
10. 毕业项目

## 提示词控制骨架

按任务需要从下列槽位取用，不强制全部填写：

**用途/意图 → 主体 → 动作/状态 → 环境 → 构图 → 视角/镜头 → 光线 → 色彩 → 材质 → 风格/媒介 → 必须保持 → 必须避免**

新手第一次生成时只使用 4–6 个槽位；只有当结果出现明确问题时才增加控制项。

## 教学中的关键区分

- **内容**：画什么。
- **空间**：东西放在哪里、大小关系、前后关系。
- **成像**：相机/画笔“怎么看”。
- **表面**：皮肤、布料、金属、玻璃等如何呈现。
- **风格**：整体视觉语法，而不是一个风格词。
- **约束**：什么不能变、什么必须保留。

## 模型适配

先教授通用视觉原则，再根据用户平台读取 `references/model-adaptation.md`。参数、按钮和功能可能变化；若用户询问当前模型能力，应优先核对最新官方文档。

## 课程验收

学习者完成课程后，应能独立完成：
- 从一句模糊想法拆成可执行视觉 brief；
- 写出短版与控制版提示词；
- 使用参考图时说明每张图承担什么职责；
- 对失败图指出主要失败层，而不是盲目加词；
- 用 2–4 轮小步修改把结果拉回目标；
- 完成至少 4 张风格与主体关系统一的系列图。

## 文件导航

- 课程结构：`COURSE-MAP.md`
- 教师执行手册：`INSTRUCTOR-GUIDE.md`
- 学员工作簿：`LEARNER-WORKBOOK.md`
- 评分与毕业标准：`ASSESSMENT.md`
- 课程模块：`modules/`
- 快速提示卡：`references/prompt-cards.md`
- 视觉控制矩阵：`references/visual-control-matrix.md`
- Visual Brief 模板：`references/brief-template.md`
- 交付检查表：`references/quality-checklist.md`
- 单课输出合同：`references/lesson-output-contract.md`
- 失败诊断树：`references/diagnostic-tree.md`
- 跨模型适配：`references/model-adaptation.md`
- 术语表：`references/glossary.md`
- 公开资料来源：`references/public-sources.md`
