import json,time,sys
import build_tables as b
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg';OUT=b.ROOT/'acceptance'
key=sys.argv[1] if len(sys.argv)>1 else 'B1'
rid=json.loads((OUT/f'{key}.json').read_text())['record_id_list'][0]
def batch():
 args=[x for f in ['批次号','状态','处理阶段','处理说明','校验结果','租客应收合计','房东承担合计','报告'] for x in ['--field-id',f]]
 r=b.call('+record-list','--table-id','计费批次','--filter-json',json.dumps({'logic':'and','conditions':[['标题','==','验收A-'+key]]},ensure_ascii=False),'--format','json',*args)
 return dict(zip(r['fields'],r['data'][0]))
status=batch();print('BEFORE',status,flush=True)
assert status['校验结果']=='通过',status
b.call('+record-batch-update','--table-id','计费批次','--json',json.dumps({'record_id_list':[rid],'patch':{'状态':'生成中'}},ensure_ascii=False))
for i in range(20):
 time.sleep(2);status=batch()
 if status['状态']!=['生成中']:break
print('AFTER',status,flush=True)
fees=b.call('+record-list','--table-id','费用明细','--format','json','--field-id','唯一键','--field-id','本行金额','--field-id','批次号','--field-id','承担方','--field-id','期间起')
print('FEES',fees,flush=True)
(OUT/f'{key}-round-{int(time.time())}.json').write_text(json.dumps({'batch':status,'fees':fees},ensure_ascii=False,indent=2))
