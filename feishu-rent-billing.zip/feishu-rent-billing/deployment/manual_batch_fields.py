import json
from build_tables import ROOT,call
original=json.loads((ROOT/'formula-schema.json').read_text())
def formula(name,expr): return dict(name=name,type='formula',expression=expr)
active='OR(CurrentValue.[状态]="生成中",CurrentValue.[状态]="待继续")'
plan={
'计费批次':[
 dict(name='处理阶段',type='select',multiple=False,options=[{'name':x} for x in ['水电','租约','收尾','完成']],default_value=['水电']),
 dict(name='处理说明',type='text'),
],
'抄表记录':[
 formula('待计费顺序','IF(AND([记录状态]="有效",[计费状态]="未计费"),[抄表记录].COUNTIF(AND(CurrentValue.[记录状态]="有效",CurrentValue.[计费状态]="未计费",CurrentValue.[序号值]<=[序号值])),0)')
],
'租约':[
 dict(name='最近处理批次',type='text'),
 formula('租约序号值','VALUE(SUBSTITUTE([租约编号],"Z",""))'),
 *[formula('当前'+name,f'[计费批次].FILTER({active}).[{source}].FIRST()') for name,source in [('批次号','批次号'),('批次类型','批次类型'),('批次月份','所属月份'),('批次月末','月末'),('截止序号','截止抄表序号')]],
 formula('当前批次待处理','AND(NOT(ISBLANK([当前批次号])),[最近处理批次]!=[当前批次号],IF([当前批次类型]="交接结算",AND([退租结算状态]="待出账",[退租抄表序号]<=[当前截止序号]),AND(OR([当前批次类型]="月底结算",[当前批次类型]="公摊补充"),[归档]="在用",[入住日期]<=[当前批次月末],OR(ISBLANK([退租日期]),[退租日期]>[当前批次月份]))))'),
 formula('待处理顺序','IF([当前批次待处理],[租约].COUNTIF(AND(CurrentValue.[当前批次待处理],CurrentValue.[租约序号值]<=[租约序号值])),0)')
],
'费用明细':[
 formula('承担方批次合计','[费用明细].FILTER(AND(CurrentValue.[批次号]=[批次号],CurrentValue.[租约编号]=[租约编号],CurrentValue.[承担方类型]="租客")).[本行金额].SUM()'),
 formula('分人合计行','IF(AND([承担方类型]="租客",[报告行]!="",[唯一键]=[费用明细].FILTER(AND(CurrentValue.[批次号]=[批次号],CurrentValue.[租约编号]=[租约编号],CurrentValue.[承担方类型]="租客",CurrentValue.[报告行]!="")).[唯一键].FIRST()),CONCATENATE("- 【",[楼层],"·",[承担方],"】应付：",TEXT([承担方批次合计],"0.00")," 元"),"")')
]}
if __name__=='__main__':
 for table,fs in plan.items():
  snap=call('+table-get','--table-id',table)
  known={x['name']:x for x in snap['fields']}
  if table=='计费批次':
   state=known['状态']; obj={k:v for k,v in state.items() if k in ['name','type','multiple','options','default_value','description']}
   if not any(x['name']=='待继续' for x in obj['options']):
    obj['options'].append({'name':'待继续'})
    call('+field-update','--table-id',table,'--field-id',state['id'],'--json',json.dumps(obj,ensure_ascii=False),'--yes')
  for f in fs:
   if f['name'] not in known:
    call('+field-create','--table-id',table,'--json',json.dumps(f,ensure_ascii=False),'--i-have-read-guide')
    print('CREATED',table,f['name'],flush=True)
  (ROOT/f'table-{table}.json').write_text(json.dumps(call('+table-get','--table-id',table),ensure_ascii=False,indent=2))
 # Formula updates preserve the existing business checks while allowing resumption.
 base={f['name']:f['expression'] for f in original['计费批次']}
 check=base['校验结果'].replace('[状态]!="草稿"','AND([状态]!="草稿",[状态]!="待继续")').replace('CurrentValue.[状态]!="草稿"','AND(CurrentValue.[状态]!="草稿",CurrentValue.[批次号]!=[批次号])')
 # Exclude the current batch in the monthly duplicate check on resume.
 check=check.replace('CurrentValue.AND([状态]!="草稿",[状态]!="待继续")','AND(CurrentValue.[状态]!="草稿",CurrentValue.[批次号]!=[批次号])')
 check=f'IF([计费批次].COUNTIF(AND({active},CurrentValue.[批次号]!=[批次号]))>0,"另一个批次尚未完成，请先完成该批次",{check})'
 updates=[formula('校验结果',check),formula('分人合计','ARRAYJOIN([费用明细].FILTER(AND(CurrentValue.[批次号]=[批次号],CurrentValue.[分人合计行]!="")).[分人合计行],CHAR(10))'),formula('报告','IF(OR([状态]="已生成",[状态]="已发送"),'+base['报告']+',CONCATENATE("报告尚未生成。",CHAR(10),[处理说明]))')]
 for f in updates:
  call('+field-update','--table-id','计费批次','--field-id',f['name'],'--json',json.dumps(f,ensure_ascii=False),'--yes','--i-have-read-guide')
  print('UPDATED',f['name'],flush=True)
 (ROOT/'manual-batch-fields.json').write_text(json.dumps({'create':plan,'update':updates},ensure_ascii=False,indent=2))
 (ROOT/'table-计费批次.json').write_text(json.dumps(call('+table-get','--table-id','计费批次'),ensure_ascii=False,indent=2))
