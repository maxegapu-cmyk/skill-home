import json,time
from decimal import Decimal
import build_tables as b
from acceptance_data import create
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg';OUT=b.ROOT/'acceptance'
def patch(t,ids,p):return b.call('+record-batch-update','--table-id',t,'--json',json.dumps({'record_id_list':ids,'patch':p},ensure_ascii=False))
def query(t,fields,conditions=[]):
 r=b.call('+record-list','--table-id',t,'--format','json','--filter-json',json.dumps({'logic':'and','conditions':conditions},ensure_ascii=False),*[x for f in fields for x in ['--field-id',f]])
 assert not r['has_more']
 return [(rid,dict(zip(r['fields'],row))) for rid,row in zip(r['record_id_list'],r['data'])]
def batch(key):return query('计费批次',['批次号','状态','处理阶段','校验结果','报告','租客应收合计','房东承担合计'],[['标题','==','验收A-'+key]])[0]
def run(key):
 for round in range(12):
  rid,row=batch(key)
  if row['状态']==['已生成']:break
  if row['校验结果']!='通过':
   time.sleep(3);rid,row=batch(key)
  assert row['校验结果']=='通过',(key,row)
  print('RUN',key,round+1,row['处理阶段'],flush=True)
  patch('计费批次',[rid],{'状态':'生成中'})
  for i in range(30):
   time.sleep(2);rid,row=batch(key)
   if row['状态']!=['生成中']:break
  assert row['状态']!=['生成中'],('stuck',key,row)
 else:raise AssertionError(('too many rounds',key))
 time.sleep(3)
 rid,row=batch(key)
 fees=query('费用明细',['唯一键','本行金额','承担方类型','费用类型','报告行'],[['批次号','==',row['批次号']]])
 result={'batch':row,'fees':fees}
 (OUT/f'{key}-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print('DONE',key,[(f['唯一键'],f['本行金额'],f['承担方类型']) for _,f in fees],flush=True)
 return result
if __name__=='__main__':
 # Preserve the second failed water test, then rerun those two fees.
 if not (OUT/'water-reset2.json').exists():
  old=query('费用明细',['唯一键'],[['批次号','==','P1'],['费用类型','intersects',['空置水电']]])
  for rid,f in old:patch('费用明细',[rid],{'唯一键':'失败样本2|'+f['唯一键'],'批次号':'失败样本2'})
  readings=json.loads((OUT/'readings-A.json').read_text())['record_id_list']
  patch('抄表记录',[readings[1]],{'计费状态':'未计费','计费批次号':None})
  patch('计费批次',['reczz28Ia8rQgS5g'],{'处理阶段':'水电','状态':'待继续'})
  (OUT/'water-reset2.json').write_text(json.dumps(old,ensure_ascii=False))
 result=run('B1')
 assert Decimal(result['batch']['租客应收合计'])==Decimal('776.35'),result
 assert Decimal(result['batch']['房东承担合计'])==0,result
 expected={'B2':('42','23.90'),'B3':('1976.84','0'),'B4':('15.66','2.66')}
 for key,kind,cut in [('B2','交接结算',3),('B3','月底结算',4),('B4','公摊补充',None)]:
  if key=='B4' and not (OUT/'public-A.json').exists():
   create('公摊账单',[{'所属月份':'2026-08-01','账期开始':'2026-08-01','账期结束':'2026-09-02','公摊合计':18.32,'状态':'已确认'}],'public-A')
   time.sleep(5)
  if not (OUT/f'{key}.json').exists():
   create('计费批次',[{'标题':'验收A-'+key,'批次类型':kind,'截止抄表序号':cut,'所属月份':'2026-08-01' if key!='B2' else None,'状态':'草稿','处理阶段':'水电'}],key)
   time.sleep(5)
  result=run(key)
  assert Decimal(result['batch']['租客应收合计'])==Decimal(expected[key][0]),result
  assert Decimal(result['batch']['房东承担合计'])==Decimal(expected[key][1]),result
 print('A_B1_B4_PASS',flush=True)
