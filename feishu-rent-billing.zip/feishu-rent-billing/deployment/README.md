# 正式部署配置

唯一业务规则：../references/billing-rules.md，v1.0.2。
当前实现：release/ 中六张表的字段与七个工作流（含 W1R）导出；文档 data-model.md、formulas.md、automation-setup.md 已同步。

本目录根下 build_*、fix_*、prepare_* 是部署历史与迁移记录，不是可以重复运行的安装入口。尤其旧按钮测试脚本会覆盖后续修复，不得直接重跑。修改前先读取正式配置并保存备份，再做定向更新。

改规则须同步：规则文件 → 表结构/公式/工作流 → 核算器 → 算例；通过核对后再升级规则版本。CHG-001 改为先退租再入住，金额算法不变。

验收证据在 acceptance/；上线状态见 release/status.json；删除核对见 cleanup-result.json。

CHG-001 备份、专项验收及发布证据见 chg-001/；历史验收记录保留。当前交接登记以新版说明为准。
