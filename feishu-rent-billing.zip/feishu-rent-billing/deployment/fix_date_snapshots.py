import json
from build_tables import ROOT,call
from manual_batch_fields import formula
for table,fs in [('抄表记录',[formula('上次日期文本','IF(ISBLANK([上次日期]),"",TEXT([上次日期],"YYYY-MM-DD"))')]),('费用明细',[{'name':'期间起文本','type':'text'},{'name':'所属月份文本','type':'text'}])]:
 snap=call('+table-get','--table-id',table);known={f['name'] for f in snap['fields']}
 for f in fs:
  if f['name'] not in known:call('+field-create','--table-id',table,'--json',json.dumps(f,ensure_ascii=False),'--i-have-read-guide')
for name,source in [('期间起','期间起文本'),('所属月份','所属月份文本')]:
 f=formula(name,f'IF(ISBLANK([{source}]),"",TODATE([{source}]))')
 call('+field-update','--table-id','费用明细','--field-id',name,'--json',json.dumps(f,ensure_ascii=False),'--yes','--i-have-read-guide')
for t in ['抄表记录','费用明细']:
 (ROOT/f'table-{t}.json').write_text(json.dumps(call('+table-get','--table-id',t),ensure_ascii=False,indent=2))
