import json
from build_tables import ROOT,call
from manual_batch_fields import formula
fields=['抄表序号','水量','电量','水价','电价','公摊总额','调整前金额','调整差额']
snap=call('+table-get','--table-id','费用明细');known={f['name'] for f in snap['fields']}
for name in fields:
 f={'name':name+'快照','type':'text'}
 if f['name'] not in known:call('+field-create','--table-id','费用明细','--json',json.dumps(f,ensure_ascii=False))
 f=formula(name,f'IF(ISBLANK([{name}快照]),0,VALUE([{name}快照]))')
 call('+field-update','--table-id','费用明细','--field-id',name,'--json',json.dumps(f,ensure_ascii=False),'--yes','--i-have-read-guide')
 print(name,flush=True)
(ROOT/'table-费用明细.json').write_text(json.dumps(call('+table-get','--table-id','费用明细'),ensure_ascii=False,indent=2))
