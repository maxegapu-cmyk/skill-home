import json
from build_manual_workflows import build
from build_tables import ROOT,call
p=build()['W2A']
# Read before replacing the draft.
wid=json.loads((ROOT/'W2A-manual-created.json').read_text())['workflow_id']
call('+workflow-get','--workflow-id',wid)
call('+workflow-update','--workflow-id',wid,'--json',json.dumps({'title':p['title'],'steps':p['steps']},ensure_ascii=False))
import build_tables as b
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg'
s=json.dumps(p,ensure_ascii=False)
for path in (ROOT/'acceptance').glob('table-*.json'):
 source=json.loads((ROOT/path.name).read_text());dest=json.loads(path.read_text());df={f['name']:f['id'] for f in dest['fields']}
 for f in source['fields']:s=s.replace(f['id'],df[f['name']])
p=json.loads(s)
wid=json.loads((ROOT/'acceptance/W2A-created.json').read_text())['workflow_id']
b.call('+workflow-get','--workflow-id',wid)
b.call('+workflow-update','--workflow-id',wid,'--json',json.dumps({'title':p['title'],'steps':p['steps']},ensure_ascii=False))
b.call('+workflow-enable','--workflow-id',wid)
b.call('+workflow-disable','--workflow-id','wkfqFAr58zxIbAjr')
b.call('+record-batch-update','--table-id','计费批次','--json',json.dumps({'record_id_list':['reczz28Ia8rQgS5g'],'patch':{'标题':'验收A-B1','处理阶段':'水电'}},ensure_ascii=False))
