import json,time,copy
import build_tables as b
for token,folder,wid in [('Hcgobn2S4aaXHNs0bHBcOOFWnWc',b.ROOT,'wkfpfzEUhAAgMOYb'),('VDMMbTzxma57SIsSC3ociKkOnJg',b.ROOT/'acceptance','wkfcvSXKISr4d3fC')]:
 b.BASE=token
 t=b.call('+table-get','--table-id','费用明细');b.call('+table-get','--table-id','计费批次')
 known={f['name']:f for f in t['fields']}
 specs=[{'name':'原批次状态','type':'formula','expression':'ARRAYJOIN([计费批次].FILTER(CurrentValue.[批次号]=[批次号]).[状态],"")'}, {'name':'调整请求键','type':'formula','expression':'CONCATENATE("调整|",[唯一键],"|",TEXT([费用明细].COUNTIF(CurrentValue.[调整对象键]=[唯一键])+1,"0"))'}]
 for f in specs:
  if f['name'] not in known:
   b.call('+field-create','--table-id','费用明细','--json',json.dumps(f,ensure_ascii=False),'--i-have-read-guide');time.sleep(1.3)
 t=b.call('+table-get','--table-id','费用明细');(folder/'table-费用明细.json').write_text(json.dumps(t,ensure_ascii=False,indent=2));fs={f['name']:f['id'] for f in t['fields']}
 p=b.call('+workflow-get','--workflow-id',wid);p=p.get('workflow',p)
 nodes={n['id']:n for n in p['steps']};nodes.pop('查原批次',None)
 r=lambda name:{'value_type':'ref','value':'$.调整.'+fs[name]}
 nodes['新增调整']['next']='原批次未发送'
 for f in nodes['新增调整']['data']['field_values']:
  if f['field_name']=='唯一键':f['value']=[r('调整请求键')]
 nodes['原批次未发送']['data']['condition']={'conjunction':'or','conditions':[{'conjunction':'and','conditions':[{'left_value':r('原批次状态'),'operator':'isNotEmpty','right_value':[]},{'left_value':r('原批次状态'),'operator':'isNot','right_value':[{'value_type':'text','value':'已发送'}]}]}]}
 nodes['检查调整']['children']['links'][0]['to']='查调整请求'
 nodes['查调整请求']={'id':'查调整请求','title':'查调整请求','type':'FindRecordAction','data':{'table_name':'费用明细','field_names':['唯一键'],'should_proceed_when_no_results':True,'filter_info':{'conjunction':'and','conditions':[{'field_name':'唯一键','operator':'is','value':[r('调整请求键')]}]}},'next':'请求未登记'}
 nodes['请求未登记']={'id':'请求未登记','title':'请求未登记','type':'IfElseBranch','data':{'condition':{'conjunction':'or','conditions':[{'conjunction':'and','conditions':[{'left_value':{'value_type':'ref','value':'$.查调整请求.recordNum'},'operator':'is','right_value':[{'value_type':'number','value':0}]}]}]}},'next':None,'children':{'links':[{'kind':'if_true','to':'新增调整'},{'kind':'if_false','to':'重复不处理'}]}}
 nodes['重复不处理']={'id':'重复不处理','title':'重复不处理','type':'SetRecordAction','data':{'table_name':'费用明细','ref_info':{'step_id':'调整'},'field_values':[{'field_name':'拟调整为','value':[]}]},'next':None}
 # Switch supports nested branches in Feishu.
 for n in nodes.values():
  if n['type']=='IfElseBranch':
   condition=n['data']['condition'];links=n['children']['links'];n['type']='SwitchBranch'
   n['data']={'mode':'exclusive','no_match_action':'fail','child_branch_list':[{'name':'满足条件','condition':condition},{'name':'其他情况','condition':{'conjunction':'or','conditions':[{'conjunction':'and','conditions':[{'left_value':r('唯一键'),'operator':'isNotEmpty','right_value':[]}]}]}}]}
   n['children']['links']=[{'kind':'case','label':f'branch_{i+1}','to':v['to'],'desc':'满足条件' if i==0 else '其他情况'} for i,v in enumerate(links)]
 payload={'title':p['title'],'steps':list(nodes.values())}
 b.call('+workflow-update','--workflow-id',wid,'--json',json.dumps(payload,ensure_ascii=False));(folder/'W3-corrected.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))
 if folder!=b.ROOT:b.call('+workflow-enable','--workflow-id',wid)
 print('ADJUSTMENT_FIXED',token,flush=True)
