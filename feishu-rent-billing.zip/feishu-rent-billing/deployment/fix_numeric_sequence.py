import json,time
import build_tables as b
for token,folder,wid in [('Hcgobn2S4aaXHNs0bHBcOOFWnWc',b.ROOT,'wkfejnb0uuhOZ1En'),('VDMMbTzxma57SIsSC3ociKkOnJg',b.ROOT/'acceptance','wkfa0PiiAfPPKVig')]:
 b.BASE=token
 t=b.call('+table-get','--table-id','抄表记录')
 if not any(f['name']=='计费序号' for f in t['fields']):
  b.call('+field-create','--table-id','抄表记录','--json',json.dumps({'name':'计费序号','type':'number','style':{'type':'plain','precision':0},'description':'工作流从自动编号写入的数字序号，用于数值范围筛选；请勿手改。'},ensure_ascii=False));time.sleep(1.3)
 t=b.call('+table-get','--table-id','抄表记录');(folder/'table-抄表记录.json').write_text(json.dumps(t,ensure_ascii=False,indent=2))
 f={x['name']:x['id'] for x in t['fields']}
 r=b.call('+record-list','--table-id','抄表记录','--format','json','--field-id','序号值','--field-id','计费序号');assert not r['has_more']
 for rid,row in zip(r['record_id_list'],r['data']):
  d=dict(zip(r['fields'],row))
  if d['计费序号'] is None:
   b.call('+record-batch-update','--table-id','抄表记录','--json',json.dumps({'record_id_list':[rid],'patch':{'计费序号':int(d['序号值'])}}));time.sleep(1.3)
 p=b.call('+workflow-get','--workflow-id',wid)
 (folder/'W1-before-sequence.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
 obj=p.get('workflow',p);steps=obj['steps']
 s=json.dumps(steps,ensure_ascii=False).replace('$.登记.'+f['序号值'],'$.登记.'+f['抄表序号']+'.sequence');steps=json.loads(s)
 for n in steps:
  if n['id'].startswith('登记状态'):
   n['data']['field_values']=[x for x in n['data']['field_values'] if x['field_name']!='计费序号']+[{'field_name':'计费序号','value':[{'value_type':'ref','value':'$.登记.'+f['抄表序号']+'.sequence'}]}]
 b.call('+workflow-update','--workflow-id',wid,'--json',json.dumps({'title':obj['title'],'steps':steps},ensure_ascii=False))
 (folder/'W1-sequence.json').write_text(json.dumps({'steps':steps},ensure_ascii=False,indent=2));print('NUMERIC_SEQUENCE',token,flush=True)
