import json
import build_tables as bt
bt.BASE='KIlVbVz54aO4sKsJpkncmj7Knyc'
from build_workflows import Workflow,val,ref,group,cond
s=bt.call('+table-get','--table-id','接续验收')
f={x['name']:x['id'] for x in s['fields']}
w=Workflow('验收：自动接续至第8轮')
w.step('接续','SetRecordTrigger',{'table_name':'接续验收','field_watch_info':[{'field_name':'轮次'}],'trigger_control_list':[]},'未完成')
w.branch('未完成',group(cond(ref('接续.'+f['轮次']),'isLess',val(8,'number'))),'加一','停止')
w.set('加一','接续验收',{'轮次':ref('接续.'+f['下一轮'])},source='接续')
w.set('停止','接续验收',{'测试名':'接续完成'},source='接续')
p=w.save('continuation-test')
r=bt.call('+workflow-create','--json',json.dumps(p,ensure_ascii=False))
(bt.ROOT/'continuation-created.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(r,flush=True)
rid=bt.call('+record-batch-create','--table-id','接续验收','--json',json.dumps({'fields':['测试名','轮次'],'rows':[['待验收',0]]},ensure_ascii=False))
(bt.ROOT/'continuation-record.json').write_text(json.dumps(rid,ensure_ascii=False,indent=2))
print(rid,flush=True)
