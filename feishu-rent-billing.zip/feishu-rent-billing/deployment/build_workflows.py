import json
import uuid
from build_tables import ROOT, call

TABLES={p.stem[6:]:json.loads(p.read_text()) for p in ROOT.glob('table-*.json')}
FIELDS={t:{f['name']:f['id'] for f in s['fields']} for t,s in TABLES.items()}
OWNER='ou_808409af9ee8d608132d4478f62c7980'
def val(x,kind='text'): return {'value_type':kind,'value':{'name':x} if kind=='option' else x}
def ref(step,table=None,field=None):
    return val('$.'+step+('.'+FIELDS[table][field] if field else ''),'ref')
def values(x): return x if isinstance(x,list) else [x] if isinstance(x,dict) else [val(x)]
def cond(left,op,right=None): return {'left_value':left,'operator':op,'right_value':[] if right is None else values(right)}
def group(*cs): return {'conjunction':'or','conditions':[{'conjunction':'and','conditions':list(cs)}]}
def filtr(*cs): return {'conjunction':'and','conditions':[{'field_name':name,'operator':op,'value':[] if v is None else values(v)} for name,op,v in cs]}

class Workflow:
    def __init__(self,title): self.title=title; self.steps=[]
    def step(self,id,typ,data,next=None,links=None):
        node={'id':id,'type':typ,'title':id,'data':data,'next':next}
        if links is not None: node['children']={'links':links}
        self.steps.append(node); return id
    def set(self,id,table,patch,next=None,source=None,filter=None):
        data={'table_name':table,'field_values':[{'field_name':k,'value':values(v)} for k,v in patch.items()]}
        if source: data['ref_info']={'step_id':source}
        if filter: data['filter_info']=filter
        return self.step(id,'SetRecordAction',data,next)
    def add(self,id,table,patch,next=None): return self.step(id,'AddRecordAction',{'table_name':table,'field_values':[{'field_name':k,'value':values(v)} for k,v in patch.items()]},next)
    def branch(self,id,condition,yes,no,next=None):
        return self.step(id,'IfElseBranch',{'condition':condition},next,[{'kind':'if_true','to':yes},{'kind':'if_false','to':no}])
    def find(self,id,table,names,filter,next=None):
        return self.step(id,'FindRecordAction',{'table_name':table,'field_names':names,'should_proceed_when_no_results':True,'filter_info':filter},next)
    def loop(self,id,find,entry,next=None):
        return self.step(id,'Loop',{'loop_mode':'end','max_loop_times':500,'data':[ref(find+'.fieldRecords')]},next,[{'kind':'loop_start','to':entry}])
    def msg(self,id,text,next=None):
        return self.step(id,'LarkMessageAction',{'receiver':[val({'id':OWNER},'user')],'send_to_everyone':False,'title':[val(self.title)],'content':values(text),'btn_list':[]},next)
    def save(self,key):
        data={'client_token':str(uuid.uuid4()),'title':self.title,'steps':self.steps}
        ids=[s['id'] for s in self.steps]
        assert len(set(ids))==len(ids)
        for s in self.steps:
            assert s['next'] is None or s['next'] in ids,s
            for l in s.get('children',{}).get('links',[]): assert l['to'] in ids,l
        (ROOT/f'{key}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
        return data

def w1():
    w=Workflow('W1 抄表登记处理')
    w.step('登记','AddRecordTrigger',{'table_name':'抄表记录','watched_field_name':'登记事由','trigger_control_list':['openAPIBatchUpdate']},'按事由处理')
    events=['首次建档','月度抄表','上层入住','上层退租','上层换租','下层入住','下层退租','下层换租','换表起码']
    branches=[]; links=[]
    for i,event in enumerate(events):
        branches.append({'name':event,'condition':group(cond(ref('登记','抄表记录','登记事由'),'is',val(event,'option')))})
        links.append({'kind':'case','to':f'登记状态{i}','label':f'branch_{i+1}','desc':event})
        status='起点不计费' if event=='首次建档' else '换表不计费' if event=='换表起码' else '未计费'
        out=event.endswith(('退租','换租')); incoming=event.endswith(('入住','换租'))
        next=f'退租{i}' if out else f'入住{i}' if incoming else None
        w.set(f'登记状态{i}','抄表记录',{'计费状态':val(status,'option')},next,source='登记')
        floor=event[:2]
        if out:
            w.set(f'退租{i}','租约',{'退租日期':ref('登记','抄表记录','抄表日期'),'退租抄表序号':ref('登记','抄表记录','序号值'),'退租结算状态':val('待出账','option')},f'入住{i}' if incoming else None,filter=filtr(('楼层','is',val(floor,'option')),('退租抄表序号','isEmpty',None),('入住抄表序号','isLess',ref('登记','抄表记录','序号值'))))
        if incoming:
            w.add(f'入住{i}','租约',{'租客姓名':ref('登记','抄表记录','新租客姓名'),'联系电话':ref('登记','抄表记录','新租客电话'),'楼层':val(floor,'option'),'入住日期':ref('登记','抄表记录','抄表日期'),'入住抄表序号':ref('登记','抄表记录','序号值'),'退租结算状态':val('未退租','option'),'归档':val('在用','option')})
    w.step('按事由处理','SwitchBranch',{'mode':'exclusive','no_match_action':'fail','child_branch_list':branches},'提醒核对',links)
    w.msg('提醒核对',[val('抄表已登记。请对照照片核对读数，将核对状态改为已核对。入住或换租后，请补填租约单价；押金未填不拦截月账。首次建档时，请手动补建当前在住租约。')])
    return w.save('W1')

def w2():
    w=Workflow('W2 生成本批次费用')
    B=lambda f:ref('出账','计费批次',f)
    def skip(id,next=None): return w.set(id,'计费批次',{'状态':val('生成中','option')},next,source='出账')
    def ensure(id,patch,next=None):
        w.find(id,'费用明细',['唯一键'],filtr(('唯一键','is',patch['唯一键'])),id+'判断')
        w.branch(id+'判断',group(cond(ref(id+'.recordNum'),'is',val(0,'number'))),id+'新增',id+'跳过',next)
        w.add(id+'新增','费用明细',patch)
        skip(id+'跳过')
        return id
    def public(id,patch,actual_key,zero_key,status,total,next=None):
        w.branch(id,group(cond(status,'is',val('暂按0'))),id+'查占位',id+'查实际',next)
        either=filtr(('唯一键','is',actual_key),('唯一键','is',zero_key)); either['conjunction']='or'
        w.find(id+'查占位','费用明细',['唯一键'],either,id+'占位判断')
        w.branch(id+'占位判断',group(cond(ref(id+'查占位.recordNum'),'is',val(0,'number'))),id+'新增占位',id+'占位跳过')
        w.add(id+'新增占位','费用明细',dict(patch,唯一键=zero_key,公摊状态=val('暂按0','option'),公摊总额=val(0,'number')))
        skip(id+'占位跳过')
        w.find(id+'查实际','费用明细',['唯一键'],filtr(('唯一键','is',actual_key)),id+'实际判断')
        w.branch(id+'实际判断',group(cond(ref(id+'查实际.recordNum'),'is',val(0,'number'))),id+'新增实际',id+'实际跳过')
        w.add(id+'新增实际','费用明细',dict(patch,唯一键=actual_key,公摊状态=status,公摊总额=total))
        skip(id+'实际跳过')
    def fixed(id,T,month,key,next=None):
        patch={'唯一键':[val('固定费|'),T('租约编号'),val('|'),key], '批次号':B('批次号'),'费用类型':val('固定费','option'),'楼层':T('楼层'),'承担方类型':val('租客','option'),'承担方':T('租客姓名'),'租约编号':T('租约编号'),'所属月份':month,'入住日期':T('入住日期'),'退租日期':T('退租日期'),'月租':T('月租'),'垃圾费单价':T('垃圾费'),'管理费单价':T('管理费')}
        ensure(id,patch,next)
    def tenant_public(id,T,month,key,status,total,next=None):
        patch={'批次号':B('批次号'),'费用类型':val('公摊','option'),'楼层':T('楼层'),'承担方类型':val('租客','option'),'承担方':T('租客姓名'),'租约编号':T('租约编号'),'所属月份':month,'入住日期':T('入住日期'),'退租日期':T('退租日期')}
        public(id,patch,[val('公摊实|'),key,val('|'),T('租约编号')],[val('公摊暂0|'),key,val('|'),T('租约编号')],status,total,next)
    w.step('出账','ButtonTrigger',{'button_type':'buttonField','table_name':'计费批次'},'校验')
    w.branch('校验',group(cond(B('校验结果'),'is',val('通过'))),'开始','拦截')
    w.msg('拦截',[val('本批次未生成：'),B('校验结果')])
    w.set('开始','计费批次',{'状态':val('生成中','option')},'是否水电',source='出账')
    w.branch('是否水电',{'conjunction':'or','conditions':[{'conjunction':'and','conditions':[cond(B('批次类型'),'is',val(t,'option'))]} for t in ['交接结算','月底结算']]},'查未计费抄表','水电跳过','选择批次')
    skip('水电跳过')
    names=list(FIELDS['抄表记录'])
    w.find('查未计费抄表','抄表记录',names,filtr(('计费状态','is',val('未计费','option')),('记录状态','is',val('有效','option')),('序号值','isLessEqual',B('截止抄表序号'))),'逐段')
    w.loop('逐段','查未计费抄表','上层需计')
    R=lambda f:ref('逐段.item','抄表记录',f)
    for floor,nxt in [('上层','下层需计'),('下层','标记抄表已计')]:
        w.branch(floor+'需计',group(cond(R(floor+'需出账'),'is',val('是'))),floor+'按承担方',floor+'无用量跳过',nxt)
        skip(floor+'无用量跳过')
        w.branch(floor+'按承担方',group(cond(R('段'+floor+'在住'),'is',val(True,'boolean'))),floor+'租客查重',floor+'房东查重')
        for payer in ['租客','房东']:
            patch={'唯一键':R(floor+'费用键'),'批次号':B('批次号'),'费用类型':val('水电' if payer=='租客' else '空置水电','option'),'楼层':val(floor,'option'),'承担方类型':val(payer,'option'),'承担方':R(floor+'承担方'),'租约编号':R('段'+floor+'租约'),'抄表序号':R('序号值'),'期间起':R('上次日期'),'期间止':R('抄表日期'),'水量':R(floor+'水量'),'电量':R(floor+'电量'),'水价':R(floor+'水价用'),'电价':R(floor+'电价用')}
            ensure(floor+payer+'查重',patch)
    w.set('标记抄表已计','抄表记录',{'计费状态':val('已计费','option'),'计费批次号':B('批次号')},filter=filtr(('序号值','is',R('序号值'))))
    cases=[]; links=[]
    for i,(kind,to) in enumerate([('月底结算或公摊补充','月结查租约'),('交接结算','交接查租约'),('调整入账','仅调整')]):
        check=group(cond(B('批次类型'),'containsAny',[val('月底结算','option'),val('公摊补充','option')])) if i==0 else group(cond(B('批次类型'),'is',val(kind,'option')))
        cases.append({'name':kind,'condition':check})
        links.append({'kind':'case','label':f'branch_{i+1}','to':to,'desc':kind})
    w.step('选择批次','SwitchBranch',{'mode':'exclusive','no_match_action':'fail','child_branch_list':cases},'收入调整',links)
    skip('仅调整')
    for prefix in ['月结']:
        w.find(prefix+'查租约','租约',list(FIELDS['租约']),filtr(('归档','is',val('在用','option')),('入住日期','isLessEqual',B('月末'))),prefix+'逐租约')
        w.loop(prefix+'逐租约',prefix+'查租约',prefix+'当月在住',prefix+'上层房东')
        T=lambda f,p=prefix:ref(p+'逐租约.item','租约',f)
        conditions={'conjunction':'or','conditions':[{'conjunction':'and','conditions':[cond(T('退租日期'),'isEmpty')]},{'conjunction':'and','conditions':[cond(T('退租日期'),'isGreater',B('所属月份'))]}]}
        w.branch(prefix+'当月在住',conditions,prefix+'是否固定',prefix+'已退跳过')
        skip(prefix+'已退跳过')
        w.branch(prefix+'是否固定',group(cond(B('批次类型'),'is',val('月底结算','option'))),prefix+'固定',prefix+'补充不收固定',prefix+'公摊')
        skip(prefix+'补充不收固定')
        fixed(prefix+'固定',T,B('所属月份'),B('月份键'))
        tenant_public(prefix+'公摊',T,B('所属月份'),B('月份键'),B('出账公摊状态'),B('公摊总额'),prefix+'本月退租')
        if prefix=='月结':
            w.branch(prefix+'本月退租',group(cond(B('批次类型'),'is',val('月底结算','option')),cond(T('退租月份键'),'is',B('月份键'))),prefix+'结清退租',prefix+'未退跳过')
            w.set(prefix+'结清退租','租约',{'退租结算状态':val('已出账','option')},filter=filtr(('租约编号','is',T('租约编号'))))
            skip(prefix+'未退跳过')
        for floor,nxt in [('上层',prefix+'下层房东'),('下层',None)]:
            patch={'批次号':B('批次号'),'费用类型':val('空置公摊','option'),'楼层':val(floor,'option'),'承担方类型':val('房东','option'),'承担方':val('房东'),'所属月份':B('所属月份')}
            public(prefix+floor+'房东',patch,[val('公摊实|'),B('月份键'),val('|'+floor+'|房东')],[val('公摊暂0|'),B('月份键'),val('|'+floor+'|房东')],B('出账公摊状态'),B('公摊总额'),nxt)
    w.find('交接查租约','租约',list(FIELDS['租约']),filtr(('退租结算状态','is',val('待出账','option')),('退租抄表序号','isLessEqual',B('截止抄表序号'))),'交接逐租约')
    w.loop('交接逐租约','交接查租约','交接有天数')
    T=lambda f:ref('交接逐租约.item','租约',f)
    w.branch('交接有天数',group(cond(T('退租月在住天数'),'isGreater',val(0,'number'))),'交接固定','交接零天跳过','交接标记已出')
    skip('交接零天跳过')
    fixed('交接固定',T,T('退租计费月'),T('退租月份键'),'交接公摊')
    tenant_public('交接公摊',T,T('退租计费月'),T('退租月份键'),T('退租出账公摊状态'),T('退租月公摊总额'))
    w.set('交接标记已出','租约',{'退租结算状态':val('已出账','option')},filter=filtr(('租约编号','is',T('租约编号'))))
    w.set('收入调整','费用明细',{'批次号':B('批次号')},'完成',filter=filtr(('费用类型','is',val('调整','option')),('批次号','isEmpty',None)))
    w.set('完成','计费批次',{'状态':val('已生成','option'),'生成时间':val('now','date')},'通知完成',source='出账')
    w.msg('通知完成',[val('批次 '),B('批次号'),val(' 已生成。请打开该批次核对报告，再复制发给租客。发完后把状态改为已发送。')])
    return w.save('W2')

def w3():
    w=Workflow('W3 登记调整')
    R=lambda f:ref('调整','费用明细',f)
    w.step('调整','ButtonTrigger',{'button_type':'buttonField','table_name':'费用明细'},'检查调整')
    w.branch('检查调整',group(cond(R('拟调整为'),'isNotEmpty'),cond(R('调整原因'),'isNotEmpty'),cond(R('待调差额'),'isNot',val(0,'number'))),'新增调整','提示填写')
    w.msg('提示填写','请先填写拟调整金额和调整原因。金额没有变化时，不新增调整。')
    patch={'唯一键':[val('调整|'),R('唯一键'),val('|'),ref('调整.time')],'费用类型':val('调整','option'),'调整对象键':R('唯一键'),'调整前金额':R('有效金额'),'调整后金额':R('拟调整为'),'调整差额':R('待调差额'),'调整原因':R('调整原因'),'楼层':R('楼层'),'承担方类型':R('承担方类型'),'承担方':R('承担方'),'租约编号':R('租约编号')}
    w.add('新增调整','费用明细',patch,'查原批次')
    w.find('查原批次','计费批次',['批次号','状态'],filtr(('批次号','is',R('批次号'))),'原批次未发送')
    w.branch('原批次未发送',group(cond(ref('查原批次.recordNum'),'isGreater',val(0,'number')),cond(ref('查原批次.firstfieldsRecord','计费批次','状态'),'isNot',val('已发送','option'))),'写入原批次','留待下次','清除输入')
    w.set('写入原批次','费用明细',{'批次号':R('批次号')},source='新增调整')
    w.msg('留待下次','调整已登记，将在下一个计费批次中入账。')
    w.set('清除输入','费用明细',{'拟调整为':[]},source='调整')
    return w.save('W3')

if __name__=='__main__':
    import sys
    key=next((x for x in sys.argv[1:] if x in ('W1','W2','W3')),'W1')
    payload={'W1':w1,'W2':w2,'W3':w3}[key]()
    print(key,'nodes',len(payload['steps']),flush=True)
    if '--create' in sys.argv:
        data=call('+workflow-create','--json',json.dumps(payload,ensure_ascii=False))
        (ROOT/f'{key}-created.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
        print(json.dumps({k:data.get(k) for k in ('workflow_id','title','status')},ensure_ascii=False),flush=True)
