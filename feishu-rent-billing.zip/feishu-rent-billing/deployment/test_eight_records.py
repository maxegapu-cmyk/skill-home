import json,time
from decimal import Decimal
from acceptance_suite import b,OUT,query,patch,batch,run,create

if not (OUT/'readings-eight.json').exists():
 rows=[{'抄表日期':f'2026-09-{i+1:02d}','登记事由':'月度抄表','总水表读数':360+2*i,'总电表读数':11560.82+10*i,'上层水表读数':131+i,'上层电表读数':5180.5+4*i,'核对状态':'已核对','记录状态':'有效','计费状态':'未计费'} for i in range(1,9)]
 create('抄表记录',rows,'readings-eight');time.sleep(4)
ids=json.loads((OUT/'readings-eight.json').read_text())['record_id_list']
if not (OUT/'B5.json').exists():
 create('计费批次',[{'标题':'验收A-B5','批次类型':'交接结算','截止抄表序号':12,'状态':'草稿','处理阶段':'水电'}],'B5');time.sleep(4)
if not (OUT/'block-results.json').exists():
 results=[]
 for changes,label in [({'上层水表读数':None},'missing'),({'上层水表读数':139,'总水表读数':1},'rollback')]:
  patch('抄表记录',[ids[-1]],changes);time.sleep(4)
  state=query('抄表记录',['序号值','校验结果'],[['计费序号','==',12]])
  _,br=batch('B5');assert br['校验结果']!='通过',(label,state,br)
  results.append({'case':label,'reading':state,'batch':br['校验结果']});print('BLOCK',label,br['校验结果'],flush=True)
 patch('抄表记录',[ids[-1]],{'总水表读数':376,'上层水表读数':139});time.sleep(4)
 (OUT/'block-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
if not (OUT/'numeric-reset.json').exists():
 old=query('费用明细',['唯一键'],[['批次号','==','P5']])
 for rid,f in old:
  patch('费用明细',[rid],{'唯一键':'失败样本3|'+f['唯一键'],'批次号':'失败样本3'});time.sleep(1.3)
 patch('抄表记录',ids,{'计费状态':'未计费','计费批次号':None})
 patch('计费批次',[batch('B5')[0]],{'状态':'待继续','处理阶段':'水电'});time.sleep(5)
 (OUT/'numeric-reset.json').write_text(json.dumps(old,ensure_ascii=False))
if not (OUT/'five-plus-three.json').exists():
 results=[]
 for expected in (5,8):
  rid,row=batch('B5');assert row['校验结果']=='通过',row
  patch('计费批次',[rid],{'状态':'生成中'})
  for _ in range(45):
   time.sleep(2);rid,row=batch('B5')
   if row['状态']!=['生成中']:break
  time.sleep(4);rid,row=batch('B5')
  read=query('抄表记录',['序号值','计费状态'],[['计费序号','>=',5],['计费序号','<=',12],['计费状态','intersects',['已计费']]])
  assert len(read)==expected,(expected,read,row)
  assert row['报告'].startswith('报告尚未生成。'),row
  results.append({'done':len(read),'batch':row});print('BATCH_LIMIT',expected,row['状态'],row['处理阶段'],flush=True)
 (OUT/'five-plus-three.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
result=run('B5');assert len(result['fees'])==16,result
assert Decimal(result['batch']['租客应收合计'])==Decimal('146.40'),result
print('EIGHT_PASS',flush=True)
