# CHG-001 当前交接（2026-10-03）

当前规则 v1.0.2：取消新增换租，先退租再入住。正式 W1、W1R 与表单已更新，另五个工作流不变。表单现有 16 项输入。

专项 T01–T09、A/B/C/D 计费回归和历史换租兼容已通过。A 调整沿用既有飞书验收及本次本地回归；T09 为模拟实况名单核对。证据见 chg-001/acceptance/，配置比对见 chg-001/formal-final/。正式业务表仍为空，需录入真实资料后使用。

以下保留切换前记录。

# 2026-10-03 完工记录

正式Base Hcgobn2S4aaXHNs0bHBcOOFWnWc，规则v1.0.1，手动继续，每轮最多5条。

- 用户明确同意删除；已删除旧抄表问卷vewv7hOw8T及空查询页vewMXCM0lr。六张表字段ID集合未改变。证据cleanup-result.json。
- 保留正式抄表登记入口vew5rIyLap，13项输入；两个网页按钮已绑定。
- A的B1–B4，5+3分批B5，实际网页换租及交接B6均通过。
- 已发送原账299→300的+1调整保持独立；B7只入账此1元。证据acceptance/B7-result.json。重复点击未重复新增。
- 本地A/B/C/D通过；B/C/D未逐一做真实飞书验收。照片识别未配置。
- 正式W2C启用发现旧字段引用，已从验收W2C映射到正式字段修复。最终以release/W2C.json为准。
- 正式六流程与验收停用状态见release/status.json。不要按早期STATUS.md或历史脚本恢复。
- data-model.md、formulas.md、automation-setup.md、test-cases.md已同步；房东操作见../使用说明.md。
- 正式无真实租约/账目。下一步需录入实际租约价格和起始抄表。

CLI使用所有者身份可启停；外部网页帐号可改字段和按钮但不可启停。无需再次切换帐号。
历史build/fix/prepare脚本不是可重复安装入口。严禁用旧prepare_button_tests.py覆盖修复。
