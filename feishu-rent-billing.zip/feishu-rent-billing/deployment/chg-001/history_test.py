import json,time,copy
from collections import defaultdict
from decimal import Decimal
import regression as reg
import scenarios as s
import live_test as t
import billing_test as b
from rent_calc import Ledger
label='T08-HISTORY';s.reset(label)
ws=[w for w in t.call('+workflow-list')['items'] if w['title'].split()[0] in ('W1','W1R')]
for w in ws:
 t.call('+workflow-disable','--workflow-id',w['workflow_id'])
 time.sleep(3)
data=copy.deepcopy(next(c['data'] for c in reg.DATA['cases'] if c['name'].startswith('D')))
lg=Ledger(data);mapping={};ten={x['id']:x for x in data['tenancies']}
for r in data['readings']:
 p={'抄表日期':r['date'],'登记事由':r['event'],'核对状态':'已核对','记录状态':'有效',
    '登记规则版本':'v1.0.1','计费状态':'起点不计费' if r['event']=='首次建档' else '换表不计费' if r['event']=='换表起码' else '未计费'}
 for a,c in zip(['total_water','up_water','total_elec','up_elec'],['总水表读数','上层水表读数','总电表读数','上层电表读数']):p[c]=r.get(a)
 if r.get('tenant'):p['新租客姓名']=ten[r['tenant']]['name']
 rid=t.create('抄表记录',p,label+'-reading-'+str(r['seq']))
 for i in range(12):
  row=dict(t.query('抄表记录',['序号值'])).get(rid)
  if row:break
  time.sleep(2)
 mapping[r['seq']]=row['序号值']
 t.update('抄表记录',rid,{'计费序号':row['序号值']})
for tid,x in lg.ten.items():
 p={'租客姓名':x['name'],'楼层':x['floor'],'入住日期':x['move_in'],
    '入住抄表序号':mapping.get(x.get('in_seq',1)), '归档':'在用',
    '退租结算状态':'待出账' if x.get('move_out') else '未退租'}
 if x.get('move_out'):p.update(退租日期=x['move_out'],退租抄表序号=mapping[x['out_seq']])
 p.update(dict(zip(['月租','垃圾费','管理费','水价','电价'],[x.get(k,0) for k in ['rent','garbage','mgmt','water_price','elec_price']])))
 t.create('租约',p,label+'-tenant-'+tid)
for bill in data['public_bills']:
 t.create('公摊账单',{'所属月份':bill['month']+'-01','公摊合计':bill['amount'],'状态':bill['status']},label+'-public')
time.sleep(5)
for batch in data['batches']:
 p={'标题':label+' '+batch['id'],'批次类型':batch['type'],'状态':'草稿','处理阶段':'水电','截止抄表序号':mapping[batch['cutoff']]}
 if batch.get('month'):p['所属月份']=batch['month']+'-01'
 bid=t.create('计费批次',p,label+'-'+batch['id']);time.sleep(3)
 result=b.run_batch(bid,label+'-'+batch['id']+'-result')
 expected=defaultdict(Decimal)
 for r in lg.run_batch(batch):expected[(r.floor,r.payer,r.kind)]+=r.amount
 actual=reg.grouped(result['fees'])
 assert {k:v for k,v in actual.items() if v}=={k:v for k,v in expected.items() if v},(actual,expected)
before={n:t.query(n,f) for n,f in [('抄表记录',['序号值','登记事由']),('租约',['入住抄表序号','退租抄表序号']),('费用明细',['唯一键','本行金额'])]}
for w in ws:
 t.call('+workflow-enable','--workflow-id',w['workflow_id'])
 time.sleep(3)
time.sleep(3)
after={n:t.query(n,f) for n,f in [('抄表记录',['序号值','登记事由']),('租约',['入住抄表序号','退租抄表序号']),('费用明细',['唯一键','本行金额'])]}
assert before==after
# Any repeat attempt on a generated batch remains blocked by the original validation.
assert all(r['状态']==['已生成'] and '批次不是草稿' in r['校验结果'] for _,r in t.query('计费批次',['状态','校验结果']))
t.save('T08-history-preserved',{'before':before,'after':after,'passed':True})
print('T08_HISTORY_PASS',flush=True)
