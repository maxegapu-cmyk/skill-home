import backup,json
from pathlib import Path
backup.BASE=json.loads((backup.ROOT/'test-base.json').read_text())['data']['base']['base_token']
out=backup.ROOT/'test-before';out.mkdir(exist_ok=True)
for cmd,name in [('+table-list','tables'),('+workflow-list','workflows')]:
 r=backup.call(cmd);(out/(name+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2));print(name,r)
for t in json.loads((out/'tables.json').read_text())['tables']:
 r=backup.call('+table-get','--table-id',t['id']);(out/('table-'+t['name']+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))
for w in json.loads((out/'workflows.json').read_text())['items']:
 r=backup.call('+workflow-get','--workflow-id',w['workflow_id']);(out/(w['title'].split()[0]+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2))
 if w['status']=='enabled': backup.call('+workflow-disable','--workflow-id',w['workflow_id'])
print('TEST_SNAPSHOT_COMPLETE')
