# CHG-001 验收金额核对

下列数据读取自独立飞书验收表实际结果。失败样本和诊断过程保留在同目录。

| 场景 | 租客应收 | 房东承担 | 费用行数 |
|---|---:|---:|---:|
| [T01-billing-result](T01-billing-result.json) | 6562 | 0 | 13 |
| [T02-billing-result](T02-billing-result.json) | 6249 | 11.02 | 14 |
| [T03-billing-result](T03-billing-result.json) | 6552 | 8.02 | 14 |
| [T04-oct-result](T04-oct-result.json) | 6250 | 0 | 8 |
| [T04-Nov-billing-result](T04-Nov-billing-result.json) | 6402 | 8.02 | 10 |
| [REG-A-B1-result](REG-A-B1-result.json) | 776.35 | 0 | 4 |
| [REG-A-B2-result](REG-A-B2-result.json) | 42 | 23.9 | 2 |
| [REG-A-B3-result](REG-A-B3-result.json) | 1976.84 | 0 | 8 |
| [REG-A-B4-result](REG-A-B4-result.json) | 15.66 | 2.66 | 5 |
| [REG-B-B1-result](REG-B-B1-result.json) | 1200 | 57.86 | 6 |
| [REG-C-B1-result](REG-C-B1-result.json) | 1160 | 0 | 5 |
| [REG-D-B1-result](REG-D-B1-result.json) | 553.34 | 11.95 | 4 |
| [REG-D-B2-result](REG-D-B2-result.json) | 589.53 | 23.89 | 8 |

专项拦截和恢复见 `guards-result.txt`、`case-T07-insert.json`、`T09-roster-recovered.json`。历史兼容以 `T08-history-preserved.json` 为准。全量汇总通过以 `release-approved.json` 为准。

原 A 的调整流程使用既有飞书验收及本次本地自检；正式 W3 定义不变。T09 采用模拟实际在住名单，不能代替房东每月底核对。
