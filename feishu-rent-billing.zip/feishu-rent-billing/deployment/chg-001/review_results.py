"""从实际输出核对发布条件；缺证据或金额不符时不产生放行记录。"""
import json
from pathlib import Path
from decimal import Decimal
ROOT=Path(__file__).resolve().parent
A=ROOT/'acceptance'
def read(n):return json.loads((A/(n+'.json')).read_text())
def grouped(n):
 r=read(n);g={}
 keys=[f['唯一键'] for _,f in r['fees']]
 assert len(keys)==len(set(keys)),('duplicate fees',n)
 for _,f in r['fees']:
  k=(f['承担方'],f['费用类型'][0]);g[k]=g.get(k,Decimal(0))+Decimal(str(f['本行金额']))
 for who,field in [('租客','租客应收合计'),('房东','房东承担合计')]:
  amount=sum((Decimal(str(f['本行金额'])) for _,f in r['fees'] if f['承担方类型']==[who]),Decimal(0))
  assert amount==Decimal(str(r['batch'][field])),(n,who,amount,r['batch'][field])
 return g
for label,expected in {
 'T01':{('A','固定费'):1400,('B','固定费'):1700,('A','公摊'):14,('B','公摊'):17},
 'T02':{('A','固定费'):1400,('B','固定费'):1400,('房东','空置水电'):'8.02',('房东','空置公摊'):3},
 'T03':{('B','固定费'):1700,('房东','空置水电'):'8.02'},
 'T04-Nov':{('B','固定费'):3100,('房东','空置水电'):'8.02'}
}.items():
 g=grouped(label+'-billing-result')
 for k,v in expected.items():assert g[k]==Decimal(str(v)),(label,k,g)
assert grouped('T04-oct-result')[('A','固定费')]==3000
assert read('T06-duplicate-result')['交接处理状态']==['需更正']
retry=read('T06-retry');assert retry['reading']['交接处理状态']==['已完成'] and len(retry['tenancies'])==3
assert read('case-T07-insert')['passed']
assert read('T09-roster-live')['missing']==['B']
assert read('T09-roster-recovered')['passed']
for letter,batches in [('A',['B1','B2','B3','B4']),('B',['B1']),('C',['B1']),('D',['B1','B2'])]:
 for bid in batches:
  name='REG-'+letter+'-'+bid
  assert read(name+'-comparison')['pass'];grouped(name+'-result')
assert read('T08-history-preserved')['passed']
assert 'SELFTEST PASS' in (A/'local-selftest.txt').read_text()
summary={
 'change':'CHG-001','passed':True,'target_version':'v1.0.2',
 'live_base':'PMZUbwDzCa6N5JsbcYxcX94Gn9d',
 'live_checks':['T01','T02','T03','T04','T05','T06','T07','T08','T09（模拟实况名单）'],
 'regression':'飞书 A 的 B1–B4、B/C/D 计费；本地 A/B/C/D 含 A 的调整；正式 W3 保持原定义并沿用既有调整验收',
 'remaining':'正式配置及表单定向更新、读回核对、版本升级和文件同步'
}
(A/'release-approved.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('CHG001_RELEASE_CHECKS_PASS')
