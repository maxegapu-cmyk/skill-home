import json,time
from datetime import datetime
from zoneinfo import ZoneInfo
import backup
R=backup.ROOT
assert json.loads((R/'formal-final/scope-verification.json').read_text())['passed']
assert (R/'formal-final/form-proof.png').exists()
backup.BASE='Hcgobn2S4aaXHNs0bHBcOOFWnWc'
tables=backup.call('+table-list')
assert all(t['records_count']==0 for t in tables['tables'] if t['name']!='系统参数')
p=backup.call('+record-list','--table-id','系统参数','--format','json')
assert len(p['record_id_list'])==1
backup.call('+record-batch-update','--table-id','系统参数','--json',json.dumps({'record_id_list':p['record_id_list'],'patch':{'规则版本':'v1.0.2'}},ensure_ascii=False))
time.sleep(3)
now=backup.call('+record-list','--table-id','系统参数','--format','json')
a=dict(zip(p['fields'],p['data'][0]));b=dict(zip(now['fields'],now['data'][0]))
assert b.pop('规则版本')=='v1.0.2';a.pop('规则版本');assert a==b
(R/'formal-final/records-系统参数.json').write_text(json.dumps(now,ensure_ascii=False,indent=2))
(R/'formal-final/activation.json').write_text(json.dumps({'version':'v1.0.2','effective_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'base':backup.BASE,'business_records':0},ensure_ascii=False,indent=2))
print('VERSION_ACTIVATED',flush=True)
backup.BASE='PMZUbwDzCa6N5JsbcYxcX94Gn9d'
for w in backup.call('+workflow-list')['items']:
 if w['status']=='enabled':
  backup.call('+workflow-disable','--workflow-id',w['workflow_id']);time.sleep(3)
ws=backup.call('+workflow-list')
assert all(w['status']=='disabled' for w in ws['items'])
(R/'acceptance/test-workflows-final.json').write_text(json.dumps(ws,ensure_ascii=False,indent=2))
print('TEST_WORKFLOWS_DISABLED')
