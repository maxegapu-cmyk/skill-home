#!/usr/bin/env python3
"""上下两层出租屋 收租计费 参考核算器（与飞书多维表格方案同一套规则）。

用途：用同一份抄表/租约/公摊数据，独立算出每个计费批次“本次新增”的费用明细和纯文字报告，
用来核对飞书里的公式和工作流是否算对。只用 Python 标准库。

用法：
  python3 rent_calc.py ledger.json            # 按批次输出报告
  python3 rent_calc.py ledger.json --json     # 输出全部费用行（JSON）
  python3 rent_calc.py --selftest             # 运行内置算例自检

规则摘要（详见 references/billing-rules.md）：
- 水电按相邻两次抄表的区间结算，区间归属看“区间起点那条抄表记录的本次后状态”。
- 两层都在住：上层=上层表差，下层=总表差-上层表差；缺上层读数则拦截，不估算。
- 仅一层在住且上层表两端读数不全：在住层按总表计，另一层 0。
- 空置层：有抄表依据的实际水电按空置单价记“房东承担”。两层都空置且无法分户时，合计记在下层侧。
- 固定费（房租/垃圾费/管理费）每租约每月一行，月中入住/退租按 在住天数/当月天数 折算；入住日计、退租日不计。
- 公摊按月：上层份额=ROUND(总额/2,2)，下层份额=总额-上层份额；租客按在住天数累计取整折算，房东空置份额=层份额-该层租客份额之和。
- 公摊账单未确认时只生成“暂按0”占位行；确认后由月底/公摊补充批次生成“实收”行。“确认为0”与“暂按0”分开记。
- 每行有唯一键，重复运行同一批次不会新增任何费用。
"""
from __future__ import annotations

import calendar
import json
import sys
from dataclasses import dataclass, field, asdict
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP

UP, DOWN = "上层", "下层"
LANDLORD = "房东"
D0 = Decimal("0")


def money(x) -> Decimal:
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def qty(x) -> Decimal:
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def fmt(x: Decimal) -> str:
    return f"{x:.2f}"


def fq(x: Decimal) -> str:
    """数量/单价原样显示（去掉末尾 0），不做四舍五入，避免 0.786 被显示成 0.79。"""
    s = format(Decimal(str(x)).normalize(), "f")
    return s if s not in ("", "-0") else "0"


def d(s):
    return None if s in (None, "") else date.fromisoformat(s)


def month_bounds(m: str):
    y, mo = map(int, m.split("-"))
    first = date(y, mo, 1)
    n = calendar.monthrange(y, mo)[1]
    return first, first + timedelta(days=n), n  # 月初, 下月初(不含), 当月天数


class LedgerError(Exception):
    pass


@dataclass
class Row:
    key: str
    batch: str
    kind: str          # 水电 / 固定费 / 公摊实 / 公摊暂0 / 调整
    floor: str
    payer: str         # 租客姓名 或 房东
    payer_type: str    # 租客 / 房东
    period: str
    amount: Decimal
    detail: str
    meta: dict = field(default_factory=dict)


class Ledger:
    def __init__(self, data: dict):
        vp = data.get("vacant_price", {})
        self.vw = Decimal(str(vp.get("water", 4.09)))
        self.ve = Decimal(str(vp.get("elec", 0.786)))
        self.ten = {t["id"]: t for t in data.get("tenancies", [])}
        self.readings = sorted(data.get("readings", []), key=lambda r: r["seq"])
        self.bills = {b["month"]: b for b in data.get("public_bills", [])}
        self.batches = data.get("batches", [])
        self.adjust = data.get("adjustments", [])
        self.rows: dict[str, Row] = {}
        self.billed: set[int] = set()
        self.done_batches: list[str] = []
        self._build_chain()

    # ---------- 抄表链与在住状态 ----------
    def _build_chain(self):
        state = {UP: None, DOWN: None}
        prev = None
        for r in self.readings:
            ev = r["event"]
            r["_prev"] = prev
            r["_start"] = dict(state) if prev else None
            if prev and d(r["date"]) < d(prev["date"]):
                raise LedgerError(f"抄表#{r['seq']} 日期早于上一条，必须按时间顺序登记")
            if ev == "首次建档":
                if prev:
                    raise LedgerError("首次建档只能是第一条")
                state = {UP: r.get("after", {}).get(UP), DOWN: r.get("after", {}).get(DOWN)}
                for fl, tid in state.items():
                    if tid and not self.ten[tid].get("move_in"):
                        raise LedgerError(f"首次建档时在住的租约 {tid} 必须填写入住日期")
            else:
                for fl in (UP, DOWN):
                    if ev in (f"{fl}退租", f"{fl}换租"):
                        tid = state[fl]
                        if not tid:
                            raise LedgerError(f"抄表#{r['seq']} {ev}，但该层当前无人在住")
                        self.ten[tid]["move_out"] = r["date"]
                        self.ten[tid]["out_seq"] = r["seq"]
                        state[fl] = None
                    if ev in (f"{fl}入住", f"{fl}换租"):
                        if state[fl]:
                            raise LedgerError(f"抄表#{r['seq']} {ev}，但该层已有在住租约，请用“换租”或先退租")
                        tid = r["tenant"]
                        t = self.ten[tid]
                        if t.get("floor") != fl:
                            raise LedgerError(f"租约 {tid} 的楼层与事由 {ev} 不一致")
                        t["move_in"] = r["date"]
                        t["in_seq"] = r["seq"]
                        state[fl] = tid
            r["_after"] = dict(state)
            prev = r

    def tname(self, tid):
        return self.ten[tid]["name"]

    # ---------- 校验单条区间 ----------
    def segment(self, r):
        p = r["_prev"]
        st = r["_start"]
        errs = []
        U, D = st[UP], st[DOWN]
        res = {"errors": errs, "U": U, "D": D}
        if r["event"] == "换表起码":
            res["zero"] = True
            return res
        for k in ("total_water", "total_elec"):
            if r.get(k) is None or p.get(k) is None:
                errs.append(f"抄表#{r['seq']} 缺 {k} 读数")
        after = r["_after"]
        need_up = (U and D) or (after[UP] and after[DOWN])
        for k in ("up_water", "up_elec"):
            if need_up and r.get(k) is None:
                errs.append(f"抄表#{r['seq']} 两层在住，必须填写上层{('水' if 'water' in k else '电')}表读数（不估算）")
            if U and D and p.get(k) is None:
                errs.append(f"抄表#{r['seq']} 的上一条（#{p['seq']}）缺上层{('水' if 'water' in k else '电')}表读数，两层在住区间无法分户")
        if errs:
            return res
        for util, tk, uk in (("水", "total_water", "up_water"), ("电", "total_elec", "up_elec")):
            tot = qty(Decimal(str(r[tk])) - Decimal(str(p[tk])))
            if tot < 0:
                errs.append(f"抄表#{r['seq']} 总{util}表读数小于上一条（{p[tk]}→{r[tk]}），疑似录错/换表/回零")
                continue
            sep = r.get(uk) is not None and p.get(uk) is not None
            if sep:
                up = qty(Decimal(str(r[uk])) - Decimal(str(p[uk])))
                if up < 0:
                    errs.append(f"抄表#{r['seq']} 上层{util}表读数小于上一条，疑似录错/换表")
                    continue
                down = tot - up
                if down < 0:
                    errs.append(f"抄表#{r['seq']} 上层{util}用量 {up} 大于总表用量 {tot}，读数矛盾")
                    continue
                how = "上层按独立表，下层=总表-上层表"
            else:
                if U and D:
                    errs.append(f"抄表#{r['seq']} 两层在住缺上层{util}表读数")
                    continue
                if U:
                    up, down, how = tot, D0, "上层表读数不全，仅上层在住：上层按总表计，下层0"
                elif D:
                    up, down, how = D0, tot, "上层表读数不全，仅下层在住：下层按总表计，上层0"
                else:
                    up, down, how = D0, tot, "两层空置且无法分户：合计记在下层侧，由房东承担"
            res[util] = {"tot": tot, UP: up, DOWN: down, "how": how}
        return res

    # ---------- 生成行 ----------
    def add(self, row: Row, created: list):
        if row.key in self.rows:
            return False
        self.rows[row.key] = row
        created.append(row)
        return True

    def utility_rows(self, r, bid, created):
        seg = self.segment(r)
        if seg["errors"]:
            raise LedgerError("；".join(seg["errors"]))
        self.billed.add(r["seq"])
        if seg.get("zero"):
            return
        p = r["_prev"]
        period = f"{p['date']}~{r['date']}"
        for fl in (UP, DOWN):
            tid = seg["U"] if fl == UP else seg["D"]
            w, e = seg["水"][fl], seg["电"][fl]
            if tid:
                t = self.ten[tid]
                wp, ep = Decimal(str(t["water_price"])), Decimal(str(t["elec_price"]))
                payer, ptype, label = t["name"], "租客", "水电"
            else:
                wp, ep = self.vw, self.ve
                payer, ptype, label = LANDLORD, "房东", "空置水电"
                if w == 0 and e == 0:
                    continue
            wa, ea = money(w * wp), money(e * ep)
            detail = f"水 {fq(w)} 吨×{fq(wp)}={fmt(wa)}；电 {fq(e)} 度×{fq(ep)}={fmt(ea)}"
            note = seg["水"]["how"] if seg["水"]["how"] == seg["电"]["how"] else f"水：{seg['水']['how']}；电：{seg['电']['how']}"
            self.add(Row(f"水电|{r['seq']}|{fl}", bid, label, fl, payer, ptype, period, wa + ea, detail,
                         {"note": note, "w": str(w), "e": str(e)}), created)

    def days_in(self, t, m):
        first, nxt, n = month_bounds(m)
        mi, mo = d(t.get("move_in")), d(t.get("move_out"))
        if not mi:
            return 0, n
        start = max(mi, first)
        end = min(mo, nxt) if mo else nxt  # 退租日不计
        return max(0, (end - start).days), n

    def fixed_row(self, tid, m, bid, created):
        t = self.ten[tid]
        days, n = self.days_in(t, m)
        if days == 0:
            return
        parts, total = [], D0
        for name, k in (("房租", "rent"), ("垃圾费", "garbage"), ("管理费", "mgmt")):
            fee = Decimal(str(t.get(k) or 0))
            a = fee if days == n else money(fee * days / n)
            total += a
            parts.append(f"{name} {fmt(a)}" if days == n else f"{name} {fq(fee)}×{days}/{n}={fmt(a)}")
        self.add(Row(f"固定费|{tid}|{m}", bid, "固定费", t["floor"], t["name"], "租客", m,
                     total, "；".join(parts), {"days": days, "n": n}), created)

    def layer_share(self, total: Decimal, fl):
        up = money(total / 2)
        return up if fl == UP else total - up

    def bill_status(self, m, bid):
        b = self.bills.get(m)
        if not b:
            return "未收到", None
        ready = b.get("confirmed_at_batch")
        order = [x["id"] for x in self.batches]
        if ready and bid in order and order.index(bid) < order.index(ready):
            return "未收到", None
        st = b.get("status", "已确认")
        return st, Decimal(str(b.get("amount", 0)))

    def tenancies_in_month(self, m, fl=None):
        out = []
        for tid, t in self.ten.items():
            if fl and t["floor"] != fl:
                continue
            days, _ = self.days_in(t, m)
            if days > 0:
                out.append(tid)
        return out

    def public_rows(self, m, tids, bid, created, with_landlord):
        st, total = self.bill_status(m, bid)
        _, _, n = month_bounds(m)
        if st in ("已确认", "确认为0"):
            if st == "确认为0":
                total = D0
            for tid in tids:
                t = self.ten[tid]
                days, _ = self.days_in(t, m)
                share = self.layer_share(total, t["floor"])
                # 同层同月多位租客：按入住先后累计取整，保证租客合计不超过层份额（不会多收一分）
                prior = sum(self.days_in(self.ten[o], m)[0] for o in self.tenancies_in_month(m, t["floor"])
                            if d(self.ten[o]["move_in"]) < d(t["move_in"]))
                a = money(share * (prior + days) / n) - money(share * prior / n)
                had_ph = f"公摊暂0|{m}|{tid}" in self.rows
                det = (f"当月公摊 {fmt(total)}，{t['floor']}50%={fmt(share)}，在住 {days}/{n} 天"
                       + ("（已确认当月公摊为0）" if st == "确认为0" else "")
                       + ("（补收：此前结算暂按0）" if had_ph else ""))
                self.add(Row(f"公摊实|{m}|{tid}", bid, "公摊", t["floor"], t["name"], "租客", m, a, det,
                             {"days": days}), created)
            if with_landlord:
                for fl in (UP, DOWN):
                    share = self.layer_share(total, fl)
                    trs = [x for x in self.rows.values() if x.kind == "公摊" and x.meta.get("month", m) == m
                           and x.key.startswith(f"公摊实|{m}|") and x.floor == fl and x.payer_type == "租客"]
                    used_days = sum(x.meta["days"] for x in trs)
                    vac = n - used_days
                    if vac < 0:
                        raise LedgerError(f"{m} {fl} 租客在住天数之和超过当月天数，租约日期重叠")
                    a = share - sum((x.amount for x in trs), D0)
                    if vac == 0 and a == 0:
                        continue
                    self.add(Row(f"公摊实|{m}|{fl}|房东", bid, "空置公摊", fl, LANDLORD, "房东", m, a,
                                 f"当月公摊 {fmt(total)}，{fl}50%={fmt(share)}，空置 {vac}/{n} 天（层份额减去该层租客份额）",
                                 {"days": vac}), created)
        else:
            for tid in tids:
                t = self.ten[tid]
                if f"公摊实|{m}|{tid}" in self.rows:
                    continue
                days, _ = self.days_in(t, m)
                self.add(Row(f"公摊暂0|{m}|{tid}", bid, "公摊", t["floor"], t["name"], "租客", m, D0,
                             f"在住 {days}/{n} 天；公摊账单未到，暂按 0 元，待补", {"days": days}), created)
            if with_landlord:
                for fl in (UP, DOWN):
                    used = sum(self.days_in(self.ten[x], m)[0] for x in self.tenancies_in_month(m, fl))
                    if n - used > 0 and f"公摊实|{m}|{fl}|房东" not in self.rows:
                        self.add(Row(f"公摊暂0|{m}|{fl}|房东", bid, "空置公摊", fl, LANDLORD, "房东", m, D0,
                                     f"空置 {n - used}/{n} 天；公摊账单未到，暂按 0 元，待补", {"days": n - used}), created)

    # ---------- 批次 ----------
    def run_batch(self, b):
        bid, typ = b["id"], b["type"]
        created: list[Row] = []
        cutoff = b.get("cutoff")
        if typ in ("月底结算", "交接结算"):
            if cutoff is None:
                raise LedgerError(f"批次 {bid} 缺截止抄表")
            todo = [r for r in self.readings if r["seq"] <= cutoff and r["_prev"] and r["seq"] not in self.billed]
            # 先整体校验，任何一段不通过则整批不生成
            errs = []
            for r in todo:
                errs += self.segment(r)["errors"]
            if errs:
                raise LedgerError(f"批次 {bid} 被拦截：" + "；".join(errs))
            for r in todo:
                self.utility_rows(r, bid, created)
        if typ == "月底结算":
            m = b["month"]
            tids = self.tenancies_in_month(m)
            for tid in tids:
                self.fixed_row(tid, m, bid, created)
            self.public_rows(m, tids, bid, created, with_landlord=True)
        elif typ == "交接结算":
            for tid, t in self.ten.items():
                if t.get("out_seq") and t["out_seq"] <= cutoff and t.get("move_out"):
                    mo = d(t["move_out"])
                    last_day = mo - timedelta(days=1)
                    if last_day < d(t["move_in"]):
                        continue
                    m = f"{last_day.year:04d}-{last_day.month:02d}"
                    self.fixed_row(tid, m, bid, created)
                    self.public_rows(m, [tid], bid, created, with_landlord=False)
        elif typ == "公摊补充":
            m = b["month"]
            st, _ = self.bill_status(m, bid)
            if st not in ("已确认", "确认为0"):
                raise LedgerError(f"批次 {bid}：{m} 公摊账单尚未确认，不能补充")
            self.public_rows(m, self.tenancies_in_month(m), bid, created, with_landlord=True)
        for a in self.adjust:
            if a.get("batch") != bid:
                continue
            orig = self.rows.get(a["key"])
            if not orig:
                raise LedgerError(f"调整引用的费用行不存在：{a['key']}")
            prior = [x for k, x in self.rows.items() if k.startswith(f"调整|{a['key']}|")]
            before = orig.amount + sum((x.amount for x in prior), D0)
            after = money(a["new_amount"])
            diff = after - before
            if diff == 0:
                continue
            self.add(Row(f"调整|{a['key']}|{len(prior) + 1}", bid, "调整", orig.floor, orig.payer, orig.payer_type,
                         orig.period, diff,
                         f"{orig.kind}（{orig.period}）由 {fmt(before)} 调整为 {fmt(after)}，差额 {fmt(diff)}；原因：{a.get('reason', '未填写')}"),
                     created)
        self.done_batches.append(bid)
        return created

    def report(self, b, created):
        lines = [f"【{b.get('title', b['id'])}】{b['type']}" + (f"｜所属月份 {b['month']}" if b.get("month") else "")]
        if not created:
            lines.append("本次没有新增费用（已计过的不会重复计）。")
            return "\n".join(lines)
        order = {"水电": 0, "空置水电": 0, "固定费": 1, "公摊": 2, "空置公摊": 2, "调整": 3}
        created = sorted(created, key=lambda x: (x.payer_type != "租客", x.floor, x.payer, order.get(x.kind, 9)))
        for x in created:
            who = f"{x.floor}·{x.payer}" if x.payer_type == "租客" else f"{x.floor}·房东承担（空置）"
            lines.append(f"- 【{who}】{x.kind} {x.period}：{x.detail}；小计 {fmt(x.amount)} 元")
        lines.append("合计：")
        payers = []
        for x in created:
            if (x.payer_type, x.payer) not in payers:
                payers.append((x.payer_type, x.payer))
        tsum = D0
        for pt, p in payers:
            s = sum((x.amount for x in created if x.payer == p and x.payer_type == pt), D0)
            if pt == "租客":
                tsum += s
            lines.append(f"- {'房东承担空置费' if pt == '房东' else p + ' 应付'}：{fmt(s)} 元")
        lines.append(f"本次租客应收合计：{fmt(tsum)} 元")
        if any(x.key.startswith("公摊暂0") for x in created):
            lines.append("注：标“暂按 0”的公摊待账单到后用“公摊补充”批次补收，不会重复收。")
        return "\n".join(lines)


def run(data: dict, as_json=False) -> str:
    lg = Ledger(data)
    out = []
    for b in lg.batches:
        created = lg.run_batch(b)
        if b.get("rerun"):
            again = lg.run_batch(b)
            assert not again, "重复运行产生了新费用"
        out.append(lg.report(b, created))
    if as_json:
        return json.dumps([{**asdict(r), "amount": fmt(r.amount)} for r in lg.rows.values()], ensure_ascii=False, indent=2)
    return "\n\n".join(out)


def selftest():
    import pathlib
    p = pathlib.Path(__file__).resolve().parent.parent / "assets" / "test-ledger.json"
    suite = json.loads(p.read_text(encoding="utf-8"))
    fails = 0
    for case in suite["cases"]:
        lg = Ledger(json.loads(json.dumps(case["data"])))
        got = {}
        for b in lg.batches:
            for r in lg.run_batch(b):
                got[r.key] = fmt(r.amount)
            if lg.run_batch(b):
                print(f"FAIL {case['name']}：批次 {b['id']} 重复运行产生了新费用")
                fails += 1
        exp = case["expected"]
        bad = {k: (v, got.get(k)) for k, v in exp.items() if got.get(k) != v}
        extra = sorted(set(got) - set(exp))
        if bad or extra:
            fails += 1
            print(f"FAIL {case['name']}", json.dumps({"不一致(期望,实际)": bad, "多出的行": extra}, ensure_ascii=False))
        else:
            print(f"PASS {case['name']}（{len(exp)} 行）")
    for case in suite["blocked_cases"]:
        try:
            lg = Ledger(json.loads(json.dumps(case["data"])))
            lg.run_batch(lg.batches[0])
            fails += 1
            print(f"FAIL 未拦截：{case['name']}")
        except LedgerError as e:
            print(f"PASS 已拦截：{case['name']} → {e}")
    print("SELFTEST", "PASS" if not fails else f"FAIL（{fails}）")
    return 1 if fails else 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        sys.exit(0)
    if args[0] == "--selftest":
        sys.exit(selftest())
    try:
        print(run(json.loads(open(args[0], encoding="utf-8").read()), as_json="--json" in args))
    except LedgerError as e:
        print(f"拦截：{e}")
        sys.exit(2)
