# feishu-rent-billing v1.0.1

上下两层出租屋的飞书多维表格收租计费技能。入口是 `SKILL.md`。

- 规则（唯一来源）：references/billing-rules.md
- 修改日志：[规则修改日志.md](规则修改日志.md)（方案、过程、验收及生效记录；草案不直接用于计费）
- 搭建：references/data-model.md → references/formulas.md → references/automation-setup.md
- 核算器：`python3 scripts/rent_calc.py --selftest`（已通过）；`python3 scripts/rent_calc.py 你的数据.json`
- 验收：references/test-cases.md

已验证：核算器的规则与算例 A/B/C 的人工手算逐行一致，重复运行不新增，缺上层读数与读数倒退会被拦截。
未验证：飞书公式与工作流未在真实多维表格中实测，需按 test-cases.md 的“飞书验收步骤”走一遍。
