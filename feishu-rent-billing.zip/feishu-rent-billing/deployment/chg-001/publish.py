"""CHG-001 定向发布；不运行历史安装脚本。"""
import json,sys,copy,time
import backup
ROOT=backup.ROOT
BASE='Hcgobn2S4aaXHNs0bHBcOOFWnWc'
backup.BASE=BASE
assert (ROOT/'acceptance'/'release-approved.json').exists(),'验收汇总未通过，禁止发布'
OUT=ROOT/'formal-final';OUT.mkdir(exist_ok=True)
def save(name,value):(OUT/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2))
def call(*args):return backup.call(*args)
def preflight():
 tables=call('+table-list');save('preflight-tables',tables)
 assert all(t['records_count']==0 for t in tables['tables'] if t['name']!='系统参数'), '正式表出现新业务记录，先补充备份及兼容核对，不能删除旧选项'
 old={w['workflow_id']:w for w in json.loads((ROOT/'backup/workflows.json').read_text())['items']}
 for w in call('+workflow-list')['items']:
  if w['workflow_id'] in old:
   current=call('+workflow-get','--workflow-id',w['workflow_id'])
   baseline=json.loads((ROOT/'backup'/(w['title'].split()[0]+'.json')).read_text())
   assert current['steps']==baseline['steps'],('正式工作流已变更',w['title'])
 save('preflight',{'passed':True,'base':BASE})

def options_and_views():
 table=call('+table-get','--table-id','抄表记录')
 fields={f['name']:f for f in table['fields']}
 assert next(t for t in call('+table-list')['tables'] if t['name']=='抄表记录')['records_count']==0
 f=copy.deepcopy(fields['登记事由']);f.pop('id',None)
 f['options']=[x for x in f['options'] if x['name'] not in ('上层换租','下层换租')]
 call('+field-update','--table-id','抄表记录','--field-id','登记事由','--json',json.dumps(f,ensure_ascii=False),'--yes')
 for name in ['新租客姓名','新租客电话','总水表读数','总电表读数']:
  time.sleep(3)
  f=copy.deepcopy(fields[name]);f.pop('id',None);f['description']=f.get('description','').replace('入住、换租','入住')
  if name in ('总水表读数','总电表读数'):f['description']='直接交接可从关联退租自动带入；其余情况必须填写实际读数'
  call('+field-update','--table-id','抄表记录','--field-id',name,'--json',json.dumps(f,ensure_ascii=False),'--yes')
 visible=json.loads((ROOT/'backup/reading-visible-fields.json').read_text())['data']['visible_fields']
 for f in ['交接意向','关联退租序号','同一时点交接','交接更正原因','交接处理状态','交接处理说明','交接完成状态','交接登记检查']:
  if f not in visible:visible.append(f)
 call('+view-set-visible-fields','--table-id','抄表记录','--view-id','vewJdQCzai',
      '--json',json.dumps({'visible_fields':visible},ensure_ascii=False))
 save('visible-fields',call('+view-get-visible-fields','--table-id','抄表记录','--view-id','vewJdQCzai'))
 for name in ['待核对','有问题']:
  time.sleep(3)
  saved=json.loads((ROOT/'backup'/('visible-'+name+'.json')).read_text())
  names=saved['visible_fields']
  for f in ['交接意向','关联退租序号','同一时点交接','交接更正原因','交接处理状态','交接处理说明','交接完成状态','交接登记检查']:
   if f not in names:names.append(f)
  call('+view-set-visible-fields','--table-id','抄表记录','--view-id',saved['view_id'],
       '--json',json.dumps({'visible_fields':names},ensure_ascii=False))


def export():
 for t in call('+table-list')['tables']:save('table-'+t['name'],call('+table-get','--table-id',t['id']))
 for w in call('+workflow-list')['items']:save(w['title'].split()[0],call('+workflow-get','--workflow-id',w['workflow_id']))
 save('workflows',call('+workflow-list'))
 print('FORMAL_EXPORTED')
if __name__=='__main__':
 {'preflight':preflight,'options':options_and_views,'export':export}[sys.argv[1]]()
