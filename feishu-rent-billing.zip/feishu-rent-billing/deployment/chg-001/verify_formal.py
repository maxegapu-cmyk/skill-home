"""比较正式导出与备份、验收配置，拒绝 CHG-001 范围外差异。"""
import json,copy
from pathlib import Path
R=Path(__file__).resolve().parent
B=R/'backup';F=R/'formal-final';T=R/'test-prepared'
def read(p):return json.loads(p.read_text())
allowed={'抄表记录':{'登记事由','新租客姓名','新租客电话','总水表读数','总电表读数','校验结果'},'计费批次':{'校验结果'}}
changes=[]
for path in B.glob('table-*.json'):
 table=path.stem[6:];old=read(path);new=read(F/path.name)
 by={f['name']:f for f in new['fields']}
 for f in old['fields']:
  n=by[f['name']]
  if f!=n:
   assert f['name'] in allowed.get(table,set()),(table,f['name'])
   changes.append([table,f['name']])
 for f in new['fields']:
  if f['name'] not in {o['name'] for o in old['fields']}:
   assert table=='抄表记录',table
   changes.append([table,f['name'],'新增'])
for key in ['W2','W2A','W2B','W2C','W3']:
 assert read(B/(key+'.json'))['steps']==read(F/(key+'.json'))['steps'],key
# Normalize platform-generated field/option IDs, preserving step IDs and references.
names={}
for folder in [T,F]:
 for p in folder.glob('table-*.json'):
  for f in read(p)['fields']:
   names[f['id']]=f['name']
   for o in f.get('options',[]):
    if 'id' in o:names[o['id']]=o['name']
def norm(x):
 if isinstance(x,list):return [norm(v) for v in x]
 if isinstance(x,dict):
  if set(x)=={'id','name'}:return {'name':x['name']}
  return {k:norm(v) for k,v in x.items()}
 if isinstance(x,str):
  for id,name in names.items():x=x.replace(id,'{'+name+'}')
 return x
for key in ['W1','W1R']:
 a=read(T/(key+'.json'))['steps'];b=copy.deepcopy(read(F/(key+'.json'))['steps'])
 msgs={s['id'] for s in b if s['type']=='LarkMessageAction'}
 b=[s for s in b if s['id'] not in msgs]
 for s in b:
  if s.get('next') in msgs:s.pop('next')
 # Platform sometimes emits null rather than absent terminal next.
 for steps in [a,b]:
  for s in steps:
   if s.get('next') is None:s.pop('next',None)
 assert norm(a)==norm(b),key+' differs from tested flow'
opts=next(f for f in read(F/'table-抄表记录.json')['fields'] if f['name']=='登记事由')['options']
assert len(opts)==7 and not any('换租' in o['name'] for o in opts)
(F/'scope-verification.json').write_text(json.dumps({'passed':True,'changed_fields':changes,
 'unchanged_workflows':['W2','W2A','W2B','W2C','W3'],
 'tested_flow_equivalent':['W1','W1R']},ensure_ascii=False,indent=2)+'\n')
print('FORMAL_SCOPE_VERIFIED')
