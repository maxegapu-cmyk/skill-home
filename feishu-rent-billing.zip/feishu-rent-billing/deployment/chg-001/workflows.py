import sys,json,copy
import prepare as p
sys.path.insert(0,str(p.ROOT.parent))
import build_workflows as h
h.FIELDS={t:{f['name']:f['id'] for f in s['fields']} for t,s in p.schema().items()}
V,R,C,G,F=h.val,h.ref,h.cond,h.group,h.filtr
S='抄表记录';T='租约'
def sw(w,key,choices):
 w.step(key,'SwitchBranch',{'mode':'exclusive','no_match_action':'fail','child_branch_list':[
  {'name':dest,'condition':cond} for dest,cond in choices]},None,[
  {'kind':'case','label':'branch_'+str(i+1),'desc':dest,'to':dest} for i,(dest,_) in enumerate(choices)])
def make(retry=False):
 w=h.Workflow('W1R 处理及重试登记' if retry else 'W1 抄表登记处理')
 A=lambda f:R('登记',S,f)
 seq=V('$.登记.'+h.FIELDS[S]['抄表序号']+'.sequence','ref')
 if not retry:
  w.step('登记','AddRecordTrigger',{'table_name':S,'watched_field_name':'登记事由',
   'trigger_control_list':['openAPIBatchUpdate']},'准备处理')
  w.set('准备处理',S,{'计费序号':seq,'登记规则版本':'v1.0.2',
                    '交接处理状态':V('待处理','option')},source='登记')
  return {'title':w.title,'steps':w.steps}
 w.step('登记','SetRecordTrigger',{'table_name':S,
  'field_watch_info':[{'field_name':'交接处理状态','operator':'is','value':[V('待处理','option')]}],
  'trigger_control_list':['openAPIBatchUpdate','automationBatchUpdate']},'复查')
 fields=['交接登记检查','登记事由','计费状态','原交接意向','交接意向','同一时点交接']
 w.find('复查',S,fields,F(('计费序号','is',seq)),'分流')
 Q=lambda f:R('复查.firstfieldsRecord',S,f)
 choices=[('保留已出账',G(C(Q('计费状态'),'is',V('已计费','option')))),
          ('登记拦截',G(C(Q('交接登记检查'),'isNot',V(''))))]
 w.set('保留已出账',S,{'交接处理状态':V('已完成','option'),'交接处理说明':'已出账记录不重放，差额用调整'},source='登记')
 w.set('登记拦截',S,{'交接处理状态':V('需更正','option'),'交接处理说明':Q('交接登记检查')},source='登记')
 def done(key,status='未计费',extra=None):
  patch={'交接处理状态':V('已完成','option'),'计费状态':V(status,'option'),
         '交接处理说明':'登记完成。核对读数；入住后补齐租约价格。'}
  if extra:patch.update(extra)
  w.set(key,S,patch,key+'提醒' if p.MODE=='formal' else None,source='登记')
  if p.MODE=='formal':
   old=json.loads((p.ROOT/'backup'/'W1.json').read_text())
   data=copy.deepcopy(next(x['data'] for x in old['steps'] if x['type']=='LarkMessageAction'))
   data['content']=[V('抄表登记处理完成。请核对读数，将核对状态改为已核对。入住后补齐租约价格；当天有人入住的退租须补录关联入住。首次建档时请补建当前在住租约。')]
   w.step(key+'提醒','LarkMessageAction',data)
 for event,status in [('首次建档','起点不计费'),('月度抄表','未计费'),('换表起码','换表不计费')]:
  choices.append((event,G(C(Q('登记事由'),'is',V(event,'option')))))
  done(event,status)
 for floor in ['上层','下层']:
  for direct in [False,True]:
   k=floor+('直接入住' if direct else '重抄入住')
   choices.append((k,G(C(Q('登记事由'),'is',V(floor+'入住','option')),
                       C(Q('同一时点交接'),'is',V(direct,'boolean')))))
   w.find(k,T,['租约编号'],F(('入住抄表序号','is',seq)),k+'防重')
   entry=k+'查读数' if direct else k+'创建'
   sw(w,k+'防重',[(entry,G(C(R(k+'.recordNum'),'is',V(0,'number')))),
                   (k+'已有',G(C(R(k+'.recordNum'),'is',V(1,'number')))),
                   (k+'重复',G(C(R(k+'.recordNum'),'isGreater',V(1,'number'))))])
   if direct:
    nums=['总水表读数','总电表读数','上层水表读数','上层电表读数']
    w.find(k+'查读数',S,nums,F(('计费序号','is',A('关联退租序号'))),k+'带入')
    w.set(k+'带入',S,{f:R(k+'查读数.firstfieldsRecord',S,f) for f in nums},k+'创建',source='登记')
   w.add(k+'创建',T,{'租客姓名':A('新租客姓名'),'联系电话':A('新租客电话'),
    '楼层':V(floor,'option'),'入住日期':A('抄表日期'),'入住抄表序号':seq,
    '退租结算状态':V('未退租','option'),'归档':V('在用','option')},k+'完成')
   done(k+'完成');done(k+'已有')
   w.set(k+'重复',S,{'交接处理状态':V('需更正','option'),'交接处理说明':'同一抄表对应多份租约，需核对'},source='登记')
  for intent in ['当天有人入住','转为空置']:
   k=floor+('退租待接' if intent=='当天有人入住' else '退租空置')
   choices.append((k,G(C(Q('登记事由'),'is',V(floor+'退租','option')),C(Q('交接意向'),'is',V(intent,'option')))))
   w.find(k,T,['租约编号'],F(('退租抄表序号','is',seq)),k+'防重')
   sw(w,k+'防重',[(k+'关闭',G(C(R(k+'.recordNum'),'is',V(0,'number')))),
                   (k+'已有',G(C(R(k+'.recordNum'),'is',V(1,'number'))))])
   w.set(k+'关闭',T,{'退租日期':A('抄表日期'),'退租抄表序号':seq,'退租结算状态':V('待出账','option')},
         k+'完成',filter=F(('楼层','is',V(floor,'option')),('退租抄表序号','isEmpty',None),('入住抄表序号','isLess',seq)))
   done(k+'完成',extra={'原交接意向':intent});done(k+'已有')
 sw(w,'分流',choices)
 assert len(w.steps)<100,len(w.steps)
 return {'title':w.title,'steps':w.steps}
def deploy():
 known={x['title'].split()[0]:x for x in p.call('+workflow-list')['items']}
 for key,retry in [('W1',False),('W1R',True)]:
  body=make(retry);p.save(key+'-request',body)
  if key in known:
   p.call('+workflow-disable','--workflow-id',known[key]['workflow_id'])
   p.call('+workflow-update','--workflow-id',known[key]['workflow_id'],'--json',json.dumps(body,ensure_ascii=False))
   wid=known[key]['workflow_id']
  else:
   import uuid
   body['client_token']=str(uuid.uuid4())
   result=p.call('+workflow-create','--json',json.dumps(body,ensure_ascii=False));p.save(key+'-created',result)
   wid=result.get('workflow_id') or result.get('workflow',{}).get('workflow_id')
  p.save(key,p.call('+workflow-get','--workflow-id',wid))
  p.call('+workflow-enable','--workflow-id',wid);print('ENABLED',key,wid,flush=True)
if __name__=='__main__':deploy()
