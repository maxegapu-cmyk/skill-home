import live_test as t
import json,time
from decimal import Decimal

def enable_billing():
 for w in t.call('+workflow-list')['items']:
  k=w['title'].split()[0]
  if k in ('W2A','W2B','W2C'):
   if k=='W2C':
    body=t.call('+workflow-get','--workflow-id',w['workflow_id'])
    for s in body['steps']:
     if s['type']=='LarkMessageAction':
      s['type']='SetRecordAction'
      s['data']={'table_name':'计费批次','ref_info':{'step_id':'收尾'},
                 'field_values':[{'field_name':'处理说明','value':[{'value_type':'text','value':'专项验收完成，不发送通知'}]}]}
      # Trigger id is read from the actual definition.
      s['data']['ref_info']['step_id']=body['steps'][0]['id']
    t.call('+workflow-update','--workflow-id',w['workflow_id'],
           '--json',json.dumps({'title':body['title'],'steps':body['steps']},ensure_ascii=False))
   t.call('+workflow-enable','--workflow-id',w['workflow_id'])

def run_batch(rid,label):
 for step in range(15):
  for attempt in range(20):
   b=dict(t.query('计费批次')).get(rid)
   if b is None:
    time.sleep(2);continue
   if b['状态'] in (['已生成'],['已发送']):
    fees=t.query('费用明细',conds=[['批次号','==',b['批次号']]])
    result={'batch':b,'fees':fees};t.save(label,result)
    print(label,b['租客应收合计'],b['房东承担合计'],len(fees),flush=True);return result
   if b['状态'] in (['草稿'],['待继续']) and b['校验结果']=='通过':break
   if attempt==19:raise AssertionError(b)
   time.sleep(2)
  else:raise AssertionError(('stuck',b))
  t.update('计费批次',rid,{'状态':'生成中'})
  time.sleep(5)
 raise AssertionError('too many billing rounds')

def finish_t01():
 enable_billing()
 for rid,row in t.query('租约',['租客姓名']):
  if row['租客姓名']=='B':t.update('租约',rid,{'月租':3100,'垃圾费':0,'管理费':0,'水价':5,'电价':1})
 rid,row=t.reading('2026-11-01','月度抄表',[120,48,1200,480],'T01-end')
 t.create('公摊账单',{'所属月份':'2026-10-01','公摊合计':62,'状态':'已确认'},'T01-public')
 time.sleep(3)
 bid=t.create('计费批次',{'标题':'CHG-001 T01','批次类型':'月底结算','所属月份':'2026-10-01',
  '截止抄表序号':row['计费序号'],'状态':'草稿','处理阶段':'水电'},'T01-batch')
 result=run_batch(bid,'T01-billing-result')
 # Read fees by payer/type, not generated tenancy IDs.
 vals={}
 for _,r in result['fees']:
  key=(r['承担方'],tuple(r['费用类型']));vals[key]=vals.get(key,Decimal(0))+Decimal(str(r['本行金额']))
 for who,amount in [('A',1400),('B',1700),('C',3100)]:assert vals[(who,('固定费',))]==amount,vals
 for who,amount in [('A',14),('B',17),('C',31)]:assert vals[(who,('公摊',))]==amount,vals
 assert Decimal(str(result['batch']['租客应收合计']))==6562,result['batch']
 assert Decimal(str(result['batch']['房东承担合计']))==0,result['batch']
 print('T01_BILLING_PASS',flush=True)
if __name__=='__main__':finish_t01()
