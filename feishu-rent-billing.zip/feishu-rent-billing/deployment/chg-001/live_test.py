import backup,json,time,sys
from pathlib import Path
backup.BASE=json.loads((backup.ROOT/'test-base.json').read_text())['data']['base']['base_token']
OUT=backup.ROOT/'acceptance';OUT.mkdir(exist_ok=True)
def save(n,d): (OUT/(n+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2))
def call(*a):return backup.call(*a)
def create(t,p,n):
 r=call('+record-batch-create','--table-id',t,'--json',json.dumps({'fields':list(p),'rows':[list(p.values())]},ensure_ascii=False))
 save(n,r);rid=r['record_id_list'][0]
 for _ in range(20):
  if rid in dict(query(t,[next(iter(p))])):return rid
  time.sleep(1)
 raise AssertionError(('new record not visible',t,rid))
def update(t,r,p):return call('+record-batch-update','--table-id',t,'--json',json.dumps({'record_id_list':[r],'patch':p},ensure_ascii=False))
def query(t,fields=None,conds=None):
 args=['--table-id',t,'--format','json','--limit','200']
 if fields:
  for f in fields:args+=['--field-id',f]
 if conds:args+=['--filter-json',json.dumps({'logic':'and','conditions':conds},ensure_ascii=False)]
 r=call('+record-list',*args);assert not r.get('has_more')
 return [(rid,dict(zip(r['fields'],row))) for rid,row in zip(r['record_id_list'],r['data'])]
def wait_reading(rid):
 for i in range(12):
  rows=query('抄表记录',['计费序号','登记事由','交接处理状态','交接处理说明','交接登记检查','校验结果','总水表读数','总电表读数','上层水表读数','上层电表读数','交接完成状态'])
  row=dict(rows).get(rid,{})
  if row.get('交接处理状态')==['需更正']:return row
  if row.get('交接处理状态')==['已完成'] and '登记处理未完成' not in (row.get('校验结果') or ''):return row
  time.sleep(2)
 return row

def reading(dt,event,nums,n,**extra):
 p={'抄表日期':dt,'登记事由':event,'核对状态':'已核对','记录状态':'有效'}
 if nums:p.update(dict(zip(['总水表读数','上层水表读数','总电表读数','上层电表读数'],nums)))
 p.update(extra);r=create('抄表记录',p,n);row=wait_reading(r);save(n+'-result',row);print(n,row,flush=True);return r,row

def setup_t01():
 r=json.loads((OUT/'T01-start.json').read_text())['record_id_list'][0]
 row=wait_reading(r)
 assert row.get('交接处理状态')==['已完成'],row
 seq=int(float(row['计费序号']))
 for name,fl in [('A','上层'),('C','下层')]:
  create('租约',{'租客姓名':name,'楼层':fl,'入住日期':'2026-10-01','入住抄表序号':seq,
                 '月租':3100,'垃圾费':0,'管理费':0,'水价':5,'电价':1,'归档':'在用','退租结算状态':'未退租'},'T01-tenant-'+name)
 time.sleep(3)
 r,row=reading('2026-10-15','上层退租',[110,44,1100,440],'T01-out',交接意向='当天有人入住')
 assert row.get('交接处理状态')==['已完成'],row
 seq=int(float(row['计费序号']))
 r,row=reading('2026-10-15','上层入住',None,'T01-in',关联退租序号=seq,同一时点交接=True,新租客姓名='B')
 assert row.get('交接处理状态')==['已完成'],row
 time.sleep(3)
 save('T01-tenancies',query('租约'))
 print('T01_REGISTRATION_PASS',flush=True)
if __name__=='__main__':setup_t01()
