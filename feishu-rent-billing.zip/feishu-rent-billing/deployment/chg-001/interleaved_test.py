import scenarios as s
import live_test as t
import time
s.reset('T07-insert');s.seed('T07-insert')
rid,out=t.reading('2026-10-15','上层退租',[110,44,1100,440],'T07-insert-out',交接意向='当天有人入住')
t.reading('2026-10-15','月度抄表',[111,44,1110,440],'T07-intermediate')
inc,r=t.reading('2026-10-15','上层入住',[111,44,1110,440],'T07-direct-rejected',
                关联退租序号=out['计费序号'],同一时点交接=True,新租客姓名='B')
assert r['交接处理状态']==['需更正'] and '不能直接带入' in r['交接登记检查'],r
assert len(t.query('租约'))==2
# Use the fresh actual reading; no forced copying of earlier values.
t.update('抄表记录',inc,{'同一时点交接':False})
for _ in range(20):
 row=dict(t.query('抄表记录',['交接登记检查'])).get(inc,{})
 if row.get('交接登记检查')=='':break
 time.sleep(2)
t.update('抄表记录',inc,{'交接处理状态':'待处理'})
time.sleep(4)
r=t.wait_reading(inc);t.save('T07-reread-recovery',r)
assert r['交接处理状态']==['已完成'],r
assert len(t.query('租约'))==3
bad,r=t.reading('2026-10-14','下层退租',[111,44,1110,440],'T07-date-reversed',交接意向='转为空置')
assert r['交接处理状态']==['需更正'] and '日期倒序' in r['交接登记检查'],r
assert not t.query('费用明细')
t.update('抄表记录',bad,{'记录状态':'作废'})
# Confirm the real-world roster supplied by the fixture is now represented.
roster=t.query('租约',['租客姓名','退租抄表序号'])
registered=sorted(r['租客姓名'] for _,r in roster if not r['退租抄表序号'])
assert registered==['B','C'],registered
t.save('T09-roster-recovered',{'actual':['B','C'],'registered':registered,'passed':True})
t.save('case-T07-insert',{'passed':True})
print('T07_INSERT_AND_T09_PASS',flush=True)
