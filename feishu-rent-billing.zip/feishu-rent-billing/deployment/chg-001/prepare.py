import json,sys,copy
from pathlib import Path
import backup
ROOT=backup.ROOT
MODE=sys.argv[1] if len(sys.argv)>1 else 'test'
assert MODE in ('test','formal')
backup.BASE=json.loads((ROOT/'test-base.json').read_text())['data']['base']['base_token'] if MODE=='test' else 'Hcgobn2S4aaXHNs0bHBcOOFWnWc'
OUT=ROOT/(MODE+'-prepared');OUT.mkdir(exist_ok=True)
def call(*a): return backup.call(*a)
def save(n,x): (OUT/(n+'.json')).write_text(json.dumps(x,ensure_ascii=False,indent=2))
def schema():
 return {t['name']:call('+table-get','--table-id',t['id']) for t in call('+table-list')['tables']}
def formula(n,e):return dict(name=n,type='formula',expression=e)
def num(n,desc=''):return dict(name=n,type='number',style={'type':'plain','precision':0},description=desc)
def text(n,desc=''):return dict(name=n,type='text',description=desc)
def sel(n,options,default=None):
 r=dict(name=n,type='select',multiple=False,options=[{'name':v} for v in options])
 if default:r['default_value']=[default]
 return r
def ensure(table,f):
 current={x['name']:x for x in call('+table-get','--table-id',table)['fields']}
 if f['name'] in current:
  if f['type']=='formula' and current[f['name']].get('expression')!=f.get('expression'):update(table,f)
  return
 args=['--table-id',table,'--json',json.dumps(f,ensure_ascii=False)]
 if f['type']=='formula':args+=['--i-have-read-guide']
 call('+field-create',*args);print('CREATE',table,f['name'],flush=True)
def update(table,f):
 args=['--table-id',table,'--field-id',f['name'],'--json',json.dumps({k:v for k,v in f.items() if k!='id'},ensure_ascii=False),'--yes']
 if f['type']=='formula':args+=['--i-have-read-guide']
 call('+field-update',*args);print('UPDATE',table,f['name'],flush=True)
def count(t,c):return f'[{t}].COUNTIF({c})'
def get(c,f):return f'[抄表记录].FILTER({c}).[{f}].FIRST()'
def iferr(c,msg):return f'IF({c},"{msg}；","")'
def setup_fields():
 for f in [sel('交接意向',['当天有人入住','转为空置']),text('原交接意向'),text('交接更正原因'),num('关联退租序号','入住时填同层退租的抄表序号；同一退租只关联一次'),dict(name='同一时点交接',type='checkbox'),sel('交接处理状态',['待处理','处理中','已完成','需更正']),text('交接处理说明'),dict(text('登记规则版本'),default_value='v1.0.2')]:ensure('抄表记录',f)
 ev='[登记事由]';seq='[序号值]';fl='LEFT([登记事由],2)';inc='OR([登记事由]="上层入住",[登记事由]="下层入住")';out='OR([登记事由]="上层退租",[登记事由]="下层退租")'
 source='AND(CurrentValue.[序号值]=[关联退租序号],CurrentValue.[记录状态]="有效")'
 linkcount=count('抄表记录','AND(CurrentValue.[关联退租序号]=[关联退租序号],CurrentValue.[记录状态]="有效")')
 copycheck='AND('+inc+',NOT(ISBLANK([关联退租序号])),'+count('抄表记录',source)+'=1,'+get(source,'登记事由')+'=LEFT([登记事由],2)&"退租",'+get(source,'交接处理状态')+'="已完成",[关联退租序号]=[上次序号],TEXT([抄表日期],"YYYY-MM-DD")=TEXT('+get(source,'抄表日期')+',"YYYY-MM-DD"))'
 ensure('抄表记录',formula('允许带入读数',f'IF({copycheck},"是","否")'))
 errs=[
  iferr('CONTAINTEXT([登记事由],"换租")','新登记已取消换租，请先退租再入住'),
  iferr(f'AND({out},ISBLANK([交接意向]))','退租缺交接意向'),
  iferr('AND([原交接意向]="当天有人入住",[交接意向]="转为空置",ISBLANK([交接更正原因]))','交接意向更正缺原因'),
  iferr(f'AND({inc},ISBLANK([新租客姓名]))','入住缺新租客姓名'),
  iferr(f'AND({inc},IF(LEFT([登记事由],2)="上层",[段上层租约数],[段下层租约数])>0)','该层仍有在住租约，请先退租'),
  iferr(f'AND({out},IF(LEFT([登记事由],2)="上层",[段上层租约数],[段下层租约数])!=1)','退租必须对应唯一在住租约'),
  iferr(f'AND(NOT(ISBLANK([关联退租序号])),NOT({inc}))','只有入住可关联退租'),
  iferr('AND([同一时点交接],OR(ISBLANK([关联退租序号]),[允许带入读数]!="是"))','不能直接带入，请核对关联或重新抄表'),
  iferr('AND(NOT(ISBLANK([关联退租序号])),OR('+count('抄表记录',source)+'!=1,'+get(source,'登记事由')+'!=LEFT([登记事由],2)&"退租",[关联退租序号]>=[序号值],'+get(source,'交接处理状态')+'!="已完成"))','关联退租无效、未完成或顺序错误'),
  iferr('AND(NOT(ISBLANK([关联退租序号])),'+linkcount+'>1)','同一退租重复关联'),
  iferr('AND(NOT(ISBLANK([关联退租序号])),'+get(source,'交接意向')+'="当天有人入住",TEXT([抄表日期],"YYYY-MM-DD")!=TEXT('+get(source,'抄表日期')+',"YYYY-MM-DD"))','声明当天入住但日期不同'),
  iferr('AND(NOT(ISBLANK([上次序号])),[抄表日期]<[上次日期])','日期倒序'),
  iferr('ISBLANK([抄表日期])','缺抄表日期')]
 # Readers remain human-verified; physical reading validity is also gated before billing.
 expr='CONCATENATE('+','.join(errs)+')'
 ensure('抄表记录',formula('交接登记检查',expr))
 complete=count('抄表记录','AND(CurrentValue.[关联退租序号]=[序号值],CurrentValue.[记录状态]="有效",CurrentValue.[交接处理状态]="已完成")')
 ensure('抄表记录',formula('交接完成状态',f'IF(AND({out},[交接意向]="当天有人入住"),IF({complete}=1,"已关联入住","待补录入住"),"")'))
 # Preserve original billing checks and arithmetic; only append CHG-001 controls.
 old=json.loads((ROOT/'backup'/'table-抄表记录.json').read_text())
 f=copy.deepcopy(next(x for x in old['fields'] if x['name']=='校验结果'))
 f['expression']=f['expression'].replace('请改用“上层换租”或先登记退租','请先登记退租').replace('请改用“下层换租”或先登记退租','请先登记退租')
 f['expression']='IF([记录状态]="作废","",CONCATENATE('+f['expression']+',IF([登记规则版本]="v1.0.2",[交接登记检查],""),IF(AND([登记规则版本]="v1.0.2",[交接处理状态]!="已完成"),"登记处理未完成；",""),IF([交接完成状态]="待补录入住","交接待补录入住；","")))'
 update('抄表记录',f)
 # Guard public supplement as well as utility batches, including previously billed departures.
 old=json.loads((ROOT/'backup'/'table-计费批次.json').read_text())
 f=copy.deepcopy(next(x for x in old['fields'] if x['name']=='校验结果'))
 pending='[抄表记录].COUNTIF(AND(CurrentValue.[记录状态]="有效",OR(CurrentValue.[交接完成状态]="待补录入住",AND(CurrentValue.[登记规则版本]="v1.0.2",OR(CurrentValue.[交接处理状态]!="已完成",CurrentValue.[交接登记检查]!=""))),OR(AND(NOT(ISBLANK([截止抄表序号])),CurrentValue.[序号值]<=[截止抄表序号]),AND(NOT(ISBLANK([所属月份])),TEXT(CurrentValue.[抄表日期],"YYYY-MM")=TEXT([所属月份],"YYYY-MM")))))>0'
 f['expression']='IF(AND([批次类型]!="调整入账",'+pending+'),"交接待补录入住或登记有误",'+f['expression']+')'
 update('计费批次',f)
 for t,sc in schema().items():save('table-'+t,sc)
if __name__=='__main__':setup_fields()
