import json,time,sys
from decimal import Decimal
import billing_test as b
import live_test as t

def reset(label):
 assert t.backup.BASE=='PMZUbwDzCa6N5JsbcYxcX94Gn9d'
 for table in ['费用明细','计费批次','公摊账单','租约','抄表记录']:
  rows=t.query(table);t.save(label+'-before-reset-'+table,rows)
  ids=[r for r,_ in rows]
  if ids:t.call('+record-delete','--table-id',table,'--json',json.dumps({'record_id_list':ids}),'--yes')
 time.sleep(3)

def seed(label):
 rid,r=t.reading('2026-10-01','首次建档',[100,40,1000,400],label+'-start')
 assert r['交接处理状态']==['已完成'],r
 for name,fl in [('A','上层'),('C','下层')]:
  t.create('租约',{'租客姓名':name,'楼层':fl,'入住日期':'2026-10-01','入住抄表序号':r['计费序号'],
    '月租':3100,'垃圾费':0,'管理费':0,'水价':5,'电价':1,'归档':'在用','退租结算状态':'未退租'},label+'-tenant-'+name)
 time.sleep(3)

def fill_prices():
 for rid,r in t.query('租约',['租客姓名','月租']):
  if r['月租'] is None:t.update('租约',rid,{'月租':3100,'垃圾费':0,'管理费':0,'水价':5,'电价':1})

def end_bill(label,dt='2026-11-01',month='2026-10-01'):
 fill_prices()
 rid,r=t.reading(dt,'月度抄表',[120,48,1200,480],label+'-end')
 t.create('公摊账单',{'所属月份':month,'公摊合计':62,'状态':'已确认'},label+'-public')
 bid=t.create('计费批次',{'标题':'CHG-001 '+label,'批次类型':'月底结算','所属月份':month,
  '截止抄表序号':r['计费序号'],'状态':'草稿','处理阶段':'水电'},label+'-batch')
 time.sleep(3)
 return b.run_batch(bid,label+'-billing-result')

def sums(result):
 vals={}
 for _,r in result['fees']:
  key=(r['承担方'],tuple(r['费用类型']));vals[key]=vals.get(key,Decimal(0))+Decimal(str(r['本行金额']))
 return vals

def vacancy(label,day):
 reset(label);seed(label)
 rid,r=t.reading('2026-10-15','上层退租',[110,44,1100,440],label+'-out',
                 交接意向='转为空置' if day==18 else '当天有人入住')
 assert r['交接处理状态']==['已完成'],r
 rid,inc=t.reading(f'2026-10-{day}','上层入住',[113,45,1115,445],label+'-in',
                   关联退租序号=r['计费序号'],同一时点交接=False,新租客姓名='B')
 assert inc['交接处理状态']==['已完成'],inc
 result=end_bill(label);v=sums(result)
 assert v[('房东',('空置水电',))]==Decimal('8.02'),v
 assert v[('A',('固定费',))]==1400,v
 assert v[('B',('固定费',))]==(1400 if day==18 else 1700),v
 if day==18:assert v[('房东',('空置公摊',))]==3,v
 print(label+'_PASS',flush=True)

def guards():
 reset('T05');seed('T05')
 rid,out=t.reading('2026-10-15','上层退租',[110,44,1100,440],'T05-out',交接意向='当天有人入住')
 seq=out['计费序号']
 bid=t.create('计费批次',{'标题':'CHG-001 T05 待入住','批次类型':'交接结算','截止抄表序号':seq,'状态':'草稿'},'T05-batch')
 time.sleep(4);rows=t.query('计费批次');t.save('T05-blocked',rows)
 assert '待补录' in dict(rows)[bid]['校验结果'],rows
 assert not t.query('费用明细')
 roster=t.query('租约',['租客姓名','退租抄表序号'])
 actual={'B','C'};registered={r['租客姓名'] for _,r in roster if not r['退租抄表序号']}
 t.save('T09-missing-roster',{'actual':sorted(actual),'registered':sorted(registered),'missing':sorted(actual-registered)})
 assert actual-registered=={'B'}
 t.update('抄表记录',rid,{'交接意向':'转为空置'})
 time.sleep(8)
 t.save('T05-correction-without-reason',t.query('抄表记录'))
 assert dict(t.query('计费批次'))[bid]['校验结果']!='通过'
 t.update('抄表记录',rid,{'交接更正原因':'验收模拟：确认无人入住'})
 time.sleep(8)
 assert dict(t.query('计费批次'))[bid]['校验结果']=='通过'
 t.save('T05-correction-with-reason',t.query('抄表记录'))
 t.update('抄表记录',rid,{'交接意向':'当天有人入住'})
 time.sleep(4)
 wrong,wr=t.reading('2026-10-15','下层入住',[110,44,1100,440],'T05-wrong-floor',
                   关联退租序号=seq,同一时点交接=True,新租客姓名='错误测试')
 assert wr['交接处理状态']==['需更正'],wr
 assert len(t.query('租约'))==2
 t.update('抄表记录',wrong,{'记录状态':'作废'})
 # Missing mandatory upper reading is checked before billing even with zero usage.
 inc,ir=t.reading('2026-10-15','上层入住',[110,44,1100,440],'T05-correct-in',
                  关联退租序号=seq,同一时点交接=True,新租客姓名='B')
 assert ir['交接处理状态']==['已完成'],ir
 fill_prices();time.sleep(4)
 roster=t.query('租约',['租客姓名','退租抄表序号'])
 registered={r['租客姓名'] for _,r in roster if not r['退租抄表序号']}
 t.save('T09-reconciled-roster',{'actual':['B','C'],'registered':sorted(registered)})
 assert registered=={'B','C'}
 t.save('T05-recovered',t.query('计费批次'))
 assert dict(t.query('计费批次'))[bid]['校验结果']=='通过'
 # Repeat the same incoming record after a simulated interrupted completion.
 before=len(t.query('租约'))
 t.update('抄表记录',inc,{'交接处理状态':'处理中'})
 t.update('抄表记录',inc,{'交接处理状态':'待处理'})
 rr=t.wait_reading(inc);time.sleep(3);t.save('T06-retry',{'reading':rr,'tenancies':t.query('租约')})
 assert rr['交接处理状态']==['已完成'] and len(t.query('租约'))==before
 t.update('抄表记录',inc,{'上层电表读数':None});time.sleep(3)
 result=t.query('计费批次');t.save('T07-missing-reading',result)
 # Cutoff must include incoming reading, whose post-state now has both floors occupied.
 t.update('计费批次',bid,{'截止抄表序号':ir['计费序号']});time.sleep(3)
 assert dict(t.query('计费批次'))[bid]['校验结果']!='通过'
 assert not t.query('费用明细')
 t.update('抄表记录',inc,{'上层电表读数':440,'总水表读数':90});time.sleep(3)
 t.save('T07-reversed',t.query('抄表记录'))
 assert dict(t.query('计费批次'))[bid]['校验结果']!='通过'
 t.update('抄表记录',inc,{'总水表读数':110});time.sleep(3)
 # Duplicate incoming must not create another tenancy.
 bad,br=t.reading('2026-10-15','上层入住',[110,44,1100,440],'T06-duplicate',
                  关联退租序号=seq,同一时点交接=True,新租客姓名='B')
 assert br['交接处理状态']==['需更正'] and len(t.query('租约'))==before
 t.update('抄表记录',bad,{'记录状态':'作废'})
 print('T05_T06_T07_PASS',flush=True)

def boundary():
 reset('T04');seed('T04')
 rid,r=t.reading('2026-10-31','上层退租',[110,44,1100,440],'T04-out',交接意向='转为空置')
 bid=t.create('计费批次',{'标题':'CHG-001 T04 十月','批次类型':'月底结算','所属月份':'2026-10-01',
  '截止抄表序号':r['计费序号'],'状态':'草稿','处理阶段':'水电'},'T04-oct-batch')
 time.sleep(3);res=b.run_batch(bid,'T04-oct-result');v=sums(res)
 assert v[('A',('固定费',))]==3000,v
 rid,inc=t.reading('2026-11-01','上层入住',[113,45,1115,445],'T04-in',
                   关联退租序号=r['计费序号'],同一时点交接=False,新租客姓名='B')
 assert inc['交接处理状态']==['已完成'],inc
 res=end_bill('T04-Nov','2026-12-01','2026-11-01');v=sums(res)
 assert v[('B',('固定费',))]==3100,v
 assert v[('房东',('空置水电',))]==Decimal('8.02'),v
 print('T04_PASS',flush=True)

if __name__=='__main__':
 name=sys.argv[1]
 if name in ('T02','T03'):vacancy(name,18 if name=='T02' else 15)
 elif name=='guards':guards()
 elif name=='T04':boundary()
 t.save('case-'+name,{'passed':True,'test_base':t.backup.BASE})
