"""仅在正式配置验收并导出后，同步 CHG-001 关联说明。"""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
P=ROOT.parent.parent
RELEASE=ROOT/'formal-final'
assert (ROOT/'acceptance'/'release-approved.json').exists(), '全部验收通过并记录后才同步生效文档'
def edit(path,fn):
 f=P/path;old=f.read_text();new=fn(old)
 if old!=new:f.write_text(new)
def add(path,body):edit(path,lambda s:s.rstrip()+'\n\n'+body.strip()+'\n')
for name in ['SKILL.md','README.md','references/billing-rules.md','references/data-model.md',
             'references/formulas.md','references/automation-setup.md','assets/landlord-defaults.md','使用说明.md']:
 edit(name,lambda s:s.replace('v1.0.1','v1.0.2',1) if name=='references/billing-rules.md' else s.replace('v1.0.1','v1.0.2'))
old='每月一次“月度抄表”，每次入住、退租、换租各登记一次，先选事由再填读数、日期、照片。事由：首次建档、月度抄表、上层入住、上层退租、上层换租、下层入住、下层退租、下层换租、换表起码。换租 = 同一天同一层老租客退租、新租客入住，只登记一次读数。'
new='''每月一次“月度抄表”。新登记事由只有：首次建档、月度抄表、上层入住、上层退租、下层入住、下层退租、换表起码。

同层交接先登记退租，等处理完成后再登记入住，两条记录使用不同序号。退租选择交接意向“当天有人入住”或“转为空置”。当天有人入住但未关联有效入住时，提示待补录并拦截相关批次。

入住通过“关联退租序号”关联同层退租。同一时点、同一天、相邻有效记录，且退租已处理完成，才可勾选“同一时点交接”并带入同一组总表和上层表读数。两条记录之间用量为 0，仍执行必填检查。日期相同但存在时间间隔、实际用量或中间有其他有效抄表时，取消该勾选并重新抄表；空置层有依据的实际水电归房东。另一层照常按其实际状态计费。

交接意向从“当天有人入住”更正为“转为空置”时，保留原意向并填写更正原因。登记有误或中断时，先更正资料，再将交接处理状态改为“待处理”重试，不再提交重复记录。每次等前一条处理完成后再登记下一条。

旧“换租”记录作为历史资料保留，不批量拆分，不改序号、租约关联或已出账唯一键。新流程不再创建换租记录。'''
edit('references/billing-rules.md',lambda s:s.replace(old,new).replace('所以同一天换租时：截至换租读数的那段归老租客，之后的段归新租客。',
 '同一时点交接时：截至退租读数的区间归老租客，退租至入住区间用量为 0，入住后的区间归新租客。若存在实际空置用量，按 R5 归房东。入住前必须结束旧租约；同一退租只关联一次入住。重复处理同一记录不重复建立租约或收费。'))
add('references/billing-rules.md','''## CHG-001 生效说明

v1.0.2 仅改变交接登记及相关校验。固定费天数、公摊累计取整、单价、金额精度和已出账调整方式保持原规则。小时级空置不另算一天空置。月底由房东核对实际在住名单与系统租约；系统无法发现完全未登记的实际入住。过程和验收见 `../规则修改日志.md` CHG-001。
''')
add('assets/landlord-defaults.md','2026-10-03 CHG-001：用户要求取消换租，新交接分别登记退租和入住。直接交接可带入读数；有间隔则重新抄表。原 1–11 项计费口径保持不变。')
for name in ['references/data-model.md','使用说明.md']:
 edit(name,lambda s:s.replace('入住或换租时','入住时').replace('入住、换租时','入住时'))
edit('references/data-model.md',lambda s:s.replace('| 总水表读数 | number | 必填 |','| 总水表读数 | number | 必须有值；直接交接可带入 |').replace('| 总电表读数 | number | 必填 |','| 总电表读数 | number | 必须有值；直接交接可带入 |'))
# Only remove obsolete options in the current field definition, not in historical examples.
edit('references/data-model.md',lambda s:'\n'.join(
 line.replace(' / 上层换租','').replace(' / 下层换租','').replace('、上层换租','').replace('、下层换租','') if line.startswith('| 登记事由 |') else line
 for line in s.split('\n')))
old_fields={f['name'] for f in json.loads((ROOT/'backup/table-抄表记录.json').read_text())['fields']}
sc=json.loads((RELEASE/'table-抄表记录.json').read_text())
newfields=[f for f in sc['fields'] if f['name'] not in old_fields]
add('references/data-model.md','## CHG-001 新增交接字段\n\n以下字段均在抄表记录表。关联退租序号引用唯一数字抄表序号；不是租约编号。\n\n| 字段 | 类型 | 用途 |\n|---|---|---|\n'+'\n'.join(
 '| '+f['name']+' | '+f['type']+' | '+(f.get('description') or ('由公式计算' if f['type']=='formula' else 'CHG-001 交接登记与校验'))+' |' for f in newfields))
for table in ['抄表记录','计费批次']:
 live=json.loads((RELEASE/('table-'+table+'.json')).read_text())
 f=next(f for f in live['fields'] if f['name']=='校验结果')
 def replace_formula(s,table=table,f=f):
  start=s.index('## '+table+'\n');nxt=s.find('\n## ',start+1);end=len(s) if nxt<0 else nxt
  part=s[start:end]
  part=re.sub(r'(### 校验结果\n\n```text\n).*?(\n```)',lambda m:m.group(1)+f['expression']+m.group(2),part,flags=re.S,count=1)
  return s[:start]+part+s[end:]
 edit('references/formulas.md',replace_formula)
add('references/formulas.md','## CHG-001 新增交接校验公式\n\n仅新增下列交接公式及扩展两表的校验结果；用量、单价、天数、公摊和费用唯一键公式未变。\n\n'+'\n\n'.join(
 '### '+f['name']+'\n\n```text\n'+f['expression']+'\n```' for f in newfields if f['type']=='formula'))
edit('references/automation-setup.md',lambda s:s.replace(
 '新增记录后按登记事由分支。把自动编号的数字 sequence 写入「计费序号」。登记入住或换租时建新租约；退租或换租时关闭对应旧租约。保留待核对状态，并提醒房东补齐租约价格及核对读数。',
 'W1 把自动编号的数字 sequence 写入「计费序号」，标记登记规则版本并将交接处理状态设为待处理。W1R 监听待处理，先检查关联、顺序、楼层和交接意向，再按事由处理。退租关闭唯一旧租约，入住按抄表序号查重后建立新租约。直接交接从关联退租带入读数。登记完成后仍须人工核对读数并补齐新租约价格。\n\nW1R 同时用于更正后重试：改正输入并等待交接登记检查清空后，将交接处理状态设为待处理。已建立或已关闭的租约按原抄表序号识别，不重复处理。已出账记录不重放登记，差额走调整。工作流采用独立 Switch 分支，避免平台不支持的嵌套 IfElse。'))
edit('references/automation-setup.md',lambda s:s.replace('日期、登记事由、总水、总电必填。','日期和登记事由必填。总水、总电必须有值；直接交接时可由关联退租自动带入，计费前仍检查缺值。').replace('共13项。','另增加交接意向、关联退租序号及同一时点交接。'))
add('references/automation-setup.md','''## CHG-001 验收及发布

正式配置以 `deployment/release/` 为准，新增 W1R。相关批次遇到交接待补录、处理未完成或交接校验错误时拦截；公摊补充也执行交接检查。每次等处理完成后再登记下一条；公式刷新后再出账。费用计算及 W2A/W2B/W2C/W3 的正式处理逻辑保持原样。
''')
add('使用说明.md','''## 退租后再入住

1. 先登记退租，选择当天有人入住或转为空置。等交接处理状态显示已完成。
2. 再登记入住，填写关联退租序号和新租客姓名。同一时点直接交接，勾选同一时点交接，读数自动带入；有时间间隔或中间插入其他抄表，则不勾选，重新填写读数。
3. 当天有人入住但尚未补录时，相关批次不能出账。确认转为空置时，填写交接更正原因。
4. 登记失败时先更正输入，等交接登记检查清空后，再把交接处理状态改为待处理。不要再提交一条相同登记。
5. 月底核对实际在住名单。完全没登记的入住，需要房东发现并补录。

例：10 月 15 日同一时点交接，先退 A，再入 B。A 房租算到 14 日，B 从 15 日起算；共用读数时两条记录之间水电为 0。
''')
edit('references/edge-cases.md',lambda s:s.replace('## 一、入住、退租、换租','## 一、入住、退租、交接').replace(
 '| 同一天老租客走、新租客来（同一层） | 选“上层换租/下层换租”登记一次：截至这次读数的水电归老租客，之后归新租客；固定费老租客算到前一天，新租客从当天算 | 只登记一次，不要分两条 |',
 '| 同一天老租客走、新租客来（同一层） | 先登记退租，处理完成后再登记入住。同一时点直接交接可关联并带入读数；有间隔则重新抄表，实际空置用量归房东。固定费老租客算到前一天，新租客从当天算 | 分两条记录，不同序号；同日不等于同一时点 |'))
add('references/edge-cases.md','''## CHG-001 交接检查

- 当天有人入住却未补录：拦截相关批次；补齐同层关联入住，或确认转为空置并说明原因。
- 同日但不同时间交接：重新抄表，空置层实际用量归房东；固定费仍按自然日期。
- 直接交接中插入其他有效抄表：不得带入旧读数，改为重新抄表。
- 重试：在原记录更正，将交接处理状态设为待处理。已出账错误仍用调整行。
- 历史换租：保留记录及唯一键；不拆分，不改旧账。
''')
add('references/test-cases.md','''## CHG-001 专项验收

专项输入和期望值见 `../规则修改日志.md` 的 T01–T09。执行记录见 `../deployment/chg-001/acceptance/`；本地检查包含在 `python3 scripts/rent_calc.py --selftest`。原算例 D 保留为历史换租兼容基线，并增加拆分登记后的金额比较。T09 是用模拟实际在住名单核对系统状态，正式使用仍须房东核对实际情况。
''')
add('SKILL.md','''## CHG-001 登记约束

新交接只使用退租和入住。先退后入，直接交接须关联同层退租并确认同一时点；中间有实际用量则重新抄表。交接待补录、关联错误或处理未完成时不可出相关批次。更正后在原记录重试；历史换租保留。核算器新输入使用 rule_version=v1.0.2；历史换租记录明确标 historical=true，旧版输入仍可复核。
''')
add('README.md','CHG-001：新登记已取消换租，分别登记退租和入住。执行过程、验收和回退证据见 `deployment/chg-001/`。')
edit('README.md',lambda s:s.replace('未验证：飞书公式与工作流未在真实多维表格中实测，需按 test-cases.md 的“飞书验收步骤”走一遍。',
 'CHG-001 的飞书专项及 A/B/C/D 回归证据见 deployment/chg-001/acceptance/。照片自动识别未配置。'))
edit('使用说明.md',lambda s:s.replace('B/C/D未逐一在真实飞书运行。','CHG-001 已增加 A/B/C/D 的飞书回归验收。'))
edit('references/formulas.md',lambda s:s.replace('算例 A 已在独立飞书验收表验证；B/C/D 仅完成本地核算验证。',
 'CHG-001 已在独立飞书验收表核对专项及 A/B/C/D 计费结果，证据见 ../deployment/chg-001/acceptance/。'))
# Earlier dated validation paragraphs remain historical; new evidence is dated separately.
for name in ['README.md','使用说明.md','references/formulas.md']:
 add(name,'2026-10-03 CHG-001 的验收范围及结果以 `deployment/chg-001/acceptance/` 和规则修改日志为准；此前日期的验证说明属于历史记录。')
print('CHG001_DOCS_SYNCED')
