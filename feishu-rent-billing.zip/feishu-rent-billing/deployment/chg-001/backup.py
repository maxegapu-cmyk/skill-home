import json, os, subprocess, pathlib, shutil
ROOT=pathlib.Path(__file__).resolve().parent
BASE='Hcgobn2S4aaXHNs0bHBcOOFWnWc'
OUT=ROOT/'backup'
OUT.mkdir(exist_ok=True)
def call(cmd,*args):
 p=subprocess.run(['lark-cli','base',cmd,'--base-token',BASE,'--as','user',*args],text=True,capture_output=True,env=dict(os.environ,LARKSUITE_CLI_NO_UPDATE_NOTIFIER='1',LARKSUITE_CLI_NO_SKILLS_NOTIFIER='1'))
 r=json.loads(p.stdout or p.stderr)
 if not r.get('ok'): raise RuntimeError(r)
 return r['data']
def save(name,data):
 (OUT/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
def main():
 if (OUT/'complete.json').exists(): raise SystemExit('Backup already complete; do not overwrite')
 save('base',call('+base-get'))
 ts=call('+table-list'); save('tables',ts)
 for t in ts['tables']:
  save('table-'+t['name'],call('+table-get','--table-id',t['id']))
  pages=[]; offset=0
  while True:
   p=call('+record-list','--table-id',t['id'],'--format','json','--offset',str(offset),'--limit','200'); pages.append(p)
   if not p.get('has_more'): break
   offset+=len(p['record_id_list'])
  save('records-'+t['name'],pages)
  save('views-'+t['name'],call('+view-list','--table-id',t['id']))
  if t['name']=='抄表记录':
   fs=call('+form-list','--table-id',t['id']); save('forms',fs)
  print('BACKUP',t['name'],flush=True)
 ws=call('+workflow-list');save('workflows',ws)
 for w in ws['items']: save(w['title'].split()[0],call('+workflow-get','--workflow-id',w['workflow_id']))
 project=ROOT.parent.parent
 for folder in ['references','assets','scripts']:
  shutil.copytree(project/folder,OUT/'local'/folder,dirs_exist_ok=True)
 for fn in ['SKILL.md','README.md','使用说明.md','规则修改日志.md']:
  shutil.copy2(project/fn,OUT/'local'/fn)
 save('complete',{'base':BASE,'date':'2026-10-03','tables':len(ts['tables']),'workflows':len(ws['items'])})
 print('COMPLETE',flush=True)
if __name__=='__main__': main()
