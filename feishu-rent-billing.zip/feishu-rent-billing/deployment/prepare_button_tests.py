import json,uuid
import build_tables as b
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg'
for key,file,wid in [('W2','W2-manual.json','wkfzT8Wu6CkNX0m1'),('W3','W3.json',None)]:
 s=(b.ROOT/file).read_text()
 for path in (b.ROOT/'acceptance').glob('table-*.json'):
  source=json.loads((b.ROOT/path.name).read_text());dest=json.loads(path.read_text());df={f['name']:f['id'] for f in dest['fields']}
  for f in source['fields']:
   if f['name'] in df:s=s.replace(f['id'],df[f['name']])
 p=json.loads(s)
 for n in p['steps']:
  if n['type']=='LarkMessageAction':
   text=n['data']['content']
   n['type']='SetRecordAction';n['data']={'table_name':'计费批次' if key=='W2' else '费用明细','ref_info':{'step_id':'出账' if key=='W2' else '调整'},'field_values':[{'field_name':'处理说明' if key=='W2' else '调整原因','value':text}]}
 path=b.ROOT/'acceptance'/f'{key}-button-created.json'
 if path.exists():wid=json.loads(path.read_text())['workflow_id']
 if wid:
  b.call('+workflow-get','--workflow-id',wid)
  r=b.call('+workflow-update','--workflow-id',wid,'--json',json.dumps({'title':p['title'],'steps':p['steps']},ensure_ascii=False))
 else:
  p['client_token']=str(uuid.uuid4());r=b.call('+workflow-create','--json',json.dumps(p,ensure_ascii=False));wid=r['workflow_id']
 path.write_text(json.dumps({'workflow_id':wid},ensure_ascii=False))
 b.call('+workflow-enable','--workflow-id',wid);print('BUTTON_READY',key,wid,flush=True)
