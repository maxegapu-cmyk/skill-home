import json
import build_tables as bt
bt.BASE='KIlVbVz54aO4sKsJpkncmj7Knyc'
from build_workflows import Workflow,val,ref
s=bt.call('+table-get','--table-id','接续验收')
f={x['name']:x['id'] for x in s['fields']}
w=Workflow('验收：工作流之间接续')
w.step('接续','SetRecordTrigger',{'table_name':'接续验收','field_watch_info':[{'field_name':'轮次','operator':'is','value':[val(2,'number')]}],'trigger_control_list':[]},'加一')
w.set('加一','接续验收',{'轮次':ref('接续.'+f['下一轮'])},source='接续')
r=bt.call('+workflow-create','--json',json.dumps(w.save('cross-continuation-test'),ensure_ascii=False))
(bt.ROOT/'cross-continuation-created.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(r['workflow_id'],flush=True)
print(bt.call('+workflow-enable','--workflow-id',r['workflow_id']),flush=True)
print(bt.call('+record-batch-update','--table-id','接续验收','--json',json.dumps({'record_id_list':['reczz28IZfqV4xBG'],'patch':{'轮次':1}})),flush=True)
