import json
from build_tables import ROOT,call
from manual_batch_fields import plan,formula
pending=next(f['expression'] for f in plan['租约'] if f['name']=='当前批次待处理')
for table,f in [('租约',formula('当前批次待处理',f'IF({pending},"是","否")')),('租约',formula('待处理顺序','IF([当前批次待处理]="是",[租约].COUNTIF(AND(CurrentValue.[当前批次待处理]="是",CurrentValue.[租约序号值]<=[租约序号值])),0)'))]:
 call('+field-update','--table-id',table,'--field-id',f['name'],'--json',json.dumps(f,ensure_ascii=False),'--yes','--i-have-read-guide')
for table,rank in [('租约','待处理顺序'),('抄表记录','待计费顺序')]:
 f=formula('本轮可处理',f'IF(AND([{rank}]>0,[{rank}]<=5),"是","否")')
 call('+field-create','--table-id',table,'--json',json.dumps(f,ensure_ascii=False),'--i-have-read-guide')
 (ROOT/f'table-{table}.json').write_text(json.dumps(call('+table-get','--table-id',table),ensure_ascii=False,indent=2))
