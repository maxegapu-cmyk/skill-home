import json,copy
from build_workflows import Workflow,val,ref,cond,group,filtr,FIELDS,w2,ROOT,call

def save(w,key):
 # The API rejects IfElseBranch inside loops; SwitchBranch supports this nesting.
 for n in w.steps:
  if n['type']=='IfElseBranch':
   check=n['data']['condition']; links=n['children']['links']
   n['type']='SwitchBranch'
   n['data']={'mode':'exclusive','no_match_action':'fail','child_branch_list':[{'name':'满足条件','condition':check},{'name':'其他情况','condition':group(cond(ref('出账','计费批次','批次号'),'isNotEmpty'))}]}
   n['children']['links']=[{'kind':'case','label':f'branch_{i+1}','to':v['to'],'desc':'满足条件' if i==0 else '其他情况'} for i,v in enumerate(links)]
 return w.save(key)

def build():
 original={s['id']:s for s in w2()['steps']}
 B=lambda f:ref('出账','计费批次',f)
 def worker(title,phase,entry):
  w=Workflow(title)
  w.step('出账','SetRecordTrigger',{'table_name':'计费批次','field_watch_info':[{'field_name':'状态','operator':'is','value':[val('生成中','option')]}],'trigger_control_list':[],'condition_list':[filtr(('处理阶段','is',val(phase,'option')))]},entry)
  return w
 def graft(w,entry,stops=()):
  seen={s['id'] for s in w.steps}
  def visit(id):
   if id is None or id in stops or id in seen:return
   s=copy.deepcopy(original[id]);seen.add(id)
   if s['type']=='Loop':s['data']['max_loop_times']=5
   if s['type'] in ('FindRecordAction','SetRecordAction') and s['data'].get('table_name')=='抄表记录':
    for c in s['data'].get('filter_info',{}).get('conditions',[]):
     if c['field_name']=='序号值':c['field_name']='计费序号'
   if id in ['上层按承担方','下层按承担方']:
    s['data']['condition']=group(cond(ref('逐段.item','抄表记录',id[:2]+'费用类型'),'is',val('水电')))
   if id=='交接有天数':s['data']['condition']=group(cond(ref('交接逐租约.item','租约','退租月在住天数'),'isNot',val('0')))
   if s['type']=='AddRecordAction' and s['data']['table_name']=='费用明细':
    for fv in s['data']['field_values']:
     if fv['field_name'] in ['抄表序号','水量','电量','水价','电价','公摊总额','调整前金额','调整差额']:
      fv['field_name']+='快照'
      for value in fv['value']:
       if value['value_type']=='number':value.update(value_type='text',value=str(value['value']))
     if fv['field_name']=='期间起':
      fv['field_name']='期间起文本'
      fv['value']=[ref('逐段.item','抄表记录','上次日期文本')]
     elif fv['field_name']=='所属月份':
      fv['field_name']='所属月份文本'
      v=fv['value'][0]['value']
      if v.startswith('$.出账.'):
       fv['value']=[B('月份键'),val('-01')]
      else:
       source=v.rsplit('.',1)[0][2:]
       fv['value']=[ref(source,'租约','退租月份键'),val('-01')]

   if s.get('next') in stops:s['next']=None
   w.steps.append(s)
   visit(s.get('next'))
   for x in s.get('children',{}).get('links',[]):visit(x['to'])
  visit(entry)
 def node(w,id):return next(s for s in w.steps if s['id']==id)
 def wait(w,id,phase,reason):
  w.set(id,'计费批次',{'状态':val('待继续','option'),'处理阶段':val(phase,'option'),'处理说明':reason},source='出账')
 payloads={}
 w=Workflow('W2 开始或继续处理')
 w.step('出账','ButtonTrigger',{'button_type':'buttonField','table_name':'计费批次'},'校验')
 w.branch('校验',group(cond(B('校验结果'),'is',val('通过'))),'开始','拦截')
 w.set('开始','计费批次',{'状态':val('生成中','option'),'处理说明':'正在处理，请勿重复点击。完成本轮后查看处理说明。'},source='出账')
 w.msg('拦截',[val('本轮未开始：'),B('校验结果')])
 payloads['W2']=save(w,'W2-manual')
 w=worker('W2A 每轮水电最多5条','水电','是否水电')
 graft(w,'是否水电',('选择批次',))
 node(w,'是否水电')['next']='查剩余水电'

 w.find('查剩余水电','抄表记录',['序号值'],filtr(('记录状态','is',val('有效','option')),('计费状态','is',val('未计费','option')),('计费序号','isLessEqual',B('截止抄表序号'))),'水电完成判断')
 w.branch('水电完成判断',group(cond(ref('查剩余水电.recordNum'),'isGreater',val(0,'number'))),'继续水电','进入租约')
 wait(w,'继续水电','水电','本轮水电已处理。还有抄表记录，请点击“开始或继续处理”。')
 wait(w,'进入租约','租约','水电阶段已完成。请点击“开始或继续处理”，生成租约费用。')
 payloads['W2A']=save(w,'W2A')
 w=worker('W2B 每轮租约最多5条','租约','选择批次')
 graft(w,'选择批次',('收入调整','月结上层房东'))
 node(w,'选择批次')['next']=None
 node(w,'仅调整')['next']='进入收尾'
 for prefix in ['月结','交接']:
  n=node(w,prefix+'查租约')
  criteria=filtr(('归档','is',val('在用','option')),('最近处理批次','isNot',B('批次号'))) if prefix=='月结' else filtr(('退租结算状态','is',val('待出账','option')),('退租抄表序号','isLessEqual',B('截止抄表序号')),('最近处理批次','isNot',B('批次号')))
  n['data']['filter_info']=criteria
  node(w,prefix+'逐租约')['next']=prefix+'查剩余'
  w.find(prefix+'查剩余','租约',['租约编号'],criteria,prefix+'完成判断')
  w.branch(prefix+'完成判断',group(cond(ref(prefix+'查剩余.recordNum'),'isGreater',val(0,'number'))),prefix+'继续租约',prefix+'进入收尾')
  wait(w,prefix+'继续租约','租约','本轮租约费用已处理。还有租约，请点击“开始或继续处理”。')
  wait(w,prefix+'进入收尾','收尾','租约费用已完成。请点击“开始或继续处理”，核算房东费用并生成报告。')
  if prefix=='月结':node(w,'月结当月在住')['data']['condition']=group(cond(ref('月结逐租约.item','租约','当前批次待处理'),'is',val('是')))

  lp=prefix+'逐租约'
  if prefix=='月结':node(w,'月结当月在住')['next']='月结记录进度'
  else:node(w,'交接标记已出')['next']='交接记录进度'
  w.set(prefix+'记录进度','租约',{'最近处理批次':B('批次号')},filter=filtr(('租约编号','is',ref(lp+'.item','租约','租约编号'))))
 wait(w,'进入收尾','收尾','租约费用已完成。请点击“开始或继续处理”，核算房东费用并生成报告。')
 payloads['W2B']=save(w,'W2B')
 w=worker('W2C 收尾并生成报告','收尾','需要房东公摊')
 w.branch('需要房东公摊',group(cond(B('批次类型'),'containsAny',[val('月底结算','option'),val('公摊补充','option')])),'月结上层房东','跳过房东','收入调整')
 graft(w,'月结上层房东')
 w.set('跳过房东','计费批次',{'处理说明':'正在汇总调整费用。'},source='出账')
 graft(w,'收入调整')
 node(w,'收入调整')['data']['max_set_record_num']=5
 node(w,'收入调整')['next']='查剩余调整'
 w.find('查剩余调整','费用明细',['唯一键'],filtr(('费用类型','is',val('调整','option')),('批次号','isEmpty',None)),'调整完成判断')
 w.branch('调整完成判断',group(cond(ref('查剩余调整.recordNum'),'isGreater',val(0,'number'))),'继续调整','完成')
 wait(w,'继续调整','收尾','还有调整费用待入账，请点击“开始或继续处理”。')
 node(w,'完成')['data']['field_values'] += [{'field_name':'处理阶段','value':[val('完成','option')]},{'field_name':'处理说明','value':[val('本批次全部完成。请核对报告。')]}]
 payloads['W2C']=save(w,'W2C')
 return payloads

if __name__=='__main__':
 import sys
 for key,payload in build().items():
  print(key,'nodes',len(payload['steps']),flush=True)
  assert len(payload['steps'])<=100
  if '--create' in sys.argv:
   saved=ROOT/f'{key}-manual-created.json'
   if saved.exists():continue
   result=call('+workflow-create','--json',json.dumps(payload,ensure_ascii=False))
   saved.write_text(json.dumps(result,ensure_ascii=False,indent=2))
   print(key,result['workflow_id'],flush=True)
