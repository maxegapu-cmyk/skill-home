import json
import build_tables as b
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg'
OUT=b.ROOT/'acceptance'
def create(table,records,key):
 fields=list(dict.fromkeys(k for row in records for k in row))
 p={'fields':fields,'rows':[[row.get(f) for f in fields] for row in records]}
 r=b.call('+record-batch-create','--table-id',table,'--json',json.dumps(p,ensure_ascii=False))
 (OUT/f'{key}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));return r
if __name__=='__main__':
 if not (OUT/'tenancies-A.json').exists():
  records=[]
  for name,floor,date,seq,rent,wprice,eprice,end,out in [('张三','上层','2026-07-01',1,1500,5,.8,None,None),('李四','下层','2026-07-01',1,1200,4.5,.75,'2026-08-16',2),('王五','下层','2026-08-25',3,1300,5,.85,None,None)]:
   records.append({'租客姓名':name,'楼层':floor,'入住日期':date,'入住抄表序号':seq,'月租':rent,'垃圾费':20,'管理费':30,'水价':wprice,'电价':eprice,'退租日期':end,'退租抄表序号':out,'退租结算状态':'待出账' if end else '未退租','归档':'在用'})
  print(create('租约',records,'tenancies-A')['record_id_list'],flush=True)
 if not (OUT/'readings-A.json').exists():
  rows=[]
  for i,(date,event,tw,te,uw,ue) in enumerate([('2026-08-01','首次建档',338,11240.82,120,5000.5),('2026-08-16','下层退租',348,11400.82,125,5080.5),('2026-08-25','下层入住',352,11460.82,127,5120.5),('2026-09-01','月度抄表',360,11560.82,131,5180.5)]):
   rows.append({'抄表日期':date,'登记事由':event,'总水表读数':tw,'总电表读数':te,'上层水表读数':uw,'上层电表读数':ue,'核对状态':'已核对','记录状态':'有效','计费状态':'起点不计费' if i==0 else '未计费'})
  print(create('抄表记录',rows,'readings-A')['record_id_list'],flush=True)
 if not (OUT/'B1.json').exists():print(create('计费批次',[{'标题':'验收A-B1','批次类型':'交接结算','截止抄表序号':2,'状态':'草稿','处理阶段':'水电'}],'B1')['record_id_list'],flush=True)
 for t,fields in [('抄表记录',['序号值','校验结果','上层水量','上层电量','下层水量','下层电量','段上层在住','段下层在住','本轮可处理']),('计费批次',['批次号','校验结果','状态','处理阶段'])]:
  args=[x for f in fields for x in ['--field-id',f]]
  r=b.call('+record-list','--table-id',t,'--format','json',*args)
  (OUT/f'initial-{t}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)); print(t,r,flush=True)
