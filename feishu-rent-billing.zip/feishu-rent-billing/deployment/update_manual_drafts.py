import json
import build_tables as b
from build_manual_workflows import build
ROOT=b.ROOT
payloads=build()
for key in __import__('sys').argv[1:] or ['W2A','W2B','W2C']:
 p=payloads[key]
 b.BASE='Hcgobn2S4aaXHNs0bHBcOOFWnWc'
 wid=json.loads((ROOT/f'{key}-manual-created.json').read_text())['workflow_id']
 b.call('+workflow-get','--workflow-id',wid)
 b.call('+workflow-update','--workflow-id',wid,'--json',json.dumps({'title':p['title'],'steps':p['steps']},ensure_ascii=False))
 b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg'
 s=json.dumps(p,ensure_ascii=False)
 for path in (ROOT/'acceptance').glob('table-*.json'):
  source=json.loads((ROOT/path.name).read_text());dest=json.loads(path.read_text());df={f['name']:f['id'] for f in dest['fields']}
  for f in source['fields']:
   if f['name'] in df:s=s.replace(f['id'],df[f['name']])
 p=json.loads(s)
 for n in p['steps']:
  if n['type']=='LarkMessageAction':
   n['type']='SetRecordAction';n['data']={'table_name':'计费批次','ref_info':{'step_id':'出账'},'field_values':[{'field_name':'处理说明','value':[{'value_type':'text','value':'验收：报告已完成'}]}]}
 wid=json.loads((ROOT/f'acceptance/{key}-created.json').read_text())['workflow_id']
 b.call('+workflow-get','--workflow-id',wid)
 b.call('+workflow-update','--workflow-id',wid,'--json',json.dumps({'title':p['title'],'steps':p['steps']},ensure_ascii=False))
 b.call('+workflow-enable','--workflow-id',wid)
 print('UPDATED',key,flush=True)
