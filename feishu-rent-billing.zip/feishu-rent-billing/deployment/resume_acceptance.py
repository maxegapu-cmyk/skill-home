import json,time
import build_tables as b
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg';OUT=b.ROOT/'acceptance'
def patch(table,ids,values):return b.call('+record-batch-update','--table-id',table,'--json',json.dumps({'record_id_list':ids,'patch':values},ensure_ascii=False))
# Keep failed samples under a separate batch instead of deleting them.
r=b.call('+record-list','--table-id','费用明细','--format','json','--field-id','唯一键','--filter-json',json.dumps({'logic':'and','conditions':[['批次号','==','P1']]},ensure_ascii=False))
for rid,row in zip(r['record_id_list'],r['data']):
 patch('费用明细',[rid],{'唯一键':'失败样本|'+row[0],'批次号':'失败样本'})
readings=json.loads((OUT/'readings-A.json').read_text())['record_id_list']
patch('抄表记录',[readings[1]],{'计费状态':'未计费','计费批次号':None})
patch('抄表记录',[readings[2]],{'新租客姓名':'王五'})
patch('计费批次',['reczz28Ia8rQgS5g'],{'处理阶段':'水电','状态':'待继续'})
for key in ['W2A','W2B','W2C']:
 time.sleep(1.5)
 wid=json.loads((OUT/f'{key}-created.json').read_text())['workflow_id']
 print(b.call('+workflow-enable','--workflow-id',wid),flush=True)
