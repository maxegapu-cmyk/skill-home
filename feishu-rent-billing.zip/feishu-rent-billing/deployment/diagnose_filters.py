import json,uuid
import build_tables as b
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg'
from build_workflows import Workflow,val,ref,filtr
w=Workflow('验收：查找条件诊断')
w.step('出账','SetRecordTrigger',{'table_name':'计费批次','field_watch_info':[{'field_name':'标题'}],'trigger_control_list':[]},'A')
base=[('计费状态','is',val('未计费','option'))]
for label,extra,next in [('A',[],'B'),('B',[('本轮可处理','is',val('是'))],'C'),('C',[('序号值','isLessEqual',ref('出账','计费批次','截止抄表序号'))],'D'),('D',[('抄表序号','isLessEqual',ref('出账','计费批次','截止抄表序号'))],'结果')]:
 w.find(label,'抄表记录',['抄表序号'],filtr(*(base+extra)),next)
w.set('结果','计费批次',{'处理说明':[val('A='),ref('A.recordNum'),val(' B='),ref('B.recordNum'),val(' C='),ref('C.recordNum'),val(' D='),ref('D.recordNum')]},source='出账')
p=w.save('filter-diagnosis')
r=b.call('+workflow-create','--json',json.dumps(p,ensure_ascii=False))
(b.ROOT/'acceptance/filter-diagnosis-created.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(b.call('+workflow-enable','--workflow-id',r['workflow_id']))
print(b.call('+record-batch-update','--table-id','计费批次','--json',json.dumps({'record_id_list':['reczz28Ia8rQgS5g'],'patch':{'标题':'验收A-B1-诊断'}},ensure_ascii=False)))
