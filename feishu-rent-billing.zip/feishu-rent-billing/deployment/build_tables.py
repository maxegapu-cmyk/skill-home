import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = 'Hcgobn2S4aaXHNs0bHBcOOFWnWc'
ENV = dict(os.environ, LARKSUITE_CLI_NO_UPDATE_NOTIFIER='1', LARKSUITE_CLI_NO_SKILLS_NOTIFIER='1')

def call(command, *args):
    p = subprocess.run(['lark-cli', 'base', command, '--base-token', BASE, '--as', 'user', *args], capture_output=True, text=True, env=ENV)
    raw = p.stdout if p.returncode == 0 else p.stderr or p.stdout
    try:
        result = json.loads(raw)
    except Exception:
        raise SystemExit(raw)
    if not result.get('ok'):
        raise SystemExit(json.dumps(result, ensure_ascii=False))
    return result['data']

def schema():
    tables = {}
    table = None
    for line in (ROOT.parent/'references/data-model.md').read_text().splitlines():
        m = re.match(r'## 表 \d：([^（]+)', line)
        if m:
            table = m[1]; tables[table] = []
        if not table or not line.startswith('| ') or line.startswith('| 字段'):
            continue
        cells = [x.strip() for x in line.split('|')][1:4]
        if len(cells) != 3:
            continue
        name, kind, desc = cells
        if name.startswith('★') or kind in ('按钮', 'AI 字段（可选）'):
            continue
        for name in re.split(r' / |、|，', name):
            f = {'name': name, 'description': desc.replace('⚙', '由工作流填写。')}
            if kind.startswith('自动编号'):
                rules = ([{'type': 'text', 'text': 'Z'}] if table == '租约' else []) + [{'type': 'incremental_number', 'length': 1}]
                f.update(type='auto_number', style={'rules': rules})
            elif kind.startswith('数字'):
                precision = 0 if '整数' in kind or name in ('抄表序号', '截止抄表序号') else 4 if name in ('水价','电价','空置水价','空置电价') else 2
                f.update(type='number', style={'type':'plain', 'precision':precision})
            elif kind.startswith('单选：'):
                choices = kind.split('：',1)[1].split(' / ')
                f.update(type='select', multiple=False, options=[{'name':x} for x in choices])
                default = {'退租结算状态':'未退租','归档':'在用','核对状态':'待核对','记录状态':'有效','状态': '未收到' if table == '公摊账单' else '草稿'}.get(name)
                if default: f['default_value'] = [default]
            elif kind.startswith('日期'):
                f.update(type='datetime', style={'format':'yyyy-MM-dd HH:mm' if '含时间' in kind and '不含时间' not in kind else 'yyyy-MM-dd'})
            elif kind == '附件': f['type'] = 'attachment'
            elif kind == '人员': f.update(type='user', multiple=False)
            elif kind in ('文本', '多行文本', '电话'):
                f.update(type='text', style={'type':'phone' if kind=='电话' else 'plain'})
            else:
                continue
            tables[table].append(f)
    return tables

if __name__ == '__main__':
    schemas = schema()
    (ROOT/'storage-schema.json').write_text(json.dumps(schemas,ensure_ascii=False,indent=2))
    existing = call('+table-list')
    (ROOT/'tables-before.json').write_text(json.dumps(existing,ensure_ascii=False,indent=2))
    known = {x['name']: x['id'] for x in existing['tables']}
    for name, fields in schemas.items():
        if name not in known:
            data = call('+table-create','--name',name,'--fields',json.dumps(fields,ensure_ascii=False))
            (ROOT/f'created-{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
            print('CREATED',name,flush=True)
        else:
            print('EXISTS',name,flush=True)
    data = call('+table-list')
    (ROOT/'tables.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    for item in data['tables']:
        if item['name'] in schemas:
            snap = call('+table-get','--table-id',item['id'])
            (ROOT/f'table-{item["name"]}.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2))
    print('DONE',flush=True)
