import json
import re
from build_tables import ROOT, call

def split_args(text):
    depth = 0; quoted = False; start = 0; parts=[]
    for i,c in enumerate(text):
        if c == '"': quoted = not quoted
        if quoted: continue
        if c == '(': depth += 1
        elif c == ')': depth -= 1
        elif c == ',' and depth == 0:
            parts.append(text[start:i].strip()); start=i+1
    parts.append(text[start:].strip())
    return parts

def normalize(expr):
    while 'LET(' in expr:
        start=expr.index('LET('); depth=1; quoted=False; end=start+4
        while depth:
            c=expr[end]
            if c=='"': quoted=not quoted
            if not quoted:
                if c=='(': depth+=1
                elif c==')': depth-=1
            end+=1
        args=split_args(expr[start+4:end-1])
        assert len(args)==3, args
        name,value,body=args
        chunks=re.split(r'("[^"]*"|\[[^\]]*\])',body)
        for i in range(0,len(chunks),2):
            chunks[i]=re.sub(r'(?<![\w])'+re.escape(name)+r'(?![\w])','('+value+')',chunks[i])
        expr=expr[:start]+''.join(chunks)+expr[end:]
    chunks=re.split(r'("[^"]*")',expr)
    for i in range(0,len(chunks),2):
        chunks[i]=chunks[i].replace('<>','!=')
    return ''.join(chunks)

def plan():
    result={}; table=None; inside=False; block=[]
    for line in (ROOT.parent/'references/formulas.md').read_text().splitlines():
        m=re.match(r'## [一二三四五]、(.+)',line)
        if m: table=m[1]; result[table]=[]
        if line=='```':
            if inside and table:
                text='\n'.join(block)
                matches=list(re.finditer(r'^([^\s=]+)\s*=\s*',text,re.M))
                for i,m in enumerate(matches):
                    end=matches[i+1].start() if i+1<len(matches) else len(text)
                    expr=text[m.end():end].strip()
                    result[table].append({'type':'formula','name':m[1],'expression':normalize(expr)})
            inside=not inside; block=[]
        elif inside: block.append(line)
    twin={'段上层租约数','段上层在住','段上层租约','本次后上层在住','上层承担方','上层费用类型','上层水价用','上层电价用','上层费用键','上层需出账'}
    expanded=[]
    for f in result['抄表记录']:
        expanded.append(f)
        if f['name'] in twin:
            expanded.append({k:v.replace('上层','下层') for k,v in f.items()})
    result['抄表记录']=expanded
    return result

if __name__=='__main__':
    import sys
    formulas=plan()
    (ROOT/'formula-schema.json').write_text(json.dumps(formulas,ensure_ascii=False,indent=2))
    if '--plan' in sys.argv:
        print({t:len(fs) for t,fs in formulas.items()}); raise SystemExit(0)
    for table in ['公摊账单','租约','抄表记录','费用明细','计费批次']:
        snap=call('+table-get','--table-id',table)
        known={x['name'] for x in snap['fields']}
        for f in formulas[table]:
            if f['name'] in known: continue
            response=call('+field-create','--table-id',snap['table']['id'],'--json',json.dumps(f,ensure_ascii=False),'--i-have-read-guide')
            (ROOT/'last-field.json').write_text(json.dumps(response,ensure_ascii=False,indent=2))
            print('CREATED',table,f['name'],flush=True)
        snap=call('+table-get','--table-id',table)
        (ROOT/f'table-{table}.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2))
    print('DONE',flush=True)
