import json,time
from build_tables import call as raw_call,ROOT
def call(*args):
 time.sleep(1.3)
 return raw_call(*args)
fields={
'租约':['租约编号','租客姓名','楼层','在住状态','入住日期','退租日期','月租','垃圾费','管理费','水价','电价','押金','资料检查','联系电话','入住抄表序号','退租抄表序号','退租结算状态','归档','备注'],
'抄表记录':['抄表序号','抄表日期','登记事由','总水表读数','总电表读数','上层水表读数','上层电表读数','核对状态','校验结果','计费状态','记录状态','总水表照片','总电表照片','上层水表照片','上层电表照片','新租客姓名','新租客电话','备注'],
'计费批次':['批次序号','标题','批次类型','所属月份','截止抄表序号','状态','处理阶段','处理说明','校验结果','租客应收合计','房东承担合计','报告','生成时间'],
'费用明细':['唯一键','批次号','费用类型','楼层','承担方','所属月份','期间起','期间止','本行金额','有效金额','报告行','提示','拟调整为','调整原因'],
'公摊账单':['所属月份','账期开始','账期结束','公摊合计','状态','截图','备注'],
}
views={
'租约':[('押金待补',[['归档','intersects',['在用']],['押金','empty']])],
'抄表记录':[('待核对',[['核对状态','intersects',['待核对']]]),('有问题',[['校验结果','non_empty']])],
'计费批次':[('待继续',[['状态','intersects',['待继续']]]),('草稿',[['状态','intersects',['草稿']]]),('已生成报告',[['状态','intersects',['已生成','已发送']]])],
'费用明细':[('报警',[['提示','non_empty']])]
}
for table,names in fields.items():
 snap=call('+table-get','--table-id',table)
 known={x['name']:x['id'] for x in snap.get('views',snap['table'].get('views',[]))}
 if not known:
  print('NO VIEWS',table,snap.keys());raise SystemExit(1)
 for name,cs in views.get(table,[]):
  if name not in known:
   r=call('+view-create','--table-id',table,'--json',json.dumps({'name':name},ensure_ascii=False))
   snap=call('+table-get','--table-id',table);known={x['name']:x['id'] for x in snap.get('views',snap['table'].get('views',[]))}
  call('+view-set-filter','--table-id',table,'--view-id',known[name],'--json',json.dumps({'logic':'and','conditions':cs},ensure_ascii=False))
 for name,vid in known.items():
  if name=='抄表登记':continue
  call('+view-set-visible-fields','--table-id',table,'--view-id',vid,'--json',json.dumps({'visible_fields':names},ensure_ascii=False))
 print('VIEWS',table,flush=True)
 time.sleep(1)
