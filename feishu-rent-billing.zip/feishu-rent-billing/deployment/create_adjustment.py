import json
from build_workflows import w3,call,ROOT
p=w3()
for n in p['steps']:
 if n['type']=='AddRecordAction':
  for f in n['data']['field_values']:
   if f['field_name'] in ['调整前金额','调整差额']:f['field_name']+='快照'
result=call('+workflow-create','--json',json.dumps(p,ensure_ascii=False))
(ROOT/'W3-created.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
(ROOT/'W3.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
print(result['workflow_id'])
