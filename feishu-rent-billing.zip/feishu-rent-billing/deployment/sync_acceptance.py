import json,time,uuid
from pathlib import Path
import build_tables as b
ROOT=b.ROOT; OUT=ROOT/'acceptance';OUT.mkdir(exist_ok=True)
b.BASE='VDMMbTzxma57SIsSC3ociKkOnJg'
raw_call=b.call
def paced(*args):
 time.sleep(1.2)
 return raw_call(*args)
b.call=paced
tables=['系统参数','公摊账单','租约','抄表记录','费用明细','计费批次']
keys=['name','type','expression','description','style','multiple','options','default_value']
# First create snapshot storage fields and helpers, then update old fields.
for table in tables:
 wanted=json.loads((ROOT/f'table-{table}.json').read_text())
 actual=b.call('+table-get','--table-id',table);known={f['name']:f for f in actual['fields']}
 for f in wanted['fields']:
  if f['name'] not in known:
   obj={k:v for k,v in f.items() if k in keys}
   b.call('+field-create','--table-id',table,'--json',json.dumps(obj,ensure_ascii=False),'--i-have-read-guide')
 for f in wanted['fields']:
  old=known.get(f['name'])
  if old and (old['type']!=f['type'] or (f['type']=='formula' and old['expression']!=f['expression']) or (f['type']=='select' and [x['name'] for x in old.get('options',[])]!=[x['name'] for x in f.get('options',[])])):
   obj={k:v for k,v in f.items() if k in keys}
   b.call('+field-update','--table-id',table,'--field-id',old['id'],'--json',json.dumps(obj,ensure_ascii=False),'--yes','--i-have-read-guide')
 actual=b.call('+table-get','--table-id',table)
 (OUT/f'table-{table}.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2))
 print('SYNC',table,flush=True)
replace={}
for t in tables:
 src=json.loads((ROOT/f'table-{t}.json').read_text());dest=json.loads((OUT/f'table-{t}.json').read_text());df={f['name']:f['id'] for f in dest['fields']}
 replace.update({f['id']:df[f['name']] for f in src['fields']})
for key in ['W2A','W2B','W2C']:
 if (OUT/f'{key}-created.json').exists():continue
 s=(ROOT/f'{key}.json').read_text()
 for old,new in replace.items():s=s.replace(old,new)
 p=json.loads(s);p['client_token']=str(uuid.uuid4())
 for n in p['steps']:
  if n['type']=='LarkMessageAction':
   n['type']='SetRecordAction';n['data']={'table_name':'计费批次','ref_info':{'step_id':'出账'},'field_values':[{'field_name':'处理说明','value':[{'value_type':'text','value':'验收：报告已完成'}]}]}
 r=b.call('+workflow-create','--json',json.dumps(p,ensure_ascii=False))
 (OUT/f'{key}-created.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
 b.call('+workflow-enable','--workflow-id',r['workflow_id'])
 print('TEST ENABLED',key,r['workflow_id'],flush=True)
