"""CHG-001 专项核算验收。飞书验收另存 deployment/chg-001。"""
import copy
import json
import unittest
from pathlib import Path
from rent_calc import Ledger, LedgerError, money


def fixture(day=15, direct=True):
    def t(i,f):
        return dict(id=i,name=i,floor=f,move_in='2026-10-01',rent=3100,garbage=0,mgmt=0,water_price=5,elec_price=1)
    def r(seq,dt,event,w,uw,e,ue,**kw):
        return dict(seq=seq,date=dt,event=event,total_water=w,up_water=uw,total_elec=e,up_elec=ue,**kw)
    a=r(1,'2026-10-01','首次建档',100,40,1000,400,after={'上层':'A','下层':'C'})
    b=r(2,'2026-10-15','上层退租',110,44,1100,440,handover_intent='当天有人入住' if day==15 else '转为空置')
    c=r(3,f'2026-10-{day:02d}','上层入住',110 if direct else 113,44 if direct else 45,
        1100 if direct else 1115,440 if direct else 445,tenant='B',handover_from=2,same_instant=direct)
    z=r(4,'2026-11-01','月度抄表',120,48,1200,480)
    return dict(rule_version='v1.0.2',tenancies=[t('A','上层'),t('B','上层'),t('C','下层')],
                readings=[a,b,c,z],public_bills=[dict(month='2026-10',status='已确认',amount=62)],
                batches=[dict(id='B1',type='月底结算',month='2026-10',cutoff=4)])

class HandoverTests(unittest.TestCase):
    def run_ledger(self,data):
        lg=Ledger(data)
        for b in lg.batches: lg.run_batch(b)
        return lg
    def test_T01_direct(self):
        x=fixture();lg=self.run_ledger(x)
        for key,v in {'水电|2|上层':60,'固定费|A|2026-10':1400,'固定费|B|2026-10':1700,
                      '公摊实|2026-10|A':14,'公摊实|2026-10|B':17,'公摊实|2026-10|C':31}.items():
            self.assertEqual(lg.rows[key].amount,money(v))
        self.assertFalse(any(r.amount for r in lg.rows.values() if r.key.startswith('水电|3|')))
        for k in ['total_water','up_water','total_elec','up_elec']:x['readings'][2].pop(k)
        self.assertEqual(self.run_ledger(x).rows['固定费|B|2026-10'].amount,money(1700))
    def test_T02_vacancy(self):
        lg=self.run_ledger(fixture(18,False))
        self.assertEqual(lg.rows['水电|3|上层'].amount,money('8.02'))
        self.assertEqual(lg.rows['水电|3|上层'].payer,'房东')
        for t in ['A','B']:self.assertEqual(lg.rows[f'固定费|{t}|2026-10'].amount,money(1400))
        self.assertEqual(lg.rows['公摊实|2026-10|上层|房东'].amount,money(3))
    def test_T03_same_day_gap(self):
        lg=self.run_ledger(fixture(15,False))
        self.assertEqual(lg.rows['水电|3|上层'].amount,money('8.02'))
        self.assertEqual(lg.rows['固定费|B|2026-10'].amount,money(1700))
    def test_T04_month_boundary(self):
        x=fixture(1,False);x['readings'][1]['date']='2026-10-31'
        x['readings'][2]['date']='2026-11-01';x['readings'][3]['date']='2026-12-01'
        x['batches']=[dict(id='O',type='月底结算',month='2026-10',cutoff=2),
                      dict(id='N',type='月底结算',month='2026-11',cutoff=4)]
        lg=self.run_ledger(x)
        self.assertEqual(lg.rows['固定费|A|2026-10'].amount,money(3000))
        self.assertEqual(lg.rows['固定费|B|2026-11'].amount,money(3100))
    def test_T05_missing_wrong_link(self):
        x=fixture();x['readings'].pop(2)
        lg=Ledger(x)
        with self.assertRaisesRegex(LedgerError,'待补录'):lg.run_batch(x['batches'][0])
        self.assertEqual(lg.rows,{})
        for ref in [1,4,999]:
            y=fixture();y['readings'][2]['handover_from']=ref
            with self.assertRaises(LedgerError):Ledger(y)
        x['readings'][1].update(handover_intent='转为空置',previous_handover_intent='当天有人入住')
        with self.assertRaisesRegex(LedgerError,'原因'):Ledger(x)
        x['readings'][1]['handover_reason']='房东确认新租客取消入住'
        x['tenancies']=[t for t in x['tenancies'] if t['id']!='B']
        self.run_ledger(x)
    def test_T06_idempotent_retry(self):
        x=fixture();lg=self.run_ledger(x);before=copy.deepcopy(lg.rows)
        self.assertEqual(lg.run_batch(x['batches'][0]),[]);self.assertEqual(lg.rows,before)
        self.assertEqual(self.run_ledger(x).rows,before)
        x['readings'].append(copy.deepcopy(x['readings'][2]))
        with self.assertRaisesRegex(LedgerError,'重复'):Ledger(x)
    def test_T07_readings_and_order(self):
        for k,val in [('up_elec',None),('total_water',90)]:
            x=fixture();x['readings'][1][k]=val
            x['readings'][2][k]=val
            with self.assertRaises(LedgerError):self.run_ledger(x)
        x=fixture();middle=copy.deepcopy(x['readings'][1]);middle.update(seq=3,event='月度抄表');middle.pop('handover_intent')
        x['readings'][2]['seq']=4;x['readings'][3]['seq']=5;x['readings'].insert(2,middle)
        with self.assertRaisesRegex(LedgerError,'相邻'):Ledger(x)
        x['readings'][3]['same_instant']=False;x['batches'][0]['cutoff']=5
        self.run_ledger(x)
    def test_T08_historical(self):
        cases=json.loads((Path(__file__).parent.parent/'assets/test-ledger.json').read_text())
        # Original full regression remains the calculator's --selftest.
        self.assertTrue(cases)
        original=cases['cases'][3]['data']
        split=copy.deepcopy(original);split['rule_version']='v1.0.2'
        pos=next(i for i,r in enumerate(split['readings']) if r['event'].endswith('换租'))
        old=split['readings'][pos];cut=old['seq'];fl=old['event'][:2]
        incoming=copy.deepcopy(old)
        old.update(event=fl+'退租',handover_intent='当天有人入住');old.pop('tenant')
        incoming.update(event=fl+'入住',seq=cut+1,handover_from=cut,same_instant=True)
        for r in split['readings'][pos+1:]:r['seq']+=1
        split['readings'].insert(pos+1,incoming)
        for b in split['batches']:
            if b.get('cutoff',0)>=cut:b['cutoff']+=1
        def totals(lg):
            out={}
            for r in lg.rows.values():
                key=(r.payer,r.kind,r.period if r.kind not in ('水电','空置水电') else '')
                out[key]=out.get(key,0)+r.amount
            return out
        self.assertEqual(totals(self.run_ledger(original)),totals(self.run_ledger(split)))
        x=fixture();x['readings'][1].update(event='上层换租',tenant='B',historical=True)
        x['readings'][1].pop('handover_intent');x['readings'].pop(2)
        lg=self.run_ledger(x)
        self.assertEqual(lg.rows['固定费|B|2026-10'].amount,money(1700))
        x['readings'][1].pop('historical')
        with self.assertRaisesRegex(LedgerError,'新登记'):Ledger(x)
    def test_T09_reconcile_actual_occupancy(self):
        # This comparison needs the landlord's actual roster; the ledger cannot infer it.
        x=fixture();x['readings'].pop(2);x['readings'][1]['handover_intent']='转为空置'
        lg=Ledger(x);actual={'上层':'B','下层':'C'}
        self.assertNotEqual(lg.readings[-1]['_after'],actual)
        self.assertEqual(Ledger(fixture()).readings[-1]['_after'],actual)

if __name__=='__main__':unittest.main(verbosity=2)
