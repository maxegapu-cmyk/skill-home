# feishu-rent-billing v1.0.2

上下两层出租屋的飞书多维表格收租计费技能。入口是 `SKILL.md`。

- 规则（唯一来源）：references/billing-rules.md
- 修改日志：[规则修改日志.md](规则修改日志.md)（方案、过程、验收及生效记录；草案不直接用于计费）
- 搭建：references/data-model.md → references/formulas.md → references/automation-setup.md
- 核算器：`python3 scripts/rent_calc.py --selftest`（已通过）；`python3 scripts/rent_calc.py 你的数据.json`
- 验收：references/test-cases.md

已验证：核算器的规则与算例 A/B/C 的人工手算逐行一致，重复运行不新增，缺上层读数与读数倒退会被拦截。
CHG-001 的飞书专项及 A/B/C/D 回归证据见 deployment/chg-001/acceptance/。照片自动识别未配置。

CHG-001：新登记已取消换租，分别登记退租和入住。执行过程、验收和回退证据见 `deployment/chg-001/`。

2026-10-03 CHG-001 的验收范围及结果以 `deployment/chg-001/acceptance/` 和规则修改日志为准；此前日期的验证说明属于历史记录。
