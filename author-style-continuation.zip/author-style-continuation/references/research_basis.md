# 设计依据

本技能每一步都对应一个开源项目里验证过的做法，或论文里的一个结论。需要向用户解释“为什么这样做”时可以引用这里。项目星数为 2026 年 10 月的大致数字。

## 一、开源项目：借鉴了什么

| 项目 | 做什么 | 本技能借鉴的做法 |
|---|---|---|
| WeClone（xming521/WeClone，约 1.8 万星） | 用聊天记录微调出“数字分身” | 连发消息按时间窗合并（2 分钟）、问答按时间窗配对、用 Presidio 打码隐私 → `chat_parser.py` 的合并与打码 |
| dot-skill / colleague-skill（titanwings，约 2.3 万星） | 从消息里“蒸馏”同事或伴侣的 Claude 技能 | 每条结论必须引原话、证据不足标“原材料不足”、用户手动修正层优先 → 文风卡的例句要求与“用户修正”一节 |
| Chat-Haruhi-Suzumiya（LC1332） | 用原著台词让模型扮演角色 | 检索与当前场景最相近的原著对白片段作为示例，要求模型沿用原著说法 → `find_anchors.py` 与第 7 步 |
| RoleLLM | 角色扮演数据与方法 | 用 BM25 取最相关的若干段对话作为示例 → 锚点检索用 BM25，免嵌入模型 |
| Character-LLM / CoSER | 训练与评测扮演既有角色 | “保护性场景”让角色不知道不该知道的事；场景中区分想法、动作、台词 → 声音卡的“知识边界”、节拍表的信息变化 |
| RecurrentGPT | 循环生成长文本 | 每段写完更新记忆，先说删什么再说加什么 → 账本的滚动记忆 |
| Re3 / DOC（yangkevin2） | 长故事生成 | 规划 → 起草 → 重排 → 编辑，按人物属性检查矛盾 → 第 6–9 步顺序与连贯性清单 |
| Dramatron（DeepMind） | 分层生成剧本 | 梗概 → 人物 → 节拍 → 场景 → 对白，逐层展开 → 节拍表 |
| LongWriter（THUDM） | 长文写作 | 先列段落要点和字数预算，再按段写，防止压缩 → 节拍字数预算 |
| AI_NovelGenerator / InkOS / oh-story-claudecode | 中文长篇写作工具与 Claude 技能 | 人物状态表、伏笔账本（埋设/强化/回收）、导入已有小说重建状态、文风指纹 + 文风说明、疲劳词与禁用句式表 → 剧情账本模板与去 AI 味清单 |
| written-voice-replication | 复刻个人文风的 Claude 技能 | 虚词、句法、标点做成带均值和波动的数值目标 → `style_stats.py compare` 的 z 分数 |
| stylo / faststylometry | 文体计量学工具 | Burrows' Delta：用高频虚词的标准化频率衡量作者距离 → compare 报告里的“虚词距离” |
| antislop-sampler / slop-score（sam-paech） | 检测与抑制模型“口癖” | 与人类基线比较找过度使用的词；单独统计“not X but Y”句式 → `ai_flavor_lint.py` 与“原文从未用过的片段” |
| Humanizer-zh / humanizer | 去 AI 痕迹的提示词技能 | 中文 AI 写作标记（不是…而是…、值得注意的是、破折号泛滥、三段排比）；改完再问“哪里一看就是 AI 写的” → 混读测试 |
| EQ-Bench creative-writing-bench | 创意写作评测 | 负面评分项：说教、紫色文笔、对白无力、结尾积极得不相称、转变缺乏铺垫 → 去 AI 味清单第 9 节 |
| SillyTavern 角色卡 | 角色扮演前端 | Author's Note 放在离生成位置最近处，影响最大 → 锚点的放置顺序 |

## 二、论文：结论与对应设计

**模型模仿普通作者的文风很吃力**
- *Catch Me If You Can? Not Yet: LLMs Still Struggle to Imitate the Implicit Writing Styles of Everyday Authors*（2025）：给模型若干篇作者样本做上下文模仿，结构化文体（新闻、邮件）尚可，随意的个人写作（博客、论坛）模仿得差。→ 不依赖模型“自然学会”，用数字目标和锚点约束。
- *Low-Resource Authorship Style Transfer: Can Non-Famous Authors Be Imitated?*（Patel 等，STYLL）：先把文本改成中性表达，再结合作者样本和风格描述改写，对非知名作者有效。→ 第 8 步的“两遍法”。

**模型写作的趋同与套路**
- *Art or Artifice? Large Language Models and the False Promise of Creativity*（Chakrabarty 等，CHI 2024）：按托兰斯创造力测试改编的指标，模型写的故事通过率远低于职业作家。
- *Can AI Writing Be Salvaged? Mitigating Idiosyncrasies and Improving Human-AI Alignment in the Writing Process through Edits*（Chakrabarty 等，CHI 2025）：专业作家编辑模型文本时，问题集中在陈词滥调、多余的解释说明、紫色文笔、句子结构差、缺少具体细节、用词别扭等几类。→ 去 AI 味清单的分类。
- *Does Writing with Language Models Reduce Content Diversity?*（Padmakumar & He，ICLR 2024）与 *Generative AI enhances individual creativity but reduces the collective diversity of novel content*（Doshi & Hauser，Science Advances 2024）：模型参与写作会让不同人的作品彼此更相似。→ 每次写作都锚定到原文，而非模型的默认文风。

**长上下文中的位置效应**
- *Lost in the Middle: How Language Models Use Long Contexts*（Liu 等，TACL 2024）：放在长上下文开头和结尾的信息利用得最好，中间最差。→ 锚点和文风要点放在上下文末尾、紧挨生成位置。
- *Many-Shot In-Context Learning*（Agarwal 等，2024）：示例从少量增加到大量，多数任务持续变好。→ 锚点给足 1500–3000 字，聊天人物给 40 组示例。

**先规划再写作**
- *Re3: Generating Longer Stories With Recursive Reprompting and Revision*（Yang 等，EMNLP 2022）；*DOC: Improving Long Story Coherence With Detailed Outline Control*（Yang 等，ACL 2023）；*Co-Writing Screenplays and Theatre Scripts with Language Models*（Dramatron，Mirowski 等，CHI 2023）；*RecurrentGPT*（Zhou 等，2023）；*LongWriter*（Bai 等，2024）：分层规划、滚动记忆、字数预算都能提升长文本的连贯性和长度控制。

**角色一致性**
- *Character-LLM: A Trainable Agent for Role-Playing*（Shao 等，EMNLP 2023）：角色要“不知道”超出其经历的事。
- *RoleLLM*（Wang 等，2023）与 *ChatHaruhi*（Li 等，2023）：检索原作台词作为示例能明显提升角色说话的还原度。
- *CoSER: Coordinating LLM-Based Persona Simulation of Established Roles*（Wang 等，2025）：用书中场景的“给定情境”（动机、想法、动作、台词分开）训练和评测角色扮演。

**自我修订与自评**
- *Self-Refine*（Madaan 等，NeurIPS 2023）：模型给自己反馈再修改，多数任务有提升，两三轮后收益递减。→ 修订最多两轮。
- *Can Large Language Models Identify Authorship?*（Huang 等，2024）：模型直接判断作者归属能力有限，提示中加入语言学特征后有改善。→ 自检先看脚本统计，再做阅读判断。
- Burrows 的 Delta 方法（2002）：高频虚词的频率是区分作者最稳定的特征之一。→ `style_stats.py` 以虚词为核心指纹。

## 三、本技能没有采用的做法

- **微调**（WeClone、StyleTunedLM、Character-LLM）：效果好，但需要训练环境，超出提示词技能的范围。用户有条件时可以另行考虑。
- **采样层干预**（antislop-sampler、DOC 的控制器）：需要读取逐词概率，接口不支持；改为写完后检查。
- **嵌入向量检索**（ChatHaruhi）：需要嵌入模型；改用不依赖外部服务的 BM25，对中文用字符二元组，效果足够。
