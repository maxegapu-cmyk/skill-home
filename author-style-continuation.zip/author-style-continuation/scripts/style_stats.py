# -*- coding: utf-8 -*-
"""文风指纹统计与对比。

用法：
  python style_stats.py profile 原文.txt [--json fingerprint.json]
      输出原文的量化文风画像（Markdown），可选同时保存 JSON。
  python style_stats.py compare 原文.txt 草稿.txt [--json report.json]
      把原文切成与草稿等长的若干块，统计每项指标在原文内部的自然波动，
      再看草稿落在哪里（z 分数）。|z|>2 视为明显偏离，并给出修改提示。

只依赖 Python 标准库；装了 jieba 会自动用它分词。
"""
import argparse
import json
import re
import statistics
import sys
from collections import Counter

import textutil as tu

FUNC_ZH = [
    "的", "了", "着", "过", "地", "得", "是", "在", "有", "就", "也", "都", "还", "又",
    "再", "才", "却", "便", "而", "但", "可", "只", "竟", "倒", "呢", "吧", "啊", "吗",
    "嘛", "呀", "罢", "么", "之", "其", "乃", "亦", "则", "已", "所", "被", "把", "将",
    "让", "给", "从", "向", "对", "于", "和", "与", "这", "那", "些", "个", "不", "没",
    "很", "太", "最", "更", "只是", "不过", "然而", "于是", "仿佛", "似乎", "好像", "忽然",
    "突然", "竟然", "终于", "已经", "一直", "还是", "因为", "所以", "如果", "虽然", "大约",
    "便是", "倒是", "罢了", "而已", "一个", "什么", "怎么", "这样", "那样", "自己",
]
FUNC_EN = [
    "the", "a", "an", "and", "but", "or", "of", "to", "in", "on", "at", "for", "with",
    "as", "by", "from", "that", "this", "it", "he", "she", "they", "i", "you", "we",
    "was", "were", "is", "be", "had", "have", "not", "no", "so", "then", "just", "only",
    "very", "all", "there", "what", "which", "who", "when", "if", "would", "could", "said",
]
FIGURATIVE_ZH = ["像", "仿佛", "好像", "如同", "宛如", "犹如", "似的", "一般", "恍如", "好似"]
FIGURATIVE_EN = [r"\blike\b", r"\bas if\b", r"\bas though\b", r"\bseemed\b"]
CONTRAST_ZH = [
    r"不是[^。！？!?\n]{1,40}?而是",
    r"并(?:不是|非)[^。！？!?\n]{1,30}?[，,]\s*(?:而)?是",
    r"(?<![不并])是[^。！？!?\n，,]{1,20}?而不是",
    r"不像[^。！？!?\n]{1,30}?(?:倒|反而|更)像",
    r"与其说[^。！？!?\n]{1,30}?不如说",
    r"没有[^。！？!?\n]{1,30}?[，,]\s*但也",
    r"不(?:仅仅|只)是[^。！？!?\n]{1,30}?(?:更是|而是)",
]
CONTRAST_EN = [
    r"\bnot (?:just |only |merely )?[^.?!\n]{1,40}?, but\b",
    r"\bit(?:'s| is| was)n'?t [^.?!\n]{1,30}?[,;—-]+ it(?:'s| is| was)\b",
    r"\bisn't [^.?!\n]{1,30}?[,;—-]+ it's\b",
]
PUNCT_KEYS = {
    "，": "逗号", "。": "句号", "！": "感叹号", "？": "问号", "…": "省略号", "—": "破折号",
    "；": "分号", "：": "冒号", "、": "顿号", "（": "括号",
}
PUNCT_EN = {",": "comma", ".": "period", "!": "exclaim", "?": "question", ";": "semicolon",
            ":": "colon", "—": "dash", "(": "paren"}


def _count_func(text, cjk):
    out = {}
    if cjk:
        for w in FUNC_ZH:
            out[w] = text.count(w)
    else:
        words = Counter(w.lower() for w in tu.LATIN_WORD_RE.findall(text))
        for w in FUNC_EN:
            out[w] = words.get(w, 0)
    return out


def profile(text, cjk=None, with_lists=True):
    if cjk is None:
        cjk = tu.is_cjk_text(text)
    total = max(tu.units(text, cjk), 1)
    paras = tu.split_paragraphs(text)
    sents = []
    para_lens, sents_per_para = [], []
    for _, p in paras:
        ss = tu.split_sentences(p)
        sents.extend(ss)
        para_lens.append(tu.units(p, cjk))
        sents_per_para.append(len(ss))
    sent_lens = [tu.units(s, cjk) for s in sents]
    sent_lens_nz = [x for x in sent_lens if x > 0] or [0]
    short_t, long_t = (10, 40) if cjk else (8, 30)
    sd = tu.describe(sent_lens_nz)
    n_sent = max(len(sents), 1)

    quotes, quote_styles = tu.dialogue_spans(text)
    dlg_units = sum(tu.units(q, cjk) for q in quotes)
    dlg_paras = sum(1 for _, p in paras if tu.dialogue_spans(p)[0])
    narration = text
    for q in quotes:
        narration = narration.replace(q, " ")

    ends = Counter()
    for s in sents:
        t = s.rstrip("".join(tu.CLOSERS))
        last = t[-1] if t else ""
        if last in "！!":
            ends["!"] += 1
        elif last in "？?":
            ends["?"] += 1
        elif last == "…":
            ends["…"] += 1
    commas = text.count("，") + (text.count(",") if not cjk else 0)

    m = {}
    m["sent_mean"] = sd["mean"]
    m["sent_median"] = sd["median"]
    m["sent_cv"] = round(sd["std"] / sd["mean"], 3) if sd["mean"] else 0
    m["sent_short_share"] = round(sum(1 for x in sent_lens_nz if x <= short_t) / len(sent_lens_nz), 3)
    m["sent_long_share"] = round(sum(1 for x in sent_lens_nz if x >= long_t) / len(sent_lens_nz), 3)
    m["comma_per_sent"] = round(commas / n_sent, 3)
    pdsc = tu.describe(para_lens)
    m["para_mean"] = pdsc["mean"]
    m["para_single_sent_share"] = round(
        sum(1 for x in sents_per_para if x <= 1) / max(len(sents_per_para), 1), 3
    )
    m["dialogue_ratio"] = round(dlg_units / total, 3)
    m["dialogue_para_share"] = round(dlg_paras / max(len(paras), 1), 3)
    m["exclaim_share"] = round(ends["!"] / n_sent, 3)
    m["question_share"] = round(ends["?"] / n_sent, 3)
    m["ellipsis_end_share"] = round(ends["…"] / n_sent, 3)
    per1k = 1000.0 / total
    if cjk:
        for ch, name in PUNCT_KEYS.items():
            cnt = text.count(ch)
            if ch == "…":
                cnt = len(re.findall(r"…+", text)) + len(re.findall(r"\.{3,}", text))
            if ch == "—":
                cnt = len(re.findall(r"—+", text))
            if ch == "（":
                cnt = text.count("（") + text.count("(")
            m["punct_" + name] = round(cnt * per1k, 2)
        m["figurative_per1k"] = round(sum(narration.count(w) for w in FIGURATIVE_ZH) * per1k, 2)
        m["contrast_per10k"] = round(sum(len(re.findall(p, text)) for p in CONTRAST_ZH) * per1k * 10, 2)
        m["pron_first_per1k"] = round(narration.count("我") * per1k, 2)
        m["pron_third_per1k"] = round((narration.count("他") + narration.count("她")) * per1k, 2)
    else:
        for ch, name in PUNCT_EN.items():
            m["punct_" + name] = round(text.count(ch) * per1k, 2)
        low = narration.lower()
        m["figurative_per1k"] = round(sum(len(re.findall(p, low)) for p in FIGURATIVE_EN) * per1k, 2)
        m["contrast_per10k"] = round(sum(len(re.findall(p, text, re.I)) for p in CONTRAST_EN) * per1k * 10, 2)
        words = [w.lower() for w in tu.LATIN_WORD_RE.findall(narration)]
        wc = Counter(words)
        m["pron_first_per1k"] = round((wc["i"] + wc["me"] + wc["my"]) * per1k, 2)
        m["pron_third_per1k"] = round((wc["he"] + wc["she"] + wc["him"] + wc["her"]) * per1k, 2)
    toks = tu.tokens(text, cjk)
    m["mattr"] = round(tu.mattr(toks, 300 if len(toks) < 3000 else 500), 4)
    func = _count_func(text, cjk)
    for w, c in func.items():
        m["fw_" + w] = round(c * per1k, 3)

    res = {
        "lang": "zh" if cjk else "en",
        "units": total,
        "paragraphs": len(paras),
        "sentences": len(sents),
        "sentence_len": sd,
        "paragraph_len": pdsc,
        "quote_styles": dict(quote_styles),
        "metrics": m,
    }
    if with_lists:
        res.update(_lists(text, narration, sents, quotes, cjk))
    return res


def _lists(text, narration, sents, quotes, cjk):
    out = {}
    stop = set("的了着过地得是在有就也都还又再才却便而但可只这那个不没我你他她它们和与把被一上下来去说道")
    if cjk:
        grams = tu.char_ngrams(text, 2, 4)
        out["top_ngrams"] = tu.prune_ngrams(grams, min_count=3, top=40, stop_chars=stop)
        openers = Counter()
        for s in sents:
            core = re.sub(r"^[“”「」『』\"'（(—…\s]+", "", s)
            run = re.match(r"[一-鿿]{2}", core)
            if run:
                openers[run.group(0)] += 1
        out["sentence_openers"] = openers.most_common(15)
        pre = len(re.findall(r"(?:说|道|问|答|喊|叫|嚷|笑)[了着]?[：:，,]\s*[“「『]", text))
        post = len(re.findall(r"[”」』][^“「『\n]{0,8}?(?:说|道|问|答|喊|笑)", text))
        out["dialogue_tags"] = {"quotes": len(quotes), "tag_before": pre, "tag_after": post}
    else:
        words = [w.lower() for w in tu.LATIN_WORD_RE.findall(text)]
        bigr = Counter(zip(words, words[1:]))
        fw = set(FUNC_EN)
        out["top_ngrams"] = [
            (" ".join(b), n) for b, n in bigr.most_common(400) if not (b[0] in fw and b[1] in fw)
        ][:40]
        openers = Counter()
        for s in sents:
            ws = tu.LATIN_WORD_RE.findall(s)
            if ws:
                openers[ws[0]] += 1
        out["sentence_openers"] = openers.most_common(15)
    return out


# ---------------------------------------------------------------- reporting
LABELS = {
    "sent_mean": "平均句长", "sent_median": "句长中位数", "sent_cv": "句长离散度(CV)",
    "sent_short_share": "短句占比", "sent_long_share": "长句占比",
    "comma_per_sent": "每句逗号数", "para_mean": "平均段长", "para_single_sent_share": "单句段占比",
    "dialogue_ratio": "对白字数占比", "dialogue_para_share": "含对白段落占比",
    "exclaim_share": "感叹句占比", "question_share": "问句占比", "ellipsis_end_share": "省略号收尾句占比",
    "figurative_per1k": "比喻标记/千字", "contrast_per10k": "对比否定句/万字",
    "pron_first_per1k": "叙述中“我”/千字", "pron_third_per1k": "叙述中“他/她”/千字",
    "mattr": "用词多样性(MATTR)",
}
HINTS = {
    "sent_mean": ("句子偏长：拆开长句，学原文的断句节奏", "句子偏短：合并碎句，原文的句子更舒展"),
    "sent_median": ("典型句子偏长", "典型句子偏短"),
    "sent_cv": ("长短句落差比原文大", "句长太均匀，缺少原文那种长短交错"),
    "sent_short_share": ("短句过多，节奏发碎", "短句太少，原文爱用短句收束"),
    "sent_long_share": ("长句过多", "长句太少"),
    "comma_per_sent": ("一句里串了太多分句", "分句太少，原文爱用逗号连缀"),
    "para_mean": ("段落偏长，按原文习惯多分段", "段落偏碎，原文段落更厚"),
    "para_single_sent_share": ("单句成段太多（网文腔/AI腔常见）", "单句段太少"),
    "dialogue_ratio": ("对白比原文多，补叙述和动作", "对白比原文少，让人物开口"),
    "dialogue_para_share": ("对白段落偏多", "对白段落偏少"),
    "exclaim_share": ("感叹句偏多，情绪写得太满", "感叹句偏少"),
    "question_share": ("问句偏多", "问句偏少"),
    "ellipsis_end_share": ("省略号收尾太多", "省略号收尾偏少"),
    "figurative_per1k": ("比喻偏多：删掉大半，只留最贴的", "比喻偏少"),
    "contrast_per10k": ("对比否定句式偏多：改成直接陈述", "—"),
    "pron_first_per1k": ("第一人称偏多，检查视角", "第一人称偏少，检查视角"),
    "pron_third_per1k": ("“他/她”主语过密，可省略或换称呼", "“他/她”偏少"),
    "mattr": ("用词比原文更花哨多样，换回原文常用的朴素词", "用词重复度高于原文"),
}


def _label(k):
    if k in LABELS:
        return LABELS[k]
    if k.startswith("punct_"):
        return "标点·" + k[6:] + "/千字"
    if k.startswith("fw_"):
        return "虚词「" + k[3:] + "」/千字"
    return k


def report_profile(p):
    m = p["metrics"]
    L = []
    L.append(f"# 文风指纹（{'中文' if p['lang']=='zh' else 'English'}，约 {p['units']} 字/词）\n")
    L.append(f"段落 {p['paragraphs']} · 句子 {p['sentences']}\n")
    sl, pl = p["sentence_len"], p["paragraph_len"]
    L.append("## 节奏")
    L.append(f"- 句长：均值 {sl['mean']}，中位 {sl['median']}，P10–P90 {sl['p10']}–{sl['p90']}，CV {m['sent_cv']}")
    L.append(f"- 短句占比 {m['sent_short_share']:.0%}，长句占比 {m['sent_long_share']:.0%}，每句逗号 {m['comma_per_sent']}")
    L.append(f"- 段长：均值 {pl['mean']}，中位 {pl['median']}，P90 {pl['p90']}；单句段占比 {m['para_single_sent_share']:.0%}")
    L.append("## 对白")
    L.append(f"- 对白字数占比 {m['dialogue_ratio']:.0%}，含对白段落 {m['dialogue_para_share']:.0%}；引号样式 {p.get('quote_styles')}")
    if "dialogue_tags" in p:
        L.append(f"- 引语标签：{p['dialogue_tags']}（tag_before=“X说：”式，tag_after=“……”X说式）")
    L.append("## 句末与标点")
    L.append(f"- 感叹句 {m['exclaim_share']:.0%}，问句 {m['question_share']:.0%}，省略号收尾 {m['ellipsis_end_share']:.0%}")
    pun = {k[6:]: v for k, v in m.items() if k.startswith("punct_")}
    L.append("- 每千字：" + "，".join(f"{k} {v}" for k, v in pun.items()))
    L.append("## 修辞与视角")
    L.append(f"- 比喻标记 {m['figurative_per1k']}/千字；对比否定句 {m['contrast_per10k']}/万字")
    L.append(f"- 叙述中第一人称 {m['pron_first_per1k']}/千字，第三人称 {m['pron_third_per1k']}/千字；用词多样性 {m['mattr']}")
    fws = sorted(((k[3:], v) for k, v in m.items() if k.startswith("fw_")), key=lambda x: -x[1])
    L.append("## 虚词（每千字，前 25）")
    L.append("- " + "，".join(f"{w} {v}" for w, v in fws[:25]))
    if p.get("top_ngrams"):
        L.append("## 高频片段（口头禅/惯用语候选，需人工甄别）")
        L.append("- " + "，".join(f"{g}×{n}" for g, n in p["top_ngrams"]))
    if p.get("sentence_openers"):
        L.append("## 常见句首")
        L.append("- " + "，".join(f"{g}×{n}" for g, n in p["sentence_openers"]))
    return "\n".join(L)


def _floor(k, mu, size):
    """Minimum std so that z is measured in sensible units: for rates, one
    occurrence per chunk; for lengths/shares, a small relative band."""
    if k.endswith("per10k"):
        return max(10000.0 / size, abs(mu) * 0.08)
    if k.startswith(("fw_", "punct_")) or k.endswith("per1k"):
        return max(1000.0 / size, abs(mu) * 0.08)
    if k in ("sent_mean", "sent_median", "para_mean"):
        return max(abs(mu) * 0.08, 0.5)
    return max(abs(mu) * 0.08, 0.03)


def chunk_text(text, size, cjk):
    paras = tu.split_paragraphs(text)
    chunks, buf, cur = [], [], 0
    for _, p in paras:
        buf.append(p)
        cur += tu.units(p, cjk)
        if cur >= size:
            chunks.append("\n".join(buf))
            buf, cur = [], 0
    if buf and cur >= size * 0.6:
        chunks.append("\n".join(buf))
    return chunks


def compare(src_text, draft_text):
    cjk = tu.is_cjk_text(src_text)
    src_units = tu.units(src_text, cjk)
    d_units = tu.units(draft_text, cjk)
    lo = 800 if cjk else 500
    size = min(max(d_units, lo), 6000)
    if src_units / size < 5:
        size = max(150 if cjk else 100, src_units // 5)
    chunks = chunk_text(src_text, size, cjk)
    dp = profile(draft_text, cjk, with_lists=False)["metrics"]
    rows = []
    if len(chunks) >= 3:
        cps = [profile(c, cjk, with_lists=False)["metrics"] for c in chunks]
        for k, v in dp.items():
            vals = [c.get(k, 0) for c in cps]
            mu = statistics.fmean(vals)
            sd = statistics.pstdev(vals)
            sd_eff = max(sd, _floor(k, mu, size))
            z = (v - mu) / sd_eff
            if max(vals) == 0 and v > 0:
                # never used by the author: flag when the draft uses it repeatedly
                per = 10000.0 if k.endswith("per10k") else 1000.0
                cnt = v * d_units / per
                if k.startswith(("fw_", "punct_")) or k.endswith(("per1k", "per10k")):
                    z = "NEW" if cnt >= (1 if k.startswith("contrast") else 2) - 1e-9 else z
            rows.append((k, mu, sd, v, z))
        # function-word delta (Burrows-style) vs in-sample chunk baseline
        fkeys = [k for k in dp if k.startswith("fw_")]
        fkeys.sort(key=lambda k: -statistics.fmean([c.get(k, 0) for c in cps]))
        fkeys = fkeys[:30]
        stats = {}
        for k in fkeys:
            vals = [c.get(k, 0) for c in cps]
            mu_k = statistics.fmean(vals)
            stats[k] = (mu_k, max(statistics.pstdev(vals), _floor(k, mu_k, size)))

        def delta(mm):
            return statistics.fmean(abs((mm.get(k, 0) - mu) / sd) for k, (mu, sd) in stats.items())

        base = sorted(delta(c) for c in cps)
        d_delta = delta(dp)
        p50 = base[len(base) // 2]
        p90 = base[min(len(base) - 1, int(len(base) * 0.9))]
    else:
        # source too short to estimate variation: fall back to ratios
        sp = profile(src_text, cjk, with_lists=False)["metrics"]
        for k, v in dp.items():
            mu = sp.get(k, 0)
            z = None
            rate = k.startswith(("fw_", "punct_")) or k.endswith(("per1k", "per10k"))
            if mu == 0 and v > 0 and rate:
                per = 10000.0 if k.endswith("per10k") else 1000.0
                if v * d_units / per >= (1 if k.startswith("contrast") else 2) - 1e-9:
                    z = "NEW"
            elif mu > 0 and not k.startswith("fw_"):
                ratio = v / mu
                if ratio > 1.6 or ratio < 0.6:
                    z = "UP" if ratio > 1 else "DOWN"
            rows.append((k, mu, None, v, z))
        d_delta = p50 = p90 = None

    # n-grams frequent in draft but absent from source = model's own tics
    if cjk:
        dg = tu.char_ngrams(draft_text, 2, 4)
        sg_text = src_text
        cand = Counter({g: n for g, n in dg.items() if n >= 2 and g not in sg_text})
        foreign = tu.prune_ngrams(cand, min_count=2, top=20, stop_chars=set("的了着是在一不我你他她这那"))
    else:
        dw = [w.lower() for w in tu.LATIN_WORD_RE.findall(draft_text)]
        sl = src_text.lower()
        bg = Counter(" ".join(b) for b in zip(dw, dw[1:]))
        foreign = [(g, n) for g, n in bg.most_common(200) if n >= 2 and g not in sl][:20]
    return {
        "lang": "zh" if cjk else "en",
        "source_units": src_units,
        "draft_units": d_units,
        "chunks": len(chunks),
        "chunk_size": size,
        "rows": rows,
        "fw_delta": d_delta,
        "fw_delta_p50": p50,
        "fw_delta_p90": p90,
        "foreign_ngrams": foreign,
    }


def report_compare(r):
    L = [f"# 草稿 vs 原文 文风对比\n"]
    if r["chunks"] >= 3:
        L.append(f"原文约 {r['source_units']} 字，草稿约 {r['draft_units']} 字；原文切成 {r['chunks']} 块（每块约 {r['chunk_size']} 字）估计自然波动。\n")
    else:
        L.append(f"原文约 {r['source_units']} 字，太短，无法估计自然波动；下面按比例粗略比较（偏离超过 60% 才标出）。\n")
    if r["fw_delta"] is not None:
        verdict = "✓ 在原文自然波动范围内" if r["fw_delta"] <= r["fw_delta_p90"] else "✗ 虚词分布整体偏离原文（模型自己的腔调在冒头）"
        L.append(f"**虚词距离（Burrows Delta 思路）**：草稿 {r['fw_delta']:.2f}；原文各块中位 {r['fw_delta_p50']:.2f}、P90 {r['fw_delta_p90']:.2f} → {verdict}\n")
    flagged, ok = [], []
    for k, mu, sd, v, z in r["rows"]:
        if z is None:
            ok.append(f"| {_label(k)} | {mu:.3g} | {v:.3g} | – |")
            continue
        if z in ("UP", "DOWN"):
            hint = HINTS.get(k, ("比原文高", "比原文低"))[0 if z == "UP" else 1]
            flagged.append((abs(v / mu - 1) if mu else 9, f"| {_label(k)} | {mu:.3g} | {v:.3g} | {'偏高' if z == 'UP' else '偏低'} | {hint} |"))
            continue
        if z == "NEW":
            flagged.append((99, f"| {_label(k)} | 原文从未出现 | {v:.3g} | 新增 | 原作者不用，删掉或换成原文的说法 |"))
            continue
        if k.startswith("fw_") and mu == 0 and v == 0:
            continue
        zs = f"{z:+.1f}" if abs(z) < 10 else (">+9" if z > 0 else "<-9")
        line = f"| {_label(k)} | {mu:.3g} ± {sd:.2g} | {v:.3g} | {zs} |"
        if abs(z) > 2 and not (k.startswith("fw_") and abs(v - mu) < 1.0):
            hint = ""
            if k in HINTS:
                hint = HINTS[k][0] if z > 0 else HINTS[k][1]
            elif k.startswith("fw_"):
                hint = "用得比原文多" if z > 0 else "用得比原文少"
            elif k.startswith("punct_"):
                hint = "这个标点比原文多" if z > 0 else "这个标点比原文少"
            flagged.append((abs(z), line + f" {hint} |"))
        else:
            ok.append(line)
    if flagged:
        flagged.sort(reverse=True)
        L.append("## 需要修改（|z| > 2，按偏离程度排序）")
        L.append("| 指标 | 原文 | 草稿 | z | 提示 |\n|---|---|---|---|---|")
        L.extend(x for _, x in flagged)
    else:
        L.append("## 没有明显偏离的指标 ✓")
    if r["foreign_ngrams"]:
        L.append("\n## 草稿里重复、原文从未出现的片段（逐个检查：新人名和新情节词可以忽略，套话和修饰语多半是模型口癖）")
        L.append("- " + "，".join(f"{g}×{n}" for g, n in r["foreign_ngrams"]))
    L.append("\n<details><summary>其余指标</summary>\n")
    L.append("| 指标 | 原文 | 草稿 | z |\n|---|---|---|---|")
    L.extend(ok)
    L.append("\n</details>")
    L.append("\n注：草稿越短，统计越不稳；500 字以下的草稿只看“需要修改”里 |z|>3 的项。")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("profile")
    a.add_argument("source")
    a.add_argument("--json")
    b = sub.add_parser("compare")
    b.add_argument("source")
    b.add_argument("draft")
    b.add_argument("--json")
    args = ap.parse_args(argv)
    if args.cmd == "profile":
        p = profile(tu.read_text(args.source))
        print(report_profile(p))
        if args.json:
            json.dump(p, open(args.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    else:
        r = compare(tu.read_text(args.source), tu.read_text(args.draft))
        print(report_compare(r))
        if args.json:
            json.dump(r, open(args.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
