# -*- coding: utf-8 -*-
"""聊天记录解析：统一格式、清洗打码、按说话人统计说话习惯、抽取示例对话。

用法：
  python chat_parser.py 聊天记录.txt|.csv|.json [--target 小王] [--out chat_out]
        [--me 我] [--other 对方] [--merge-window 120] [--no-mask] [--samples 40]

支持的输入（自动识别）：
  * 纯文本  “名字: 消息” / “名字：消息”
  * 带时间  “2024-01-01 12:00:00 名字: 消息”、“[12:30] 名字：消息”
  * 头行式  “2024-01-01 12:00:00 名字” 下一行起是消息（QQ 导出、常见微信导出 txt）
  * CSV     含 发送者/内容/时间 列（如 WeChatMsg/留痕 导出：StrContent、IsSender、
            NickName、CreateTime 等；IsSender=1 记为 --me 指定的名字）
  * JSON    Telegram Desktop 导出（messages 列表）或 [{speaker,text,time}] 列表
列名识别不到时可用 --col-speaker / --col-text / --col-time 指定。

输出（--out 目录）：
  chat.jsonl          清洗后的逐条消息 {time, speaker, text, media}
  speakers.md         每个说话人的说话习惯画像（数字 + 口头禅候选）
  samples_<目标>.md   目标说话人的示例对话（对方一句 → 目标回应），用于写人物声音卡
  stats.json          全部统计数据
默认对手机号、邮箱、身份证号、银行卡号打码，网址替换为[链接]。
"""
import argparse
import csv
import datetime as dt
import json
import math
import os
import re
import sys
from collections import Counter, defaultdict

import textutil as tu

DATE = r"\d{4}[-/.年]\d{1,2}[-/.月]\d{1,2}日?"
CLOCK = r"\d{1,2}:\d{2}(?::\d{2})?"
INLINE_TIMED = re.compile(
    rf"^\[?(?P<time>(?:{DATE}\s*)?{CLOCK})\]?\s*(?P<name>[^:：\[\]\d][^:：\[\]]{{0,29}}?)\s*[:：]\s?(?P<text>.*)$"
)
HEADER = re.compile(rf"^(?P<time>{DATE}\s+{CLOCK})\s+(?P<name>\S.{{0,40}}?)\s*$")
HEADER_NAME_FIRST = re.compile(rf"^(?P<name>[^\d\s:：][^:：]{{0,30}}?)\s+(?P<time>{DATE}\s+{CLOCK})\s*$")
PLAIN = re.compile(r"^(?P<name>[^:：\s\d\[][^:：]{0,20}?)\s*[:：]\s?(?P<text>.+)$")

MEDIA = [
    ("图片", r"^\[(?:图片|照片|photo|image|图像)\]$"),
    ("表情包", r"^\[(?:表情|动画表情|表情包|sticker|自定义表情|emoji)\]$"),
    ("语音", r"^\[(?:语音|voice)[^\]]*\]$"),
    ("视频", r"^\[(?:视频|video)[^\]]*\]$"),
    ("文件", r"^\[(?:文件|file)[^\]]*\]$"),
    ("链接", r"^\[(?:链接|分享|link|卡片|小程序)[^\]]*\]$"),
    ("红包转账", r"^\[(?:红包|转账|收款)[^\]]*\]$"),
    ("位置", r"^\[(?:位置|location)[^\]]*\]$"),
    ("通话", r"^\[(?:语音通话|视频通话|通话)[^\]]*\]$"),
]
MEDIA = [(n, re.compile(p, re.I)) for n, p in MEDIA]
SYSTEM = re.compile(
    r"撤回了一条消息|拍了拍|加入了群聊|邀请.{0,30}加入了群聊|以上是打招呼的内容|你已添加了|"
    r"现在可以开始聊天了|修改群名为|开启了朋友验证|消息已发出，但被对方拒收"
)
WX_TYPES = {"1": None, "3": "图片", "34": "语音", "43": "视频", "47": "表情包", "48": "位置",
            "49": "链接", "50": "通话", "10000": "系统", "10002": "系统"}
EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF\U0001F900-\U0001F9FF]"
)
BRACKET_EMO = re.compile(
    r"\[(?!(?:链接|邮箱|证件号|卡号|手机号|图片|表情包|语音|视频|文件|位置|红包转账|通话)\])"
    r"[一-鿿A-Za-z]{1,6}\]"
)
LAUGH = re.compile(r"哈{2,}|h{3,}|H{3,}|2333+|嘿嘿+|嘻嘻+|呵呵+|笑死|xswl|绷不住|笑不活")
PARTICLES = ["嗯", "啊", "呢", "吧", "嘛", "呀", "哦", "噢", "喔", "啦", "呗", "捏", "欸", "诶",
             "哈", "嘿", "唉", "哎", "嘞", "咯", "哟", "叭", "鸭", "哇", "额", "呃", "emm", "hhh", "orz"]
PII = [
    (re.compile(r"https?://\S+|www\.\S+"), "[链接]"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[邮箱]"),
    (re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)"), "[证件号]"),
    (re.compile(r"(?<!\d)\d{16,19}(?!\d)"), "[卡号]"),
    (re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"), "[手机号]"),
]
SPK_COLS = ["speaker", "sender", "sender_name", "name", "nickname", "from", "talker",
            "发送者", "发送人", "昵称", "说话人", "用户", "remark", "strtalker"]
TXT_COLS = ["text", "content", "message", "msg", "strcontent", "消息内容", "内容", "消息", "message_content"]
TIME_COLS = ["time", "timestamp", "date", "datetime", "strtime", "createtime", "create_time",
             "发送时间", "时间", "日期"]


def parse_time(s):
    if s is None or s == "":
        return None
    s = str(s).strip()
    if re.fullmatch(r"\d{10}(?:\.\d+)?", s):
        return dt.datetime.fromtimestamp(float(s))
    if re.fullmatch(r"\d{13}", s):
        return dt.datetime.fromtimestamp(int(s) / 1000)
    s2 = re.sub(r"[年月/.]", "-", s).replace("日", "").replace("T", " ")
    s2 = re.sub(r"\s+", " ", s2).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%H:%M:%S", "%H:%M"):
        try:
            return dt.datetime.strptime(s2[:19], fmt)
        except ValueError:
            continue
    return None


def clean_name(n):
    n = n.strip()
    n = re.sub(r"\s*[(（]\d{5,}[)）]$", "", n)  # QQ 号
    n = re.sub(r"\s*<[^>]+>$", "", n)  # 邮箱
    return n.strip() or "?"


# ------------------------------------------------------------------ loaders
def load_txt(path):
    text = tu.read_text(path)
    lines = text.split("\n")
    sample = [l for l in lines if l.strip()][:3000]
    n = max(len(sample), 1)
    c_inline = sum(1 for l in sample if INLINE_TIMED.match(l))
    c_header = sum(1 for l in sample if HEADER.match(l) or HEADER_NAME_FIRST.match(l))
    c_plain = sum(1 for l in sample if PLAIN.match(l) and not HEADER.match(l))
    msgs = []
    if c_inline / n >= 0.3:
        mode = "inline"
    elif c_header / n >= 0.12:
        mode = "header"
    elif c_plain / n >= 0.3:
        mode = "plain"
    else:
        sys.exit("无法识别聊天记录格式：请转成“名字: 消息”每行一条，或用 CSV。")
    cur = None
    for l in lines:
        s = l.strip()
        if mode == "header":
            m = HEADER.match(s) or HEADER_NAME_FIRST.match(s)
            if m:
                cur = {"time": m.group("time"), "speaker": clean_name(m.group("name")), "text": ""}
                msgs.append(cur)
                continue
            if cur is not None and s:
                cur["text"] = (cur["text"] + "\n" + s) if cur["text"] else s
        else:
            m = INLINE_TIMED.match(s) if mode == "inline" else PLAIN.match(s)
            if m:
                cur = {"time": m.groupdict().get("time"), "speaker": clean_name(m.group("name")),
                       "text": m.group("text").strip()}
                msgs.append(cur)
            elif cur is not None and s:
                cur["text"] += "\n" + s
    return msgs, mode


def _find_col(fields, cands, override):
    if override:
        return override
    low = {f.lower().strip(): f for f in fields}
    for c in cands:
        if c in low:
            return low[c]
    return None


def load_csv(path, args):
    raw = tu.read_text(path)
    rows = list(csv.DictReader(raw.splitlines()))
    if not rows:
        sys.exit("CSV 为空")
    fields = rows[0].keys()
    c_spk = _find_col(fields, SPK_COLS, args.col_speaker)
    c_txt = _find_col(fields, TXT_COLS, args.col_text)
    c_time = _find_col(fields, TIME_COLS, args.col_time)
    c_is = _find_col(fields, ["issender", "is_sender", "issend", "is_send"], None)
    c_type = _find_col(fields, ["type", "msgtype", "消息类型"], None)
    if not c_txt:
        sys.exit(f"找不到消息内容列，现有列：{list(fields)}，请用 --col-text 指定")
    msgs = []
    for r in rows:
        if c_is and str(r.get(c_is, "")).strip() in ("1", "true", "True"):
            spk = args.me
        elif c_is and not args.col_speaker:
            spk = (r.get("Remark") or r.get("NickName") or r.get(c_spk or "", "") or args.other).strip() or args.other
        else:
            spk = (r.get(c_spk, "") if c_spk else args.other) or args.other
        text = r.get(c_txt, "") or ""
        media = None
        if c_type:
            t = str(r.get(c_type, "")).strip()
            media = WX_TYPES.get(t, None) if t in WX_TYPES else None
        msgs.append({"time": r.get(c_time) if c_time else None, "speaker": clean_name(spk),
                     "text": text, "media": media})
    return msgs, "csv"


def load_json(path):
    data = json.load(open(path, encoding="utf-8-sig"))
    msgs = []
    if isinstance(data, dict) and "messages" in data:  # Telegram
        for m in data["messages"]:
            if m.get("type") != "message":
                continue
            t = m.get("text", "")
            if isinstance(t, list):
                t = "".join(x if isinstance(x, str) else x.get("text", "") for x in t)
            media = None
            if m.get("photo"):
                media = "图片"
            elif m.get("media_type") == "sticker":
                media = "表情包"
            elif m.get("media_type") in ("voice_message", "audio_file"):
                media = "语音"
            elif m.get("media_type"):
                media = "视频"
            msgs.append({"time": m.get("date"), "speaker": clean_name(m.get("from") or "?"),
                         "text": t, "media": media})
        return msgs, "telegram"
    if isinstance(data, list):
        for m in data:
            spk = next((m[k] for k in m if k.lower() in SPK_COLS), "?")
            txt = next((m[k] for k in m if k.lower() in TXT_COLS), "")
            tim = next((m[k] for k in m if k.lower() in TIME_COLS), None)
            msgs.append({"time": tim, "speaker": clean_name(str(spk)), "text": str(txt)})
        return msgs, "json-list"
    sys.exit("无法识别的 JSON 结构")


# ------------------------------------------------------------------ cleaning
def clean(msgs, mask=True):
    out = []
    dropped = 0
    for m in msgs:
        text = (m.get("text") or "").strip()
        media = m.get("media")
        if media == "系统" or SYSTEM.search(text):
            dropped += 1
            continue
        for name, rx in MEDIA:
            if rx.match(text):
                media, text = name, ""
                break
        if media and media != "系统":
            text = "" if text.startswith("<") else text  # 微信 XML 卡片内容丢弃
        if mask:
            for rx, rep in PII:
                text = rx.sub(rep, text)
        if not text and not media:
            dropped += 1
            continue
        out.append({"time": m.get("time"), "_t": parse_time(m.get("time")),
                    "speaker": m["speaker"], "text": text, "media": media})
    return out, dropped


def to_turns(msgs, window):
    """Merge consecutive messages of one speaker into a turn (burst)."""
    turns = []
    for m in msgs:
        if turns and turns[-1]["speaker"] == m["speaker"]:
            prev = turns[-1]["msgs"][-1]
            gap = None
            if m["_t"] and prev["_t"]:
                gap = (m["_t"] - prev["_t"]).total_seconds()
            if gap is None or 0 <= gap <= window:
                turns[-1]["msgs"].append(m)
                continue
        turns.append({"speaker": m["speaker"], "msgs": [m]})
    return turns


# ------------------------------------------------------------------ stats
def speaker_stats(msgs, turns):
    by = defaultdict(list)
    for m in msgs:
        by[m["speaker"]].append(m)
    total = len(msgs)
    grams_by = {}
    stats = {}
    for spk, ms in by.items():
        texts = [m["text"] for m in ms if m["text"]]
        media = Counter(m["media"] for m in ms if m["media"])
        n_txt = max(len(texts), 1)
        lens = [tu.units(BRACKET_EMO.sub("", EMOJI_RE.sub("", t)), True) for t in texts]
        ends = Counter()
        for t in texts:
            core = EMOJI_RE.sub("", BRACKET_EMO.sub("", t)).rstrip()
            last = core[-1] if core else ""
            if last in "。.":
                ends["句号"] += 1
            elif last in "！!":
                ends["感叹号"] += 1
            elif last in "？?":
                ends["问号"] += 1
            elif last in "~～":
                ends["波浪号"] += 1
            elif last in "…":
                ends["省略号"] += 1
            elif last in "，,、":
                ends["逗号"] += 1
            elif not core:
                ends["纯表情"] += 1
            else:
                ends["无标点"] += 1
        joined = "\n".join(texts)
        laughs = Counter(LAUGH.findall(joined))
        parts = {p: joined.count(p) for p in PARTICLES if joined.count(p)}
        emojis = Counter(EMOJI_RE.findall(joined))
        brackets = Counter(BRACKET_EMO.findall(joined))
        latin = sum(len(w) for w in tu.LATIN_WORD_RE.findall(joined))
        cjk = len(tu.CJK_RE.findall(joined))
        sp_turns = [t for t in turns if t["speaker"] == spk]
        bursts = [len(t["msgs"]) for t in sp_turns]
        openers = Counter()
        for t in sp_turns:
            first = next((m["text"] for m in t["msgs"] if m["text"]), "")
            mm = re.match(r"[一-鿿A-Za-z]{1,3}", first)
            if mm:
                openers[mm.group(0)[:2]] += 1
        # reply latency
        lat = []
        for a, b in zip(turns, turns[1:]):
            if b["speaker"] == spk and a["speaker"] != spk:
                ta, tb = a["msgs"][-1]["_t"], b["msgs"][0]["_t"]
                if ta and tb:
                    d = (tb - ta).total_seconds()
                    if 0 <= d < 86400:
                        lat.append(d)
        hours = Counter(m["_t"].hour for m in ms if m["_t"] and m["_t"].year > 1900)
        grams_by[spk] = tu.char_ngrams(re.sub(r"\[[^\[\]]{1,8}\]", " ", joined), 2, 4)
        stats[spk] = {
            "messages": len(ms),
            "share": round(len(ms) / max(total, 1), 3),
            "text_messages": len(texts),
            "msg_len": tu.describe(lens),
            "burst_mean": round(sum(bursts) / max(len(bursts), 1), 2),
            "burst_3plus_share": round(sum(1 for b in bursts if b >= 3) / max(len(bursts), 1), 3),
            "ending": {k: round(v / n_txt, 3) for k, v in ends.most_common()},
            "question_share": round(sum(1 for t in texts if re.search(r"[？?]", t)) / n_txt, 3),
            "laughs": laughs.most_common(6),
            "particles_per100": {k: round(v * 100 / n_txt, 1) for k, v in sorted(parts.items(), key=lambda x: -x[1])[:12]},
            "emoji_per100": round(sum(emojis.values()) * 100 / n_txt, 1),
            "top_emoji": emojis.most_common(8),
            "bracket_emoticons": brackets.most_common(8),
            "media_per100": {k: round(v * 100 / max(len(ms), 1), 1) for k, v in media.most_common()},
            "latin_share": round(latin / max(latin + cjk, 1), 3),
            "space_as_pause_share": round(sum(1 for t in texts if re.search(r"[一-鿿] [一-鿿]", t)) / n_txt, 3),
            "openers": openers.most_common(10),
            "reply_latency_median_s": (sorted(lat)[len(lat) // 2] if lat else None),
            "active_hours": [h for h, _ in hours.most_common(4)],
        }
    # distinctive n-grams: weighted log-odds with informative prior
    allc = Counter()
    for g in grams_by.values():
        allc.update(g)
    n_all = sum(allc.values()) or 1
    stop = set("的了是我你他她这那一不在有就也都")
    for spk, g in grams_by.items():
        n_s = sum(g.values()) or 1
        n_o = n_all - n_s
        if len(grams_by) == 1 or n_o < 200:
            stats[spk]["signature"] = tu.prune_ngrams(g, min_count=3, top=25, stop_chars=stop)
            continue
        a0 = 500.0
        scored = Counter()
        for w, y_s in g.items():
            if y_s < 3 or all(ch in stop for ch in w):
                continue
            y_o = allc[w] - y_s
            a_w = a0 * allc[w] / n_all
            d = math.log((y_s + a_w) / (n_s + a0 - y_s - a_w)) - math.log((y_o + a_w) / (n_o + a0 - y_o - a_w))
            z = d / math.sqrt(1 / (y_s + a_w) + 1 / (y_o + a_w))
            if z > 1.96:
                scored[w] = z
        stats[spk]["signature"] = tu.dedupe_overlapping(
            sorted(scored.items(), key=lambda x: -x[1] * (1 + 0.25 * (len(x[0]) - 2))), g, top=25
        )
    return stats


def pick_samples(turns, target, n):
    pairs = []
    for i, t in enumerate(turns):
        if t["speaker"] != target:
            continue
        prev = turns[i - 1] if i > 0 and turns[i - 1]["speaker"] != target else None
        size = sum(tu.units(m["text"], True) for m in t["msgs"])
        if size == 0:
            continue
        pairs.append((i, prev, t, size))
    if not pairs:
        return []
    short = [p for p in pairs if p[3] < 10]
    mid = [p for p in pairs if 10 <= p[3] < 40]
    long_ = [p for p in pairs if p[3] >= 40]
    quota = {"short": int(n * 0.3), "mid": int(n * 0.4)}
    quota["long"] = n - quota["short"] - quota["mid"]

    def spread(lst, k):
        if k <= 0 or not lst:
            return []
        if len(lst) <= k:
            return lst
        step = len(lst) / k
        return [lst[int(j * step)] for j in range(k)]

    chosen = spread(long_, quota["long"]) + spread(mid, quota["mid"]) + spread(short, quota["short"])
    if len(chosen) < n:
        rest = [p for p in pairs if p not in chosen]
        chosen += spread(rest, n - len(chosen))
    chosen.sort(key=lambda p: p[0])
    return chosen


def fmt_turn(t):
    out = []
    for m in t["msgs"]:
        out.append(m["text"] if m["text"] else f"[{m['media']}]")
    return " ⏎ ".join(out)


def report(stats, mode, dropped, n_msgs, min_msgs):
    L = [f"# 聊天记录说话习惯画像\n", f"格式：{mode} · 有效消息 {n_msgs} 条 · 丢弃系统/空消息 {dropped} 条\n"]
    for spk, s in sorted(stats.items(), key=lambda x: -x[1]["messages"]):
        if s["messages"] < min_msgs:
            continue
        ml = s["msg_len"]
        L.append(f"## {spk}（{s['messages']} 条，占 {s['share']:.0%}）")
        L.append(f"- 单条长度：均值 {ml['mean']} 字，中位 {ml['median']}，P90 {ml['p90']}")
        L.append(f"- 连发：平均每轮 {s['burst_mean']} 条，三条以上连发占 {s['burst_3plus_share']:.0%}")
        L.append("- 句末习惯：" + "，".join(f"{k} {v:.0%}" for k, v in s["ending"].items()))
        L.append(f"- 问句占比 {s['question_share']:.0%}；中文里用空格断句 {s['space_as_pause_share']:.0%}；英文字母占比 {s['latin_share']:.0%}")
        if s["particles_per100"]:
            L.append("- 语气词（每百条）：" + "，".join(f"{k} {v}" for k, v in s["particles_per100"].items()))
        if s["laughs"]:
            L.append("- 笑法：" + "，".join(f"{k}×{v}" for k, v in s["laughs"]))
        if s["top_emoji"] or s["bracket_emoticons"]:
            L.append(f"- 表情：emoji {s['emoji_per100']}/百条 {''.join(e for e, _ in s['top_emoji'])}；"
                     + " ".join(f"{e}×{c}" for e, c in s["bracket_emoticons"]))
        if s["media_per100"]:
            L.append("- 非文字消息（每百条）：" + "，".join(f"{k} {v}" for k, v in s["media_per100"].items()))
        if s["openers"]:
            L.append("- 常见开头：" + "，".join(f"{k}×{v}" for k, v in s["openers"]))
        if s.get("signature"):
            L.append("- 标志性用语候选（相对其他人显著偏多）：" + "，".join(f"{w}×{c}" for w, c in s["signature"]))
        if s["reply_latency_median_s"] is not None:
            L.append(f"- 回复间隔中位数：{int(s['reply_latency_median_s'])} 秒；活跃时段：{s['active_hours']} 点")
        L.append("")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--out", default="chat_out")
    ap.add_argument("--target")
    ap.add_argument("--me", default="我")
    ap.add_argument("--other", default="对方")
    ap.add_argument("--merge-window", type=int, default=120, help="同一人连发合并为一轮的最大间隔（秒）")
    ap.add_argument("--samples", type=int, default=40)
    ap.add_argument("--min-msgs", type=int, default=5)
    ap.add_argument("--no-mask", action="store_true")
    ap.add_argument("--col-speaker")
    ap.add_argument("--col-text")
    ap.add_argument("--col-time")
    args = ap.parse_args(argv)

    ext = os.path.splitext(args.input)[1].lower()
    if ext == ".csv":
        raw, mode = load_csv(args.input, args)
    elif ext == ".json":
        raw, mode = load_json(args.input)
    else:
        raw, mode = load_txt(args.input)
    msgs, dropped = clean(raw, mask=not args.no_mask)
    if not msgs:
        sys.exit("没有解析出有效消息")
    turns = to_turns(msgs, args.merge_window)
    stats = speaker_stats(msgs, turns)
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "chat.jsonl"), "w", encoding="utf-8") as f:
        for m in msgs:
            f.write(json.dumps({k: m[k] for k in ("time", "speaker", "text", "media")}, ensure_ascii=False) + "\n")
    rep = report(stats, mode, dropped, len(msgs), args.min_msgs)
    open(os.path.join(args.out, "speakers.md"), "w", encoding="utf-8").write(rep)
    json.dump(stats, open(os.path.join(args.out, "stats.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)
    print(rep)
    speakers = sorted(stats, key=lambda s: -stats[s]["messages"])
    if args.target:
        if args.target not in stats:
            sys.exit(f"找不到说话人“{args.target}”。现有：{speakers}")
        chosen = pick_samples(turns, args.target, args.samples)
        L = [f"# {args.target} 的示例对话（{len(chosen)} 组，按时间排序；⏎ 表示连发的下一条）\n"]
        for i, prev, t, size in chosen:
            if prev:
                L.append(f"{prev['speaker']}：{fmt_turn(prev)}")
            L.append(f"**{args.target}**：{fmt_turn(t)}\n")
        safe = re.sub(r"[^\w]+", "_", args.target)
        p = os.path.join(args.out, "samples_" + safe + ".md")
        open(p, "w", encoding="utf-8").write("\n".join(L))
        print(f"\n示例对话已写入 {p}")
    else:
        print(f"\n提示：用 --target 指定要模仿的人（可选：{speakers[:8]}），会额外导出示例对话。")
    print(f"清洗后的消息：{os.path.join(args.out, 'chat.jsonl')}")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
