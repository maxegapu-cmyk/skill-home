# -*- coding: utf-8 -*-
"""从原文里检索与即将要写的场景最相近的段落，作为动笔前的“文风锚点”。

用法：
  python find_anchors.py 原文.txt --query "雨夜 码头 两人争吵 分手" [--top 5]
  python find_anchors.py 原文.txt --scene 争吵 --must 林晚 --dialogue
  python find_anchors.py chat.jsonl --query "加班 抱怨" --speaker 小王   # 聊天记录

参数：
  --query    关键词或一句场景描述（BM25 检索，中文无需分词）
  --scene    场景类型，自动补充关键词：打斗 争吵 告白 离别 日常 吃饭 景物 心理 回忆 悬疑 亲密 搞笑
  --must     段落必须包含的词（可多次），常用于限定出场人物
  --dialogue 只要对白占比较高的段落（学人物说话）
  --narration 只要叙述为主的段落（学叙述腔）
  --window   每个候选段的目标长度（字），默认 450
  --speaker  （聊天记录）只返回包含该说话人的片段
  --tail     从原文末尾 N 字里额外取一段（续写衔接用），默认 0
"""
import argparse
import json
import math
import re
import sys
from collections import Counter

import textutil as tu

SCENES = {
    "打斗": "打 拳 刀 剑 血 招 退 躲 挡 砍 踢 倒地 出手 杀",
    "争吵": "吵 骂 吼 喊 冷笑 摔 你凭什么 够了 闭嘴 滚 生气 怒",
    "告白": "喜欢 爱 心 脸红 看着 低头 等你 我们 一起 答应",
    "离别": "走 送 告别 再见 车站 背影 回头 等 保重 以后",
    "日常": "吃 饭 睡 早上 晚上 买 家 回来 笑 聊",
    "吃饭": "吃 饭 菜 酒 碗 筷子 汤 桌 喝 店",
    "景物": "风 雨 雪 天 云 树 山 河 月 夜 光 街 灯",
    "心理": "想 觉得 心里 明白 知道 怕 恨 后悔 忽然 记得",
    "回忆": "那年 从前 记得 小时候 以前 想起 后来 当时",
    "悬疑": "门 声音 脚步 影子 黑 突然 不见 死 秘密 线索",
    "亲密": "手 抱 靠 呼吸 肩 温 轻 头发 近",
    "搞笑": "笑 哈 傻 逗 骗 装 尴尬 吐槽",
}


def build_passages_text(text, window):
    cjk = tu.is_cjk_text(text)
    paras = tu.split_paragraphs(text)
    out, buf, start, cur = [], [], None, 0
    for ln, p in paras:
        if start is None:
            start = ln
        buf.append(p)
        cur += tu.units(p, cjk)
        if cur >= window:
            out.append({"line": start, "text": "\n".join(buf), "units": cur})
            buf, start, cur = [], None, 0
    if buf:
        out.append({"line": start, "text": "\n".join(buf), "units": cur})
    return out, cjk


def build_passages_chat(path, turns=12):
    msgs = []
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line:
            msgs.append(json.loads(line))
    out = []
    for i in range(0, len(msgs), turns // 2):
        seg = msgs[i : i + turns]
        if not seg:
            continue
        txt = "\n".join(f"{m.get('speaker','?')}：{m.get('text','')}" for m in seg)
        out.append({"line": i + 1, "text": txt, "units": tu.units(txt, True),
                    "speakers": {m.get("speaker") for m in seg}})
    return out, True


class BM25:
    def __init__(self, docs, k1=1.5, b=0.75):
        self.k1, self.b = k1, b
        self.docs = [Counter(d) for d in docs]
        self.lens = [len(d) for d in docs]
        self.avg = sum(self.lens) / max(len(self.lens), 1)
        df = Counter()
        for d in self.docs:
            df.update(d.keys())
        N = len(docs)
        self.idf = {t: math.log(1 + (N - n + 0.5) / (n + 0.5)) for t, n in df.items()}

    def score(self, q, i):
        d, L = self.docs[i], self.lens[i]
        s = 0.0
        for t in q:
            if t in d:
                f = d[t]
                s += self.idf.get(t, 0) * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * L / self.avg))
        return s


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("source")
    ap.add_argument("--query", default="")
    ap.add_argument("--scene", default="")
    ap.add_argument("--must", action="append", default=[])
    ap.add_argument("--dialogue", action="store_true")
    ap.add_argument("--narration", action="store_true")
    ap.add_argument("--speaker")
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--window", type=int, default=450)
    ap.add_argument("--tail", type=int, default=0)
    args = ap.parse_args(argv)

    if args.source.endswith(".jsonl"):
        passages, cjk = build_passages_chat(args.source)
    else:
        text = tu.read_text(args.source)
        passages, cjk = build_passages_text(text, args.window)

    q = args.query
    for s in args.scene.split():
        q += " " + SCENES.get(s, s)
    q_toks = tu.tokens(q, cjk) + [w for w in q.split() if len(w) == 1 and tu.CJK_RE.match(w)]
    docs = []
    for p in passages:
        toks = tu.tokens(p["text"], cjk)
        # also index single CJK chars so 1-char keywords match
        toks += tu.CJK_RE.findall(p["text"])
        docs.append(toks)
    bm = BM25(docs)

    cands = []
    for i, p in enumerate(passages):
        t = p["text"]
        if any(m not in t for m in args.must):
            continue
        if args.speaker and args.speaker not in p.get("speakers", {args.speaker}) and args.speaker not in t:
            continue
        if args.dialogue or args.narration:
            qs, _ = tu.dialogue_spans(t)
            ratio = sum(tu.units(x, cjk) for x in qs) / max(p["units"], 1)
            if args.dialogue and ratio < 0.3:
                continue
            if args.narration and ratio > 0.2:
                continue
        sc = bm.score(q_toks, i) if q_toks else 0.0
        cands.append((sc, i))
    cands.sort(reverse=True)

    # diversity: skip passages adjacent to an already chosen one
    chosen = []
    for sc, i in cands:
        if any(abs(i - j) <= 1 for _, j in chosen):
            continue
        chosen.append((sc, i))
        if len(chosen) >= args.top:
            break
    if not q_toks and not chosen:
        print("没有符合条件的段落。放宽 --must/--dialogue 条件试试。")
    print(f"# 文风锚点候选（共 {len(passages)} 段可选，返回 {len(chosen)} 段）\n")
    for rank, (sc, i) in enumerate(chosen, 1):
        p = passages[i]
        print(f"## {rank}. 第 {p['line']} 行起 · 约 {p['units']} 字 · 相关度 {sc:.2f}\n")
        print(p["text"])
        print()
    if args.tail and not args.source.endswith(".jsonl"):
        paras = tu.split_paragraphs(text)
        tail, cur = [], 0
        for ln, p in reversed(paras):
            tail.append((ln, p))
            cur += tu.units(p, cjk)
            if cur >= args.tail:
                break
        tail.reverse()
        print(f"## 原文末尾（第 {tail[0][0]} 行起，约 {cur} 字，续写从这里接）\n")
        print("\n".join(p for _, p in tail))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
