# -*- coding: utf-8 -*-
"""去 AI 味检查：找出草稿里的 AI 套路句式和陈词。

用法：
  python ai_flavor_lint.py 草稿.txt [--source 原文.txt] [--extra 自定义规则.txt]

--source：给出原文后，会计算每条规则在原文里的出现频率。原作者自己就常用的
写法（频率不低于草稿）会被标记为“作者习惯，豁免”，不要求修改。
--extra：每行一个正则，可写成 “正则<TAB>说明”，用于加入用户自己的禁用句式。

输出按严重度排序的命中列表（行号 + 上下文 + 改法提示）。
"""
import argparse
import re
import sys

import textutil as tu

# (id, 严重度 3/2/1, 正则, 改法提示)
RULES_ZH = [
    # —— 对比否定：用“排除 A”来说 B
    ("对比否定·不是而是", 3, r"不是[^。！？!?\n]{1,40}?而是", "直接写“是什么”，删掉被排除的那一半"),
    ("对比否定·并不是", 3, r"并(?:不是|非)[^。！？!?\n]{1,30}?[，,]\s*(?:而)?是", "直接陈述结论"),
    ("对比否定·是而不是", 3, r"(?<![不并])是[^。！？!?\n，,]{1,20}?而不是", "删去“而不是……”"),
    ("对比否定·不像倒像", 3, r"不像[^。！？!?\n]{1,30}?(?:倒|反而|更)像", "只留后一个比喻，或换成具体细节"),
    ("对比否定·与其说不如说", 3, r"与其说[^。！？!?\n]{1,30}?不如说", "直接下判断"),
    ("对比否定·没有但也", 2, r"没有[^。！？!?\n]{1,30}?[，,]\s*但也", "直接写实际状态"),
    ("对比否定·不只是更是", 2, r"不(?:仅仅|只)是[^。！？!?\n]{1,30}?(?:更是|而是)", "拆成一句具体陈述"),
    # —— 高频陈词（网文/AI 腔）
    ("陈词·一丝", 2, r"一丝(?:不易察觉|笑意|寒意|暖意|苦涩|慌乱|异样|波澜|涟漪|狡黠|玩味|宠溺|心疼|无奈)", "换成可见的动作或删掉"),
    ("陈词·嘴角上扬", 2, r"嘴角(?:微微)?(?:上扬|勾起|扬起|一勾)|勾起一抹|一抹(?:笑意|弧度|微笑|苦笑|冷笑)", "写一个具体反应，或干脆不写表情"),
    ("陈词·眼中闪过", 2, r"(?:眼|眸)(?:中|里|底)(?:闪过|划过|掠过|浮现)(?:一丝|一抹|一道)", "删掉，或用台词/动作体现情绪"),
    ("陈词·深吸一口气", 1, r"深(?:深地)?吸了?一口气", "同一篇里最多一次"),
    ("陈词·淬冰淬毒", 3, r"淬了?(?:冰|毒)", "换成原文会用的说法"),
    ("陈词·不容置喙", 2, r"不容(?:置喙|置疑|拒绝|反驳)", "让台词本身显得强硬"),
    ("陈词·心漏一拍", 3, r"(?:心|心脏|心跳)(?:猛地|狠狠)?(?:漏跳|漏了)(?:了)?一拍", "删"),
    ("陈词·喉结滚动", 2, r"喉结(?:上下)?滚动", "删或换"),
    ("陈词·指节泛白", 2, r"指节(?:泛白|发白)|骨节分明", "删或换"),
    ("陈词·空气凝固", 3, r"空气(?:仿佛|似乎|好像)?(?:都)?(?:凝固|凝滞|安静)了?|时间(?:仿佛|好像|似乎)(?:都)?(?:静止|停止|凝固)", "写在场的人具体做了什么"),
    ("陈词·整个世界", 2, r"(?:仿佛|好像|似乎)整个世界(?:都)?", "删"),
    ("陈词·涟漪石子", 2, r"(?:石子|石头)(?:投入|落入|丢进|扔进)[^。]{0,6}(?:湖|水)|(?:激起|泛起|荡起)[^。]{0,4}涟漪", "换成具体反应"),
    ("陈词·命运齿轮", 3, r"命运的齿轮", "删"),
    ("陈词·难以言喻", 2, r"难以言喻|说不清道不明|莫名的(?:情绪|感觉)|复杂的(?:情绪|神色|眼神)", "说清楚是什么情绪，或用细节呈现"),
    ("陈词·涌起一股", 2, r"(?:心中|心里|胸口)(?:涌起|升起|泛起)一(?:股|阵)|一股暖流", "删，或写身体上可见的变化"),
    ("陈词·低沉磁性", 2, r"低沉(?:而)?(?:富有|充满|带着)?磁性", "删"),
    ("陈词·带着几分", 1, r"带着(?:一丝|几分|些许|一抹)", "多数情况下可直接删"),
    ("陈词·微不可察", 2, r"微不可(?:察|闻|见)|几不可(?:闻|察|见)|好整以暇", "删"),
    ("陈词·仿佛诉说", 2, r"仿佛在(?:诉说|述说|讲述|低语)", "删"),
    ("陈词·目光坚定", 1, r"(?:眼神|目光)(?:变得)?(?:坚定|复杂|深邃)", "用行动体现"),
    ("陈词·声音不大却", 2, r"声音(?:很轻|不大|不高)[，,]?却", "删掉转折，直接写效果"),
    # —— 叙述套路
    ("套路·升华总结", 3, r"(?:也许|或许|大概)[，,]?这(?:就是|便是)", "删掉总结句，让场景停在动作或台词上"),
    ("套路·这一刻", 1, r"(?:这|那)一刻", "同一篇里最多一两次"),
    ("套路·他知道", 1, r"(?:^|[。！？\n，,])(?:他|她|我)(?:知道|明白|清楚)[，,]", "检查是否在替读者下结论"),
    ("套路·说明腔", 3, r"值得(?:注意|一提)的是|总而言之|综上所述|不可否认|某种(?:意义|程度)上", "小说里删掉"),
    ("套路·同位语", 1, r"(?:^|[。！？\n])(?:他|她)，[^，。！？\n]{2,12}，", "“他，某某，……”是翻译腔，改顺"),
    ("套路·三连的", 1, r"(?:[^，。！？\n]{1,8}的[^，。！？\n]{1,8}[，、]){2}[^，。！？\n]{1,8}的[^，。！？\n]{1,8}[。！？]", "排比三连，砍掉一到两项"),
]
RULES_EN = [
    ("contrast·not X but Y", 3, r"\bnot (?:just |only |merely )?[^.?!\n]{1,40}?, but\b", "state the positive directly"),
    ("contrast·it's not X, it's Y", 3, r"\b(?:it|this|that)(?:'s| is| was)(?:n't| not) [^.?!\n]{1,30}?[,;—-]+ (?:it|this|that)(?:'s| is| was)\b", "state the positive directly"),
    ("cliche·testament", 3, r"\ba testament to\b", "cut"),
    ("cliche·tapestry", 3, r"\btapestry\b", "cut"),
    ("cliche·delve", 2, r"\bdelv(?:e|ed|ing)\b", "cut"),
    ("cliche·barely above a whisper", 3, r"barely (?:above|more than) a whisper", "cut"),
    ("cliche·shiver spine", 3, r"shivers? (?:ran |run |runs |running |went |go |going )?(?:down|up) (?:his|her|my|their|the) spine", "cut"),
    ("cliche·breath didn't know", 3, r"(?:a )?breath (?:he|she|I|they) didn'?t know", "cut"),
    ("cliche·the weight of", 2, r"\bthe weight of\b", "be concrete"),
    ("cliche·palpable", 2, r"\bpalpable\b", "cut"),
    ("cliche·in that moment", 1, r"\bin that moment\b", "max once"),
    ("cliche·couldn't help but", 1, r"couldn'?t help but", "cut"),
    ("cliche·something shifted", 2, r"something (?:shifted|changed) (?:in|between)", "say what changed"),
    ("cliche·eyes glinting", 2, r"eyes (?:sparkling|glinting|gleaming|twinkling) with", "cut"),
    ("cliche·a mix of", 1, r"\ba (?:mix|mixture) of [a-z]+ and [a-z]+\b", "pick one concrete feeling"),
    ("cliche·maybe that was enough", 3, r"\b(?:maybe|perhaps),? (?:that|this) (?:was|is) (?:enough|what)\b", "end on action, not moral"),
]


def load_extra(path):
    rules = []
    for line in tu.read_text(path).split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        pat, _, hint = line.partition("\t")
        rules.append(("自定义·" + pat[:12], 3, pat, hint or "用户禁用"))
    return rules


def lint(draft, source=None, extra=None):
    cjk = tu.is_cjk_text(draft)
    rules = (RULES_ZH if cjk else RULES_EN) + (extra or [])
    d_units = max(tu.units(draft, cjk), 1)
    s_units = max(tu.units(source, cjk), 1) if source else None
    lines = draft.split("\n")
    out = []
    for rid, sev, pat, hint in rules:
        try:
            rx = re.compile(pat, re.I | re.M)
        except re.error as e:
            print(f"[跳过无效正则] {pat}: {e}", file=sys.stderr)
            continue
        hits = []
        for ln, line in enumerate(lines, 1):
            for m in rx.finditer(line):
                a, b = max(0, m.start() - 12), min(len(line), m.end() + 12)
                hits.append((ln, line[a:b], m.group(0)))
        if not hits:
            continue
        d_rate = len(hits) / d_units * 10000
        s_rate = None
        exempt = False
        if source is not None:
            s_cnt = len(rx.findall(source))
            s_rate = s_cnt / s_units * 10000
            # the author's own habit: used at least as often in the source
            exempt = s_cnt >= 2 and s_rate >= d_rate * 0.7
        out.append({"rule": rid, "severity": sev, "hint": hint, "count": len(hits),
                    "draft_per10k": round(d_rate, 2),
                    "source_per10k": None if s_rate is None else round(s_rate, 2),
                    "exempt": exempt, "hits": hits})
    out.sort(key=lambda r: (r["exempt"], -r["severity"], -r["count"]))
    return out


def report(results, has_source):
    if not results:
        return "未发现已知的 AI 套路句式。仍建议通读一遍，用“哪里一看就是 AI 写的？”自问。"
    L = ["# 去 AI 味检查\n"]
    todo = [r for r in results if not r["exempt"]]
    ex = [r for r in results if r["exempt"]]
    if todo:
        L.append(f"## 需要改（{sum(r['count'] for r in todo)} 处）")
        for r in todo:
            star = "★" * r["severity"]
            src = "" if r["source_per10k"] is None else f"（原文 {r['source_per10k']}/万字，草稿 {r['draft_per10k']}/万字）"
            L.append(f"\n### {star} {r['rule']} ×{r['count']} {src}\n改法：{r['hint']}")
            for ln, ctx, hit in r["hits"][:8]:
                L.append(f"- 第{ln}行：…{ctx}…  ⟶ 「{hit}」")
            if len(r["hits"]) > 8:
                L.append(f"- ……另有 {len(r['hits'])-8} 处")
    if ex:
        L.append("\n## 作者本人也常用，豁免（保持与原文相近的频率即可）")
        for r in ex:
            L.append(f"- {r['rule']}：原文 {r['source_per10k']}/万字，草稿 {r['draft_per10k']}/万字")
    if not has_source:
        L.append("\n提示：加 --source 原文.txt 可以豁免原作者自己的习惯写法。")
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("draft")
    ap.add_argument("--source")
    ap.add_argument("--extra", help="自定义禁用规则文件，每行“正则<TAB>说明”")
    args = ap.parse_args(argv)
    draft = tu.read_text(args.draft)
    source = tu.read_text(args.source) if args.source else None
    extra = load_extra(args.extra) if args.extra else None
    print(report(lint(draft, source, extra), source is not None))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
