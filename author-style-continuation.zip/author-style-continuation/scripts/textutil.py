# -*- coding: utf-8 -*-
"""Shared text helpers for the author-style-continuation scripts.

Pure standard library. If `jieba` is installed it is used for Chinese word
segmentation; otherwise character n-grams are used, which works fine for the
statistics these scripts compute.
"""
import math
import re
import statistics
from collections import Counter

try:  # optional
    import jieba  # type: ignore

    jieba.setLogLevel(60)
    HAS_JIEBA = True
except Exception:  # pragma: no cover
    HAS_JIEBA = False

CJK_RE = re.compile(r"[㐀-䶿一-鿿豈-﫿]")
LATIN_WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?")
PUNCT_CHARS = set("，。！？；：、…—“”‘’「」『』（）()《》〈〉【】[]〔〕~～·,.!?;:\"'-")
TERMINALS = set("。！？!?…")
CLOSERS = set("」』”’）)\"'】》")
QUOTE_PATTERNS = [
    ("“”", re.compile(r"“[^“”]*”")),
    ("「」", re.compile(r"「[^「」]*」")),
    ("『』", re.compile(r"『[^『』]*』")),
    ('""', re.compile(r'"[^"\n]*"')),
]


def read_text(path):
    """Read a text file trying common Chinese encodings."""
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-8", "gb18030", "big5", "utf-16"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = raw.decode("utf-8", errors="replace")
    return normalize(text)


def normalize(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n").replace("　", " ")
    text = text.replace("﻿", "")
    return "\n".join(line.rstrip() for line in text.split("\n"))


def is_cjk_text(text):
    sample = text[:200000]
    cjk = len(CJK_RE.findall(sample))
    latin = sum(len(w) for w in LATIN_WORD_RE.findall(sample))
    return cjk >= latin * 0.3 and cjk > 0


def units(text, cjk=None):
    """Length unit: CJK characters + Latin words (Chinese '字数' style).
    For mostly-English text: words."""
    if cjk is None:
        cjk = is_cjk_text(text)
    n_cjk = len(CJK_RE.findall(text))
    n_words = len(LATIN_WORD_RE.findall(text))
    return n_cjk + n_words if cjk else n_words + n_cjk


def split_paragraphs(text):
    """Return list of (start_line_no, paragraph_text). Line numbers are 1-based.

    Chinese novels usually put one paragraph per line; hard-wrapped texts
    separate paragraphs by blank lines. We detect which convention applies."""
    lines = text.split("\n")
    nonempty = [l for l in lines if l.strip()]
    if not nonempty:
        return []
    blank = len(lines) - len(nonempty)
    unterminated = sum(
        1 for l in nonempty if l.strip()[-1] not in TERMINALS | CLOSERS | set(".:;")
    )
    hard_wrapped = blank > 0 and unterminated / len(nonempty) > 0.5
    paras = []
    if hard_wrapped:
        buf, start = [], None
        for i, l in enumerate(lines, 1):
            if l.strip():
                if start is None:
                    start = i
                buf.append(l.strip())
            elif buf:
                paras.append((start, _join(buf)))
                buf, start = [], None
        if buf:
            paras.append((start, _join(buf)))
    else:
        for i, l in enumerate(lines, 1):
            if l.strip():
                paras.append((i, l.strip()))
    return paras


def _join(parts):
    out = parts[0]
    for p in parts[1:]:
        if out and CJK_RE.match(out[-1]) and CJK_RE.match(p[0]):
            out += p
        else:
            out += " " + p
    return out


def split_sentences(text):
    """Split into sentences. Handles Chinese terminal punctuation followed by
    closing quotes, and English periods followed by whitespace."""
    sents = []
    buf = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        buf.append(ch)
        end = False
        if ch in TERMINALS:
            end = True
        elif ch == "." and (i + 1 == n or text[i + 1].isspace()):
            prev = text[i - 1] if i else ""
            if not prev.isdigit():
                end = True
        elif ch == "\n":
            end = True
        if end:
            j = i + 1
            while j < n and (text[j] in TERMINALS or text[j] in CLOSERS or text[j] == "."):
                buf.append(text[j])
                j += 1
            s = "".join(buf).strip()
            if s:
                sents.append(s)
            buf = []
            i = j
            continue
        i += 1
    s = "".join(buf).strip()
    if s:
        sents.append(s)
    # drop pure-punctuation fragments
    return [s for s in sents if any(not c in PUNCT_CHARS and not c.isspace() for c in s)]


def dialogue_spans(text):
    """Return list of quoted strings (with quotes) and the quote style counts."""
    found = []
    styles = Counter()
    for name, pat in QUOTE_PATTERNS:
        for m in pat.finditer(text):
            found.append(m.group(0))
            styles[name] += 1
    return found, styles


def tokens(text, cjk=True, use_jieba=True):
    """Word tokens for retrieval / frequency.

    Chinese: jieba words if available, else CJK character bigrams (plus single
    characters for short runs). Latin words are lowercased."""
    out = []
    for w in LATIN_WORD_RE.findall(text):
        out.append(w.lower())
    if not cjk:
        return out
    if HAS_JIEBA and use_jieba:
        for w in jieba.lcut(text):
            if CJK_RE.search(w):
                out.append(w)
        return out
    for run in re.findall(r"[㐀-䶿一-鿿豈-﫿]+", text):
        if len(run) == 1:
            out.append(run)
        else:
            out.extend(run[k : k + 2] for k in range(len(run) - 1))
    return out


def char_ngrams(text, nmin=2, nmax=4):
    """Counter of CJK character n-grams that do not cross punctuation."""
    c = Counter()
    for run in re.findall(r"[㐀-䶿一-鿿豈-﫿]+", text):
        L = len(run)
        for n in range(nmin, nmax + 1):
            for k in range(L - n + 1):
                c[run[k : k + n]] += 1
    return c


def _bigrams(g):
    return {g[k : k + 2] for k in range(len(g) - 1)} or {g}


def dedupe_overlapping(ranked, counts, top=25):
    """Greedy pick from (gram, score) ranked best-first; skip a gram that shares
    a character bigram with one already chosen (avoids 也太/太离/离谱 fragments)."""
    ranked = list(ranked)
    # a fragment is dropped when a longer candidate containing it is nearly as
    # frequent (陈豆 inside 陈豆腐, 腐店 inside 豆腐店)
    best_super = {}
    for h, _ in ranked:
        ch = counts[h]
        for n in range(2, len(h)):
            for k in range(len(h) - n + 1):
                sub = h[k : k + n]
                if ch > best_super.get(sub, 0):
                    best_super[sub] = ch
    ranked = [(g, s) for g, s in ranked if best_super.get(g, 0) < 0.6 * counts[g]]
    chosen, seen = [], set()
    for g, _ in ranked:
        bg = _bigrams(g)
        if bg & seen:
            continue
        chosen.append((g, counts[g]))
        seen |= bg
        if len(chosen) >= top:
            break
    return chosen


def prune_ngrams(counter, min_count=3, top=40, stop_chars=None):
    """Pick salient n-grams: frequent, longer grams preferred when their count
    is close to the shorter fragments they contain; overlapping fragments are
    collapsed into the best-scoring one."""
    stop_chars = stop_chars or set()
    cands = [
        (g, n)
        for g, n in counter.items()
        if n >= min_count and not all(ch in stop_chars for ch in g)
    ]
    cands.sort(key=lambda x: (x[1] * (1 + 0.35 * (len(x[0]) - 2))), reverse=True)
    return dedupe_overlapping(cands, counter, top=top)


def mattr(toks, window=500):
    """Moving-average type-token ratio (lexical diversity)."""
    if not toks:
        return 0.0
    if len(toks) <= window:
        return len(set(toks)) / len(toks)
    counts = Counter(toks[:window])
    ttrs = [len(counts) / window]
    for i in range(window, len(toks)):
        out_t = toks[i - window]
        counts[out_t] -= 1
        if counts[out_t] == 0:
            del counts[out_t]
        counts[toks[i]] += 1
        ttrs.append(len(counts) / window)
    return sum(ttrs) / len(ttrs)


def describe(values):
    if not values:
        return {"n": 0, "mean": 0, "median": 0, "std": 0, "p10": 0, "p90": 0}
    vals = sorted(values)
    n = len(vals)

    def pct(p):
        k = (n - 1) * p
        f = math.floor(k)
        c = min(f + 1, n - 1)
        return vals[f] + (vals[c] - vals[f]) * (k - f)

    return {
        "n": n,
        "mean": round(statistics.fmean(vals), 2),
        "median": round(pct(0.5), 2),
        "std": round(statistics.pstdev(vals), 2) if n > 1 else 0.0,
        "p10": round(pct(0.1), 2),
        "p90": round(pct(0.9), 2),
    }
