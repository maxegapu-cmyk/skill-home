# Skill Reforge Foundry v6.0.0

把对话、个人经验、粗糙提示词、SOP 或旧 Skill，萃取成经过测试、可复用的 Agent Skill；也可以一次整理成一小套技能。零基础用户也能用。

## 它做什么

- 从当前对话中萃取经验：纠正点、被认可的终稿、隐性标准；
- 新手引导：最多两轮提问，每问带默认，只确认一次方案；
- 五种模式：萃取、采访、重铸、修补、体系；
- 自测：触发用例、纠正回放、5 维评分门槛；
- 交付：技能文件夹/ZIP、Notion 页面版、单份指令版，并附给新手的交付卡。

## 新手怎么用

在聊完一件事之后直接说："把我们刚才的经验做成一个技能。"

## 检查与打包（Python 3.8+，无第三方依赖）

```bash
python scripts/forgecheck.py lint . --strict
python scripts/forgecheck.py init ../ my-new-skill
python scripts/forgecheck.py pack . ../skill-reforge-foundry-v6.0.0.zip
```
