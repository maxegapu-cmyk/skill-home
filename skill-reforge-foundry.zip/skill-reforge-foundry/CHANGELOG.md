# Changelog

## 6.0.0

- 新增萃取、采访、重铸、修补、体系五种模式，以及新手引导协议（references/novice-guide.md）。
- 新增对话经验萃取方法：信号分级、初稿与终稿差异、证据、泛化三问、脱敏（references/experience-mining.md）。
- 新增经验到技能写法的对照、description 公式、范例写法（references/distill-patterns.md）。
- 新增唯一确认点（方案卡）、技能骨架（assets/skill-skeleton.md）和交付卡（assets/handoff-card.md）。
- 测试台新增触发用例、纠正回放和 5 维评分门槛；自带 evals/trials.yaml。
- 新增体系模式：技能地图与拆分规则。
- 运行环境新增 Notion、聊天平台、无文件系统环境的交付规范。
- forgecheck：新增 init；lint 新增 description 长度与标签、保留词、文件夹名一致性、占位内容、孤儿文件、密钥与个人信息、用例数量与反例检查，以及 --strict；pack 以 name 作为顶层目录，并保留脚本执行权限。
- 包文件夹改为不带版本号的 skill-reforge-foundry/，版本只体现在 ZIP 文件名中。

## 5.1.0

- Simplified the main workflow around concrete examples, package shape, implementation, realistic tests, and release checks.
- Added `agents/openai.yaml` using current OpenAI Skill UI metadata conventions.
- Reduced mandatory scaffolding; small Skills can remain single-file.
- Added package-shape guidance and a compact test-bench reference.
- Tightened metadata checks around the two fields used for activation across common Skill runtimes.
- Consolidated validation and deterministic packaging into one lightweight helper.
