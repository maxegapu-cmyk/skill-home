#!/usr/bin/env python3
"""forgecheck: lint, scaffold, and pack Agent Skill folders (standard library only)."""
from __future__ import annotations

import argparse
import hashlib
import re
import sys
import zipfile
from pathlib import Path

VERSION = "6.0.0"
FM_BLOCK = re.compile(r"\A\ufeff?---[ \t]*\r?\n(?P<body>.*?)\r?\n---[ \t]*(?:\r?\n|\Z)", re.S)
FIELD = re.compile(r"^(?P<key>[A-Za-z0-9_-]+):[ \t]*(?P<value>.*?)[ \t]*$")
GOOD_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
LINK = re.compile(r"(?<![A-Za-z0-9_./-])((?:references|scripts|assets|agents|evals)/[A-Za-z0-9_./-]+\.[A-Za-z0-9]+)")
XML_TAG = re.compile(r"<[A-Za-z/!][^>]*>")
PLACEHOLDER = re.compile(r"TODO|TBD|FIXME|\{\{[^}]*\}\}|【待填")
TRIGGER_CUES = ("use when", "when ", "trigger", "use for", "当", "用于", "适用", "触发", "需要", "想要")
KNOWN_FIELDS = {"name", "description", "license", "compatibility", "metadata", "allowed-tools"}
SCALAR_MARKS = {">", ">-", ">+", "|", "|-", "|+"}
SECRET_PATTERNS = [
    re.compile(r"(?<![A-Za-z0-9])sk-(?:proj-)?[A-Za-z0-9_-]{20,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}"),
    re.compile(r"xox[abprs]-[A-Za-z0-9-]{10,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
]
PHONE = re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
TEXT_SUFFIXES = {".md", ".txt", ".yaml", ".yml", ".json", ".py", ".js", ".ts", ".sh", ".toml", ".csv", ".html"}
IGNORED = {".git", "__pycache__", ".DS_Store", "dist", "node_modules"}

class Report:
    def __init__(self) -> None:
        self.rows: list[tuple[str, str]] = []

    def add(self, level: str, message: str) -> None:
        self.rows.append((level, message))

    def count(self, level: str) -> int:
        return sum(1 for lv, _ in self.rows if lv == level)

    def show(self) -> None:
        order = {"FAIL": 0, "WARN": 1, "NOTE": 2}
        for level, message in sorted(self.rows, key=lambda r: order.get(r[0], 9)):
            print(f"{level:<5} {message}")

def read_header(raw: str) -> tuple[dict[str, str], str]:
    hit = FM_BLOCK.search(raw)
    if not hit:
        raise ValueError("SKILL.md 缺少 frontmatter，或格式错误（需以 --- 开始并以 --- 结束）")
    values: dict[str, str] = {}
    current: str | None = None
    for row in hit.group("body").splitlines():
        if not row.strip() or row.lstrip().startswith("#"):
            continue
        if row[:1] in (" ", "\t"):
            if current is not None:
                values[current] = (values[current] + " " + row.strip()).strip()
            continue
        match = FIELD.match(row)
        if not match:
            current = None
            continue
        current = match.group("key")
        value = match.group("value")
        if value in SCALAR_MARKS:
            value = ""
        elif len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        values[current] = value
    return values, raw[hit.end():]

def iter_files(folder: Path):
    for item in sorted(folder.rglob("*"), key=lambda p: p.as_posix()):
        if not item.is_file():
            continue
        rel = item.relative_to(folder)
        if any(part in IGNORED for part in rel.parts) or item.suffix in {".pyc", ".zip"}:
            continue
        yield item, rel

def check_meta(meta: dict[str, str], folder: Path, rep: Report) -> None:
    name = meta.get("name", "")
    desc = meta.get("description", "")
    if not name:
        rep.add("FAIL", "frontmatter 缺少 name")
    else:
        if not GOOD_NAME.fullmatch(name):
            rep.add("FAIL", f"name 只能用小写字母、数字和连字符：{name}")
        if len(name) > 64:
            rep.add("FAIL", "name 超过 64 个字符")
        if "anthropic" in name or "claude" in name:
            rep.add("WARN", "name 含 anthropic/claude，在 Claude 上会被拒绝")
        if folder.name != name:
            rep.add("WARN", f"文件夹名 {folder.name} 与 name {name} 不一致，部分运行时要求二者相同")
    if not desc:
        rep.add("FAIL", "frontmatter 缺少 description")
    else:
        if len(desc) > 1024:
            rep.add("FAIL", f"description 长度 {len(desc)}，超过 1024 字符上限")
        if len(desc) < 30:
            rep.add("WARN", "description 过短，难以说清能力和触发场景")
        if XML_TAG.search(desc):
            rep.add("FAIL", "description 不能包含尖括号标签")
        if not any(cue in desc.lower() for cue in TRIGGER_CUES):
            rep.add("WARN", "description 没写明何时使用（如“当用户……时使用”或 Use when）")
    extras = sorted(set(meta) - KNOWN_FIELDS)
    if extras:
        rep.add("NOTE", "非通用 frontmatter 字段，仅在目标运行时支持时保留：" + ", ".join(extras))

def check_body(body: str, folder: Path, rep: Report) -> None:
    lines = body.splitlines()
    if not body.strip():
        rep.add("FAIL", "SKILL.md 正文为空")
    elif len(lines) > 500:
        rep.add("WARN", f"SKILL.md 正文 {len(lines)} 行，建议控制在 500 行内")
    mentioned = set(LINK.findall(body))
    for linked in sorted(mentioned):
        if not (folder / linked).is_file():
            rep.add("FAIL", f"SKILL.md 引用了不存在的文件：{linked}")
    for sub in ("references", "scripts", "assets"):
        base = folder / sub
        if not base.is_dir():
            continue
        for _, rel in iter_files(base):
            rel_path = f"{sub}/{rel.as_posix()}"
            if rel_path not in mentioned:
                rep.add("WARN", f"{rel_path} 没有在 SKILL.md 中提及，可能永远不会被使用")

def check_placeholders(folder: Path, rep: Report) -> None:
    targets = [folder / "SKILL.md"]
    ref_dir = folder / "references"
    if ref_dir.is_dir():
        targets += sorted(ref_dir.rglob("*.md"))
    for path in targets:
        if not path.is_file():
            continue
        for number, row in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if PLACEHOLDER.search(row):
                rep.add("FAIL", f"{path.relative_to(folder).as_posix()}:{number} 仍有未填写的占位内容")

def check_ui(folder: Path, meta: dict[str, str], rep: Report) -> None:
    ui_file = folder / "agents" / "openai.yaml"
    if not ui_file.is_file():
        return
    ui = ui_file.read_text(encoding="utf-8")
    found = re.search(r"^\s*short_description:\s*(.+?)\s*$", ui, re.M)
    if not found:
        rep.add("WARN", "agents/openai.yaml 缺少 short_description")
    else:
        label = found.group(1).strip().strip("\"'")
        if not 25 <= len(label) <= 64:
            rep.add("FAIL", f"openai short_description 长度 {len(label)}，应为 25-64 字符")
    name = meta.get("name", "")
    prompt = re.search(r"^\s*default_prompt:\s*(.+?)\s*$", ui, re.M)
    if name and prompt and f"${name}" not in prompt.group(1):
        rep.add("WARN", f"default_prompt 建议显式包含 ${name}")

def check_evals(folder: Path, rep: Report) -> None:
    eval_dir = folder / "evals"
    files = sorted(p for p in eval_dir.glob("*") if p.suffix in {".yaml", ".yml"}) if eval_dir.is_dir() else []
    if not files:
        rep.add("WARN", "没有找到 evals 下的 yaml 测试用例，交付前至少准备 3 个")
        return
    total = 0
    negative = 0
    for path in files:
        text = path.read_text(encoding="utf-8")
        total += len(re.findall(r"^\s*-?\s*id:\s*\S", text, re.M))
        negative += len(re.findall(r"^\s*should_trigger:\s*(?:false|no)\b", text, re.M | re.I))
    if total < 3:
        rep.add("WARN", f"测试用例只有 {total} 个，建议 4-8 个")
    if negative == 0:
        rep.add("WARN", "没有“不应触发”的用例，无法检验 description 的边界")

def check_privacy(folder: Path, rep: Report) -> None:
    for item, rel in iter_files(folder):
        if item.suffix.lower() not in TEXT_SUFFIXES and item.name != "LICENSE":
            continue
        try:
            text = item.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        where = rel.as_posix()
        if any(p.search(text) for p in SECRET_PATTERNS):
            rep.add("FAIL", f"{where} 疑似包含密钥或令牌，发布前必须删除")
        if PHONE.search(text) or EMAIL.search(text):
            rep.add("WARN", f"{where} 含手机号或邮箱，确认是否需要脱敏")

def lint(folder: Path, strict: bool = False) -> int:
    rep = Report()
    skill_file = folder / "SKILL.md"
    meta: dict[str, str] = {}
    if not skill_file.is_file():
        rep.add("FAIL", "根目录没有 SKILL.md")
    else:
        raw = skill_file.read_text(encoding="utf-8")
        try:
            meta, body = read_header(raw)
        except ValueError as exc:
            rep.add("FAIL", str(exc))
            body = raw
        check_meta(meta, folder, rep)
        check_body(body, folder, rep)
    check_placeholders(folder, rep)
    check_ui(folder, meta, rep)
    check_evals(folder, rep)
    check_privacy(folder, rep)
    rep.show()
    fails, warns = rep.count("FAIL"), rep.count("WARN")
    if fails or (strict and warns):
        print(f"RESULT  FAIL（FAIL {fails} / WARN {warns}）")
        return 1
    print(f"RESULT  PASS（WARN {warns}）")
    return 0

def pack(folder: Path, target: Path, strict: bool = False) -> int:
    if lint(folder, strict):
        print("PACK  已中止：先修复上面的问题")
        return 1
    meta, _ = read_header((folder / "SKILL.md").read_text(encoding="utf-8"))
    root = meta.get("name") or folder.name
    target.parent.mkdir(parents=True, exist_ok=True)
    target_resolved = target.resolve()
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for src, rel in iter_files(folder):
            if src.resolve() == target_resolved:
                continue
            entry = zipfile.ZipInfo(f"{root}/{rel.as_posix()}", (2026, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if src.suffix in {".py", ".sh"} else 0o644
            entry.external_attr = (0o100000 | mode) << 16
            archive.writestr(entry, src.read_bytes(), compresslevel=9)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    print(f"PACK  {target}")
    print(f"SHA256  {digest}")
    return 0

def init(parent: Path, name: str) -> int:
    if not GOOD_NAME.fullmatch(name) or len(name) > 64:
        print("FAIL  name 必须是 64 字符内的小写字母、数字和连字符")
        return 2
    target = parent / name
    if target.exists():
        print(f"FAIL  {target} 已存在，拒绝覆盖")
        return 2
    assets = Path(__file__).resolve().parent.parent / "assets"
    skeleton = (assets / "skill-skeleton.md").read_text(encoding="utf-8")
    trial = (assets / "trial.template.yaml").read_text(encoding="utf-8")
    (target / "evals").mkdir(parents=True)
    (target / "SKILL.md").write_text(skeleton.replace("{{name}}", name), encoding="utf-8")
    (target / "evals" / "trials.yaml").write_text(trial, encoding="utf-8")
    print(f"INIT  {target}")
    print("NEXT  填完所有占位内容后运行 lint")
    return 0

def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    cli = argparse.ArgumentParser(description=f"forgecheck {VERSION}: lint, scaffold, or pack an Agent Skill folder")
    modes = cli.add_subparsers(dest="mode", required=True)
    lint_cmd = modes.add_parser("lint", help="检查 Skill 文件夹")
    lint_cmd.add_argument("folder")
    lint_cmd.add_argument("--strict", action="store_true", help="WARN 也视为失败")
    pack_cmd = modes.add_parser("pack", help="检查后打包为确定性 ZIP")
    pack_cmd.add_argument("folder")
    pack_cmd.add_argument("output")
    pack_cmd.add_argument("--strict", action="store_true")
    init_cmd = modes.add_parser("init", help="从骨架创建新 Skill")
    init_cmd.add_argument("parent")
    init_cmd.add_argument("name")
    args = cli.parse_args()

    if args.mode == "init":
        return init(Path(args.parent).resolve(), args.name)
    folder = Path(args.folder).resolve()
    if not folder.is_dir():
        print("FAIL  folder not found")
        return 2
    if args.mode == "lint":
        return lint(folder, args.strict)
    return pack(folder, Path(args.output).resolve(), args.strict)

if __name__ == "__main__":
    raise SystemExit(main())
