---
name: skill-reforge-foundry
description: Build, rebuild, improve, test, and package reusable Agent Skills from a goal, rough prompt, SOP, existing Skill, or failure report. Trigger for requests that need a working Skill bundle with a concise SKILL.md, justified references/scripts/assets, realistic test cases, compatibility checks, or a release ZIP. Do not use for one-off task completion, generic prompt polishing, or unrelated application development.
---

# Skill Reforge Foundry

Create practical Agent Skills that are easy to trigger, easy to maintain, and straightforward to test. Prefer a compact working package over a large framework.

## Working stance

- Start from concrete user requests and examples, not abstract taxonomy.
- Keep `SKILL.md` focused on routing, essential decisions, and execution.
- Put detailed domain material in `references/`, repeatable mechanics in `scripts/`, and reusable output material in `assets/` only when they earn their place.
- Match instruction precision to the job: use flexible guidance where several approaches are valid and tighter scripts/checks where consistency matters.
- Test the behavior that can fail in real use. Do not treat a file-tree check as proof of model quality.
- Rebuild broadly when an old Skill is structurally weak; patch narrowly when only one failure is demonstrated.

## Start from examples

Before authoring, establish a small set of representative requests. Use user-provided examples when available; otherwise infer a few realistic examples from the stated job and clearly mark assumptions.

Capture:

- what users will ask for;
- what inputs are normally available;
- what a successful result looks like;
- what nearby requests should stay out of scope;
- which failures would make the Skill frustrating or unsafe to use.

For larger jobs, record this in `assets/build-brief.template.yaml`. Do not create a brief for a tiny Skill when the information already fits naturally in `SKILL.md`.

## Choose the package shape

Use the lightest shape that supports the task:

- **Single-file** — `SKILL.md` only, for compact procedural guidance.
- **Reference-backed** — add `references/` for substantial conditional knowledge.
- **Tool-backed** — add `scripts/` when deterministic work should not be left to prose.
- **Asset-backed** — add `assets/` for reusable templates or static material used in outputs.
- **Mixed** — combine only the parts the task genuinely needs.

Read `references/package-shapes.md` when the correct structure is not obvious.

## Build the Skill

When creating or revising the package:

1. Write a specific lowercase hyphenated `name` and a description that says both what the Skill does and when it should trigger.
2. Keep frontmatter limited to `name` and `description` unless the target runtime explicitly requires more.
3. Write instructions as direct actions. Remove explanations the model does not need to execute the job.
4. Keep common behavior in `SKILL.md`; move long mode-specific material to focused references and point to it only where relevant.
5. Use scripts for operations that benefit from repeatability, validation, parsing, transformation, packaging, or checksums.
6. Give failures a usable exit: request the missing information, return a partial result, explain the blocked dependency, or stop when continuing would invent facts.
7. Keep file references shallow and verify that every referenced file actually exists.

When targeting Codex/OpenAI skill surfaces, add `agents/openai.yaml` with concise UI metadata. See `references/runtime-notes.md`.

## Reforge an existing Skill

When the user supplies an older Skill, prompt, or SOP:

- identify the recurring job and observable outcomes first;
- separate durable behavior from accidental wording, outdated workarounds, and duplicated instructions;
- preserve compatibility only where the user needs it;
- choose the new package shape from the current job rather than inheriting the old file tree automatically;
- rewrite weak sections from the task requirements instead of layering more exceptions onto them;
- keep useful working pieces when a narrow patch is genuinely enough.

A reforge should feel simpler to operate after the change, not merely newer.

## Test with realistic cases

Create a small test bench proportional to the Skill. A typical release draft needs 4–6 trials, not an enormous suite.

Cover the most relevant mix of:

- normal production request;
- incomplete but recoverable input;
- ambiguous or conflicting material;
- near-neighbor request that should not trigger;
- tool/dependency failure if tools are involved;
- long or multi-object input if context pressure matters;
- a replay of a known failure that motivated the reforge.

Store structured trials when repeatability matters. Use `assets/trial.template.yaml` as a starter.

Read `references/trial-bench.md` for evaluation guidance. If no target runtime is available, label the result as a walkthrough rather than a live model run.

## Validate and package

For a package that is meant to ship, run:

```bash
python scripts/forgecheck.py lint <skill-dir>
python scripts/forgecheck.py pack <skill-dir> <release.zip>
```

Also run any task-specific tests that came with the Skill. Static checks cover package integrity and obvious metadata/reference errors; they do not prove every behavioral outcome.

For this foundry itself:

```bash
python scripts/forgecheck.py lint .
```

## Delivery

When the user asks for a finished build, return the artifact first. Then summarize only what helps them use or judge it:

- package/version or release filename;
- important changes;
- checks actually run;
- known untested areas;
- SHA-256 when a release archive was produced.

Do not flood the delivery with internal drafting history.
