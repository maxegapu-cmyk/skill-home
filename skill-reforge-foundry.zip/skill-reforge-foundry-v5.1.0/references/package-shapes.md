# Package Shapes

Choose structure by execution need, not by appearance.

## Single-file

Use only `SKILL.md` when the job is compact, procedural, and does not require large knowledge blocks or deterministic helpers.

## Reference-backed

Add `references/` when the agent needs substantial information only in certain branches. Keep one clear topic per file and link it from the exact point where it becomes useful.

Useful examples include schemas, product rules, domain glossaries, long decision tables, or platform-specific notes.

## Tool-backed

Add `scripts/` when a repeatable operation should produce the same class of result each run. Typical examples are validation, parsing, conversion, data cleanup, file generation, and packaging.

A script should have clear arguments, non-zero failure exits, and readable output.

## Asset-backed

Add `assets/` for material that is copied, filled, transformed, or embedded in the final output. Do not use assets as a second documentation folder.

## Mixed

Combine resources only when the task genuinely crosses those needs. If a reference or script is not used by the workflow, remove it.

## Freedom level

Match implementation strictness to the work:

- High freedom: multiple valid approaches; use concise heuristics.
- Medium freedom: a preferred pattern exists; use structured steps or parameterized helpers.
- Low freedom: fragile or consistency-critical operations; use narrow scripts and explicit checks.
