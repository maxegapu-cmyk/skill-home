# Runtime Notes

## Broad Agent Skills compatibility

Keep `SKILL.md` at the package root. Use lowercase hyphenated names and make the description specific enough to support activation.

For broad compatibility, keep YAML frontmatter to `name` and `description` unless the target runtime documents additional fields.

## OpenAI / Codex

Current OpenAI public examples recommend an optional `agents/openai.yaml` for user-facing interface metadata.

Typical fields:

```yaml
interface:
  display_name: "Human-facing title"
  short_description: "Short UI description"
  default_prompt: "Use $skill-name to ..."
```

Keep UI metadata aligned with `SKILL.md` after major edits. Add icons or dependencies only when they actually exist.

## Resource loading

Keep essential routing and execution guidance in `SKILL.md`. Put substantial conditional material in `references/` so it can be loaded only when needed. Scripts may be executed without loading their entire source into context.
