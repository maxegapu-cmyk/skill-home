# Test Bench

A useful test bench is small enough to understand and varied enough to expose likely failures.

## Case design

Each trial should include:

- request or input;
- relevant environment assumptions;
- observable success conditions;
- important failure conditions;
- notes from the run or walkthrough.

Prefer 4–6 representative trials for a normal Skill. Add one when real use exposes an uncovered boundary.

## What to test

Choose only what fits the Skill:

- ordinary production use;
- missing information that can be recovered;
- ambiguity or contradictory source material;
- a nearby request that should stay out of scope;
- unavailable tools or dependencies;
- long input or multiple objects;
- a replay of a known failure.

## Run labels

Use plain language:

- `static` — package or file checks only;
- `walkthrough` — the expected behavior was reviewed without a live target runtime;
- `runtime` — executed in the intended runtime/model;
- `field` — observed during actual repeated use.

Do not upgrade one label into another without a new run or observation.
