#!/usr/bin/env python3
"""Small lint-and-pack helper for Agent Skill folders."""
from __future__ import annotations

import argparse
import hashlib
import re
import sys
import zipfile
from pathlib import Path

FM_BLOCK = re.compile(r"\A---\s*\n(?P<body>.*?)\n---\s*\n", re.S)
FIELD = re.compile(r"^(?P<key>[A-Za-z0-9_-]+):\s*(?P<value>.+?)\s*$")
GOOD_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
CODE_LINK = re.compile(r"`((?:references|scripts|assets|agents)/[^`]+)`")
IGNORED = {".git", "__pycache__", ".DS_Store"}


def read_header(path: Path) -> dict[str, str]:
    raw = path.read_text(encoding="utf-8")
    hit = FM_BLOCK.search(raw)
    if not hit:
        raise ValueError("missing or malformed frontmatter")
    values: dict[str, str] = {}
    current = None
    for row in hit.group("body").splitlines():
        match = FIELD.match(row)
        if match:
            current = match.group("key")
            values[current] = match.group("value").strip('"\'')
        elif current and row.startswith((" ", "\t")):
            values[current] += " " + row.strip()
    return values


def lint(folder: Path) -> int:
    skill_file = folder / "SKILL.md"
    problems: list[str] = []
    notes: list[str] = []

    if not skill_file.exists():
        problems.append("SKILL.md not found")
    else:
        try:
            meta = read_header(skill_file)
        except ValueError as exc:
            meta = {}
            problems.append(str(exc))

        skill_name = meta.get("name", "")
        summary = meta.get("description", "")
        if not GOOD_NAME.fullmatch(skill_name):
            problems.append("name must be lowercase hyphen-case")
        if len(skill_name) > 64:
            problems.append("name is longer than 64 characters")
        if len(summary) < 40:
            problems.append("description should clearly state capability and trigger context")

        extras = sorted(set(meta) - {"name", "description"})
        if extras:
            notes.append("extra frontmatter fields: " + ", ".join(extras))

        body = skill_file.read_text(encoding="utf-8")
        for linked in CODE_LINK.findall(body):
            if not (folder / linked).exists():
                problems.append(f"missing referenced file: {linked}")

    ui_file = folder / "agents" / "openai.yaml"
    if ui_file.exists():
        ui = ui_file.read_text(encoding="utf-8")
        found = re.search(r'short_description:\s*["\']?(.*?)["\']?\s*$', ui, re.M)
        if found:
            label = found.group(1).strip().strip('"\'')
            if not 25 <= len(label) <= 64:
                problems.append("openai short_description should be 25-64 characters")

    for note in notes:
        print(f"NOTE  {note}")
    for issue in problems:
        print(f"FAIL  {issue}")
    if problems:
        return 1
    print("PASS  package lint")
    return 0


def iter_payload(folder: Path):
    for item in sorted(folder.rglob("*"), key=lambda p: p.as_posix()):
        if not item.is_file():
            continue
        rel = item.relative_to(folder)
        if any(part in IGNORED for part in rel.parts) or item.suffix == ".pyc":
            continue
        yield item, rel


def pack(folder: Path, target: Path) -> int:
    if lint(folder):
        return 1
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for src, rel in iter_payload(folder):
            entry = zipfile.ZipInfo(f"{folder.name}/{rel.as_posix()}", (2026, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            archive.writestr(entry, src.read_bytes())
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    print(f"PACK  {target}")
    print(f"SHA256  {digest}")
    return 0


def main() -> int:
    cli = argparse.ArgumentParser(description="Lint or package an Agent Skill folder")
    modes = cli.add_subparsers(dest="mode", required=True)
    lint_cmd = modes.add_parser("lint")
    lint_cmd.add_argument("folder")
    pack_cmd = modes.add_parser("pack")
    pack_cmd.add_argument("folder")
    pack_cmd.add_argument("output")
    args = cli.parse_args()

    folder = Path(args.folder).resolve()
    if not folder.is_dir():
        print("FAIL  folder not found")
        return 2
    if args.mode == "lint":
        return lint(folder)
    return pack(folder, Path(args.output).resolve())


if __name__ == "__main__":
    raise SystemExit(main())
