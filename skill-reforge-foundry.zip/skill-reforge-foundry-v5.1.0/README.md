# Skill Reforge Foundry v5.1.0

A practical meta-Skill for building and improving Agent Skills from real tasks, rough prompts, SOPs, existing packages, and failure reports.

The package follows current public Skill conventions: concise activation metadata, progressive disclosure, optional supporting resources, realistic test cases, deterministic utilities where they help, and verified release checks.

## What it does

- creates new Skills from concrete usage examples;
- refactors older Skills without automatically inheriting their structure;
- chooses between single-file, reference-backed, tool-backed, asset-backed, and mixed packages;
- builds a compact realistic test bench;
- checks package integrity and produces deterministic release ZIPs;
- includes OpenAI-facing `agents/openai.yaml` metadata.

## Install

Place the folder in a runtime that supports Agent Skills. Python 3.10+ is recommended for the bundled utility. No third-party Python package is required.

## Validate

```bash
python scripts/forgecheck.py lint .
```

## Build a release

```bash
python scripts/forgecheck.py pack . ../skill-reforge-foundry-v5.1.0.zip
```

The build script writes the archive SHA-256 after packaging.
