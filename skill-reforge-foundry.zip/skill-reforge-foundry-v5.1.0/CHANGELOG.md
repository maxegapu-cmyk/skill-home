# Changelog

## 5.1.0

- Simplified the main workflow around concrete examples, package shape, implementation, realistic tests, and release checks.
- Added `agents/openai.yaml` using current OpenAI Skill UI metadata conventions.
- Reduced mandatory scaffolding; small Skills can remain single-file.
- Added package-shape guidance and a compact test-bench reference.
- Tightened metadata checks around the two fields used for activation across common Skill runtimes.
- Consolidated validation and deterministic packaging into one lightweight helper.
