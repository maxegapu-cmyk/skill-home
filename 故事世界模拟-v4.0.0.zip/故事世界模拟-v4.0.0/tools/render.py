#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import load_json

def novel(run):
    lines=['# 候选正文路径','']
    for e in run.get('events',[]):
        r=e.get('rendering') or {}; text=r.get('prose') or e.get('summary','')
        lines.append(text.strip()); lines.append('')
    return '\n'.join(lines).rstrip()+'\n'
def fountain(run):
    out=[]
    for e in run.get('events',[]):
        r=e.get('rendering') or {}; slug=r.get('slugline') or 'INT./EXT. UNSPECIFIED - CONTINUOUS'; out += [slug,'']
        if r.get('action'): out += [r['action'],'']
        for d in r.get('dialogue',[]): out += [d.get('character','CHARACTER').upper(),d.get('text',''),'']
        if not r.get('action') and not r.get('dialogue'): out += [e.get('summary',''),'']
    return '\n'.join(out)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('--format',choices=['novel','fountain'],required=True); ap.add_argument('--out',required=True); a=ap.parse_args(); run=load_json(a.run); txt=novel(run) if a.format=='novel' else fountain(run); Path(a.out).write_text(txt,encoding='utf-8'); print(a.out)
if __name__=='__main__': main()
