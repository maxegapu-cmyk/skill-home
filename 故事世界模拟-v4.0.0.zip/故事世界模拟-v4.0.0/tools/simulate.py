#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,copy,sys
from pathlib import Path
from common import load_json,read_jsonl,dump_json,schema_validate,deep_merge
from knowledge import missing,active_knowledge
from metrics import derive_metrics

ALLOWED_EFFECTS={'fact_set','fact_delete','entity_patch','resource_delta','move','knowledge_grant','promise_update'}

def locate(spacetime,entity_id,t):
    for e in spacetime.get('entities',[]):
        if e.get('id')!=entity_id: continue
        best={'t':float('-inf'),'place_id':e.get('place_id')}
        for pt in e.get('trajectory',[]):
            if float(pt.get('t',0))<=t and float(pt.get('t',0))>=best['t']: best={'t':float(pt['t']),'place_id':pt.get('place_id')}
        return best.get('place_id')
    return None

def preconditions_ok(facts,pcs):
    fails=[]
    for p in pcs or []:
        fid=p['fact_id']; op=p['op']; exists=fid in facts; val=facts.get(fid)
        ok=(op=='exists' and exists) or (op=='not_exists' and not exists) or (op=='eq' and exists and val==p.get('value')) or (op=='neq' and (not exists or val!=p.get('value')))
        if not ok: fails.append({'fact_id':fid,'op':op,'expected':p.get('value'),'actual':val if exists else None})
    return fails

def run_sim(project,plan):
    root=Path(project); pj=load_json(root/'project.json'); facts=load_json(root/'state'/'facts.json') if (root/'state'/'facts.json').exists() else {}
    knowledge=read_jsonl(root/'state'/'knowledge.jsonl'); promises=read_jsonl(root/'state'/'promises.jsonl')
    spacetime=load_json(root/'world'/'spacetime.json') if (root/'world'/'spacetime.json').exists() else {'entities':[]}
    intents=plan.get('intents',[]); errors=[]
    for i,it in enumerate(intents):
        for e in schema_validate(it,'intent.schema.json'): errors.append(f'intent[{i}] {e}')
    if errors: return {'ok':False,'schema_errors':errors,'events':[],'rejected':intents,'metrics':{}},1
    events=[]; rejected=[]; resource_claims={}; state=copy.deepcopy(facts); knowledge_work=list(knowledge)
    order=sorted(enumerate(intents),key=lambda z:(float(z[1]['story_time']),-int(z[1].get('priority',0)),z[0]))
    for _,it in order:
        reasons=[]; t=float(it['story_time']); actor=it['actor_id']
        miss=missing(knowledge_work,actor,t,it.get('required_knowledge',[]))
        if miss: reasons.append({'code':'KNOWLEDGE_MISSING','detail':miss})
        pcs=preconditions_ok(state,it.get('preconditions',[]))
        if pcs: reasons.append({'code':'PRECONDITION_FAILED','detail':pcs})
        if it.get('requires_colocation') and it.get('target_id'):
            a=locate(spacetime,actor,t); b=locate(spacetime,it['target_id'],t)
            if not a or a!=b: reasons.append({'code':'NOT_COLOCATED','detail':{'actor_place':a,'target_place':b}})
        for r in it.get('exclusive_resources',[]):
            key=(t,r)
            if key in resource_claims: reasons.append({'code':'RESOURCE_CONFLICT','detail':{'resource':r,'held_by':resource_claims[key]}})
        bad=[e.get('kind') for e in it.get('effects',[]) if e.get('kind') not in ALLOWED_EFFECTS]
        if bad: reasons.append({'code':'UNSUPPORTED_EFFECT','detail':bad})
        if reasons:
            rejected.append({'intent':it,'reasons':reasons}); continue
        for r in it.get('exclusive_resources',[]): resource_claims[(t,r)]=it['id']
        deltas=[]; kgrants=[]; pupdates=[]
        for eff in it.get('effects',[]):
            kind=eff['kind']
            if kind=='fact_set': state[eff['fact_id']]=eff.get('value'); deltas.append({'kind':'fact_set','target':eff['fact_id'],'value':eff.get('value')})
            elif kind=='fact_delete': state.pop(eff['fact_id'],None); deltas.append({'kind':'fact_delete','target':eff['fact_id']})
            elif kind=='entity_patch': deltas.append({'kind':'entity_patch','target':eff['target'],'value':eff.get('value',{})})
            elif kind=='resource_delta': deltas.append({'kind':'resource_delta','target':eff['target'],'value':eff.get('value',0)})
            elif kind=='move': deltas.append({'kind':'move','target':eff.get('target',actor),'value':{'place_id':eff.get('place_id')}})
            elif kind=='knowledge_grant':
                kg={'id':eff.get('id',f'k_{it["id"]}_{len(kgrants)+1}'),'subject_id':eff.get('subject_id',actor),'fact_id':eff['fact_id'],'learned_at':t,'forgotten_at':None,'source_event_id':None,'confidence':float(eff.get('confidence',1.0)),'status':eff.get('status','KNOWN'),'interpretation':eff.get('interpretation')}; kgrants.append(kg); knowledge_work.append(kg)
            elif kind=='promise_update': pupdates.append({'promise_id':eff['promise_id'],'status':eff.get('status'),'progress':eff.get('progress')})
        ev={'id':it.get('event_id',f'ev_{it["id"]}'),'status':'CANDIDATE','story_time':t,'sequence':len(events)+1,'summary':it.get('summary') or it['action'],'actor_id':actor,'participants':[x for x in [actor,it.get('target_id')] if x],'causes':it.get('causes',[]),'state_deltas':deltas,'knowledge_grants':kgrants,'promise_updates':pupdates,'telemetry':it.get('telemetry',{}),'rendering':it.get('rendering',{})}
        for kg in kgrants: kg['source_event_id']=ev['id']
        events.append(ev)
    metrics=derive_metrics(events,pj.get('protagonist_ids',[]),promises)
    return {'ok':True,'id':plan.get('id','run'),'base_canon_version':pj.get('canon_version',0),'t0':plan.get('t0'), 't1':plan.get('t1'),'events':events,'rejected':rejected,'metrics':metrics,'final_facts':state,'constraint_violations':[]},0

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('plan'); ap.add_argument('--out'); a=ap.parse_args()
    result,code=run_sim(a.project,load_json(a.plan))
    if a.out: dump_json(a.out,result)
    print(json.dumps(result,ensure_ascii=False,indent=2)); raise SystemExit(code)
if __name__=='__main__': main()
