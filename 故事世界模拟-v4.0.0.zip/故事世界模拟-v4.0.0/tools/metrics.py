from __future__ import annotations

def clamp(x): return max(0.0,min(1.0,float(x)))
def derive_metrics(events,protagonist_ids=None,promises=None):
    protagonist_ids=set(protagonist_ids or [])
    promises=promises or []
    if not events:
        return {'tension':0.0,'agency':0.0,'payoff_progress':0.0,'reveal_rate':0.0,'causal_density':0.0}
    tensions=[]; impactful_protag=0; protag_events=0; choices=0; reveals=0; causal=0
    progress=[]
    for e in events:
        tel=e.get('telemetry') or {}
        stakes=clamp(abs(float(tel.get('stakes_delta',0))))
        consequence=clamp(float(tel.get('consequence_weight',0)))
        pressure=clamp(float(tel.get('pressure',0)))
        tensions.append(clamp(0.4*stakes+0.4*consequence+0.2*pressure))
        if e.get('actor_id') in protagonist_ids:
            protag_events+=1
            choices += max(0,int(tel.get('choice_count',0)))
            if consequence>=0.25 or stakes>=0.25: impactful_protag+=1
        reveals += max(0,int(tel.get('reveal_count',0)))
        causal += len(e.get('causes',[]) or [])
        for p in e.get('promise_updates',[]) or []:
            if 'progress' in p: progress.append(clamp(p['progress']))
    tension=clamp(sum(tensions)/len(tensions))
    if protagonist_ids:
        agency=clamp((impactful_protag + 0.25*min(choices,4))/(max(1,protag_events)+1.0))
    else: agency=0.0
    if progress: payoff=sum(progress)/len(progress)
    else:
        vals=[float(p.get('progress',0)) for p in promises if p.get('status') in ('OPEN','ADVANCED','PAID')]
        payoff=sum(vals)/len(vals) if vals else 0.0
    return {'tension':round(tension,4),'agency':round(clamp(agency),4),'payoff_progress':round(clamp(payoff),4),'reveal_rate':round(clamp(reveals/max(1,len(events))),4),'causal_density':round(clamp(causal/max(1,len(events)*2)),4)}
