#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,shutil
from pathlib import Path
from common import *

def paths(root):
    r=Path(root); return {'root':r,'project':r/'project.json','events':r/'state'/'canon_events.jsonl','facts':r/'state'/'facts.json','knowledge':r/'state'/'knowledge.jsonl','promises':r/'state'/'promises.jsonl'}
def init(root,title='新故事'):
    p=paths(root); r=p['root']; r.mkdir(parents=True,exist_ok=True)
    for d in ['state','characters','memories','branches','world','monitors','runs','interventions','snapshots','drafts','chapters','style/voices','sources','imports']: (r/d).mkdir(parents=True,exist_ok=True)
    proj=load_json(ROOT/'templates'/'project.json'); proj['project_id']=r.name; proj['title']=title; dump_json(p['project'],proj); dump_json(p['facts'],{}); write_jsonl(p['events'],[]); write_jsonl(p['knowledge'],[]); write_jsonl(p['promises'],[]); write_jsonl(r/'chapters'/'ledger.jsonl',[]); write_jsonl(r/'interventions'/'ledger.jsonl',[]); dump_json(r/'world'/'places.json',{'places':[],'links':[]}); dump_json(r/'world'/'spacetime.json',{'entities':[]}); dump_json(r/'world'/'rules.json',{'rules':[]}); dump_json(r/'relationships.json',[]); dump_json(r/'monitors'/'default.json',load_json(ROOT/'templates'/'monitor.json')); dump_json(r/'style'/'style_bible.json',load_json(ROOT/'templates'/'style_bible.json')); return r

def validate(root):
    r=Path(root); errors=[]; warnings=[]
    if not (r/'project.json').exists(): return ['missing project.json'],warnings
    for e in schema_validate(load_json(r/'project.json'),'project.schema.json'): errors.append('project: '+e)
    specs=[('state/canon_events.jsonl','event.schema.json'),('state/knowledge.jsonl','knowledge.schema.json'),('state/promises.jsonl','promise.schema.json'),('chapters/ledger.jsonl','chapter.schema.json')]
    for rel,sch in specs:
        ids=set()
        try: rows=read_jsonl(r/rel)
        except Exception as ex: errors.append(str(ex)); continue
        for i,row in enumerate(rows,1):
            for e in schema_validate(row,sch): errors.append(f'{rel}:{i}: {e}')
            if row.get('id') in ids: errors.append(f'{rel}:{i}: duplicate id {row.get("id")}')
            ids.add(row.get('id'))
    for p in (r/'characters').glob('*.json'):
        for e in schema_validate(load_json(p),'character.schema.json'): errors.append(f'{p.name}: {e}')
    for p in (r/'memories').glob('*.json'):
        for e in schema_validate(load_json(p),'memory.schema.json'): errors.append(f'{p.name}: {e}')
    return errors,warnings

def snapshot(root,name):
    r=Path(root); dst=r/'snapshots'/name
    if dst.exists(): raise SystemExit('snapshot exists')
    dst.mkdir(parents=True); keep=['project.json','state','characters','memories','relationships.json','world','monitors','interventions','chapters','style']
    for rel in keep:
        s=r/rel
        if s.is_dir(): shutil.copytree(s,dst/rel)
        elif s.exists(): (dst/rel).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(s,dst/rel)
    dump_json(dst/'SNAPSHOT.json',{'name':name,'created_at':now(),'source_hash':sha_tree(root)}); return dst

def rollback(root,name):
    r=Path(root); src=r/'snapshots'/name
    if not src.exists(): raise SystemExit('snapshot missing')
    for rel in ['project.json','state','characters','memories','relationships.json','world','monitors','interventions','chapters','style']:
        s=src/rel; t=r/rel
        if t.is_dir(): shutil.rmtree(t)
        elif t.exists(): t.unlink()
        if s.is_dir(): shutil.copytree(s,t)
        elif s.exists(): t.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(s,t)

def commit(root,branch_file):
    r=Path(root); b=load_json(branch_file); pj=load_json(r/'project.json')
    errs=schema_validate(b,'branch.schema.json')
    if errs: raise SystemExit('branch schema invalid: '+'; '.join(errs))
    if b.get('status')!='ACCEPTED': raise SystemExit('branch must be ACCEPTED')
    if int(b.get('base_canon_version',-1))!=int(pj.get('canon_version',0)): raise SystemExit('stale branch: base_canon_version does not match current canon_version')
    existing=read_jsonl(r/'state'/'canon_events.jsonl'); ids={x.get('id') for x in existing}; new=b.get('events',[]); dup=[e['id'] for e in new if e.get('id') in ids]
    if dup: raise SystemExit('duplicate event ids: '+','.join(dup))
    for ev in new:
        e=dict(ev); e['status']='CANON'; append_jsonl(r/'state'/'canon_events.jsonl',e)
        for kg in e.get('knowledge_grants',[]): append_jsonl(r/'state'/'knowledge.jsonl',kg)
    facts=load_json(r/'state'/'facts.json')
    for ev in new:
        for d in ev.get('state_deltas',[]):
            if d.get('kind')=='fact_set': facts[d['target']]=d.get('value')
            elif d.get('kind')=='fact_delete': facts.pop(d['target'],None)
    dump_json(r/'state'/'facts.json',facts); pj['canon_version']=int(pj.get('canon_version',0))+1; pj['current_story_time']=max([float(e.get('story_time',pj.get('current_story_time',0))) for e in new] or [pj.get('current_story_time',0)]); dump_json(r/'project.json',pj)

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    x=sub.add_parser('init'); x.add_argument('project'); x.add_argument('--title',default='新故事')
    x=sub.add_parser('validate'); x.add_argument('project')
    x=sub.add_parser('snapshot'); x.add_argument('project'); x.add_argument('name')
    x=sub.add_parser('rollback'); x.add_argument('project'); x.add_argument('name')
    x=sub.add_parser('commit'); x.add_argument('project'); x.add_argument('branch')
    a=ap.parse_args()
    if a.cmd=='init': print(init(a.project,a.title))
    elif a.cmd=='validate':
        e,w=validate(a.project); print(json.dumps({'ok':not e,'errors':e,'warnings':w},ensure_ascii=False,indent=2)); raise SystemExit(1 if e else 0)
    elif a.cmd=='snapshot': print(snapshot(a.project,a.name))
    elif a.cmd=='rollback': rollback(a.project,a.name); print('rolled back')
    elif a.cmd=='commit': commit(a.project,a.branch); print('committed')
if __name__=='__main__': main()
