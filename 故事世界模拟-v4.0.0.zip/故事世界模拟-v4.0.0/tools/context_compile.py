#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path
from common import load_json,read_jsonl
from knowledge import active_knowledge
ALIASES={'停电':['停电','断电','power failure','power outage','outage'],'暴风雨':['暴风雨','风暴','storm'],'救援':['救援','营救','rescue'],'证据':['证据','线索','evidence','clue']}
def expand(cues):
    out=set()
    for cue in cues:
        c=cue.lower(); out.add(c)
        for _,vals in ALIASES.items():
            if any(c==v.lower() or c in v.lower() or v.lower() in c for v in vals): out.update(v.lower() for v in vals)
    return out
def score_memory(m,cues,at=None):
    s=.45*float(m.get('importance',0))+.25*float(m.get('accessibility',0)); hay=' '.join(map(str,m.get('triggers',[])+[m.get('objective_event',''),m.get('perceived_event',''),m.get('appraisal','')])).lower()
    matches=sum(1 for c in expand(cues) if c and c in hay); s+=min(.3,.08*matches)
    if at is not None and isinstance(m.get('story_time'),(int,float)) and m['story_time']>at: return -1
    return round(s,4)
def compile_context(project,character,at,cues,limit):
    root=Path(project); pj=load_json(root/'project.json'); c=load_json(root/'characters'/f'{character}.json'); events=[e for e in read_jsonl(root/'state'/'canon_events.jsonl') if float(e.get('story_time',-1e30))<=at]
    events=sorted(events,key=lambda e:(float(e.get('story_time',0)),int(e.get('sequence',0))))
    mem=[]
    for mid in c.get('memory_ids',[]):
        p=root/'memories'/f'{mid}.json'
        if p.exists():
            m=load_json(p); sc=score_memory(m,cues,at)
            if sc>=0: m=dict(m,_score=sc); mem.append(m)
    mem.sort(key=lambda x:x['_score'],reverse=True)
    know=active_knowledge(read_jsonl(root/'state'/'knowledge.jsonl'),character,at)
    return {'project':{'project_id':pj['project_id'],'canon_version':pj['canon_version']},'at':at,'character':c,'knowledge':know,'recent_events':events[-8:],'relevant_memories':mem[:limit],'open_promises':[p for p in read_jsonl(root/'state'/'promises.jsonl') if p.get('status') in ('OPEN','ADVANCED') and (p.get('created_at') is None or float(p['created_at'])<=at)]}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('character'); ap.add_argument('--at',type=float,required=True); ap.add_argument('--cue',action='append',default=[]); ap.add_argument('--limit',type=int,default=6); a=ap.parse_args(); print(json.dumps(compile_context(a.project,a.character,a.at,a.cue,a.limit),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
