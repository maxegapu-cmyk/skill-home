#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from common import load_json

def evaluate(run,contract):
    metrics=run.get('metrics',{}); violations=[]; score=0.; total=0.
    for m in contract.get('metrics',[]):
        n=m['name']; w=float(m.get('weight',1)); total+=w; v=metrics.get(n)
        if v is None:
            if m.get('required'): violations.append({'code':'METRIC_MISSING','metric':n,'value':None})
            continue
        good=True
        if m.get('min') is not None and v<m['min']: good=False; violations.append({'code':'METRIC_BELOW_MIN','metric':n,'value':v,'limit':m['min']})
        if m.get('max') is not None and v>m['max']: good=False; violations.append({'code':'METRIC_ABOVE_MAX','metric':n,'value':v,'limit':m['max']})
        if good: score+=w
    for x in run.get('constraint_violations',[]): violations.append({'code':'CONSTRAINT_VIOLATION','detail':x})
    return {'ok':not violations,'violations':violations,'corridor_score':round(score/total if total else 1.,4),'metrics':metrics}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('contract'); a=ap.parse_args(); print(json.dumps(evaluate(load_json(a.run),load_json(a.contract)),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
