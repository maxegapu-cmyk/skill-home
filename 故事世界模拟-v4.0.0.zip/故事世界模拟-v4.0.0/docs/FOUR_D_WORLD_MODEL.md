# 4D World Model

## 1. Why XYZT

A static character bible answers “what is this person like?” A world model must also answer “where were they, when, under which state, and what could they physically or socially reach?”

Represent a queryable state using space plus story time.

A useful relative coordinate is:
`tau = t - t0`

Past and future differ in time, not by negating spatial coordinates.

## 2. Geometry is optional

Use exact `(x,y,z)` only when needed. Most stories benefit more from stable place IDs and containment:

`bedroom -> apartment -> tower -> district -> city`

Links can carry:
- travel time;
- access conditions;
- visibility;
- capacity;
- danger;
- opening hours;
- social permission.

## 3. Entity shapes

- point: a person or movable object;
- bounded region: a room, estate or territory;
- network: a family, corporation or faction spread across locations;
- composite: a city or country with internal subentities and territory.

## 4. Time validity

Facts should declare when they are true. “A owns the house” may begin at t=10 and end at t=90. Historical replay must not leak the later owner backward.

## 5. Worldline query

Given entity E and time T:
1. find latest accepted trajectory sample/event not later than T;
2. apply all valid deltas through T;
3. return location, state and uncertainty;
4. never use projected future as accepted history.
