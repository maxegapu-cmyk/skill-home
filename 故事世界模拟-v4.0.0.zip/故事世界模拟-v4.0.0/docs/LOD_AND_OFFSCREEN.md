# LOD and Off-screen World Evolution

## Why

A living world should not freeze when the camera leaves, but fully simulating every entity every minute is wasteful and noisy.

## Levels
- L0 background: no active tick; change only from explicit events.
- L1 aggregate: coarse periodic update.
- L2 plan: update goals, resources, relation pressure and deadlines.
- L3 actor: run intention/collision/consequence cycle.
- L4 scene: include micro-memory, tactic shifts, dialogue intention and blocking constraints.

## Promotion rules
Promote when causal relevance rises. Demote after consequences are safely summarized.

## Reconciliation
When an off-screen entity returns to high detail:
1. replay its coarse events;
2. materialize only state changes that have causes;
3. resolve contradictions against accepted history;
4. never invent a dramatic off-screen event solely to justify the present.
