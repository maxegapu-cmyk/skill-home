# Steering Protocol

## Baseline first
Never steer before observing a natural baseline. Otherwise the system cannot distinguish natural behavior from controller-created behavior.

## Candidate interventions
Create a small intervention set with different causal levers, not cosmetic variants.

For each intervention record:
- target deviation;
- mechanism;
- delivery channel;
- earliest effect time;
- cost;
- side effects;
- affected entities;
- reversibility;
- whether explicit human approval is required.

## Evaluation
1. hard constraints;
2. character integrity;
3. causal plausibility;
4. target corridor improvement;
5. intervention cost;
6. unwanted long-horizon debt.

## Controller debt
A convenient intervention may create future obligations. Track them. Example: an emergency used to force two characters together must have realistic aftermath instead of disappearing after the scene.
