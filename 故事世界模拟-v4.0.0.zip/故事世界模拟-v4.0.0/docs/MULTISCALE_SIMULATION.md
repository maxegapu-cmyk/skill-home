# Multi-scale Simulation

A story may span one person, a household, a family, a company and a country. They cannot all be simulated with the same cognitive model.

## Individual
Use memory, belief, desire, fear, tactics and local resources.

## Household / family
Use member-level actors plus shared assets, obligations, reputation, secrets and routines. Aggregate only what is genuinely shared.

## Organization
Use leadership, departments/factions, authority, resources, policy, information flow and incentives.

## City / nation
Use institutions, factions, aggregate resources, public narrative, crisis variables, law/policy and external relations. Drill down to individual actors only where causally relevant.

## Cross-scale propagation
Examples:
- one person's leak -> company scandal -> regulator response -> citywide layoffs -> family stress;
- drought -> food price change -> household budget pressure -> relationship conflict;
- family feud -> election funding shift -> institutional response.

Each cross-scale edge must name the transmission mechanism.
