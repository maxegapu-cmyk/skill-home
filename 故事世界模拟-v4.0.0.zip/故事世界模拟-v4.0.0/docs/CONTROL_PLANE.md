# Observation and Control Plane

## 1. Purpose

Natural story simulation can drift. A commercial or structural project may need a specific experience: faster escalation, a payoff before an episode boundary, fewer passive protagonist beats, lower production cost, or a controlled reveal schedule.

The answer is not to force characters. The answer is a feedback loop.

## 2. Three-plane separation

- Simulation plane: actors pursue goals.
- Observation plane: reads outcomes and metrics.
- Control plane: changes legal conditions and re-runs.

The controller does not own character intent.

## 3. Monitor contract

A contract contains:
- metrics;
- acceptable corridors;
- hard constraints;
- intervention budget;
- horizon;
- priorities;
- stop rules.

Example:
- protagonist agency >= 0.65;
- tension at episode end between 0.70 and 0.90;
- at least one open promise advances;
- no knowledge leak;
- intervention cost <= 3.

## 4. Observability

If a goal cannot be measured or approximated from the run, the system should not pretend to control it. Add an observable first.

## 5. Controllability

If no legal intervention can change a metric inside the requested horizon, report the world as uncontrollable under the current constraints. Do not violate character logic to hit a target.

## 6. Minimal intervention

Prefer changing one upstream condition that causes several downstream improvements. Penalize interventions that require many unrelated coincidences.

## 7. Provenance

Every controlled run records:
- baseline run ID;
- monitor violations;
- intervention ID;
- reason;
- cost;
- affected variables;
- side effects;
- final metric changes.
