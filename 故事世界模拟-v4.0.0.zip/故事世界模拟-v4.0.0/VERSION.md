# Version

- Product: 故事世界模拟 / Story World Simulator
- Version: 4.0.0
- Status: tested release candidate
