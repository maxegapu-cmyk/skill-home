# Architecture — v4.0

## 1. 四层架构

### A. Canon / World State
`W(t) = {facts, entities, locations, relationships, resources, institutions, promises, knowledge, events}`

### B. Intent / Simulation
角色或 AI 提交 `Intent`，只描述“想做什么”和它自称依赖什么信息。引擎负责检查：
- actor 是否存在；
- required knowledge 是否在该时间已获得；
- fact preconditions 是否成立；
- 是否需要共址且真的共址；
- 排他资源是否冲突；
- effects 是否属于允许的确定性 effect 类型。

### C. Observation / Control
从候选事件的 telemetry 和开放承诺派生指标。Monitor 只判断目标区间；Steering 根据 violation code 生成结构化干预，并通过 ledger 扣预算。

### D. Render
Novel / Screenplay 只读取事件路径与角色口吻，不反向篡改世界事实。

## 2. AI 与代码的责任边界

代码不假装理解文学。对“羞耻、爱、背叛、恐惧是否成立”这类语义问题，AI 可以给结构化判断；但一旦进入引擎，必须落为可审计字段（例如 `telemetry.stakes_delta`、`knowledge_grants`、`promise_updates`、`evidence`）。

## 3. 正史版本控制

每个分支记录 `base_canon_version`。提交采用乐观锁：版本不同即拒绝，避免基于旧世界的分支覆盖新正史。提交成功后 `canon_version += 1`。
