# Playbook

## ANALYZE
导入资料到 `sources/`，用 `ingest.py` 生成候选记录；人工确认后再写角色、事实、事件、知识与承诺。

## SIMULATE
1. 编译目标角色在 `t` 时刻可见上下文。
2. AI/用户提交 intents。
3. `simulate.py` 逐条按 `(story_time, priority, input order)` 执行。
4. 非法意图记录为 rejected，不自动补剧情。
5. 合法意图变成候选 events，并派生 metrics。

## STEER
Monitor 先输出 code 化 violations。Steering 只针对 code 建议动作，并从预算账本计算剩余额度；预算不足则不生成超支建议。

## NOVEL / SCREENPLAY
选择一个 run 或 branch，用 `render.py` 输出 Markdown 或 Fountain。渲染层可以补语言，不得新增改变因果的事件。

## COMMIT
`branch.status=ACCEPTED` → `audit --branch` → 检查版本锁、重复 ID → 写正史 → 写知识增量/事实增量 → canon_version +1。
