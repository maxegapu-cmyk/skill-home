import json, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    out=Path(td)/"plan.json"
    subprocess.run(["python",str(ROOT/"scripts/plan_packaging.py"),str(ROOT/"examples/sample_transcript.srt"),"-o",str(out)],check=True)
    data=json.loads(out.read_text(encoding="utf-8"))
    assert data["events"], "no events generated"
    subprocess.run(["python",str(ROOT/"scripts/validate_plan.py"),str(out)],check=True)
print("smoke ok")
