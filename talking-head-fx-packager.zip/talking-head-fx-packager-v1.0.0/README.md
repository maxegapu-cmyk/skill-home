# Talking Head FX Packager v1.0.0

一个专门处理“口播特效包装层”的 Agent Skill。

它不默认重剪整条视频，而是根据口播含义输出：字幕策略、重点词、数字冲击、图卡、截图/证据窗口、B-roll、UI 标注、轻推近、转场、音效与视觉休息段。

## 快速用法

### Agent
把整个文件夹放进你的 skills 目录，让 Agent 读取 `SKILL.md`。

### 命令行生成起始方案
```bash
python scripts/plan_packaging.py examples/sample_transcript.srt -o examples/sample_plan.json --title "口播包装示例"
python scripts/validate_plan.py examples/sample_plan.json
```

这个 Python 脚本只是“保守起稿器”。真正的 Agent 应结合语义、画面、素材和品牌风格对方案二次判断。

## 五种风格
- clean_creator：通用干净型
- editorial_premium：高级克制型
- fast_social：短视频快节奏型
- playful_commentary：娱乐吐槽型
- tech_interface：科技/UI型

## 设计原则
核心不是“更多特效”，而是让观众每一刻知道：谁是主角、哪里是证据、什么是重点、什么时候该休息。
