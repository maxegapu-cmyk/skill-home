---
name: talking-head-fx-packager
description: Turn a talking-head script, transcript, SRT/VTT, or rough timeline into a restrained, editor-ready effects-packaging plan: captions, emphasis typography, callouts, punches, overlays, B-roll prompts, UI cards, transitions, SFX cues, and density control. Does not rewrite the content or replace the primary edit unless explicitly asked.
version: 1.0.0
---

# Talking Head FX Packager

## What this skill is
A packaging director for spoken-content videos. It converts meaning and delivery rhythm into an editor-ready packaging plan instead of blindly stacking effects.

Use it for:
- 口播 / talking head / vlog / knowledge explainer / review / tutorial / product intro
- vertical 9:16, square 1:1, landscape 16:9
- script-only planning, timestamped subtitle planning, or post-edit packaging
- CapCut/Jianying, Premiere, After Effects, DaVinci, Remotion, or other NLEs

Do NOT treat this as a full editing engine by default. The core job is the visual + sonic packaging layer.

## Trigger examples
- “把这条口播包装一下”
- “给这段口播加特效、字幕、重点字卡”
- “别太花，帮我做高级口播包装”
- “按时间轴告诉我哪里放什么包装”
- “做一套剪映/PR 能照着执行的包装方案”

## Input priority
Accept the richest available source without blocking:
1. Timestamped transcript / SRT / VTT
2. Transcript + duration
3. Script only
4. Rough notes + target duration

Optional context:
- target platform and aspect ratio
- intended audience
- brand/style references
- desired intensity: low / medium / high
- available assets: screenshots, product shots, charts, photos, screen recordings

If optional context is missing, use these safe defaults:
- aspect_ratio: follow source if known, else 9:16
- style: clean_creator
- intensity: medium
- audience pace: general internet viewer

## Core principle
Package meaning, not every sentence.

A strong talking-head edit usually alternates among four states:
- FACE: let the speaker carry the moment
- EMPHASIS: reinforce one idea without replacing the speaker
- EVIDENCE: show proof, example, product, chart, screenshot, or B-roll
- RESET: give the eye a short visual rest before the next idea

The skill must preserve contrast between these states. If everything moves, nothing feels important.

## Workflow

### 1. Parse semantic beats
Split the speech by idea changes, not fixed seconds. Mark each beat as one of:
- hook
- claim
- explanation
- example
- contrast
- list
- number/data
- instruction
- proof/evidence
- emotional beat
- punchline
- CTA

### 2. Score packaging need
For each beat, estimate:
- importance: 0-3
- visualizability: 0-3
- novelty: 0-2
- emotional energy: 0-2
- proof need: 0-2

Default packaging score = importance + visualizability + novelty + emotional energy + proof need.

Interpretation:
- 0-3: FACE / almost no packaging
- 4-6: light emphasis
- 7-9: visible packaging event
- 10-12: hero packaging event, usually evidence or a structured graphic

Never use the score mechanically. It is a sanity check, not a substitute for editorial judgment.

### 3. Choose one primary event per beat
Allowed primary event types:
- caption_focus
- keyword_pop
- phrase_card
- numeric_hit
- list_build
- comparison_split
- evidence_insert
- broll_window
- screenshot_focus
- ui_callout
- object_label
- diagram_micro
- quote_card
- chapter_reset
- punch_zoom
- freeze_annotate
- reaction_sticker
- progress_indicator
- cta_lockup

A beat may have secondary micro-effects, but only one primary visual idea.

### 4. Apply density budget
Default density rules:
- Never fire two hero events back-to-back unless the script itself is escalating.
- Keep at least 0.6-1.2s of visual breathing room after a heavy event.
- Avoid changing more than 2 visual dimensions at once (e.g. camera scale + typography + background all at once).
- Effects must not obscure eyes, mouth, hands, product, or evidence unless that obstruction is intentional and brief.
- Repeated effects should establish a visual grammar, not look random.

Suggested event rate by intensity:
- low: 1 meaningful event every 6-12s
- medium: 1 every 3-7s
- high: 1 every 1.8-4s, with regular reset beats

These are pacing guides, not hard limits.

### 5. Match effect to semantic function
Use `references/effect-grammar.md`.

Examples:
- exact number -> numeric_hit, not random sticker
- contrast -> comparison_split or paired phrase treatment
- 3-step instruction -> list_build / progress_indicator
- evidence -> screenshot_focus / evidence_insert
- emotional admission -> FACE with minimal captions, often no extra graphic
- punchline -> hold face first; add delayed micro reaction only if tone supports it

### 6. Choose style skin
Use `references/style-presets.md`.

Default is `clean_creator`.

### 7. Build the timeline plan
Output both:
1. Human-readable packaging sheet
2. Structured JSON conforming to `schemas/packaging-plan.schema.json`

Each event should include:
- start/end or anchor text when timing is unavailable
- semantic beat
- primary effect
- on-screen copy
- visual action
- sound cue
- layer priority
- safe-area note
- asset requirement
- exit behavior

### 8. Run anti-overpack pass
Before finalizing, remove any event that fails all three tests:
- Does it clarify?
- Does it intensify?
- Does it prove?

If no, delete it.

Then check:
- no identical hero effect 3 times in a row
- no persistent full-screen card replacing the speaker without a reason
- no emoji/sticker spam
- no constant zoom pumping
- no subtitle animation fighting with a separate headline animation
- no sound effect on every text entrance

### 9. Delivery format
Provide a concise summary first, then a timecoded table.

Recommended columns:
`time | spoken beat | visual packaging | text treatment | motion | SFX | asset | notes`

If the user asks for an editor handoff, add:
- global caption style
- global motion rules
- global sound rules
- safe areas
- reusable component list

## Caption rules
Captions are the base layer, not the hero layer.
- Segment by natural phrase, not arbitrary character count.
- Highlight only the semantic nucleus, usually 1-4 words.
- Avoid making every word bounce.
- For calm or premium material, use position/weight/opacity changes before scale explosions.
- For fast short-form material, active-word emphasis may be used, but hero typography should remain distinct from subtitles.

## Sound rules
SFX should signal hierarchy.
- micro UI tick: tiny informational changes
- soft whoosh: spatial or card entrance
- low hit: major claim / number / chapter change
- riser: anticipation before a reveal, used sparingly
- click/tap: interface or evidence interaction
- no SFX: emotional, intimate, reflective beats often work better dry

Never attach a sound to every animation.

## Camera treatment rules
Packaging may suggest camera treatments but should not fabricate missing footage.
Allowed:
- 102-108% digital punch-in for emphasis when source resolution permits
- short lateral crop shift to create separation between beats
- freeze + annotation when a visual detail must be explained
- background defocus/dim behind a card when readability needs it

Avoid repeated punch-zoom oscillation.

## Evidence hierarchy
When claims need support, prioritize:
1. real evidence supplied by user
2. exact screenshot / screen recording / product shot
3. simple data card using known facts
4. neutral diagram
5. decorative iconography

Do not invent proof, statistics, testimonials, screenshots, interfaces, or citations.

## Asset behavior
If an effect needs a missing asset, mark `asset_status: missing` and describe exactly what should be sourced or created. Do not pretend it exists.

## Platform notes
- 9:16: keep key text away from top/bottom UI zones; favor central and upper-middle readable regions.
- 16:9: allow more side-by-side comparison and evidence windows.
- 1:1: use shorter lines and avoid edge-heavy layouts.

## Output quality bar
A finished plan should feel like one designer made it:
- consistent spacing and motion family
- a limited type hierarchy
- repeated components with purposeful variation
- obvious hierarchy between subtitle, emphasis, evidence, and CTA
- enough quiet moments that strong effects still feel strong

## Fast mode
If user says “直接来 / 快速 / 傻瓜模式”:
1. choose `clean_creator`
2. medium intensity
3. keep captions always-on
4. select 6-12 meaningful packaging moments per minute
5. output an editor-ready table + JSON
6. do not ask non-blocking questions

## Strict mode
If user asks for high-end/premium packaging:
- use lower event density
- demand stronger semantic justification per event
- favor evidence, layout, typography, masking, and camera restraint over stickers
- enforce a visual motif across the whole piece

## Failure modes
Reject or repair these patterns:
- “每句话一个特效”
- random templates unrelated to meaning
- 5+ fonts/colors
- every keyword has a different animation
- fake screenshots/data
- subtitles occupying the same visual tier as hero text
- effects covering the speaker’s face continuously
- 100% screen time filled with cards/B-roll
- unmotivated glitch effects

## Files
- `references/effect-grammar.md`: effect choice by semantic function
- `references/style-presets.md`: five visual skins
- `schemas/packaging-plan.schema.json`: structured handoff format
- `scripts/plan_packaging.py`: deterministic starter planner from SRT or plain text
- `scripts/validate_plan.py`: schema-lite + editorial sanity validator
- `examples/`: sample input and output
