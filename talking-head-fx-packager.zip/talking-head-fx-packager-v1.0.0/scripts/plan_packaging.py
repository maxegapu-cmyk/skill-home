#!/usr/bin/env python3
"""Generate a conservative starter packaging plan from SRT or plain text.
Standard-library only. This is intentionally deterministic and editable.
"""
import argparse, json, re
from pathlib import Path

EFFECTS = {
    "number": ("numeric_hit", "scale + lock", "low hit"),
    "contrast": ("comparison_split", "wipe + reveal", "soft whoosh"),
    "list": ("list_build", "slide + settle", "micro tick"),
    "proof": ("evidence_insert", "wipe + reveal", None),
    "warning": ("phrase_card", "slide + settle", "low hit"),
    "cta": ("cta_lockup", "scale + lock", "soft whoosh"),
    "hook": ("keyword_pop", "scale + lock", "soft hit"),
    "default": ("caption_focus", "slide + settle", None),
}

def ts_to_sec(ts):
    h,m,sms = ts.split(":")
    s,ms = sms.split(",")
    return int(h)*3600 + int(m)*60 + int(s) + int(ms)/1000

def parse_srt(text):
    chunks = re.split(r"\n\s*\n", text.strip())
    out=[]
    for chunk in chunks:
        lines=[x.strip() for x in chunk.splitlines() if x.strip()]
        if len(lines) < 2: continue
        ti = 1 if re.fullmatch(r"\d+", lines[0]) else 0
        if ti >= len(lines) or " --> " not in lines[ti]: continue
        a,b=lines[ti].split(" --> ",1)
        spoken=" ".join(lines[ti+1:])
        out.append({"start":ts_to_sec(a),"end":ts_to_sec(b),"text":spoken})
    return out

def parse_plain(text):
    parts=[p.strip() for p in re.split(r"(?<=[。！？!?])\s*|\n+", text) if p.strip()]
    return [{"start":None,"end":None,"text":p} for p in parts]

def classify(t, i):
    low=t.lower()
    if i==0: return "hook"
    if re.search(r"\d|%|％|元|美元|倍|万|亿", t): return "number"
    if any(x in t for x in ["但是","但其实","相反","不是","而是","对比","vs","VS"]): return "contrast"
    if any(x in t for x in ["第一","第二","第三","步骤","首先","其次","最后"]): return "list"
    if any(x in low for x in ["截图","证据","数据","实测","测试","according","report"]): return "proof"
    if any(x in t for x in ["注意","千万","别","风险","警告"]): return "warning"
    if any(x in t for x in ["关注","点赞","收藏","评论","私信","下单","购买"]): return "cta"
    return "default"

def copy_for(t, kind):
    if kind=="number":
        m=re.search(r"[^，。！？!?]{0,8}(?:\d+(?:\.\d+)?\s*(?:%|％|元|美元|倍|万|亿)?)[^，。！？!?]{0,8}", t)
        return m.group(0).strip() if m else t[:16]
    if kind in {"contrast","warning","cta","hook"}: return t[:18]
    return None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o","--output",default="packaging-plan.json")
    ap.add_argument("--title",default="Untitled Talking Head")
    ap.add_argument("--aspect",default="9:16",choices=["9:16","16:9","1:1","source"])
    ap.add_argument("--style",default="clean_creator",choices=["clean_creator","editorial_premium","fast_social","playful_commentary","tech_interface"])
    ap.add_argument("--intensity",default="medium",choices=["low","medium","high"])
    args=ap.parse_args()
    p=Path(args.input); text=p.read_text(encoding="utf-8-sig")
    segs=parse_srt(text) if p.suffix.lower()==".srt" else parse_plain(text)
    events=[]
    for i,s in enumerate(segs):
        kind=classify(s["text"],i)
        effect,motion,sfx=EFFECTS[kind]
        priority="hero" if kind in {"number","proof"} else ("support" if kind in {"hook","contrast","list","warning","cta"} else "micro")
        # Conservative density: skip some default beats.
        if kind=="default" and i%3!=0: continue
        events.append({
            "id":f"fx-{len(events)+1:03d}","start_sec":s["start"],"end_sec":s["end"],
            "anchor_text":s["text"] if s["start"] is None else None,
            "beat":kind,"effect":effect,"onscreen_copy":copy_for(s["text"],kind),
            "visual_action":f"Use {effect} to reinforce this {kind} beat; keep speaker readable.",
            "motion":motion,"sfx":sfx,"priority":priority,
            "asset_status":"missing" if kind=="proof" else "none",
            "asset_need":"Real screenshot / data / footage supporting the claim" if kind=="proof" else None,
            "safe_area_note":"Keep eyes, mouth and platform UI zones clear.",
            "exit_behavior":"Return cleanly to FACE state; no lingering decorative motion."
        })
    duration=max([s["end"] or 0 for s in segs],default=0) or None
    plan={"version":"1.0.0","project":{"title":args.title,"aspect_ratio":args.aspect,"duration_sec":duration},
          "global":{"style":args.style,"intensity":args.intensity,"caption_mode":"phrase captions with selective keyword emphasis","motion_family":["slide + settle","scale + lock"],"sound_rule":"SFX only on hierarchy changes; no sound on every animation."},
          "events":events}
    Path(args.output).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"wrote {args.output} ({len(events)} events)")
if __name__=="__main__": main()
