#!/usr/bin/env python3
import argparse, json
from pathlib import Path

ALLOWED_STYLES={"clean_creator","editorial_premium","fast_social","playful_commentary","tech_interface"}
ALLOWED_INTENSITY={"low","medium","high"}
ALLOWED_PRIORITY={"micro","support","hero"}

def fail(msg, errors): errors.append(msg)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("plan"); args=ap.parse_args()
    data=json.loads(Path(args.plan).read_text(encoding="utf-8")); errs=[]; warns=[]
    for k in ["version","project","global","events"]:
        if k not in data: fail(f"missing top-level key: {k}",errs)
    if errs:
        print("FAIL"); [print("-",x) for x in errs]; raise SystemExit(1)
    g=data["global"]
    if g.get("style") not in ALLOWED_STYLES: fail("invalid global.style",errs)
    if g.get("intensity") not in ALLOWED_INTENSITY: fail("invalid global.intensity",errs)
    events=data["events"]
    last_effect=None; streak=0; hero_streak=0
    for i,e in enumerate(events):
        for k in ["id","beat","effect","visual_action","priority"]:
            if k not in e: fail(f"event {i} missing {k}",errs)
        if e.get("priority") not in ALLOWED_PRIORITY: fail(f"event {i} invalid priority",errs)
        effect=e.get("effect")
        if effect==last_effect: streak+=1
        else: streak=1; last_effect=effect
        if streak>=3: warns.append(f"events around {i}: same effect repeated {streak} times")
        if e.get("priority")=="hero": hero_streak+=1
        else: hero_streak=0
        if hero_streak>=3: warns.append(f"events around {i}: 3+ hero events back-to-back; add a reset")
        a,b=e.get("start_sec"),e.get("end_sec")
        if a is not None and b is not None and b<a: fail(f"event {i} end before start",errs)
        if e.get("beat")=="proof" and e.get("asset_status") not in {"available","missing"}:
            warns.append(f"event {i}: proof beat should explicitly mark evidence asset status")
    print("PASS" if not errs else "FAIL")
    print(f"events={len(events)} errors={len(errs)} warnings={len(warns)}")
    for x in errs: print("ERROR:",x)
    for x in warns: print("WARN:",x)
    raise SystemExit(1 if errs else 0)
if __name__=="__main__": main()
