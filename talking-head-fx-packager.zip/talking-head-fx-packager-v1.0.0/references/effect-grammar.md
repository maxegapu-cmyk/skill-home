# Effect Grammar

The effect is chosen for what the sentence is doing.

| Semantic job | Preferred packaging | Avoid |
|---|---|---|
| Hook / surprising premise | short keyword_pop, phrase_card, restrained punch_zoom | full intro animation before the hook lands |
| Exact number / price / percentage | numeric_hit with unit locked to number | decorative chart without data |
| Definition | phrase_card + small supporting label | five unrelated icons |
| Contrast / A vs B | comparison_split, paired labels | sequential cards that hide the comparison |
| Step-by-step | list_build, progress_indicator | all steps appearing at once |
| Evidence / proof | screenshot_focus, evidence_insert, freeze_annotate | AI-fabricated evidence |
| Example / story beat | broll_window or object_label | generic stock montage unless needed |
| Warning / caveat | short alert bar / edge marker | alarm-red full screen for mild caveats |
| Emotional confession | FACE + minimal subtitle emphasis | meme overlays fighting the face |
| Punchline | face hold, optional delayed micro-sticker or type snap | pre-empting the joke with animation |
| CTA | cta_lockup tied to exact action | persistent CTA through the whole video |

## Motion families
Choose 1 primary family and 1 secondary family per video.

### Slide + settle
Best general-purpose family. Cards or labels enter 12-32 px equivalent, ease out, settle without bounce.

### Scale + lock
Use for numbers or major keywords. Enter from ~92-96% to 100%; avoid giant elastic scaling.

### Wipe + reveal
Use for comparisons, screenshots, masked evidence, before/after.

### Draw + trace
Use for diagrams, arrows, underlines, annotations.

### Cut + snap
Use for comedy, opinionated creator content, or fast hooks. Do not apply to calm premium material.

## Layer hierarchy
1. Source speaker / primary footage
2. Evidence or B-roll when active
3. Hero emphasis graphic
4. Subtitle layer
5. Micro labels / decorative accents
6. Watermark / persistent brand marks

Hero graphics should not compete with evidence. If evidence is on screen, typography becomes support unless the text itself is the evidence.

## Entrance/exit timing guide
- micro label: 120-220ms in, 120-180ms out
- keyword emphasis: 160-300ms in, 180-260ms out
- card: 220-420ms in, 180-320ms out
- evidence window: 280-520ms in, 240-420ms out
- chapter reset: 350-700ms total transition

Use shorter timings at high speech tempo, longer at calm tempo.
