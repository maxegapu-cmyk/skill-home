# Style Presets

## clean_creator (default)
Modern, readable, creator-friendly, adaptable.
- 1 bold sans + 1 regular sans
- neutral base with 1 accent color
- rounded or square cards, not both
- motion: slide + settle, scale + lock
- icons: minimal
- SFX: sparse ticks / soft whooshes / low hits
- best for: tutorials, AI, tech, education, reviews

## editorial_premium
Calmer, expensive, magazine-like.
- strong grid and whitespace
- large but restrained type
- low saturation or muted palette
- motion: masks, wipes, gentle parallax
- almost no stickers
- SFX: rare, soft, low-frequency accents
- best for: interviews, finance explainers, design, business, long-form Bilibili/YouTube

## fast_social
Dense, energetic, short-form optimized.
- larger captions
- frequent active-word emphasis
- strong contrast
- motion: cut + snap, controlled scale
- B-roll punches are short
- SFX: more frequent, but only on hierarchy changes
- best for: Douyin/TikTok/Reels/Shorts

## playful_commentary
Humorous, reactive, personality-first.
- stickers/reaction elements allowed
- irregular but bounded placement
- motion: snap, pop, delayed reaction
- meme inserts only when context supports them
- preserve facial reactions
- best for: commentary, entertainment, game talk, casual creator content

## tech_interface
UI/system aesthetic without turning into fake software.
- labels, brackets, data chips, cursor/highlight motifs
- motion: trace, scan, focus frame, panel reveal
- use real screenshots when claiming interface behavior
- no fake terminal/code unless illustrative and clearly generic
- best for: software, AI tools, workflows, product demos

## Preset selection heuristic
- unclear request -> clean_creator
- “高级 / 克制 / 电影感 / 品牌感” -> editorial_premium
- “抖音感 / 快节奏 / 抓人” -> fast_social
- “搞笑 / 吐槽 / 娱乐” -> playful_commentary
- “科技 / 软件 / AI / 工具演示” -> tech_interface
