# Changelog

## 2.1.0 — Reference-Family Lock / Adult Drift Root Fix

- Promoted Reference Style Authority above identity/class/content.
- Added Render / Facial / Material / Lighting hard Style Gates.
- Added adult human masculine/feminine and elder human class profiles.
- Added mandatory adult smoke test before batch character production.
- Added reference-locked character master prompt.
- Added positive-prompt hazard rewrite rules for pores, rough skin, stubble, gritty wear and dark concept lighting.
- Added fail-fast diagnostics for western concept, photoreal adult, dark/gritty and generic anime-3D drift.
- Shifted current profile to bright pale-cool high-key asset presentation.
- Added regression tests for the exact failure signatures observed in production.

## 2.0.1 — Package Polish

- Refined package presentation and entry-point wording.
- Improved package cleanliness and version-consistency checks.
- Preserved the full style-fidelity, asset-management, installation, QA and release workflow.

## 2.0.0 — High-Fidelity Asset System Rebuild

Major upgrade from v1.0.0.

### Style fidelity
- Added 12-D Style Fingerprint.
- Split childlike, adult and elder anthropomorphic character classes.
- Added dedicated Face / Skin / Fur Boundary logic.
- Added eye wetness / tearline / age-plane checks.
- Added World Grammar for monumental ceremonial architecture.
- Added reference-role matrix for style / identity / costume / pose separation.

### Asset management
- Added component / assembly model.
- Added stable asset IDs, versions, dependencies, states and QA.
- Added `assetctl.py` for init/register/list/validate.
- Added asset registry JSON schema.

### Usability / installation
- Added `START-HERE.md`.
- Added safe installer with dry-run and backup-on-replace.
- Added Windows and POSIX wrappers.
- Added `doctor.py`.
- Removed third-party Python dependencies for package utilities.

### Quality / release
- Replaced script-only pseudo-tests with discoverable pytest tests.
- Strengthened package-hygiene and release validation checks.
- Added cache / residue checks.
- Added Fresh Extract release protocol.
