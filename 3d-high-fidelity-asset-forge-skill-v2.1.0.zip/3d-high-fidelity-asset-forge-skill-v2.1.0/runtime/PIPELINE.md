# Runtime Pipeline v2.1 — Reference Style Authority

State machine:
`BOOT -> INGEST -> COVERAGE -> STYLE_AUTHORITY -> CLASS_SPLIT -> LOOKDEV -> WORLD_GRAMMAR -> ASSET_COMPILE -> PROMPT_COMPILE -> STYLE_GATES -> QA -> PUBLISH`

## 0. BOOT
- 读取 START-HERE。
- 如果用户明确要求当前参考视频/帧同风格，加载 `CINEMATIC_CEREMONIAL_FANTASY_3D_A`。
- 人物任务加载 `REFERENCE_STYLE_CHARACTER_MASTER.md`。

## 1. INGEST / 2. COVERAGE
按信息增益检查脸、全身、不同年龄、材质、环境、道具、不同景别。

## 3. STYLE_AUTHORITY
先锁四个 Family：
`RENDER -> FACIAL -> MATERIAL -> LIGHTING`
每一门记录：must-match / forbidden / evidence / confidence。

当前 Profile 的关键结果必须明确写出：
- bright clean premium stylized 3D animation
- soft adult facial planes
- expressive moist eyes
- clean SSS skin without pore-led realism
- refined groom
- pale cool high-key atmospheric lighting
- no western/gritty/photoreal concept-art family

## 4. CLASS_SPLIT
成人骨架可以真实成立，但**视觉媒介不能真人化**。
如果输入为成年男性且没有明确 Class Profile，默认 `ADULT_HUMAN_MASCULINE`，不得回退到 photoreal human。

## 5. LOOKDEV
优先：face -> eyes -> skin -> hair/fur -> cloth -> props。
年龄、疲惫、贫穷只改变大中型结构和状态，不改变材质家族。

## 6. WORLD_GRAMMAR
当前世界：明亮、干净、东方幻想、浅色石材、柔和空气感。具体场景可现代/其他内容化，但只要用户要求“同风格”，渲染和材质必须保留同家族。

## 7. ASSET_COMPILE
保持 stable id / style profile / class profile / version / dependencies / anchors / qa。

## 8. PROMPT_COMPILE
必须：
1. 先插入 Style Authority；
2. 再插四个 Family；
3. 再写 Class / Identity；
4. 对高风险写实词执行 Rewrite；
5. 最后加入 Forbidden Routes 和 Same-Work Self-Check。

**禁止依赖 Negative Prompt 去挽救一个已经被正向写实词污染的 Prompt。**

## 9. STYLE_GATES
先判：
- Same-work Test
- Render Family
- Facial Family
- Material Family
- Lighting Family

任一失败：回退到 Prompt Compile / Lookdev；不进入发布。

## 10. QA
执行 `docs/SIMILARITY_QA.md`。

## 11. PUBLISH
发布前：doctor / registry / pytest / residue / version / Fresh Extract 全过。

## Mandatory Batch Rule
第一次批量角色前：
- 成人男性 smoke test 必须 PASS；
- 至少另一成人/年龄类 smoke test PASS；
- 才允许多人群像或 5+ 角色批量资产板。
