# Failure Recovery — Adult / Western / Photoreal Drift

## Symptom: 成人变真人
Delete or rewrite: realistic pores, rough skin, photoreal, realistic stubble, skin scan, deep eye socket emphasis.
Keep: adult skeleton, mature face, fatigue, age.
Re-express with: soft sculpted macro/mid forms, expressive eyes, clean SSS, stylized beard shadow.

## Symptom: 欧美冒险家 / 末世概念角色
Delete or rewrite: rugged, gritty, worn leather microcracks, sepia, dark studio, hard orange rim, western adventurer cues.
Restore: pale cool background, bright high-fill daylight, soft face, clean cloth, controlled wear.

## Symptom: 很漂亮但像另一部国漫/手游
Reduce 2D/anime exaggeration; preserve true 3D facial volume, restrained eye enlargement, premium materials, cinematic lighting.

## Recovery Order
`Prompt positive rewrite -> Style Family restore -> Class geometry -> Material detail scale -> Lighting -> Negative routes`
Never start by adding more negatives while leaving conflicting positive realism terms intact.
