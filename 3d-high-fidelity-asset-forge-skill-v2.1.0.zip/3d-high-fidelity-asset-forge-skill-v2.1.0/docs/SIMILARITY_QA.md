# Similarity QA v2.1 — Reference Family First

## Gate 0: SAME-WORK TEST
先遮掉姓名、服装、职业、道具，仅看：脸、眼睛、皮肤、头发、Shader、灯光。

如果不像参考视频同一部作品，**直接 FAIL**。资产板完整度、细节数量、服装漂亮都不能补偿。

## Four Style Gates — ALL REQUIRED
1. **Render Family Gate**：是否为明亮、干净、高规格动画电影 CGI，而非真人 CG / 游戏 / 欧美概念角色？
2. **Facial Family Gate**：成人是否仍是柔化动画脸，而非“为了成熟”变成深眼窝、硬眉骨、真人比例脸？
3. **Material Family Gate**：皮肤是否干净 SSS，头发是否精致 Groom，磨损是否为大中尺度美术化，而非毛孔 / 微裂纹 / 重污迹主导？
4. **Lighting Family Gate**：是否浅冷高明度、高 fill、柔阴影、轻空气感，而非暗灰/棕/强橙边缘光？

四门任一失败：整体不得 PASS。

## Critical Gates
- wrong 3D medium / render family
- wrong facial family
- wrong material family
- wrong lighting family
- wrong class proportions
- adult became photoreal / western concept character
- elder became photoreal skin scan
- skin/fur/hair boundary failure
- cross-view identity drift
- unrelated environment grammar
- prompt contradiction / risky realism term not rewritten

## Weighted Rubric — 100
- Same-work / Render Family: 20
- Facial Family & age-safe geometry: 20
- Eyes / expression: 8
- Skin / hair / fur / boundary: 14
- Material detail scale / costume / props: 10
- Lighting / exposure / background: 10
- Environment grammar: 6
- Camera / DOF: 4
- Cross-view consistency: 8

### Interpretation
- 92–100: release candidate（全部 Gates 通过）
- 86–91: strong, targeted fix required
- 78–85: broad family only, not high-fidelity
- <78: rebuild upstream

## Failure Signatures
### Western Concept Drift
症状：长脸、深眼窝、硬眉骨、暗棕皮革、灰黑背景、橙边光、粗糙微裂纹。
修复：回退 Prompt Compile，使用 Reference Master；提高 bright/pale-cool/soft-face/clean-SSS 权威，删除 rugged/gritty/photoreal 触发词。

### Adult -> Photoreal Drift
症状：成年男性毛孔、真实胡茬根、深鼻唇沟、摄影级皮肤。
修复：保留成年骨架；把年龄/疲惫改写成大中型雕刻结构 + 眼神 + 色泽，皮肤恢复 clean stylized SSS。

### Generic Chinese Anime 3D Drift
症状：很漂亮，但过度二次元、二维大眼、尖下巴、手游质感。
修复：降低动漫夸张，恢复柔和 3D 面部体积、克制眼睛放大、真实材质分离与电影光照。

### Dark/Gritty Drift
症状：暗棚、低 fill、褐色、强对比、重污迹。
修复：bright soft daylight + cool ambient fill + pale background + art-directed wear。

## Regression Set
正式 Style Profile 至少保留：
- 成年男性单人资产板（必测）
- 成年女性或第二成人类
- 幼体或老人类
- face close-up
- 环境
- 道具/材质

**不得仅用幼体成功样例验证成人。**
