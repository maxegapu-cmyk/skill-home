# Style Authority Contract — Current Reference

## Purpose
本合同用于阻止“角色身份描述比参考风格更具体，所以模型改走另一视觉家族”的失败。

## Authority
`Reference Style > Render/Facial/Material/Lighting Family > Class Geometry > Identity > Costume/Prop > Layout`

## Four Families
### Render
高规格动画电影 CGI；明亮、干净、柔润、具有可信材质，但明显不是真人。

### Facial
柔化面部平面；成年人维持成年骨架，但眼睛略动画化、五官大形更简洁、边缘更柔和。

### Material
皮肤 clean SSS；头发精致 Groom；布料磨损为美术化大中尺度；不以毛孔/裂纹/重污迹证明“真实”。

### Lighting
浅冷高明度、高 fill、柔和阴影、轻雾和空气感；禁止暗灰/暗棕/强橙轮廓光。

## Conflict Examples
- “35岁粗糙工人” -> 保留 35 岁骨架和疲惫神态；不生成毛孔级粗糙皮肤。
- “常年胡茬” -> soft stylized beard shadow；不生成摄影级毛囊。
- “衣服很破旧” -> 大中尺度磨损和色差；不生成末世皮革裂纹海。
- “强硬反派” -> 表情/姿态/眉眼强度变化；不切换深眼窝西方英雄脸。

## Fail Fast
出现“另一部作品”的视觉家族时直接回退 Prompt，不允许在错误图上继续补细节。
