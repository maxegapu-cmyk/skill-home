# Output Standard v2.0

## Character Pack
建议拆两张，不挤成一张：

### Sheet A — Identity / Turnaround
- hero 3/4
- front
- side
- back
- scale marker
- silhouette strip

### Sheet B — Lookdev / Performance
- face close-up
- 6 expressions
- hands / feet
- ears / tail / horn（如有）
- hair / fur direction callout
- skin / fur boundary callout
- costume layer breakdown
- material swatches
- key prop

## Environment Pack
- hero establishing shot
- plan-like spatial diagram
- architecture module strip
- floor / wall / pillar materials
- prop density samples
- atmosphere depth samples
- day / neutral lookdev light

## Prop Pack
- hero 3/4
- front / side / back / top
- scale reference
- construction layers
- material stack
- wear map
- grip / hinge / contact points

## Asset Output Status
每项输出必须标：
`DRAFT / REVIEW / APPROVED / BLOCKED / DEPRECATED`

## Prompt Handoff
每个 Prompt 拆成：
- immutable anchor block
- flexible design block
- scene-specific block
- negative drift block

这样同一资产换动作、镜头、场景时不必重写身份。


## v2.1 Reference-Locked Character Sheet
- Default board: bright pale cool-gray / blue-gray, high-key.
- Hero + turnaround + face close-up + six expressions + essential detail callouts.
- Do not use dark charcoal / brown concept-art boards for the current reference profile.
- If label text generation destabilizes identity, reduce labels before reducing character views or style fidelity.
- Adult smoke-test sheet is mandatory before multi-character batch production.
