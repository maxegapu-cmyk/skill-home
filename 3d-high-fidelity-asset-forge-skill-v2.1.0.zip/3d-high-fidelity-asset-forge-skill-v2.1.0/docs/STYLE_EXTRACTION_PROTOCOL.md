# Style Extraction Protocol v2.0

## 核心目标
不是描述“看起来像什么”，而是恢复“它为什么看起来是这样”。

## 12-D Style Fingerprint

### 1. Silhouette
- 大形是圆、尖、柱、薄片还是混合？
- 大中小形状比例？
- 服装轮廓是否扩张身体？

### 2. Proportion
- 头身比
- 肩宽 / 骨盆宽
- 四肢长度
- 手脚尺度
- 躯干压缩

### 3. Face Geometry
- 额头、眉骨、眼窝、颧骨、鼻、口周、下颌、下巴
- 幼态 / 成年 / 老年结构分别记录

### 4. Eyes
- 眼裂、眼距、虹膜占比
- 角膜高光、泪线、眼白曝光
- 是否存在动画化放大

### 5. Hair / Fur
- strand vs clump
- 长度分区
- 根部密度
- 方向场
- 耳缘 / 发际线 / 胡须边界
- rim response

### 6. Skin
- SSS 感
- 粗糙度
- 毛孔 / 微细节可见度
- 年龄褶皱
- 红润 / 血色 / 泪痕

### 7. Costume
- 层级
- 厚度
- 垂坠
- 刺绣 / 压纹 / 金属件
- 文化装饰密度

### 8. Props
- 轮廓
- 比例
- 构造方式
- 使用痕迹
- 与角色交互方式

### 9. Environment
- 建筑模块
- 空间尺度
- 负空间
- 重复节奏
- 表面年龄

### 10. Lighting
- key / fill / rim
- source size
- shadow softness
- atmosphere / bounce
- warm-cool relationship

### 11. Camera
- focal feel
- perspective compression
- camera height
- DOF
- face close-up behavior
- wide establishing behavior

### 12. Render / Post
- stylization/realism balance
- highlight rolloff
- bloom/haze
- sharpening
- saturation curve
- temporal softness（视频）

## Evidence Rule
每项都使用：
- `OBSERVED`: 画面直接可见
- `INFERRED`: 基于多帧稳定推断
- `UNCERTAIN`: 参考不足

不得把 `INFERRED` 写成客观事实。

## Similarity Priority
当资源有限时，按以下顺序修：
1. 角色类别比例
2. 脸部几何
3. 眼睛与口鼻
4. 毛发 / 皮肤边界
5. 材质差异
6. 灯光
7. 镜头
8. 色彩与装饰小细节
