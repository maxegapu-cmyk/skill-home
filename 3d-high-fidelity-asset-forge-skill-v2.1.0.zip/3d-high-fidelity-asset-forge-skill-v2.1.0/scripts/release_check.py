#!/usr/bin/env python3
import subprocess, sys, os, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
cmds=[
 [sys.executable,str(ROOT/"scripts/lint_skill.py")],
 [sys.executable,str(ROOT/"scripts/doctor.py")],
 [sys.executable,"-m","pytest","-q","-p","no:cacheprovider",str(ROOT/"tests")]
]
env=os.environ.copy(); env["PYTHONDONTWRITEBYTECODE"]="1"
for residue in [ROOT/".pytest_cache", ROOT/"tests"/"__pycache__"]:
    if residue.exists(): shutil.rmtree(residue)
try:
    for c in cmds:
        r=subprocess.run(c,cwd=ROOT,env=env)
        if r.returncode: raise SystemExit(r.returncode)
finally:
    for residue in [ROOT/".pytest_cache", ROOT/"tests"/"__pycache__"]:
        if residue.exists(): shutil.rmtree(residue)
print("PASS release checks")
