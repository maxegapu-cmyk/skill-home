#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=["START-HERE.md","README.md","SKILL.md","VERSION","manifest.json","runtime/PIPELINE.md","profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json","prompts/REFERENCE_STYLE_CHARACTER_MASTER.md","scripts/assetctl.py","scripts/prompt_guard.py"]
for rel in required:
    if not (ROOT/rel).exists(): errors.append(f"missing {rel}")
version=(ROOT/"VERSION").read_text(encoding="utf-8").strip() if (ROOT/"VERSION").exists() else ""
try:
    manifest=json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))
    if manifest.get("version")!=version: errors.append("manifest version mismatch")
except Exception as e: errors.append(f"manifest invalid: {e}")
try:
    profile=json.loads((ROOT/"profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json").read_text(encoding="utf-8"))
    for k in ["profile_id","authority_order","style_gates","immutable_anchors","character_classes","lookdev","lighting_camera","world_grammar","forbidden_drift"]:
        if k not in profile: errors.append(f"style profile missing {k}")
except Exception as e: errors.append(f"style profile invalid: {e}")
residue=[]
for p in ROOT.rglob("*"):
    if ".pytest_cache" in p.parts or "__pycache__" in p.parts or p.suffix==".pyc": residue.append(str(p.relative_to(ROOT)))
if residue: errors.append("cache residue: "+", ".join(residue[:8]))
if errors:
    print("FAIL doctor")
    for e in errors: print(" -",e)
    raise SystemExit(2)
print(f"PASS doctor v{version}")
print("entrypoint: START-HERE.md -> SKILL.md -> runtime/PIPELINE.md")
print("style profile: CINEMATIC_CEREMONIAL_FANTASY_3D_A")
