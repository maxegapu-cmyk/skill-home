#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path

ALLOWED_TYPES={"character","environment","prop","material","lighting_rig","camera_rig","assembly"}
ALLOWED_STATUS={"draft","review","approved","blocked","deprecated"}
SEMVER_RE=re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$")

def registry_path(project: Path) -> Path: return project / "asset_registry.json"
def load(project: Path):
    p=registry_path(project)
    if not p.exists(): raise SystemExit(f"registry not found: {p}. Run: assetctl.py init <project>")
    return json.loads(p.read_text(encoding="utf-8"))
def save(project: Path, data):
    project.mkdir(parents=True, exist_ok=True)
    registry_path(project).write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def semver_key(v):
    m=SEMVER_RE.match(v or "")
    return tuple(map(int,m.groups())) if m else (-1,-1,-1)
def find_asset(data, asset_id, version=None):
    matches=[a for a in data.get("assets",[]) if a.get("id")==asset_id and (version is None or a.get("version")==version)]
    if not matches: raise SystemExit(f"asset not found: {asset_id}"+(f"@{version}" if version else ""))
    if version is None:
        approved=[a for a in matches if a.get("status")=="approved"]
        pool=approved or matches
        return max(pool,key=lambda a:semver_key(a.get("version")))
    return matches[0]

def cmd_init(args):
    project=Path(args.project).resolve(); p=registry_path(project)
    if p.exists() and not args.force: raise SystemExit(f"refusing to overwrite existing registry: {p}")
    save(project,{"registry_version":"1.0","project":project.name,"assets":[]}); print(f"OK initialized {p}")
def cmd_register(args):
    project=Path(args.project).resolve(); data=load(project)
    if args.type not in ALLOWED_TYPES: raise SystemExit(f"invalid type: {args.type}")
    if args.status not in ALLOWED_STATUS: raise SystemExit(f"invalid status: {args.status}")
    if not SEMVER_RE.match(args.version): raise SystemExit("version must be SemVer-like MAJOR.MINOR.PATCH")
    if not re.match(r"^[a-z_]+\.[a-z0-9_]+$",args.id): raise SystemExit("asset id must look like type.semantic_name")
    if any(a["id"]==args.id and a["version"]==args.version for a in data["assets"]): raise SystemExit("same asset id+version already exists")
    asset={"id":args.id,"name":args.name or args.id.split(".",1)[1],"type":args.type,"version":args.version,"status":args.status,
           "style_profile":args.style,"class_profile":args.class_profile,"dependencies":args.dep or [],"anchors":args.anchor or [],"files":[],
           "qa":{"status":"pending","score":None,"critical_gates":[],"style_gates":{"render_family":"pending","facial_family":"pending","material_family":"pending","lighting_family":"pending"}},"notes":args.notes or ""}
    if args.status=="approved": raise SystemExit("new assets cannot start approved; run qa then set-status approved")
    data["assets"].append(asset); save(project,data); print(f"OK registered {args.id}@{args.version}")
def cmd_list(args):
    data=load(Path(args.project).resolve()); assets=data["assets"]
    if args.type: assets=[a for a in assets if a.get("type")==args.type]
    if args.status: assets=[a for a in assets if a.get("status")==args.status]
    if not assets: print("(no assets)"); return
    for a in sorted(assets,key=lambda x:(x['id'],semver_key(x['version']))):
        print(f'{a["id"]:<38} {a["version"]:<10} {a["status"]:<10} QA={a["qa"]["status"]:<7} {a["style_profile"]}')
def cmd_show(args):
    data=load(Path(args.project).resolve()); a=find_asset(data,args.id,args.version); print(json.dumps(a,ensure_ascii=False,indent=2))
def cmd_latest(args):
    data=load(Path(args.project).resolve()); a=find_asset(data,args.id,None); print(f'{a["id"]}@{a["version"]} {a["status"]}')
def cmd_qa(args):
    project=Path(args.project).resolve(); data=load(project); a=find_asset(data,args.id,args.version)
    if args.status not in {"pending","pass","fail"}: raise SystemExit("invalid qa status")
    if args.score is not None and not 0<=args.score<=100: raise SystemExit("score must be 0..100")
    prev=a.get("qa",{})
    gates=prev.get("style_gates",{"render_family":"pending","facial_family":"pending","material_family":"pending","lighting_family":"pending"})
    for key,val in [("render_family",args.render_gate),("facial_family",args.facial_gate),("material_family",args.material_gate),("lighting_family",args.lighting_gate)]:
        if val is not None: gates[key]=val
    a["qa"]={"status":args.status,"score":args.score,"critical_gates":args.gate or [],"style_gates":gates}; save(project,data)
    print(f'OK QA {a["id"]}@{a["version"]}: {args.status} style_gates={gates}')
def cmd_set_status(args):
    project=Path(args.project).resolve(); data=load(project); a=find_asset(data,args.id,args.version)
    if args.status not in ALLOWED_STATUS: raise SystemExit("invalid status")
    if args.status=="approved":
        q=a.get("qa",{})
        if q.get("status")!="pass" or q.get("critical_gates"):
            raise SystemExit("cannot approve: QA must pass and critical_gates must be empty")
        if a.get("type")=="character":
            gates=q.get("style_gates",{})
            required=["render_family","facial_family","material_family","lighting_family"]
            if any(gates.get(k)!="pass" for k in required):
                raise SystemExit("cannot approve character: all four style_gates must pass")
    a["status"]=args.status; save(project,data); print(f'OK status {a["id"]}@{a["version"]} -> {args.status}')
def cmd_add_dep(args):
    project=Path(args.project).resolve(); data=load(project); a=find_asset(data,args.id,args.version)
    ids={x['id'] for x in data['assets']}
    if args.dep not in ids: raise SystemExit(f"dependency does not exist: {args.dep}")
    if args.dep==a['id']: raise SystemExit("asset cannot depend on itself")
    if args.dep not in a['dependencies']: a['dependencies'].append(args.dep)
    save(project,data); print(f"OK dependency {a['id']} -> {args.dep}")
def validate_data(data):
    errors=[]
    if not isinstance(data,dict): return ["registry root must be object"]
    if data.get("registry_version") is None: errors.append("missing registry_version")
    assets=data.get("assets")
    if not isinstance(assets,list): return errors+["assets must be list"]
    seen=set(); ids=set()
    for i,a in enumerate(assets):
        pref=f"assets[{i}]"
        for k in ["id","name","type","version","status","style_profile","dependencies","anchors","qa"]:
            if k not in a: errors.append(f"{pref}: missing {k}")
        if a.get("type") not in ALLOWED_TYPES: errors.append(f"{pref}: invalid type")
        if a.get("status") not in ALLOWED_STATUS: errors.append(f"{pref}: invalid status")
        if not SEMVER_RE.match(a.get("version",'')): errors.append(f"{pref}: invalid version")
        key=(a.get("id"),a.get("version"))
        if key in seen: errors.append(f"{pref}: duplicate id+version {key}")
        seen.add(key); ids.add(a.get("id"))
        q=a.get("qa",{})
        if q.get("status") not in {"pending","pass","fail"}: errors.append(f"{pref}: invalid qa status")
        if a.get("status")=="approved" and (q.get("status")!="pass" or q.get("critical_gates")): errors.append(f"{pref}: approved asset requires passing QA and no critical gates")
        if a.get("status")=="approved" and a.get("type")=="character":
            gates=q.get("style_gates",{})
            required=["render_family","facial_family","material_family","lighting_family"]
            if any(gates.get(k)!="pass" for k in required): errors.append(f"{pref}: approved character requires all four style gates pass")
    for i,a in enumerate(assets):
        for dep in a.get("dependencies",[]):
            if dep not in ids: errors.append(f"assets[{i}]: unresolved dependency {dep}")
            if dep==a.get('id'): errors.append(f"assets[{i}]: self dependency")
    return errors
def cmd_validate(args):
    data=load(Path(args.project).resolve()); errors=validate_data(data)
    if errors:
        print("FAIL registry validation")
        for e in errors: print(" -",e)
        raise SystemExit(2)
    print(f"PASS registry validation ({len(data['assets'])} assets)")
def main():
    p=argparse.ArgumentParser(description="Lightweight asset registry manager")
    s=p.add_subparsers(dest="cmd",required=True)
    a=s.add_parser("init"); a.add_argument("project"); a.add_argument("--force",action="store_true"); a.set_defaults(func=cmd_init)
    a=s.add_parser("register"); a.add_argument("project"); a.add_argument("--id",required=True); a.add_argument("--type",required=True); a.add_argument("--version",default="1.0.0"); a.add_argument("--status",default="draft"); a.add_argument("--style",required=True); a.add_argument("--class-profile"); a.add_argument("--name"); a.add_argument("--dep",action="append"); a.add_argument("--anchor",action="append"); a.add_argument("--notes"); a.set_defaults(func=cmd_register)
    a=s.add_parser("list"); a.add_argument("project"); a.add_argument("--type"); a.add_argument("--status"); a.set_defaults(func=cmd_list)
    a=s.add_parser("show"); a.add_argument("project"); a.add_argument("--id",required=True); a.add_argument("--version"); a.set_defaults(func=cmd_show)
    a=s.add_parser("latest"); a.add_argument("project"); a.add_argument("--id",required=True); a.set_defaults(func=cmd_latest)
    a=s.add_parser("qa"); a.add_argument("project"); a.add_argument("--id",required=True); a.add_argument("--version",required=True); a.add_argument("--status",required=True); a.add_argument("--score",type=float); a.add_argument("--gate",action="append"); a.add_argument("--render-gate",choices=["pending","pass","fail"]); a.add_argument("--facial-gate",choices=["pending","pass","fail","na"]); a.add_argument("--material-gate",choices=["pending","pass","fail"]); a.add_argument("--lighting-gate",choices=["pending","pass","fail"]); a.set_defaults(func=cmd_qa)
    a=s.add_parser("set-status"); a.add_argument("project"); a.add_argument("--id",required=True); a.add_argument("--version",required=True); a.add_argument("--status",required=True); a.set_defaults(func=cmd_set_status)
    a=s.add_parser("add-dep"); a.add_argument("project"); a.add_argument("--id",required=True); a.add_argument("--version",required=True); a.add_argument("--dep",required=True); a.set_defaults(func=cmd_add_dep)
    a=s.add_parser("validate"); a.add_argument("project"); a.set_defaults(func=cmd_validate)
    args=p.parse_args(); args.func(args)
if __name__=="__main__": main()
