#!/usr/bin/env python3
import argparse, sys, re
from pathlib import Path

RULES=[
    (r"\bphotoreal(?:istic)?\b|真人照片|真人摄影|照片级", "改为 high-end cinematic stylized 3D / clean animation-film rendering"),
    (r"visible pores|skin pores|毛孔|皮肤扫描|skin scan", "改为 clean stylized cinematic skin, soft SSS, no visible pores"),
    (r"rough skin|粗糙皮肤|gritty|rugged realism", "把粗粝状态改写为大中尺度年龄/疲惫结构，不改变动画材质家族"),
    (r"dense stubble|stubble follicles|真实胡茬|毛囊", "改为 soft stylized beard shadow / sparse refined short groom"),
    (r"heavy grime|dense scratches|密集裂纹|大量划痕", "改为 large/medium-scale art-directed wear"),
    (r"dark studio|dark cinematic|深灰背景|暗棕|sepia", "恢复 bright pale cool-neutral high-key lighting/background"),
    (r"western adventurer|post-apocalyptic|steampunk|dieselpunk|victorian adventurer|cowboy", "删除无关西方/末世设计家族，恢复参考视频的东方幻想动画电影视觉"),
]

def scan(text):
    hits=[]
    for pattern,fix in RULES:
        ms=list(re.finditer(pattern,text,re.I))
        if ms: hits.append((pattern,len(ms),fix))
    return hits

def main():
    ap=argparse.ArgumentParser(description='Check a character prompt for terms that can break the current reference-style family.')
    ap.add_argument('file',nargs='?',help='Prompt text file; omit to read stdin')
    args=ap.parse_args()
    text=Path(args.file).read_text(encoding='utf-8') if args.file else sys.stdin.read()
    hits=scan(text)
    if not hits:
        print('PASS prompt guard: no high-risk reference-family drift triggers found')
        return
    print('BLOCK prompt guard: rewrite positive prompt before generation')
    for pattern,count,fix in hits:
        print(f' - {count} hit(s): {pattern}')
        print(f'   rewrite: {fix}')
    raise SystemExit(2)

if __name__=='__main__': main()
