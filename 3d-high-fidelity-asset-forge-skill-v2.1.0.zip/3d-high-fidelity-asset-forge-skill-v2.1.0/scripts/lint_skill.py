#!/usr/bin/env python3
import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=["START-HERE.md","README.md","SKILL.md","VERSION","manifest.json","runtime/PIPELINE.md","docs/STYLE_EXTRACTION_PROTOCOL.md","docs/STYLE_AUTHORITY_CONTRACT.md","docs/FAILURE_RECOVERY.md","docs/SIMILARITY_QA.md","prompts/MASTER_PROMPT_COMPILER.md","prompts/REFERENCE_STYLE_CHARACTER_MASTER.md","schemas/style_dna.schema.json","schemas/asset_registry.schema.json","scripts/prompt_guard.py"]
for x in required:
    if not (ROOT/x).is_file(): errors.append(f"missing {x}")
version=(ROOT/"VERSION").read_text(encoding="utf-8").strip() if (ROOT/"VERSION").exists() else None
try:
    m=json.loads((ROOT/"manifest.json").read_text(encoding="utf-8"))
    if m.get("version")!=version: errors.append("version mismatch manifest/VERSION")
except Exception as e: errors.append(f"manifest json error: {e}")
for jf in [ROOT/"schemas/style_dna.schema.json",ROOT/"schemas/asset_registry.schema.json",ROOT/"profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json"]:
    try: json.loads(jf.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"invalid json {jf.name}: {e}")
for p in ROOT.rglob("*"):
    if ".pytest_cache" in p.parts or "__pycache__" in p.parts or p.suffix==".pyc": errors.append(f"cache residue {p.relative_to(ROOT)}")
for p in ROOT.rglob("*"):
    if p.is_file() and p.name in {".DS_Store","Thumbs.db"}:
        errors.append(f"package residue {p.relative_to(ROOT)}")
if errors:
    print("FAIL skill lint")
    for e in errors: print(" -",e)
    raise SystemExit(2)
print("PASS skill lint")
