#!/usr/bin/env python3
import argparse, shutil, sys
from pathlib import Path

SKILL_NAME="3d-high-fidelity-asset-forge"

def main():
    p=argparse.ArgumentParser(description="Safe installer for 3D High-Fidelity Asset Forge")
    p.add_argument("--target",required=True,help="Parent skills directory")
    p.add_argument("--dry-run",action="store_true")
    p.add_argument("--replace",action="store_true",help="Replace existing install after backing it up")
    args=p.parse_args()
    src=Path(__file__).resolve().parents[1]
    parent=Path(args.target).expanduser().resolve()
    dst=parent/SKILL_NAME
    print(f"source: {src}")
    print(f"target: {dst}")
    if args.dry_run:
        print("DRY-RUN: no files changed"); return
    parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        if not args.replace:
            raise SystemExit(f"target exists: {dst}; use --replace to back up and replace")
        backup=parent/(SKILL_NAME+".backup")
        if backup.exists(): shutil.rmtree(backup)
        dst.rename(backup)
        print(f"backup: {backup}")
    shutil.copytree(src,dst,ignore=shutil.ignore_patterns(".pytest_cache","__pycache__","*.pyc"))
    print("PASS installed")
    print(f"next: python {dst/'scripts'/'doctor.py'}")
if __name__=="__main__": main()
