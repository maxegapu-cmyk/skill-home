@echo off
if "%~1"=="" (
  echo Usage: install.bat C:\path\to\skills [--replace]
  exit /b 2
)
python "%~dp0install.py" --target "%~1" %2
