# Naming & Versioning

## Stable ID
格式：`type.semantic_name`

Stable ID 表示“这是哪个资产”，版本表示“它现在迭代到哪一版”。

不要把版本写进 ID：
- ✅ `character.elder_tiger_a` + `version=1.2.0`
- ❌ `character.elder_tiger_a_v12`

## Version
默认 SemVer：`MAJOR.MINOR.PATCH`

- PATCH：不改变核心外观的修正，例如手指错误、材质粗糙度小修。
- MINOR：增加可选服装、表情、道具或视角，不破坏核心身份。
- MAJOR：身份几何、核心设计、Style Profile 发生不兼容变化。

## Status
- `draft`: 正在施工
- `review`: 等待 QA / 审片
- `approved`: 当前可正式使用
- `blocked`: 有明确阻断问题
- `deprecated`: 退役，保留追溯

## Current Resolution
Registry 可以同时保存历史版本；使用时优先解析：
1. `approved`
2. 最高 SemVer

若无 approved，则最高 `review` 只能作为候选，不得冒充正式版。
