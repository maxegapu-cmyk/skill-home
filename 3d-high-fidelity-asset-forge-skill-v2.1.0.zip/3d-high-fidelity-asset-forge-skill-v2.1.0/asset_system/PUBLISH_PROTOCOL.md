# Publish Protocol

## Publish Gate
资产从 review -> approved 前必须：
1. Reference / Style Profile 可解析
2. 依赖可解析
3. QA.status = pass
4. Critical gates 为空
5. 若为角色：Render / Facial / Material / Lighting 四个 Style Gate 全部 PASS
6. 若是角色：正侧背身份一致
7. 若是场景：world grammar 不漂
8. 若是材质：没有塑料化 / 同质化问题

## Revision Strategy
出现问题先判定属于：
- extraction error
- class profile error
- lookdev error
- prompt compile error
- generator capability limit
- asset bookkeeping/version error

只修最小上游层，不整套推翻。

## Approval History
不要删除旧 approved 版本。新版本 approved 后，旧版可标 `deprecated`，保留回滚路径。
