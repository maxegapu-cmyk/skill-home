# Asset Model

借鉴成熟 CG/VFX 管线常见的“组件 / 组合 / 发布 / 更新 / 审核”思路，本 Skill 使用轻量级资产模型，不绑定任何 DCC。

## Asset Types
- `character`
- `environment`
- `prop`
- `material`
- `lighting_rig`
- `camera_rig`
- `assembly`

## Component vs Assembly

### Component
可独立发布、独立版本化的资产，例如一个角色、一把武器、一根柱子、一套材质。

### Assembly
由多个 Component 组成的资产，例如“神殿广场场景”“角色+坐骑组合”“完整房间套件”。

## Asset State
`draft -> review -> approved -> deprecated`

异常状态：`blocked`

## Stable ID
建议：
`<type>.<semantic_name>`

例如：
- `character.tiger_cub_a`
- `character.elder_tiger_a`
- `environment.ceremonial_plaza_a`
- `prop.wooden_bucket_a`

版本变化不改变 Stable ID。

## Dependency Rule
每个资产显式记录：
- style profile
- class profile
- materials
- props
- assemblies
- source references

禁止把依赖埋在 Prompt 文字里。

## Publish Rule
正式发布必须同时满足：
- schema valid
- critical QA pass
- no unresolved identity drift
- dependencies resolvable
- status = approved


## Style Gate State (v2.1)
Character QA records four style gates: `render_family`, `facial_family`, `material_family`, `lighting_family`.
A character cannot be approved unless all four are `pass`. This prevents a polished but wrong-family character sheet from entering the library.
