# Asset Registry Guide

`asset_registry.json` 是轻量唯一索引。

## 为什么需要 Registry
如果不做 Registry，人物、材质、场景和 Prompt 很快会变成“靠记忆找版本”。
Registry 用来回答：
- 当前正式版本是谁？
- 这个角色绑定哪个 Style Profile？
- 它依赖哪些材质 / 道具？
- 哪些版本已经废弃？
- 哪个资产还没过 QA？

## 推荐字段
- `id`
- `name`
- `type`
- `version`
- `status`
- `style_profile`
- `class_profile`
- `dependencies`
- `anchors`
- `files`
- `qa`
- `notes`

## 命令
初始化：
```bash
python scripts/assetctl.py init /path/to/project
```

登记资产：
```bash
python scripts/assetctl.py register /path/to/project --id character.hero_a --type character --version 1.0.0 --status draft --style CINEMATIC_CEREMONIAL_FANTASY_3D_A
```

查看：
```bash
python scripts/assetctl.py list /path/to/project
```

校验：
```bash
python scripts/assetctl.py validate /path/to/project
```

记录 QA：
```bash
python scripts/assetctl.py qa /path/to/project --id character.hero_a --version 1.0.0 --status pass --score 94
```

批准：
```bash
python scripts/assetctl.py set-status /path/to/project --id character.hero_a --version 1.0.0 --status approved
```

解析当前正式/最高版本：
```bash
python scripts/assetctl.py latest /path/to/project --id character.hero_a
```
