# Golden Adult Human Style Case

## Purpose
用于验证“成年人物仍属于参考视频同一视觉家族”。

## Expected Success Signature
- 正常成年骨架和身高，不幼态。
- 柔化的动画电影面部平面；眼睛略大、湿润、有情绪但不二维动漫。
- 干净 soft SSS 皮肤，无可见毛孔。
- 头发以大中发束为主、细丝为辅。
- 服装细节清楚但磨损以大中尺度美术化处理。
- 整体浅冷、高明度、高 fill、柔阴影、轻空气感。
- 资产板背景为浅灰蓝/冷灰，不是深色欧美 Concept Board。

## Immediate Failure Signature
- 深眼窝 + 硬眉骨 + 长脸 + 欧美冒险家气质。
- 皮肤毛孔、密集胡茬根、皮革微裂纹成为主要真实感来源。
- 暗灰/褐色板、强橙边缘光、Sepia。
- 看起来像 AAA 游戏 NPC、末世生存角色、欧美3D冒险动画。

## Decision
只要出现 Immediate Failure Signature，图再完整也不进入下一轮批量资产。
