# Current Reference Profile

Canonical structured profile:
`profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json`

Reference source characteristics observed from the supplied video:
- 1280×720
- 24 fps
- ~15 seconds
- cinematic stylized 3D
- childlike anthropomorphic character + adult anthropomorphic female + elder anthropomorphic male
- pale monumental ceremonial architecture
- soft atmospheric daylight

Use the JSON profile as the single structured source of truth for this reference family.
