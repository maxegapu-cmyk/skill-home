# Prop Asset Bible v2

## Metadata
- Asset ID:
- Version:
- Status:
- Style Profile:

## Function / Semantic Role
- 

## Geometry
- silhouette:
- relative scale:
- construction:
- thickness:
- interaction points:

## Material Stack
- primary:
- secondary:
- hardware:
- roughness / specular:
- wear:

## Ornament
- motif:
- density:
- relief depth:

## Views
front / side / back / top / hero 3-4

## Forbidden Drift
- 
