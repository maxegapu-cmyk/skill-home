# Environment Asset Bible v2

## Metadata
- Asset ID:
- Version:
- Status:
- Style Profile:

## World Scale
- human/character scale reference:
- ceiling / column / stair scale:
- negative-space ratio:

## Architecture Grammar
- primary modules:
- repetition rhythm:
- silhouette family:
- ornament hierarchy:
- transition pieces:

## Surface Family
- floor:
- wall:
- column:
- wood:
- metal:
- cloth:
- wear / cleanliness:

## Atmosphere / Lighting
- key direction:
- ambient:
- bounce:
- haze:
- shadow softness:
- depth falloff:

## Camera-Friendly Zones
- close dialogue:
- medium action:
- wide establishing:

## Modular Kit
- 

## Forbidden Drift
- 
