# Character Asset Bible v2

## Metadata
- Asset ID:
- Version:
- Status:
- Style Profile:
- Class Profile:

## Identity
- Name / role:
- Species:
- Age presentation:
- Personality/performance cues:

## Immutable Geometry
- Head volume:
- Forehead / brow:
- Eye socket / eye shape / spacing:
- Nose / muzzle:
- Mouth / lips:
- Cheek / jaw / chin:
- Ear / horn / tail:
- Head-body ratio:
- Shoulder / pelvis:
- Limb ratio:
- Hand / foot construction:

## Face / Skin / Fur Boundary
- Hairline:
- Eyebrow / fur transition:
- Ear edge:
- Cheek fur transition:
- Beard / skin boundary:
- SSS / roughness:
- Age planes / wrinkles:
- Eye wetness / tearline:

## Hair / Fur
- Length zones:
- Direction field:
- Strand / clump scale:
- Density:
- Root-tip variation:
- Flyaways:
- Rim response:

## Costume
- Silhouette:
- Layer order:
- Fabric thickness:
- Fold scale:
- Seams / fasteners:
- Ornament hierarchy:
- Embroidery relief:
- Wear state:

## Materials
- Skin:
- Fur:
- Hair:
- Cloth A/B:
- Leather:
- Metal:
- Jewelry:

## Performance Range
- neutral
- joy
- anger
- fear
- sadness
- surprise
- class-specific extreme expression

## Turnaround
front / 3-4 / side / back

## Forbidden Drift
- 
