# Reference Manifest

- Case ID:
- Source type: image / multi-image / video
- Source count:
- Video duration / fps / resolution (if known):
- Target output: character / environment / prop / full pack
- Same identity or new identity:
- Generator / DCC (if known):

## Coverage Matrix
| Requirement | Covered? | Best reference | Confidence | Notes |
|---|---|---|---|---|
| Face close-up | | | | |
| Full body | | | | |
| Different character class | | | | |
| Hair/fur boundary | | | | |
| Skin / age detail | | | | |
| Costume / material | | | | |
| Environment wide | | | | |
| Prop close-up | | | | |
| Different camera/light | | | | |

## Blind Spots
- 
