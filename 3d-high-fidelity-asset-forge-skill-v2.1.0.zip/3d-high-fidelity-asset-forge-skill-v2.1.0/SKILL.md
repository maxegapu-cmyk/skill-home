# 3D High-Fidelity Asset Forge v2.1.0

## Mission
把用户指定参考视频 / 参考帧的 **3D 视觉家族本身** 锁成最高权威，再生产人物、场景、道具和可管理资产。

本版默认目标不是“做一张高级 3D 图”，而是：

> **新资产必须像是从参考视频同一部高规格 3D 动画电影中直接扩展出来。**

当当前任务使用 `CINEMATIC_CEREMONIAL_FANTASY_3D_A` 时，**Reference Style Authority 高于角色身份、职业、年龄、脏污、服装、道具和资产板布局。**

## Non-Negotiable Rules

1. **STYLE AUTHORITY FIRST。** 角色身份只能改变“是谁”，不能改变“作品长什么样”。
2. 不允许把复杂参考简化成“3D 卡通 / 国风 3D / 游戏 CG / 欧美动画”等泛化标签。
3. 不允许成人 / 老年角色因为年龄词、胡茬、皱纹、疲惫、脏污而切换到真人 CG、AI 仿真人或粗粝游戏角色路径。
4. 不允许幼体比例污染成年 / 老年；也不允许用“真实成人”作为修复手段把人物推向照片级写实。
5. 不允许用毛孔、皮肤扫描、摄影级胡茬、密集微皱纹来表达年龄或疲惫。
6. 不允许参考视频的明亮、柔润、高空气感，被深灰棚拍、暗棕概念稿、强橙轮廓光替换。
7. 不允许西方冒险家 / 末世 / 蒸汽朋克 / 暗黑游戏 / 写实 AAA 角色美术家族侵入当前参考风格。
8. 不允许脸部、皮肤、毛发、布料、金属、木材、石材统一成同一种塑料 shader。
9. 不允许跳过 Reference Coverage、Style Authority、Class Profile、Lookdev 就写最终 Prompt。
10. 不允许跨视角改变身份几何、头身比、服装拓扑、发型或关键饰件。
11. 不允许用“95% 一致”等不可验证数字替代实际 QA。
12. 所有资产进入正式库前必须有版本、状态、依赖和 QA 结果。

## Priority Order

当指令发生冲突时，按以下顺序裁决：

`REFERENCE STYLE AUTHORITY > RENDER/FACIAL/MATERIAL/LIGHTING FAMILY > CLASS AGE GEOMETRY > CHARACTER IDENTITY > COSTUME/PROP CONTENT > SHEET LAYOUT`

如果“35 岁、疲惫、粗糙、胡茬”等内容词会让画面进入真人 / 欧美粗粝 CG 路径，必须**改写这些内容的表现方式**，而不是牺牲风格。

## Workflow

严格按 `runtime/PIPELINE.md` 执行：

`BOOT -> INGEST -> COVERAGE -> STYLE_AUTHORITY -> CLASS_SPLIT -> LOOKDEV -> WORLD_GRAMMAR -> ASSET_COMPILE -> PROMPT_COMPILE -> STYLE_GATES -> QA -> PUBLISH`

### BOOT
- 读取 `START-HERE.md`。
- 当前用户明确指定本参考风格时，默认加载 `profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json`。
- 人物资产默认调用 `prompts/REFERENCE_STYLE_CHARACTER_MASTER.md`，除非用户明确要求另一视觉家族。

### INGEST / COVERAGE
视频或多图必须覆盖：
- 脸部近景
- 全身 / 比例
- 成年 / 老年 / 幼体（若存在）
- 毛发 / 皮肤 / 服装材质
- 环境广角
- 不同景别 / 光照

### STYLE_AUTHORITY
必须先锁四个“作品家族门”：
1. **Render Family** — 高规格电影级 stylized 3D，不是真人摄影 CG，不是游戏角色展示。
2. **Facial Family** — 柔化面部平面、动画化眼睛与五官比例、年龄结构风格化表达。
3. **Material Family** — 干净皮肤 SSS、精致 Groom、柔和布料金属分离，不用粗粝微细节制造真实感。
4. **Lighting Family** — 明亮浅冷、高 fill、柔和体积光、轻空气感，不走暗棚 / 棕黑 / 强硬高反差。

四门任何一门未锁定，不得继续批量生产。

### CLASS_SPLIT
至少检查：
- CHILDLIKE_HUMAN / CHILDLIKE_ANTHRO
- ADULT_HUMAN_MASCULINE
- ADULT_HUMAN_FEMININE
- ADULT_ANTHRO_FEMININE / ADULT_ANTHRO_MASCULINE
- ELDER_HUMAN_MASCULINE / ELDER_HUMAN_FEMININE
- ELDER_ANTHRO_MASCULINE

Class Profile 只能改变年龄和骨架，不得改变渲染媒介。

### LOOKDEV
人物优先顺序：
`face geometry -> eyes -> skin -> hair/fur boundary -> costume material -> prop material`

成人默认执行：
- 正常成年身高与骨架
- 眼睛相对真人轻度放大，提升情绪可读性
- 眉骨 / 颧骨 / 眼窝 / 下颌柔化
- 鼻翼、毛孔、胡茬根、微皱纹等照片级细节降级
- 年龄通过大中型雕刻结构、眼神、姿态、色泽表达

### PROMPT_COMPILE
必须以 `prompts/REFERENCE_STYLE_CHARACTER_MASTER.md` 为母版。
禁止使用会反客为主的写实触发词而不做重写。

### STYLE_GATES
最终图先过四门：
- Render Family Gate
- Facial Family Gate
- Material Family Gate
- Lighting Family Gate

**任意失败，即使图很漂亮、资产板很完整，也判 FAIL。**

### QA / PUBLISH
使用 `docs/SIMILARITY_QA.md`。只有 Style Gates 和 Critical Gates 全过，才允许 `approved`。

## Mandatory Adult Smoke Test

首次批量生产一套角色前，必须先做：
1. 一个成年男性单人资产测试；
2. 一个成年女性或另一年龄层单人资产测试（若项目存在）；
3. 两者 Style Gates 全过后，才允许多人群像 / 批量角色。

禁止直接从幼体成功样例推断成人一定成功。

## Default Deliverables
1. Reference Coverage Report
2. Style Authority Contract
3. Character Class Profiles
4. Face / Skin / Hair / Fur Lookdev Profile
5. World Grammar
6. Character / Environment / Prop Asset Bible
7. Asset Registry
8. Prompt Pack
9. Style Gate Report
10. Similarity QA
11. Known Uncertainties

## Shortcut
用户说“按这个视频 / 这张图的 3D 风格做人设”，默认：
- 先加载 Style Authority
- 单人验证
- Hero 3/4
- Front / Side / Back
- Face Close-up
- 6 Expressions
- Hair / Skin / Costume / Prop Callouts
- 浅冷明亮资产背景
- 同身份一致性 QA

**先证明属于同一个作品，再谈资产板有多完整。**
