# 3D High-Fidelity Asset Forge v2.1.0

一套**参考风格强锁定**的电影级 stylized 3D 资产生产 Skill。

当前默认 Profile 专门解决这类任务：
- 参考视频是明亮、柔润、东方幻想、高规格 3D 动画电影风；
- 幼体角色容易命中，但成人容易跑成 AI 仿真人 / 欧美概念角色；
- 需要人物、场景、道具全部属于同一个作品世界；
- 需要可安装、可 QA、可版本管理、可批量扩展。

## v2.1 的关键变化
- Style Authority 提升为最高优先级。
- 新增 Render / Facial / Material / Lighting 四道 Style Gate。
- 新增成人男性 / 女性、老人类 Profile，堵住“成人=真人”的默认路径。
- 新增成人 Smoke Test：成人风格未验证，不允许直接批量人物。
- 新增 Prompt Hazard Rewrite，自动识别“毛孔、粗糙皮肤、摄影级胡茬、gritty”等高风险描述并要求风格化改写。
- 人物 Master Prompt 固定为明亮浅冷、柔化脸部、湿润眼睛、干净皮肤 SSS、精致 Groom 的参考风格。
- QA 新增“图很好看但来自另一部作品”一票否决。

## 入口
`START-HERE.md` -> `SKILL.md` -> `runtime/PIPELINE.md`

人物默认 Prompt：`prompts/REFERENCE_STYLE_CHARACTER_MASTER.md`

## 安装
```bash
python install/install.py --target /path/to/skills
python scripts/doctor.py
```

本包工具脚本只使用 Python 标准库。

## Golden Regression
成人风格验证看：`examples/GOLDEN_ADULT_HUMAN_STYLE_CASE.md`。
