# START HERE — 3D High-Fidelity Asset Forge v2.1.0

## 默认目标
当用户指定当前参考视频 / 参考图的风格时，默认加载：

`profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json`

人物生产默认使用：

`prompts/REFERENCE_STYLE_CHARACTER_MASTER.md`

本版最重要的判断不是“是不是 3D”，而是：

> **是不是参考视频同一个 3D 视觉家族。**

## 最短生产路径
1. 给参考视频 / 参考帧 + 角色身份。
2. 执行 `STYLE_AUTHORITY`，先锁 Render / Facial / Material / Lighting 四个 Family。
3. 选择对应 Class Profile。
4. **先出一个成年单人 smoke test**，不要直接多人群像。
5. 过四个 Style Gate 后，再出正式资产板。
6. 角色批量生产前至少验证两个不同年龄 / 性别类。
7. QA 通过后再进入 Registry / Publish。

## 成功长什么样
即使遮掉姓名、服装、职业、道具，只看脸、眼睛、皮肤、头发、光线，也应该像参考视频同一部高规格东方幻想 3D 动画电影。

## 一票否决
以下任何一种出现都不是“差一点”，而是**风格家族失败**：
- 欧美冒险家 / 末世 / 维多利亚 / 蒸汽朋克概念角色
- 深灰或暗棕 Character Concept Sheet
- AI 仿真人 / 真人 CG / 写实游戏 NPC
- 毛孔、皮肤扫描、摄影级胡茬成为主要质感
- 高反差暗棚、强橙边缘光、Sepia / 褐色主调
- 成人为了“不幼态”直接变成真人比例真人脸

## 安装
直接把整个目录作为 Skill 使用，或：

```bash
python install/install.py --target /path/to/skills
python scripts/doctor.py
```

零额外 Python 依赖。
