from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
PROFILE=ROOT/'profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json'

def data(): return json.loads(PROFILE.read_text(encoding='utf-8'))

def test_style_profile_core_anchors():
    d=data()
    for k in ['profile_id','authority_order','style_family','style_gates','immutable_anchors','forbidden_drift','character_classes','lookdev','lighting_camera','world_grammar','prompt_hazards','qa_focus']:
        assert k in d
    assert d['default_for_current_reference'] is True
    assert d['authority_order'][0]=='reference_style'

def test_adult_human_classes_present():
    c=data()['character_classes']
    for k in ['ADULT_HUMAN_MASCULINE','ADULT_HUMAN_FEMININE','ELDER_HUMAN_MASCULINE','CHILDLIKE_HUMAN']:
        assert k in c
    assert 'adult does not mean photoreal' in c['ADULT_HUMAN_MASCULINE']['hard_rule']

def test_four_style_gates_present():
    g=data()['style_gates']
    assert set(g) == {'render_family','facial_family','material_family','lighting_family'}

def test_forbidden_routes_block_observed_failure_family():
    s=' | '.join(data()['forbidden_drift']).lower()
    for term in ['western fantasy concept art','photoreal human','dark gray / brown concept sheet','visible pores','hard orange rim']:
        assert term in s

def test_reference_lighting_is_bright_pale_cool():
    l=data()['lighting_camera']
    text=(l['background']+' '+l['lighting']+' '+l['exposure']).lower()
    for term in ['pale','cool','bright','high-key']:
        assert term in text

def test_skin_and_stubble_are_not_photoreal():
    l=data()['lookdev']
    assert 'no visible pores' in l['skin']
    assert 'never follicle-led photographic stubble' in l['stubble']
