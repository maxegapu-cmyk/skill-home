from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_no_common_package_residue():
    bad=[]
    for p in ROOT.rglob('*'):
        parts=set(p.parts)
        if '.pytest_cache' in parts or '__pycache__' in parts or (p.is_file() and (p.name in {'.DS_Store','Thumbs.db'} or p.suffix=='.pyc')):
            bad.append(str(p.relative_to(ROOT)))
    assert not bad, bad
