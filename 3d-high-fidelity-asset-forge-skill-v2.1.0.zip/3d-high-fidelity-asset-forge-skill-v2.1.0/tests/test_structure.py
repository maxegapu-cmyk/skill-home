from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def test_required_files_exist():
    required=[
        'START-HERE.md','README.md','SKILL.md','VERSION','manifest.json',
        'runtime/PIPELINE.md','docs/STYLE_EXTRACTION_PROTOCOL.md','docs/SIMILARITY_QA.md',
        'prompts/MASTER_PROMPT_COMPILER.md','schemas/style_dna.schema.json',
        'schemas/asset_registry.schema.json','scripts/assetctl.py','scripts/doctor.py',
        'profiles/CINEMATIC_CEREMONIAL_FANTASY_3D_A.json','prompts/REFERENCE_STYLE_CHARACTER_MASTER.md','docs/STYLE_AUTHORITY_CONTRACT.md','docs/FAILURE_RECOVERY.md','scripts/prompt_guard.py'
    ]
    missing=[x for x in required if not (ROOT/x).is_file()]
    assert not missing, missing

def test_versions_synced():
    v=(ROOT/'VERSION').read_text(encoding='utf-8').strip()
    m=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    assert m['version']==v=='2.1.0'

def test_no_cache_residue():
    bad=[]
    for p in ROOT.rglob('*'):
        if '.pytest_cache' in p.parts or '__pycache__' in p.parts or p.suffix=='.pyc':
            bad.append(str(p.relative_to(ROOT)))
    assert not bad, bad
