from pathlib import Path
import json, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
ASSETCTL=ROOT/'scripts/assetctl.py'

def test_demo_registry_validates():
    project=ROOT/'examples/project_demo'
    r=subprocess.run([sys.executable,str(ASSETCTL),'validate',str(project)],capture_output=True,text=True)
    assert r.returncode==0, r.stdout+r.stderr

def test_registry_rejects_approved_without_qa_pass():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)
        bad={"registry_version":"1.0","project":"x","assets":[{
            "id":"character.bad","name":"bad","type":"character","version":"1.0.0","status":"approved",
            "style_profile":"S","class_profile":None,"dependencies":[],"anchors":[],"files":[],
            "qa":{"status":"pending","score":None,"critical_gates":[],"style_gates":{"render_family":"pending","facial_family":"pending","material_family":"pending","lighting_family":"pending"}},"notes":""
        }]}
        (p/'asset_registry.json').write_text(json.dumps(bad),encoding='utf-8')
        r=subprocess.run([sys.executable,str(ASSETCTL),'validate',str(p)],capture_output=True,text=True)
        assert r.returncode!=0
        assert 'approved asset requires passing QA' in r.stdout

def test_registry_rejects_unresolved_dependency():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)
        bad={"registry_version":"1.0","project":"x","assets":[{
            "id":"character.a","name":"a","type":"character","version":"1.0.0","status":"draft",
            "style_profile":"S","class_profile":None,"dependencies":["material.missing"],"anchors":[],"files":[],
            "qa":{"status":"pending","score":None,"critical_gates":[],"style_gates":{"render_family":"pending","facial_family":"pending","material_family":"pending","lighting_family":"pending"}},"notes":""
        }]}
        (p/'asset_registry.json').write_text(json.dumps(bad),encoding='utf-8')
        r=subprocess.run([sys.executable,str(ASSETCTL),'validate',str(p)],capture_output=True,text=True)
        assert r.returncode!=0
        assert 'unresolved dependency' in r.stdout


def test_approval_flow_and_latest_resolution():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)
        subprocess.run([sys.executable,str(ASSETCTL),'init',str(p)],check=True,capture_output=True,text=True)
        for v in ['1.0.0','1.1.0']:
            r=subprocess.run([sys.executable,str(ASSETCTL),'register',str(p),'--id','character.hero','--type','character','--version',v,'--style','S'],capture_output=True,text=True)
            assert r.returncode==0, r.stdout+r.stderr
        r=subprocess.run([sys.executable,str(ASSETCTL),'set-status',str(p),'--id','character.hero','--version','1.1.0','--status','approved'],capture_output=True,text=True)
        assert r.returncode!=0
        r=subprocess.run([sys.executable,str(ASSETCTL),'qa',str(p),'--id','character.hero','--version','1.1.0','--status','pass','--score','93','--render-gate','pass','--facial-gate','pass','--material-gate','pass','--lighting-gate','pass'],capture_output=True,text=True)
        assert r.returncode==0
        r=subprocess.run([sys.executable,str(ASSETCTL),'set-status',str(p),'--id','character.hero','--version','1.1.0','--status','approved'],capture_output=True,text=True)
        assert r.returncode==0
        r=subprocess.run([sys.executable,str(ASSETCTL),'latest',str(p),'--id','character.hero'],capture_output=True,text=True)
        assert r.returncode==0 and '1.1.0 approved' in r.stdout


def test_character_approval_rejects_failed_style_family():
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)
        subprocess.run([sys.executable,str(ASSETCTL),'init',str(p)],check=True,capture_output=True,text=True)
        subprocess.run([sys.executable,str(ASSETCTL),'register',str(p),'--id','character.wrong_family','--type','character','--version','1.0.0','--style','CINEMATIC_CEREMONIAL_FANTASY_3D_A','--class-profile','ADULT_HUMAN_MASCULINE'],check=True,capture_output=True,text=True)
        r=subprocess.run([sys.executable,str(ASSETCTL),'qa',str(p),'--id','character.wrong_family','--version','1.0.0','--status','pass','--score','95','--render-gate','pass','--facial-gate','fail','--material-gate','pass','--lighting-gate','pass'],capture_output=True,text=True)
        assert r.returncode==0
        r=subprocess.run([sys.executable,str(ASSETCTL),'set-status',str(p),'--id','character.wrong_family','--version','1.0.0','--status','approved'],capture_output=True,text=True)
        assert r.returncode!=0
        assert 'all four style_gates must pass' in (r.stdout+r.stderr)
