from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MASTER=(ROOT/'prompts/REFERENCE_STYLE_CHARACTER_MASTER.md').read_text(encoding='utf-8').lower()
COMPILER=(ROOT/'prompts/MASTER_PROMPT_COMPILER.md').read_text(encoding='utf-8').lower()
QA=(ROOT/'docs/SIMILARITY_QA.md').read_text(encoding='utf-8').lower()

def test_master_prompt_is_reference_first():
    assert 'style authority — highest priority' in MASTER
    assert '人物可以变' in MASTER and '渲染世界不能变' in MASTER

def test_master_prompt_blocks_western_photoreal_routes():
    for term in ['western fantasy concept art','aaa realistic game character','photorealistic human','ai pseudo-real human','dark gray or brown concept sheet']:
        assert term in MASTER

def test_adult_lock_is_explicit():
    assert 'adult face lock' in MASTER
    assert '成人 ≠ 真人' in MASTER
    assert '不幼态 ≠ 写实化' in MASTER

def test_positive_hazard_rewrite_exists():
    assert 'prompt hazard rewrite' in COMPILER
    for term in ['真实成人男性比例','毛孔','粗糙皮肤','浓密真实胡茬','dark cinematic']:
        assert term.lower() in COMPILER
    assert '不得仅靠 negative prompt' in COMPILER

def test_same_work_fail_fast_exists():
    assert 'same-work test' in QA
    assert '直接 fail' in QA
