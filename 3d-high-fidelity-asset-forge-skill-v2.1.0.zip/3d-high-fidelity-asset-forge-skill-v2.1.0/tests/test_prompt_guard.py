from pathlib import Path
import subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
GUARD=ROOT/'scripts/prompt_guard.py'

def run(text):
    return subprocess.run([sys.executable,str(GUARD)],input=text,capture_output=True,text=True)

def test_prompt_guard_passes_clean_reference_prompt():
    r=run('成年男性，柔化面部平面，clean stylized cinematic skin, soft SSS, bright pale cool background')
    assert r.returncode==0, r.stdout+r.stderr

def test_prompt_guard_blocks_observed_failure_triggers():
    r=run('35岁真实男性，visible pores, gritty rough skin, dense stubble follicles, dark studio, western adventurer')
    assert r.returncode!=0
    assert 'BLOCK prompt guard' in r.stdout
    assert 'rewrite' in r.stdout
