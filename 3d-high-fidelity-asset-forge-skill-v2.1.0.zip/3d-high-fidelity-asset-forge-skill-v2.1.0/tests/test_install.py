from pathlib import Path
import subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
INSTALL=ROOT/'install/install.py'

def test_dry_run_install():
    with tempfile.TemporaryDirectory() as td:
        r=subprocess.run([sys.executable,str(INSTALL),'--target',td,'--dry-run'],capture_output=True,text=True)
        assert r.returncode==0
        assert 'DRY-RUN' in r.stdout
        assert not (Path(td)/'3d-high-fidelity-asset-forge').exists()

def test_real_install_and_doctor():
    with tempfile.TemporaryDirectory() as td:
        r=subprocess.run([sys.executable,str(INSTALL),'--target',td],capture_output=True,text=True)
        assert r.returncode==0, r.stdout+r.stderr
        dst=Path(td)/'3d-high-fidelity-asset-forge'
        assert (dst/'START-HERE.md').exists()
        d=subprocess.run([sys.executable,str(dst/'scripts/doctor.py')],capture_output=True,text=True)
        assert d.returncode==0, d.stdout+d.stderr
