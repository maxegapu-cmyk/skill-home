# Reference-Style Character Master Prompt v2.1

> 这是当前参考视频 / 参考图的人物生产母版。执行端必须先填角色内容，再完整继承本风格锁。不要把它压缩成“高规格3D动画”几个词。

## 0. STYLE AUTHORITY — HIGHEST PRIORITY

**以用户提供的参考视频 / 参考帧作为唯一最高视觉风格依据。**

必须高度贴近参考中的：
- 人物建模语言
- 面部比例与五官艺术化程度
- 眼睛大小、湿润度与情绪可读性
- 皮肤 Shader
- 头发 / 毛发 Groom
- 服装材质的干净程度与细节尺度
- 明亮浅冷的整体色调
- 柔和高 fill 灯光
- 空气感、景深、CG 动画电影质感

**只替换人物身份、年龄、服装和道具；不重新设计画风。**

冲突时：
`REFERENCE STYLE > CHARACTER AGE/IDENTITY > COSTUME/PROP > SHEET LAYOUT`

人物可以变，**渲染世界不能变。**

---

## 1. CHARACTER CONTENT
角色：[NAME]
年龄：[AGE]
性别：[SEX]
身份 / 职业：[ROLE]
体型：[BODY TYPE]
核心气质：[TEMPERAMENT]
发型：[HAIR]
服装：[COSTUME]
关键道具：[PROP]
状态：[STATE]

---

## 2. REQUIRED VISUAL FAMILY
最终人物必须明显属于：

**high-end cinematic stylized 3D animation**
**soft semi-realistic animated character modeling**
**clean premium feature-animation CGI rendering**
**soft simplified facial planes**
**rounded form transitions**
**clean stylized cinematic skin shading**
**expressive moist cinematic eyes**
**refined groomed hair**
**bright soft cool-neutral atmospheric daylight**
**clean premium material separation**
**gentle cinematic depth of field**

视觉必须是：
> **动画电影人物 + 可信高品质材质**

绝不是：
> 真人 / AI仿真人 / AAA写实游戏人物 / 欧美粗粝概念角色经过3D化。

---

## 3. ADULT FACE LOCK — CRITICAL
如果是成年人：
- 保持成年身高、肩宽、四肢、骨架和年龄。
- **成年人也必须采用同一参考视频的动画电影脸部语言。**
- 眼睛相对真人轻度放大约 10%–18%，增强情绪可读性，但不幼儿化。
- 额头到眉骨柔和过渡；眉骨存在但不硬凸。
- 眼窝存在但不深陷真人化。
- 颧骨、面颊、下颌采用柔化大形；不要硬锐西方英雄脸。
- 鼻梁清楚但鼻翼和鼻孔微结构简化。
- 嘴唇结构清楚、干净、柔和。
- 下巴和下颌保持成年，但边缘圆润。

**成人 ≠ 真人。**
**不幼态 ≠ 写实化。**

如果是老人：年龄通过额头、眼窝、面颊容量、鼻唇区、下颌等大中型结构表达；皱纹是少量柔和雕刻线，不是密集摄影纹理。

---

## 4. EYES — STYLE ANCHOR
- clear cornea
- soft iris detail
- moist lower lid
- subtle tearline
- bright controlled catchlight
- natural lid thickness
- emotionally readable gaze

禁止玻璃珠玩偶眼、真人摄影眼、二维超大动漫眼。

---

## 5. SKIN — NO LIVE-ACTION MICRODETAIL
采用：
**clean stylized cinematic skin + soft SSS + controlled roughness + broad soft highlight rolloff**

允许轻微肤色变化、眼周/鼻尖/脸颊柔和暖红。

严格禁止：
- visible pores
- skin scan texture
- photographic follicle detail
- blackheads
- oily live-action skin
- dense micro-wrinkle network
- hyperreal beard roots

疲惫通过眼神、姿态、轻微眼袋、柔和暗沉表达；不要靠粗糙毛孔表达。

胡茬使用：**soft stylized beard shadow** 或少量精致短须。

---

## 6. HAIR / FUR
头发：
**sculpted primary hair masses + layered locks + fine secondary groom strands + controlled flyaways**

要求大中型发束先成立，再用少量细丝丰富边缘；整体干净、柔软、精致。

禁止油腻真人发丝、硬塑料块、粗厚欧美游戏发束。

---

## 7. COSTUME / WEAR
服装内容按角色身份，但渲染必须属于参考视频：
**clean premium animated-film cloth materials**

- 清楚层级和剪裁
- 中尺度褶皱
- 适度厚度
- 哑光织物
- 克制纹理
- 圆润边缘
- 金属 / 皮革 / 布料清楚分离

贫穷、旧、破、脏只能使用：
**large/medium-scale art-directed wear**

禁止：密集裂纹、大量细划痕、摄影级泥垢、末世废土质感、西部牛仔皮革质感、暗棕粗粝表面。

---

## 8. COLOR / LIGHTING — HARD LOCK
整体：
**bright clean cinematic color palette**
**high-key pale cool-neutral presentation**

灯光：
- bright soft cinematic daylight
- large soft sky illumination
- cool ambient fill
- gentle warm skin response
- high fill ratio
- soft shadows
- subtle volumetric haze
- smooth highlight rolloff

背景：
**pale cool gray / light blue-gray / soft atmospheric gradient**

禁止：
- dark charcoal board
- brown/sepia grading
- gritty gray studio
- hard orange rim light
- dramatic low-key hero lighting
- cyber neon

---

## 9. ASSET SHEET OUTPUT
制作一张**电影动画人物资产设定板**，不是欧美游戏 Concept Art。

A. Hero 3/4 全身主视觉
B. Turnaround：正面 / 侧面 / 背面
C. Face Close-up：大尺寸脸部近景
D. Expressions：neutral / subtle joy / sadness / anger / fear / surprise
E. Detail Callouts：手、发型、主要服装材质、核心道具

所有视图必须保持：
- 同一身份
- 同一脸型
- 同一年龄
- 同一头身比例
- 同一发型
- 同一服装拓扑
- 同一材质与颜色

如果生成模型文字能力不稳定，**宁可减少标签文字，也不能牺牲人物一致性和画风。**

---

## 10. FORBIDDEN VISUAL ROUTES — FAIL IMMEDIATELY
- Western fantasy concept art
- European animated adventure facial family
- gritty survival character
- post-apocalyptic survivor
- steampunk / dieselpunk / Victorian adventurer
- Western cowboy aesthetics
- dark fantasy game character
- AAA realistic game character
- photorealistic human
- AI pseudo-real human
- live-action actor
- hyperreal skin / visible pores / skin scan
- dark gray or brown concept sheet
- heavy leather cracking / dense scratches / grime-led realism
- sepia color grading
- hard orange rim light
- generic western stylized 3D
- glossy toy 3D
- flat toon / cel shading

---

## 11. FINAL SELF-CHECK
遮掉姓名、职业、服装、道具，只看：
**脸 + 眼睛 + 皮肤 + 头发 + Shader + 光线**。

仍然必须像参考视频同一部高规格 3D 动画电影。

如果更像：欧美3D动画 / 游戏人物 / 真人CG / AI仿真人 / 西方概念设计，**直接判 FAIL，重新生成，不允许用“细节很好”抵消风格错误。**
