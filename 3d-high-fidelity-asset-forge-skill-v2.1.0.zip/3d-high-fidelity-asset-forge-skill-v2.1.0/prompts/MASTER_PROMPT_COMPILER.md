# Master Prompt Compiler v2.1

## Character Prompt Compile Order — DO NOT REORDER

`STYLE AUTHORITY -> RENDER FAMILY -> FACIAL FAMILY -> MATERIAL FAMILY -> LIGHTING FAMILY -> CLASS GEOMETRY -> IDENTITY -> COSTUME/PROP -> ASSET SHEET -> NEGATIVES -> SELF-CHECK`

> 旧版把 identity / class 放在 style 前面，成人身份词可能把模型拉向真人或欧美概念角色。v2.1 改为 Style Authority 先行。

### 0. STYLE AUTHORITY
直接继承 `prompts/REFERENCE_STYLE_CHARACTER_MASTER.md` 的 STYLE AUTHORITY 与四个 Style Family。

### 1. CLASS GEOMETRY
只描述年龄/骨架必要的大中型结构。禁止用“真实成人比例”“超写实成人”等措辞作为风格修复。

### 2. IDENTITY
[who / age / role / temperament]

### 3. FACE / EYES
[soft planes / restrained adult eye enlargement / clear wet eye / simplified nose-mouth-jaw / class-specific age forms]

### 4. SKIN / HAIR / FUR
[clean SSS / no pore-led realism / groom hierarchy / boundaries]

### 5. COSTUME / PROP
[layer order / identity / large-medium art-directed wear / clean material separation]

### 6. LIGHTING / BACKGROUND
[bright pale cool-neutral / high fill / soft shadow / subtle haze]

### 7. SHEET
Hero + Front/Side/Back + Face + Expressions + essential details.

### 8. CONSISTENCY LOCK
All views: same identity geometry, age, proportions, hairstyle, costume topology, colors, material assignments.

### 9. FORBIDDEN ROUTES
使用 Master Prompt 的完整 Forbidden Visual Routes。

---

## Prompt Hazard Rewrite
以下内容词如果原样进入 Prompt，极易把成人推向错误视觉家族；必须改写：

| 高风险写法 | 必须改写为 |
|---|---|
| 真实成人男性比例 | 正常成年骨架与身高，但保持参考动画电影脸部语言 |
| 真实皮肤 / 毛孔 | 干净 stylized cinematic skin，soft SSS，无可见毛孔 |
| 粗糙皮肤 | 通过柔和色泽、眼袋、表情和中尺度材质变化表现疲惫 |
| 浓密真实胡茬 | soft stylized beard shadow / sparse refined short groom |
| 写实皱纹 | soft sculpted macro/mid age forms |
| heavy grime / dense scratches | large/medium-scale art-directed wear |
| rugged / gritty | mature / weathered in identity, but clean animation-film rendering |
| dark cinematic | bright soft cinematic daylight matching reference |

不得仅靠 Negative Prompt 抵消正向 Prompt 中的强写实触发词；**必须先改写正向描述。**

---

## Environment Prompt
以当前 Profile 的 World Grammar 为最高权威：明亮、干净、浅色石材、东方幻想、柔和空气感。禁止无关暗黑/中世纪/废土美学。

## Prop Prompt
功能 -> 轮廓 -> 相对尺度 -> 构造 -> 材质 -> 装饰 -> 受控磨损 -> 交互点 -> 多视图。材质细节尺度必须与当前动画电影世界一致。

## Reference Role Matrix
如果后端支持多参考：
- A = STYLE ONLY
- B = IDENTITY ONLY
- C = COSTUME / PROP ONLY
- D = POSE / COMPOSITION ONLY

Reference A 的 Style Authority 不得被 B/C/D 覆盖。
