# Final Palette Image Prompt Template

将所有 `{{VARIABLE}}` 替换成实际结果。色卡数量可以是 6、9 或 13；默认 13。

```text
A clean digital color palette reference design, 16:9 horizontal layout, pure flat design aesthetic with no photographic elements.

The background is a solid neutral off-white #F5F2EC fill, completely flat, no texture, no shadow, no paper, no surface.

The composition contains exactly three elements:

ELEMENT 1 - Title at the top center:
Clean sans-serif typography in solid black #1A1A1A, the text reads:
"{{MAIN_TITLE}}"
Below the main title, in smaller lighter gray #888888 sans-serif:
"{{SUBTITLE}} · {{COLOR_COUNT}} color system"

ELEMENT 2 - A single horizontal row of {{COLOR_COUNT}} rectangular color swatches, evenly spaced, centered vertically in the frame:
Each swatch is a clean flat rectangle of solid color fill, identical dimensions, sharp clean edges, no gradient, no shadow, no border.

The {{COLOR_COUNT}} swatches from left to right with these exact HEX fills:

{{NUMBERED_HEX_LIST}}

ELEMENT 3 - Two lines of small text directly beneath each swatch:
First line is the HEX code in clean monospace typography, color #333333.
Second line is the function label in even smaller clean sans-serif typography, color #666666, describing the color's role.

The {{COLOR_COUNT}} function labels from left to right:

{{NUMBERED_FUNCTION_LABEL_LIST}}

OVERALL DESIGN SPECIFICATION:
This is a flat 2D digital graphic design layout, the kind produced in Figma or Adobe Illustrator for a film production design document. No depth, no perspective, no lighting, no photographic rendering, no paper texture, no physical object. Pure flat vector-style color swatches on a flat background with crisp typography. Think production design bible reference sheets, color management documents, color scripts, or professional visual design system documentation.

The aesthetic is precise, clinical, informational, minimal, restrained, and professionally art-directed. The palette must remain the visual focus. Maintain generous negative space, strict alignment, consistent spacing, and clear typographic hierarchy.

Avoid: photographic rendering, paper texture, desk surface, table surface, depth of field, lens blur, film grain, photorealistic elements, 3D render, lighting effects on swatches, shadows under swatches, glossy finish on swatches, gradients, hand-painted look, watercolor look, illustration, sketch, physical mockup, real-world object simulation, decorative icons, extra charts, extra text, duplicated swatches, incorrect HEX codes, misspelled labels, uneven rectangle sizes, perspective distortion.
```
