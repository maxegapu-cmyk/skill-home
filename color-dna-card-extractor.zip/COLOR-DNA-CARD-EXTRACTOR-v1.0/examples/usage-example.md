# 使用示例

## 用户输入

上传一张参考图，然后输入：

> 提取这张图的完整影视功能性色卡，并生成最终色卡展示提示词。

## 输出骨架

```text
PART 1 — EXTRACTED PALETTE DATA

01 | #F4E6C8 | hot sunlight cast | 覆盖画面受直射光影响的综合色偏。
02 | #D4B896 | sand highlight | 沙地直接受光面的高光色。
...
13 | #4FC3D9 | dormant interface cyan | 小面积设备灯形成的冷色识别点。

Palette logic: 暖沙色环境由高亮米黄逐级压入灰褐阴影，少量暗红与休眠青色提供叙事识别。
Dominant ratio: environment 55% / light neutrals 18% / midtones 15% / darks 10% / accents 2%
Forbidden drift: saturated orange, vivid cobalt blue, magenta cast, pure white highlights, crushed neutral black

PART 2 — FINAL IMAGE GENERATION PROMPT

[完整英文生成提示词]
```
