# COLOR DNA CARD EXTRACTOR v1.0

一个用途非常单纯的 Skill：

**上传一张图片 → 自动理解画面的光线、材质、阴影和强调色 → 提取功能性色卡 → 输出专业色卡展示页提示词。**

默认会根据画面复杂度选择 6、9 或 13 色；要求完整影视级效果时使用 13 色。

核心入口：`SKILL.md`
最终展示模板：`templates/final-palette-prompt-template.md`
