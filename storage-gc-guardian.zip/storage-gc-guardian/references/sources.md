# Public references used in the design

This package is an independent implementation. No third-party source code is copied into it.

- OpenAI Codex skill-creator sample (skill layout and validation principles):
  https://github.com/openai/codex/blob/main/codex-rs/skills/src/assets/samples/skill-creator/SKILL.md
- OpenAI Codex installer source (`CODEX_HOME`, standalone release storage):
  https://github.com/openai/codex/blob/main/scripts/install/install.sh
- OpenAI Codex issue documenting session-loss impact when `CODEX_HOME/sessions` and `archived_sessions` were deleted:
  https://github.com/openai/codex/issues/37419
- OpenAI Codex discussion describing session and archive locations under `CODEX_HOME`:
  https://github.com/openai/codex/discussions/23680
- Microsoft Storage Sense documentation (supported Windows temporary-file cleanup):
  https://learn.microsoft.com/en-us/windows/configuration/storage/storage-sense
- Send2Trash (reference for recoverable deletion as a general safety pattern):
  https://github.com/arsenetar/send2trash
- BleachBit cleaner definitions (reference for narrowly scoped, application-specific cleanup rules):
  https://github.com/bleachbit/bleachbit/tree/master/cleaners
