# Safety model: leases, quarantine, commit

The engine is designed as a small garbage collector rather than a generic recursive deleter.

## 1. Lease

A file becomes a candidate only when a named profile owns the exact root and all lease conditions pass: platform, age, optional extension filter, ordinary-file type, no symlink/reparse point, and no protected-root overlap.

A scan produces a JSON plan with a stat fingerprint (`size`, `mtime_ns`, and file identity when available). A later stage operation rechecks that fingerprint. Changed files are rejected instead of being cleaned from stale evidence.

## 2. Quarantine

Staging uses a rename into `.storage-gc-quarantine/<transaction>/` inside the same managed root. The original relative path is preserved in the transaction manifest. A rename is intentionally preferred because it is quick, does not follow a link target, and remains reversible.

Staging does **not** reclaim physical disk space. It is the reversible boundary before a destructive commit.

## 3. Commit

Permanent reclamation happens only through `commit`, against a recorded transaction, with its generated confirmation token. The engine never accepts an arbitrary path for commit. Each staged entry is revalidated as residing below the transaction quarantine directory before deletion.

The skill should run `commit` only after the user has explicitly authorized permanent deletion of the displayed transaction/candidate set. A generic request to inspect or recommend cleanup is not authorization to commit.

## 4. Restore

`restore` moves staged entries back to their recorded original paths. If the original path has been recreated, restore stops on that item rather than overwriting it.

## Non-goals

This engine does not edit the registry, empty the Recycle Bin, purge browser profiles, remove installed applications, erase Downloads, mutate Windows servicing stores, delete project build trees by name, or clean arbitrary folders just because they contain `temp`, `cache`, `old`, or `backup` in the name.
