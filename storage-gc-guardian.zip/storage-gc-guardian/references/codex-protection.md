# Codex local-state protection

Treat `CODEX_HOME` as durable mixed state, not as a cache directory. By default this skill does **not** stage or purge anything under `CODEX_HOME`.

Hard-protected examples include:

- `sessions/` and `archived_sessions/` (conversation rollout data)
- `session_index.jsonl`, `history.jsonl`, thread/state SQLite databases
- `auth.json`, `config.toml`, global `AGENTS.md` / `AGENTS.override.md`
- `memories/` and memory databases
- `skills/`, plugins, attachments, and user-created tool state

Even paths that sound cache-like inside `CODEX_HOME` are not assumed disposable. If a future Codex release documents a supported cleanup command, prefer that supported interface.

`packages/standalone/releases` may contain old standalone runtimes, but removal is not automatic here. First prove which executable is active, which release it belongs to, and whether rollback is still needed. Use the official installer/uninstaller path when available.

## Why this is strict

Codex clients share state beneath `CODEX_HOME`, and current releases use session rollouts and local databases for history/project associations. Deleting these paths can cause irreversible local history loss or inconsistent UI state. The cleanup engine therefore rejects any managed root that resolves inside `CODEX_HOME`.
