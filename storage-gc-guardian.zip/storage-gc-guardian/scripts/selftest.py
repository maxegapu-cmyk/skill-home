#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
cmd = [sys.executable, "-m", "unittest", "discover", "-s", str(root / "tests"), "-v"]
raise SystemExit(subprocess.call(cmd, cwd=root))
