#!/usr/bin/env python3
"""Transactional storage garbage collector for the Storage GC Guardian skill.

Stdlib-only. It scans only named policy roots, binds a plan to file metadata,
stages unchanged files into same-root quarantine, and requires a transaction
confirmation token before permanent deletion.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform as _platform
import re
import secrets
import shutil
import stat
import sys
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = 1
QUARANTINE_NAME = ".storage-gc-quarantine"
STATE_DIR_NAME = ".storage-gc-guardian"
DEFAULT_PLAN_MAX_AGE_HOURS = 24.0
FILE_ATTRIBUTE_REPARSE_POINT = 0x400


def now_ns() -> int:
    return time.time_ns()


def iso_utc(ts: float | None = None) -> str:
    import datetime as dt
    d = dt.datetime.fromtimestamp(ts if ts is not None else time.time(), tz=dt.timezone.utc)
    return d.isoformat().replace("+00:00", "Z")


def detect_platform() -> str:
    forced = os.environ.get("STORAGE_GC_PLATFORM", "").strip().lower()
    if forced in {"windows", "linux", "darwin"}:
        return forced
    s = _platform.system().lower()
    if s.startswith("win"):
        return "windows"
    if s == "darwin":
        return "darwin"
    return "linux"


def state_home() -> Path:
    raw = os.environ.get("STORAGE_GC_STATE_HOME")
    return Path(raw).expanduser().absolute() if raw else Path.home() / STATE_DIR_NAME


def transactions_dir() -> Path:
    p = state_home() / "transactions"
    p.mkdir(parents=True, exist_ok=True)
    return p


def script_root() -> Path:
    return Path(__file__).resolve().parents[1]


def default_policy_path() -> Path:
    return script_root() / "references" / "default_profiles.json"


def atomic_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}-{secrets.token_hex(4)}")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def expand_vars(raw: str) -> str:
    # os.path.expandvars does not expand Windows %VAR% syntax on POSIX, which
    # matters for release tests and WSL-authored policies.
    def repl(m: re.Match[str]) -> str:
        return os.environ.get(m.group(1), m.group(0))

    x = re.sub(r"%([^%]+)%", repl, raw)
    x = os.path.expandvars(x)
    x = os.path.expanduser(x)
    return x


def absolute_no_resolve(path: Path) -> Path:
    # Avoid resolving through a link before we have checked link/reparse status.
    return Path(os.path.abspath(os.fspath(path)))


def safe_resolve(path: Path) -> Path:
    try:
        return path.resolve(strict=False)
    except OSError:
        return absolute_no_resolve(path)


def is_descendant(child: Path, parent: Path, *, allow_equal: bool = False) -> bool:
    c = safe_resolve(child)
    p = safe_resolve(parent)
    try:
        rel = c.relative_to(p)
    except ValueError:
        return False
    return allow_equal or rel != Path(".")


def same_path(a: Path, b: Path) -> bool:
    try:
        return os.path.normcase(os.path.abspath(os.fspath(a))) == os.path.normcase(os.path.abspath(os.fspath(b)))
    except OSError:
        return False


def is_drive_or_fs_root(path: Path) -> bool:
    p = absolute_no_resolve(path)
    return p.parent == p


def lstat_linklike(path: Path) -> tuple[os.stat_result | None, str | None]:
    try:
        st = path.lstat()
    except (FileNotFoundError, PermissionError, OSError) as e:
        return None, f"lstat:{type(e).__name__}:{e}"
    if stat.S_ISLNK(st.st_mode):
        return st, "symlink"
    attrs = getattr(st, "st_file_attributes", 0)
    if attrs & FILE_ATTRIBUTE_REPARSE_POINT:
        return st, "reparse-point"
    return st, None


def assert_no_link_components(root: Path, target: Path) -> None:
    """Reject existing symlink/reparse components between root and target.

    This uses lexical containment first; resolving either side before checking would
    hide a parent-link substitution attack. Missing components are allowed because
    stage/restore may need to recreate normal directories.
    """
    root_abs = absolute_no_resolve(root)
    target_abs = absolute_no_resolve(target)
    try:
        rel = target_abs.relative_to(root_abs)
    except ValueError as e:
        raise ValueError("path escaped managed root") from e
    cur = root_abs
    for part in rel.parts:
        cur = cur / part
        if not os.path.lexists(cur):
            continue
        st, link_reason = lstat_linklike(cur)
        if st is None:
            raise ValueError(f"cannot validate path component: {cur}: {link_reason}")
        if link_reason:
            raise ValueError(f"path component is {link_reason}: {cur}")


def codex_home() -> Path:
    return absolute_no_resolve(Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))).expanduser())


def root_guard_reason(root: Path) -> str | None:
    root_abs = absolute_no_resolve(root)
    home = absolute_no_resolve(Path.home())
    cwd = absolute_no_resolve(Path.cwd())
    cdx = codex_home()
    state = absolute_no_resolve(state_home())

    if is_drive_or_fs_root(root_abs):
        return "managed root is a filesystem/drive root"
    if same_path(root_abs, home):
        return "managed root is the user home directory"
    if same_path(root_abs, cwd) or is_descendant(cwd, root_abs):
        return "managed root is the current workspace or one of its ancestors"
    if same_path(root_abs, cdx) or is_descendant(root_abs, cdx):
        return "managed root is inside CODEX_HOME"
    if same_path(root_abs, state) or is_descendant(root_abs, state):
        return "managed root is inside the guardian state directory"
    st, link_reason = lstat_linklike(root_abs)
    if st is not None and link_reason:
        return f"managed root is {link_reason}"
    return None


def human_bytes(n: int) -> str:
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    x = float(n)
    for unit in units:
        if abs(x) < 1024.0 or unit == units[-1]:
            return f"{x:.2f} {unit}" if unit != "B" else f"{int(x)} B"
        x /= 1024.0
    return f"{n} B"


def stat_fingerprint(st: os.stat_result) -> dict[str, int]:
    return {
        "size": int(st.st_size),
        "mtime_ns": int(st.st_mtime_ns),
        "dev": int(getattr(st, "st_dev", 0)),
        "ino": int(getattr(st, "st_ino", 0)),
    }


def fingerprint_matches(expected: dict[str, Any], st: os.stat_result) -> bool:
    current = stat_fingerprint(st)
    for key in ("size", "mtime_ns"):
        if int(expected.get(key, -1)) != current[key]:
            return False
    # File identity is a useful extra invariant when the platform exposes it.
    for key in ("dev", "ino"):
        ev = int(expected.get(key, 0) or 0)
        cv = int(current.get(key, 0) or 0)
        if ev and cv and ev != cv:
            return False
    return True


@dataclass(frozen=True)
class Profile:
    id: str
    platforms: tuple[str, ...]
    roots: tuple[str, ...]
    min_age_days: float
    default_enabled: bool
    kind: str
    extensions: tuple[str, ...]
    note: str


def load_policy(path: Path) -> tuple[dict[str, Any], list[Profile], str]:
    raw = load_json(path)
    if raw.get("schema_version") != 1 or not isinstance(raw.get("profiles"), list):
        raise ValueError("unsupported or invalid policy schema")
    profiles: list[Profile] = []
    seen: set[str] = set()
    for p in raw["profiles"]:
        pid = str(p.get("id", "")).strip()
        if not pid or pid in seen or not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,63}", pid):
            raise ValueError(f"invalid or duplicate profile id: {pid!r}")
        seen.add(pid)
        roots = tuple(str(x) for x in p.get("roots", []))
        if not roots:
            raise ValueError(f"profile {pid} has no roots")
        age = float(p.get("min_age_days", 0))
        if age < 1:
            raise ValueError(f"profile {pid} min_age_days must be >= 1")
        exts = tuple(str(x).lower() for x in p.get("extensions", []))
        if any(not x.startswith(".") for x in exts):
            raise ValueError(f"profile {pid} extensions must start with '.'")
        profiles.append(Profile(
            id=pid,
            platforms=tuple(str(x).lower() for x in p.get("platforms", [])),
            roots=roots,
            min_age_days=age,
            default_enabled=bool(p.get("default_enabled", False)),
            kind=str(p.get("kind", "unknown")),
            extensions=exts,
            note=str(p.get("note", "")),
        ))
    return raw, profiles, file_sha256(path)


def select_profiles(profiles: list[Profile], requested: list[str], current_platform: str) -> list[Profile]:
    by_id = {p.id: p for p in profiles}
    if requested:
        missing = [x for x in requested if x not in by_id]
        if missing:
            raise ValueError("unknown profile(s): " + ", ".join(missing))
        chosen = [by_id[x] for x in requested]
    else:
        chosen = [p for p in profiles if p.default_enabled]
    out = []
    for p in chosen:
        if p.platforms and current_platform not in p.platforms:
            if requested:
                raise ValueError(f"profile {p.id} does not support platform {current_platform}")
            continue
        out.append(p)
    return out


def root_instances(profile: Profile) -> list[Path]:
    out: list[Path] = []
    seen: set[str] = set()
    for raw in profile.roots:
        expanded = expand_vars(raw)
        # An unexpanded %VAR% is a missing root, not a literal directory.
        if re.search(r"%[^%]+%", expanded):
            continue
        p = absolute_no_resolve(Path(expanded))
        key = os.path.normcase(os.path.abspath(os.fspath(p)))
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def scan_root(profile: Profile, root: Path, cutoff_ns: int, max_files: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
    candidates: list[dict[str, Any]] = []
    skips: list[dict[str, Any]] = []
    visited = 0
    reason = root_guard_reason(root)
    if reason:
        skips.append({"profile": profile.id, "root": str(root), "reason": reason})
        return candidates, skips, visited
    if not root.exists() or not root.is_dir():
        skips.append({"profile": profile.id, "root": str(root), "reason": "root missing or not a directory"})
        return candidates, skips, visited

    try:
        for base, dirs, files in os.walk(root, topdown=True, followlinks=False):
            base_p = Path(base)
            filtered_dirs: list[str] = []
            for d in dirs:
                if d == QUARANTINE_NAME:
                    continue
                dp = base_p / d
                st, link_reason = lstat_linklike(dp)
                if st is None:
                    skips.append({"profile": profile.id, "path": str(dp), "reason": link_reason or "unstatable"})
                    continue
                if link_reason:
                    skips.append({"profile": profile.id, "path": str(dp), "reason": link_reason})
                    continue
                filtered_dirs.append(d)
            dirs[:] = filtered_dirs

            for name in files:
                visited += 1
                if visited > max_files:
                    skips.append({"profile": profile.id, "root": str(root), "reason": f"max_files limit reached ({max_files})"})
                    return candidates, skips, visited
                p = base_p / name
                st, link_reason = lstat_linklike(p)
                if st is None:
                    skips.append({"profile": profile.id, "path": str(p), "reason": link_reason or "unstatable"})
                    continue
                if link_reason:
                    skips.append({"profile": profile.id, "path": str(p), "reason": link_reason})
                    continue
                if not stat.S_ISREG(st.st_mode):
                    skips.append({"profile": profile.id, "path": str(p), "reason": "not a regular file"})
                    continue
                if st.st_mtime_ns > cutoff_ns:
                    continue
                if profile.extensions and p.suffix.lower() not in profile.extensions:
                    continue
                if same_path(p, root) or not is_descendant(p, root):
                    skips.append({"profile": profile.id, "path": str(p), "reason": "containment check failed"})
                    continue
                if same_path(p, codex_home()) or is_descendant(p, codex_home()):
                    skips.append({"profile": profile.id, "path": str(p), "reason": "inside CODEX_HOME"})
                    continue
                rel = p.relative_to(root)
                candidates.append({
                    "profile": profile.id,
                    "kind": profile.kind,
                    "root": str(root),
                    "path": str(p),
                    "relative_path": rel.as_posix(),
                    "fingerprint": stat_fingerprint(st),
                })
    except (PermissionError, OSError) as e:
        skips.append({"profile": profile.id, "root": str(root), "reason": f"walk:{type(e).__name__}:{e}"})
    return candidates, skips, visited


def cmd_profiles(args: argparse.Namespace, profiles: list[Profile], current_platform: str) -> int:
    rows = []
    for p in profiles:
        rows.append({
            "id": p.id,
            "platforms": list(p.platforms),
            "eligible_here": not p.platforms or current_platform in p.platforms,
            "default_enabled": p.default_enabled,
            "min_age_days": p.min_age_days,
            "kind": p.kind,
            "roots": list(p.roots),
            "note": p.note,
        })
    print(json.dumps(rows, indent=2, ensure_ascii=False))
    return 0


def cmd_doctor(args: argparse.Namespace, profiles: list[Profile], current_platform: str) -> int:
    home = Path.home()
    usage = shutil.disk_usage(home)
    print(json.dumps({
        "schema_version": SCHEMA_VERSION,
        "platform": current_platform,
        "python": sys.version.split()[0],
        "home": str(home),
        "free_bytes": usage.free,
        "free_human": human_bytes(usage.free),
        "state_home": str(state_home()),
        "codex_home": str(codex_home()),
        "codex_home_policy": "protected; automatic cleanup disabled",
        "quarantine_name": QUARANTINE_NAME,
    }, indent=2, ensure_ascii=False))
    return 0


def cmd_scan(args: argparse.Namespace, policy_hash: str, profiles: list[Profile], current_platform: str) -> int:
    chosen = select_profiles(profiles, args.profile or [], current_platform)
    generated_ns = now_ns()
    all_candidates: list[dict[str, Any]] = []
    all_skips: list[dict[str, Any]] = []
    profile_runs = []
    total_visited = 0
    global_seen: set[str] = set()

    for p in chosen:
        roots = root_instances(p)
        if not roots:
            all_skips.append({"profile": p.id, "reason": "no roots expanded on this machine"})
            continue
        cutoff_ns = generated_ns - int(p.min_age_days * 86400 * 1_000_000_000)
        for root in roots:
            candidates, skips, visited = scan_root(p, root, cutoff_ns, max(1, args.max_files - total_visited))
            total_visited += visited
            deduped = []
            for c in candidates:
                key = os.path.normcase(os.path.abspath(c["path"]))
                if key in global_seen:
                    continue
                global_seen.add(key)
                deduped.append(c)
            all_candidates.extend(deduped)
            all_skips.extend(skips)
            profile_runs.append({
                "profile": p.id,
                "root": str(root),
                "min_age_days": p.min_age_days,
                "candidate_count": len(deduped),
                "candidate_bytes": sum(int(c["fingerprint"]["size"]) for c in deduped),
            })
            if total_visited >= args.max_files:
                break
        if total_visited >= args.max_files:
            break

    total_bytes = sum(int(c["fingerprint"]["size"]) for c in all_candidates)
    plan = {
        "schema_version": SCHEMA_VERSION,
        "plan_id": str(uuid.uuid4()),
        "created_at": iso_utc(),
        "created_at_ns": generated_ns,
        "platform": current_platform,
        "policy_sha256": policy_hash,
        "profiles": profile_runs,
        "candidate_count": len(all_candidates),
        "candidate_bytes": total_bytes,
        "candidates": all_candidates,
        "skips": all_skips,
        "limits": {"max_files": args.max_files, "visited_files": total_visited},
    }
    out = Path(args.out).expanduser().absolute()
    atomic_write_json(out, plan)
    print(json.dumps({
        "plan": str(out),
        "plan_id": plan["plan_id"],
        "candidate_count": len(all_candidates),
        "candidate_bytes": total_bytes,
        "candidate_human": human_bytes(total_bytes),
        "skip_count": len(all_skips),
        "visited_files": total_visited,
        "note": "read-only plan; no files moved or deleted",
    }, indent=2, ensure_ascii=False))
    return 0


def txn_path(txn_id: str) -> Path:
    if not re.fullmatch(r"[0-9a-f-]{36}", txn_id):
        raise ValueError("invalid transaction id")
    return transactions_dir() / f"{txn_id}.json"


def load_txn(txn_id: str) -> dict[str, Any]:
    p = txn_path(txn_id)
    if not p.exists():
        raise FileNotFoundError(f"transaction not found: {txn_id}")
    return load_json(p)


def save_txn(txn: dict[str, Any]) -> None:
    txn["updated_at"] = iso_utc()
    atomic_write_json(txn_path(txn["transaction_id"]), txn)


def prune_empty_parents(path: Path, stop: Path) -> None:
    cur = path.parent
    stop_abs = absolute_no_resolve(stop)
    while is_descendant(cur, stop_abs) and not same_path(cur, stop_abs):
        if cur.name == QUARANTINE_NAME:
            break
        try:
            cur.rmdir()
        except OSError:
            break
        cur = cur.parent


def stage_destination(root: Path, txn_id: str, rel: Path) -> Path:
    qbase = root / QUARANTINE_NAME / txn_id / "files"
    dest = qbase / rel
    if not is_descendant(dest, qbase):
        raise ValueError("quarantine destination escaped transaction root")
    return dest


def validate_plan_candidate(c: dict[str, Any]) -> tuple[Path, Path, Path, os.stat_result]:
    root = absolute_no_resolve(Path(c["root"]))
    src = absolute_no_resolve(Path(c["path"]))
    rel = Path(c["relative_path"])
    reason = root_guard_reason(root)
    if reason:
        raise ValueError(f"root rejected: {reason}")
    if rel.is_absolute() or ".." in rel.parts or rel == Path("."):
        raise ValueError("invalid relative path")
    if not is_descendant(src, root) or same_path(src, root):
        raise ValueError("source outside managed root")
    assert_no_link_components(root, src.parent)
    expected_src = root / rel
    if not same_path(src, expected_src):
        raise ValueError("relative path does not match source")
    st, link_reason = lstat_linklike(src)
    if st is None:
        raise FileNotFoundError(link_reason or "source missing")
    if link_reason:
        raise ValueError(f"source rejected: {link_reason}")
    if not stat.S_ISREG(st.st_mode):
        raise ValueError("source is not a regular file")
    if not fingerprint_matches(c["fingerprint"], st):
        raise ValueError("stale plan: file fingerprint changed")
    return root, src, rel, st


def cmd_stage(args: argparse.Namespace) -> int:
    plan_path = Path(args.plan).expanduser().absolute()
    plan = load_json(plan_path)
    if plan.get("schema_version") != SCHEMA_VERSION or not isinstance(plan.get("candidates"), list):
        raise ValueError("invalid plan schema")
    age_hours = (now_ns() - int(plan.get("created_at_ns", 0))) / 3_600_000_000_000
    if age_hours < 0 or age_hours > args.max_plan_age_hours:
        raise ValueError(f"plan is too old ({age_hours:.2f}h); rescan before staging")

    txn_id = str(uuid.uuid4())
    token = secrets.token_urlsafe(12)
    txn = {
        "schema_version": SCHEMA_VERSION,
        "transaction_id": txn_id,
        "plan_id": plan.get("plan_id"),
        "plan_path": str(plan_path),
        "created_at": iso_utc(),
        "updated_at": iso_utc(),
        "status": "staging",
        "commit_token": token,
        "entries": [],
        "errors": [],
    }
    save_txn(txn)

    staged_bytes = 0
    for c in plan["candidates"]:
        try:
            root, src, rel, st = validate_plan_candidate(c)
            dest = stage_destination(root, txn_id, rel)
            # Validate any pre-existing quarantine components before creating more.
            assert_no_link_components(root, dest.parent)
            entry = {
                "profile": c.get("profile"),
                "root": str(root),
                "source": str(src),
                "relative_path": rel.as_posix(),
                "destination": str(dest),
                "bytes": int(st.st_size),
                "fingerprint": stat_fingerprint(st),
                "status": "pending",
            }
            txn["entries"].append(entry)
            save_txn(txn)  # write-ahead record
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                raise FileExistsError(f"quarantine collision: {dest}")
            os.replace(src, dest)
            entry["status"] = "staged"
            staged_bytes += int(st.st_size)
            save_txn(txn)
            prune_empty_parents(src, root)
        except Exception as e:
            txn["errors"].append({
                "path": str(c.get("path", "")),
                "error": f"{type(e).__name__}: {e}",
            })
            save_txn(txn)

    staged_count = sum(1 for e in txn["entries"] if e.get("status") == "staged")
    txn["status"] = "staged" if not txn["errors"] else "partial"
    txn["staged_bytes"] = staged_bytes
    txn["staged_count"] = staged_count
    save_txn(txn)
    print(json.dumps({
        "transaction_id": txn_id,
        "status": txn["status"],
        "staged_count": staged_count,
        "staged_bytes": staged_bytes,
        "staged_human": human_bytes(staged_bytes),
        "error_count": len(txn["errors"]),
        "restore": f"python scripts/storage_gc.py restore --txn {txn_id}",
        "commit": f"python scripts/storage_gc.py commit --txn {txn_id} --confirm {token}",
        "commit_token": token,
        "note": "staged data still occupies disk space until commit",
    }, indent=2, ensure_ascii=False))
    return 0 if not txn["errors"] else 2


def reconcile_entry_state(entry: dict[str, Any]) -> str:
    src = absolute_no_resolve(Path(entry["source"]))
    dest = absolute_no_resolve(Path(entry["destination"]))
    if dest.exists() and not src.exists():
        return "staged"
    if src.exists() and not dest.exists():
        return "source-present"
    if not src.exists() and not dest.exists():
        return "missing-both"
    return "conflict-both-present"


def validate_txn_destination(entry: dict[str, Any], txn_id: str) -> tuple[Path, Path, Path]:
    root = absolute_no_resolve(Path(entry["root"]))
    src = absolute_no_resolve(Path(entry["source"]))
    dest = absolute_no_resolve(Path(entry["destination"]))
    rel = Path(entry["relative_path"])
    qbase = root / QUARANTINE_NAME / txn_id / "files"
    if not is_descendant(dest, qbase):
        raise ValueError("transaction destination escaped quarantine")
    if not same_path(dest, qbase / rel):
        raise ValueError("transaction destination mismatch")
    if not is_descendant(src, root):
        raise ValueError("transaction source escaped managed root")
    # Re-check every existing parent component at commit/restore time. A
    # quarantine or source parent replaced by a symlink/reparse point must never
    # redirect a destructive operation outside the recorded root.
    assert_no_link_components(root, dest.parent)
    assert_no_link_components(root, src.parent)
    return root, src, dest


def cmd_restore(args: argparse.Namespace) -> int:
    txn = load_txn(args.txn)
    restored_bytes = 0
    conflicts = []
    for entry in txn.get("entries", []):
        try:
            root, src, dest = validate_txn_destination(entry, args.txn)
            state = reconcile_entry_state(entry)
            if state == "staged":
                src.parent.mkdir(parents=True, exist_ok=True)
                if src.exists():
                    raise FileExistsError("restore would overwrite an existing path")
                os.replace(dest, src)
                prune_empty_parents(dest, root / QUARANTINE_NAME / args.txn)
                entry["status"] = "restored"
                restored_bytes += int(entry.get("bytes", 0))
                save_txn(txn)
            elif state == "source-present":
                entry["status"] = "restored"
            else:
                conflicts.append({"source": str(src), "state": state})
        except Exception as e:
            conflicts.append({"source": entry.get("source", ""), "error": f"{type(e).__name__}: {e}"})
        save_txn(txn)
    txn["status"] = "restored" if not conflicts else "restore-partial"
    txn["restore_conflicts"] = conflicts
    save_txn(txn)
    # Best-effort prune empty transaction directories.
    for entry in txn.get("entries", []):
        try:
            root = Path(entry["root"])
            qtxn = root / QUARANTINE_NAME / args.txn
            for p in [qtxn / "files", qtxn, root / QUARANTINE_NAME]:
                try:
                    p.rmdir()
                except OSError:
                    pass
        except Exception:
            pass
    print(json.dumps({
        "transaction_id": args.txn,
        "status": txn["status"],
        "restored_bytes": restored_bytes,
        "restored_human": human_bytes(restored_bytes),
        "conflicts": conflicts,
    }, indent=2, ensure_ascii=False))
    return 0 if not conflicts else 2


def cmd_commit(args: argparse.Namespace) -> int:
    txn = load_txn(args.txn)
    if args.confirm != txn.get("commit_token"):
        raise ValueError("confirmation token does not match this transaction")
    if txn.get("status") in {"committed", "restored"}:
        raise ValueError(f"transaction already finalized: {txn.get('status')}")
    txn["status"] = "committing"
    save_txn(txn)
    deleted_bytes = 0
    errors = []
    for entry in txn.get("entries", []):
        try:
            root, src, dest = validate_txn_destination(entry, args.txn)
            state = reconcile_entry_state(entry)
            if state == "staged":
                st, link_reason = lstat_linklike(dest)
                if st is None:
                    raise FileNotFoundError(link_reason or "staged file missing")
                if link_reason:
                    raise ValueError(f"staged object became {link_reason}")
                if not stat.S_ISREG(st.st_mode):
                    raise ValueError("staged object is no longer a regular file")
                # Ensure staged bytes are still what the transaction recorded.
                if int(entry.get("bytes", -1)) != int(st.st_size):
                    raise ValueError("staged file size changed; refusing commit")
                dest.unlink()
                prune_empty_parents(dest, root / QUARANTINE_NAME / args.txn)
                deleted_bytes += int(st.st_size)
                entry["status"] = "committed"
                save_txn(txn)
            elif state == "missing-both" and entry.get("status") == "committed":
                pass
            elif state == "source-present" and entry.get("status") == "restored":
                raise ValueError("entry was restored; cannot commit it")
            else:
                raise ValueError(f"unexpected entry state: {state}")
        except Exception as e:
            errors.append({"source": entry.get("source", ""), "error": f"{type(e).__name__}: {e}"})
            save_txn(txn)

    # Prune only known empty quarantine directories.
    for entry in txn.get("entries", []):
        try:
            root = Path(entry["root"])
            qtxn = root / QUARANTINE_NAME / args.txn
            for p in [qtxn / "files", qtxn, root / QUARANTINE_NAME]:
                try:
                    p.rmdir()
                except OSError:
                    pass
        except Exception:
            pass

    txn["status"] = "committed" if not errors else "commit-partial"
    txn["committed_bytes"] = deleted_bytes
    txn["commit_errors"] = errors
    save_txn(txn)
    print(json.dumps({
        "transaction_id": args.txn,
        "status": txn["status"],
        "committed_bytes": deleted_bytes,
        "committed_human": human_bytes(deleted_bytes),
        "error_count": len(errors),
        "errors": errors,
    }, indent=2, ensure_ascii=False))
    return 0 if not errors else 2


def cmd_status(args: argparse.Namespace) -> int:
    txn = load_txn(args.txn)
    states: dict[str, int] = {}
    for e in txn.get("entries", []):
        try:
            s = reconcile_entry_state(e)
        except Exception:
            s = "invalid"
        states[s] = states.get(s, 0) + 1
    out = {
        "transaction_id": txn.get("transaction_id"),
        "status": txn.get("status"),
        "created_at": txn.get("created_at"),
        "updated_at": txn.get("updated_at"),
        "entry_count": len(txn.get("entries", [])),
        "staged_bytes": int(txn.get("staged_bytes", 0)),
        "committed_bytes": int(txn.get("committed_bytes", 0)),
        "filesystem_states": states,
        "error_count": len(txn.get("errors", [])) + len(txn.get("commit_errors", [])) + len(txn.get("restore_conflicts", [])),
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Evidence-bound transactional storage garbage collector")
    p.add_argument("--policy", default=str(default_policy_path()), help="profile policy JSON")
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="show environment and safety roots")
    sub.add_parser("profiles", help="list cleanup profiles")

    s = sub.add_parser("scan", help="create a read-only cleanup plan")
    s.add_argument("--profile", action="append", help="profile id; repeat to combine; defaults to enabled profiles")
    s.add_argument("--out", required=True, help="output plan JSON")
    s.add_argument("--max-files", type=int, default=200000, help="hard cap on files inspected")

    s = sub.add_parser("stage", help="move unchanged plan candidates into reversible quarantine")
    s.add_argument("--plan", required=True)
    s.add_argument("--max-plan-age-hours", type=float, default=DEFAULT_PLAN_MAX_AGE_HOURS)

    s = sub.add_parser("restore", help="restore a staged transaction")
    s.add_argument("--txn", required=True)

    s = sub.add_parser("commit", help="permanently delete one staged transaction")
    s.add_argument("--txn", required=True)
    s.add_argument("--confirm", required=True)

    s = sub.add_parser("status", help="inspect a transaction")
    s.add_argument("--txn", required=True)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        policy_path = Path(args.policy).expanduser().absolute()
        _raw, profiles, policy_hash = load_policy(policy_path)
        current_platform = detect_platform()
        if args.command == "doctor":
            return cmd_doctor(args, profiles, current_platform)
        if args.command == "profiles":
            return cmd_profiles(args, profiles, current_platform)
        if args.command == "scan":
            if args.max_files < 1:
                raise ValueError("--max-files must be >= 1")
            return cmd_scan(args, policy_hash, profiles, current_platform)
        if args.command == "stage":
            if args.max_plan_age_hours <= 0:
                raise ValueError("--max-plan-age-hours must be > 0")
            return cmd_stage(args)
        if args.command == "restore":
            return cmd_restore(args)
        if args.command == "commit":
            return cmd_commit(args)
        if args.command == "status":
            return cmd_status(args)
        parser.error("unknown command")
        return 2
    except KeyboardInterrupt:
        print("ERROR: interrupted", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
