import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1]
SCRIPT = SKILL / "scripts" / "storage_gc.py"


class StorageGCTests(unittest.TestCase):
    def setUp(self):
        self.tmp_obj = tempfile.TemporaryDirectory(prefix="storage-gc-test-")
        self.base = Path(self.tmp_obj.name)
        self.home = self.base / "home"
        self.home.mkdir()
        self.cache = self.base / "managed-cache"
        self.cache.mkdir()
        self.state = self.base / "state"
        self.codex = self.home / ".codex"
        self.codex.mkdir()
        self.policy = self.base / "policy.json"
        self.write_policy(self.cache)
        self.env = os.environ.copy()
        self.env.update({
            "HOME": str(self.home),
            "USERPROFILE": str(self.home),
            "CODEX_HOME": str(self.codex),
            "STORAGE_GC_STATE_HOME": str(self.state),
            "STORAGE_GC_PLATFORM": "linux",
        })
        self.cwd = SKILL

    def tearDown(self):
        self.tmp_obj.cleanup()

    def write_policy(self, root: Path, *, min_age=1, extensions=None):
        profile = {
            "id": "test-cache",
            "platforms": ["linux"],
            "roots": [str(root)],
            "min_age_days": min_age,
            "default_enabled": True,
            "kind": "rebuildable-cache",
            "note": "test",
        }
        if extensions is not None:
            profile["extensions"] = extensions
        self.policy.write_text(json.dumps({"schema_version": 1, "profiles": [profile]}), encoding="utf-8")

    def run_cli(self, *args, expect=0):
        cp = subprocess.run(
            [sys.executable, str(SCRIPT), "--policy", str(self.policy), *args],
            cwd=self.cwd,
            env=self.env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if cp.returncode != expect:
            self.fail(f"rc={cp.returncode} expected={expect}\nstdout={cp.stdout}\nstderr={cp.stderr}")
        return cp

    def old_file(self, rel="old.bin", data=b"abc"):
        p = self.cache / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        old = time.time() - 3 * 86400
        os.utime(p, (old, old))
        return p

    def scan(self):
        plan = self.base / "plan.json"
        cp = self.run_cli("scan", "--out", str(plan))
        return plan, json.loads(cp.stdout)

    def stage(self, plan: Path, expect=0):
        cp = self.run_cli("stage", "--plan", str(plan), expect=expect)
        return json.loads(cp.stdout) if cp.stdout.strip() else None

    def test_scan_is_read_only_and_age_bound(self):
        old = self.old_file("a/old.bin", b"old")
        fresh = self.cache / "fresh.bin"
        fresh.write_bytes(b"fresh")
        plan_path, out = self.scan()
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
        self.assertEqual(out["candidate_count"], 1)
        self.assertEqual(plan["candidate_count"], 1)
        self.assertTrue(old.exists())
        self.assertTrue(fresh.exists())

    def test_symlink_is_never_candidate(self):
        target = self.old_file("target.bin")
        link = self.cache / "link.bin"
        try:
            link.symlink_to(target)
        except (OSError, NotImplementedError):
            self.skipTest("symlink unavailable")
        old = time.time() - 3 * 86400
        try:
            os.utime(link, (old, old), follow_symlinks=False)
        except Exception:
            pass
        plan_path, _ = self.scan()
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
        paths = {Path(c["path"]).name for c in plan["candidates"]}
        self.assertIn("target.bin", paths)
        self.assertNotIn("link.bin", paths)

    def test_stage_then_restore(self):
        src = self.old_file("nested/data.bin", b"123456")
        plan, _ = self.scan()
        out = self.stage(plan)
        self.assertFalse(src.exists())
        txn = out["transaction_id"]
        txndata = json.loads((self.state / "transactions" / f"{txn}.json").read_text(encoding="utf-8"))
        dest = Path(txndata["entries"][0]["destination"])
        self.assertTrue(dest.exists())
        cp = self.run_cli("restore", "--txn", txn)
        restored = json.loads(cp.stdout)
        self.assertEqual(restored["status"], "restored")
        self.assertTrue(src.exists())
        self.assertEqual(src.read_bytes(), b"123456")
        self.assertFalse(dest.exists())

    def test_commit_requires_token_and_frees_quarantine(self):
        src = self.old_file("payload.bin", b"x" * 100)
        plan, _ = self.scan()
        staged = self.stage(plan)
        txn, token = staged["transaction_id"], staged["commit_token"]
        self.run_cli("commit", "--txn", txn, "--confirm", "wrong", expect=2)
        self.assertFalse(src.exists())
        cp = self.run_cli("commit", "--txn", txn, "--confirm", token)
        out = json.loads(cp.stdout)
        self.assertEqual(out["status"], "committed")
        self.assertEqual(out["committed_bytes"], 100)
        self.assertFalse(src.exists())
        txndata = json.loads((self.state / "transactions" / f"{txn}.json").read_text(encoding="utf-8"))
        self.assertFalse(Path(txndata["entries"][0]["destination"]).exists())

    def test_changed_file_is_rejected_by_stale_plan_guard(self):
        src = self.old_file("changing.bin", b"before")
        plan, _ = self.scan()
        src.write_bytes(b"after and different")
        staged = self.stage(plan, expect=2)
        self.assertEqual(staged["staged_count"], 0)
        self.assertEqual(staged["error_count"], 1)
        self.assertTrue(src.exists())
        self.assertEqual(src.read_bytes(), b"after and different")

    def test_codex_home_is_hard_protected(self):
        root = self.codex / "cache"
        root.mkdir()
        p = root / "old.bin"
        p.write_bytes(b"secret-ish")
        old = time.time() - 3 * 86400
        os.utime(p, (old, old))
        self.write_policy(root)
        plan, _ = self.scan()
        data = json.loads(plan.read_text(encoding="utf-8"))
        self.assertEqual(data["candidate_count"], 0)
        self.assertTrue(any("CODEX_HOME" in s.get("reason", "") for s in data["skips"]))
        self.assertTrue(p.exists())

    def test_home_root_is_rejected(self):
        p = self.home / "old.bin"
        p.write_bytes(b"keep")
        old = time.time() - 3 * 86400
        os.utime(p, (old, old))
        self.write_policy(self.home)
        plan, _ = self.scan()
        data = json.loads(plan.read_text(encoding="utf-8"))
        self.assertEqual(data["candidate_count"], 0)
        self.assertTrue(any("home directory" in s.get("reason", "") for s in data["skips"]))
        self.assertTrue(p.exists())

    def test_expired_plan_is_rejected_before_transaction(self):
        self.old_file("old.bin")
        plan, _ = self.scan()
        data = json.loads(plan.read_text(encoding="utf-8"))
        data["created_at_ns"] = time.time_ns() - int(48 * 3600 * 1e9)
        plan.write_text(json.dumps(data), encoding="utf-8")
        self.run_cli("stage", "--plan", str(plan), expect=2)
        txndir = self.state / "transactions"
        self.assertFalse(txndir.exists() and any(txndir.iterdir()))

    def test_tampered_transaction_cannot_delete_outside_file(self):
        self.old_file("payload.bin", b"garbage")
        outside = self.base / "outside.txt"
        outside.write_bytes(b"DO NOT DELETE")
        plan, _ = self.scan()
        staged = self.stage(plan)
        txn, token = staged["transaction_id"], staged["commit_token"]
        txnp = self.state / "transactions" / f"{txn}.json"
        data = json.loads(txnp.read_text(encoding="utf-8"))
        data["entries"][0]["destination"] = str(outside)
        txnp.write_text(json.dumps(data), encoding="utf-8")
        cp = self.run_cli("commit", "--txn", txn, "--confirm", token, expect=2)
        out = json.loads(cp.stdout)
        self.assertEqual(out["status"], "commit-partial")
        self.assertTrue(outside.exists())
        self.assertEqual(outside.read_bytes(), b"DO NOT DELETE")


    def test_quarantine_parent_symlink_substitution_is_blocked(self):
        self.old_file("nested/payload.bin", b"garbage")
        plan, _ = self.scan()
        staged = self.stage(plan)
        txn, token = staged["transaction_id"], staged["commit_token"]
        txnp = self.state / "transactions" / f"{txn}.json"
        data = json.loads(txnp.read_text(encoding="utf-8"))
        dest = Path(data["entries"][0]["destination"])
        qfiles = dest.parents[1]  # .../<txn>/files
        backup = qfiles.with_name("files-real")
        outside = self.base / "attacker-target"
        outside_target = outside / "nested" / "payload.bin"
        outside_target.parent.mkdir(parents=True)
        outside_target.write_bytes(b"DO NOT DELETE")
        try:
            qfiles.rename(backup)
            qfiles.symlink_to(outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("symlink substitution unavailable")
        cp = self.run_cli("commit", "--txn", txn, "--confirm", token, expect=2)
        out = json.loads(cp.stdout)
        self.assertEqual(out["status"], "commit-partial")
        self.assertTrue(outside_target.exists())
        self.assertEqual(outside_target.read_bytes(), b"DO NOT DELETE")

    def test_extension_filter(self):
        self.write_policy(self.cache, extensions=[".log"])
        log = self.old_file("a.log")
        binf = self.old_file("b.bin")
        plan, _ = self.scan()
        data = json.loads(plan.read_text(encoding="utf-8"))
        paths = {Path(c["path"]).name for c in data["candidates"]}
        self.assertEqual(paths, {"a.log"})
        self.assertTrue(log.exists() and binf.exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
