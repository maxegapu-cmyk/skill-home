# Interactive Film UI Fusion Production Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Upgrade the addon from contract-only v1.0 into a production-trial v1.1 that can visibly reproduce the WorkBuddy-style HUD grammar, execute its preview in a real browser, reject malformed production contracts, and guide beginners through one-command builds.

**Architecture:** Keep upstream story/state authority untouched. Harden the project schema and validator, enrich CET with UI lifetimes/copy/audio/layout, render a stateful WorkBuddy-grade browser preview from the same CET, add one-command build and readiness audit, then export unchanged event/action identity to adapters.

**Tech Stack:** Python 3 stdlib, SVG/HTML/CSS/vanilla JS, optional Node/Chromium/Playwright only for release verification.

**Spec:** Existing references plus WorkBuddy v5 golden fixture in `fixtures/workbuddy-v5/project.json`.

## Global Constraints
- No new story state may be invented by the UI layer.
- All adapters preserve event IDs and canonical action IDs.
- Core build remains Python-stdlib-only.
- External CV/runtime tools stay adapters, not hard dependencies.
- WorkBuddy 18-shot fixture remains the golden regression sample.

---

### Task 1: Add adversarial contract tests
Create failing tests for duplicate shots, event ordering, anchor enums/geometry, keyframe ordering, event family required fields, UI state contracts, QTE windows, and settlement payload.

### Task 2: Harden validator and CET lifecycle
Implement the minimal validation/lifecycle rules needed by Task 1 and add deterministic event end/lifetime fields.

### Task 3: Make preview executable and WorkBuddy-grade
Add browser-executed syntax/smoke tests first, then render persistent HUD, map/route, collection bar, event cards, tips, stamps, settlement, HUD clear, and brand outro from project/CET data.

### Task 4: Enrich WorkBuddy golden fixture
Add all 18-shot visible copy, audio cues, route nodes, eight collection items, timer settlement override, UI layout, and component state contracts while preserving canonical event identity.

### Task 5: Add production readiness audit and beginner build
Add a mode-aware readiness report plus one-command builder that validates, compiles CET, generates SVG assets, preview, adapters, and a human-readable production report.

### Task 6: Stress and release verification
Run unit/adversarial tests, mutation escape suite, actual browser runtime checks, golden build, fresh ZIP extraction, rerun full suite, verify manifest and SHA256, and report remaining pixel-level limits honestly.
