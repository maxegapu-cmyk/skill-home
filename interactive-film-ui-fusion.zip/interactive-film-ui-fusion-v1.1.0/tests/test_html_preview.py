import json
import tempfile
import unittest
from pathlib import Path
from scripts.compile_overlay import compile_overlay
from scripts.generate_html_preview import generate_preview

ROOT=Path(__file__).resolve().parents[1]

class HtmlPreviewTests(unittest.TestCase):
    def test_generates_self_contained_timeline_preview(self):
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        overlay=compile_overlay(project)
        with tempfile.TemporaryDirectory() as td:
            path=generate_preview(project,overlay,Path(td)/'preview.html')
            text=path.read_text(encoding='utf-8')
            self.assertIn('data-project-id="workbuddy-v5-golden"',text)
            self.assertIn('id="timeline"',text)
            self.assertIn('HOTSPOT_HIT',text)
            self.assertIn('const CET =',text)
            self.assertNotIn('http://',text)
            self.assertNotIn('https://',text)


    def test_preview_uses_project_aspect_ratio(self):
        import copy
        project=copy.deepcopy(json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8')))
        project['frame']['width']=1080
        project['frame']['height']=1920
        overlay=compile_overlay(project)
        with tempfile.TemporaryDirectory() as td:
            path=generate_preview(project,overlay,Path(td)/'preview.html')
            text=path.read_text(encoding='utf-8')
            self.assertIn('aspect-ratio:1080/1920',text)

if __name__=='__main__': unittest.main()
