import copy
import json
import unittest
from pathlib import Path

from scripts.validate_project import validate_project

ROOT = Path(__file__).resolve().parents[1]


class ProductionValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))

    def errors_for(self, mutator):
        p = copy.deepcopy(self.project)
        mutator(p)
        return validate_project(p)

    def assert_rejected(self, mutator, needle):
        errors = self.errors_for(mutator)
        self.assertTrue(any(needle.lower() in e.lower() for e in errors), errors)

    def test_duplicate_shot_id_is_rejected(self):
        self.assert_rejected(lambda p: p['shots'][1].__setitem__('id', p['shots'][0]['id']), 'duplicate shot')

    def test_events_must_be_time_sorted_inside_shot(self):
        self.assert_rejected(lambda p: p['shots'][5]['events'].reverse(), 'event order')

    def test_anchor_type_is_enumerated(self):
        self.assert_rejected(lambda p: p['anchors']['screen-top'].__setitem__('type', 'MAGIC'), 'anchor type')

    def test_tracking_mode_is_enumerated(self):
        self.assert_rejected(lambda p: p['anchors']['screen-top'].__setitem__('tracking', 'teleport'), 'tracking')

    def test_occlusion_mode_is_enumerated(self):
        self.assert_rejected(lambda p: p['anchors']['screen-top'].__setitem__('occlusion', 'ghost'), 'occlusion')

    def test_point_static_anchor_requires_coordinates(self):
        def mutate(p):
            p['anchors']['bad-point'] = {'type': 'POINT', 'tracking': 'static'}
        self.assert_rejected(mutate, 'requires x/y')

    def test_keyframes_are_monotonic(self):
        def mutate(p):
            p['anchors']['sword-1']['keyframes'] = list(reversed(p['anchors']['sword-1']['keyframes']))
        self.assert_rejected(mutate, 'keyframe time')

    def test_hotspot_hit_requires_anchor(self):
        self.assert_rejected(lambda p: p['shots'][5]['events'][1].pop('anchor'), 'hotspot')

    def test_qte_requires_positive_window(self):
        self.assert_rejected(lambda p: p['shots'][6]['events'][0].__setitem__('window_sec', 0), 'window_sec')

    def test_settlement_requires_grade(self):
        def mutate(p):
            p['shots'][14]['events'][0]['data'].pop('grade')
        self.assert_rejected(mutate, 'grade')

    def test_ui_components_require_state_contract(self):
        def mutate(p):
            p['ui_registry']['timer']['states'] = []
        self.assert_rejected(mutate, 'states')

    def test_unknown_event_type_is_rejected(self):
        self.assert_rejected(lambda p: p['shots'][0]['events'][0].__setitem__('type', 'WHATEVER'), 'event type')


if __name__ == '__main__':
    unittest.main()

class QTESuccessContractTests(unittest.TestCase):
    def test_qte_requires_success_action(self):
        from scripts.validate_project import validate_project
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        for shot in project['shots']:
            for event in shot.get('events') or []:
                if event.get('type')=='QTE_OPEN':
                    event.pop('success_action_id',None)
        errors=validate_project(project)
        self.assertTrue(any('success_action_id' in e for e in errors),errors)
