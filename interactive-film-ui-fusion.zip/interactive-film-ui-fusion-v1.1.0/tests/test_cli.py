import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class CliTests(unittest.TestCase):
    def test_compile_overlay_runs_as_direct_script(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'cet.json'
            cp=subprocess.run([sys.executable,str(ROOT/'scripts/compile_overlay.py'),str(ROOT/'fixtures/workbuddy-v5/project.json'),'--out',str(out)],capture_output=True,text=True)
            self.assertEqual(cp.returncode,0,cp.stderr+cp.stdout)
            self.assertTrue(out.exists())

    def test_export_bridge_runs_as_direct_script(self):
        with tempfile.TemporaryDirectory() as td:
            cp=subprocess.run([sys.executable,str(ROOT/'scripts/export_runtime_bridge.py'),str(ROOT/'fixtures/workbuddy-v5/project.json'),td],capture_output=True,text=True)
            self.assertEqual(cp.returncode,0,cp.stderr+cp.stdout)
            self.assertTrue((Path(td)/'web-bridge.json').exists())

if __name__=='__main__': unittest.main()
