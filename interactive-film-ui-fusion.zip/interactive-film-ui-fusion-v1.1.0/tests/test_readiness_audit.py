import copy
import json
import unittest
from pathlib import Path

from scripts.audit_production_readiness import audit_project

ROOT = Path(__file__).resolve().parents[1]


class ReadinessAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))

    def test_workbuddy_is_previs_ready_but_not_final_video_verified(self):
        report = audit_project(self.project)
        self.assertTrue(report['ready_for_previs'])
        self.assertFalse(report['pixel_fusion_verified'])
        self.assertGreaterEqual(report['score'], 85)
        self.assertTrue(any('actual footage' in item.lower() for item in report['remaining_limits']))

    def test_missing_copy_downgrades_readiness(self):
        p = copy.deepcopy(self.project)
        p['shots'][5].pop('copy', None)
        report = audit_project(p)
        self.assertFalse(report['ready_for_previs'])
        self.assertTrue(any('copy' in item.lower() for item in report['p0']))


if __name__ == '__main__':
    unittest.main()

class EvidenceHardeningTests(unittest.TestCase):
    def setUp(self):
        self.project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))

    def test_legacy_true_booleans_cannot_fake_final_verification(self):
        from scripts.audit_production_readiness import audit_project
        p=json.loads(json.dumps(self.project))
        p['verification']={'pixel_fusion_verified':True,'runtime_interaction_verified':True,'audio_mix_verified':True}
        r=audit_project(p)
        self.assertFalse(r['pixel_fusion_verified'])
        self.assertFalse(r['runtime_interaction_verified'])
        self.assertFalse(r['audio_mix_verified'])
        self.assertFalse(r['ready_for_final_video'])

    def test_measured_evidence_can_certify_final_video_and_runtime(self):
        from scripts.audit_production_readiness import audit_project
        p=json.loads(json.dumps(self.project))
        p['verification']={
            'pixel_fusion':{'status':'PASS','actual_footage':True,'report_ref':'qa/pixel.json','max_anchor_error_px':2.1,'occlusion_cases':2,'contrast_checked':True},
            'runtime_interaction':{'status':'PASS','target':'chromium-mobile','report_ref':'qa/runtime.json','double_commit_blocked':True,'qte_timeout_once':True,'save_load_preserved':True,'p95_branch_latency_ms':180},
            'audio_mix':{'status':'PASS','rendered_output':True,'report_ref':'qa/audio.json','sync_checked':True}
        }
        r=audit_project(p)
        self.assertTrue(r['pixel_fusion_verified'])
        self.assertTrue(r['runtime_interaction_verified'])
        self.assertTrue(r['audio_mix_verified'])
        self.assertTrue(r['ready_for_final_video'])
        self.assertTrue(r['ready_for_interactive_runtime'])
