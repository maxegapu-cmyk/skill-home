import json
import unittest
from pathlib import Path
from scripts.compile_overlay import compile_overlay
from scripts.export_runtime_bridge import export_bridges

ROOT = Path(__file__).resolve().parents[1]

class RuntimeBridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        cls.overlay = compile_overlay(cls.project)

    def test_all_adapters_share_event_and_action_identity(self):
        bridges = export_bridges(self.project, self.overlay)
        base_ids = [e['id'] for e in self.overlay['events']]
        base_actions = [e['action_id'] for e in self.overlay['events']]
        self.assertEqual(set(bridges), {'web','remotion','unity'})
        for adapter in bridges.values():
            self.assertEqual(adapter['event_ids'], base_ids)
            self.assertEqual(adapter['canonical_actions'], base_actions)


    def test_adapters_receive_visual_ui_and_progress_contracts(self):
        bridges = export_bridges(self.project, self.overlay)
        for adapter in bridges.values():
            self.assertEqual(len(adapter['route']['nodes']), 8)
            self.assertEqual(adapter['collection']['total'], 8)
            self.assertIn('quest-card', adapter['ui_registry'])
            self.assertEqual(adapter['timer']['settlement_display'], '01:00')

    def test_web_bridge_declares_frame_clock(self):
        bridges = export_bridges(self.project, self.overlay)
        self.assertEqual(bridges['web']['clock'], 'video-frame-callback')

if __name__ == '__main__':
    unittest.main()
