import json
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from scripts.compile_overlay import compile_overlay
from scripts.generate_html_preview import generate_preview

ROOT = Path(__file__).resolve().parents[1]


class PreviewRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        cls.overlay = compile_overlay(cls.project)

    def test_generated_javascript_parses(self):
        node = shutil.which('node')
        if not node:
            self.skipTest('node not installed')
        with tempfile.TemporaryDirectory() as td:
            out = generate_preview(self.project, self.overlay, Path(td) / 'preview.html')
            text = out.read_text(encoding='utf-8')
            scripts = re.findall(r'<script>(.*?)</script>', text, flags=re.S)
            self.assertEqual(len(scripts), 1)
            js = Path(td) / 'preview.js'
            js.write_text(scripts[0], encoding='utf-8')
            cp = subprocess.run([node, '--check', str(js)], capture_output=True, text=True)
            self.assertEqual(cp.returncode, 0, cp.stderr + cp.stdout)

    def test_preview_contains_workbuddy_visual_layers(self):
        with tempfile.TemporaryDirectory() as td:
            out = generate_preview(self.project, self.overlay, Path(td) / 'preview.html')
            text = out.read_text(encoding='utf-8')
            for element_id in [
                'timer', 'questInfo', 'routeMap', 'collectionBar', 'eventLayer',
                'tipLayer', 'stampLayer', 'settlementLayer', 'brandLayer'
            ]:
                self.assertIn(f'id="{element_id}"', text)
            self.assertIn('一城揽三国', text)
            self.assertIn('田子坊', text)
            self.assertIn('文姬归汉', text)


    def test_preview_supports_real_video_frame_sync_contract(self):
        with tempfile.TemporaryDirectory() as td:
            out = generate_preview(self.project, self.overlay, Path(td) / 'preview.html')
            text = out.read_text(encoding='utf-8')
            self.assertIn('id="videoPlayer"', text)
            self.assertIn('requestVideoFrameCallback', text)
            self.assertIn('currentTime', text)


    def test_preview_state_sequence_matches_workbuddy_golden(self):
        try:
            from playwright.sync_api import sync_playwright
        except Exception:
            self.skipTest('playwright not installed')
        chromium = shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
        if not chromium:
            self.skipTest('chromium not installed')
        with tempfile.TemporaryDirectory() as td:
            out = generate_preview(self.project, self.overlay, Path(td) / 'preview.html')
            html = out.read_text(encoding='utf-8')
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, executable_path=chromium, args=['--no-sandbox'])
                page = browser.new_page(viewport={'width':1280,'height':900})
                page.set_content(html, wait_until='load')
                def seek(t):
                    page.locator('#timeline').evaluate(f'(el)=>{{el.value="{t}"; el.dispatchEvent(new Event("input",{{bubbles:true}}))}}')
                seek(9.3)
                self.assertIn('最优解', page.locator('#tipLayer').inner_text())
                seek(13.8)
                self.assertIn('盖章', page.locator('#stampLayer').inner_text())
                seek(25.2)
                self.assertIn('文姬归汉', page.locator('#tipLayer').inner_text())
                seek(53.4)
                self.assertFalse(page.locator('#timer').is_visible())
                self.assertTrue(page.locator('#realWorldLayer').is_visible())
                seek(57.5)
                self.assertIn('一城揽三国', page.locator('#brandLayer').inner_text())
                browser.close()

    def test_preview_executes_in_browser_when_playwright_available(self):
        try:
            from playwright.sync_api import sync_playwright
        except Exception:
            self.skipTest('playwright not installed')
        chromium = shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
        if not chromium:
            self.skipTest('chromium not installed')
        with tempfile.TemporaryDirectory() as td:
            out = generate_preview(self.project, self.overlay, Path(td) / 'preview.html')
            html = out.read_text(encoding='utf-8')
            errors = []
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, executable_path=chromium, args=['--no-sandbox'])
                page = browser.new_page(viewport={'width': 1280, 'height': 900})
                page.on('pageerror', lambda exc: errors.append(str(exc)))
                page.set_content(html, wait_until='load')
                page.locator('#timeline').evaluate('(el)=>{el.value="44.3"; el.dispatchEvent(new Event("input",{bubbles:true}))}')
                self.assertEqual(page.locator('#progress').inner_text(), '8/8')
                self.assertEqual(page.locator('#timer').inner_text(), '01:00')
                self.assertIn('S', page.locator('#settlementLayer').inner_text())
                browser.close()
            self.assertEqual(errors, [])


if __name__ == '__main__':
    unittest.main()
