import hashlib
import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_manifest_matches_payload_files(self):
        manifest_path=ROOT/'MANIFEST.json'
        self.assertTrue(manifest_path.exists(), 'MANIFEST.json must exist')
        data=json.loads(manifest_path.read_text(encoding='utf-8'))
        self.assertEqual(data['name'],'interactive-film-ui-fusion')
        self.assertEqual(data['version'],(ROOT/'VERSION').read_text(encoding='utf-8').strip())
        for item in data['files']:
            path=ROOT/item['path']
            self.assertTrue(path.exists(), item['path'])
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            self.assertEqual(digest,item['sha256'],item['path'])

if __name__=='__main__': unittest.main()
