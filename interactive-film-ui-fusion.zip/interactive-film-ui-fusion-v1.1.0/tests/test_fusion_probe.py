import tempfile
import unittest
from pathlib import Path

class FusionProbeTests(unittest.TestCase):
    def test_synthetic_moving_anchor_and_occlusion_probe(self):
        from scripts.run_fusion_probe import run_fusion_probe
        with tempfile.TemporaryDirectory() as td:
            report=run_fusion_probe(Path(td))
            self.assertTrue(report['video_decodes'])
            self.assertLessEqual(report['max_anchor_error_px'],1.5)
            self.assertTrue(report['unoccluded_overlay_visible'])
            self.assertTrue(report['foreground_occlusion_preserved'])
            self.assertTrue((Path(td)/'fusion-probe.mp4').exists())
            self.assertTrue((Path(td)/'occlusion-frame.png').exists())
            self.assertTrue((Path(td)/'track.json').exists())

if __name__=='__main__': unittest.main()
