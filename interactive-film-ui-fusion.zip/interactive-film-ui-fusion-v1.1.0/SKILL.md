---
name: interactive-film-ui-fusion
description: Use when an interactive film, FMV, AI video, branching video, playable short, H5 experience, or cinematic game needs HUD/UI assets, hotspots, QTE presentation, interaction feedback, video-attached overlays, motion states, spatial anchors, storyboard/previs review, or runtime UI handoff.
version: 1.1.0
---

# Interactive Film UI Fusion

## Overview
Compile the **visible interaction layer** of an interactive film without stealing story/state authority from the upstream system. The film stays primary; UI reveals agency, registers commitment, shows consequence, then clears.

When paired with `interactive-film-production` or another FMV system, approved Node IDs, Canonical Action IDs, state, branch graph and media remain upstream truth. This Skill owns Canonical Event Timeline (CET), UI components, video-space fusion, WorkBuddy-style storyboard/previs, stress simulation and renderer adapters.

## Load only what is needed
1. `references/architecture.md`
2. `references/canonical-event-timeline.md`
3. `references/ui-component-contract.md` for assets/UI states
4. `references/fusion-contract.md` for tracking/occlusion/perspective
5. `references/adapter-contracts.md` for Web/Remotion/Unity
6. `references/beginner-workflow.md` for first-run production
7. `references/qa-gates.md` before delivery

## Production path
1. If an upstream interactive-film manifest exists, normalize it with `python scripts/import_upstream_contract.py RUNTIME-MANIFEST.json upstream-contract.json`; strict pairing must preserve Node/Action IDs.
2. Validate before expensive generation: `python scripts/validate_project.py project.json`.
3. Build the full review bundle: `python scripts/build_project.py project.json build --clean`.
4. Review `storyboard.html` first, then `preview.html`, `readiness.json`, and `stress-report.json`. For preview-only regeneration: `python scripts/generate_html_preview.py project.json preview.html`.
5. Run `python scripts/stress_project.py project.json` before batch production. Commit-once, deterministic QTE timeout and save/load are mandatory.
6. For moving world UI, declare SCREEN/POINT/BOX/QUAD/OBJECT/CHARACTER/WORLD_REGION plus tracking, occlusion and perspective. Run `python scripts/run_fusion_probe.py fusion-probe` before trusting the real-footage path.
7. Export every target from the same CET. Web/Phaser, Remotion preview and Unity adapters render canon; they do not rewrite it.

## Core interaction grammar
`OPEN → AWAIT_INPUT → SELECTED → COMMITTED → REACT → STATE_PULSE → CLEAR → NEXT_HOOK`

State mutation happens exactly once. A QTE must have an explicit timeout action. Important consequences must also exist in the film/audio world, not only HUD.

## Quick reference
| Need | Contract |
|---|---|
| fixed timer/map/progress | SCREEN |
| moving clickable prop | POINT/BOX + keyframe/external track |
| planar sign/screen | QUAD + homography |
| person-attached label | CHARACTER + track |
| actor crosses overlay | foreground/object mask |
| client long-board | `storyboard.html` |
| frame-synced review | `preview.html` + video frame callback |
| real H5 | web bridge |
| effect video | Remotion bridge |
| existing desktop FMV | Unity bridge |

## Release boundary
A schema PASS is not a final-pixel PASS. `actual footage` must still prove tracking stability, occlusion, perspective, contrast, audio mix and target-runtime latency. PREVIS may be called ready when those are unverified; FINAL VIDEO or INTERACTIVE RUNTIME may not.

## Golden fixture
`fixtures/workbuddy-v5/project.json` contains 18 shots: HUD boot, route reveal, find-object hotspots, QTE, stamps, hidden achievement, 8/8 collection, S settlement, reward, real-world information return and brand outro.
