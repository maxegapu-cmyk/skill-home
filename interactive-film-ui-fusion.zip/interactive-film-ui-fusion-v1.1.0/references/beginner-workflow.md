# Beginner Workflow

The beginner path has one rule: **do not start by hand-authoring dozens of UI files. Start from one project contract and let the builder expose what is missing.**

## 1. One-command build

```bash
python scripts/build_project.py project.json build --clean
```

Open these in this order:

1. `storyboard.html` — the WorkBuddy-style long board. Confirm every shot, spoken line, sound cue, route/progress state and UI family.
2. `preview.html` — scrub the exact CET timing. Check task → action → response → state pulse → clear.
3. `readiness.json` — **P0 means stop**. Fix it before video/UI batch production. **P1 means production risk**; fix it or record an explicit acceptance.
4. `stress-report.json` — mutation misses must be zero; commit-once, timeout and save/load checks must pass.
5. `production-report.md` — handoff summary for director/editor/client.

## 2. Put in real video only after timing is approved

真实视频进入后，先做一条最难镜头，不要先批量做 18 条：选择一个会移动的交互物体，并让人物/前景从 UI 前经过。必须同时验证 tracking、occlusion、perspective、contrast。

- 固定 HUD：`SCREEN`
- 跟物体：`POINT/BOX/OBJECT` + keyframe/external track
- 平面透视：`QUAD` + homography
- 人物穿过 UI：foreground/object mask

Before batch compositing:

```bash
python scripts/run_fusion_probe.py fusion-probe
```

This proves the **fusion execution path**, not the quality of your real tracking model. Actual footage remains a required review gate.

## 3. Stress before export

```bash
python scripts/stress_project.py project.json --output stress-report.json
```

A production candidate must not rely on “looks okay in one preview”. Double click, QTE timeout, save/load, invalid hotspot geometry, event ordering, duplicate IDs and broken component states are deliberate negative cases.

## 4. Pair with the older interactive-film Skill

If story/branch/state already exists upstream, normalize it first and turn on strict pairing. The upstream Node IDs and Canonical Action IDs remain truth; this UI Fusion layer may render them but may not invent replacements.

```bash
python scripts/import_upstream_contract.py RUNTIME-MANIFEST.json upstream-contract.json
```

Put that object into `upstream_contract` and link shots with `upstream_node_id`. The validator rejects invented canonical actions in strict mode.

## 5. Delivery gates

- PREVIS: storyboard + timeline + assets + CET + stress may pass without final footage.
- FINAL VIDEO: requires actual-footage pixel fusion, readable contrast, real mask/track review and audio mix.
- INTERACTIVE RUNTIME: additionally requires target-device input, commit-once, timeout, prefetch, save/load and branch latency tests.

**Do not call PREVIS “final video”. Do not call a data bridge “playable runtime”.**
