# UI Component Contract

## Principle
A component is a stateful interaction asset, not a PNG. Define semantic role, states, bindings, motion, safe-zone preference, and accessibility text.

## Required state families
General interactive component:
`HIDDEN, INTRO, AWAITING_INPUT, SELECTED, COMMITTED, DISABLED, TIMEOUT, EXIT`

Quest card:
`HIDDEN, INTRO, ACTIVE, PROGRESS, SUCCESS, FAILED, EXIT`

Map node:
`LOCKED, AVAILABLE, ACTIVE, COMPLETED`

Stamp/reward marker:
`HIDDEN, PREPARE, IMPACT, SETTLE, UNLOCKED`

## Motion grammar
Default ranges are guidance, not canon:
- entry: ~180–320 ms
- selection acknowledgement: visible before branch transition
- commit: ~120–260 ms
- state pulse: ~350–800 ms
- clear: ~160–300 ms

Urgency animation belongs to urgent fiction. Idle HUD should be quiet.

## Layer order
Prioritize:
1. face / critical action / clue
2. current interaction readability
3. subtitles/dialogue
4. urgent timer
5. persistent state
6. decorative effects

Lower-priority layers move or disappear first.

## Safe composition
Every production node should reserve:
- persistent HUD zone
- temporary choice/subtitle zone
- critical subject/action zone
- hotspot objects

For 16:9, upper corners are good persistent-HUD lanes and lower ~22–30% is a typical temporary choice lane, but the actual shot wins over a fixed template.

## Asset format
Default portable representation:
- SVG geometry
- JSON state/binding/motion contract
- external raster/icon assets only when needed

High-end tools such as Rive may be used as adapters, but the project must still preserve a portable semantic contract.
