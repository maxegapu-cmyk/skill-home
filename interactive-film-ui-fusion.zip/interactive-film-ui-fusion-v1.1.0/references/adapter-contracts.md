# Adapter Contracts

Adapters render canon; they do not author it. Every adapter preserves CET event IDs, Canonical Action IDs, timing and state deltas.

## Web/H5
Prefer a browser game/runtime (e.g. Phaser) for real touch/hotspot/QTE input. Drive overlay timing from presented video frames (`requestVideoFrameCallback`) rather than loose wall-clock timers. A deterministic state machine owns legal commits.

## Remotion / linear effect video
Replay the same CET read-only to produce client previs/MP4. It may automate selected “perfect route” interactions but cannot change canonical meaning. This is how a real interactive design also produces the WorkBuddy-style linear speedrun presentation.

## Unity
The bridge is compatible with the prior interactive-film persistent-single-scene direction: prepared branch players/prefetch, runtime overlay, normalized static/moving hotspots, deterministic QTE timeout and save/load. UI Fusion does not duplicate graph/state inside scene scripts.

## Upstream pairing
Normalize older interactive-film manifests with `import_upstream_contract.py`. In strict mode, `upstream_node_id`, event `action_id`, QTE `success_action_id` and `timeout_action_id` must already exist upstream.

## Clock separation
Keep separate:
1. actual media frame/playback clock;
2. CET/overlay timing;
3. Canonical commit ledger.

A late render frame must never replay a state commit.
