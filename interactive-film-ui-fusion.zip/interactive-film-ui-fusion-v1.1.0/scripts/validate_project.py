#!/usr/bin/env python3
"""Validate an Interactive Film UI Fusion project using stdlib only."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

NORMALIZED_KEYS = {"x", "y", "w", "h"}
ANCHOR_TYPES = {"SCREEN", "POINT", "BOX", "QUAD", "OBJECT", "CHARACTER", "WORLD_REGION"}
TRACKING_MODES = {"static", "keyframe", "external-track"}
OCCLUSION_MODES = {"none", "foreground-mask", "object-mask"}
PERSPECTIVE_MODES = {"none", "affine", "homography"}
KNOWN_EVENT_TYPES = {
    "GAME_START", "HUD_ENTER", "HUD_CLEAR", "BRAND_OUTRO",
    "QUEST_OPEN", "QUEST_PROGRESS", "QUEST_COMPLETE", "QUEST_FAIL",
    "HOTSPOT_OPEN", "HOTSPOT_HIT", "CHOICE_OPEN", "ACTION_COMMIT",
    "QTE_OPEN", "QTE_TIMEOUT", "RESPONSE_PULSE", "STAMP_IMPACT",
    "ACHIEVEMENT_UNLOCK", "MAP_UNLOCK", "COLLECTION_UPDATE",
    "COLLECTION_COMPLETE", "SETTLEMENT_OPEN", "REWARD_REVEAL",
    "ROUTE_REVEAL", "TIP_OPEN",
}
HOTSPOT_EVENT_TYPES = {"HOTSPOT_OPEN", "HOTSPOT_HIT"}


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _coord_errors(prefix: str, obj: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for key in NORMALIZED_KEYS:
        if key in obj:
            value = obj[key]
            if not _is_number(value) or not 0 <= float(value) <= 1:
                errors.append(f"{prefix}: coordinate {key}={value!r} outside normalized [0,1]")
    return errors


def _validate_point(prefix: str, obj: dict[str, Any]) -> list[str]:
    errors = _coord_errors(prefix, obj)
    if not _is_number(obj.get("x")) or not _is_number(obj.get("y")):
        errors.append(f"{prefix}: requires x/y coordinates")
    return errors


def _validate_box(prefix: str, obj: dict[str, Any]) -> list[str]:
    errors = _coord_errors(prefix, obj)
    for key in ("x", "y", "w", "h"):
        if not _is_number(obj.get(key)):
            errors.append(f"{prefix}: BOX requires x/y/w/h")
            break
    if _is_number(obj.get("w")) and float(obj["w"]) <= 0:
        errors.append(f"{prefix}: BOX width must be > 0")
    if _is_number(obj.get("h")) and float(obj["h"]) <= 0:
        errors.append(f"{prefix}: BOX height must be > 0")
    return errors


def _validate_quad(prefix: str, obj: dict[str, Any]) -> list[str]:
    points = obj.get("points")
    errors: list[str] = []
    if not isinstance(points, list) or len(points) != 4:
        return [f"{prefix}: QUAD requires exactly four points"]
    for idx, point in enumerate(points):
        if not isinstance(point, dict):
            errors.append(f"{prefix}: QUAD point {idx} must be an object")
        else:
            errors.extend(_validate_point(f"{prefix} point {idx}", point))
    return errors


def _validate_anchor(anchor_id: str, anchor: Any, duration: float | None) -> list[str]:
    prefix = f"anchor {anchor_id}"
    if not isinstance(anchor, dict):
        return [f"{prefix}: must be an object"]
    errors: list[str] = []
    anchor_type = anchor.get("type")
    if anchor_type not in ANCHOR_TYPES:
        errors.append(f"{prefix}: invalid anchor type {anchor_type!r}")
    tracking = anchor.get("tracking", "static")
    if tracking not in TRACKING_MODES:
        errors.append(f"{prefix}: invalid tracking mode {tracking!r}")
    occlusion = anchor.get("occlusion", "none")
    if occlusion not in OCCLUSION_MODES:
        errors.append(f"{prefix}: invalid occlusion mode {occlusion!r}")
    perspective = anchor.get("perspective", "none")
    if perspective not in PERSPECTIVE_MODES:
        errors.append(f"{prefix}: invalid perspective mode {perspective!r}")

    if tracking == "static":
        if anchor_type in {"SCREEN", "POINT"}:
            errors.extend(_validate_point(prefix, anchor))
        elif anchor_type in {"BOX", "OBJECT", "CHARACTER", "WORLD_REGION"}:
            # semantic regions may be box-shaped when static
            if any(k in anchor for k in ("x", "y", "w", "h")):
                errors.extend(_validate_box(prefix, anchor))
        elif anchor_type == "QUAD":
            errors.extend(_validate_quad(prefix, anchor))
    elif tracking == "keyframe":
        keyframes = anchor.get("keyframes")
        if not isinstance(keyframes, list) or not keyframes:
            errors.append(f"{prefix}: moving/keyframe anchor missing keyframes")
        else:
            last_t: float | None = None
            for idx, keyframe in enumerate(keyframes):
                kp = f"{prefix} keyframe {idx}"
                if not isinstance(keyframe, dict):
                    errors.append(f"{kp}: must be an object")
                    continue
                t = keyframe.get("t")
                if not _is_number(t):
                    errors.append(f"{kp}: keyframe time must be numeric")
                else:
                    tf = float(t)
                    if tf < 0 or (duration is not None and tf > duration):
                        errors.append(f"{kp}: keyframe time {tf} outside project duration")
                    if last_t is not None and tf <= last_t:
                        errors.append(f"{kp}: keyframe time must be strictly increasing")
                    last_t = tf
                if anchor_type in {"SCREEN", "POINT", "OBJECT", "CHARACTER", "WORLD_REGION"}:
                    errors.extend(_validate_point(kp, keyframe))
                elif anchor_type == "BOX":
                    errors.extend(_validate_box(kp, keyframe))
                elif anchor_type == "QUAD":
                    errors.extend(_validate_quad(kp, keyframe))
    elif tracking == "external-track":
        if not anchor.get("track_ref"):
            errors.append(f"{prefix}: external-track anchor missing track_ref")
    return errors


def validate_project(project: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if not isinstance(project, dict):
        return ["project: root must be an object"]
    if not project.get("project_id"):
        errors.append("project: missing project_id")

    frame = project.get("frame") or {}
    if not isinstance(frame.get("width"), int) or frame.get("width", 0) <= 0:
        errors.append("project: frame.width must be a positive integer")
    if not isinstance(frame.get("height"), int) or frame.get("height", 0) <= 0:
        errors.append("project: frame.height must be a positive integer")
    if not _is_number(frame.get("fps")) or frame.get("fps", 0) <= 0:
        errors.append("project: frame.fps must be positive")

    shots = project.get("shots") or []
    if not isinstance(shots, list) or not shots:
        errors.append("project: shots must be a non-empty list")
        return errors
    numeric_ends = [s.get("end") for s in shots if isinstance(s, dict) and _is_number(s.get("end"))]
    duration = max(map(float, numeric_ends), default=None)

    ui_registry = project.get("ui_registry") or {}
    if not isinstance(ui_registry, dict) or not ui_registry:
        errors.append("project: ui_registry must be a non-empty object")
        ui_registry = {}
    for component_id, component in ui_registry.items():
        if not isinstance(component, dict):
            errors.append(f"component {component_id}: must be an object")
            continue
        if not component.get("role"):
            errors.append(f"component {component_id}: missing role")
        states = component.get("states")
        if not isinstance(states, list) or not states or not all(isinstance(x, str) and x for x in states):
            errors.append(f"component {component_id}: states must be a non-empty string list")

    anchors = project.get("anchors") or {}
    if not isinstance(anchors, dict):
        errors.append("project: anchors must be an object")
        anchors = {}
    for anchor_id, anchor in anchors.items():
        errors.extend(_validate_anchor(anchor_id, anchor, duration))

    upstream = project.get("upstream_contract") or {}
    upstream_node_ids = set(upstream.get("node_ids") or []) if isinstance(upstream, dict) else set()
    upstream_action_ids = set(upstream.get("action_ids") or []) if isinstance(upstream, dict) else set()
    strict_upstream_actions = bool(isinstance(upstream, dict) and upstream.get("strict_actions"))

    event_ids: set[str] = set()
    shot_ids: set[str] = set()
    commits: set[tuple[str, str]] = set()
    progress_current = 0
    progress_total: int | None = None
    collection_complete = False

    previous_shot_end = -1.0
    for shot_index, shot in enumerate(shots):
        if not isinstance(shot, dict):
            errors.append(f"shot index {shot_index}: must be an object")
            continue
        shot_id = shot.get("id", "<unknown>")
        if not shot.get("id"):
            errors.append(f"shot index {shot_index}: missing id")
        elif shot_id in shot_ids:
            errors.append(f"shot {shot_id}: duplicate shot id")
        shot_ids.add(str(shot_id))

        upstream_node_id = shot.get("upstream_node_id")
        if upstream_node_id and upstream_node_ids and upstream_node_id not in upstream_node_ids:
            errors.append(f"shot {shot_id}: upstream node {upstream_node_id!r} missing from upstream contract")

        start = shot.get("start")
        end = shot.get("end")
        if not _is_number(start) or not _is_number(end):
            errors.append(f"shot {shot_id}: start/end must be numeric")
            continue
        start_f, end_f = float(start), float(end)
        if end_f <= start_f:
            errors.append(f"shot {shot_id}: end must be after start")
        if start_f < previous_shot_end:
            errors.append(f"shot {shot_id}: overlaps or regresses before previous shot end")
        previous_shot_end = max(previous_shot_end, end_f)

        events = shot.get("events") or []
        if not isinstance(events, list):
            errors.append(f"shot {shot_id}: events must be a list")
            continue
        last_event_at: float | None = None
        for event_index, event in enumerate(events):
            if not isinstance(event, dict):
                errors.append(f"shot {shot_id}: event {event_index} must be an object")
                continue
            event_id = event.get("id")
            if not event_id:
                errors.append(f"shot {shot_id}: event missing id")
                continue
            if event_id in event_ids:
                errors.append(f"event {event_id}: duplicate event id")
            event_ids.add(str(event_id))

            event_type = event.get("type")
            if event_type not in KNOWN_EVENT_TYPES:
                errors.append(f"event {event_id}: unknown event type {event_type!r}")

            at = event.get("at")
            if not _is_number(at) or not start_f <= float(at) <= end_f:
                errors.append(f"event {event_id}: at={at!r} outside shot window {start}-{end}")
            elif last_event_at is not None and float(at) < last_event_at:
                errors.append(f"shot {shot_id}: event order must be nondecreasing by at")
            if _is_number(at):
                last_event_at = float(at)

            duration_sec = event.get("duration_sec")
            if duration_sec is not None and (not _is_number(duration_sec) or float(duration_sec) <= 0):
                errors.append(f"event {event_id}: duration_sec must be positive")
            if _is_number(at) and _is_number(duration_sec) and float(at) + float(duration_sec) > end_f + 1e-9:
                errors.append(f"event {event_id}: duration exceeds shot window")

            component = event.get("component")
            if not component:
                errors.append(f"event {event_id}: missing component")
            elif component not in ui_registry:
                errors.append(f"event {event_id}: component {component!r} missing from ui_registry")

            anchor_id = event.get("anchor")
            if anchor_id and anchor_id not in anchors:
                errors.append(f"event {event_id}: anchor {anchor_id!r} missing from anchors")
            if event_type in HOTSPOT_EVENT_TYPES and not anchor_id:
                errors.append(f"event {event_id}: hotspot event requires anchor")

            action_id = event.get("action_id")
            if not isinstance(action_id, str) or not action_id.strip():
                errors.append(f"event {event_id}: action_id must be a non-empty canonical id")
            if event.get("state_write") and not action_id:
                errors.append(f"event {event_id}: state mutation requires canonical action_id")
            if strict_upstream_actions and action_id and action_id not in upstream_action_ids:
                errors.append(f"event {event_id}: upstream canonical action {action_id!r} not declared by upstream contract")
            timeout_action_id = event.get("timeout_action_id")
            if strict_upstream_actions and timeout_action_id and timeout_action_id not in upstream_action_ids:
                errors.append(f"event {event_id}: upstream timeout action {timeout_action_id!r} not declared by upstream contract")

            if event.get("commit_once"):
                instance = event.get("interaction_instance") or event_id
                if action_id:
                    key = (str(instance), str(action_id))
                    if key in commits:
                        errors.append(f"event {event_id}: duplicate commit for interaction {instance!r} action {action_id!r}")
                    commits.add(key)

            if event_type == "QTE_OPEN":
                if not event.get("success_action_id"):
                    errors.append(f"event {event_id}: QTE requires canonical success_action_id")
                if not event.get("timeout_action_id"):
                    errors.append(f"event {event_id}: QTE requires deterministic timeout_action_id")
                if strict_upstream_actions and event.get("success_action_id") and event.get("success_action_id") not in upstream_action_ids:
                    errors.append(f"event {event_id}: upstream QTE success action {event.get('success_action_id')!r} not declared by upstream contract")
                window = event.get("window_sec")
                if not _is_number(window) or float(window) <= 0:
                    errors.append(f"event {event_id}: QTE requires positive window_sec")

            if event_type == "SETTLEMENT_OPEN":
                data = event.get("data") or {}
                if not isinstance(data, dict) or not data.get("grade"):
                    errors.append(f"event {event_id}: settlement requires grade data")

            progress = event.get("progress")
            if progress:
                current = progress.get("current")
                total = progress.get("total")
                if not isinstance(current, int) or not isinstance(total, int) or total <= 0 or current < 0:
                    errors.append(f"event {event_id}: progress current/total must be valid nonnegative integers")
                else:
                    if progress_total is not None and total != progress_total:
                        errors.append(f"event {event_id}: progress total changed from {progress_total} to {total}")
                    progress_total = total
                    if current < progress_current:
                        errors.append(f"event {event_id}: progress regression {progress_current}->{current}")
                    if current > total:
                        errors.append(f"event {event_id}: progress current {current} exceeds total {total}")
                    progress_current = max(progress_current, current)

            if event_type == "COLLECTION_COMPLETE":
                if progress_total is not None and progress_current < progress_total:
                    errors.append(f"event {event_id}: collection completed before progress reached {progress_total}")
                collection_complete = True

            if event_type == "SETTLEMENT_OPEN":
                required = (event.get("requires") or {}).get("collection")
                if required is not None and progress_current < required:
                    errors.append(f"event {event_id}: settlement requires collection {required}, current {progress_current}")
                if required and not collection_complete:
                    errors.append(f"event {event_id}: settlement opened before COLLECTION_COMPLETE")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    args = parser.parse_args()
    data = json.loads(args.project.read_text(encoding="utf-8"))
    errors = validate_project(data)
    if errors:
        for error in errors:
            print(f"FAIL: {error}")
        return 1
    print("PASS: project valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
