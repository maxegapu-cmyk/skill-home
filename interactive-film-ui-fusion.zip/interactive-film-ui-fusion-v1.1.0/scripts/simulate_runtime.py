#!/usr/bin/env python3
"""Deterministic contract-level runtime simulator for CET actions/state/QTEs.

This is intentionally engine-neutral. It proves commit-once, canonical state writes,
progress, deterministic timeout, and save/load behavior before a Phaser/Unity adapter
is asked to render the experience.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import sys
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.compile_overlay import compile_overlay
from scripts.validate_project import validate_project


@dataclass
class PendingQTE:
    event_id: str
    open_action_id: str
    timeout_action_id: str
    success_action_id: str | None
    deadline: float
    resolved: bool = False


class RuntimeSimulator:
    def __init__(self, project: dict[str, Any]):
        errors = validate_project(project)
        if errors:
            raise ValueError("project validation failed: " + " | ".join(errors))
        self.project_id = project["project_id"]
        total = int((project.get("collection") or {}).get("total", 0))
        self.state: dict[str, Any] = {}
        self.progress = {"current": 0, "total": total}
        self._commits: dict[str, int] = {}
        self._pending_qtes: dict[str, PendingQTE] = {}
        self.duplicate_commits = 0

    def commit_count(self, action_id: str) -> int:
        return self._commits.get(action_id, 0)

    def _commit_action(self, action_id: str) -> bool:
        if action_id in self._commits:
            self.duplicate_commits += 1
            return False
        self._commits[action_id] = 1
        return True

    def open_qte(self, event: dict[str, Any]) -> dict[str, Any]:
        action_id = event["action_id"]
        committed = self._commit_action(action_id)
        qte_id = event.get("interaction_instance") or event["id"]
        if committed:
            self._pending_qtes[qte_id] = PendingQTE(
                event_id=event["id"],
                open_action_id=action_id,
                timeout_action_id=event["timeout_action_id"],
                success_action_id=event.get("success_action_id"),
                deadline=float(event["at"]) + float(event["window_sec"]),
            )
        return {"committed": committed, "action_id": action_id, "qte_id": qte_id}

    def resolve_qte(self, qte_id: str, success_action_id: str | None = None) -> dict[str, Any]:
        qte = self._pending_qtes.get(qte_id)
        action = success_action_id or (qte.success_action_id if qte else None)
        if not qte or qte.resolved or not action:
            return {"committed": False, "action_id": action}
        committed = self._commit_action(action)
        if committed:
            qte.resolved = True
        return {"committed": committed, "action_id": action}

    def tick(self, now: float) -> dict[str, Any]:
        committed_actions: list[str] = []
        for qte in self._pending_qtes.values():
            if qte.resolved or now < qte.deadline:
                continue
            if self._commit_action(qte.timeout_action_id):
                committed_actions.append(qte.timeout_action_id)
            qte.resolved = True
        return {"committed_actions": committed_actions}

    def commit_event(self, event: dict[str, Any]) -> dict[str, Any]:
        if event.get("type") == "QTE_OPEN":
            return self.open_qte(event)
        action_id = event.get("action_id")
        if not action_id:
            raise ValueError(f"event {event.get('id')} has no action_id")
        committed = self._commit_action(action_id)
        if not committed:
            return {"committed": False, "action_id": action_id}
        for key, value in (event.get("state_write") or {}).items():
            self.state[key] = value
        if event.get("progress"):
            self.progress = {
                "current": int(event["progress"]["current"]),
                "total": int(event["progress"]["total"]),
            }
        return {"committed": True, "action_id": action_id}

    def snapshot(self) -> dict[str, Any]:
        return {
            "schema": "runtime-snapshot-1.0",
            "project_id": self.project_id,
            "state": self.state,
            "progress": self.progress,
            "commits": sorted(self._commits),
            "pending_qtes": {
                key: {
                    "event_id": q.event_id,
                    "open_action_id": q.open_action_id,
                    "timeout_action_id": q.timeout_action_id,
                    "success_action_id": q.success_action_id,
                    "deadline": q.deadline,
                    "resolved": q.resolved,
                }
                for key, q in self._pending_qtes.items()
            },
        }

    @classmethod
    def from_snapshot(cls, project: dict[str, Any], payload: dict[str, Any]) -> "RuntimeSimulator":
        sim = cls(project)
        if payload.get("project_id") != sim.project_id:
            raise ValueError("snapshot project_id mismatch")
        sim.state = dict(payload.get("state") or {})
        sim.progress = dict(payload.get("progress") or sim.progress)
        sim._commits = {action: 1 for action in payload.get("commits") or []}
        for key, item in (payload.get("pending_qtes") or {}).items():
            sim._pending_qtes[key] = PendingQTE(
                event_id=item["event_id"], open_action_id=item["open_action_id"],
                timeout_action_id=item["timeout_action_id"], success_action_id=item.get("success_action_id"), deadline=float(item["deadline"]),
                resolved=bool(item.get("resolved", False)),
            )
        return sim

    def replay(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        for event in events:
            self.commit_event(event)
        return {
            "project_id": self.project_id,
            "state": dict(self.state),
            "progress": dict(self.progress),
            "committed_actions": sorted(self._commits),
            "duplicate_commits": self.duplicate_commits,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("--snapshot", type=Path)
    args = parser.parse_args()
    project = json.loads(args.project.read_text(encoding="utf-8"))
    overlay = compile_overlay(project)
    sim = RuntimeSimulator(project)
    report = sim.replay(overlay["events"])
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.snapshot:
        args.snapshot.write_text(json.dumps(sim.snapshot(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(text, end="")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
