#!/usr/bin/env python3
"""Adversarial production stress suite for UI Fusion projects.

Runs structural mutations plus runtime idempotency/timeout/save-load checks. The
suite is deterministic and dependency-free so beginners can run it before any
expensive video generation.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any, Callable

import sys
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.compile_overlay import compile_overlay
from scripts.simulate_runtime import RuntimeSimulator
from scripts.validate_project import validate_project

Mutation = Callable[[dict[str, Any]], None]


def _event(project: dict[str, Any], event_id: str) -> dict[str, Any]:
    for shot in project["shots"]:
        for event in shot.get("events") or []:
            if event.get("id") == event_id:
                return event
    raise KeyError(event_id)


def _mutations() -> list[tuple[str, Mutation]]:
    def duplicate_shot(p): p["shots"][1]["id"] = p["shots"][0]["id"]
    def unsorted_event(p): p["shots"][5]["events"][1]["at"] = 14.8; p["shots"][5]["events"][2]["at"] = 12.0
    def reverse_track(p): p["anchors"]["sword-1"]["keyframes"][1]["t"] = p["anchors"]["sword-1"]["keyframes"][0]["t"] - .1
    def point_missing_xy(p): p["anchors"]["screen-top"].pop("x", None)
    def invalid_anchor_type(p): p["anchors"]["screen-top"]["type"] = "MAGIC"
    def invalid_tracking(p): p["anchors"]["screen-top"]["tracking"] = "telepathy"
    def invalid_occlusion(p): p["anchors"]["screen-top"]["occlusion"] = "maybe"
    def unknown_event(p): _event(p,"e001")["type"] = "UNKNOWN_UI_MAGIC"
    def hotspot_no_anchor(p): _event(p,"e009").pop("anchor", None)
    def qte_zero_window(p): _event(p,"e015")["window_sec"] = 0
    def qte_no_success(p): _event(p,"e015").pop("success_action_id", None)
    def ui_no_states(p): p["ui_registry"]["quest-card"]["states"] = []
    def empty_action(p): _event(p,"e009")["action_id"] = ""
    def negative_progress(p): _event(p,"e014")["progress"]["current"] = -1
    def settlement_no_grade(p): _event(p,"e038")["data"].pop("grade",None)
    def missing_component(p): _event(p,"e004")["component"] = "missing-ui"
    return [
        ("duplicate-shot-id", duplicate_shot),
        ("unsorted-events", unsorted_event),
        ("non-monotonic-track", reverse_track),
        ("point-missing-coordinate", point_missing_xy),
        ("invalid-anchor-type", invalid_anchor_type),
        ("invalid-tracking", invalid_tracking),
        ("invalid-occlusion", invalid_occlusion),
        ("unknown-event", unknown_event),
        ("hotspot-without-anchor", hotspot_no_anchor),
        ("qte-zero-window", qte_zero_window),
        ("qte-without-success-action", qte_no_success),
        ("ui-without-states", ui_no_states),
        ("empty-canonical-action", empty_action),
        ("negative-progress", negative_progress),
        ("settlement-without-grade", settlement_no_grade),
        ("missing-ui-component", missing_component),
    ]


def stress_project(project: dict[str, Any]) -> dict[str, Any]:
    golden_errors = validate_project(project)
    missed: list[str] = []
    details: dict[str, list[str]] = {}
    for name, mutate in _mutations():
        bad = copy.deepcopy(project)
        mutate(bad)
        errors = validate_project(bad)
        details[name] = errors
        if not errors:
            missed.append(name)

    overlay = compile_overlay(project)
    sim = RuntimeSimulator(project)
    e009 = next(e for e in overlay["events"] if e["id"] == "e009")
    first = sim.commit_event(e009)
    second = sim.commit_event(e009)
    double_commit_blocked = bool(first["committed"] and not second["committed"] and sim.commit_count(e009["action_id"]) == 1)

    qte_sim = RuntimeSimulator(project)
    qte = next(e for e in overlay["events"] if e["id"] == "e015")
    qte_sim.open_qte(qte)
    first_timeout = qte_sim.tick(qte["at"] + qte["window_sec"] + .001)["committed_actions"]
    second_timeout = qte_sim.tick(qte["at"] + qte["window_sec"] + 1)["committed_actions"]
    qte_timeout_once = qte["timeout_action_id"] in first_timeout and not second_timeout and qte_sim.commit_count(qte["timeout_action_id"]) == 1

    snap_sim = RuntimeSimulator(project)
    for event_id in ("e009", "e010", "e011", "e014"):
        snap_sim.commit_event(next(e for e in overlay["events"] if e["id"] == event_id))
    snap = snap_sim.snapshot()
    restored = RuntimeSimulator.from_snapshot(project, snap)
    save_load_preserved = restored.state == snap_sim.state and restored.progress == snap_sim.progress and restored.snapshot()["commits"] == snap["commits"]

    total = len(_mutations())
    return {
        "stress_schema": "1.0",
        "project_id": project.get("project_id"),
        "golden_valid": not golden_errors,
        "golden_errors": golden_errors,
        "mutation_cases": total,
        "mutation_missed": missed,
        "mutation_detection_rate": (total - len(missed)) / total if total else 1.0,
        "mutation_errors": details,
        "runtime": {
            "double_commit_blocked": double_commit_blocked,
            "qte_timeout_once": qte_timeout_once,
            "save_load_preserved": save_load_preserved,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    project = json.loads(args.project.read_text(encoding="utf-8"))
    report = stress_project(project)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    ok = report["golden_valid"] and not report["mutation_missed"] and all(report["runtime"].values())
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
