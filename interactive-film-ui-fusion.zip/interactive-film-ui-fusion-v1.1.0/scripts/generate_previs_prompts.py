#!/usr/bin/env python3
"""Generate clean AI previs bottom-plate prompts from shot contracts.

The prompts deliberately exclude runtime HUD/text so editable UI remains a separate
post layer, matching the WorkBuddy production model.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

MODE_HINTS={
    'street-title':'上海街景建立镜头，真实城市纪实感，稳定广角，留出中央标题安全区',
    'hud-load':'真实上海街道或建筑环境，平稳中广景，四角与顶部留出 HUD 安全区',
    'task-card':'真实地点环境建立镜头，人物动作克制，中央/中下部留任务卡净空',
    'reward-card':'真实场景，画面节奏短促，中央留奖励卡净空',
    'route-map':'真实上海城市/江岸环境，大空间建立镜头，构图为路线图浮层留足净空',
    'hand-hotspot':'真人手部特写，手与目标物件同一清晰焦平面，物件周围留可点击标记空间',
    'backlit-qte':'逆光剪影，动作轮廓清楚，手臂与道具动作可读，人物脸无需正面清晰',
    'foreground-action':'前景遮挡构图，从道具/枝叶缝隙观察动作，焦点锁在手势',
    'quiet-achievement':'全片静态呼吸镜头，半脸/手部细节，柔和侧光，动作安静',
    'wide-cool':'大广角，人小景大，冷青环境色，人物退至画面一侧',
    'low-angle-warm':'低角度仰拍，暖橙环境，前景物件交错掠过，动作有力量但不夸张',
    'reflection':'玻璃反射构图，不直接正拍人物，以反射与流动路人建立空间层次',
    'crowd-arrival':'真实人潮与步行推进，城市风感，终点空间逐渐展开',
    'stamp-merge':'终点群像/卷轴空间，构图稳定，为八印合一后期特效留中央净空',
    'settlement':'真实终点场景低运动量，中央大面积净空用于结算面板',
    'reward-list':'真实场景或结算背景，右侧/中央留奖励清单净空',
    'real-world-grid':'真实服务中心门头/现场证据镜头，客观、清楚、无游戏特效',
    'brand-outro':'无需真人底图；使用纯净深色落版背景或品牌指定底色',
}


def generate_previs_prompts(project: dict[str,Any]) -> str:
    lines=[
        f"# {project.get('title',project['project_id'])} — AI Previs Bottom-Plate Prompt Pack",
        "",
        "统一规则：真实上海/真实活动现场优先，现代真人与真实材质，摄影机逻辑明确；AI 图只作为内部 previs。**不要把 HUD、文字、按钮、地图、印章直接生成进底图**，这些全部由可编辑矢量/运行时 UI 后合成。",
        "",
    ]
    for shot in project.get('shots') or []:
        copy=shot.get('copy') or {}; visual=shot.get('visual') or {}; mode=visual.get('mode','')
        hint=visual.get('prompt_hint') or MODE_HINTS.get(mode,'真实上海环境，电影感纪实摄影，保留 UI 安全区')
        headline=copy.get('headline',shot['id']); detail=copy.get('detail','')
        lines += [
            f"## {shot['id']} · {headline}",
            f"时间：{shot['start']:.1f}–{shot['end']:.1f}s",
            f"底图任务：{detail}",
            f"镜头：{hint}",
            "画面要求：写实真人摄影预演，环境可信，人物动作可拍、可复现；保留关键人物/动作阅读区，避免在预定 HUD 区域堆高对比细节。",
            "负面约束：无烧录文字、无游戏 HUD、无浮空按钮、无自动生成地图/印章/进度条、无多余品牌标识、无与任务无关的奇幻 VFX。",
            "",
        ]
    return "\n".join(lines)


def main()->int:
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('project',type=Path); ap.add_argument('output',type=Path); a=ap.parse_args()
    p=json.loads(a.project.read_text(encoding='utf-8')); a.output.write_text(generate_previs_prompts(p),encoding='utf-8'); print(a.output); return 0
if __name__=='__main__': raise SystemExit(main())
