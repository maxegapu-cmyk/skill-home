#!/usr/bin/env python3
"""Render a deterministic moving-anchor + foreground-occlusion fusion probe.

The probe is a release diagnostic, not a beauty demo. It proves that an external
normalized track can drive a world-attached overlay and that a foreground mask
can correctly occlude that overlay before the same contract is used on real
footage.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import cv2
import numpy as np

W, H, FPS, FRAMES = 640, 360, 30, 90
GOLD = np.array([46, 171, 226], dtype=np.uint8)  # BGR
OCCLUDER = np.array([48, 50, 58], dtype=np.uint8)


def _target_xy(i: int) -> tuple[float, float]:
    # Cross the foreground occluder near the middle of the sequence.
    x = 110 + (420 * i / (FRAMES - 1))
    y = 180 + 18 * math.sin(i / 13)
    return x, y


def _draw_ring_layer(cx: int, cy: int) -> np.ndarray:
    layer = np.zeros((H, W, 4), dtype=np.uint8)
    cv2.circle(layer, (cx, cy), 26, tuple(int(x) for x in GOLD) + (255,), 4, cv2.LINE_AA)
    cv2.circle(layer, (cx, cy), 5, tuple(int(x) for x in GOLD) + (220,), -1, cv2.LINE_AA)
    return layer


def _composite(frame: np.ndarray, layer: np.ndarray, foreground_mask: np.ndarray) -> np.ndarray:
    alpha = layer[:, :, 3].astype(np.float32) / 255.0
    alpha *= (1.0 - foreground_mask.astype(np.float32) / 255.0)
    rgb = layer[:, :, :3].astype(np.float32)
    out = frame.astype(np.float32)
    a3 = alpha[:, :, None]
    out = rgb * a3 + out * (1.0 - a3)
    return np.clip(out, 0, 255).astype(np.uint8)


def _detect_gold_center(frame: np.ndarray) -> tuple[float, float] | None:
    diff = np.abs(frame.astype(np.int16) - GOLD.astype(np.int16))
    mask = np.all(diff <= np.array([24, 24, 24], dtype=np.int16), axis=2)
    ys, xs = np.where(mask)
    if len(xs) < 5:
        return None
    return float(xs.mean()), float(ys.mean())


def run_fusion_probe(output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    out_video = output_dir / "fusion-probe.mp4"
    out_track = output_dir / "track.json"
    out_frame = output_dir / "occlusion-frame.png"

    track = []
    writer = cv2.VideoWriter(str(out_video), cv2.VideoWriter_fourcc(*"mp4v"), FPS, (W, H))
    if not writer.isOpened():
        raise RuntimeError("OpenCV could not open MP4 writer")

    sample_errors: list[float] = []
    unoccluded_visible = False
    foreground_preserved = False
    occlusion_saved = False

    for i in range(FRAMES):
        t = i / FPS
        cx_f, cy_f = _target_xy(i)
        cx, cy = round(cx_f), round(cy_f)
        track.append({"t": round(t, 6), "x": cx_f / W, "y": cy_f / H})

        # Film base: dark cinematic gradient + a cyan tracked object.
        frame = np.zeros((H, W, 3), dtype=np.uint8)
        frame[:] = (35, 47, 42)
        frame[:, :, 1] += np.linspace(0, 24, W, dtype=np.uint8)[None, :]
        cv2.circle(frame, (cx, cy), 13, (172, 135, 44), -1, cv2.LINE_AA)

        # Foreground actor/object crossing: present only around center passage.
        foreground_mask = np.zeros((H, W), dtype=np.uint8)
        if 36 <= i <= 58:
            x0, x1, y0, y1 = 286, 356, 112, 252
            foreground_mask[y0:y1, x0:x1] = 255
            frame[y0:y1, x0:x1] = OCCLUDER

        layer = _draw_ring_layer(cx, cy)
        composited = _composite(frame, layer, foreground_mask)

        # Measure attachment on unoccluded sample frames.
        if i in (8, 20, 72, 84):
            detected = _detect_gold_center(composited)
            if detected is not None:
                sample_errors.append(math.dist(detected, (cx_f, cy_f)))
            probe_y = max(0, cy - 26)
            px = composited[probe_y, cx]
            if np.linalg.norm(px.astype(np.int16) - GOLD.astype(np.int16)) < 60:
                unoccluded_visible = True

        # At frame ~50 the target is behind the foreground rectangle. The ring
        # top sample must remain foreground-colored rather than gold.
        if i == 50:
            probe_y = max(0, cy - 26)
            px = composited[probe_y, cx]
            foreground_preserved = np.linalg.norm(px.astype(np.int16) - OCCLUDER.astype(np.int16)) < 20
            cv2.imwrite(str(out_frame), composited)
            occlusion_saved = True

        writer.write(composited)

    writer.release()
    out_track.write_text(json.dumps({"schema": "normalized-point-track-1.0", "width": W, "height": H, "fps": FPS, "keyframes": track}, indent=2) + "\n", encoding="utf-8")

    cap = cv2.VideoCapture(str(out_video))
    decoded = 0
    while True:
        ok, _ = cap.read()
        if not ok:
            break
        decoded += 1
    cap.release()

    return {
        "probe_schema": "1.0",
        "video_decodes": decoded >= FRAMES - 2,
        "decoded_frames": decoded,
        "expected_frames": FRAMES,
        "max_anchor_error_px": max(sample_errors) if sample_errors else 9999.0,
        "unoccluded_overlay_visible": unoccluded_visible,
        "foreground_occlusion_preserved": foreground_preserved and occlusion_saved,
        "contract_proven": ["external normalized point track", "world-attached overlay", "foreground-mask occlusion", "MP4 encode/decode"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    report = run_fusion_probe(args.output_dir)
    (args.output_dir / "fusion-probe-report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["video_decodes"] and report["foreground_occlusion_preserved"] and report["max_anchor_error_px"] <= 1.5 else 1

if __name__ == "__main__":
    raise SystemExit(main())
