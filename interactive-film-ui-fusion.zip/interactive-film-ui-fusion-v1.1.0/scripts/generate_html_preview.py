#!/usr/bin/env python3
"""Generate a self-contained, executable HTML timeline preview for UI/fusion review."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.compile_overlay import compile_overlay


def _safe_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")


def generate_preview(project: dict[str, Any], overlay: dict[str, Any], output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    project_id = str(project["project_id"]).replace('"', '&quot;')
    duration = float(overlay["summary"]["duration_sec"])
    frame_w = int(overlay["frame"]["width"])
    frame_h = int(overlay["frame"]["height"])
    cet_json = _safe_json(overlay)
    title = str(project.get("title") or project["project_id"])
    html = f'''<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Interactive Film UI Fusion Preview</title>
<style>
:root{{--wood:#30271d;--wood2:#4a3823;--paper:#eee4cf;--paper2:#f7f0df;--ink:#25231f;--text:#f8f3e9;--gold:#b9862f;--gold2:#d2ad63;--red:#b93f2f;--jade:#496c5c;--muted:#9e998c;--black:#12110f}}
*{{box-sizing:border-box}}body{{margin:0;background:#e7e2d8;color:#1f1d19;font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:1240px;margin:18px auto;padding:0 16px}}.stage{{position:relative;aspect-ratio:{frame_w}/{frame_h};overflow:hidden;border:5px solid #22342e;border-radius:10px;background:linear-gradient(135deg,#6f806f,#2f4a47 48%,#21322f);box-shadow:0 12px 32px #0003}}
.video-player,.image-player{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:none}}.video-base{{position:absolute;inset:0;background:radial-gradient(circle at 68% 35%,#e3d7b755,transparent 25%),linear-gradient(120deg,#879489,#425b58 55%,#263936);transition:background .2s}}
.video-base:after{{content:attr(data-label);position:absolute;left:2.4%;bottom:2.4%;padding:6px 10px;background:#0007;color:#fff;font-size:12px;letter-spacing:.04em}}
.vignette{{position:absolute;inset:0;background:linear-gradient(180deg,#0002,transparent 22%,transparent 75%,#0005);pointer-events:none}}
.hud{{position:absolute;inset:0;pointer-events:none;color:var(--text)}}
.timer{{position:absolute;top:1.5%;left:50%;transform:translateX(-50%);min-width:168px;text-align:center;padding:7px 22px 8px;clip-path:polygon(10% 0,90% 0,100% 24%,100% 76%,90% 100%,10% 100%,0 76%,0 24%);background:linear-gradient(#4d3a22,#2d241a);border:1px solid var(--gold);font-weight:800;letter-spacing:.08em;color:#ffd98e;text-shadow:0 1px #000;font-variant-numeric:tabular-nums}}
.quest-info{{position:absolute;top:2.2%;left:2.2%;max-width:31%;padding:9px 13px;background:#e9dfc9e8;color:var(--ink);border:1px solid #b99855;border-left:5px solid var(--jade);box-shadow:0 4px 16px #0003}}
.progress-pill{{position:absolute;top:12.2%;left:2.2%;padding:5px 10px;background:#2d241acc;border:1px solid var(--gold);color:#ffd98e;font-weight:800}}.quest-info b{{display:block;font-size:14px}}.quest-info small{{display:block;margin-top:2px;opacity:.8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.route-map{{position:absolute;top:2%;right:2%;width:28%;height:18%;background:#efe7d5e8;border:1px solid #a98a50;color:var(--ink);overflow:hidden;box-shadow:0 4px 16px #0003}}
.map-title{{position:absolute;left:8px;top:5px;font-size:10px;font-weight:700;color:#5a4934}}.map-line{{position:absolute;left:7%;right:5%;top:57%;height:2px;background:linear-gradient(90deg,var(--gold),#8f7d5e);transform:rotate(-5deg);transform-origin:left center;opacity:.8}}
.map-node{{position:absolute;width:15px;height:15px;border-radius:50%;border:2px solid #897e69;background:#d4cec1;transform:translate(-50%,-50%);box-shadow:0 0 0 2px #f3eddfaa}}
.map-node.done{{background:var(--red);border-color:#f6d9b0}}.map-node.active{{background:#f0c15c;border-color:var(--red);box-shadow:0 0 0 5px #b93f2f33}}.map-node span{{position:absolute;top:17px;left:50%;transform:translateX(-50%);white-space:nowrap;font-size:8px;color:#4b4134}}
.collection-bar{{position:absolute;left:50%;bottom:2.8%;transform:translateX(-50%);display:grid;grid-template-columns:repeat(8,1fr);gap:4px;width:min(66%,730px);padding:7px;background:#e8e1d0dd;border:1px solid #b99a5f;box-shadow:0 4px 18px #0004}}
.slot{{height:48px;display:grid;place-items:center;background:#c9c8bd88;color:#8b897f;border:1px solid #bdb7aa;position:relative;font-family:serif;font-weight:800}}.slot.done{{background:#f0e8d5;color:#5b4830;border-color:var(--gold)}}.slot.active{{outline:3px solid #b93f2f55}}.slot small{{position:absolute;bottom:1px;font:8px system-ui;color:inherit}}
.event-layer,.tip-layer,.stamp-layer,.settlement-layer,.brand-layer,.real-world-layer{{position:absolute;inset:0}}
.event-card{{position:absolute;left:50%;top:44%;transform:translate(-50%,-50%);width:min(62%,680px);background:var(--paper2);color:var(--ink);border:2px solid var(--gold);box-shadow:0 10px 30px #0006;padding:16px 22px;text-align:center}}
.event-card:before,.event-card:after{{content:"";position:absolute;top:7px;bottom:7px;width:5px;background:var(--red)}}.event-card:before{{left:8px}}.event-card:after{{right:8px}}.event-card b{{display:block;color:#9d3a2e;font-size:18px;margin-bottom:4px}}.event-card p{{margin:0;font-size:13px}}
.tip{{position:absolute;left:10%;bottom:21%;padding:8px 15px;background:#e5ae3d;color:#332719;border-radius:18px 18px 18px 4px;font-weight:800;box-shadow:0 5px 16px #0004}}
.stamp{{position:absolute;left:50%;top:52%;width:118px;height:118px;transform:translate(-50%,-50%) rotate(-8deg);border:7px solid var(--red);border-radius:50%;color:var(--red);display:grid;place-items:center;font:800 25px/1.1 serif;text-align:center;box-shadow:inset 0 0 0 4px #b93f2f55;animation:stampIn .22s ease-out}}
@keyframes stampIn{{from{{transform:translate(-50%,-50%) rotate(-8deg) scale(1.65);opacity:0}}to{{transform:translate(-50%,-50%) rotate(-8deg) scale(1);opacity:1}}}}
.hotspot{{position:absolute;width:40px;height:40px;border:3px solid #d74735;border-radius:8px;transform:translate(-50%,-50%);box-shadow:0 0 0 7px #d7473525,inset 0 0 0 1px #fff8}}
.settlement-layer{{display:none;place-items:center;background:#10110ed0}}.settlement-layer.show{{display:grid}}.settlement{{width:min(58%,630px);padding:26px;background:#eee6d4;color:var(--ink);border:3px solid var(--gold);text-align:center;box-shadow:0 14px 36px #0009}}.grade{{margin:0 auto 8px;width:88px;height:88px;border-radius:50%;display:grid;place-items:center;background:var(--red);color:#fff;font:800 62px serif}}.settlement h2{{margin:6px 0;font-family:serif}}.reward-list{{margin:15px auto 0;padding-top:12px;border-top:1px solid #bfa46e;text-align:left;max-width:440px}}.reward-list div{{margin:6px 0}}
.brand-layer{{display:none;background:var(--black);color:var(--red);place-items:center;text-align:center}}.brand-layer.show{{display:grid}}.brand-seal{{width:210px;height:210px;border:8px double var(--red);border-radius:50%;display:grid;place-items:center;padding:20px;font:700 27px/1.35 serif}}.brand-meta{{color:#d9cdb8;font:13px system-ui;margin-top:18px}}
.real-world-layer{{display:none;place-items:center;background:#dde4ddd9}}.real-world-layer.show{{display:grid}}.door-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:82%}}.door-grid div{{aspect-ratio:4/3;background:linear-gradient(135deg,#8ba39b,#556f68);border:2px solid #f6f1e5;display:grid;place-items:end center;padding:8px;color:#fff;text-shadow:0 1px 3px #000;background-blend-mode:multiply}}
.controls{{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;margin-top:14px}}input[type=range]{{width:100%}}.readout{{font-variant-numeric:tabular-nums;font-weight:700}}.log{{margin-top:12px;background:#f3eee4;border:1px solid #c7bda9;padding:10px;min-height:66px;white-space:pre-wrap;font:12px/1.45 ui-monospace,monospace;color:#484137}}.note{{margin:10px 0;color:#655c4d;font-size:12px}}
@media(max-width:720px){{.quest-info{{max-width:42%}}.route-map{{width:34%}}.collection-bar{{width:92%}}.event-card{{width:84%}}}}
</style>
<main data-project-id="{project_id}">
  <div class="stage" id="stage">
    <video class="video-player" id="videoPlayer" muted playsinline controls></video><img class="image-player" id="imagePlayer" alt="Shot preview"><div class="video-base" id="videoBase" data-label="PREVIS · {title}"></div><div class="vignette"></div>
    <div class="hud" id="hudRoot">
      <div class="timer" id="timer">00:00</div>
      <div class="quest-info" id="questInfo"></div>
      <div class="progress-pill" id="progress">0/8</div>
      <div class="route-map" id="routeMap"></div>
      <div class="collection-bar" id="collectionBar"></div>
      <div class="event-layer" id="eventLayer"></div>
      <div class="tip-layer" id="tipLayer"></div>
      <div class="stamp-layer" id="stampLayer"></div>
      <div class="settlement-layer" id="settlementLayer"></div>
      <div class="real-world-layer" id="realWorldLayer"></div>
      <div class="brand-layer" id="brandLayer"></div>
    </div>
  </div>
  <div class="controls"><input id="timeline" type="range" min="0" max="{duration:.3f}" step="0.001" value="0" aria-label="Timeline"><div class="readout" id="readout">0.00s</div></div>
  <div class="note">同一 CET 驱动：HUD / 路线 / 收集 / 热点 / 印章 / 结算 / 落版。拖动时间轴检查 18 镜。</div>
  <div class="log" id="log">Move the timeline to inspect CET events.</div>
</main>
<script>
const CET = {cet_json};
const $=id=>document.getElementById(id);
const timeline=$('timeline'),readout=$('readout'),timer=$('timer'),questInfo=$('questInfo'),progressEl=$('progress'),videoPlayer=$('videoPlayer'),imagePlayer=$('imagePlayer'),routeMap=$('routeMap'),collectionBar=$('collectionBar'),eventLayer=$('eventLayer'),tipLayer=$('tipLayer'),stampLayer=$('stampLayer'),settlementLayer=$('settlementLayer'),brandLayer=$('brandLayer'),realWorldLayer=$('realWorldLayer'),videoBase=$('videoBase'),log=$('log');
function fmt(t){{const m=Math.floor(t/60),s=Math.floor(t%60);return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')}}
function shotAt(t){{return CET.shots.find(s=>t>=s.start&&t<s.end)||CET.shots[CET.shots.length-1]}}
function eventsBefore(t,type=null){{return CET.events.filter(e=>e.at<=t&&(!type||e.type===type))}}
function lastBefore(t,type){{const a=eventsBefore(t,type);return a.length?a[a.length-1]:null}}
function activeEvents(t){{return CET.events.filter(e=>e.at<=t&&t<=e.end_at)}}
function progressAt(t){{let current=CET.collection.initial||0,total=CET.collection.total||8;for(const e of CET.events){{if(e.at<=t&&e.progress){{current=e.progress.current;total=e.progress.total}}}}return {{current,total}}}}
function interp(anchor,t){{if(!anchor)return null;if(anchor.tracking==='static')return [anchor.x,anchor.y];const k=anchor.keyframes||[];if(!k.length)return null;if(t<=k[0].t)return [k[0].x,k[0].y];if(t>=k[k.length-1].t)return [k[k.length-1].x,k[k.length-1].y];for(let i=1;i<k.length;i++){{if(t<=k[i].t){{const a=k[i-1],b=k[i],u=(t-a.t)/(b.t-a.t);return [a.x+(b.x-a.x)*u,a.y+(b.y-a.y)*u]}}}}return null}}
function hudVisibleAt(t){{const entered=eventsBefore(t,'HUD_ENTER').length>0;const cleared=lastBefore(t,'HUD_CLEAR');return entered&&!cleared}}
function renderMap(progress){{const nodes=(CET.route&&CET.route.nodes)||[];routeMap.innerHTML='';const title=document.createElement('div');title.className='map-title';title.textContent=CET.route.title||'ROUTE';routeMap.appendChild(title);const line=document.createElement('div');line.className='map-line';routeMap.appendChild(line);nodes.forEach((n,i)=>{{const node=document.createElement('div');node.className='map-node'+(i<progress.current?' done':i===progress.current?' active':'');node.style.left=(8+i*(84/Math.max(1,nodes.length-1)))+'%';node.style.top=(54-((i%3)-1)*8)+'%';const label=document.createElement('span');label.textContent=n.label;node.appendChild(label);routeMap.appendChild(node)}})}}
function renderCollection(progress){{collectionBar.innerHTML='';const items=(CET.collection&&CET.collection.items)||[];items.forEach((item,i)=>{{const cell=document.createElement('div');cell.className='slot'+(i<progress.current?' done':i===progress.current?' active':'');cell.textContent=item.glyph||String(i+1);const small=document.createElement('small');small.textContent=item.label;cell.appendChild(small);collectionBar.appendChild(cell)}})}}
function renderTransient(t,shot,active){{eventLayer.innerHTML='';tipLayer.innerHTML='';stampLayer.innerHTML='';for(const e of active){{if(['QUEST_OPEN','REWARD_REVEAL','ROUTE_REVEAL','ACTION_COMMIT','QTE_OPEN'].includes(e.type)){{const card=document.createElement('div');card.className='event-card';const b=document.createElement('b');b.textContent=shot.copy.headline||e.type;const p=document.createElement('p');p.textContent=shot.copy.detail||e.action_id;card.append(b,p);eventLayer.appendChild(card)}}if(e.type==='TIP_OPEN'||e.type==='ACHIEVEMENT_UNLOCK'){{const tip=document.createElement('div');tip.className='tip';tip.textContent=(e.data&&((e.data.title?e.data.title+' · ':'')+(e.data.detail||e.data.tip||'')))||shot.copy.detail||e.type;tipLayer.appendChild(tip)}}if(e.type==='STAMP_IMPACT'||e.type==='COLLECTION_COMPLETE'){{const s=document.createElement('div');s.className='stamp';s.textContent=e.type==='COLLECTION_COMPLETE'?'八印\\n合一':'盖章';stampLayer.appendChild(s)}}if(e.anchor){{const p=interp(CET.anchors[e.anchor],t);if(p){{const dot=document.createElement('div');dot.className='hotspot';dot.style.left=(p[0]*100)+'%';dot.style.top=(p[1]*100)+'%';dot.title=e.type;eventLayer.appendChild(dot)}}}}}}}}
function renderSettlement(t){{const settle=lastBefore(t,'SETTLEMENT_OPEN'),clear=lastBefore(t,'HUD_CLEAR');const show=!!settle&&!clear;if(!show){{settlementLayer.classList.remove('show');settlementLayer.innerHTML='';return}}settlementLayer.classList.add('show');const reward=lastBefore(t,'REWARD_REVEAL');const data=settle.data||{{}};settlementLayer.innerHTML='';const box=document.createElement('div');box.className='settlement';const grade=document.createElement('div');grade.className='grade';grade.textContent=data.grade||'S';const h=document.createElement('h2');h.textContent=data.result||'完美通关';const stats=document.createElement('div');stats.textContent=data.stats||'收集 8/8';box.append(grade,h,stats);if(reward&&reward.data){{const list=document.createElement('div');list.className='reward-list';(reward.data.lines||[]).forEach(line=>{{const row=document.createElement('div');row.textContent='✓ '+line;list.appendChild(row)}});if(reward.data.footer){{const foot=document.createElement('b');foot.textContent=reward.data.footer;list.appendChild(foot)}}box.appendChild(list)}}settlementLayer.appendChild(box)}}
function renderBrand(t){{const e=lastBefore(t,'BRAND_OUTRO');if(!e){{brandLayer.classList.remove('show');brandLayer.innerHTML='';return}}brandLayer.classList.add('show');brandLayer.innerHTML='';const wrap=document.createElement('div');const seal=document.createElement('div');seal.className='brand-seal';seal.textContent=(e.data&&e.data.title)||CET.title;const meta=document.createElement('div');meta.className='brand-meta';meta.textContent=((e.data&&e.data.subtitle)||'')+' · '+((e.data&&e.data.credit)||'');wrap.append(seal,meta);brandLayer.appendChild(wrap)}}
function renderRealWorld(shot){{const show=shot.visual&&shot.visual.mode==='real-world-grid';realWorldLayer.classList.toggle('show',show);realWorldLayer.innerHTML='';if(show){{const grid=document.createElement('div');grid.className='door-grid';['田子坊','大世界','豫园','外滩'].forEach(x=>{{const d=document.createElement('div');d.textContent=x+' · 实拍门头';grid.appendChild(d)}});realWorldLayer.appendChild(grid)}}}}
function initMedia(){{const src=CET.media&&CET.media.master_src;if(src){{videoPlayer.src=src;videoPlayer.style.display='block';videoBase.style.display='none';if('requestVideoFrameCallback' in HTMLVideoElement.prototype){{const tick=(now,meta)=>{{if(!videoPlayer.paused){{timeline.value=String(meta.mediaTime);render()}}videoPlayer.requestVideoFrameCallback(tick)}};videoPlayer.requestVideoFrameCallback(tick)}}}}}}
function syncMedia(t,shot){{if(videoPlayer.src){{if(videoPlayer.paused&&videoPlayer.readyState>=1&&Math.abs(videoPlayer.currentTime-t)>.04)videoPlayer.currentTime=t;return}}const still=shot.media&&shot.media.src;if(still){{imagePlayer.src=still;imagePlayer.style.display='block';videoBase.style.display='none'}}else{{imagePlayer.style.display='none';videoBase.style.display='block'}}}}
function render(){{const t=Number(timeline.value),shot=shotAt(t),progress=progressAt(t),active=activeEvents(t),hudVisible=hudVisibleAt(t);readout.textContent=t.toFixed(2)+'s';const settle=lastBefore(t,'SETTLEMENT_OPEN');timer.textContent=settle&&!lastBefore(t,'HUD_CLEAR')?((settle.data&&settle.data.display_time)||CET.timer.settlement_display||'01:00'):fmt(t);questInfo.innerHTML='';const b=document.createElement('b');b.textContent=shot.copy.headline||shot.id;const small=document.createElement('small');small.textContent=shot.copy.detail||'';questInfo.append(b,small);progressEl.textContent=progress.current+'/'+progress.total;timer.style.display=hudVisible?'block':'none';questInfo.style.display=hudVisible?'block':'none';progressEl.style.display=hudVisible?'block':'none';routeMap.style.display=hudVisible?'block':'none';collectionBar.style.display=hudVisible?'grid':'none';renderMap(progress);renderCollection(progress);renderTransient(t,shot,active);renderSettlement(t);renderRealWorld(shot);renderBrand(t);syncMedia(t,shot);videoBase.dataset.label=shot.id+' · '+(shot.visual.mode||'PREVIS');const nearby=CET.events.filter(e=>Math.abs(e.at-t)<=0.5);log.textContent=nearby.length?nearby.map(e=>e.id+'  '+e.type+'  '+e.action_id).join('\\n'):'No CET event in ±0.50s';}}
timeline.addEventListener('input',render);initMedia();render();
</script>
'''
    output.write_text(html, encoding="utf-8")
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = json.loads(args.project.read_text(encoding="utf-8"))
    overlay = compile_overlay(project)
    path = generate_preview(project, overlay, args.output)
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
