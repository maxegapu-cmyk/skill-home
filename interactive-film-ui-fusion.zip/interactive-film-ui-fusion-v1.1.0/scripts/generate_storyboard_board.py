#!/usr/bin/env python3
"""Generate a WorkBuddy-style long storyboard review page from one project contract."""
from __future__ import annotations

import argparse
import base64
import html
import json
import mimetypes
from pathlib import Path
from typing import Any


def _fmt(sec: float) -> str:
    m=int(sec)//60; s=int(sec)%60
    return f"{m:02d}:{s:02d}"


def _progress_at(project: dict[str, Any], t: float) -> int:
    current=0
    for shot in project.get('shots') or []:
        for e in shot.get('events') or []:
            if e.get('at',9999) <= t and e.get('progress'):
                current=max(current,int(e['progress']['current']))
    return current


def _hero_background(mode: str, index: int) -> str:
    palettes={
        'street-title':'linear-gradient(130deg,#37483f,#9b8667 58%,#d2c6a7)',
        'hud-load':'linear-gradient(130deg,#657b70,#b6aa8f)',
        'task-card':'linear-gradient(145deg,#86775e,#b7af96 55%,#455b51)',
        'reward-card':'linear-gradient(140deg,#455c54,#a99771)',
        'route-map':'linear-gradient(145deg,#756952,#b9b09a 50%,#51665f)',
        'hand-hotspot':'linear-gradient(135deg,#6d5b42,#c1b493 55%,#334b44)',
        'backlit-qte':'linear-gradient(135deg,#223933,#a78a5d 55%,#d4c8a8)',
        'foreground-action':'linear-gradient(145deg,#2c403a,#8f7351 52%,#d0c19b)',
        'quiet-achievement':'linear-gradient(145deg,#6e5943,#b7a27c 48%,#374944)',
        'wide-cool':'linear-gradient(145deg,#31535b,#779497 48%,#c0bca6)',
        'low-angle-warm':'linear-gradient(145deg,#432b22,#b14e29 48%,#e39b49)',
        'reflection':'linear-gradient(145deg,#31453f,#8e8270 48%,#cab997)',
        'crowd-arrival':'linear-gradient(145deg,#313b38,#736e5c 48%,#b0a284)',
        'stamp-merge':'linear-gradient(145deg,#5a4a36,#c3ac77 48%,#334b42)',
        'settlement':'linear-gradient(145deg,#d0c2a1,#73634c 60%,#202520)',
        'reward-list':'linear-gradient(145deg,#d6caa9,#827155 60%,#31342e)',
        'real-world-grid':'linear-gradient(135deg,#65746b,#d2c5a6)',
        'brand-outro':'#17130f',
    }
    return palettes.get(mode,'linear-gradient(135deg,#40554c,#a99878)')


def generate_storyboard_board(project: dict[str, Any], output: Path, base_dir: Path | None = None) -> None:
    title=html.escape(project.get('title') or project['project_id'])
    total=int((project.get('collection') or {}).get('total',8))
    cards=[]
    for idx,shot in enumerate(project['shots'],1):
        p=_progress_at(project,float(shot['start']))
        copy=shot.get('copy') or {}
        audio=shot.get('audio') or {}
        mode=(shot.get('visual') or {}).get('mode','')
        events=shot.get('events') or []
        event_names=' · '.join(e['type'] for e in events)
        event_data=' · '.join(' / '.join(str(v) for v in (e.get('data') or {}).values() if not isinstance(v,(list,dict))) for e in events if e.get('data'))
        details=copy.get('detail','')
        voice=copy.get('voiceover','')
        # If the copy used role labels inside detail, keep them visible for real production handoff.
        headline=copy.get('headline',shot['id'])
        map_dots=''.join(f'<i class="dot {"on" if i<p else ""}"></i>' for i in range(total))
        slots=''.join(f'<span class="slot {"on" if i<p else ""}">{i+1}</span>' for i in range(total))
        media_html=''
        still_src=(shot.get('media') or {}).get('still_src')
        if isinstance(still_src,str) and still_src:
            if still_src.startswith(('http://','https://','data:')):
                src=still_src
            else:
                candidate=Path(still_src)
                if not candidate.is_absolute() and base_dir is not None:
                    candidate=(base_dir/candidate).resolve()
                if candidate.exists() and candidate.is_file():
                    mime=mimetypes.guess_type(candidate.name)[0] or 'image/png'
                    src=f"data:{mime};base64,{base64.b64encode(candidate.read_bytes()).decode('ascii')}"
                else:
                    src=still_src
            media_html=f'<img class="shot-media" src="{html.escape(src,quote=True)}" alt="">'
        center=''
        if mode=='brand-outro':
            center=f'<div class="brand-seal">一城揽三国<br><b>半步入江湖</b></div>'
        elif any(e.get('type')=='SETTLEMENT_OPEN' for e in events):
            center='<div class="settle-mini"><b>S 评级</b><small>完美通关 · 8/8</small></div>'
        else:
            center=f'<div class="event-card-mini"><b>{html.escape(headline)}</b><small>{html.escape(details[:70])}</small></div>'
        cards.append(f'''<article class="shot-card" data-shot="{html.escape(shot['id'])}">
  <div class="hero" style="background:{_hero_background(mode,idx)}">
    {media_html}
    <div class="timer">{_fmt(float(shot['start']))}</div>
    <div class="stage-chip">关卡 {p}/{total}</div>
    <div class="mini-map">{map_dots}</div>
    {center}
    <div class="collection">{slots}</div>
  </div>
  <div class="meta"><span class="shot-id">{html.escape(shot['id'])}</span><b>{_fmt(float(shot['start']))}–{_fmt(float(shot['end']))}</b></div>
  <h3>{html.escape(headline)}</h3>
  <p class="detail">{html.escape(details)}</p>
  <p class="voiceover"><strong>口播</strong> {html.escape(voice)}</p>
  <p class="sfx"><strong>音效</strong> {html.escape(audio.get('sfx',''))}</p>
  <p class="ui"><strong>UI</strong> {html.escape(event_names)} {html.escape(event_data)}</p>
</article>''')
    css='''
*{box-sizing:border-box} body{margin:0;background:#ede9df;color:#28251f;font-family:system-ui,"Noto Sans CJK SC",sans-serif}.page{max-width:1180px;margin:auto;padding:28px 26px 56px}.header{background:#f8f4ea;border:1px solid #d8d0bd;padding:20px 24px;border-radius:12px;margin-bottom:18px}.header h1{font-size:24px;margin:0 0 7px}.header p{margin:0;color:#6f695c}.legend{display:flex;gap:7px;flex-wrap:wrap;margin-top:13px}.legend span{background:#3b352c;color:#f4ead4;padding:6px 12px;border-radius:999px;font-size:12px}.board{display:grid;grid-template-columns:1fr 1fr;gap:16px}.shot-card{background:#fbfaf5;border:1px solid #d4cbb8;border-radius:10px;overflow:hidden;box-shadow:0 2px 7px #00000012}.hero{position:relative;aspect-ratio:16/8.6;overflow:hidden}.shot-media{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0}.hero:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,#0001,#0000 45%,#0003);pointer-events:none}.timer{position:absolute;z-index:2;top:8px;left:50%;transform:translateX(-50%);background:#332919;color:#f0c66b;border:1px solid #a77d2b;padding:3px 12px;border-radius:3px;font:700 12px ui-monospace}.stage-chip{position:absolute;z-index:2;left:10px;top:10px;background:#efe5cfdd;border:1px solid #c8b68e;color:#463a2b;padding:5px 9px;border-radius:3px;font-size:11px}.mini-map{position:absolute;z-index:2;right:10px;top:10px;width:96px;height:42px;border:1px solid #d1c5a8;background:#efe8d8d9;display:flex;align-items:center;justify-content:center;gap:4px;transform:skewX(-4deg)}.dot{width:6px;height:6px;border-radius:50%;border:1px solid #847a68;background:#cbc5b7}.dot.on{background:#ad3e2e;border-color:#ad3e2e}.event-card-mini,.settle-mini{position:absolute;z-index:2;left:50%;top:51%;transform:translate(-50%,-50%);width:70%;background:#f4ead6eb;border:1px solid #bc9a55;color:#342d24;padding:10px 14px;text-align:center;box-shadow:0 2px 10px #0002}.event-card-mini b,.settle-mini b{display:block;font-size:13px}.event-card-mini small,.settle-mini small{display:block;margin-top:4px;font-size:9px;color:#6e604d}.settle-mini b{font-size:30px;color:#b43f2f}.brand-seal{position:absolute;z-index:2;left:50%;top:50%;transform:translate(-50%,-50%);border:2px solid #b43b2a;border-radius:50%;color:#d75b3c;padding:18px;text-align:center;font-size:13px}.collection{position:absolute;z-index:2;bottom:9px;left:50%;transform:translateX(-50%);display:flex;gap:3px;background:#eee6d7dd;padding:4px 6px;border:1px solid #c7b99d}.slot{display:grid;place-items:center;width:24px;height:20px;border:1px solid #bdb29e;color:#9b9487;font-size:9px}.slot.on{background:#527461;color:#fff;border-color:#527461}.meta{display:flex;justify-content:space-between;padding:10px 12px 0;font-size:11px;color:#756e61}.shot-id{background:#b84631;color:#fff;font-weight:700;padding:2px 5px;border-radius:2px}.shot-card h3{margin:8px 12px 6px;font-size:14px}.shot-card p{margin:5px 12px;color:#5e594f;font-size:11px;line-height:1.55}.shot-card p:last-child{margin-bottom:13px}.voiceover strong,.sfx strong,.ui strong{color:#a44731;margin-right:5px}@media(max-width:760px){.page{padding:14px}.board{grid-template-columns:1fr}}
'''
    body='\n'.join(cards)
    document=f'''<!doctype html><meta charset="utf-8"><title>{title} · 分镜板</title><style>{css}</style><main class="page"><section class="header"><h1>{title} · 分镜生产板</h1><p>真人/AI底图 + 游戏 HUD · CET 驱动 · UI/口播/音效/状态同页审查</p><div class="legend"><span>速通计时器</span><span>副本进度</span><span>路线地图</span><span>任务/奖励</span><span>8格收集</span><span>朱砂反馈</span></div></section><section class="board">{body}</section></main>'''
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(document,encoding='utf-8')


def main()->int:
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('project',type=Path); ap.add_argument('output',type=Path); a=ap.parse_args()
    generate_storyboard_board(json.loads(a.project.read_text(encoding='utf-8')),a.output,base_dir=a.project.resolve().parent); print(a.output); return 0
if __name__=='__main__': raise SystemExit(main())
