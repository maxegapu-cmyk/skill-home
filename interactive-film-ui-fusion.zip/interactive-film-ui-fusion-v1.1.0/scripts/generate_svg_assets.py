#!/usr/bin/env python3
"""Generate editable starter SVG assets from a portable UI theme."""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_THEME = ROOT / "templates" / "ui-theme.json"


def _load_theme(theme_path: Path | None) -> dict[str, Any]:
    path = theme_path or DEFAULT_THEME
    return json.loads(path.read_text(encoding="utf-8"))


def _svg(component_id: str, width: int, height: int, body: str, theme_id: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" data-component-id="{html.escape(component_id)}" '
        f'data-theme-id="{html.escape(theme_id)}">\n{body}\n</svg>\n'
    )


def _asset_specs(theme: dict[str, Any]) -> dict[str, tuple[int, int, str]]:
    c = theme["colors"]
    op = theme["opacity"]["panel"]
    r = theme["radius"]["medium"]
    gold = c["accent"]
    danger = c["danger"]
    paper = c["panel_alt"]
    dark = c["panel"]
    text = c["text"]
    ink = c["text_dark"]
    muted = c["muted"]

    route_nodes = "".join(
        f'<circle cx="{55+i*105}" cy="84" r="18" fill="{gold if i < 3 else muted}" fill-opacity="{1 if i < 3 else .45}"/>'
        f'<text x="{55+i*105}" y="130" text-anchor="middle" font-size="18" fill="{ink}" font-family="system-ui">{i+1}</text>'
        for i in range(8)
    )
    collection_cells = "".join(
        f'<g id="slot-{i+1}"><rect x="{18+i*92}" y="14" width="76" height="76" rx="8" fill="{paper}" stroke="{gold if i < 3 else muted}" stroke-width="3"/>'
        f'<text x="{56+i*92}" y="63" text-anchor="middle" font-size="28" fill="{ink if i < 3 else muted}" font-family="serif">{i+1}</text></g>'
        for i in range(8)
    )

    return {
        "timer": (520, 104,
            f'<g id="state-hidden" opacity="0"/><g id="state-idle"><path d="M10 18 L45 4 H475 L510 18 V86 L475 100 H45 L10 86Z" fill="{dark}" fill-opacity=".9" stroke="{gold}" stroke-width="2"/><text id="binding-time" x="260" y="66" text-anchor="middle" font-size="48" fill="{text}" font-family="system-ui">00:00</text></g><g id="state-frozen" opacity="0"><rect x="4" y="4" width="512" height="96" rx="{r}" fill="{gold}"/><text x="260" y="66" text-anchor="middle" font-size="48" fill="{ink}" font-family="system-ui">01:00</text></g>'),
        "quest-card": (720, 300,
            f'<g id="state-hidden" opacity="0"/><g id="state-active"><rect x="4" y="4" width="712" height="292" rx="{r}" fill="{paper}" stroke="{gold}" stroke-width="3"/><path d="M20 18 H700 M20 280 H700" stroke="{gold}" stroke-opacity=".55"/><text id="binding-title" x="40" y="72" font-size="36" fill="{ink}" font-family="system-ui">任务标题</text><text id="binding-body" x="40" y="132" font-size="26" fill="{ink}" font-family="system-ui">任务说明 / 0/3</text></g><g id="state-success" opacity="0"><circle cx="650" cy="62" r="32" fill="none" stroke="{danger}" stroke-width="6"/><text x="650" y="72" text-anchor="middle" font-size="24" fill="{danger}" font-family="serif">成</text></g>'),
        "tip-bubble": (540, 150,
            f'<g id="state-hidden" opacity="0"/><g id="state-intro"><path d="M20 10 H500 Q525 10 525 35 V105 Q525 130 500 130 H90 L55 145 L64 130 H20 Q10 130 10 118 V22 Q10 10 20 10Z" fill="{gold}"/><text id="binding-tip" x="52" y="86" font-size="28" fill="{ink}" font-family="system-ui">TIPS</text></g>'),
        "stamp": (220, 220,
            f'<g id="state-hidden" opacity="0"/><g id="state-impact"><circle cx="110" cy="110" r="94" fill="none" stroke="{danger}" stroke-width="12"/><circle cx="110" cy="110" r="72" fill="none" stroke="{danger}" stroke-width="4"/><text id="binding-stamp" x="110" y="124" text-anchor="middle" font-size="34" fill="{danger}" font-family="serif">通关</text></g><g id="state-unlocked" opacity="0"><circle cx="110" cy="110" r="94" fill="{danger}" fill-opacity=".15" stroke="{danger}" stroke-width="8"/></g>'),
        "map-node": (140, 140,
            f'<g id="state-locked"><circle cx="70" cy="70" r="32" fill="{muted}" fill-opacity="0.55"/><circle cx="70" cy="70" r="48" fill="none" stroke="{muted}" stroke-width="4" stroke-dasharray="8 8"/></g><g id="state-active" opacity="0"><circle cx="70" cy="70" r="40" fill="none" stroke="{danger}" stroke-width="5"/></g><g id="state-completed" opacity="0"><circle cx="70" cy="70" r="36" fill="{gold}"/><path d="M50 71 L64 86 L94 51" fill="none" stroke="{ink}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></g>'),
        "collection-slot": (150, 176,
            f'<g id="state-locked"><rect x="8" y="8" width="134" height="134" rx="18" fill="{dark}" fill-opacity="0.34" stroke="{muted}" stroke-width="3"/><text id="binding-index" x="75" y="164" text-anchor="middle" font-size="22" fill="{muted}" font-family="system-ui">1/8</text></g><g id="state-completed" opacity="0"><rect x="8" y="8" width="134" height="134" rx="18" fill="{paper}" stroke="{gold}" stroke-width="4"/></g>'),
        "settlement": (900, 560,
            f'<g id="state-hidden" opacity="0"/><g id="state-intro"><rect x="6" y="6" width="888" height="548" rx="28" fill="{dark}" fill-opacity="0.90" stroke="{gold}" stroke-width="4"/><circle cx="450" cy="160" r="88" fill="{danger}"/><text id="binding-grade" x="450" y="205" text-anchor="middle" font-size="140" fill="{text}" font-family="serif">S</text><text id="binding-result" x="450" y="320" text-anchor="middle" font-size="40" fill="{text}" font-family="system-ui">完美通关</text><text id="binding-stats" x="450" y="400" text-anchor="middle" font-size="28" fill="{text}" font-family="system-ui">收集 8/8 · 成就 1/1</text></g>'),
        "route-map": (900, 180,
            f'<g id="state-route"><rect x="4" y="4" width="892" height="172" rx="18" fill="{paper}" fill-opacity=".94" stroke="{gold}" stroke-width="3"/><path d="M55 84 C180 50 240 110 370 80 S610 74 790 58" fill="none" stroke="{gold}" stroke-width="5" stroke-linecap="round"/>{route_nodes}</g>'),
        "collection-bar": (770, 112,
            f'<g id="state-progress"><rect x="4" y="4" width="762" height="104" rx="14" fill="{dark}" fill-opacity=".64" stroke="{gold}" stroke-width="2"/>{collection_cells}</g>'),
        "brand-outro": (960, 540,
            f'<g id="state-active"><rect width="960" height="540" fill="#12110f"/><circle cx="480" cy="220" r="104" fill="none" stroke="{danger}" stroke-width="8"/><circle cx="480" cy="220" r="84" fill="none" stroke="{danger}" stroke-width="3"/><text id="binding-title" x="480" y="210" text-anchor="middle" font-size="34" fill="{danger}" font-family="serif">一城揽三国</text><text x="480" y="255" text-anchor="middle" font-size="28" fill="{danger}" font-family="serif">半步入江湖</text><text id="binding-subtitle" x="480" y="370" text-anchor="middle" font-size="22" fill="{text}" font-family="system-ui">上海旅游节 · 黄浦区系列活动</text></g>'),
    }


def generate_assets(output_dir: Path, theme_path: Path | None = None) -> list[Path]:
    theme = _load_theme(theme_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for component_id, (w, h, body) in _asset_specs(theme).items():
        path = output_dir / f"{component_id}.svg"
        path.write_text(_svg(component_id, w, h, body, theme["theme_id"]), encoding="utf-8")
        paths.append(path)
    return paths


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--theme", type=Path)
    args = parser.parse_args()
    paths = generate_assets(args.output_dir, args.theme)
    for path in paths:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
