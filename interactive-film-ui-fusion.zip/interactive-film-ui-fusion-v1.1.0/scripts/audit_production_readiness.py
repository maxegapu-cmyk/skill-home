#!/usr/bin/env python3
"""Audit production readiness beyond schema validity."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import sys
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.validate_project import validate_project


def audit_project(project: dict[str, Any]) -> dict[str, Any]:
    p0: list[str] = []
    p1: list[str] = []
    structural = validate_project(project)
    p0.extend(structural)

    profile = project.get("production_profile") or {}
    shots = project.get("shots") or []

    if profile.get("require_shot_copy"):
        for shot in shots:
            copy_block = shot.get("copy") if isinstance(shot, dict) else None
            sid = shot.get("id", "<unknown>") if isinstance(shot, dict) else "<unknown>"
            if not isinstance(copy_block, dict) or not copy_block.get("headline") or "voiceover" not in copy_block:
                p0.append(f"shot {sid}: required copy contract missing headline/voiceover")

    if profile.get("require_audio_cues"):
        for shot in shots:
            sid = shot.get("id", "<unknown>")
            audio = shot.get("audio") or {}
            if not audio.get("sfx"):
                p0.append(f"shot {sid}: required audio cue missing")

    route = project.get("route") or {}
    route_nodes = route.get("nodes") or []
    if profile.get("require_route") and len(route_nodes) < 2:
        p0.append("route: production profile requires a multi-node route")

    collection = project.get("collection") or {}
    total = collection.get("total")
    items = collection.get("items") or []
    if profile.get("require_collection"):
        if not isinstance(total, int) or total <= 0:
            p0.append("collection: positive total required")
        elif len(items) != total:
            p0.append(f"collection: expected {total} item definitions, found {len(items)}")

    # Practical visual completeness, not hard schema validity.
    visual = project.get("visual_profile") or {}
    if not visual.get("skin"):
        p1.append("visual: no skin/profile declared; UI may drift into generic styling")
    if not visual.get("palette"):
        p1.append("visual: no palette declared")

    hotspot_events = [e for s in shots for e in (s.get("events") or []) if e.get("type") in {"HOTSPOT_OPEN", "HOTSPOT_HIT"}]
    if hotspot_events and not project.get("anchors"):
        p0.append("fusion: hotspot interactions exist without anchors")

    moving_anchors = [a for a in (project.get("anchors") or {}).values() if isinstance(a, dict) and a.get("tracking") in {"keyframe", "external-track"}]
    if hotspot_events and not moving_anchors:
        p1.append("fusion: all hotspots are static; verify whether footage actually moves")

    verification = project.get("verification") or {}

    # Final claims require measured evidence objects; legacy booleans are not proof.
    pixel = verification.get("pixel_fusion") if isinstance(verification, dict) else None
    max_error_limit = max(4.0, float((project.get("frame") or {}).get("height", 1080)) * 0.004)
    pixel_fusion_verified = bool(
        isinstance(pixel, dict)
        and pixel.get("status") == "PASS"
        and pixel.get("actual_footage") is True
        and isinstance(pixel.get("report_ref"), str) and pixel.get("report_ref")
        and isinstance(pixel.get("max_anchor_error_px"), (int, float))
        and float(pixel["max_anchor_error_px"]) <= max_error_limit
        and isinstance(pixel.get("occlusion_cases"), int) and pixel.get("occlusion_cases", 0) >= 1
        and pixel.get("contrast_checked") is True
    )

    runtime_ev = verification.get("runtime_interaction") if isinstance(verification, dict) else None
    runtime_interaction_verified = bool(
        isinstance(runtime_ev, dict)
        and runtime_ev.get("status") == "PASS"
        and isinstance(runtime_ev.get("target"), str) and runtime_ev.get("target")
        and isinstance(runtime_ev.get("report_ref"), str) and runtime_ev.get("report_ref")
        and runtime_ev.get("double_commit_blocked") is True
        and runtime_ev.get("qte_timeout_once") is True
        and runtime_ev.get("save_load_preserved") is True
        and isinstance(runtime_ev.get("p95_branch_latency_ms"), (int, float))
        and float(runtime_ev["p95_branch_latency_ms"]) <= 750
    )

    audio_ev = verification.get("audio_mix") if isinstance(verification, dict) else None
    audio_mix_verified = bool(
        isinstance(audio_ev, dict)
        and audio_ev.get("status") == "PASS"
        and audio_ev.get("rendered_output") is True
        and isinstance(audio_ev.get("report_ref"), str) and audio_ev.get("report_ref")
        and audio_ev.get("sync_checked") is True
    )

    if any(verification.get(k) is True for k in ("pixel_fusion_verified", "runtime_interaction_verified", "audio_mix_verified")):
        p1.append("verification: legacy true/false flags are not accepted as evidence; provide measured evidence objects")

    remaining_limits: list[str] = []
    if not pixel_fusion_verified:
        remaining_limits.append("Actual footage has not yet passed pixel-level tracking, occlusion, contrast, and compositing review.")
    if not runtime_interaction_verified:
        remaining_limits.append("A target runtime has not yet passed real tap/double-tap/QTE/save-load interaction verification.")
    if not audio_mix_verified:
        remaining_limits.append("Final audio timing/mix has not been verified against rendered footage.")

    # Contract quality can score highly, but unverifiable final pixels are intentionally capped.
    score = 100 - 15 * len(p0) - 4 * len(p1)
    if not pixel_fusion_verified:
        score = min(score, 94)
    if not runtime_interaction_verified:
        score = min(score, 92)
    score = max(0, score)

    ready_for_previs = not p0 and score >= 85
    ready_for_final_video = ready_for_previs and pixel_fusion_verified and audio_mix_verified
    ready_for_interactive_runtime = ready_for_previs and runtime_interaction_verified

    return {
        "schema": "production-readiness-1.0",
        "project_id": project.get("project_id"),
        "delivery_mode": project.get("delivery_mode", "PREVIS"),
        "score": score,
        "ready_for_previs": ready_for_previs,
        "ready_for_final_video": ready_for_final_video,
        "ready_for_interactive_runtime": ready_for_interactive_runtime,
        "pixel_fusion_verified": pixel_fusion_verified,
        "runtime_interaction_verified": runtime_interaction_verified,
        "audio_mix_verified": audio_mix_verified,
        "p0": p0,
        "p1": p1,
        "remaining_limits": remaining_limits,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    data = json.loads(args.project.read_text(encoding="utf-8"))
    report = audit_project(data)
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["ready_for_previs"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
