#!/usr/bin/env python3
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "SKILL.md"
EXPECTED_NAME = "industry-intelligence-engine"
REQUIRED = [
    "SKILL.md",
    "references/industry-reality-model.md",
    "references/research-runtime.md",
    "references/industry-archetypes.md",
    "references/evidence-discipline.md",
    "references/market-economics.md",
    "references/competition-and-power.md",
    "references/customer-and-demand.md",
    "references/operations-and-technology.md",
    "references/regulation-and-risk.md",
    "references/trends-and-news.md",
    "references/opportunity-and-entry.md",
    "references/output-and-qa.md",
    "assets/industry-research-brief.md",
    "assets/industry-reality-map.md",
    "assets/evidence-ledger.md",
    "assets/competitor-matrix.md",
    "assets/value-chain-map.md",
    "assets/industry-report.md",
    "assets/opportunity-memo.md",
    "assets/quick-prompts.md",
    "scripts/validate_skill.py",
]

def frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}
    out = {}
    for line in text[4:end].splitlines():
        if ":" not in line or line.startswith(" "):
            continue
        k, v = line.split(":", 1)
        out[k.strip()] = v.strip().strip('"').strip("'")
    return out


def validate() -> list[str]:
    errors: list[str] = []
    if ROOT.name != EXPECTED_NAME:
        errors.append(f"directory name must be {EXPECTED_NAME}")
    for rel in REQUIRED:
        if not (ROOT / rel).is_file():
            errors.append(f"missing required file: {rel}")
    if not MAIN.is_file():
        return errors
    text = MAIN.read_text("utf-8")
    fm = frontmatter(text)
    if fm.get("name") != EXPECTED_NAME:
        errors.append("frontmatter name mismatch")
    desc = fm.get("description", "")
    if not desc.startswith("Use when"):
        errors.append("description must begin with 'Use when'")
    if len(desc) > 1024:
        errors.append("description too long")
    if len(text.splitlines()) >= 500:
        errors.append(f"SKILL.md too long: {len(text.splitlines())} lines")

    all_text = []
    for p in ROOT.rglob("*"):
        if p.is_file() and p.suffix in {".md", ".py", ".txt", ".json"}:
            body = p.read_text("utf-8")
            all_text.append((p, body))
            if p.suffix == ".md":
                for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", body):
                    if "://" in target or target.startswith("#"):
                        continue
                    dest = (p.parent / target.split("#", 1)[0]).resolve()
                    try:
                        dest.relative_to(ROOT.resolve())
                    except ValueError:
                        errors.append(f"link escapes root: {target} in {p.relative_to(ROOT)}")
                        continue
                    if not dest.exists():
                        errors.append(f"broken link: {target} in {p.relative_to(ROOT)}")

    markers = [
        "one industry", "industry archetype", "value flow", "money flow",
        "information flow", "latest", "counterevidence", "entry", "unknown",
        "confidence", "cutoff", "profit pools", "pain pools", "kill criteria"
    ]
    lower = text.lower()
    for marker in markers:
        if marker.lower() not in lower:
            errors.append(f"SKILL.md missing behavior marker: {marker}")

    routed = set(re.findall(r"references/[A-Za-z0-9._-]+\.md", text))
    expected = {x for x in REQUIRED if x.startswith("references/")}
    for rel in sorted(expected - routed):
        errors.append(f"SKILL.md does not route to {rel}")

    return errors


def main() -> int:
    errors = validate()
    if errors:
        print(f"FAIL: {len(errors)} issue(s)")
        for e in errors:
            print("-", e)
        return 1
    files = sum(1 for p in ROOT.rglob("*") if p.is_file())
    print(f"PASS: {EXPECTED_NAME}")
    print(f"files: {files}")
    print(f"SKILL.md lines: {len(MAIN.read_text('utf-8').splitlines())}")
    print("external dependencies: none")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
