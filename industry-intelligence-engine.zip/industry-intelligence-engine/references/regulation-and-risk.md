# Regulation and Risk

## Regulatory Map

Identify:

- regulator/jurisdiction;
- licenses and permits;
- mandatory standards;
- product/service approvals;
- privacy/data rules;
- labor requirements;
- environmental obligations;
- safety/liability;
- insurance/bonding;
- reporting/audit duties;
- cross-border restrictions;
- enforcement intensity.

Distinguish law, proposed rule, guidance, industry standard and common practice.

## Risk Layers

### Demand risk
Customers may not pay, renew or adopt.

### Economic risk
Margins may collapse due to input, channel, financing or price pressure.

### Operational risk
Capacity, quality, labor, supply or delivery may fail.

### Regulatory risk
Rules can block access, increase cost or invalidate the model.

### Technology risk
A substitute may remove the need or commoditize the capability.

### Platform/channel risk
A gatekeeper may change access, ranking, fees or rules.

### Reputation/trust risk
One failure can destroy acquisition economics in trust-sensitive industries.

### Tail risk
Low-frequency catastrophic loss, liability, fraud, default, recall, cyber or safety events.

## Failure Case Method

Study actual failure where possible:

- bankruptcies;
- shutdowns;
- recalls;
- lawsuits;
- enforcement;
- failed pilots;
- customer churn;
- project overruns;
- channel bans;
- abandoned capacity.

For each ask:

**proximate cause → structural cause → warning sign → whether the same mechanism still exists.**

## Risk-to-Action Translation

Every major risk should produce one of:

- prerequisite;
- operating control;
- insurance/hedge;
- contract term;
- validation step;
- limit/cap;
- kill criterion;
- reason not to enter.
