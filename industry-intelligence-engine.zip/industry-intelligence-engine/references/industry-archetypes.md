# Industry Archetypes

Classify first. Many industries are hybrids; use a primary archetype plus secondary modifiers.

## 1. Asset-Heavy Manufacturing

Prioritize capacity, yield, utilization, capex, supplier concentration, qualification cycles, inventory, working capital, maintenance, energy, logistics and scale economics.

Red flag: confusing announced capacity with economically usable output.

## 2. Software / SaaS

Prioritize buyer workflow, deployment burden, retention, expansion, usage, switching, integration, security, gross margin, CAC/payback, implementation services and platform dependency.

Red flag: treating signups as durable demand.

## 3. Marketplace / Platform

Prioritize liquidity, local density, take rate, multi-homing, subsidy, disintermediation, trust/safety, matching quality, network effects, channel ownership and regulation.

Red flag: calling every two-sided business a network-effect moat.

## 4. Media / Content / Attention

Prioritize audience acquisition, recommendation systems, hit rate, retention, rights/IP, monetization mix, ad economics, creator supply, platform dependency and content production cost.

Red flag: equating views with profitable attention.

## 5. Consumer Brand / Retail / Commerce

Prioritize category frequency, basket size, repeat, gross margin, returns, markdown, inventory turns, channel fees, merchandising, paid acquisition, organic distribution and brand elasticity.

Red flag: ignoring inventory and return economics.

## 6. Professional Services

Prioritize trust, expertise, billable utilization, labor leverage, realization, project risk, referrals, repeat business, sales cycle and knowledge standardization.

Red flag: assuming software-like scalability where delivery remains expert-time bound.

## 7. Local Services

Prioritize geography, lead generation, response time, route density, labor availability, utilization, reviews, licensing, repeat/referral, scheduling and local competition.

Red flag: using national TAM to justify a locally constrained business.

## 8. Finance / Insurance

Prioritize regulation, capital, funding, spread/fees, underwriting, loss/default, fraud, distribution, trust, retention, liquidity and tail risk.

Red flag: celebrating growth while ignoring risk-adjusted economics.

## 9. Healthcare / Life Sciences

Prioritize clinical evidence, reimbursement, approval, provider workflow, patient pathway, procurement, safety, liability, adoption friction and long development cycles.

Red flag: treating technical efficacy as commercial adoption.

## 10. Energy / Infrastructure / Utilities

Prioritize regulation, project finance, capex, permitting, interconnection, utilization/capacity factor, commodity exposure, long contracts, reliability and construction timelines.

Red flag: ignoring queue, permitting or financing constraints.

## 11. Logistics / Supply Chain

Prioritize density, load factor, asset turns, empty movement, dwell time, network design, service level, fuel/energy, labor, warehousing, contracts and seasonality.

Red flag: revenue growth without route economics.

## 12. Education / Training

Prioritize learner outcome, buyer/user split, credential value, completion, acquisition, teacher/instructor supply, enterprise procurement, regulation and replacement alternatives.

Red flag: using enrollment as proof of outcome or retention.

## 13. Real Estate / Construction

Prioritize land, permitting, financing, subcontractor structure, utilization, project cycle, cost escalation, location, regulation, defects, schedule risk and capital lock-up.

Red flag: ignoring cycle duration and cash exposure.

## 14. Regulated / Licensed Service

Prioritize license ownership, compliance burden, local rules, auditability, liability, insurance, approved workflows and enforcement intensity.

Red flag: assuming attractive demand is legally addressable.

## Hybrid Rule

When an industry combines archetypes, identify which layer controls economics.

Example logic:

- “AI medical software” may look like SaaS but healthcare approval/reimbursement can dominate;
- “food delivery” may look like commerce but marketplace density and logistics dominate;
- “creator education” may look like education but attention acquisition may dominate.

Choose the archetype that owns the bottleneck, not the marketing label.
