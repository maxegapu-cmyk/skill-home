# Output and QA

## Default Industry X-Ray

### 1. One-screen verdict

State:

- what the industry really is;
- who pays whom;
- main profit mechanism;
- current direction;
- strongest structural opportunity;
- biggest trap;
- overall confidence and cutoff date.

### 2. 60-second outsider explanation

Explain the industry without jargon. A smart outsider should be able to repeat the economic logic.

### 3. Boundary and segmentation

Define what is in/out and which segments have different economics.

### 4. Reality map

Show value chain plus value, money and information flow.

### 5. Customer reality

Show buyer/user roles, triggers, procurement, channels, retention and switching.

### 6. Economics

Show transaction unit, pricing, unit economics, cost stack, profit pools and pain pools.

### 7. Competition and power

Explain who controls critical access/resources and why.

### 8. Operations and technology

Show actual workflow, bottleneck, required assets/capabilities and technology impact.

### 9. Market structure

Present size/growth only with definitions and methodology caveats.

### 10. Regulation and risk

State access requirements, key failure modes and what can invalidate the model.

### 11. Current-change ledger

Use exact dates and separate recent events from structural trends.

### 12. Opportunities / entry playbook

Only derive opportunities from verified friction. Include cheapest validation and kill criteria.

### 13. Watchlist

List 5–10 leading indicators or developments worth rechecking.

### 14. Evidence quality

List contested claims, unknowns and what would change the conclusion.

## Quality Gates

### Gate 1 — Boundary
Can the reader tell what is and is not counted?

### Gate 2 — Causality
Does the report explain mechanisms, not just correlations and trends?

### Gate 3 — Money
Can the reader explain who pays whom, how price is set, and where margin is captured?

### Gate 4 — Power
Can the reader name the gatekeepers and why they have leverage?

### Gate 5 — Customer behavior
Is demand supported by behavior or only stated interest?

### Gate 6 — Operational reality
Does the report include workflow and bottlenecks, not just market slides?

### Gate 7 — Evidence traceability
Can material claims be traced to appropriate evidence?

### Gate 8 — Independence
Were repeated copies of one upstream claim mistaken for triangulation?

### Gate 9 — Freshness
Do dynamic claims have a current cutoff and exact dates where needed?

### Gate 10 — Counterevidence
Was the strongest plausible contrary case checked?

### Gate 11 — Actionability
Does an entrant know what to test first, whom to sell to, and when to stop?

### Gate 12 — Honesty
Are hypothesis, inference, contested claims and unknowns explicit?

## Final Adversarial Review

Before delivering a deep study, ask:

1. What is the single easiest way this report could be wrong?
2. Which attractive number has the weakest definition?
3. Which actor has more power than the report initially gives them?
4. Which hidden cost would destroy the economics?
5. Which recent event might be temporary noise?
6. Which recommendation depends on one unverified assumption?
7. What would reverse the entry recommendation?

Fix the model when evidence requires it. Do not preserve an earlier thesis for consistency.
