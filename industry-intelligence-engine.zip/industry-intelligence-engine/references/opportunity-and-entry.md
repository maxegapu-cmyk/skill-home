# Opportunity and Entry

## Opportunity Must Be Derived

Do not ideate from trend words. Start from verified pain or structural change.

Opportunity chain:

**pain → affected buyer → economic consequence → current workaround → why incumbents leave it unresolved → entry wedge → distribution route → delivery model → economics → defensibility → fatal risk.**

## Wedge Types

Common legitimate wedges:

- narrow high-pain customer segment;
- underserved geography;
- compliance simplification;
- workflow automation;
- faster delivery;
- quality assurance;
- aggregation of fragmented supply;
- procurement simplification;
- financing/payment layer;
- data/measurement layer;
- service layer around hard technology;
- channel/distribution advantage;
- cheaper replacement with acceptable quality.

## Entry Barrier Audit

Classify barriers:

- legal/license;
- capex;
- working capital;
- distribution;
- reputation/trust;
- long qualification/procurement;
- technical know-how;
- supply access;
- data;
- network density;
- scale economics;
- installed-base switching;
- safety/liability.

Then distinguish **barrier to starting** from **barrier to scaling**.

## First-Customer Logic

A valid entry recommendation must answer:

- who is the first narrow buyer?
- what event makes them care now?
- where can they be reached?
- what existing budget or workaround funds the purchase?
- what proof lowers their risk?
- what can be delivered manually before automation?

## Validation Ladder

Prefer cheapest irreversible commitment last:

1. source research;
2. customer/process observation;
3. problem interviews;
4. evidence of existing spend;
5. manual concierge solution;
6. paid pilot/preorder/LOI where meaningful;
7. repeat/renewal evidence;
8. automation/capex;
9. scale.

## Kill Criteria

Define conditions that should stop the idea, for example:

- buyer pain exists but no budget owner;
- procurement cycle exceeds viable cash runway;
- compliance cost destroys unit economics;
- channel owns customer and can copy/bundle the offer;
- acquisition cost cannot be recovered under realistic retention;
- service burden prevents scale;
- required utilization cannot be reached locally;
- willingness to pay is below delivery cost.

## Entry Memo

Rank opportunities by:

**pain intensity × reachable buyer × evidence of spend × speed to proof × economic headroom × defensibility ÷ regulatory/capital/distribution burden.**

Do not turn this into fake precision. Use the formula as a thinking structure, then explain the judgment.
