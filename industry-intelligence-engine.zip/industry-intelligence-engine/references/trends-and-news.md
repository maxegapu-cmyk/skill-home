# Trends and News

## Separate Event From Trend

A trend requires repeated evidence or a mechanism that persists. One announcement is an event.

For each recent development record:

- event date;
- publication date;
- data period if applicable;
- affected layer of the industry model;
- likely duration;
- who benefits;
- who is harmed;
- whether economics actually change;
- confidence.

## Trend Categories

Search across:

- demand behavior;
- price;
- capacity/supply;
- regulation;
- technology;
- distribution;
- capital/funding;
- consolidation;
- labor;
- standards;
- customer procurement;
- substitution;
- geography/trade.

## Catalyst Test

A catalyst matters only if it changes at least one of:

- number of buyers;
- willingness to pay;
- cost to serve;
- capacity;
- access/distribution;
- regulation;
- competitive advantage;
- capital requirement;
- switching cost.

## Signal Strength

Classify:

- **structural:** mechanism likely persists;
- **cyclical:** tied to a recurring economic cycle;
- **policy-driven:** depends on rule/subsidy/enforcement;
- **company-specific:** not industry-wide;
- **speculative:** narrative ahead of evidence.

## Leading Indicators

Choose indicators that move before headline revenue where possible:

- orders/backlog;
- utilization;
- price/discounts;
- inventory;
- job postings;
- lead times;
- permits/licenses;
- capacity announcements;
- churn/renewal;
- app/search/channel activity;
- procurement notices;
- default/claims;
- funding conditions.

The final report should include a watchlist rather than pretending one snapshot stays current forever.
