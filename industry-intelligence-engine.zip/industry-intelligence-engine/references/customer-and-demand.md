# Customer and Demand

## Separate Roles

Never use “customer” as one blob when roles differ:

- user;
- beneficiary;
- economic buyer;
- evaluator;
- procurement;
- approver;
- blocker;
- renewal owner.

## Demand Trigger

Identify the event that creates urgency:

- breakdown;
- compliance deadline;
- growth threshold;
- hiring shortage;
- cost shock;
- life event;
- replacement cycle;
- new budget;
- platform change;
- competitive pressure.

No trigger often means weak conversion even when interest is high.

## Buying Journey

Map:

**trigger → discovery → trust formation → shortlist → proof → procurement → purchase → onboarding → usage → renewal/repeat → referral/churn.**

At every step identify friction, evidence needed and responsible actor.

## Willingness to Pay

Prefer behavioral evidence:

- actual purchases;
- renewal;
- upgrade;
- paid pilots;
- procurement budgets;
- channel conversion;
- switching behavior.

Stated interest is weaker evidence.

## Segmentation

Segment by economic behavior, not demographics alone. Useful dimensions include:

- urgency;
- frequency;
- budget;
- switching cost;
- workflow complexity;
- compliance exposure;
- sophistication;
- geography;
- service level;
- channel preference.

## Distribution

Identify how demand reaches suppliers:

- direct sales;
- search;
- marketplaces;
- distributors;
- referrals;
- agents/brokers;
- retail;
- app stores;
- procurement lists;
- partnerships;
- creators/media;
- embedded distribution.

Then ask who owns the customer relationship and who can change acquisition economics.

## Retention and Churn

Distinguish:

- satisfaction;
- inertia;
- contract lock-in;
- integration cost;
- habit;
- genuine differentiated value.

Retention caused by friction is economically useful but strategically fragile if switching becomes easier.
