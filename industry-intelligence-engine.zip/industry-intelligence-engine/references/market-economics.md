# Market Economics

## Start With the Transaction Unit

Before estimating market size, identify what is actually sold:

- seat/month;
- procedure;
- ton;
- shipment;
- project;
- hour;
- policy;
- impression;
- reservation;
- square meter;
- device;
- subscription;
- commission-bearing transaction.

## Revenue Mechanics

Map:

**volume × price × frequency × take rate / attach rate / utilization**, as applicable.

Then identify one-time vs recurring revenue, contract duration, discounting, rebates, financing and seasonality.

## Unit Economics

Use the smallest economically meaningful unit. Determine:

- revenue per unit/customer/order/project;
- direct variable cost;
- gross/contribution margin;
- acquisition cost;
- service/implementation cost;
- retention/repeat;
- failure/return/default/warranty burden;
- capital tied up;
- time to cash.

## Cost Stack

Separate:

1. materials/input;
2. direct labor;
3. channel/distribution;
4. logistics;
5. compute/energy;
6. warranty/returns/loss;
7. sales and marketing;
8. compliance;
9. overhead;
10. financing/working capital;
11. capex/depreciation where relevant.

## Market Size

Prefer bottom-up when feasible:

**addressable units × annual usage × realized price**.

Cross-check against top-down figures only after definitions align.

Never combine incompatible estimates simply to create a “consensus.”

## Profit Pools

Ask where economics improve structurally because of:

- scarcity;
- switching cost;
- proprietary distribution;
- regulation/license;
- data advantage;
- scale purchasing;
- network density;
- standard ownership;
- recurring workflow integration;
- brand/trust;
- low marginal cost.

## Pain Pools

Find recurring economic leakage:

- delays;
- idle capacity;
- rework;
- returns;
- fraud;
- waste;
- compliance labor;
- low conversion;
- fragmented procurement;
- manual reconciliation;
- information asymmetry;
- avoidable financing cost.

Profit opportunity is often adjacent to a pain pool, but only if someone has budget and switching is feasible.

## Sensitivity

Identify 2–4 variables that dominate economics. Test the recommendation when each moves materially.

Do not bury sensitivity inside a single average-case forecast.
