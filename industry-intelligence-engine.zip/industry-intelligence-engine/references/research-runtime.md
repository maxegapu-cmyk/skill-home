# Research Runtime

## Objective

Convert an industry model into a sequence of searches and checks that reduce decision-relevant uncertainty quickly.

## Phase 1 — Orientation

Search just enough to learn the vocabulary, category boundaries, key metrics, major subsegments, common transaction forms and obvious participants.

Output internally:

- canonical and alternative names;
- common abbreviations;
- major subsegments;
- transaction unit;
- likely source owners;
- initial contradictions.

Do not write conclusions yet.

## Phase 2 — Source Plan

For each major claim, assign the most suitable evidence owner before searching.

Examples:

- regulation → regulator / statute / official guidance;
- public-company revenue → filing / earnings material;
- technical capability → standard / original documentation / technical test;
- price → current vendor/market quote relevant to the buyer;
- market population → official statistics or transparent methodology;
- buyer pain → behavioral evidence, procurement records, churn/review patterns, interviews;
- failure rate → regulator, insurer, court, recall, bankruptcy or defensible sample where available.

## Phase 3 — Parallel Evidence Lanes

Run independent lanes where possible:

1. industry structure;
2. customer/demand;
3. economics;
4. competition/power;
5. operations/technology;
6. regulation/risk;
7. current changes;
8. failures/counterevidence.

Keep each lane focused on questions, not websites.

## Phase 4 — Freshness Windows

For dynamic claims, research three windows:

- **0–30/90 days:** very recent developments when the sector moves quickly;
- **12–24 months:** regime and momentum;
- **structural history:** long enough to understand cycles and base rates.

The exact windows should match the industry's speed.

Always distinguish:

- event date;
- publication date;
- data period;
- retrieval/cutoff date.

## Phase 5 — Independence Check

Before treating multiple sources as triangulation, ask whether they share:

- one press release;
- one survey;
- one analyst estimate;
- one government dataset;
- one company claim;
- copied syndication.

If yes, count them as one evidence path.

## Phase 6 — Contradiction Resolution

When numbers disagree:

1. compare definitions;
2. compare geography;
3. compare period;
4. compare nominal vs real / revenue vs GMV / shipments vs installed base / registered vs active;
5. inspect who funded or produced the estimate;
6. prefer transparent methodology;
7. preserve a range if the disagreement is legitimate.

Do not average incompatible numbers.

## Phase 7 — Practitioner Reality

Use practitioner or community evidence for questions they are well-positioned to answer:

- workflow friction;
- tool reliability;
- sales cycle texture;
- implementation pain;
- hidden labor;
- common workarounds;
- customer objections;
- operational failure patterns.

Do not use anecdotal discussion to establish population rates without stronger evidence.

## Phase 8 — Counterfactual Search

Search the inverse of the emerging thesis.

If the thesis is “demand is exploding,” search for cancellation, utilization, inventory, price pressure and failed entrants.

If the thesis is “high margins,” search for channel fees, warranty, returns, labor, financing, working capital and hidden delivery cost.

If the thesis is “strong moat,” search for switching, multi-homing, open standards, low-cost clones and buyer concentration.

## Phase 9 — Gap Closure

Create a short list of unresolved claims ranked by:

**decision impact × uncertainty × ease of verification.**

Search the highest product first. Stop broad browsing.

## Phase 10 — Synthesis

Organize final findings by causal question:

- why does demand exist?
- where does value get created?
- where does money get captured?
- where does power sit?
- what constrains supply or growth?
- what is changing?
- why do entrants fail?
- where can a new entrant wedge in?

The final report is not a browsing diary.
