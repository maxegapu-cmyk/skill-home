# Evidence Discipline

## Evidence Hierarchy Is Claim-Specific

There is no universal “best website.” Match evidence to the claim.

### Strong direct evidence often includes

- statutes, regulators and official datasets;
- audited filings and formal company disclosures for company-owned facts;
- standards and original technical documentation;
- original research with visible methodology;
- current transaction/pricing evidence when price is the question;
- procurement documents and contracts when buying requirements are the question.

### Valuable but contextual evidence

- reputable trade analysis;
- high-quality journalism;
- earnings calls and practitioner interviews;
- customer reviews and community discussion;
- job postings;
- distributor catalogs;
- channel data;
- court, recall and enforcement records.

Use them for what they can establish, not for claims beyond their reach.

## Claim Ledger

For material claims record:

| Claim | State | Evidence owner | Independent check | Date/period | Scope | Confidence | What could falsify it |
|---|---|---|---|---|---|---|---|

## Fact vs Inference

A good synthesis may contain strong inference. Label it.

Example:

- Fact: three large buyers account for most disclosed revenue.
- Inference: supplier bargaining power is weak.
- Unknown: whether undisclosed long-term contracts reduce that power.

## Freshness

Use a fresh check for:

- prices;
- laws and regulation;
- market shares;
- company leadership;
- product capabilities;
- availability;
- adoption metrics;
- funding conditions;
- recent news;
- platform rules;
- standards under active revision.

Evergreen sources can explain mechanisms but cannot prove a current state.

## Estimate Discipline

A market estimate is usable only if the unit is defined.

Record:

- what is counted;
- geography;
- period;
- revenue/GMV/shipments/users/capacity/installed base;
- nominal/real currency;
- included/excluded segments;
- forecast vs observed;
- methodology.

If the method is opaque, treat precision skeptically.

## Counterevidence

For every major attractive claim, search one credible failure channel.

Examples:

- growth → price pressure / churn / utilization;
- high margins → hidden delivery or channel cost;
- low competition → substitutes / DIY / incumbents bundling;
- strong demand → procurement delay / low conversion;
- regulation tailwind → implementation burden / enforcement lag;
- automation benefit → integration cost / liability / customer resistance.

## Confidence

- **HIGH:** direct and relevant evidence, important conflicts resolved;
- **MEDIUM:** credible evidence with material limitation;
- **LOW:** indirect, stale, weak or single-path evidence;
- **UNKNOWN:** insufficient evidence.

Never hide a contested claim behind fluent prose.
