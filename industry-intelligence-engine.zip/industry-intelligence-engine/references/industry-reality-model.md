# Industry Reality Model

Use this before large-scale search. The objective is not to fill every box; it is to expose the causal structure that must be verified.

## 1. Boundary

Write a one-sentence operational definition:

> This industry earns money by [activity] for [buyer/user], using [core capability/asset], and excludes [adjacent but economically different categories].

Then list subsegments by the dimension that actually changes economics: customer type, product form, price tier, channel, technology, geography, regulation, or asset intensity.

## 2. Existence Logic

Trace:

**underlying problem → existing alternatives → why alternatives fail → industry solution → willingness to pay.**

If the problem disappears when a subsidy, platform rule or temporary event disappears, mark that dependency.

## 3. Value Chain

Construct the minimum chain from upstream inputs to final outcome. For each node record:

- input;
- transformation;
- output;
- buyer;
- seller;
- key asset/capability;
- margin logic;
- bottleneck;
- switching difficulty.

Do not assume the branded company owns the chain.

## 4. Three Flows

### Value flow
What physically or digitally reaches the end user?

### Money flow
Who invoices whom? Who prepays? Who finances inventory or receivables? Who takes a commission? Who bears refunds, warranty, defaults or waste?

### Information flow
Who sees demand first? Who controls ranking, leads, data, standards, referrals, procurement requirements or customer identity?

Information-flow control can create power even without owning production.

## 5. Roles and Power

For every actor ask:

- what scarce resource do they control?
- how easily can others bypass them?
- how concentrated are alternatives?
- can they raise price, fees or requirements without losing volume?
- can they vertically integrate?
- what dependency do they impose on the rest of the system?

## 6. Customer System

Separate:

- beneficiary;
- user;
- economic buyer;
- evaluator;
- procurement gatekeeper;
- approver;
- blocker;
- renewal decision maker.

Map trigger → discovery → shortlist → proof → purchase → onboarding → use → renewal/repeat → churn.

## 7. Offer System

Record:

- core product/service;
- complements;
- bundles;
- service layer;
- warranty/guarantee;
- pricing unit;
- contract length;
- discount mechanism;
- upsell/cross-sell;
- replacement cycle.

## 8. Economics

Select metrics that match the archetype. Examples:

- manufacturing: utilization, yield, scrap, throughput, inventory turns, ASP, gross margin;
- SaaS: ARR/MRR, gross retention, net retention, CAC, payback, gross margin, seat/use expansion;
- marketplace: GMV, take rate, liquidity, repeat, subsidy, contribution margin;
- services: billable utilization, realization, labor leverage, project gross margin, repeat/referral;
- retail: traffic, conversion, basket, gross margin, inventory turns, markdown, return rate;
- content: reach, watch time, ad load, CPM, conversion, rights cost, hit rate;
- finance: spread/fees, loss ratio/default, capital requirement, acquisition cost, retention;
- logistics: load factor, route density, empty miles, dwell time, asset turns, yield.

## 9. Constraint System

Identify the few constraints that cap industry output or economics:

- capital;
- licenses;
- land/location;
- skilled labor;
- trust/brand;
- distribution;
- data;
- standards;
- supplier concentration;
- compute/energy;
- customer integration burden;
- regulatory approval;
- physical throughput.

## 10. Structural Map

Finish the pre-research model with four lists:

### Profit pools
Where does durable economic surplus accumulate?

### Pain pools
Where are cost, delay, frustration, compliance or risk repeatedly absorbed?

### Control points
What nodes can gate access or change economics?

### Unknowns
What remains unknown and could reverse the current interpretation?

The research runtime should target these unknowns first.
