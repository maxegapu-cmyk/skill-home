# Competition and Power

## Build the Competitive Set Correctly

Separate:

- direct substitutes;
- adjacent substitutes;
- internal/DIY solution;
- “do nothing”;
- bundled alternatives;
- upstream/downstream vertical integration.

The most dangerous competitor may not sell the same product.

## Map Player Types

Classify participants by economic role, not just brand:

- scaled incumbent;
- specialist;
- low-cost provider;
- premium/trust provider;
- platform/gatekeeper;
- infrastructure supplier;
- channel owner;
- vertical integrator;
- new technology entrant;
- fragmented local tail.

## Power Test

For each actor ask:

1. Can they raise price or fees?
2. Can counterparts switch easily?
3. Are alternatives concentrated?
4. Do they control scarce supply, customer access, data, licenses, standards or trust?
5. Can they bundle the function away?
6. Can they impose contract terms?
7. Can they integrate vertically?

## Moat Audit

Do not accept “brand,” “AI,” “data,” “network effect” or “scale” as a moat without mechanism.

A moat must explain:

**asset/capability → why hard to reproduce → why customers care → how it preserves economics → what can erode it.**

## Concentration

Where data permits, distinguish:

- market concentration;
- supplier concentration;
- buyer concentration;
- channel concentration.

A fragmented seller market can still be controlled by one channel.

## Competitive Movement

Track:

- price cuts;
- bundling;
- acquisitions;
- vertical integration;
- new distribution;
- standards changes;
- open-source/open-protocol substitution;
- capacity additions;
- geographic expansion;
- talent movement.

Interpret each move by which control point it attacks or strengthens.
