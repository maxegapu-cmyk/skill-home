# Operations and Technology

## Reconstruct the Work

Map the actual operating sequence from order/request to delivered outcome.

For each step record:

- actor;
- input;
- tool/system;
- time;
- queue/wait;
- quality check;
- failure mode;
- handoff;
- data created;
- cost driver.

## Capacity and Bottlenecks

Find what caps throughput:

- machine capacity;
- skilled labor;
- approvals;
- supply;
- logistics;
- compute;
- locations;
- customer onboarding;
- inspection/testing;
- sales engineering;
- working capital.

Do not assume the most visible work is the bottleneck.

## Technology Stack

Classify technology as:

1. core production;
2. workflow/ERP/CRM;
3. distribution/customer interface;
4. analytics/data;
5. compliance/security;
6. automation/AI;
7. infrastructure.

For each technology ask whether it changes:

- cost;
- speed;
- quality;
- capacity;
- risk;
- switching cost;
- distribution;
- willingness to pay.

If it changes none of these materially, it may be feature noise.

## AI / Automation Test

Do not write “AI will disrupt the industry” generically. Specify:

**task automated → baseline labor/time/error → new cost/quality → integration burden → liability → buyer acceptance → who captures the gain.**

Automation can lower supplier cost without increasing market price or supplier margin.

## Build vs Buy vs Partner

For entrants, identify which capabilities must be owned because they control:

- customer access;
- compliance;
- core quality;
- proprietary learning/data;
- critical economics;
- reliability.

Commodity capabilities should usually be rented or partnered first.

## Operational Reality Sources

Useful evidence can include manuals, job descriptions, procurement requirements, certification documents, implementation guides, customer complaints, practitioner discussions, technical tests, service-level terms and failure reports.
