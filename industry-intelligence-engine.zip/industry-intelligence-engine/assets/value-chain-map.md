# Value Chain Map

| Stage | Input | Work performed | Output | Seller | Buyer | Pricing basis | Margin driver | Bottleneck | Key risk |
|---|---|---|---|---|---|---|---|---|---|

## Flow annotations

### Value flow


### Money flow


### Information flow


### Financing / working-capital flow


## Control points

1.
2.
3.
