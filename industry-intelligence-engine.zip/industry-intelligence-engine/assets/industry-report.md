# Industry X-Ray Report

## 1. One-screen verdict

- **Industry in one sentence:**
- **Who pays whom:**
- **How money is made:**
- **Current direction:**
- **Best structural opportunity:**
- **Biggest trap:**
- **Cutoff:**
- **Overall confidence:**

## 2. 60-second explanation


## 3. Boundary and subsegments


## 4. Industry reality map

### Value chain

### Value flow

### Money flow

### Information flow

## 5. Customer and buying reality


## 6. Offer, pricing and economics


## 7. Competition and power


## 8. Operations, assets, labor and technology


## 9. Market structure and size


## 10. Regulation and failure modes


## 11. What changed recently

| Change | Event date | Evidence date | Structural/temporary | Winner | Loser | Confidence |
|---|---|---|---|---|---|---|

## 12. Profit pools and pain pools


## 13. Opportunity wedges


## 14. Entry playbook

1. Cheapest learning action:
2. Evidence targets:
3. Narrow first buyer:
4. Minimum viable offer:
5. First-customer route:
6. Proof metric:
7. Prerequisite:
8. Kill criteria:
9. Scale trigger:
10. Do not build yet:

## 15. Watchlist


## 16. Confidence, contested claims and unknowns


## 17. Evidence

Use the environment's supported citation format immediately after material claims.
