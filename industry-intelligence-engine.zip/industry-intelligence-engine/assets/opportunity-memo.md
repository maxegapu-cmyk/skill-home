# Industry Entry / Opportunity Memo

## Verdict

**Enter / Test narrowly / Watch / Avoid for now:**

## Why


## Opportunity 1

- Pain:
- Buyer:
- Existing workaround/spend:
- Why unresolved:
- Wedge:
- Distribution:
- Delivery model:
- Economic headroom:
- Defensibility path:
- Fatal risk:
- Cheapest validation:
- Kill criterion:

## Opportunity 2

- Pain:
- Buyer:
- Existing workaround/spend:
- Why unresolved:
- Wedge:
- Distribution:
- Delivery model:
- Economic headroom:
- Defensibility path:
- Fatal risk:
- Cheapest validation:
- Kill criterion:

## Non-opportunities that look attractive but are not

1.
2.
3.

## 30-day evidence plan

1.
2.
3.
4.
5.
