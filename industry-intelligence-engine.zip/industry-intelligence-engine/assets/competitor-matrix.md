# Competitor and Power Matrix

| Player/type | Target buyer | Offer | Pricing model | Distribution | Key asset/control point | Switching friction | Likely economics | Vulnerability |
|---|---|---|---|---|---|---|---|---|

## Non-obvious substitutes

- DIY/internal team:
- Bundled alternative:
- Adjacent technology:
- Do nothing:

## Gatekeepers

| Gatekeeper | What it controls | Dependency | Ability to change economics | Bypass route |
|---|---|---|---|---|
