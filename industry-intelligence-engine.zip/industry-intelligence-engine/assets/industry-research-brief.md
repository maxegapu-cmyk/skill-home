# Industry Research Brief

**Industry:**
**Primary job:** UNDERSTAND / ENTER / COMPETE / INVEST / SELL / OPERATE / CAREER / TRACK
**Geography:**
**Cutoff:**
**Time horizon:**
**Primary archetype:**
**Secondary archetype:**

## Material assumptions

-

## Decision-changing questions

1.
2.
3.
4.
5.

## Initial hypothesis map

| Area | Known | Hypothesis | Unknown | Why it matters |
|---|---|---|---|---|
| Boundary | | | | |
| Demand | | | | |
| Money | | | | |
| Power | | | | |
| Operations | | | | |
| Regulation | | | | |
| Current change | | | | |

## Evidence lanes

- Primary operating evidence:
- Independent checks:
- Counterevidence:
- Freshness checks:
