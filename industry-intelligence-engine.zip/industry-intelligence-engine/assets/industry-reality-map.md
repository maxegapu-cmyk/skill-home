# Industry Reality Map

## One-line definition


## Why it exists

**Problem → workaround → industry solution → willingness to pay**

## Value chain

`Input → Supplier → Producer/Operator → Channel/Platform → Buyer/User → Aftermarket`

## Value flow


## Money flow


## Information flow


## Power map

| Actor | Controls | Can be bypassed? | Leverage mechanism | Direction of power |
|---|---|---|---|---|

## Customer system

**Trigger → Discovery → Proof → Purchase → Onboarding → Use → Renewal/Repeat → Churn**

## Economics

- Transaction unit:
- Pricing unit:
- Key variable cost:
- Key fixed cost:
- Critical utilization/retention metric:
- Working-capital issue:
- Profit pool:
- Pain pool:

## Constraints

1.
2.
3.

## Current structural changes

1.
2.
3.

## Unknowns capable of changing the conclusion

1.
2.
3.
