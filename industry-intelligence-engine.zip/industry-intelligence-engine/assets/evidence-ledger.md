# Evidence Ledger

| ID | Claim | State | Evidence | Independent path | Event/data date | Publication date | Scope | Confidence | What could falsify it |
|---|---|---|---|---|---|---|---|---|---|
| E1 | | Verified fact / Inference / Hypothesis / Unknown / Contested | | | | | | | |
