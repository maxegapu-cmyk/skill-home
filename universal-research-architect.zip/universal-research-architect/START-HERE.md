# Universal Research Architect — 小白上手

## 安装（常见 Agent Skill 目录）

解压后保留整个 `universal-research-architect` 文件夹，不要只复制 `SKILL.md`。最终应看到：

`.../universal-research-architect/SKILL.md`

常见位置：
- Codex / 兼容 cross-runtime skills 的客户端：`~/.agents/skills/universal-research-architect/`
- Windows 对应：`%USERPROFILE%\.agents\skills\universal-research-architect\`
- Claude Code 的个人 Skill 也常放在：`~/.claude/skills/universal-research-architect/`

如果你的客户端有自己的 Skills 安装入口，以客户端入口为准。


你不需要会“提示词工程”。安装后直接用正常中文说需求即可。

## 最简单的用法

直接说：

> 帮我研究一下这个问题：[你的问题]。我不懂这个领域，请你自己决定怎么查、要比较什么、最后直接告诉我结论和下一步怎么做。

Skill 会自己判断：
- 要不要查最新资料；
- 要不要做问卷/访谈；
- 要比较哪些方案；
- 哪些事实需要一手来源；
- 哪些是推断或未知；
- 需要 FAST / STANDARD / DEEP 哪种深度。

## 你可以只给一句话

例如：
- “我要装修 90 平米老房，预算 15 万，帮我从零研究。”
- “给我设计一份食堂满意度问卷，我完全不会。”
- “研究这个行业值不值得做。”
- “比较这三个产品，长期用哪个最划算？”
- “这个网上流传的说法是真的假的？”

缺的信息如果不是关键阻塞项，系统会采用保守假设继续，而不是连续问你十几个问题。

## 想要更深

你可以补一句：

> 用 DEEP 深度，重点找反例、失败案例、隐藏成本和会推翻结论的证据。

## 想要一份正式报告

说：

> 最后给我一份可以直接发给别人看的调研报告，结论先行，事实和推断分开，关键事实带来源，写清楚不确定项。

## 想自己控制范围

给这些信息会更准：
- 地区；
- 时间范围；
- 预算；
- 最在意的目标；
- 明确不能接受的条件；
- 最终要做什么决定。

不知道也没关系，直接开题即可。
