#!/usr/bin/env python3
"""Validate the Universal Research Architect skill package.

Standard-library only. Run from anywhere:
    python scripts/validate_skill.py
or:
    python /path/to/universal-research-architect/scripts/validate_skill.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
MAIN = SKILL_ROOT / "SKILL.md"
EXPECTED_NAME = "universal-research-architect"
REQUIRED = [
    "SKILL.md",
    "START-HERE.md",
    "references/core-method.md",
    "references/evidence-sources.md",
    "references/output-and-qa.md",
    "references/survey-questionnaire.md",
    "references/interviews-qualitative.md",
    "references/market-industry.md",
    "references/renovation-projects.md",
    "references/purchase-comparison.md",
    "references/academic-research.md",
    "references/fact-checking.md",
    "references/data-synthesis.md",
    "assets/research-brief.md",
    "assets/evidence-matrix.md",
    "assets/questionnaire-template.md",
    "assets/interview-guide.md",
    "assets/comparison-matrix.md",
    "assets/research-report.md",
    "assets/decision-memo.md",
    "assets/renovation-research-board.md",
    "assets/quick-prompts.md",
    "scripts/validate_skill.py",
]


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end == -1:
        return {}
    data: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if ":" not in line or line.startswith(" "):
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip().strip('"').strip("'")
    return data


def validate() -> list[str]:
    errors: list[str] = []

    if SKILL_ROOT.name != EXPECTED_NAME:
        fail(errors, f"directory name must be {EXPECTED_NAME!r}, got {SKILL_ROOT.name!r}")

    for rel in REQUIRED:
        if not (SKILL_ROOT / rel).is_file():
            fail(errors, f"missing required file: {rel}")

    if not MAIN.is_file():
        return errors

    text = MAIN.read_text(encoding="utf-8")
    fm = parse_frontmatter(text)
    name = fm.get("name", "")
    description = fm.get("description", "")

    if name != EXPECTED_NAME:
        fail(errors, f"frontmatter name must equal {EXPECTED_NAME!r}, got {name!r}")
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
        fail(errors, "frontmatter name must use lowercase letters/numbers and single hyphens")
    if not description:
        fail(errors, "frontmatter description is required")
    if len(description) > 1024:
        fail(errors, f"description exceeds 1024 characters ({len(description)})")
    if len(text.splitlines()) >= 500:
        fail(errors, f"SKILL.md must stay under 500 lines ({len(text.splitlines())})")

    link_re = re.compile(r"\[[^\]]+\]\(([^)]+)\)")

    for path in SKILL_ROOT.rglob("*"):
        if not path.is_file() or path.suffix not in {".md", ".py"}:
            continue
        body = path.read_text(encoding="utf-8")
        if path.suffix == ".md":
            for target in link_re.findall(body):
                if "://" in target or target.startswith("#"):
                    continue
                target_file = target.split("#", 1)[0]
                resolved = (path.parent / target_file).resolve()
                try:
                    resolved.relative_to(SKILL_ROOT.resolve())
                except ValueError:
                    fail(errors, f"relative link escapes skill root: {target} in {path.relative_to(SKILL_ROOT)}")
                    continue
                if not resolved.exists():
                    fail(errors, f"broken relative link: {target} in {path.relative_to(SKILL_ROOT)}")

    main_refs = set(re.findall(r"references/[A-Za-z0-9._-]+\.md", text))
    expected_refs = {p for p in REQUIRED if p.startswith("references/")}
    missing_routes = sorted(expected_refs - main_refs)
    if missing_routes:
        fail(errors, f"SKILL.md does not route to references: {', '.join(missing_routes)}")

    beginner_markers = ["one-sentence", "FAST", "STANDARD", "DEEP", "assumption"]
    for marker in beginner_markers:
        if marker.lower() not in text.lower():
            fail(errors, f"missing beginner/depth marker in SKILL.md: {marker}")

    return errors


def main() -> int:
    errors = validate()
    if errors:
        print(f"FAIL: {len(errors)} validation issue(s)")
        for item in errors:
            print(f"- {item}")
        return 1

    count = sum(1 for p in SKILL_ROOT.rglob("*") if p.is_file())
    print(f"PASS: {EXPECTED_NAME}")
    print(f"files: {count}")
    print(f"SKILL.md lines: {len(MAIN.read_text(encoding='utf-8').splitlines())}")
    print("external dependencies: none")
    return 0


if __name__ == "__main__":
    sys.exit(main())
