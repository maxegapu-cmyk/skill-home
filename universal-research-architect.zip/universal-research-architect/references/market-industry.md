# Market and Industry Research

## Purpose

Use for market sizing, industry structure, competitor mapping, trend analysis, entry decisions, strategic research, customer landscape, and “is this market worth entering?” questions.

A market report is only useful if its definitions and assumptions survive scrutiny.

## 1. Define the Market Before Measuring It

Write explicit boundaries:
- product/service definition;
- customer segment;
- geography;
- channel;
- timeframe;
- revenue vs units vs installed base;
- what is excluded.

“Home robots” may mean vacuum robots only, mobile assistants, lawn robots, companion robots, or all consumer service robots. Numbers cannot be compared until the definition matches.

## 2. Translate Strategy into Research Questions

For an entry decision, cover:

### Demand
- Who buys?
- What job/problem is being solved?
- How frequently?
- What willingness-to-pay evidence exists?
- Is demand stated, observed, subsidized, or repeat?

### Supply / competition
- major competitors;
- substitutes;
- pricing architecture;
- distribution;
- differentiation;
- switching costs;
- concentration and fragmentation.

### Economics
- gross-margin structure where knowable;
- acquisition/distribution cost;
- service/maintenance burden;
- capital requirements;
- return/refund/failure costs;
- recurring vs one-time revenue.

### Constraints
- regulation;
- standards;
- certification;
- supply-chain bottlenecks;
- platform dependence;
- labor/service network;
- IP or licensing exposure where relevant.

### Timing
- growth drivers;
- adoption bottlenecks;
- technology maturity;
- upcoming changes that can invalidate the thesis.

## 3. Market Sizing by Triangulation

Never accept one market-size headline if the number drives the decision.

Use at least two **independent estimation paths** when feasible.

### Top-down
Start with a credible broad total and narrow by clearly defined shares.

### Bottom-up
Examples:
- number of target households × plausible penetration × annual spend;
- units shipped × average selling price;
- locations × devices per location × replacement cycle;
- customer count × contract value.

### Company-revenue sanity check
Compare estimated market size against known or estimated revenue of major participants.

### Capacity / channel sanity check
Ask whether manufacturing, retail, installer, or service capacity could support the claimed size.

If estimates disagree, do not average automatically. Explain which assumption creates the gap.

## 4. Competitor Analysis

Do not create a feature spreadsheet with 40 rows unless those features change customer choice.

For each meaningful competitor capture:
- target customer;
- core value proposition;
- price model;
- distribution;
- strengths;
- weaknesses/failure patterns;
- switching/lock-in;
- evidence of adoption;
- strategic position.

Add substitutes and “do nothing” when they compete for the same budget/job.

## 5. Demand Evidence Ladder

Stronger evidence of demand generally moves from:
- stated interest;
- search/social attention;
- trial;
- paid purchase;
- repeat purchase/use;
- retention;
- expansion/referral;
- willingness to absorb price increases.

Do not treat social buzz as equivalent to durable demand.

## 6. Counterevidence Search

Actively seek:
- category failures;
- bankrupt or exited competitors;
- products with high returns;
- stalled adoption;
- subsidy dependence;
- negative unit economics;
- unmet service/repair needs;
- regulation that narrows deployment;
- customer complaints about the supposedly key benefit.

A credible market thesis should explain why prior failures do or do not apply.

## 7. Trend Discipline

Separate:
- cyclical fluctuation;
- one-off event;
- temporary subsidy;
- measurement change;
- genuine structural trend.

For time series, check whether definitions changed across years.

## 8. Entry Decision

Do not end with “the market is growing.” Produce a decision:

- **Enter now** — evidence supports demand and feasible differentiation.
- **Enter narrowly** — attractive segment exists, broad market thesis is weaker.
- **Run a validation experiment** — key uncertainty can be tested cheaply.
- **Wait** — timing/technology/regulation is unfavorable.
- **Do not enter** — economics or structural barriers dominate.

Include the variables that would reverse the recommendation.

## 9. Output Structure

1. conclusion;
2. market definition;
3. demand;
4. market size with triangulation;
5. competitor/substitute map;
6. economics;
7. risks and counterevidence;
8. scenarios;
9. decision and next validation step;
10. confidence.
