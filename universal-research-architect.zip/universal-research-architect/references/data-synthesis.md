# Data Interpretation and Evidence Synthesis

## Purpose

Use when the research contains tables, metrics, percentages, multiple datasets, estimates, conflicting numbers, rankings, survey results, or calculations that affect the conclusion.

## 1. Normalize Before Comparing

Check:
- units;
- currency;
- inflation basis;
- tax inclusion;
- timeframe;
- geography;
- population;
- product version;
- numerator/denominator;
- mean/median;
- nominal/real;
- cumulative/annualized;
- stock/flow.

Do not compare numbers just because both have the same label.

## 2. Reconstruct Definitions

For every important metric, write:

> Metric = numerator / denominator (or formula), measured for population P, geography G, period T.

This often explains apparent contradictions.

## 3. Sanity Checks

Use simple checks:
- order of magnitude;
- bounds (percentages 0–100 unless definition permits otherwise);
- totals vs components;
- market size vs company revenues;
- per-person/per-unit implications;
- growth rate vs start/end values;
- unit conversion;
- sample size vs claimed precision.

## 4. Missing Data

Identify whether missingness is:
- random-ish;
- related to the outcome;
- caused by nonresponse;
- caused by platform exclusion;
- censored/truncated;
- simply not reported.

Do not silently drop missing values if that can bias the result.

## 5. Percentages

Always ask “percentage of what?”

Distinguish:
- percentage points vs percent change;
- relative risk vs absolute risk;
- share of respondents vs share of responses;
- conversion among exposed users vs all users.

## 6. Weighted Scores

If comparing options with a weighted matrix:

- keep hard constraints outside the score;
- make weights visible;
- normalize scales consistently;
- avoid scoring unknown data as average without labeling the assumption;
- run sensitivity on influential weights.

## 7. Conflicting Estimates

Do not average blindly.

Build:
- definition table;
- assumptions table;
- estimation path;
- source independence;
- plausible range.

Choose the estimate best matched to the decision or report a range/scenarios.

## 8. Survey Results

Before interpreting:
- sample frame;
- recruitment;
- response rate if available;
- weighting;
- base size;
- question wording/order;
- subgroup denominator;
- uncertainty;
- mode effects where relevant.

Do not call a difference meaningful only because two percentages differ visually.

## 9. Scenario Analysis

When uncertainty is material, use at least:
- conservative case;
- base case;
- favorable case.

Change the few variables that actually drive the decision. Do not create decorative scenarios with dozens of arbitrary assumptions.

## 10. Output

For important quantitative research, show:
- cleaned/normalized metric;
- source/assumption;
- calculation;
- range/uncertainty;
- implication;
- sensitivity.

A reader should be able to reproduce the logic even if they cannot reproduce every source dataset.
