# Academic and Literature Research

## Purpose

Use for literature reviews, research proposals, state-of-the-art mapping, evidence reviews, paper comparison, and identifying research gaps.

Do not call ordinary web research a systematic review unless the process actually satisfies a defined systematic protocol.

## 1. Form the Research Question

Write a precise **research question** before collecting papers.

Useful structures depend on the field:
- population / intervention / comparator / outcome;
- phenomenon / context / mechanism;
- technology / task / benchmark / metric;
- theory / construct / relationship / boundary condition.

Define:
- population/context;
- exposure/intervention/phenomenon;
- outcome;
- timeframe;
- eligible study types;
- languages/geography if relevant.

## 2. Search Strategy

Build concept groups and synonyms rather than one long natural-language query.

Example concept groups:
- “AI-assisted teaching” synonyms;
- learner age/education level;
- learning outcomes;
- controlled/experimental study terms.

Search multiple appropriate databases or indexes when available. Record:
- database/source;
- search date;
- query;
- filters;
- number screened where feasible.

For a lightweight narrative review, state that the search is targeted rather than systematic.

## 3. Inclusion and Exclusion Criteria

Define **inclusion** and **exclusion** before selecting studies when rigor matters.

Possible inclusion criteria:
- relevant population;
- defined intervention/exposure;
- reports target outcome;
- peer-reviewed or otherwise justified evidence type;
- within timeframe;
- required language.

Possible exclusion criteria:
- wrong population;
- opinion/editorial without data when empirical evidence is required;
- duplicate dataset;
- inaccessible methods;
- outcome mismatch;
- obsolete version when technology changed materially.

Do not quietly change criteria to keep a favorite paper.

## 4. Track Study Identity

Watch for multiple papers using the same dataset or cohort. They are not independent replications.

Record:
- citation;
- year;
- study design;
- sample;
- setting;
- intervention/exposure;
- comparator;
- outcome;
- result;
- limitations;
- funding/conflicts if relevant;
- dataset overlap.

## 5. Assess Study Quality

Evaluate **study quality** relative to design.

Consider:
- selection bias;
- control/comparison quality;
- randomization/blinding where applicable;
- measurement validity;
- missing data/attrition;
- confounding;
- statistical power;
- multiple testing;
- preregistration/protocol adherence where relevant;
- outcome switching;
- external validity;
- reproducibility/replication.

Do not reduce all quality judgment to journal prestige.

## 6. Distinguish Effect from Significance

Record:
- effect direction;
- effect size where available;
- uncertainty interval;
- practical importance;
- statistical significance;
- heterogeneity.

A tiny statistically significant effect may be practically unimportant. A non-significant study may still be compatible with meaningful effects if underpowered.

## 7. Synthesize by Claim

Group papers around claims/questions, not one paragraph per paper.

For each claim:
- what higher-quality studies show;
- what lower-quality studies add;
- consistency/heterogeneity;
- plausible reasons for disagreement;
- where evidence is missing.

For quantitative synthesis, do not invent a meta-analysis from incompatible summary statistics.

## 8. Identify a Real Research Gap

A **gap** is not simply “few papers exist.” Useful gap types:

- population gap;
- measurement gap;
- mechanism gap;
- replication gap;
- boundary-condition gap;
- longitudinal gap;
- implementation gap;
- contradictory evidence unresolved;
- technology/version gap;
- geographic/cultural transfer gap.

A good gap statement says why filling it changes theory, practice, or interpretation.

## 9. Avoid Common Literature Review Errors

- citation chain without reading the original claim source;
- review article cited for a detail that the original study contradicts;
- conference preprint and final paper counted as two studies;
- same dataset counted multiple times;
- publication year treated as study year;
- correlational result written as causation;
- “no evidence of effect” rewritten as “evidence of no effect”;
- current technology judged mainly from obsolete generations.

## 10. Output for a Beginner

For “帮我做文献综述”, provide:

1. research question and scope;
2. search approach and cutoff;
3. inclusion/exclusion criteria;
4. study map/table;
5. findings by theme/claim;
6. study quality and contradictions;
7. research gaps;
8. implications;
9. limitations of the review;
10. references/citations.

State explicitly whether it is a rapid/narrative/structured/systematic-style review and what that label means in this context.
