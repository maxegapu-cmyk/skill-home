# Output and Quality Assurance

## Pick the Deliverable Before Writing

Choose the shortest artifact that fully serves the user.

### Decision answer
For a practical “what should I do?” question.

Structure:
1. recommendation;
2. why;
3. conditions that would reverse it;
4. key evidence;
5. risks;
6. next action.

### Research report
For a durable, shareable investigation. Use `../assets/research-report.md`.

### Decision memo
For executives/teams choosing among options. Use `../assets/decision-memo.md`.

### Evidence matrix
For auditability or complex conflicts. Use `../assets/evidence-matrix.md`.

### Questionnaire / interview guide
Use the relevant domain reference and asset.

## Report Architecture

A strong report normally contains:

### 1. Executive conclusion
State the answer, not the research journey.

### 2. Research question and scope
Include geography, timeframe, audience, definitions, major exclusions, and data cutoff when relevant.

### 3. Method
Explain what evidence types were used and important limitations. Do not inflate ordinary web research into a formal systematic review.

### 4. Findings by question
Organize by the user's decision criteria or research questions, not by website/source.

### 5. Conflicts and uncertainty
Show where evidence disagrees and what remains unknown.

### 6. Recommendation / implications
Translate evidence into action with conditions and thresholds.

### 7. Sources / evidence notes
Cite in the environment's supported format. Material factual claims should be traceable.

## Writing Rules

- Lead with the conclusion.
- Prefer concrete language over research jargon.
- Separate fact, inference, assumption, and recommendation.
- Do not bury bad news.
- Do not repeat the same finding in three sections for “completeness.”
- Tables are useful when they reduce comparison effort; do not use them for prose that reads better as prose.
- Use dates and units explicitly when ambiguity matters.
- Explain uncertainty in terms of decision impact.

## Decision Quality Gates

### Gate 1 — Question fidelity
Can a reader point to the exact question the report answered?

Fail if:
- topic drift occurred;
- a different easier question was answered;
- recommendations ignore the user's constraints.

### Gate 2 — Method fit
Did the method actually measure/establish what is claimed?

Fail if:
- a convenience poll is treated as representative;
- interviews are used to estimate prevalence;
- vendor claims are treated as independent performance evidence;
- anecdotes are used as population rates.

### Gate 3 — Evidence traceability
Can conclusion-driving claims be traced to evidence?

Fail if:
- citations support only adjacent background;
- source snippets are mistaken for source contents;
- unsourced precise statistics appear.

### Gate 4 — Freshness and scope
Are current claims current enough and relevant to the user's geography/version/population?

### Gate 5 — Counterevidence
Was the strongest credible contrary case checked?

### Gate 6 — Uncertainty honesty
Are unknowns and assumptions explicit where they can change the outcome?

### Gate 7 — Actionability
Does the reader know what to do next, what to verify, and when to choose differently?

## Confidence Summary Template

Use a compact summary when useful:

- **Overall confidence:** HIGH / MEDIUM / LOW / UNKNOWN
- **Strongest evidence:** …
- **Largest uncertainty:** …
- **Decision sensitivity:** “If X changes beyond Y, reconsider option A.”
- **What would upgrade confidence:** …

## Adversarial Final Review

Before finalizing DEEP research, attack the result:

1. If the recommendation were wrong, what is the most likely reason?
2. Which source has the strongest incentive to mislead or selectively present data?
3. Did multiple sources secretly share one upstream source?
4. Are we extrapolating beyond the studied population/version/location?
5. Did we mistake correlation, preference, or stated intent for behavior or causation?
6. What obvious alternative has not been compared?
7. Did the result depend too heavily on one assumption?

Fix material weaknesses; list the rest as limitations.

## Completion Standard

A result is ready when it is:

- **correctly scoped**;
- **methodologically fit**;
- **evidence-backed**;
- **counterevidence-aware**;
- **honest about uncertainty**;
- **usable for a decision or next step**.

More pages do not make it more rigorous.
