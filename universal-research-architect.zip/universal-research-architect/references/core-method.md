# Core Research Method

## 1. Translate a Topic into an Answerable Research Problem

A topic is not yet a research question.

Weak: “Research home renovation.”
Strong: “For a 90 m² owner-occupied apartment in a specific city, which renovation scope gives the best improvement in comfort and durability within the stated budget, and what technical/contractor risks must be controlled?”

Write a compact internal research brief:

- **Decision/output** — what must be chosen, understood, verified, or produced?
- **Audience** — who will use it and what do they know already?
- **Scope** — geography, timeframe, category boundaries, exclusions.
- **Constraints** — budget, deadline, compatibility, safety, policy, minimum requirements.
- **Decision criteria** — what will make option A better than B?
- **Unknowns** — what could reverse the conclusion?

If the user only supplied a topic, infer a practical decision question and state it briefly.

## 2. Match the Method to the Information Needed

Choose methods based on what could answer the question:

| Need | Better method |
|---|---|
| What rules/specifications officially apply? | Primary documents, standards, official data |
| What do people report feeling or preferring? | Survey, interviews, behavioral/user data |
| Why are people behaving this way? | Interviews/qualitative discovery, observational evidence, existing studies |
| How common is something? | Representative quantitative data or a defensible sample |
| Which product/project option is best? | Criteria matrix + verified specs + independent evidence + lifecycle analysis |
| Does a claim hold? | Claim decomposition + original source + independent verification + counterevidence |
| What does academic evidence show? | Structured literature search + study quality assessment + synthesis |
| What is a market likely worth? | Multiple estimation paths + scope definitions + primary/industry data + sanity checks |

Do not default to a survey when observation, transactional data, official records, interviews, experiments, or existing datasets answer the question better.

## 3. Build a Decision-Centered Question Tree

Only create branches that can change the answer. A useful tree often contains:

### A. What is it?
Definitions, scope, comparable alternatives, terminology.

### B. What is true now?
Current baseline, price, performance, usage, market, policy, technical constraints.

### C. Why does it happen?
Mechanism, incentives, causal hypotheses, user behavior, process constraints.

### D. What could go wrong?
Failure modes, downside, hidden costs, implementation bottlenecks, adverse cases.

### E. What are the options?
Realistic alternatives including “do nothing”, staged approach, substitute, outsource, postpone.

### F. What would change the decision?
Thresholds such as budget, defect rate, utilization, maintenance cost, market size, sample bias, regulatory change.

## 4. Search as a Sequence of Hypothesis Tests

Do not run random queries indefinitely.

### Pass 1 — Vocabulary and landscape
Goal: learn terms, major actors, official categories, competing interpretations.

### Pass 2 — Claim ownership
For each material claim, seek the source that directly owns or measures it.

Examples:
- product capability → current official specification/manual;
- company performance → filing/financial report;
- regulation → regulator/statute/standard;
- scientific effect → original study or high-quality synthesis;
- market statistic → organization that collected/defined the data.

### Pass 3 — Independent challenge
Search for people or organizations with different incentives or methods.

### Pass 4 — Negative search
Queries should include ideas such as:
- failure / defect / recall / complaint;
- criticism / limitation / bias;
- contradict / not effective / null result;
- hidden cost / maintenance / implementation problem;
- revised / retracted / corrected;
- local restrictions / exceptions.

### Pass 5 — Gap closure
Search only unresolved decision-driving questions.

## 5. Maintain an Evidence Ledger

Use `../assets/evidence-matrix.md` when the task is more than a quick answer.

For each material claim record:

- claim;
- evidence/source;
- source type;
- date and geography;
- direct vs indirect support;
- independence from other evidence;
- important method or incentive caveat;
- counterevidence;
- confidence;
- impact if wrong.

This prevents the common failure where a polished final report cannot be traced back to its evidence.

## 6. Separate Four Kinds of Uncertainty

Do not use one vague “uncertain” label.

### Measurement uncertainty
The data itself has error, missingness, sampling error, noisy measurement, or inconsistent units.

### Model/inference uncertainty
The data is real but the explanation or extrapolation is uncertain.

### Scope uncertainty
The evidence may not transfer to the user's geography, population, product version, building type, or timeframe.

### Future uncertainty
The current evidence is good, but prices, behavior, regulation, supply, or technology may change.

Name the kind that matters because the remedy differs.

## 7. Resolve Conflicts Instead of Averaging Them

When credible sources disagree:

1. Check whether they are answering the same question.
2. Normalize definition, timeframe, geography, units, sample, and version.
3. Compare data collection and methodology.
4. Check whether one source cites the other.
5. Check updates, corrections, revisions, and publication dates.
6. Identify incentives and selection effects.
7. If disagreement remains legitimate, preserve it and explain its decision impact.

Never “split the difference” solely because two numbers differ.

## 8. Make Recommendations Conditional Where Needed

Avoid pretending one answer fits every user.

Use decision rules:

- “Choose A if X is a hard constraint.”
- “Choose B if maintenance burden matters more than upfront price.”
- “Delay the project if the verified quote exceeds threshold Y.”
- “The conclusion reverses if assumption Z is false.”

A conditional recommendation is often more useful than an unjustified universal winner.

## 9. Research Stop Rule

Additional work is justified only when it can plausibly change:

- the conclusion;
- the confidence level;
- the implementation plan;
- the risk mitigation;
- a high-cost/irreversible decision.

If new sources merely repeat established background, stop and synthesize.
