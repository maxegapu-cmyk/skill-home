# Renovation and Real-World Project Research

## Purpose

Use for home renovation, construction planning, room redesign, materials, contractor comparison, budgets, sequencing, maintenance, acceptance, or other physical projects where bad research can create expensive rework.

This module is a research framework, not a substitute for on-site structural, electrical, gas, fire-safety, or code inspection.

## 1. Start with the Real Project

For a beginner, convert “我想装修” into a project brief:

- **location:** country/city and building context when rules/prices matter;
- property type, approximate age, area, occupancy;
- owner-occupied/rental/resale goal;
- target duration of use;
- budget and contingency tolerance;
- scope: cosmetic refresh vs partial vs full renovation;
- non-negotiables;
- known defects;
- desired finish/style;
- move-in deadline;
- tolerance for maintenance and disruption.

If location affects code, contractor market, price, climate, or material suitability, verify location-specific facts.

## 2. Separate Four Layers

### A. Safety / compliance
Structure, fire, electrical, gas, waterproofing, ventilation, required permits/inspection.

### B. Building performance
Moisture, insulation, acoustics, drainage, HVAC, lighting, durability.

### C. Function
Storage, circulation, outlets, task lighting, furniture clearances, accessibility, cleaning.

### D. Appearance
Color, texture, style, decorative finishes.

Never let appearance decisions hide unresolved safety or performance issues.

## 3. Existing-Condition Investigation

Before recommending materials or design, identify what must be inspected or measured:

- dimensions and level/plumb conditions;
- visible moisture/mold signs;
- plumbing layout and drainage;
- electrical capacity/circuit condition;
- wall/floor substrate;
- windows/air leakage;
- ventilation;
- structural modifications;
- previous concealed work;
- building/HOA/property restrictions where applicable.

Remote research can define the inspection checklist but cannot verify concealed conditions.

## 4. Scope the Work into Packages

Create work packages such as:
- demolition/protection;
- structural/opening changes;
- plumbing;
- electrical/low voltage;
- waterproofing;
- HVAC/ventilation;
- wall/ceiling;
- flooring;
- cabinetry/storage;
- doors/windows;
- fixtures/appliances;
- painting/finish;
- final commissioning/cleaning.

This makes quotes comparable and exposes missing items.

## 5. Budget with Lifecycle Cost

Do not compare only upfront price. Include **lifecycle** cost where it matters:

- purchase/material;
- labor/installation;
- preparation/substrate work;
- maintenance;
- consumables;
- energy/water;
- expected replacement interval;
- repair difficulty;
- downtime/disruption;
- disposal/rework risk.

Keep a contingency appropriate to uncertainty; do not hide contingency inside fake precision.

## 6. Material/Product Research

For each material or system, evaluate:

- intended use and limitations;
- compatibility with substrate/environment;
- performance standards and test conditions;
- moisture/heat/UV/abrasion exposure;
- installation requirements;
- maintenance;
- repairability;
- availability of matching replacement material;
- warranty conditions;
- independent field failure patterns.

Do not accept “zero”, “lifetime”, “maintenance-free”, “waterproof”, or similar absolute marketing terms without checking definitions and test conditions.

## 7. Contractor / Vendor Research

Compare contractors on more than price:

- legal/qualification requirements where applicable;
- insurance/guarantee structure where relevant;
- scope completeness;
- who performs subcontracted work;
- payment milestones;
- schedule realism;
- change-order process;
- material specification clarity;
- quality-control process;
- references/projects relevant to the same work type;
- warranty/remedy process;
- communication and documentation discipline.

### Quote normalization
Create the same bill/scope structure for every quote. Mark:
- included;
- excluded;
- allowance/provisional sum;
- unit rate;
- quantity assumption;
- brand/model/grade;
- tax/fees;
- disposal/protection;
- warranty.

The cheapest total is meaningless if scopes differ.

## 8. Sequence and Dependency Research

Map dependencies before setting the schedule.

Typical principle:
- investigate concealed conditions before closing them;
- rough services before finishes;
- waterproofing before finish surfaces in wet areas;
- inspections/tests before concealment;
- dirty/high-impact work before sensitive finishes;
- verify dimensions before ordering custom items.

Actual sequence depends on local practice and project design.

## 9. Change-Order Risk

List predictable causes:
- hidden damage discovered after demolition;
- ambiguous drawings/specs;
- owner decisions made late;
- unavailable materials;
- dimension mismatch;
- code/approval issue;
- contractor omission;
- scope creep.

For each, define who decides, how price is approved, and what documentation is required before work proceeds.

## 10. Acceptance Criteria

Define **acceptance** before construction, not after arguing about quality.

For each work package specify:
- what will be inspected;
- measurable criterion where available;
- visual/functional tolerance;
- test method;
- evidence/photo/document to retain;
- who signs off;
- when defects must be corrected.

Examples:
- waterproofing test before tile closure where local practice supports it;
- electrical test/documentation by qualified personnel;
- cabinet alignment, door operation, finish defects;
- plumbing leak/drain function;
- appliance commissioning.

Do not invent code tolerances; verify local standards or contract requirements.

## 11. Beginner Research Board

Use `../assets/renovation-research-board.md` and fill these sections:

1. project assumptions;
2. room-by-room needs;
3. existing-condition questions;
4. must-fix safety/performance issues;
5. material/product candidates;
6. contractor comparison;
7. budget + contingency;
8. sequence/dependencies;
9. acceptance checklist;
10. unresolved decisions and deadline.

## 12. Decision Rules

Use conditional recommendations:
- choose the cheaper material only if installation and maintenance risks remain acceptable;
- postpone decorative upgrades if concealed-condition uncertainty threatens budget;
- require professional verification before irreversible structural/electrical/gas work;
- stage work if scope uncertainty is high and staged investigation can reduce rework.

## 13. Red Flags

- price quote without normalized scope;
- major deposit disconnected from milestones;
- verbal-only change orders;
- finish work before concealed systems are tested;
- custom ordering before field dimensions are verified;
- “same quality” without model/grade/specification;
- absolute performance claims without test conditions;
- recommendation based on photos alone for concealed technical issues;
- no acceptance criteria until the end.
