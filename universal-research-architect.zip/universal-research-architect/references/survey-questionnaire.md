# Survey and Questionnaire Research

## Use This Module When

The user wants a questionnaire, survey, poll, satisfaction study, customer research form, employee survey, user-feedback instrument, or quantitative opinion/behavior measurement.

Do not start by writing questions. First decide whether a survey can actually answer the **research question**.

## 1. Define the Measurement Problem

Write these six items before drafting:

- **Research question:** what must the survey help establish or compare?
- **Target population:** exactly whose views/behaviors matter?
- **Construct:** what invisible thing is being measured (satisfaction, trust, intent, pain, awareness, frequency, etc.)?
- **Decision use:** what action will the result inform?
- **Sampling/recruitment:** who will be invited and how?
- **Analysis plan:** what comparisons or decisions will be made after responses arrive?

If any of these are unclear, infer a default when safe or ask only the minimum blocking question.

## 2. Check Whether a Survey Is the Right Method

A survey is useful for structured self-reports from many people. It is weaker when the real need is:

- observed behavior rather than stated behavior;
- detailed reasons and mental models;
- causal effects;
- technical compliance;
- facts already present in records/logs;
- rare expert judgments where interviews are better.

Recommend interviews, observation, experiments, logs, or existing data when they answer the question better.

## 3. Define Population and Sample Honestly

### Target population
Examples:
- all current university students using a campus;
- customers who purchased in the last 90 days;
- homeowners in one city who renovated within three years.

### Sampling frame
The actual list/channel from which people can be reached.

### Sampling method
State whether recruitment is probability-based, quota-based, convenience, panel, customer-list, social-media, intercept, or another design.

### Representativeness warning
Never claim a convenience sample “represents” the whole population merely because the response count is large.

Large biased samples can still be biased.

### Nonresponse
Ask who is less likely to answer and whether their absence could change the result.

## 4. Build the Construct Map

Break each construct into dimensions before writing items.

Example: “cafeteria dissatisfaction” may include:
- taste;
- price/value;
- waiting time;
- cleanliness;
- seating;
- opening hours;
- menu variety;
- staff interaction;
- dietary fit;
- perceived safety.

Do not confuse one broad label with one measurable thing.

## 5. Draft Questions with the One-Concept Rule

Each question should measure **one concept**.

Bad:
> “食堂价格和口味是否让你满意？”

This is double-barreled: price and taste can differ.

Better:
- “你对食堂餐品价格的满意程度如何？”
- “你对食堂餐品口味的满意程度如何？”

Question wording should be:
- clear;
- concrete;
- neutral;
- answerable from the respondent's knowledge or memory;
- appropriate to the target population's language level.

Avoid:
- leading language (“你是否也认为…”);
- loaded moral framing;
- unexplained technical terms;
- double negatives;
- vague frequency (“经常”) when a defined period works better;
- asking respondents to calculate things they cannot reliably recall.

## 6. Choose the Right Question Type

### Screener
Determines eligibility or routing.

### Behavior
Ask about actual behavior with a timeframe.
Example: “过去7天，你在学校食堂用餐多少次？”

### Experience
Ask about a specific recent experience rather than abstract attitude when possible.

### Attitude / agreement
Use carefully; agreement scales can invite acquiescence. Direct evaluative questions are often clearer.

### Rating
Keep anchors interpretable. Define what endpoints mean.

### Ranking
Use sparingly. Ranking many options creates burden and does not show magnitude of preference.

### Open-ended
Useful for discovery, unexpected issues, explanations, or collecting language for later closed-ended items.

## 7. Build Response Options Correctly

For closed-ended items, aim for options that are:

- **mutually exclusive** — one answer should not fit two categories;
- **collectively adequate** — reasonable answers should have somewhere to go;
- balanced where the construct has positive/negative direction;
- ordered when the categories are ordinal.

Use “其他（请说明）”, “不适用”, or “不知道/无法判断” only when conceptually appropriate.

Do not force a fake opinion from respondents who genuinely cannot know.

## 8. Control Question Order

Question order can change answers.

Recommended flow for many general surveys:

1. short engaging screener/context;
2. broad behavior/experience;
3. core outcome measures;
4. detailed diagnostic dimensions;
5. sensitive or high-burden items;
6. demographics/classification items unless needed earlier for routing.

Watch for:
- earlier questions priming later ones;
- answer options creating ideas respondents would not have generated themselves;
- asking satisfaction after listing a series of negative incidents;
- long blocks of near-identical rating items causing straight-lining.

Randomize unordered item lists when the survey platform supports it and order itself is not meaningful.

## 9. Design Skip Logic

For each screener, define:

- condition;
- branch;
- destination;
- what happens if data is missing.

Example:
- Q1 used cafeteria in last 30 days?
- If no → skip detailed meal experience; ask barriers/non-use reasons.
- If yes → ask frequency and recent experience.

Do not show irrelevant questions merely because they are easy to include.

## 10. Sensitive Questions

For income, health, sexual behavior, political views, illegal behavior, workplace conflict, or other sensitive topics:

- explain why the question is needed when appropriate;
- minimize unnecessary detail;
- provide appropriate nonresponse options;
- avoid shame-inducing wording;
- consider self-administered mode;
- collect only data needed for the research purpose.

## 11. Pretest Before Launch

A **pretest** is not optional for a new important questionnaire.

Check with a small set of target-like respondents:

- Can they paraphrase what each question means?
- Do they use the response options as intended?
- Are any terms confusing?
- Are they recalling the requested period correctly?
- Does skip logic work?
- Is the questionnaire too long?
- Do open-ended answers reveal missing response categories?

For higher-stakes work, use cognitive interviewing or a pilot field test.

## 12. Plan Analysis Before Fielding

The **analysis plan** should exist before launch.

For each important question, specify:

- metric to report;
- denominator;
- subgroup comparisons;
- weighting if any;
- treatment of missing/not-applicable responses;
- minimum base sizes for subgroup reporting;
- whether a result is descriptive, associative, or causal.

Do not invent causal language from an observational survey.

## 13. Beginner Questionnaire Build Sequence

For a user who says only “帮我做个问卷”, produce:

### A. One-paragraph study definition
Purpose, target population, decision use, assumed mode.

### B. Questionnaire blueprint
A table with sections, construct, question count, and why each section exists.

### C. Final questionnaire
Numbered questions with response options and skip logic.

### D. Pretest checklist
What to test before launch.

### E. Analysis sheet
How each core question will be summarized and compared.

### F. Limitations
Sampling and measurement limitations stated plainly.

Use `../assets/questionnaire-template.md`.

## 14. Red Flags

Reject or repair:
- two concepts in one question;
- “everyone knows…” framing;
- biased scales with more positive than negative options;
- overlapping age/income ranges;
- missing time windows for behavior;
- demanding precise memory beyond what respondents can know;
- very long matrix grids;
- demographic questions unrelated to analysis;
- collecting personally identifying information “just in case”;
- claiming representativeness without a defensible sampling design.
