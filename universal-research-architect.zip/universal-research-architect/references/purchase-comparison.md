# Product, Vendor, and Purchase Comparison

## Purpose

Use when the user asks “which one should I buy/use/choose?”, compares vendors or quotes, or needs a recommendation under real constraints.

The goal is not a feature dump. The goal is a **decision that still makes sense after costs, maintenance, failure modes, and uncertainty are included**.

## 1. Start with Hard Constraints

Write the **hard constraints** first. These are pass/fail requirements, not preferences.

Examples:
- maximum dimensions;
- compatibility;
- power/voltage;
- supported platform;
- budget ceiling;
- required certification;
- minimum capacity;
- delivery deadline;
- local service availability;
- accessibility needs.

Immediately eliminate options that fail a true hard constraint unless the user explicitly wants a workaround.

## 2. Separate Must-Haves from Preferences

Create three levels:

### Must-have
Failure means the option is not viable.

### Important
Materially affects value but can trade off.

### Nice-to-have
Useful only after must-have and important criteria are satisfied.

This prevents flashy extras from compensating for a critical weakness.

## 3. Define Weights from the User's Actual Use

Use **weights** only when they help clarify trade-offs. Do not pretend the math is objective.

A practical weighting process:

1. Ask/infer what the user does most often.
2. Identify what failures would be most annoying or costly.
3. Give larger weight to high-frequency/high-impact needs.
4. Keep “must-have” constraints outside the score.

Example:
- reliability 30;
- maintenance 20;
- performance 20;
- total cost 15;
- noise 10;
- appearance 5.

Explain that these weights encode the user's priorities.

## 4. Verify Specifications

For each option, separate:

- official specification;
- independent measured performance;
- observed long-term owner/service pattern;
- marketing claim;
- unknown.

Current models/versions/prices need current verification when possible.

Do not compare a laboratory maximum from one product with typical real-world performance from another.

## 5. Calculate Total Cost of Ownership

Use **total cost**, not sticker price alone.

Potential components:
- purchase price;
- required accessories;
- installation;
- consumables;
- subscription;
- energy;
- maintenance;
- replacement parts;
- expected service/replacement interval;
- resale/disposal;
- downtime or switching cost.

When exact values are unavailable, show a range and the assumption instead of fake precision.

## 6. Maintenance and Repairability

Explicitly research **maintenance**:

- frequency;
- cost;
- parts availability;
- user-serviceable vs professional service;
- cleaning burden;
- software/support lifetime;
- warranty process;
- service network;
- repairability;
- consumable lock-in.

A slightly worse benchmark performer may be the better long-term choice if it is easier to maintain and keep operating.

## 7. Failure-Mode Search

Search beyond positive reviews:

- recurring defect patterns;
- recalls;
- warranty disputes;
- battery degradation;
- software abandonment;
- consumable cost spikes;
- poor after-sales support;
- fit/compatibility failures;
- performance under edge conditions.

User reviews are useful for discovering patterns; verify high-impact claims with stronger evidence when possible.

## 8. Normalize Comparisons

Build `../assets/comparison-matrix.md` with the same units and conditions.

Normalize:
- currency;
- tax/shipping inclusion;
- capacity basis;
- test standard;
- product generation/version;
- warranty period;
- bundle contents;
- subscription assumptions.

## 9. Sensitivity Analysis

Perform **sensitivity** analysis when the winner depends on subjective weights or uncertain values.

Ask:
- If price mattered twice as much, would the winner change?
- If maintenance cost is at the high end, does the recommendation reverse?
- If the user uses the feature only weekly instead of daily, is the premium still justified?
- Which one or two assumptions control the ranking?

Report unstable rankings honestly.

## 10. Recommendation Types

Avoid forcing one universal winner. Useful outputs:

- **Best overall for this user**
- **Best low-cost option**
- **Best for lowest maintenance**
- **Best for performance**
- **Do not buy any yet** if an upcoming version, missing evidence, or compatibility uncertainty dominates.

## 11. Beginner Output

For a simple “A/B/C哪个好?” request, deliver:

1. one-line winner;
2. hard constraints check;
3. 5–8 criteria comparison;
4. total cost summary;
5. maintenance/failure summary;
6. who should choose each option;
7. sensitivity: what could change the winner;
8. confidence and missing data.

## 12. Red Flags

- score hides a failed hard constraint;
- dozens of low-value criteria dilute important differences;
- price from different regions/dates compared directly;
- affiliate/review site treated as independent without checking incentives;
- one dramatic user review treated as prevalence;
- current product confused with an older generation;
- claimed “best” without defining for whom.
