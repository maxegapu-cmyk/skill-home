# Interviews and Qualitative Research

## Purpose

Use qualitative methods when the user needs to understand **why**, **how**, language, mental models, unmet needs, decision processes, implementation realities, or unexpected failure modes.

Interviews are excellent for depth; they do not establish population prevalence by themselves.

## 1. Define the Qualitative Research Question

Examples:
- Why do students avoid a cafeteria even when prices are low?
- How do homeowners choose contractors and where do they lose confidence?
- What causes users to abandon onboarding?

Specify:
- target participant type;
- relevant experience window;
- key behavior or decision;
- what the team must learn;
- what decision the findings will inform.

## 2. Recruit for Information, Not Convenience Alone

Create participant segments based on the decision:
- users vs non-users;
- successful vs failed outcomes;
- beginners vs experienced users;
- high-frequency vs low-frequency customers;
- different budgets or project types.

Do not call a tiny convenience interview sample “representative.”

## 3. Build an Interview Guide, Not a Script Prison

Recommended sequence:

1. context and recent concrete experience;
2. behavior timeline;
3. decision points;
4. frustrations and workarounds;
5. alternatives considered;
6. trade-offs;
7. reactions to concepts only after unaided discovery;
8. wrap-up and missing issue.

Start from events, not abstract opinions.

Weak: “你觉得装修公司靠谱吗？”
Better: “回忆你最近一次筛装修公司的过程。你最开始看了哪些？在哪一步淘汰了谁？为什么？”

## 4. Ask Neutral Probes

Useful probes:
- “然后发生了什么？”
- “能举一个最近的例子吗？”
- “当时你怎么判断的？”
- “你为什么没有选另一个方案？”
- “这件事影响有多大？”
- “如果这个条件变了，你会怎么选？”

Avoid teaching the participant the answer you hope to hear.

## 5. Separate Stated Preference from Behavior

If someone says “价格最重要”, test against their actual decisions:
- What did they buy?
- What price differences did they accept?
- What feature caused them to pay more?

Treat stated importance as evidence about self-perception, not automatically as revealed behavior.

## 6. Capture Evidence Consistently

For each interview, capture:
- participant segment;
- relevant context;
- observed/reported behavior;
- key quote or paraphrase;
- pain point;
- workaround;
- trigger;
- decision criterion;
- contradictions;
- confidence in interpretation.

Protect privacy; avoid collecting irrelevant personal data.

## 7. Code by Meaning, Not by Favorite Quote

After several interviews:

1. list recurring themes;
2. list contradictory themes;
3. separate “mentioned often” from “caused behavior”;
4. identify segment differences;
5. identify extreme cases;
6. record hypotheses that need quantitative testing.

Do not cherry-pick the most dramatic quote.

## 8. Saturation and Stopping

Do not use a magical fixed interview count. Continue while new interviews still produce decision-relevant themes or reveal missing segments.

Stop when:
- core themes repeat;
- key segments are covered;
- new interviews mostly add examples, not new decision logic;
- remaining uncertainty needs another method such as a survey or behavioral data.

## 9. Deliverable

Use `../assets/interview-guide.md` and produce:
- research objective;
- participant criteria;
- interview guide;
- note-taking structure;
- synthesis themes;
- contradictions;
- hypotheses for validation;
- limitations.
