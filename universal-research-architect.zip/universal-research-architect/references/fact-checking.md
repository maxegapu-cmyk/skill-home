# Fact-Checking and Claim Verification

## Purpose

Use for rumors, screenshots, viral claims, marketing statements, “是真的假的?”, historical assertions, statistics, quotes, product claims, and disputed facts.

Fact-checking starts by defining exactly what is being claimed.

## 1. Decompose the Claim

Rewrite the **claim** into checkable parts:

- who/what;
- did/has/is;
- quantity or property;
- location;
- timeframe;
- implied causal or comparative meaning.

Example:
“这种板材零甲醛” may contain several claims:
1. the product emits no formaldehyde at all;
2. “zero” refers to added formaldehyde rather than measured emissions;
3. a specific standard/test threshold is met;
4. the statement applies under real installed conditions.

Do not verify a weaker claim and declare the stronger viral wording true.

## 2. Find the Original Source

Search for the **original source** of the assertion:

- full video/post rather than repost;
- original study rather than article summary;
- regulator notice rather than screenshot;
- company filing/manual rather than marketing paraphrase;
- complete quote/transcript rather than clipped sentence.

Record whether the viral version changed wording, date, image, or context.

## 3. Define Terms Before Ruling

Ambiguous words can make a claim appear true or false depending on **definition**.

Check definitions for:
- “zero”, “safe”, “natural”, “organic”, “effective”;
- “market share”, “profit”, “users”;
- “crime rate”, “risk”, “increase”;
- technical material/product terms;
- legal categories.

If two sides use different definitions, explain that before judging.

## 4. Verify the Primary Evidence

Ask:
- Does the original source actually say this?
- Does the underlying data support the number?
- Is the image/video from the claimed time/place?
- Is a test performed under relevant conditions?
- Has the source been corrected, updated, retracted, or superseded?

For current facts, use a current as-of date.

## 5. Seek Independent Confirmation

Use independent evidence appropriate to the claim:
- regulator/official record;
- original dataset;
- independent lab/testing;
- multiple firsthand records;
- peer-reviewed/technical evidence;
- reputable contemporaneous reporting.

Do not count copied articles as independent confirmation.

## 6. Search for Disconfirming Evidence

Run a deliberate **disconfirming** search:
- debunk;
- correction;
- contrary dataset;
- negative test;
- alternative explanation;
- earlier/later context;
- exception;
- version difference.

A fact-check that only searches for confirmation is incomplete.

## 7. Detect Common Manipulation Patterns

### True media, false caption
Old or unrelated image/video is relabeled.

### Cropped context
The quote is real but preceding/following context changes meaning.

### Correct number, wrong denominator
A percentage is technically correct but framed misleadingly.

### Real study, exaggerated conclusion
Association becomes causation; lab result becomes real-world guarantee.

### Version substitution
Older product/model/policy is used to describe the current one.

### Absolute-language inflation
“Below a test threshold” becomes “zero”; “lower risk” becomes “safe”.

## 8. Verdict Scale

Use a verdict that matches evidence:

- **TRUE** — core claim is supported as stated.
- **MOSTLY TRUE** — core is correct but wording omits an important qualification.
- **MIXED / CONTEXT-DEPENDENT** — different parts or definitions produce different answers.
- **MISLEADING** — uses real elements to imply something not supported.
- **MOSTLY FALSE** — small true element but core claim fails.
- **FALSE** — core claim is contradicted by strong evidence.
- **UNVERIFIED** — available evidence cannot establish it.

## 9. Output

1. **Verdict**
2. **Exact claim checked**
3. **What the original source shows**
4. **Independent evidence**
5. **Contrary/disconfirming evidence**
6. **Why the viral/marketing wording differs**
7. **Confidence**
8. **What remains unknown**

Do not force TRUE/FALSE when the correct answer is definition-dependent or unverified.
