# 魔法文风 · 写作 DNA v1.0.0

**用途**：学习目标作者的写作规律，用同类风格写出新的优质文章，再完成标题、封面文字、开场与分发包装。可持续记录和确认你的纠错，让文风资料包逐步改进。

这个 ZIP 是可用的写作 Skill + 本地工具，**不是自带大模型的自动写稿软件**。它会指导当前 ChatGPT / Claude / Codex 写稿；附带 Python 脚本负责可验证的文字统计、反馈账本和脱敏导出。写作好坏仍取决于模型、材料与人工反馈。

## 最短安装路径

**不需要 pip、不需要 API Key、不会联网。需要 Python 3.10 或以上。**

1. 解压本 ZIP 到任意文件夹（路径可包含中文）。
2. 在支持 Skill 的 AI 工具中，将本文件夹作为 Skill 添加，或将 `SKILL.md` 内容提供给 AI。
3. 在本文件夹打开命令行（Windows PowerShell 或 macOS Terminal），执行：

```bash
python scripts/magicstyle.py doctor
python scripts/magicstyle.py init --project "./我的文风项目" --name "作者A"
```

4. 将作者写的四篇长文分别放进 `我的文风项目/samples/`。第五篇如作盲测，放 `我的文风项目/holdout_PRIVATE/`（勿展示给负责生成的 AI）。文档仅支持 `.txt`、`.md`、`.markdown`，建议 UTF-8。
5. 执行 `python scripts/magicstyle.py analyze --project "./我的文风项目"`，检查生成的 `reports/style_evidence.md`。
6. 让 AI 按 `SKILL.md` 结合原文建立 `transfer-map.md`（一篇文章的统计并不代表作者的写作思想）。
7. 将本次创作的真实素材放进 `我的文风项目/inputs/资料.txt`，执行：

```bash
python scripts/magicstyle.py job --project "./我的文风项目" --topic "这次要写的话题" --facts "./我的文风项目/inputs/资料.txt" --platform "公众号" --audience "普通读者" --length 2500
```

8. 把生成的 `jobs/某个任务/mission.md` 交给 AI 写作，并让它参考真实作者原文、`transfer-map.md`。交付完整文章＋两个不同方向的标题和封面文案。

### 根据你的意见持续变强

```bash
# 提交一条具体纠错（默认待批准，不会乱改文风包）
python scripts/magicstyle.py feedback --project "./我的文风项目" --kind author_fidelity --scope opening --note "作者通常先落地具体问题再做判断，不会空泛宣布一个大道理。"
# 把上一条返回的 ID 放在这里，确认后才应用
python scripts/magicstyle.py approve --project "./我的文风项目" --id "刚才的ID"
python scripts/magicstyle.py analyze --project "./我的文风项目"
```

`--kind` 分三种：`author_fidelity`（作者相似性）、`writing_quality`（文章质量）、`packaging`（标题封面包装）。确认规则后必须重新 `analyze`，防止用过期资料。要撤回已批准建议，用 `retire --id "ID"`，历史仍会保留。

### 对照草稿与导出文风包

```bash
python scripts/magicstyle.py review --project "./我的文风项目" --draft "./我的文风项目/drafts/第一稿.txt"
python scripts/magicstyle.py export --project "./我的文风项目" --output "./作者A-写作DNA.zip"
```

`review` 只检查句/段长度、问号/感叹号和显式数字，不能算真正相似度，也不能核查事实。

`export` **默认只包含匿名统计，不包含反馈；显式允许才附带确认规则**，不含原始文章、文件名、原句、草稿、事实资料或用户反馈。包接收者如需高精度模仿，需要你另外提供经过授权的可用样本，或者提供独立的转移图摘要。不要把完整的 `我的文风项目/` 当作公开资料打包。

## 两个容易搞错的地方

**误区 1：「有4篇就一定能学到作者真实思维」。** 不对。只能观察作者在这些文章里的写作决策。跨题材、跨年代要谨慎；四五篇能用于启动，不保证高准确率。

**误区 2：「改得越多越强」。** 不对。有效的持续学习必须有反馈批准、版本留档和相同题目盲测。新的建议如果使文风不像或文章变难看，就撤回它。

## 包内文件

- `SKILL.md`：给 AI 的完整工作规则。
- `scripts/magicstyle.py`：纯标准库离线数据分析、反馈管理、任务卡、导出工具。
- `docs/STYLE_MAP_TEMPLATE.md`：写作转移图模板。
- `docs/BLIND_TEST.md`：作者风格与文章质量的盲测方法。
- `docs/PACKAGING_PLAYBOOK.md`：标题、封面、开头和平台包装实战。
- `docs/USER_FLOWS.md`：三种常见场景的操作与故障修法。
- `examples/`：原创的简单示例；**只是示范格式，不是训练数据**。
- `tests/`：自动化测试。
- `CHANGELOG.md`、`MANIFEST.json`：版本信息、包清单。

## 自检

```bash
python -m unittest discover -s tests -v
```

Windows 安装 Python 后如果 `python` 不存在，可试 `py -3`。如果中文文件编码不正确，请转存为 UTF-8。遇到错误请复制完整报错，不要反复重装。

## 外发原则

本包不含任何私人作者材料，不需要其他工程依赖、不包含在线上传接口。只发布这个程序 ZIP；个人文风工作区由使用者独立创建和保管。
