#!/usr/bin/env bash
# video-studio installer for macOS / Linux
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.claude/skills/video-studio"
mkdir -p "$HOME/.claude/skills"
rm -rf "$DEST" && cp -R "$HERE/skills/video-studio" "$DEST"
echo "skill copied -> $DEST"
python3 -m pip install --upgrade numpy pillow jieba edge-tts fonttools brotli "opencv-python-headless>=4.8,<5" opencc-python-reimplemented
if [ "$(uname)" = "Darwin" ] && [ "$(uname -m)" = "arm64" ]; then python3 -m pip install mlx-whisper; fi
echo "Mandarin ASR (recommended): python3 -m pip install funasr modelscope torch torchaudio"
command -v ffmpeg >/dev/null || echo "ffmpeg missing: brew install ffmpeg-full  |  sudo apt install ffmpeg"
python3 "$DEST/scripts/doctor.py"
