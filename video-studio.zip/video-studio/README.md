# video-studio · 在 Claude Code 里本地剪视频、做视频

一个 Claude Code 插件（skill），把三件事做成对话式流程：

| 模式 | 你说 | 它做 |
|---|---|---|
| **A 口播精剪** | “把这几段口播剪成 60 秒抖音竖屏” | 逐字转写 → 找重录、口误、语气词、长停顿 → 给方案等你确认 → 剪辑 + 推镜防跳切 + 中文大字幕 + 标题条 + BGM 自动避让 → 自检 → 出片 |
| **B 直播切片** | “这场 3 小时直播回放，切 8 条高光” | 按分钟生成直播“地图”（语速/音量/关键词★）→ 并行子代理找高光 → 列清单给你勾选 → 批量出片（冷开场钩子、标题、字幕、进度条）→ 封面 + 文案 |
| **C 代码生成动画** | “做一条 30 秒的以租代购成本对比讲解视频” | 写分镜脚本 → 配音（带逐字时间）→ 场景时长自动对齐口播 → HyperFrames 渲染数字滚动/柱状图/对比卡 → 合成字幕与音乐 |

另外还有：10 种内置动态卡片（价格牌、数字滚动、数据卡、清单、柱状图、人名条、结尾引导…），
16:9→9:16 人脸跟随裁切，封面自动选帧，抖音/视频号/小红书/B站导出。

## 吸收了哪些开源项目

- **browser-use/video-use**（2.8 万星）：让模型“读”视频的方法、剪辑硬规则、自检循环
- **heygen-com/hyperframes**（5.6 万星）：HTML 写画面、确定性渲染成 MP4（Apache-2.0，商用无门槛）
- **remotion-dev/skills**、**digitalsamba/claude-code-video-toolkit**、**op7418/Youtube-clipper-skill**
  详见 `skills/video-studio/CREDITS.md`。

在它们基础上新增：中文语音识别后端（FunASR）、长直播分块可续传转写、直播分钟地图、
批量切片 EDL、自动去气口/语气词、按字号自动断行的中文字幕（不拆关键词、不留孤字、遇剪辑点必断）、
帧精确时间线（几百刀也不漂字幕）、分段缓存（改一处只重渲一处）、BGM 侧链避让、两遍响度标准化、
自动 QC（时长/响度/爆音/闪帧/黑场/字幕溢出 + 接点联系表）、干净源帧封面、Windows 适配。

## 安装（Windows）

1. 准备：Python 3.10+、ffmpeg 完整版、（做动画需要）Node.js 22+
   ```powershell
   winget install Python.Python.3.12
   winget install Gyan.FFmpeg
   winget install OpenJS.NodeJS.LTS
   ```
2. 解压本包，在解压目录运行：
   ```powershell
   powershell -ExecutionPolicy Bypass -File install.ps1
   ```
   会复制到 `%USERPROFILE%\.claude\skills\video-studio`、安装依赖并运行自检。
3. 装一个语音识别（二选一）：
   ```powershell
   python -m pip install funasr modelscope torch torchaudio   # 中文最准，首次会下载约 1GB 模型
   python -m pip install faster-whisper                       # 有 NVIDIA 显卡时很快
   ```
4. 也可以作为插件安装：在 Claude Code 里 `/plugin marketplace add <解压目录>` → `/plugin install video-studio@video-studio`。

随时可以运行 `python %USERPROFILE%\.claude\skills\video-studio\scripts\doctor.py` 查看缺什么。

## 用法示例（直接对 Claude Code 说）

- “`D:\素材\0920口播` 里是今天录的口播，剪成 45 秒竖屏，去掉重录和口误，加大字幕，重点词标黄”
- “`D:\直播回放\0928.mp4` 切 6 条 30~60 秒的高光，标题条用红底，品牌名是喜相逢”
- “做一条 9:16 的数据讲解：本月线索 3560、成交 128、转化率 3.6%，男声配音，最后引导预约”
- “这条横屏视频转成竖屏，人脸跟随，出抖音和小红书两个版本，再做 3:4 封面”

Claude 会先看素材、提问、给方案，你确认后才开剪；每次出片前会自己跑 QC 并看接点联系表。

## 已验证 / 需要在你电脑上首次验证

已在构建环境中实测通过：入库分析、静音检测、打包阅读视图、时间轴图、EDL 吸附与去气口、
批量切片、多画幅渲染、转场、图片推镜、叠加卡片、Logo、音效、BGM 避让、响度 −14 LUFS、
中文字幕断行、QC、封面、平台导出、HyperFrames 构建 + check + 渲染、口播配音时长同步。

首次在你电脑上会真实跑到、构建环境里无法联网验证的：语音识别模型下载与识别（FunASR / faster-whisper）、
edge-tts 在线配音、HyperFrames 自动下载其固定版本 Chrome。若任何一步报错，把报错发给 Claude，
`references/troubleshooting.md` 里也有常见问题。

## 目录

```
.claude-plugin/          插件清单
install.ps1 / install.sh 安装脚本
skills/video-studio/
  SKILL.md               Claude 的工作流程与硬规则
  scripts/               16 个脚本（全部 --help 可查）
  references/            口播/切片/动画/字幕/音频/平台/子代理/排障 指南
  assets/vendor/         本地 GSAP（渲染不依赖 CDN）
```
