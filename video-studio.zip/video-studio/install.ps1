# video-studio installer for Windows (PowerShell):  powershell -ExecutionPolicy Bypass -File install.ps1
$ErrorActionPreference = "Stop"
$src  = Join-Path $PSScriptRoot "skills\video-studio"
$dest = Join-Path $HOME ".claude\skills\video-studio"
New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
Copy-Item -Recurse $src $dest
Write-Host "skill copied -> $dest"

$py = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $py) { Write-Host "Python not found: winget install Python.Python.3.12" -ForegroundColor Yellow; exit 1 }
python -m pip install --upgrade numpy pillow jieba edge-tts fonttools brotli "opencv-python-headless>=4.8,<5" opencc-python-reimplemented
Write-Host ""
Write-Host "Speech recognition (pick one):" -ForegroundColor Cyan
Write-Host "  python -m pip install funasr modelscope torch torchaudio   # best for Mandarin"
Write-Host "  python -m pip install faster-whisper                       # NVIDIA GPU or CPU"
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host "ffmpeg missing: winget install Gyan.FFmpeg   (full build: libass + zscale)" -ForegroundColor Yellow
}
python (Join-Path $dest "scripts\doctor.py")
