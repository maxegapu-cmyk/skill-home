# Mode A — 口播精剪 / talking head, tutorial, interview

Goal: from raw takes to a tight, watchable, captioned video that keeps the speaker's best delivery.

## Read the material

`takes_packed.md` shows every phrase with times. Look for:
- **Retakes**: the same sentence said 2+ times (often after `{嗯}` or a long pause). Default to the LAST complete
  take — speakers usually restart because the earlier one was wrong. Check with `timeline_view` if both are clean.
- **False starts / slips**: "今天给大家讲讲…不对，今天…" — cut to the restart.
- **Fillers**: `{嗯}{啊}{呃}` isolated by pauses → `edl_tools.py tighten --fillers` drops them. Fillers glued
  inside a phrase (gap < 60 ms) stay — cutting them sounds choppy.
- **Dead air**: pauses > 0.45 s inside a range → `tighten` closes them to ~0.18 s (`--keep-gap`).
- **ASR errors**: brand/product names, numbers → add to `captions.fixes` (and `--glossary` next time).
- **Peaks**: punchlines, numbers, laughs — protect the tail after them (≥ 0.3 s reaction).

## Structure

Short-form (抖音/视频号, 30–90 s): **hook in the first 2 s** (the most surprising claim/number, even if it's from
the middle — cold open), then problem → answer → proof → CTA. If the speaker opens with "大家好我是…", move
that later or cut it. Long-form tutorial: intro → steps → gotchas → recap; chapters as `titles`.

Archetypes (adapt or invent): 痛点→方案→证据→行动 · 结论先行→三个理由→总结 · 问题→误区→正确做法 ·
故事→转折→金句 · 对比 (买 vs 租) → 算账 → 建议.

## Cut craft

- Cut on silences ≥ 400 ms when possible; 150–400 ms boundaries are fine with a `timeline_view` check; < 150 ms
  is mid-phrase — avoid.
- **Jump cuts**: same framing on both sides of a cut reads as a glitch. Alternate `zoom` 1.0 ↔ 1.08–1.15 between
  consecutive ranges of the same shot (punch-in), or insert b-roll/a card over the cut.
- Breath room: 50 ms before the first word, 80–120 ms after the last (snap defaults). Fast social: tighter;
  documentary: looser.
- Speed: 1.05–1.15 on slow speakers is usually invisible and adds energy. Never on emotional moments.
- Keep laughs, "哈哈", applause — extend past them; the reaction is the beat.

## Packaging (what makes 口播 look professional)

- Captions: `bold` style + 2–4 `highlight` keywords (numbers, benefits) + 1 `emphasis` max per video.
- Title band (`titles`, top, 0–8 s or whole video) with the hook in ≤ 12 chars.
- Lower third (`cards.py --type lower_third`) at ~3 s for the speaker's name/role, 3 s long.
- Data moments → `cards.py` counter/price_tag/stat_cards overlay synced to the spoken number: start the overlay
  ~0.4 s before the word so it lands with it.
- B-roll: product shots over the explanation; screen recordings for tutorials (`overlays` with `position: full`
  or `ranges` inserts). Keep speaker audio running under b-roll (overlay, not a range).
- Grade: `bright_clean` for indoor/phone footage, `neutral_punch` default, `auto` when mixing cameras.
- `audio.voice_enhance: true` for phone/lav recordings with room noise. BGM at −18 to −22 dB with ducking.
- 16:9 source → 9:16: `reframe.py` (face crop) for single speaker; `blur` layout + top title band for
  screen/product content; render both via `variants` if both platforms matter.

## Checklist before presenting

Hook within 2 s · no retake duplicates (`edl_tools.py show`) · no mid-word cuts · captions fit (qc) ·
names spelled right · loudness ≈ −14 LUFS · end on a clear CTA or a clean last word (no clipped tail).
