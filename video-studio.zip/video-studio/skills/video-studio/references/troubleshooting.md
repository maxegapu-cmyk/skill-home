# Troubleshooting

| Symptom | Cause → fix |
|---|---|
| `No such filter: 'ass'` / captions missing | ffmpeg without libass. mac: `brew uninstall ffmpeg && brew install ffmpeg-full`; Windows: Gyan full build |
| Captions show boxes/tofu or wrong glyph shapes | no CJK font found or JP face chosen → `doctor.py`; set `VS_FONT=/path/font.ttf` or `captions.font` |
| iPhone footage looks washed out / neon | HDR (HLG/PQ) source; render.py tone-maps when ffmpeg has `zscale` (ffmpeg-full) |
| Audio drifts from video in a long render | VFR phone footage: add `"output": {"fps": 30}` (forces CFR) — already default when fps can't be read |
| Pop/click at a cut (qc warns) | cut lands on speech energy → move into a silence, or increase pad; check with `timeline_view --marks` |
| Caption wraps to two lines (qc warns) | lower `captions.max_chars`, shorten via `fixes`, or smaller `font_size` |
| Caption timing off by a word | ASR word timing drift (srt import is approximate) → re-transcribe with funasr/whisper or nudge range edges |
| Transcription is Traditional Chinese | Whisper sometimes does this → `pip install opencc-python-reimplemented` (auto-converts) |
| Brand names wrong in captions | `--glossary "名1,名2"` on transcribe + `captions.fixes` |
| FunASR first run is slow | downloads models (~1 GB) from ModelScope once; cached in ~/.cache/modelscope |
| faster-whisper on CPU is slow | use `--model small` for drafts, or mlx-whisper (Apple Silicon), or funasr for Mandarin |
| `motion.py render` → Chrome errors | `npx hyperframes doctor`; `npx hyperframes browser ensure`; behind a proxy set `HYPERFRAMES_BROWSER_PATH` |
| HyperFrames lint `font_family_without_font_face` | named font without local @font-face → use motion.py's subsetter or remove the family name |
| HyperFrames render is blank | timeline registered before it was built, or key ≠ `data-composition-id` |
| Overlay shows wrong part of an animation | it must be referenced from the EDL (render.py PTS-shifts it) — don't pre-trim |
| `.webm` overlay has black background | needs VP9 alpha (`--format webm` in HyperFrames); render.py forces the libvpx-vp9 decoder |
| Render slow | `--draft` while iterating; segments are cached, only changed ranges re-encode; final uses `medium` preset |
| Segment cache grows | delete `edit/cache/` any time |
