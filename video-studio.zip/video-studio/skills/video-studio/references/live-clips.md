# Mode B — 直播切片 / long-stream highlights

Goal: from a 1–6 h livestream (or podcast, webinar, meeting) to N short clips, each self-contained, with a
hook, captions, a title band, a cover and copy — rendered in one batch.

## 1. Ingest and map the stream

```
python ingest.py <dir>                         # or --url <回放链接>
python analyze.py <dir>                        # envelope + silences, streamed (fast, low memory)
python transcribe.py <dir> --glossary "品牌,车型,活动名"   # chunked at real silences, resumable
python pack.py <dir> --keywords "首付,月供,福利,…"        # add the stream's own vocabulary
```
Read `edit/overview.md`: one row per minute — speech rate (字/秒), loudness, ★ (energy or ≥2 keyword
hits), keywords, first words. It is a map, not a verdict.

## 2. Find candidates (parallelize long streams)

For streams > 90 min, spawn one **clip-scout sub-agent per ~60 min window** in parallel (brief in
subagents.md). Each reads `pack.py --show ID FROM TO` for its window and returns candidates as JSON.
For shorter streams do it yourself.

What makes a good clip (score each candidate on these, mentally):
1. **Self-contained**: understandable without context. Starts at the beginning of a thought, ends after the payoff.
2. **Hook**: the first 2 s make you stay — a number, a claim, a question, a conflict. If the best line is in the
   middle, use it as a cold open (`"hook": [start, end]` in clips.json → moved to the front).
3. **Payoff**: a concrete answer, a price, a reveal, a laugh, a strong opinion.
4. **Length**: 25–75 s for 抖音/视频号; up to 3 min for B站/YouTube. Shorter wins when in doubt.
5. **Typical goldmines in commerce/顾问直播**: price/finance breakdowns (首付/月供/总成本), objection handling
   ("会不会有隐藏费用？"), comparisons, audience Q&A answers, before/after demos, limited offers (but check the
   offer is still valid/compliant before publishing), funny or emotional moments.
6. **Avoid**: "扣1"/"点点关注" filler, waiting for viewers, reading usernames, unfinished thoughts, anything with
   private info (phone numbers, plates, faces of customers who didn't consent).

## 3. Confirm the list with the user (hard rule 9)

Present a numbered table: title · time range · length · hook line · why it works. Let them strike/add.
Use AskUserQuestion (multiSelect) when they're present.

## 4. Batch build

`edit/clips.json`:
```json
[{"id": "c01", "title": "1.9万首付怎么算出来的", "source": "live", "start": "1:02:11.2", "end": "1:03:05.0",
  "hook": ["1:02:48.0", "1:02:51.6"], "highlight": ["1.9万", "首付"], "cover_title": "1.9万首付\n开回家"}]
```
`edit/clip_style.json` — shared look (any EDL fields except ranges; `{title}` is substituted):
```json
{"output": {"aspect": "9:16"}, "grade": "bright_clean",
 "captions": {"style": "bold", "fixes": {"喜香逢": "喜相逢"}},
 "titles": [{"text": "{title}", "position": "top", "bg": "#E8322E"}],
 "progress_bar": {"color": "#FFD400"},
 "audio": {"voice_enhance": true, "bgm": {"file": "assets/bgm.mp3", "volume_db": -24}},
 "logo": {"file": "assets/logo.png", "position": "top-right", "width": 0.12}}
```
Then:
```
python edl_tools.py clips edit/clips.json --template edit/clip_style.json --outdir edit/clips
python render.py "edit/clips/*.json" --draft        # all clips, fast
for f in edit/out/*_draft.mp4; do python qc.py "$f"; done
```
`clips` snaps every edge to word boundaries and tightens dead air (> 0.6 s) and isolated fillers inside each
clip. Landscape stream → vertical: run `reframe.py` on each clip EDL if one person is on camera; otherwise
use `"reframe": "blur"` with `"fg_y": "upper"` so the title band sits above the picture.

## 5. Package

Per clip: `deliver.py cover edit/out/c01.mp4 --title "<cover_title>" --highlight "1.9万" --sizes 3:4,9:16`
and write `edit/deliver/copy.md` with, for each clip: 3 title options (≤ 20 chars, number or question first),
a 1–2 sentence description, 3–5 hashtags, and the best posting order. See platforms.md for the rules.

## Pitfalls

- Livestream audio is often quiet with loud music beds: `voice_enhance` + measure; if music in the source is
  loud, don't add BGM.
- ASR on noisy streams invents words — check names/numbers in captions before rendering finals.
- Mirrored front cameras flip text in the room; flip with `"grade": "hflip"` (raw filter) only if text is visible.
- Don't cut mid-sentence to hit a length target — pick a different end point.
