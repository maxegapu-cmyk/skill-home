# Sub-agent briefs

Sub-agents start with no context: every brief is self-contained, has absolute paths, and ends with
"Do not ask questions; if something is ambiguous, pick the most reasonable reading and say which."
Spawn independent ones in ONE message so they run in parallel.

## Clip scout (直播切片, one per ~60 min window)

```
You are scouting short-video clips in a livestream transcript window.
Read: python <skill>/scripts/pack.py <edit_dir> --show <ID> <FROM> <TO>
Context: <who is speaking, what the stream sells/teaches, target platform, clip length 25–75 s>
Find 3–8 candidates. Each must be self-contained (starts at the start of a thought, ends after the payoff),
have a hook in its first 2 s (or name a 2–4 s cold-open line from inside the clip), and a concrete payoff
(number, answer, reveal, laugh, strong opinion). Skip: 扣1/点关注 filler, waiting, reading usernames,
unfinished thoughts, private info.
Return ONLY JSON: [{"title": "<≤18 chars, number/question first>", "source": "<ID>", "start": <sec>, "end": <sec>,
"hook": [<sec>, <sec>] | null, "quote": "<first line>", "payoff": "<what the viewer gets>", "score": 1-10,
"why": "<one line>"}]
Times must come from the transcript phrase boundaries.
```

## Editor (multi-take 口播)

```
You are editing a <type> video from multiple takes. Pick the best take of each beat; assemble by beat, not by
file order. Inputs: <edit_dir>/takes_packed.md · context <2 sentences> · speaker <name, style> ·
structure <archetype> · slips to avoid <list> · target <seconds>.
Rules: start/end on phrase boundaries from the transcript; prefer silences ≥ 0.4 s; prefer the last complete
take of a repeated sentence; keep reactions after punchlines; if over budget, drop a beat rather than rushing.
Return ONLY a JSON array of ranges: [{"source", "start", "end", "beat", "quote", "reason"}] and a one-line
runtime total.
```
Then YOU run `edl_tools.py snap` and `show` on the result before rendering.

## Animation slot (one per card/scene/composition)

```
Build ONE animation: <spec in one sentence>. Nothing else.
Output: <absolute path>.mov (alpha) | .mp4 (opaque) — <W>x<H> @ <fps> fps, exactly <D> s.
Tool: python <skill>/scripts/cards.py <spec.json>   (or a HyperFrames project in <dir> using
<skill>/scripts/motion.py / hand-written HTML per <skill>/references/motion.md)
Style: <palette hex values>, font <path>, accent usage, region <upper/center>.
Timeline: <what appears when, with easing; final frame held ≥ 1 s>.
Anti-list: no extra titles, no logos, nothing in the bottom 25 % (captions live there).
Deliver: the file, ffprobe duration/size check, one frame PNG at the payoff moment, a 2-line report.
```

## Critic (published work)

```
You are a harsh short-video editor reviewing <path to render> (and <reference videos> if any) against the EDL
<path>. Do not praise. Use: python <skill>/scripts/qc.py <render>; python <skill>/scripts/timeline_view.py
--edit <edit_dir> --file <render> <A> <B>; look at <edit_dir>/qc/*_cuts.png and *_overview.png.
Report: verdict (ship / fix first / redo) · ranked problems with timecodes and evidence (frame PNG, numbers) ·
the 5 fixes to do first. Check especially: hook strength in 0–2 s, cut-off payoffs, jump cuts, caption errors
(names/numbers), text too small at phone size, music vs speech balance, dead air, ending.
```
