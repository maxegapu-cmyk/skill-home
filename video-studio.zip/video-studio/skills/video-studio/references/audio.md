# Audio: speech, music, sound effects, loudness

## Speech

- Every segment edge gets 30 ms fades (render.py). If QC reports a pop at a cut, move the cut into a silence
  (`timeline_view` with `--marks`) or widen padding.
- `audio.voice_enhance: true` → high-pass 80 Hz, FFT denoise, 3:1 compression, +2.5 dB presence at 3.2 kHz.
  Use for phone/lav/livestream audio. Skip for clean studio mics (it can add a slight processed sound).
- Livestream sources often have music under the voice — don't add BGM on top; check loudness instead.

## Music (BGM)

- Default −18 to −22 dB with sidechain ducking under speech (`duck: true`, ratio 8). Music-only sections come up
  automatically; speech stays on top.
- Fade in 1 s, fade out 2–3 s before the end, or end the music on a musical phrase (pick `offset`).
- Taste is the user's call: offer two contrasting beds when it matters. Never claim the mix sounds good —
  report numbers.
- Licensing: only use music the user owns or has rights to (platform libraries, licensed stock, original).
  Don't download copyrighted songs. If none is provided, ask, or deliver without music.

## Sound effects

Tie each effect to something visible (a card landing, a cut to a number, a swipe). ~1 per 5–10 s at most.
Most effects have an attack: start the file slightly before the visual hit. −6 to −12 dB under speech.

## Voiceover (tts.py)

edge-tts (free, very good Mandarin): YunxiNeural (male, lively — default for 讲解), XiaoxiaoNeural (female, warm),
YunjianNeural (male, energetic — promos), XiaoyiNeural (female, lively), YunyangNeural (news). `--rate +5%..+12%`
suits short video. ElevenLabs for cloned/brand voices (`ELEVENLABS_API_KEY`, `VS_ELEVEN_VOICE`).
Word timings come back with the audio → captions and scene durations sync automatically.

## Loudness (master)

render.py runs two-pass `loudnorm` to −14 LUFS integrated, −1 dBTP true peak (what 抖音/YouTube/Spotify-style
platforms normalize toward), AAC 192 kbps 48 kHz. Override with `audio.loudness` / `audio.true_peak`.
`qc.py` measures the result; investigate if it's off by > 2 LU or the peak is above −0.5 dBTP.
