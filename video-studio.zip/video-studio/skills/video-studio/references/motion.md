# Mode C — 代码生成动画: data / product explainers, intros, overlays

## Pick the engine

| Need | Engine | Speed |
|---|---|---|
| A number/price/stat/list/lower-third over footage | `cards.py` (built-in, Pillow) | seconds |
| A full explainer from structured content (hook → KPIs → bars → compare → steps → CTA) | `motion.py` → HyperFrames | ~1 min/30 s |
| Bespoke design, website/product UI motion, kinetic typography, 3D, maps | hand-written HyperFrames composition | varies |
| User already has a Remotion/React codebase or asks for Remotion | Remotion + official skills | varies |
| Math/diagram derivations | Manim (if installed) | varies |

Rule of thumb: start with `cards.py`/`motion.py`; go hand-written only when the brief needs a look they can't make.

## Narration-first explainer (best results)

1. **Script per scene**: `narration` (what is said, conversational, ~4–5 字/秒) and on-screen text (short:
   titles ≤ 12 chars on 9:16, numbers as numbers). Never put the whole narration on screen — captions do that.
2. Voice: `python tts.py scenes spec.json --out edit/audio/vo --voice zh-CN-YunxiNeural --rate +5%`
   → per-scene audio, scene `duration`s written back into the spec (narration + 0.45 s tail), `vo.mp3`,
   `vo.words.json`. Let the user pick a voice first if it matters (`tts.py voices zh`).
3. Build + render visuals: `python motion.py build spec.json edit/motion/explainer` →
   `python motion.py render edit/motion/explainer --draft` (runs `hyperframes check` first) → look at frames
   (`timeline_view.py --file …/render_draft.mp4 A B`) → `motion.py render … ` (delivery quality).
4. Compose with an EDL so captions, ducking and loudness are handled the same as footage:
```json
{"name": "explainer", "output": {"aspect": "9:16"},
 "ranges": [{"source": "edit/motion/explainer/render.mp4", "start": 0, "end": 24.0}],
 "audio": {"voiceover": {"file": "edit/audio/vo/vo.mp3", "words": "edit/audio/vo/vo.words.json"},
           "bgm": {"file": "assets/bgm.mp3", "volume_db": -20}},
 "captions": {"style": "bold", "position": "low", "highlight": ["2,099"]}}
```

## motion.py scene spec

`python motion.py example` prints a full starter. Top level: `size` (9:16, 16:9, 1:1, 3:4, or WxH), `fps`,
`theme` {bg, bg2, fg, accent, accent2, muted, panel}, `font` (path; default auto CJK), `music` (path, optional),
`background: null` → transparent (render with `--alpha` → .webm overlay). Each scene: `type`, `duration`,
`narration` (for tts.py), optional `stagger`, `min_duration`, `tail`.

| type | fields |
|---|---|
| hook | kicker, title (\n for lines) |
| text | title, body |
| kpis | title, items [{label, value, prefix, suffix, decimals}] (≤ 6) |
| bars | title, items [{label, value}], unit, highlight (index) |
| compare | title?, left {title, points[]}, right {title, points[]} |
| steps | title, items [str] |
| quote | text, author |
| image | src, caption (Ken Burns push-in) |
| cta | title, button, sub |

Numbers count up, bars grow, items stagger, scenes cross-fade; title sizes auto-fit to one line per `\n` line.
The generated `index.html` is a normal HyperFrames project — edit it by hand for bespoke tweaks, then re-run
`motion.py render`. (`build` overwrites it, so make spec-level changes first.)

## cards.py (overlays and quick inserts)

10 types: title · lower_third · counter · stat_cards · bullets · bar_chart · price_tag · end_card · callout · quote.
`python cards.py --demo /tmp/cards` renders one of each to look at. Transparent `.mov` by default (use as
`overlays` with `"position": "full"`), or `"background": "#0B0F14"` → opaque `.mp4` (use as a `range`).
Theme from `edit/brand.json`. Placement: `region` = center | upper | lower | top | bottom. Keep cards out of the
caption zone (lower 25 % on 9:16) — use `upper`/`center` when captions are on.

**Sync to speech**: after a draft render, `edit/out/<name>.words.json` has output-timeline word times. Start the
overlay ~0.3–0.5 s before the spoken payoff word so the number lands with the voice.

Parallel builds: several cards/scenes → one sub-agent each (subagents.md "animation slot" brief), or simply one
spec list file to `cards.py` (sequential but fast).

## Hand-written HyperFrames (bespoke)

Install the official skills for depth: `npx skills add heygen-com/hyperframes` (router `/hyperframes`,
`/hyperframes-core`, `/hyperframes-animation`, catalog of blocks). Contract essentials:
- Root `<div id="root" data-composition-id="main" data-width data-height data-duration>`; timed elements have
  `data-start` + `data-duration` (`class="clip"` by convention).
- One `gsap.timeline({paused: true})`, registered as `window.__timelines["main"]` AFTER it's built (fine inside
  `document.fonts.load(...).then`). No `Date.now()`, unseeded `Math.random`, network, or `tl.play()`.
- Don't tween `visibility/display/autoAlpha` on `.clip` elements — animate a child. Don't mix a CSS `transform`
  with a GSAP tween on the same element (use `fromTo`). Every `<audio>` needs an `id`.
- Named fonts need a local `@font-face` file — reuse `motion.py`'s subsetter (`subset_font`) for CJK.
- Loop: `npx hyperframes lint` → `npx hyperframes check` (runtime, layout, contrast) → `render --quality draft`
  → look → `render --quality delivery`. `--format webm` for alpha.
- Chrome: HyperFrames downloads its pinned Chrome on first render (`npx hyperframes browser ensure`). Behind a
  firewall set `HYPERFRAMES_BROWSER_PATH=/path/to/chrome`.

## Remotion

Only when asked or when the user has a Remotion codebase. `npx create-video@latest` in
`edit/animations/<slot>/`, install official skills (`npx skills add remotion-dev/skills`), render with the
project-local `npx remotion render`. License: free for individuals/small teams; larger companies need a
company license (remotion.dev/license) — mention this to business users.

## Motion design rules (universal)

- One idea per scene; one new element at a time (stagger 0.15–0.4 s); never two independent reveals at once.
- Ease out (power3/cubic) for entrances; never linear. Hold the final state ≥ 1 s before a scene ends.
- Readable at 1×: simple card ≥ 3 s, data scene 4–6 s, dense chart 6–10 s; or the narration length + 0.5 s.
- 9:16: titles ≥ 80 px, body ≥ 44 px, keep 8 % side margins, nothing important in the bottom 25 %.
- ≤ 2 accent colors; numbers in accent; muted grey for comparisons; brand colors win over defaults.
- Fonts: verify the CJK face rendered (look at a frame) — wrong-font fallbacks are silent.
