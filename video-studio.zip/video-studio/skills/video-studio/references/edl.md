# EDL schema (version 2)

One JSON file describes one video (with optional aspect variants). Paths may be absolute or relative to the
EDL file, the edit dir, or the videos dir. Source IDs from `sources.json` can be used directly in `ranges`.

```jsonc
{
  "version": 2,
  "name": "koubo",                       // output file name (out/<name>.mp4)
  "sources": {"B1": "../broll/car.mp4"},  // optional extra sources (IDs from ingest work without this)
  "output": {"aspect": "9:16", "fps": 30, "reframe": "auto"},   // or width/height; default = first source
  "grade": "bright_clean",               // preset | "auto" | raw ffmpeg filter | omit
  "transition": {"type": "fade", "duration": 0.25},              // optional default between ALL ranges

  "ranges": [
    {"source": "C01", "start": 12.34, "end": 18.90, "beat": "HOOK",
     "quote": "…", "reason": "cleanest take"},                   // beat/quote/reason: notes, ignored by render
    {"source": "C01", "start": "1:02.10", "end": "1:07.80",
     "zoom": 1.12,                       // static punch-in (hides jump cuts in 口播; alternate 1.0/1.1)
     "zoom_to": 1.2,                     // animated push-in from zoom → zoom_to over the range
     "crop_x": 0.42, "crop_y": 0.45,     // focus point 0–1 for cover crops (reframe.py writes these)
     "reframe": "cover|blur|fit|auto",   // per-range override
     "speed": 1.15,                      // 0.25–4, pitch-preserving audio
     "fade_in": 0.3, "fade_out": 0.4, "fade_color": "black|white",
     "transition_in": {"type": "slideleft", "duration": 0.3},   // xfade type into this range
     "volume_db": -3, "mute": false,
     "grade": "vivid",                   // per-range grade override
     "captions": false,                  // no captions for this range
     "caption": "文字"                   // explicit caption text (images / b-roll without speech)
    },
    {"source": "edit/animations/kpi.mp4", "start": 0, "end": 4.5, "beat": "DATA"},  // rendered insert
    {"source": "assets/car.jpg", "duration": 3, "zoom": 1.0, "zoom_to": 1.12}        // still image, Ken Burns
  ],

  "captions": {"style": "bold", "highlight": ["首付"], "emphasis": ["免费"],
               "fixes": {"喜香逢": "喜相逢"}, "position": "auto", "max_chars": null},   // see captions.md
  "titles": [{"text": "1.9万首付开回家", "position": "top", "bg": "#E8322E", "start": 0, "end": 8}],
  "overlays": [
    {"file": "edit/animations/price.mov", "start": 6.2, "position": "full"},           // full-frame alpha card
    {"file": "assets/sticker.png", "start": 3, "duration": 2, "position": "top-right",
     "width": 0.25, "opacity": 0.95, "fade_in": 0.2, "fade_out": 0.2},
    {"file": "edit/animations/pip.mp4", "start": 10, "x": 0.6, "y": 0.1, "width": 0.35, "audio": false}
  ],
  "logo": {"file": "assets/logo.png", "position": "top-right", "width": 0.14, "opacity": 0.9},
  "progress_bar": {"color": "#FFD400", "position": "top", "height": 0.006},
  "audio": {
    "voice_enhance": true,               // HPF + denoise + gentle compression + presence (phone/lav audio)
    "bgm": {"file": "assets/bgm.mp3", "volume_db": -18, "duck": true, "duck_ratio": 8,
            "offset": 0, "fade_in": 1, "fade_out": 2.5},
    "voiceover": {"file": "edit/audio/vo/vo.mp3", "words": "edit/audio/vo/vo.words.json", "start": 0},
    "sfx": [{"file": "assets/whoosh.wav", "at": 2.4, "volume_db": -8}],
    "loudness": -14, "true_peak": -1.0
  },
  "variants": [                          // one render per variant; captions re-laid out per size
    {"name": "koubo_9x16", "aspect": "9:16", "reframe": "blur"},
    {"name": "koubo_16x9", "aspect": "16:9", "captions": {"max_chars": 18}, "overlays": []}
  ]
}
```

## Semantics worth knowing

- **Timeline**: output time of a range = sum of previous durations (÷ speed), minus transition overlaps.
  Computed once in `vs_edl.build_timeline` and shared by render, captions and QC. Durations are quantized to
  whole frames, so long EDLs don't drift.
- **Reframe `auto`**: same aspect (±12 %) → cover crop; has `crop_x/crop_y` → cover crop on that point;
  otherwise → `blur` (blurred fill behind the fitted picture). `fg_y: "top|upper|center"` positions the fitted
  picture in blur mode (leave room for a title band at the top of 9:16).
- **Overlay positioning**: `position` keyword (`full|center|top|bottom|top-left|top-right|bottom-left|bottom-right`
  + `margin` fraction) or `x`/`y` (fraction 0–1 of frame, or pixels). `width` fraction or pixels; height keeps aspect.
  `.mov` (qtrle/ProRes 4444) and `.webm` (VP9 alpha) keep transparency; images loop for `duration`.
- **Transitions**: any ffmpeg `xfade` type: fade, fadeblack, fadewhite, dissolve, wipeleft/right/up/down,
  slideleft/right/up/down, circleopen/close, radial, smoothleft, pixelize, zoomin, hblur, squeezeh …
  Use sparingly in 口播 (hard cuts + zoom alternation read as more professional). Transitions shorten the
  timeline by their duration; captions follow automatically.
- **Grades**: `none`, `neutral_punch`, `bright_clean` (dim livestream rooms), `warm_cinematic`, `vivid`
  (cars/products/电商), `teal_orange`, `film_fade`, `bw`, `auto` (per-range exposure match), or any filter
  string like `"eq=contrast=1.1:saturation=1.2,curves=preset=lighter"`. Look at a frame before and after.
- **Images as ranges**: `.png/.jpg/.webp` sources need `duration`; combine with `zoom_to` for Ken Burns.
- **Rendered inserts** (cards.py / motion.py output) are just sources — put them in `ranges` for full-screen
  inserts or in `overlays` for transparent graphics over footage.

## brand.json (optional, edit/brand.json)

```json
{"theme": {"fg": "#FFFFFF", "accent": "#FFD400", "accent2": "#E8322E", "panel": "#0B0F14C8", "muted": "#D0D0D0",
           "font": "/Library/Fonts/YourBrand-Bold.otf"},
 "logo": "assets/logo.png", "voice": "zh-CN-YunxiNeural", "glossary": "喜相逢,以租代购"}
```
Used by cards.py (theme), deliver.py (accent), and as your reference for titles/captions/motion specs.

## Memory — edit/project.md

Append one section per session:

```markdown
## Session N — YYYY-MM-DD
**Goal:** …   **Mode:** A/B/C   **Outputs:** out/xxx.mp4 (0:52, 9:16)
**Decisions:** takes, structure, look, captions, music — and why
**User feedback:** …
**Outstanding:** …
```
