# Platforms & delivery

Specs change; treat these as defaults and check the platform's current creator docs when it matters.

| Platform | Aspect | Sweet-spot length | Notes |
|---|---|---|---|
| 抖音 | 9:16 1080×1920 | 15–60 s (clips), 1–3 min (知识) | hook in 2 s; captions above bottom 25 %; cover 9:16 (also shows 3:4 crop in grid) |
| 视频号 | 9:16 or 16:9 | 30–90 s | cover is cropped to 3:4 in feeds — keep title centered |
| 小红书 | 3:4 1080×1440 (9:16 ok) | 30–120 s | cover + title drive clicks; text-heavy covers work |
| 快手 | 9:16 | 15–60 s | similar to 抖音 |
| B站 | 16:9 1920×1080 (60 fps ok) | 3–15 min | chapters (titles), cover 16:10/16:9, soft subs (SRT) welcome |
| YouTube | 16:9; Shorts 9:16 ≤ 60 s | — | upload SRT; thumbnail 1280×720+ |
| 微信分享 | 9:16/16:9 | — | `deliver.py export --platforms wechat` keeps files small |

`deliver.py export <video> --platforms douyin,xiaohongshu` re-encodes with platform-friendly bitrate caps
(H.264 High, yuv420p, AAC 48 kHz, faststart). Render the right aspect variant first — export refuses to
letterbox a portrait video into 16:9.

## Covers (封面)

`deliver.py cover <video> --title "首付1.9万\n开回家" --highlight 1.9万 --sub "直播间专享" --sizes 3:4,9:16`
picks the best clean source frame (sharp, well exposed, face present) unless `--at T`; writes
`cover_candidates.png` (top 6) so the user can pick another. Rules: ≤ 2 lines, ≤ 8 chars per line on 3:4,
one highlighted number/benefit, face + emotion beats scenery, consistent template across a series.

## Copy (write into edit/deliver/copy.md)

For each video: 3 title options (≤ 20 chars; lead with the number, the question or the conflict), a 1–2
sentence description that adds information the video doesn't say out loud, 3–5 hashtags (1 broad, 2–3
niche, 1 brand), and for series a posting order (strongest first). Keep claims accurate — prices, offers and
financial terms must match what's said in the video; flag anything time-limited.

## Compliance reminders (state them when relevant, don't lecture)

- Financial/auto offers: show conditions as stated in the source; don't invent rates or guarantees.
- Faces and voices of customers/viewers on camera, license plates, phone numbers: blur or cut unless consented.
- Music must be licensed for the platform.
