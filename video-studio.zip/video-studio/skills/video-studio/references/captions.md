# Captions & titles

Built by `captions.py` (called from render.py) on the OUTPUT timeline, as ASS (burned) + SRT (upload as soft
subs) + `<name>.words.json`.

## Styles

| style | look | use for |
|---|---|---|
| `bold` (default) | big white bold, black outline, pop-in, keyword highlight | 抖音/视频号 口播, 切片 |
| `box` | white on translucent black box | 知识/教程, B站, busy backgrounds |
| `karaoke` | word-by-word color fill (\kf) | music, energetic hooks, short clips |
| `minimal` | smaller, soft shadow | vlog, cinematic, interviews |
| `none` | off | |

Options: `highlight` [words → accent color], `emphasis` [≤1–2 words → bigger + accent], `fixes`
{wrong: right} (applied before line breaking, re-timed inside the original span), `keep_fillers`
(default false), `strip_punct` (default true: commas → space, final 。 dropped — the 抖音 convention),
`position` auto|low|middle|high, `max_chars`, `font` (family or file), `font_size`, `color`, `accent`, `outline`,
`margin_v`.

## Line breaking (automatic)

Hard breaks at every EDL cut, sentence end, and pause ≥ 0.5 s. When a line is full it breaks at the best point
in its back half (punctuation > pause > word boundary from ASR/jieba); with no natural point the run is split
into balanced halves (no 1–3 char orphans). Highlight/emphasis keywords are never split. Line capacity is
derived from font size and safe width; `qc.py` reports any caption that would wrap anyway.

Install `jieba` for better Chinese word boundaries when the ASR returns single characters (FunASR, SRT import).

## Safe zones (9:16, 1080×1920)

- Bottom ~25 % (y > 1440): platform UI (title, music, comments) — `auto` puts the caption baseline at 75 % height.
- Right rail x > ~950 between y 900–1650: like/comment/share buttons — side margins are 8 % each.
- Top ~8 %: status bar/search — `titles` with `position: top` default to an 11 % margin.
- 16:9: captions at 7.5 % from bottom; keep 8 % side margins.

## Titles (`titles` in the EDL)

Persistent or timed text bands: `{"text", "start", "end", "position": top|bottom|center, "bg": "#E8322E" (box) or
omitted (outlined text), "color", "size" (fraction of short side, default 0.07), "margin", "animate": pop|fade|none}`.
Use for 切片 headline bands, chapter names, price strips. Keep ≤ 12–14 chars on 9:16.

## Writing good caption text

- Correct names and numbers via `fixes` (ASR: 喜香逢→喜相逢, 一万九→1.9万, 两千零九十九→2099).
- Arabic numerals for prices/data; units close to numbers (1.9万, 36期, 98%).
- Highlight what the viewer should remember: the number, the benefit, the deadline. 2–4 per minute max.
- Don't caption music-only sections; set `"captions": false` on b-roll ranges without speech.
