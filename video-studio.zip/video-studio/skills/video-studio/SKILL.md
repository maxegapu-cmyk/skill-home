---
name: video-studio
description: >
  Edit and generate videos by conversation, locally: 口播精剪 (cut fillers/retakes/dead air, punch-in zooms,
  burned Chinese captions), 直播切片 (find highlights in multi-hour livestreams, batch-cut 9:16 clips with titles,
  covers and copy), and code-generated 数据/产品讲解动画 (HyperFrames HTML→MP4, built-in motion cards, TTS
  narration). Also reframing 16:9→9:16, captions/subtitles, BGM ducking, loudness, covers, platform exports
  (抖音/视频号/小红书/B站/YouTube). Use whenever the user wants to cut, edit, trim, clip, slice, caption,
  subtitle, reframe, package, animate or render a video — 剪辑、剪视频、精剪、粗剪、切片、加字幕、去口误、
  做片头、做动画、数据可视化视频、竖屏、封面 — even if they don't name this skill.
---

# Video Studio

Local video production for Claude Code: ffmpeg + Python for editing, HyperFrames (HTML→MP4) and built-in
motion cards for graphics. Built on ideas from browser-use/video-use (MIT), heygen-com/hyperframes
(Apache-2.0), remotion-dev/skills and op7418/Youtube-clipper-skill — see CREDITS.md.

## Principles

1. **Read the video, don't watch it.** Word-level transcript (`takes_packed.md` / `overview.md`) is the primary
   view. Drill into pictures with `timeline_view.py` only at decision points.
2. **Audio first, picture follows.** Cuts land on word boundaries and silences. Every cut must work on both tracks.
3. **Ask → confirm → execute → self-check → present → iterate → persist.** Never cut before the user OKs a
   plain-language plan. Never present a render you haven't checked with `qc.py` and looked at.
4. **Look first, then ask questions shaped by the material.** No fixed questionnaire.
5. **Correctness rules are hard; taste is yours.** Every preset and number in references is a worked example.
6. **Mechanics to scripts, judgment to you.** Snapping, tightening, captions, loudness are scripted.
   Story, take choice, highlight choice, titles and pacing are your job.

## Hard rules (production correctness — non-negotiable)

1. Never cut inside a word. Run `edl_tools.py snap` on every hand-written EDL.
2. Pad cut edges 30–200 ms (snap defaults: 50 ms in, 80 ms out).
3. Captions/titles are burned LAST, after overlays (render.py does this — don't burn captions earlier).
4. Captions use output-timeline times. Only `render.py`/`captions.py` compute them (from the EDL timeline).
5. 30 ms audio fades at every segment edge (render.py default). Never hard-cut audio.
6. Overlays are PTS-shifted to their window start (render.py does this). Never pre-trim animation clips by hand.
7. Word-level verbatim ASR only (fillers kept). SRT import is a fallback; say timings are approximate.
8. Cache: never re-transcribe/re-analyze an unchanged source. Segment renders are hash-cached — re-render freely.
9. Strategy confirmation before the first cut; for 直播切片, confirm the clip list before batch rendering.
10. All outputs in `<videos_dir>/edit/` — never write into the skill directory or over source files.
11. Run `qc.py` on every render you present; open both contact sheets (`*_cuts.png`, `*_overview.png`).
    Fix → re-render → re-check, max 3 passes, then report what's left.
12. Loudness: master at −14 LUFS, true peak ≤ −1 dBTP (render.py default). Report measured numbers; you can't listen.
13. Captions must fit: QC flags wraps; lower `max_chars` or rephrase via `fixes`. Never ship a 2-line wrap by accident.
14. Fonts fail silently: CJK font is auto-detected (`doctor.py` shows which); motion projects embed a subsetted font.
15. Multiple animations → parallel sub-agents, one file each (see references/subagents.md).

## Setup (once per machine)

`python <skill>/scripts/doctor.py` → shows what's missing with install commands for this OS.
Minimum: ffmpeg with libass, Python 3.9+ with numpy + Pillow, one ASR backend (FunASR for Mandarin;
mlx-whisper on Apple Silicon; faster-whisper elsewhere; or ELEVENLABS_API_KEY for Scribe).
Optional: jieba, opencv-python-headless, edge-tts, fonttools+brotli, Node 22+ (HyperFrames), yt-dlp.
`<skill>` = the directory containing this file. Run scripts with `python <skill>/scripts/<name>.py`.

## Route the request

| User wants | Mode | Read |
|---|---|---|
| Clean up talking-head / 口播 / tutorial / interview footage | **A 口播精剪** | references/talking-head.md |
| Highlights from a long livestream / podcast / meeting → many short clips | **B 直播切片** | references/live-clips.md |
| Data / product / concept explainer, intro/outro, animated charts, no footage | **C 代码生成动画** | references/motion.md |
| Footage + designed graphics (lower thirds, price tags, charts over video) | **A or B + overlays** | references/motion.md §overlays |
| Captions only / reframe only / compress / convert / cover only | **Quick task** | relevant script `--help` |

Always also: references/edl.md (EDL schema) when writing EDLs; references/captions.md for caption style;
references/audio.md when music/VO is involved; references/platforms.md at delivery.

## The process (A and B; C in motion.md)

```
ingest → analyze → transcribe → pack → (read) → ASK → PLAN → confirm → EDL → snap/tighten →
render --draft → qc → look → render --preview → qc → present → iterate → final render → deliver → project.md
```

1. **Inventory**: `ingest.py <videos_dir>` (or `--url <link>` via yt-dlp) → `analyze.py <dir>` (add `--scenes` for
   multi-cam/screen recordings) → `transcribe.py <dir> --glossary "品牌名,专有名词"` → `pack.py <dir>`.
   Read `edit/takes_packed.md` (short sources) or `edit/overview.md` + `pack.py --show ID FROM TO` (long ones).
   If `edit/project.md` exists, read it first and summarize the last session in one sentence.
2. **Pre-scan**: note slips, retakes (repeated sentences), ASR errors (wrong brand names → caption `fixes`),
   strong moments (laughs, numbers, punchlines, ★ windows in overview).
3. **Converse**: say what you see in 3–5 sentences, then ask only what the material leaves open — target
   platform/aspect, length, audience, must-keep/must-cut, caption style, music, brand colors. Use
   AskUserQuestion for 1–4 multiple-choice questions when the user is present.
4. **Propose**: plain-language plan (structure, which takes, length estimate, look, captions, music). Wait for OK.
5. **Execute**: write `edit/edl.json` (schema: references/edl.md). Then
   `edl_tools.py snap edit/edl.json` → optionally `edl_tools.py tighten edit/edl.json --fillers` →
   `edl_tools.py show edit/edl.json` (reads back the actual words per range — verify the story reads right).
   Landscape source going vertical with a person on camera: `reframe.py edit/edl.json`.
6. **Draft**: `render.py edit/edl.json --draft` (half-res, fast) → `qc.py edit/out/<name>_draft.mp4` → look at the
   cut sheet. Use `timeline_view.py --edit <dir> --file <render> T1 T2 --marks <cut>` on anything suspicious.
7. **Preview**: `render.py edit/edl.json --preview` → `qc.py` → look → present with: what you did, duration, any
   QC numbers worth knowing, and 1–2 specific choices the user may want to change.
8. **Iterate** on feedback by editing the EDL (segments re-render only where changed). Never re-transcribe.
9. **Final**: `render.py edit/edl.json` (all variants) → `qc.py` each → `deliver.py cover …` →
   `deliver.py export … --platforms …` if needed → write titles/descriptions/hashtags (platforms.md).
10. **Persist**: append a session section to `edit/project.md` (template in references/edl.md §memory).

For published work (ads, launches, anything with a big audience) also spawn one **critic sub-agent** after the
preview render — brief in references/subagents.md. Fresh eyes catch cut-off punchlines and unreadable text.

## Scripts (all in scripts/, all have --help)

| Script | Does |
|---|---|
| `doctor.py` | environment check + install commands |
| `ingest.py` | register sources → `edit/sources.json` (IDs), probe, optional yt-dlp download |
| `analyze.py` | loudness envelope, silences, speech ratio, scene cuts (streams 5 h files) |
| `transcribe.py` | word-level ASR: funasr / mlx / faster-whisper / scribe / srt; chunked + resumable |
| `pack.py` | `takes_packed.md`, `overview.md` (per-minute map with ★ highlights), `--show ID A B` |
| `timeline_view.py` | filmstrip + waveform + words + silences PNG for a time range |
| `edl_tools.py` | `snap` · `tighten` · `clips` (batch EDLs for 切片) · `show` |
| `reframe.py` | face-aware crop positions for 16:9→9:16 |
| `render.py` | EDL → mp4 (variants, transitions, overlays, captions, titles, BGM ducking, loudnorm) |
| `captions.py` | ASS/SRT builder (called by render.py; usable alone) |
| `cards.py` | built-in motion cards → alpha .mov overlays / opaque .mp4 inserts (10 types) |
| `motion.py` | scene spec → HyperFrames project → render (数据/产品讲解) |
| `tts.py` | voiceover with word timings (edge-tts / ElevenLabs / say); per-scene narration sync |
| `qc.py` | automated self-check + contact sheets |
| `deliver.py` | covers from clean source frames, platform exports |

## Directory layout

```
<videos_dir>/
├── <sources, untouched>
└── edit/
    ├── sources.json  analysis/  transcripts/      ← cached, never hand-edit
    ├── takes_packed.md  overview.md  packed/       ← your reading views
    ├── edl.json   clips/*.json   clips.json        ← decisions
    ├── brand.json                                  ← colors/fonts/logo (optional, see edl.md)
    ├── animations/  motion/  audio/                ← generated graphics & VO
    ├── out/        ← renders (+ .ass .srt .words.json .render.json)
    ├── qc/         ← reports + contact sheets
    ├── deliver/    ← covers, platform exports, copy.md
    ├── verify/     ← timeline_view PNGs
    ├── cache/      ← segment cache (safe to delete)
    └── project.md  ← memory across sessions
```

## Anti-patterns

- Editing before the plan is confirmed. Assuming the video type. Fixed questionnaires.
- Reading raw transcript JSON or dumping frames to "watch" the video. Use packed views + timeline_view.
- Hand-computing caption times or burning captions before overlays.
- Cutting on a pause shorter than 150 ms without looking (mid-phrase). Cutting off a laugh/reaction after a punchline.
- Re-transcribing cached sources. Sequential sub-agents for independent animations.
- Linear easing; two new elements appearing at once; text under 40 px on 1080-wide vertical video.
- Presenting a render without qc.py + looking at the sheets. Claiming it "sounds good" — report measurements.
- Generic stock SFX on every cut; music louder than speech; captions covering platform UI (bottom 25 % / right rail).
