# Credits

video-studio combines ideas and patterns from these open-source projects (thank you):

- **browser-use/video-use** (MIT) — "read the video, don't watch it": word-level transcripts + on-demand
  filmstrip/waveform views, per-segment extract → lossless concat, 30 ms boundary fades, captions-last,
  PTS-shifted overlays, self-eval loop, project.md memory, sub-agent briefs. Several hard rules are adapted
  from its SKILL.md.
- **heygen-com/hyperframes** (Apache-2.0) — HTML→MP4 deterministic rendering engine used by `motion.py`;
  composition contract and lint/check/render loop.
- **remotion-dev/skills** — official Remotion agent skills (recommended for Remotion work; not vendored).
- **digitalsamba/claude-code-video-toolkit** (MIT) — brand profiles, project lifecycle, template thinking.
- **op7418/Youtube-clipper-skill** (MIT) — semantic chaptering, bilingual subtitles and platform copy for Chinese
  social platforms.
- **GSAP** (GreenSock, standard no-charge license) — vendored in assets/vendor for offline renders.
- OpenCV / YuNet (opencv_zoo, MIT) for face detection; FunASR, faster-whisper, mlx-whisper, edge-tts as optional
  backends.

All code in scripts/ was written for this project.
