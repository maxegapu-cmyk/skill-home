#!/usr/bin/env python3
"""Pack word-level transcripts into the LLM's primary reading views.

  edit/takes_packed.md        all short sources, phrase-level, word-boundary times
  edit/packed/<ID>.md         per-source file for long sources (> --long seconds)
  edit/overview.md            per-minute map of long sources (density, energy, keywords)

Line format:
  [012.34-015.80] S0 大家好{嗯}今天我们聊 / 一下这个车?
     {…}  = filler (嗯/啊/呃/um/uh)        / = pause 0.3–0.5 s inside a phrase
     ?    = low ASR confidence (<0.45)    (laughter) = audio event (Scribe only)
Phrases break on silence ≥ 0.5 s, speaker change, or sentence end + pause.

Show a window of any source (for drilling into a long stream):
  python pack.py <edit_dir> --show C01 1:02:00 1:06:30
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import (SENT_END, find_edit_dir, fmt_t, join_tokens, load_sources, log,  # noqa: E402
                       parse_t, read_json, text_units)

DEFAULT_KEYWORDS = ("价格,优惠,福利,下单,链接,秒杀,限时,名额,抽奖,免费,首付,月供,包邮,库存,赠送,活动,"
                    "便宜,划算,对比,为什么,怎么,注意,千万,一定,干货,秘诀,重点,总结,第一,最后,"
                    "price,deal,free,discount,why,how,secret,tip")


def phrases(words: list[dict], gap: float = 0.5, max_units: int = 42) -> list[dict]:
    out: list[dict] = []
    cur: list[dict] = []

    def flush():
        if cur:
            out.append({"start": cur[0]["start"], "end": cur[-1]["end"],
                        "speaker": cur[0].get("speaker", "S0"), "words": list(cur)})
            cur.clear()

    for w in words:
        if cur:
            g = w["start"] - cur[-1]["end"]
            prev_txt = cur[-1]["text"]
            units = text_units("".join(x["text"] for x in cur))
            if (g >= gap or w.get("speaker") != cur[-1].get("speaker")
                    or (prev_txt and prev_txt[-1] in SENT_END and g >= 0.2)
                    or (units >= 10 and g >= 0.28)
                    or (units >= max_units and g >= 0.15) or units >= max_units * 1.6):
                flush()
        cur.append(w)
    flush()
    return out


def render_phrase(ph: dict) -> str:
    toks: list[str] = []
    prev_end = None
    for w in ph["words"]:
        if prev_end is not None and 0.3 <= w["start"] - prev_end < 0.5:
            toks.append(" / ")
        t = w["text"]
        if w.get("type") == "filler":
            t = "{" + t + "}"
        elif w.get("type") == "event":
            t = f"({t.strip('()')})"
        elif w.get("p") is not None and w["p"] < 0.45:
            t += "?"
        toks.append(t)
        prev_end = w["end"]
    txt = join_tokens([t for t in toks if t != " / "]) if " / " not in toks else _join_with_pauses(toks)
    return f"  [{ph['start']:07.2f}-{ph['end']:07.2f}] {ph['speaker']} {txt}"


def _join_with_pauses(toks: list[str]) -> str:
    parts, buf = [], []
    for t in toks:
        if t == " / ":
            parts.append(join_tokens(buf))
            buf = []
        else:
            buf.append(t)
    parts.append(join_tokens(buf))
    return " / ".join(p for p in parts if p)


def source_block(sid: str, tr: dict, ana: dict | None) -> list[str]:
    phs = phrases(tr["words"])
    n_f = sum(1 for w in tr["words"] if w.get("type") == "filler")
    meta = [f"duration {fmt_t(tr.get('duration', 0))}", f"{len(phs)} phrases", f"{n_f} fillers",
            f"asr {tr.get('backend')}"]
    if ana:
        meta.append(f"speech {ana.get('speech_ratio', 0):.0%}")
    if tr.get("approximate"):
        meta.append("APPROX timings (srt import) — verify cuts with timeline_view")
    lines = [f"## {sid}  ({', '.join(meta)})"]
    lines += [render_phrase(p) for p in phs]
    return lines


def overview(sid: str, tr: dict, ana: dict | None, env: np.ndarray | None, keywords: list[str],
             win: float = 60.0) -> list[str]:
    dur = tr.get("duration") or (tr["words"][-1]["end"] if tr["words"] else 0)
    hop = (ana or {}).get("hop", 0.05)
    lines = [f"## {sid}  overview ({fmt_t(dur)}, {win:.0f}s windows)",
             "  window          字/秒  音量dB  ★  关键词 | 开头",]
    gp75 = float(np.percentile(env, 75)) if env is not None and len(env) else None
    t = 0.0
    words = tr["words"]
    wi = 0
    while t < dur:
        a, b = t, min(dur, t + win)
        seg = []
        while wi < len(words) and words[wi]["start"] < b:
            if words[wi]["start"] >= a:
                seg.append(words[wi])
            wi += 1
        text = join_tokens([w["text"] for w in seg if w.get("type") != "filler"])
        rate = text_units(text) / max(1e-6, (b - a))
        loud = None
        if env is not None and len(env):
            sl = env[int(a / hop): int(b / hop)]
            loud = float(np.percentile(sl, 90)) if len(sl) else None
        hits = [k for k in keywords if k and k in text]
        energy = (loud is not None and gp75 is not None and loud > gp75 + 2 and rate > 3.5)
        star = "★" if (energy or len(hits) >= 2) else " "
        kw = ",".join(hits[:5])
        lines.append(f"  [{fmt_t(a):>8}-{fmt_t(b):>8}] {rate:4.1f}  {loud if loud is not None else 0:6.1f}  "
                     f"{star}  {kw} | {text[:38]}")
        t = b
    return lines


def show_window(edit: Path, sid: str, a: float, b: float) -> None:
    tr = read_json(edit / "transcripts" / f"{sid}.json")
    if not tr:
        sys.exit(f"no transcript for {sid}")
    ws = [w for w in tr["words"] if a <= w["start"] < b]
    for p in phrases(ws):
        print(render_phrase(p))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", default=".")
    ap.add_argument("--long", type=float, default=1200.0, help="sources longer than this get their own file")
    ap.add_argument("--keywords", default=DEFAULT_KEYWORDS)
    ap.add_argument("--window", type=float, default=60.0)
    ap.add_argument("--show", nargs=3, metavar=("ID", "FROM", "TO"))
    args = ap.parse_args()
    edit = find_edit_dir(args.path)

    if args.show:
        show_window(edit, args.show[0], parse_t(args.show[1]), parse_t(args.show[2]))
        return

    srcs = load_sources(edit)
    kw = [k.strip() for k in args.keywords.replace("，", ",").split(",") if k.strip()]
    short_lines = ["# takes_packed — phrase-level transcripts",
                   "# {嗯}=filler  /=pause 0.3–0.5s  ?=low confidence  times in source seconds", ""]
    ov_lines = ["# overview — long sources, one row per window",
                "# ★ = high energy (loud + fast) or ≥2 keyword hits. Drill in with: pack.py --show ID FROM TO", ""]
    n_long = 0
    (edit / "packed").mkdir(exist_ok=True)
    for sid in srcs:
        tr = read_json(edit / "transcripts" / f"{sid}.json")
        if not tr:
            log(f"  {sid}: no transcript yet")
            continue
        ana = read_json(edit / "analysis" / f"{sid}.json")
        block = source_block(sid, tr, ana)
        if tr.get("duration", 0) > args.long:
            n_long += 1
            (edit / "packed" / f"{sid}.md").write_text("\n".join(block) + "\n", encoding="utf-8")
            envf = edit / "analysis" / f"{sid}.env.npy"
            env = np.load(envf) if envf.exists() else None
            ov_lines += overview(sid, tr, ana, env, kw, args.window) + [""]
            short_lines += [f"## {sid}  → long source, see packed/{sid}.md and overview.md", ""]
        else:
            short_lines += block + [""]
    (edit / "takes_packed.md").write_text("\n".join(short_lines), encoding="utf-8")
    size = (edit / "takes_packed.md").stat().st_size
    print(f"takes_packed.md: {size / 1024:.1f} KB")
    if n_long:
        (edit / "overview.md").write_text("\n".join(ov_lines), encoding="utf-8")
        print(f"overview.md + packed/*.md for {n_long} long source(s)")


if __name__ == "__main__":
    main()
