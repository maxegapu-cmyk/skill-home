#!/usr/bin/env python3
"""Build burned-in captions (ASS) + soft subtitles (SRT) on the OUTPUT timeline.

Called by render.py automatically when edl.captions is set; can also run alone:
  python captions.py <edl.json> [--variant name] [-o out.ass]

edl.captions:
  {"style": "bold|box|karaoke|minimal|none",
   "max_chars": 12,                 # per line; default 12 vertical / 18 landscape
   "position": "auto|low|middle|high",
   "highlight": ["首付", "限时福利"], # colored keywords
   "emphasis": ["免费"],             # bigger + colored
   "fixes": {"喜香逢": "喜相逢"},     # ASR corrections, applied before chunking
   "keep_fillers": false, "strip_punct": true,
   "font": "PingFang SC" | "/path/font.ttf", "font_size": 70,
   "color": "#FFFFFF", "accent": "#FFD400", "outline": 5}
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import PUNCT, find_cjk_font, is_cjk, load_sources, read_json, write_json  # noqa: E402
from vs_edl import build_timeline, load_edl, output_spec, probe, resolve, source_map  # noqa: E402

BREAK_PUNCT = set("，。！？、；：,.!?;:…")


# --------------------------------------------------------------- word mapping


def _transcript_for(sid: str, path: Path | None, edit: Path) -> dict | None:
    tr = read_json(edit / "transcripts" / f"{sid}.json")
    if tr:
        return tr
    if path is not None:
        for k, v in load_sources(edit).items():
            if Path(v["path"]) == path:
                return read_json(edit / "transcripts" / f"{k}.json")
        side = path.with_suffix(".words.json")
        if side.exists():
            return read_json(side)
    return None


def output_words(edl: dict, edl_path: Path, edit: Path, keep_fillers: bool = False,
                 fps: float | None = None) -> list[dict]:
    srcmap = source_map(edl, edl_path, edit)
    tl = build_timeline(edl, fps)
    out: list[dict] = []
    cache: dict = {}
    for r, seg in zip(edl["ranges"], tl):
        if r.get("mute") or r.get("captions") is False:
            continue
        if r.get("caption"):  # explicit text for image/b-roll ranges
            txt = r["caption"]
            n = max(1, len(txt))
            for i, ch in enumerate(txt):
                a = seg["out_start"] + seg["dur"] * i / n
                out.append({"text": ch, "start": a, "end": a + seg["dur"] / n, "type": "word"})
            continue
        sid = r["source"]
        if sid not in cache:
            cache[sid] = _transcript_for(sid, srcmap.get(sid), edit)
        tr = cache[sid]
        if not tr:
            continue
        s0, s1, sp = seg["src_start"], seg["src_end"], seg["speed"]
        for w in tr["words"]:
            mid = (w["start"] + w["end"]) / 2
            if not (s0 <= mid <= s1):
                continue
            if w.get("type") == "event" or (w.get("type") == "filler" and not keep_fillers):
                continue
            a = seg["out_start"] + (max(w["start"], s0) - s0) / sp
            b = seg["out_start"] + (min(w["end"], s1) - s0) / sp
            out.append({"text": w["text"], "start": round(a, 3), "end": round(max(b, a + 0.04), 3),
                        "type": w.get("type", "word"), "seg": seg["i"]})
    vo = (edl.get("audio") or {}).get("voiceover")
    if vo and vo.get("words"):
        vw = read_json(resolve(vo["words"], edl_path, edit)) or {}
        off = float(vo.get("start", 0))
        for w in vw.get("words", []):
            out.append({"text": w["text"], "start": w["start"] + off, "end": w["end"] + off, "type": "word"})
    out.sort(key=lambda w: w["start"])
    return out


# ------------------------------------------------------------------- chunking


TOK_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9'.%-]*[A-Za-z0-9%]|[A-Za-z0-9]|\s+|.")


def _split(t: str) -> list[str]:
    return [p for p in TOK_RE.findall(t) if not p.isspace()]


def _mk(p: str, a: float, b: float) -> dict:
    return {"t": p, "s": a, "e": b, "gap": 0.0, "wb": False, "seg_end": False,
            "latin": bool(p) and not is_cjk(p) and p not in PUNCT and p[0].isalnum()}


def _items(words: list[dict]) -> list[dict]:
    """Explode words into display items: one per CJK char, one per latin word/number.

    Flags used by the chunker: gap (silence after), wb (ASR/jieba word boundary after),
    seg_end (an EDL cut follows → always a hard caption break)."""
    items = []
    for wi, w in enumerate(words):
        t = w["text"].strip()
        if not t:
            continue
        nxt = words[wi + 1] if wi + 1 < len(words) else None
        nxt_gap = (nxt["start"] - w["end"]) if nxt else 9.0
        parts = _split(t)
        n = len(parts)
        for k, p in enumerate(parts):
            it = _mk(p, w["start"] + (w["end"] - w["start"]) * k / n, w["start"] + (w["end"] - w["start"]) * (k + 1) / n)
            if k == n - 1:
                it["gap"] = nxt_gap
                it["wb"] = n > 1 or it["latin"]
                it["seg_end"] = nxt is not None and nxt.get("seg") != w.get("seg")
            items.append(it)
    _jieba_boundaries(items)
    return items


def _jieba_boundaries(items: list[dict]) -> None:
    """Mark Chinese word boundaries so lines never split 首|付. Optional dependency."""
    try:
        import jieba  # type: ignore
        jieba.setLogLevel(60)
    except Exception:
        return
    i = 0
    while i < len(items):
        if not is_cjk(items[i]["t"]):
            i += 1
            continue
        j = i
        while j < len(items) and is_cjk(items[j]["t"]) and not items[j]["seg_end"] and items[j]["gap"] < 0.2:
            j += 1
        j = min(j + 1, len(items))
        run_txt = "".join(it["t"] for it in items[i:j])
        pos = i
        for tok in jieba.cut(run_txt, HMM=True):
            pos += len(tok)
            if i < pos <= j:
                items[pos - 1]["wb"] = True
        i = j


def apply_fixes(items: list[dict], fixes: dict) -> list[dict]:
    """Replace ASR mistakes on the item stream, re-timing replaced text inside the old span."""
    if not fixes:
        return items
    for wrong, right in sorted(fixes.items(), key=lambda kv: -len(kv[0])):
        guard = 0
        start_at = 0
        while guard < 500:
            guard += 1
            txt = "".join(i["t"] for i in items)
            pos = txt.find(wrong, start_at)
            if pos < 0:
                break
            acc, a_idx, b_idx = 0, None, None
            for idx, it in enumerate(items):
                if a_idx is None and acc + len(it["t"]) > pos:
                    a_idx = idx
                if acc + len(it["t"]) >= pos + len(wrong):
                    b_idx = idx
                    break
                acc += len(it["t"])
            if a_idx is None or b_idx is None:
                break
            s, e, last = items[a_idx]["s"], items[b_idx]["e"], items[b_idx]
            parts = _split(right)
            new = [_mk(p, s + (e - s) * k / max(1, len(parts)), s + (e - s) * (k + 1) / max(1, len(parts)))
                   for k, p in enumerate(parts)]
            for it in new:
                it["seg"] = None
            if new:
                new[-1].update(gap=last["gap"], wb=True, seg_end=last["seg_end"])
                if a_idx > 0:
                    items[a_idx - 1]["wb"] = True
            items = items[:a_idx] + new + items[b_idx + 1:]
            start_at = pos + len(right)
    return items


def _units(it: dict) -> float:
    return len(it["t"]) * 0.55 + 0.3 if it["latin"] else (0.0 if it["t"] in PUNCT else 1.0)


def _break_score(it: dict) -> float:
    if it["seg_end"]:
        return 5
    if it["t"] and it["t"][-1] in BREAK_PUNCT:
        return 4
    if it["gap"] >= 0.3:
        return 3.5
    if it["gap"] >= 0.15:
        return 2.5
    if it["wb"]:
        return 1
    return 0


def _mark_nobreak(items: list[dict], protect: list[str]) -> None:
    txt = "".join(i["t"] for i in items)
    starts, acc = [], 0
    for it in items:
        starts.append(acc)
        acc += len(it["t"])
    for kw in protect:
        p = txt.find(kw)
        while p >= 0:
            e = p + len(kw)
            for k, st in enumerate(starts):
                if p <= st and st + len(items[k]["t"]) < e:
                    items[k]["nobreak"] = True
            p = txt.find(kw, p + 1)


def _is_hard(it: dict) -> bool:
    return it["seg_end"] or it["gap"] >= 0.5 or bool(it["t"] and it["t"][-1] in "。！？!?…")


def _is_soft(it: dict) -> bool:
    return it["gap"] >= 0.3 or bool(it["t"] and it["t"][-1] in BREAK_PUNCT)


def chunk(items: list[dict], max_units: float, capacity: float | None = None,
          protect: list[str] | None = None) -> list[list[dict]]:
    """Line breaking for captions.

    Hard breaks: EDL cuts, sentence ends, pauses ≥ 0.5 s.  On overflow: best scored break
    (punctuation > pause > word boundary) in the back half of the line; if none exists the
    run up to the next natural break is split into balanced halves (no 1–3 char orphans).
    Protected keywords (highlight/emphasis) are never split."""
    capacity = capacity or max_units * 1.3
    _mark_nobreak(items, protect or [])
    chunks: list[list[dict]] = []
    cur: list[dict] = []

    def ok(k: int) -> bool:  # may we break after cur[k-1]?
        return k >= 1 and not cur[k - 1].get("nobreak")

    i = 0
    while i < len(items):
        it = items[i]
        cur.append(it)
        units = sum(_units(x) for x in cur)
        if _is_hard(it) and units >= 1.5:
            if units > capacity:  # overlong sentence: balanced split, prefer word boundaries
                target, acc, cut = units / 2, 0.0, None
                cands = []
                for k in range(len(cur) - 1):
                    acc += _units(cur[k])
                    if ok(k + 1):
                        cands.append((abs(acc - target) - 0.6 * min(_break_score(cur[k]), 4), k + 1))
                if cands:
                    cut = min(cands)[1]
                    chunks.append(cur[:cut])
                    cur = cur[cut:]
            chunks.append(cur)
            cur = []
            i += 1
            continue
        if units >= max_units and not it.get("nobreak"):
            best, best_score, acc = None, 0.0, 0.0
            for k in range(len(cur) - 1):
                acc += _units(cur[k])
                if acc < max_units * 0.45 or not ok(k + 1):
                    continue
                sc = _break_score(cur[k]) + acc / max_units * 0.5
                if _break_score(cur[k]) >= 1 and sc > best_score:
                    best, best_score = k + 1, sc
            if best is None:
                # measure the run to the next natural break
                extra, j = 0.0, i + 1
                if _is_soft(it):
                    j = len(items)  # the line already ends at a natural break: split what we have
                while j < len(items) and extra <= capacity * 2:
                    extra += _units(items[j])
                    if _is_hard(items[j]) or _is_soft(items[j]):
                        break
                    j += 1
                total = units + extra
                if total <= capacity:
                    i += 1
                    continue  # whole run fits on one line
                if total <= capacity * 2:
                    target, acc, best = total / 2, 0.0, len(cur)
                    for k in range(len(cur)):
                        acc += _units(cur[k])
                        if acc >= target - 0.01 and ok(k + 1):
                            best = k + 1
                            break
                    if acc < target - 0.01:  # midpoint lies ahead: keep going
                        i += 1
                        continue
                else:
                    best = len(cur)
                    while best > 1 and not ok(best):
                        best -= 1
            chunks.append(cur[:best])
            cur = cur[best:]
        i += 1
    if cur:
        chunks.append(cur)
    merged: list[list[dict]] = []
    for c in chunks:
        if merged:
            prev = merged[-1]
            dur = c[-1]["e"] - c[0]["s"]
            u = sum(_units(x) for x in prev + c)
            if (dur < 0.4 or sum(_units(x) for x in c) <= 1.5) and u <= capacity \
                    and c[0]["s"] - prev[-1]["e"] < 0.3 and not prev[-1]["seg_end"]:
                merged[-1] = prev + c
                continue
        merged.append(c)
    return [c for c in merged if any(_units(x) > 0 for x in c)]


def chunk_text(c: list[dict], strip_punct: bool) -> str:
    out = ""
    for k, it in enumerate(c):
        t = it["t"]
        if strip_punct and t in PUNCT:
            t = " " if (t in "，、,；;：:" and k != len(c) - 1) else ""
        if out and it["latin"] and (c[k - 1]["latin"] or not is_cjk(out[-1])) and not out.endswith(" "):
            out += " "
        out += t
    return re.sub(r"\s+", " ", out).strip()


# ------------------------------------------------------------------------ ASS


def _ass_color(hex_rgb: str, alpha: int = 0) -> str:
    h = hex_rgb.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"&H{alpha:02X}{b:02X}{g:02X}{r:02X}"


def _t(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace("{", "(").replace("}", ")").replace("\n", " ")


def style_params(cfg: dict, W: int, H: int) -> dict:
    vertical = H > W
    style = cfg.get("style", "bold")
    base = int(cfg.get("font_size") or round(min(W, H) * (0.07 if vertical else 0.064)))
    pos = cfg.get("position", "auto")
    frac = {"auto": 0.25 if vertical else 0.075, "low": 0.15 if vertical else 0.05,
            "middle": 0.38 if vertical else 0.3, "high": 0.62 if vertical else 0.6}.get(pos, 0.25)
    font_file, family = find_cjk_font(cfg.get("font"))
    p = {"style": style, "size": base, "margin_v": int(cfg.get("margin_v") or H * frac),
         "margin_lr": int(W * (0.08 if vertical else 0.08)), "family": family, "font_file": font_file,
         "color": cfg.get("color", "#FFFFFF"), "accent": cfg.get("accent", "#FFD400"),
         "outline": cfg.get("outline", max(3, round(base * 0.075))), "bold": 1,
         "back": "#000000", "back_alpha": 255, "border_style": 1, "shadow": 0}
    if style == "box":
        p.update(border_style=3, back_alpha=0x60, outline=round(base * 0.18), shadow=0)
    elif style == "minimal":
        p.update(size=round(base * 0.82), outline=max(1, round(base * 0.03)), shadow=2, bold=0)
    elif style == "karaoke":
        p.update(outline=max(3, round(base * 0.08)))
    return p


def build_ass(words: list[dict], cfg: dict, W: int, H: int) -> tuple[str, list[tuple[float, float, str]]]:
    p = style_params(cfg, W, H)
    vertical = H > W
    capacity = max(6, int((W - 2 * p["margin_lr"]) / (p["size"] * 1.02)))
    max_units = float(cfg.get("max_chars") or max(6, min(capacity - 1, 12 if vertical else 20)))
    max_units = min(max_units, capacity)
    items = apply_fixes(_items(words), cfg.get("fixes") or {})
    chunks = chunk(items, max_units, capacity=capacity, protect=list(cfg.get("highlight") or []) + list(cfg.get("emphasis") or []))
    strip = cfg.get("strip_punct", True)
    highlight = sorted(set(cfg.get("highlight") or []), key=len, reverse=True)
    emphasis = sorted(set(cfg.get("emphasis") or []), key=len, reverse=True)
    acc, prim = _ass_color(p["accent"]), _ass_color(p["color"])
    sec = _ass_color(p["accent"]) if p["style"] == "karaoke" else prim
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{p['family']},{p['size']},{prim if p['style'] != 'karaoke' else sec},{prim},{_ass_color('#000000')},{_ass_color(p['back'], p['back_alpha'])},{p['bold']},0,0,0,100,100,{1 if vertical else 0},0,{p['border_style']},{p['outline']},{p['shadow']},2,{p['margin_lr']},{p['margin_lr']},{p['margin_v']},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events, srt = [], []
    for k, c in enumerate(chunks):
        start = c[0]["s"]
        end = c[-1]["e"]
        nxt = chunks[k + 1][0]["s"] if k + 1 < len(chunks) else None
        if nxt is not None and nxt - end < 0.35:
            end = nxt - 0.01  # bridge tiny gaps: no flicker
        elif nxt is not None:
            end = min(nxt - 0.01, end + 0.25)
        else:
            end += 0.3
        end = max(end, start + 0.4)
        text = chunk_text(c, strip)
        if not text:
            continue
        srt.append((start, end, text))
        if p["style"] == "karaoke":
            body = ""
            for it in c:
                t = it["t"]
                if strip and t in PUNCT:
                    continue
                cs = max(1, int(round((it["e"] - it["s"]) * 100)))
                body += "{\\kf%d}%s" % (cs, _esc(t + (" " if it["latin"] else "")))
        else:
            body = _esc(text)
            for kw in emphasis:
                body = body.replace(kw, "{\\c%s\\fscx122\\fscy122}%s{\\r}" % (acc, kw))
            for kw in highlight:
                if kw in emphasis:
                    continue
                body = re.sub(f"(?<!\\}})({re.escape(kw)})", "{\\\\c%s}\\1{\\\\r}" % acc, body)
        pre = ""
        if p["style"] == "bold":
            pre = "{\\fscx86\\fscy86\\t(0,90,\\fscx100\\fscy100)}"
        events.append(f"Dialogue: 0,{_t(start)},{_t(end)},Cap,,0,0,0,,{pre}{body}")
    return header + "\n".join(events) + "\n", srt


def write_srt(path: Path, cues: list[tuple[float, float, str]]) -> None:
    def f(t: float) -> str:
        ms = int(round(t * 1000))
        h, ms = divmod(ms, 3600000)
        m, ms = divmod(ms, 60000)
        s, ms = divmod(ms, 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
    path.write_text("".join(f"{i + 1}\n{f(a)} --> {f(b)}\n{t}\n\n" for i, (a, b, t) in enumerate(cues)),
                    encoding="utf-8")


def make_captions(edl: dict, edl_path: Path, edit: Path, W: int, H: int, out_ass: Path,
                  cfg: dict | None = None, fps: float | None = None) -> Path | None:
    cfg = cfg if cfg is not None else (edl.get("captions") or {})
    if not cfg or cfg.get("style") == "none" or cfg.get("enabled") is False:
        return None
    if cfg.get("file"):
        return resolve(cfg["file"], edl_path, edit)
    words = output_words(edl, edl_path, edit, cfg.get("keep_fillers", False), fps)
    if not words:
        return None
    ass, cues = build_ass(words, cfg, W, H)
    out_ass.parent.mkdir(parents=True, exist_ok=True)
    out_ass.write_text(ass, encoding="utf-8")
    write_srt(out_ass.with_suffix(".srt"), cues)
    write_json(out_ass.with_suffix(".words.json"), {"words": words})
    return out_ass


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("edl")
    ap.add_argument("--variant")
    ap.add_argument("-o", "--out")
    args = ap.parse_args()
    edl, edl_path, edit = load_edl(args.edl)
    variant = next((v for v in edl.get("variants", []) if v.get("name") == args.variant), None)
    srcmap = source_map(edl, edl_path, edit)
    first = srcmap.get(edl["ranges"][0]["source"])
    spec = output_spec(edl, variant, probe(first) if first else None)
    cfg = dict(edl.get("captions") or {})
    if variant and variant.get("captions"):
        cfg.update(variant["captions"])
    out = Path(args.out) if args.out else edit / "out" / f"{spec['name']}.ass"
    res = make_captions(edl, edl_path, edit, spec["width"], spec["height"], out, cfg, float(spec["fps"]))
    print(res or "no captions (no words / disabled)")


if __name__ == "__main__":
    main()


# --------------------------------------------------------------------- titles


def add_titles(ass: Path | None, titles: list[dict], W: int, H: int, out_ass: Path,
               cap_cfg: dict | None = None) -> Path:
    """Persistent / timed title text (直播切片顶部标题, 章节名, 价格条…) as extra ASS styles.

    titles: [{"text": "首付1.9万开回家", "start": 0, "end": 8, "position": "top|bottom|center",
              "size": 0.075, "color": "#FFFFFF", "bg": "#E8322E", "bold": true, "animate": "pop|fade|none",
              "margin": 0.12}]  (end omitted → whole video)
    """
    vertical = H > W
    _ff, family = find_cjk_font((cap_cfg or {}).get("font"))
    if ass and ass.exists():
        text = ass.read_text(encoding="utf-8")
    else:
        text = (f"[Script Info]\nScriptType: v4.00+\nPlayResX: {W}\nPlayResY: {H}\nWrapStyle: 0\n"
                "ScaledBorderAndShadow: yes\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\nFormat: Name, Fontname, "
                "Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, "
                "StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, "
                "MarginR, MarginV, Encoding\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, "
                "MarginV, Effect, Text\n")
    styles, events = [], []
    for k, t in enumerate(titles):
        pos = t.get("position", "top")
        align = {"top": 8, "bottom": 2, "center": 5}.get(pos, 8)
        sz = t.get("size", 0.07 if vertical else 0.075)
        size = int(sz * min(W, H)) if sz < 1 else int(sz)
        margin = t.get("margin", 0.11 if vertical else 0.06)
        mv = int(margin * H) if margin < 1 else int(margin)
        bg = t.get("bg")
        bs, outline, back = (3, max(6, size // 5), _ass_color(bg, 0)) if bg else (1, max(3, size // 14),
                                                                                    _ass_color("#000000"))
        styles.append(f"Style: Title{k},{family},{size},{_ass_color(t.get('color', '#FFFFFF'))},"
                      f"{_ass_color(t.get('color', '#FFFFFF'))},{_ass_color(bg or '#000000')},{back},"
                      f"{1 if t.get('bold', True) else 0},0,0,0,100,100,2,0,{bs},{outline},0,{align},"
                      f"{int(W * 0.06)},{int(W * 0.06)},{mv},1")
        st = float(t.get("start", 0))
        en = float(t.get("end", 36000))
        anim = t.get("animate", "pop")
        pre = {"pop": "{\\fscx70\\fscy70\\t(0,160,\\fscx104\\fscy104)\\t(160,240,\\fscx100\\fscy100)}",
               "fade": "{\\fad(250,200)}", "none": ""}.get(anim, "")
        events.append(f"Dialogue: 1,{_t(st)},{_t(en)},Title{k},,0,0,0,,{pre}{_esc(t['text'])}")
    head, ev = text.split("[Events]", 1)
    head = head.rstrip("\n") + "\n" + "\n".join(styles) + "\n\n"
    text = head + "[Events]" + ev.rstrip("\n") + "\n" + "\n".join(events) + "\n"
    out_ass.parent.mkdir(parents=True, exist_ok=True)
    out_ass.write_text(text, encoding="utf-8")
    return out_ass
