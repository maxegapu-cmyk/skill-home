#!/usr/bin/env python3
"""Inventory source media → <videos_dir>/edit/sources.json

Usage:
  python ingest.py <videos_dir>                       # scan folder (non-recursive)
  python ingest.py <videos_dir> --files a.mp4 b.mov   # only these
  python ingest.py <videos_dir> --url https://...     # download with yt-dlp first
  python ingest.py <videos_dir> --recursive

Each source gets a short stable ID (from its filename) used everywhere else:
transcripts/<ID>.json, EDL "source": "<ID>", etc. Re-running is safe: existing
IDs are kept, new files are appended.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import (AUDIO_EXT, MEDIA_EXT, die, find_edit_dir, fmt_t, has_bin,  # noqa: E402
                       log, probe, read_json, run, write_json)


def make_id(stem: str, taken: set[str]) -> str:
    base = re.sub(r"[^0-9A-Za-z一-鿿_-]+", "_", stem).strip("_")[:16] or "SRC"
    cand, n = base, 2
    while cand in taken:
        cand = f"{base}_{n}"
        n += 1
    return cand


def download(url: str, dest: Path) -> list[Path]:
    if not has_bin("yt-dlp"):
        die("yt-dlp not installed. mac: brew install yt-dlp | others: pip install yt-dlp")
    dest.mkdir(parents=True, exist_ok=True)
    before = set(dest.iterdir())
    log(f"downloading {url} → {dest}")
    run(["yt-dlp", "-f", "bv*[height<=1080]+ba/b[height<=1080]/b", "--merge-output-format", "mp4",
         "-o", str(dest / "%(title).60s [%(id)s].%(ext)s"), "--write-subs", "--write-auto-subs",
         "--sub-langs", "zh.*,en.*", "--convert-subs", "srt", url], quiet=False)
    return sorted(p for p in dest.iterdir() if p not in before and p.suffix.lower() in MEDIA_EXT)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("videos_dir")
    ap.add_argument("--files", nargs="*")
    ap.add_argument("--url", action="append", default=[])
    ap.add_argument("--recursive", action="store_true")
    ap.add_argument("--include-audio", action="store_true", help="also ingest audio-only files")
    args = ap.parse_args()

    vdir = Path(args.videos_dir).resolve()
    if not vdir.exists():
        die(f"{vdir} not found")
    edit = find_edit_dir(vdir)
    edit.mkdir(parents=True, exist_ok=True)
    srcs: dict = read_json(edit / "sources.json", {}) or {}
    known_paths = {v["path"]: k for k, v in srcs.items()}

    files: list[Path] = []
    for url in args.url:
        files += download(url, vdir / "downloads")
    if args.files:
        files += [Path(f).resolve() for f in args.files]
    elif not args.url:
        exts = MEDIA_EXT | (AUDIO_EXT if args.include_audio else set())
        it = vdir.rglob("*") if args.recursive else vdir.iterdir()
        files += sorted(p for p in it if p.is_file() and p.suffix.lower() in exts
                        and "edit" not in p.relative_to(vdir).parts and not p.name.startswith("."))

    added = 0
    for f in files:
        f = f.resolve()
        if str(f) in known_paths:
            continue
        try:
            info = probe(f)
        except Exception as e:  # unreadable file
            log(f"  skip {f.name}: {e}")
            continue
        sid = make_id(f.stem, set(srcs))
        info["file"] = f.name
        sidecar = next((s for s in f.parent.glob(f.stem + "*.srt")), None)
        if sidecar:
            info["sidecar_srt"] = str(sidecar)
        srcs[sid] = info
        added += 1

    write_json(edit / "sources.json", srcs)
    total = sum(v.get("duration", 0) for v in srcs.values())
    print(f"edit dir: {edit}")
    print(f"{len(srcs)} source(s), {added} new, total {fmt_t(total)}\n")
    print(f"{'ID':<18}{'dur':>10}  {'res':>11} {'fps':>6}  flags")
    for sid, v in srcs.items():
        res = f"{v.get('width', '-')}x{v.get('height', '-')}" if v.get("has_video") else "audio"
        flags = []
        if v.get("hdr"):
            flags.append("HDR→tonemap")
        if v.get("vfr"):
            flags.append("VFR")
        if v.get("rotation"):
            flags.append(f"rot{v['rotation']}")
        if not v.get("has_audio"):
            flags.append("NO-AUDIO")
        if v.get("sidecar_srt"):
            flags.append("has .srt")
        if v.get("duration", 0) > 1800:
            flags.append("LONG(chunked ASR)")
        print(f"{sid:<18}{fmt_t(v.get('duration', 0)):>10}  {res:>11} {v.get('fps', 0):>6}  {' '.join(flags)}")


if __name__ == "__main__":
    main()
