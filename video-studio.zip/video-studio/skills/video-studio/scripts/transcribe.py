#!/usr/bin/env python3
"""Word-level transcription with pluggable backends → edit/transcripts/<ID>.json

Backends (pick with --backend, default "auto"):
  funasr          Paraformer-zh + VAD + punctuation (+speaker). Best for Mandarin. Local.
  mlx             mlx-whisper on Apple Silicon. Fast local.
  faster-whisper  CTranslate2 Whisper (CUDA or CPU int8). Local, any language.
  scribe          ElevenLabs Scribe API (needs ELEVENLABS_API_KEY). Keeps fillers, diarization,
                  audio events like (laughter). Most "editorial" output.
  srt             Import an existing .srt (剪映/飞书妙记/平台自动字幕). Char timings are
                  interpolated → mark as approximate; fine for slicing, coarse for tight cuts.

auto: zh → funasr > mlx > faster-whisper > scribe > srt ; other languages → scribe > mlx > faster-whisper.

Long sources (> --chunk seconds, default 600) are split at real silences (from
analyze.py) and cached per chunk, so a 4-hour live stream can resume after a crash.

Output schema (normalized, backend-independent):
  {"source","duration","language","backend","approximate":bool,
   "words":[{"text","start","end","speaker":"S0","type":"word|filler|event","p":0.93}]}

Usage:
  python transcribe.py <edit_or_videos_dir> [--ids A B] [--backend auto] [--model ...]
         [--language zh] [--glossary "喜相逢,以租代购"] [--speakers 2] [--force]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import (FILLERS_EN, FILLERS_ZH, PUNCT, find_edit_dir, fmt_t, is_filler,  # noqa: E402
                       load_sources, log, os_name, read_json, run, write_json)

TOKEN_RE = re.compile(r"[㐀-䶿一-鿿豈-﫿]|[A-Za-z0-9][A-Za-z0-9'.%-]*")

FILLER_PROMPT_ZH = "嗯，啊，呃，那个，就是说，然后呢，对对对。以下是普通话直播和口播的逐字稿，保留语气词。"


# ----------------------------------------------------------------- utilities


def have(mod: str) -> bool:
    import importlib.util
    return importlib.util.find_spec(mod) is not None


def cuda_ok() -> bool:
    try:
        import ctranslate2  # noqa
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:
        return False


def is_apple_silicon() -> bool:
    import platform
    return os_name() == "mac" and platform.machine() == "arm64"


def pick_backend(lang: str | None, has_srt: bool) -> str:
    zh = (lang or "zh").startswith("zh")
    order = (["funasr", "mlx", "faster-whisper", "scribe", "srt"] if zh
             else ["scribe", "mlx", "faster-whisper", "srt"])
    for b in order:
        if b == "funasr" and have("funasr"):
            return b
        if b == "mlx" and is_apple_silicon() and have("mlx_whisper"):
            return b
        if b == "faster-whisper" and have("faster_whisper"):
            return b
        if b == "scribe" and os.environ.get("ELEVENLABS_API_KEY"):
            return b
        if b == "srt" and has_srt:
            return b
    hint = ("pip install funasr modelscope torch torchaudio   # 中文首选\n"
            "pip install mlx-whisper                          # Apple Silicon\n"
            "pip install faster-whisper                       # 通用 (CUDA/CPU)\n"
            "export ELEVENLABS_API_KEY=...                    # 云端 Scribe")
    log("no transcription backend available. Install one of:\n" + hint)
    sys.exit(2)


def extract_wav(src: str, out: Path, start: float = 0.0, dur: float | None = None) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-v", "error"]
    if start:
        cmd += ["-ss", f"{start:.3f}"]
    cmd += ["-i", src]
    if dur:
        cmd += ["-t", f"{dur:.3f}"]
    cmd += ["-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(out)]
    run(cmd)
    return out


def chunk_plan(duration: float, silences: list, size: float) -> list[tuple[float, float]]:
    """Split at the middle of the silence closest to every `size` seconds."""
    if duration <= size * 1.2:
        return [(0.0, duration)]
    mids = [((s + e) / 2, e - s) for s, e in silences if e - s >= 0.3]
    bounds, t = [0.0], size
    while t < duration - size * 0.3:
        near = [m for m, d in mids if abs(m - t) < size * 0.25]
        cut = min(near, key=lambda m: abs(m - t)) if near else t
        bounds.append(round(cut, 3))
        t = cut + size
    bounds.append(duration)
    return list(zip(bounds[:-1], bounds[1:]))


def classify(tok: str) -> str:
    return "filler" if is_filler(tok) else "word"


def W(text: str, s: float, e: float, spk: str = "S0", typ: str | None = None, p: float | None = None) -> dict:
    d = {"text": text, "start": round(float(s), 3), "end": round(float(max(e, s + 0.01)), 3),
         "speaker": spk, "type": typ or classify(text)}
    if p is not None:
        d["p"] = round(float(p), 3)
    return d


def to_simplified(words: list[dict]) -> list[dict]:
    try:
        from opencc import OpenCC  # opencc-python-reimplemented
    except Exception:
        return words
    cc = OpenCC("t2s")
    for w in words:
        w["text"] = cc.convert(w["text"])
    return words


# ----------------------------------------------------------------- backends


_MODELS: dict = {}


def run_faster_whisper(wav: Path, lang: str | None, model: str | None, prompt: str) -> list[dict]:
    from faster_whisper import WhisperModel
    gpu = cuda_ok()
    name = model or ("large-v3" if gpu else "large-v3-turbo")
    key = ("fw", name)
    if key not in _MODELS:
        log(f"    loading faster-whisper {name} ({'cuda' if gpu else 'cpu int8'})")
        _MODELS[key] = WhisperModel(name, device="cuda" if gpu else "cpu",
                                    compute_type="float16" if gpu else "int8")
    m = _MODELS[key]
    segs, _info = m.transcribe(str(wav), language=lang, word_timestamps=True, vad_filter=True,
                               vad_parameters={"min_silence_duration_ms": 300},
                               condition_on_previous_text=False, initial_prompt=prompt or None,
                               beam_size=5)
    words = []
    for seg in segs:
        for w in seg.words or []:
            t = w.word.strip()
            if t:
                words.append(W(t, w.start, w.end, p=w.probability))
    return words


def run_mlx(wav: Path, lang: str | None, model: str | None, prompt: str) -> list[dict]:
    import mlx_whisper
    repo = model or "mlx-community/whisper-large-v3-turbo"
    res = mlx_whisper.transcribe(str(wav), path_or_hf_repo=repo, language=lang, word_timestamps=True,
                                 initial_prompt=prompt or None, condition_on_previous_text=False)
    words = []
    for seg in res.get("segments", []):
        for w in seg.get("words", []):
            t = w["word"].strip()
            if t:
                words.append(W(t, w["start"], w["end"], p=w.get("probability")))
    return words


def _align_sentence(text: str, ts: list, s0: float, s1: float, spk: str) -> list[dict]:
    toks: list[str] = []
    for m in re.finditer(TOKEN_RE.pattern + r"|[^\s]", text):
        t = m.group(0)
        if t in PUNCT and toks:
            toks[-1] += t
        elif t not in PUNCT:
            toks.append(t)
    out = []
    if ts and len(ts) == len(toks):
        for t, (a, b) in zip(toks, ts):
            out.append(W(t, a / 1000, b / 1000, spk))
    elif toks:  # fallback: spread evenly
        step = (s1 - s0) / len(toks)
        for i, t in enumerate(toks):
            out.append(W(t, s0 + i * step, s0 + (i + 1) * step, spk))
    return out


def run_funasr(wav: Path, lang: str | None, model: str | None, prompt: str, speakers: int | None,
               glossary: str) -> list[dict]:
    from funasr import AutoModel
    key = ("funasr", model, bool(speakers))
    if key not in _MODELS:
        kw = dict(model=model or "paraformer-zh", vad_model="fsmn-vad", punc_model="ct-punc",
                  disable_update=True)
        if speakers:
            kw["spk_model"] = "cam++"
        log(f"    loading FunASR {kw['model']}{' + cam++' if speakers else ''}")
        _MODELS[key] = AutoModel(**kw)
    m = _MODELS[key]
    gen = dict(input=str(wav), batch_size_s=300, sentence_timestamp=True)
    if glossary:
        gen["hotword"] = " ".join(x.strip() for x in re.split(r"[,，\s]+", glossary) if x.strip())
    res = m.generate(**gen)
    words: list[dict] = []
    r = res[0] if res else {}
    sents = r.get("sentence_info")
    if sents:
        for s in sents:
            spk = f"S{s.get('spk', 0)}"
            words += _align_sentence(s.get("text", ""), s.get("timestamp") or [],
                                     s.get("start", 0) / 1000, s.get("end", 0) / 1000, spk)
    elif r.get("text"):
        ts = r.get("timestamp") or []
        e = ts[-1][1] / 1000 if ts else 0
        words = _align_sentence(r["text"], ts, 0, e, "S0")
    return words


def run_scribe(wav: Path, lang: str | None, speakers: int | None) -> list[dict]:
    import urllib.request
    import uuid
    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        raise RuntimeError("ELEVENLABS_API_KEY not set")
    fields = {"model_id": os.environ.get("VS_SCRIBE_MODEL", "scribe_v1"), "diarize": "true",
              "tag_audio_events": "true", "timestamps_granularity": "word"}
    if lang:
        fields["language_code"] = lang[:2]
    if speakers:
        fields["num_speakers"] = str(speakers)
    boundary = uuid.uuid4().hex
    body = b""
    for k, v in fields.items():
        body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode()
    body += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\n"
             f"Content-Type: audio/wav\r\n\r\n").encode() + wav.read_bytes() + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request("https://api.elevenlabs.io/v1/speech-to-text", data=body, method="POST",
                                 headers={"xi-api-key": key,
                                          "Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=1800) as resp:
        data = json.loads(resp.read())
    words = []
    spk_map: dict = {}
    for w in data.get("words", []):
        if w.get("type") == "spacing":
            continue
        spk = w.get("speaker_id") or "speaker_0"
        spk_map.setdefault(spk, f"S{len(spk_map)}")
        typ = "event" if w.get("type") == "audio_event" else None
        words.append(W(w["text"].strip(), w["start"], w["end"], spk_map[spk], typ))
    return words


def parse_srt(path: Path) -> list[dict]:
    txt = path.read_text(encoding="utf-8-sig", errors="replace")
    words = []
    for block in re.split(r"\n\s*\n", txt.strip()):
        lines = [l for l in block.strip().splitlines() if l.strip()]
        tl = next((l for l in lines if "-->" in l), None)
        if not tl:
            continue
        a, b = [x.strip().replace(",", ".") for x in tl.split("-->")]
        s, e = _hms(a), _hms(b.split()[0])
        text = " ".join(lines[lines.index(tl) + 1:])
        text = re.sub(r"<[^>]+>|\{[^}]+\}", "", text)
        toks = []
        for m in re.finditer(TOKEN_RE.pattern + r"|[^\s]", text):
            t = m.group(0)
            if t in PUNCT and toks:
                toks[-1] += t
            elif t not in PUNCT:
                toks.append(t)
        if not toks:
            continue
        weights = [max(1, len(t.strip("".join(PUNCT)))) for t in toks]
        tot = sum(weights)
        cur = s
        for t, w_ in zip(toks, weights):
            d = (e - s) * w_ / tot
            words.append(W(t, cur, cur + d))
            cur += d
    return words


def _hms(s: str) -> float:
    h, m, sec = s.split(":")
    return int(h) * 3600 + int(m) * 60 + float(sec)


# --------------------------------------------------------------------- main


def fingerprint(info: dict, backend: str, model: str | None) -> str:
    p = Path(info["path"])
    st = p.stat()
    return hashlib.sha1(f"{p}|{st.st_size}|{int(st.st_mtime)}|{backend}|{model}".encode()).hexdigest()[:16]


def transcribe_source(edit: Path, sid: str, info: dict, args) -> None:
    out = edit / "transcripts" / f"{sid}.json"
    lang = args.language
    backend = args.backend
    has_srt = bool(info.get("sidecar_srt") or args.srt)
    if backend == "auto":
        backend = pick_backend(lang, has_srt)
    fp = fingerprint(info, backend, args.model)
    prev = read_json(out)
    if prev and prev.get("fingerprint") == fp and not args.force:
        log(f"  {sid}: cached ({prev.get('backend')}, {len(prev.get('words', []))} words)")
        return
    if not info.get("has_audio"):
        log(f"  {sid}: no audio — skipped")
        return
    log(f"  {sid}: {backend} · {fmt_t(info['duration'])}")
    t0 = time.time()
    prompt = ""
    if (lang or "zh").startswith("zh"):
        prompt = FILLER_PROMPT_ZH
    if args.glossary:
        prompt = f"{prompt} 专有名词：{args.glossary}。".strip()

    if backend == "srt":
        srt = Path(args.srt or info["sidecar_srt"])
        words = parse_srt(srt)
        approx = True
    else:
        approx = False
        ana = read_json(edit / "analysis" / f"{sid}.json", {}) or {}
        plan = chunk_plan(info["duration"], ana.get("silences", []), args.chunk)
        cdir = edit / "transcripts" / ".chunks" / sid
        words = []
        for ci, (a, b) in enumerate(plan):
            cfile = cdir / f"{fp}_{ci:03d}.json"
            cached = read_json(cfile)
            if cached is not None and not args.force:
                words += cached
                continue
            wav = extract_wav(info["path"], cdir / f"chunk_{ci:03d}.wav", a, b - a)
            if backend == "faster-whisper":
                cw = run_faster_whisper(wav, lang, args.model, prompt)
            elif backend == "mlx":
                cw = run_mlx(wav, lang, args.model, prompt)
            elif backend == "funasr":
                cw = run_funasr(wav, lang, args.model, prompt, args.speakers, args.glossary)
            elif backend == "scribe":
                cw = run_scribe(wav, lang, args.speakers)
            else:
                raise SystemExit(f"unknown backend {backend}")
            for w in cw:
                w["start"] = round(w["start"] + a, 3)
                w["end"] = round(w["end"] + a, 3)
            write_json(cfile, cw)
            wav.unlink(missing_ok=True)
            words += cw
            if len(plan) > 1:
                log(f"    chunk {ci + 1}/{len(plan)} done ({fmt_t(b)})")
    if (lang or "zh").startswith("zh"):
        words = to_simplified(words)
    words.sort(key=lambda w: w["start"])
    data = {"source": sid, "path": info["path"], "duration": info["duration"],
            "language": lang or "auto", "backend": backend + (f":{args.model}" if args.model else ""),
            "approximate": approx, "fingerprint": fp, "glossary": args.glossary or "",
            "words": words}
    write_json(out, data)
    n_f = sum(1 for w in words if w["type"] == "filler")
    log(f"  {sid}: {len(words)} words, {n_f} fillers, {time.time() - t0:.0f}s"
        + ("  (approximate timings)" if approx else ""))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", default=".")
    ap.add_argument("--ids", nargs="*")
    ap.add_argument("--backend", default=os.environ.get("VS_ASR", "auto"),
                    choices=["auto", "funasr", "mlx", "faster-whisper", "scribe", "srt"])
    ap.add_argument("--model")
    ap.add_argument("--language", default=os.environ.get("VS_LANG", "zh"),
                    help="zh / en / ja … ; 'auto' lets Whisper detect")
    ap.add_argument("--glossary", default=os.environ.get("VS_GLOSSARY", ""),
                    help="brand names / jargon, comma separated (hotwords)")
    ap.add_argument("--speakers", type=int)
    ap.add_argument("--srt", help="srt file to import (backend srt)")
    ap.add_argument("--chunk", type=float, default=600.0)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    if args.language == "auto":
        args.language = None

    edit = find_edit_dir(args.path)
    srcs = load_sources(edit)
    if not srcs:
        log("no sources.json — run ingest.py first")
        sys.exit(1)
    for sid, info in srcs.items():
        if args.ids and sid not in args.ids:
            continue
        try:
            transcribe_source(edit, sid, info, args)
        except Exception as e:  # keep going with other sources
            log(f"  {sid}: FAILED — {e}")


if __name__ == "__main__":
    main()

_ = (FILLERS_EN, FILLERS_ZH)  # re-exported for callers
