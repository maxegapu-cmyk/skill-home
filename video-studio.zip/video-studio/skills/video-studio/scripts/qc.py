#!/usr/bin/env python3
"""Automated self-check of a rendered video BEFORE showing it to the user.

  python qc.py edit/out/final.mp4 [--target-lufs -14] [--strict]

Uses <name>.render.json (written by render.py) for expected duration and cut points.
Checks: duration · streams/resolution · loudness + true peak · black frames · freezes ·
dead air · audio pops at every cut · flash frames at every cut · caption overflow /
flashing cues · then writes contact sheets you MUST look at:
  qc/<name>_cuts.png      before/after frame of every cut (+ caption on screen)
  qc/<name>_overview.png  12 evenly spaced frames
Report: qc/<name>_report.md. Exit 1 if any ERROR.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from io import BytesIO
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import fmt_t, load_audio, pil_font, probe, read_json  # noqa: E402


def stderr_of(cmd: list[str]) -> str:
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stderr.decode("utf-8", "replace")


def loudness(path: str) -> tuple[float | None, float | None]:
    txt = stderr_of(["ffmpeg", "-nostats", "-i", path, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"])
    i = re.findall(r"I:\s+(-?[\d.]+) LUFS", txt)
    p = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", txt)
    return (float(i[-1]) if i else None, float(p[-1]) if p else None)


def detect(path: str, vf: str, key_start: str, key_end: str) -> list[tuple[float, float]]:
    txt = stderr_of(["ffmpeg", "-nostats", "-i", path, "-an", "-vf", vf, "-f", "null", "-"])
    starts = [float(x) for x in re.findall(key_start + r"[:=]\s*(-?[\d.]+)", txt)]
    ends = [float(x) for x in re.findall(key_end + r"[:=]\s*(-?[\d.]+)", txt)]
    return list(zip(starts, ends + [None] * (len(starts) - len(ends))))


def frame_at(path: str, t: float, h: int = 240) -> Image.Image:
    res = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0, t):.3f}", "-i", path, "-frames:v", "1",
                          "-vf", f"scale=-2:{h}", "-f", "image2pipe", "-vcodec", "png", "-"], stdout=subprocess.PIPE)
    if not res.stdout:
        return Image.new("RGB", (h * 16 // 9, h), (60, 0, 0))
    return Image.open(BytesIO(res.stdout)).convert("RGB")


def frames_around(path: str, t: float, fps: float, n: int = 2) -> list[np.ndarray]:
    a = max(0, t - n / fps)
    res = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{a:.4f}", "-i", path, "-frames:v", str(2 * n + 1),
                          "-vf", "scale=64:64,format=gray", "-f", "rawvideo", "-"], stdout=subprocess.PIPE)
    buf = np.frombuffer(res.stdout, dtype=np.uint8)
    k = len(buf) // 4096
    return [buf[i * 4096:(i + 1) * 4096].astype(np.float32) for i in range(k)]


def parse_ass(path: Path) -> tuple[dict, list[dict]]:
    styles, events, fmt = {}, [], None
    play = {"x": 1920, "y": 1080}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("PlayResX:"):
            play["x"] = int(line.split(":")[1])
        elif line.startswith("PlayResY:"):
            play["y"] = int(line.split(":")[1])
        elif line.startswith("Format:") and fmt is None:
            fmt = [f.strip() for f in line[7:].split(",")]
        elif line.startswith("Style:"):
            vals = [v.strip() for v in line[6:].split(",")]
            st = dict(zip(fmt, vals)) if fmt else {}
            styles[st.get("Name")] = st
        elif line.startswith("Dialogue:"):
            parts = line[9:].split(",", 9)

            def ts(x):
                h, m, s = x.split(":")
                return int(h) * 3600 + int(m) * 60 + float(s)
            events.append({"start": ts(parts[1].strip()), "end": ts(parts[2].strip()), "style": parts[3].strip(),
                           "text": re.sub(r"\{[^}]*\}", "", parts[9])})
    return {"play": play, "styles": styles}, events


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("video")
    ap.add_argument("--target-lufs", type=float)
    ap.add_argument("--strict", action="store_true", help="warnings also fail")
    args = ap.parse_args()
    vp = Path(args.video).resolve()
    meta = read_json(vp.with_suffix(".render.json"), {}) or {}
    name = vp.stem
    qdir = vp.parent.parent / "qc" if vp.parent.name == "out" else vp.parent / "qc"
    qdir.mkdir(parents=True, exist_ok=True)
    errs, warns, notes = [], [], []

    info = probe(vp)
    D = info["duration"]
    fps = info.get("fps") or 30
    exp = meta.get("duration")
    if exp is not None and abs(D - exp) > max(0.1, 2 / fps):
        errs.append(f"duration {D:.2f}s ≠ timeline {exp:.2f}s")
    spec = meta.get("spec") or {}
    if spec and (info.get("width"), info.get("height")) != (spec.get("width"), spec.get("height")):
        errs.append(f"resolution {info.get('width')}x{info.get('height')} ≠ spec {spec.get('width')}x{spec.get('height')}")
    if info.get("pix_fmt") != "yuv420p":
        warns.append(f"pix_fmt {info.get('pix_fmt')} (platforms expect yuv420p)")
    if not info.get("has_audio"):
        warns.append("no audio stream")
    notes.append(f"{info.get('width')}x{info.get('height')} @ {fps} fps, {fmt_t(D)}, {info['size_mb']} MB")

    # loudness
    target = args.target_lufs if args.target_lufs is not None else -14.0
    if info.get("has_audio"):
        I, TP = loudness(str(vp))
        notes.append(f"loudness {I} LUFS, true peak {TP} dBFS (target {target})")
        if I is not None and abs(I - target) > 2:
            warns.append(f"integrated loudness {I} LUFS, target {target}")
        if TP is not None and TP > -0.5:
            errs.append(f"true peak {TP} dBFS > -0.5 (clipping risk after platform transcode)")

    cuts = meta.get("cuts") or []
    tl = meta.get("timeline") or []
    faded = set()
    for s in tl:
        if s.get("td", 0) > 0:
            faded.add(round(s["out_start"] + s["td"], 3))

    # black / freeze
    for s, e in detect(str(vp), "blackdetect=d=0.25:pix_th=0.08", "black_start", "black_end"):
        msg = f"black frames {fmt_t(s)}–{fmt_t(e) if e else 'end'}"
        (notes if (s < 0.3 or (e and e > D - 0.6)) else warns).append(msg)
    for s, e in detect(str(vp), "fps=10,scale=320:-2,freezedetect=n=-55dB:d=2", "freeze_start", "freeze_end"):
        warns.append(f"frozen picture {fmt_t(s)}–{fmt_t(e) if e else 'end'} (fine if it's a still/card)")

    # audio: dead air + pops at cuts
    if info.get("has_audio"):
        sr = 48000
        x = load_audio(vp, sr=sr)
        hop = int(sr * 0.05)
        n = len(x) // hop
        env = 20 * np.log10(np.sqrt(np.mean(x[: n * hop].reshape(n, hop) ** 2, axis=1) + 1e-12) + 1e-9)
        quiet = env < max(-50.0, float(np.percentile(env, 50)) - 25)
        run_len, start = 0, 0
        for i, q in enumerate(list(quiet) + [False]):
            if q:
                if run_len == 0:
                    start = i
                run_len += 1
            else:
                a_, b_ = start * 0.05, (start + run_len) * 0.05
                intended = any(s.get("silent") and s["out_start"] - 0.3 <= a_ and b_ <= s["out_end"] + 0.4
                               for s in tl)
                if run_len * 0.05 >= 1.2 and a_ > 0.3 and b_ < D - 0.5 and not intended:
                    warns.append(f"dead air {fmt_t(a_)} ({run_len * 0.05:.1f}s)")
                run_len = 0
        for c in cuts:
            i0, i1 = int((c - 0.025) * sr), int((c + 0.025) * sr)
            j0, j1 = int((c - 0.25) * sr), int((c + 0.25) * sr)
            if i0 < 1 or j1 >= len(x):
                continue
            d = np.abs(np.diff(x[i0:i1]))
            ref = np.sqrt(np.mean(x[j0:j1] ** 2)) + 1e-4
            ref_d = np.percentile(np.abs(np.diff(x[j0:j1])), 99) + 1e-5
            if d.max() > 4 * ref_d and d.max() > 0.08 and d.max() / ref > 6:
                warns.append(f"possible pop at cut {fmt_t(c)} (Δ={d.max():.3f})")

    # flash frames at cuts
    for c in cuts:
        fr = frames_around(str(vp), c, fps, 2)
        for k in range(1, len(fr) - 1):
            a, b, z = fr[k - 1], fr[k], fr[k + 1]
            d_ab, d_bz, d_az = (np.mean(np.abs(a - b)), np.mean(np.abs(b - z)), np.mean(np.abs(a - z)))
            if d_ab > 35 and d_bz > 35 and d_az < 12:
                errs.append(f"flash frame near cut {fmt_t(c)}")
                break

    # captions
    cap = meta.get("captions")
    if cap and Path(cap).exists():
        hdr, evs = parse_ass(Path(cap))
        W = hdr["play"]["x"]
        over, flash = 0, 0
        for ev in evs:
            st = hdr["styles"].get(ev["style"], {})
            size = int(float(st.get("Fontsize", 60)))
            margin = int(st.get("MarginL", 0)) + int(st.get("MarginR", 0))
            f = pil_font(size)
            wpx = ImageDraw.Draw(Image.new("RGB", (10, 10))).textlength(ev["text"], font=f)
            if wpx > W - margin:
                over += 1
                if over <= 3:
                    warns.append(f"caption wraps to 2 lines at {fmt_t(ev['start'])}: “{ev['text']}”")
            if ev["style"] == "Cap" and ev["end"] - ev["start"] < 0.35:
                flash += 1
        if over > 3:
            warns.append(f"…{over} captions wrap in total (lower max_chars)")
        if flash:
            warns.append(f"{flash} caption cue(s) shorter than 0.35s")
        notes.append(f"{sum(1 for e in evs if e['style'] == 'Cap')} caption cues")

    # contact sheets
    fnt = pil_font(18)
    if cuts:
        th = 200
        pairs = []
        for c in cuts:
            pairs.append((c, frame_at(str(vp), c - 0.12, th), frame_at(str(vp), c + 0.12, th)))
        pw = pairs[0][1].width
        cols = max(1, min(4, 1800 // (pw * 2 + 30)))
        rows = (len(pairs) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * (pw * 2 + 30) + 10, rows * (th + 34) + 10), (16, 16, 18))
        dr = ImageDraw.Draw(sheet)
        for i, (c, a, b) in enumerate(pairs):
            x0, y0 = 10 + (i % cols) * (pw * 2 + 30), 10 + (i // cols) * (th + 34)
            sheet.paste(a, (x0, y0 + 24))
            sheet.paste(b, (x0 + pw + 4, y0 + 24))
            dr.text((x0, y0), f"cut {i + 1} @ {fmt_t(c)}  before | after", font=fnt, fill=(230, 230, 230))
        sheet.save(qdir / f"{name}_cuts.png")
    ov = [frame_at(str(vp), D * (k + 0.5) / 12, 180) for k in range(12)]
    ow = ov[0].width
    sheet = Image.new("RGB", (6 * (ow + 6) + 6, 2 * (180 + 26) + 6), (16, 16, 18))
    dr = ImageDraw.Draw(sheet)
    for k, im in enumerate(ov):
        x0, y0 = 6 + (k % 6) * (ow + 6), 6 + (k // 6) * 206
        sheet.paste(im, (x0, y0 + 22))
        dr.text((x0, y0), fmt_t(D * (k + 0.5) / 12), font=fnt, fill=(200, 200, 200))
    sheet.save(qdir / f"{name}_overview.png")

    lines = [f"# QC — {vp.name}", "", *[f"- {n}" for n in notes], ""]
    lines += ["## Errors", *([f"- ✗ {e}" for e in errs] or ["- none"]), "",
              "## Warnings", *([f"- ⚠ {w}" for w in warns] or ["- none"]), "",
              f"Contact sheets: `{qdir / (name + '_cuts.png')}` and `{qdir / (name + '_overview.png')}` — "
              "open both and look before presenting."]
    (qdir / f"{name}_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    sys.exit(1 if errs or (args.strict and warns) else 0)


if __name__ == "__main__":
    main()
