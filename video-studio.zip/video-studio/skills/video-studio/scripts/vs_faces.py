"""Face detection with graceful backends (used by reframe.py and deliver.py).

Order: OpenCV Haar (opencv < 5, offline) → YuNet DNN (cv2.FaceDetectorYN, model auto-downloaded
once to ~/.cache/video-studio/) → MediaPipe (if installed) → none.
"""
from __future__ import annotations

import os
import urllib.request
from pathlib import Path

import numpy as np

YUNET_URLS = [
    "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/face_detection_yunet/"
    "face_detection_yunet_2023mar.onnx",
    "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
]
_STATE: dict = {}


def _yunet_model() -> Path | None:
    cands = [Path(__file__).resolve().parent.parent / "assets" / "models" / "face_detection_yunet_2023mar.onnx",
             Path.home() / ".cache" / "video-studio" / "face_detection_yunet_2023mar.onnx"]
    for c in cands:
        if c.exists() and c.stat().st_size > 10000:
            return c
    if os.environ.get("VS_NO_DOWNLOAD"):
        return None
    dst = cands[1]
    dst.parent.mkdir(parents=True, exist_ok=True)
    for url in YUNET_URLS:
        try:
            with urllib.request.urlopen(url, timeout=30) as r:
                data = r.read()
            if len(data) > 10000:
                dst.write_bytes(data)
                return dst
        except Exception:
            continue
    return None


def backend() -> str:
    if "backend" in _STATE:
        return _STATE["backend"]
    b = "none"
    try:
        import cv2
        if hasattr(cv2, "CascadeClassifier") and hasattr(cv2, "data"):
            b = "haar"
        elif hasattr(cv2, "FaceDetectorYN") and _yunet_model():
            b = "yunet"
    except ImportError:
        pass
    if b == "none":
        try:
            import mediapipe
            if hasattr(mediapipe, "solutions"):
                b = "mediapipe"
        except ImportError:
            pass
    _STATE["backend"] = b
    return b


def detect(gray: np.ndarray) -> list[tuple[float, float, float, float]]:
    """Return face boxes (x, y, w, h) in pixels for a grayscale uint8 image."""
    b = backend()
    h, w = gray.shape[:2]
    if b == "haar":
        import cv2
        if "haar" not in _STATE:
            _STATE["haar"] = (cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml"),
                              cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_profileface.xml"))
        front, prof = _STATE["haar"]
        ms = (max(20, int(w * 0.04)),) * 2
        faces = front.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=ms)
        if len(faces) == 0:
            faces = prof.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=ms)
        return [tuple(map(float, f)) for f in faces]
    if b == "yunet":
        import cv2
        key = ("yunet", w, h)
        if key not in _STATE:
            _STATE[key] = cv2.FaceDetectorYN.create(str(_yunet_model()), "", (w, h), 0.7, 0.3, 50)
        img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        _n, faces = _STATE[key].detect(img)
        return [tuple(map(float, f[:4])) for f in (faces if faces is not None else [])]
    if b == "mediapipe":
        import mediapipe as mp
        if "mp" not in _STATE:
            _STATE["mp"] = mp.solutions.face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.5)
        rgb = np.stack([gray] * 3, axis=-1)
        res = _STATE["mp"].process(rgb)
        out = []
        for d in res.detections or []:
            bb = d.location_data.relative_bounding_box
            out.append((bb.xmin * w, bb.ymin * h, bb.width * w, bb.height * h))
        return out
    return []
