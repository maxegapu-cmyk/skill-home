#!/usr/bin/env python3
"""Face-aware reframing: find where the speaker is in each range → crop_x / crop_y in the EDL.

Landscape → 9:16 with a centre crop cuts people in half; with "blur" you get a small
picture. This samples each range at 2 fps, detects faces (vs_faces: OpenCV Haar / YuNet /
MediaPipe), and writes the median face position so render.py crops on the person.

  python reframe.py edit/edl.json                  # all ranges (writes crop_x/crop_y, reframe=cover)
  python reframe.py edit/edl.json --dry-run

Ranges with no face found are left alone (they fall back to the blur layout).
Needs: pip install "opencv-python-headless>=4.8,<5" (Haar, offline) — OpenCV 5 uses YuNet (auto-download)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import log, parse_t, probe, write_json  # noqa: E402
from vs_edl import IMAGE_EXT, load_edl, source_map  # noqa: E402


def sample_frames(src: Path, start: float, end: float, fps: float = 2.0, width: int = 640):
    info = probe(src)
    h = int(round(info["height"] * width / info["width"] / 2) * 2)
    dur = max(0.2, end - start)
    res = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(src),
                          "-vf", f"fps={fps},scale={width}:{h},format=gray", "-f", "rawvideo", "-"],
                         stdout=subprocess.PIPE)
    buf = np.frombuffer(res.stdout, dtype=np.uint8)
    n = len(buf) // (width * h)
    return [buf[i * width * h:(i + 1) * width * h].reshape(h, width) for i in range(n)], width, h


def face_center(frames, w, h):
    from vs_faces import detect
    xs, ys, sizes = [], [], []
    for f in frames:
        faces = detect(f)
        if len(faces) == 0:
            continue
        x, y, fw, fh = max(faces, key=lambda b: b[2] * b[3])
        xs.append((x + fw / 2) / w)
        ys.append((y + fh * 0.75) / h)  # bias toward upper body, keep headroom
        sizes.append(fw / w)
    if len(xs) < max(1, len(frames) * 0.25):
        return None
    return float(np.median(xs)), float(np.median(ys)), float(np.median(sizes)), len(xs) / max(1, len(frames))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("edl")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("-o", "--out")
    args = ap.parse_args()
    from vs_faces import backend
    if backend() == "none":
        sys.exit('no face detector: pip install "opencv-python-headless>=4.8,<5"  (or allow the YuNet download)')
    log(f"face detector: {backend()}")
    edl, p, edit = load_edl(args.edl)
    srcmap = source_map(edl, p, edit)
    changed = 0
    for i, r in enumerate(edl["ranges"]):
        src = srcmap.get(r["source"])
        if not src or src.suffix.lower() in IMAGE_EXT or "crop_x" in r:
            continue
        frames, w, h = sample_frames(src, parse_t(r["start"]), parse_t(r["end"]))
        res = face_center(frames, w, h) if frames else None
        if res is None:
            log(f"  [{i:02d}] no stable face → keep layout")
            continue
        cx, cy, size, hit = res
        log(f"  [{i:02d}] face at x={cx:.2f} y={cy:.2f} (size {size:.2f}, seen {hit:.0%})")
        r["crop_x"], r["crop_y"] = round(cx, 3), round(min(max(cy - 0.12, 0.3), 0.6), 3)
        r.setdefault("reframe", "cover")
        changed += 1
    if not args.dry_run:
        write_json(Path(args.out) if args.out else p, edl)
    log(f"✓ reframed {changed}/{len(edl['ranges'])} ranges")


if __name__ == "__main__":
    main()
