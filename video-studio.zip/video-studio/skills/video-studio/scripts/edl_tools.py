#!/usr/bin/env python3
"""EDL utilities — the mechanical parts of editing, so judgment goes to the story.

  snap      snap every range edge to word boundaries + padding (never cut inside a word)
  tighten   split ranges to drop internal dead air (> --max-gap) and isolated fillers (嗯/啊/um)
  clips     live-stream slicing: clips.json + style template → one EDL per clip (snapped, tightened)
  show      print the EDL as text: each range's actual spoken words, output timecodes, total

  python edl_tools.py snap    edit/edl.json [--pad-in 0.05 --pad-out 0.08] [-o out.json]
  python edl_tools.py tighten edit/edl.json [--max-gap 0.45 --keep-gap 0.18 --fillers] [-o out.json]
  python edl_tools.py clips   edit/clips.json --template edit/clip_style.json --outdir edit/clips
  python edl_tools.py show    edit/edl.json

clips.json:  [{"id": "c01", "title": "首付1.9万怎么做到的", "source": "live", "start": "1:02:11.2",
               "end": "1:03:05", "hook": [12.3, 15.0]?, "cover_title": "…", "highlight": ["首付"]}]
  "hook" (optional, source seconds): a 2–4 s punchline moved to the front as a cold open.
template:    any EDL fields without "ranges" (captions, titles, audio, variants, grade, output…);
             "{title}" inside template strings is replaced per clip.
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import fmt_t, join_tokens, log, parse_t, read_json, write_json  # noqa: E402
from vs_edl import build_timeline, load_edl, source_map  # noqa: E402


def words_for(edit: Path, sid: str, cache: dict) -> list[dict]:
    if sid not in cache:
        tr = read_json(edit / "transcripts" / f"{sid}.json") or {}
        cache[sid] = [w for w in tr.get("words", []) if w.get("type") != "event"]
    return cache[sid]


def snap_range(r: dict, words: list[dict], pad_in: float, pad_out: float) -> dict:
    if not words or r.get("image") or r.get("nosnap"):
        return r
    s, e = parse_t(r["start"]), parse_t(r["end"])
    inside = [w for w in words if w["end"] > s and w["start"] < e]
    if not inside:
        return r
    first, last = inside[0], inside[-1]
    # a word only barely touched by the range edge is excluded, a mostly-covered one is included
    if first["start"] < s and (first["end"] - s) < (first["end"] - first["start"]) * 0.35 and len(inside) > 1:
        first = inside[1]
    if last["end"] > e and (e - last["start"]) < (last["end"] - last["start"]) * 0.35 and len(inside) > 1:
        last = inside[-2]
    i0, i1 = words.index(first), words.index(last)
    prev_end = words[i0 - 1]["end"] if i0 > 0 else 0.0
    next_start = words[i1 + 1]["start"] if i1 + 1 < len(words) else last["end"] + 1.0
    ns = max(prev_end + 0.01, first["start"] - pad_in, 0.0)
    ne = min(next_start - 0.01, last["end"] + pad_out)
    out = dict(r)
    out["start"], out["end"] = round(ns, 3), round(max(ne, ns + 0.1), 3)
    return out


def tighten_range(r: dict, words: list[dict], max_gap: float, keep_gap: float, drop_fillers: bool,
                  min_len: float = 0.35) -> list[dict]:
    if not words or r.get("image") or r.get("keep"):
        return [r]
    s, e = parse_t(r["start"]), parse_t(r["end"])
    ws = [w for w in words if w["start"] >= s - 0.02 and w["end"] <= e + 0.02]
    if not ws:
        return [r]
    keep: list[dict] = []
    for k, w in enumerate(ws):
        if drop_fillers and w.get("type") == "filler":
            gap_b = w["start"] - (ws[k - 1]["end"] if k else s)
            gap_a = (ws[k + 1]["start"] if k + 1 < len(ws) else e) - w["end"]
            if gap_b >= 0.06 or gap_a >= 0.06:
                continue  # isolated filler → drop
        keep.append(w)
    if not keep:
        return []
    pieces: list[list[dict]] = [[keep[0]]]
    for a, b in zip(keep, keep[1:]):
        gap = b["start"] - a["end"]
        skipped = ws.index(b) - ws.index(a) > 1
        if gap > max_gap or skipped:
            pieces.append([b])
        else:
            pieces[-1].append(b)
    out = []
    half = keep_gap / 2
    for i, pc in enumerate(pieces):
        ps = s if i == 0 else max(s, pc[0]["start"] - half)
        pe = e if i == len(pieces) - 1 else min(e, pc[-1]["end"] + half)
        if pe - ps < min_len and out:
            out[-1]["end"] = round(pe, 3)
            continue
        nr = {k: v for k, v in r.items() if k not in ("start", "end")}
        nr["start"], nr["end"] = round(ps, 3), round(pe, 3)
        if i > 0:
            nr.pop("fade_in", None)
            nr["beat"] = r.get("beat", "")
        if i < len(pieces) - 1:
            nr.pop("fade_out", None)
        out.append(nr)
    return out


def range_text(r: dict, words: list[dict]) -> str:
    s, e = parse_t(r["start"]), parse_t(r["end"])
    return join_tokens([("{" + w["text"] + "}") if w.get("type") == "filler" else w["text"]
                        for w in words if (w["start"] + w["end"]) / 2 >= s and (w["start"] + w["end"]) / 2 <= e])


def cmd_snap(args) -> None:
    edl, p, edit = load_edl(args.edl)
    cache: dict = {}
    edl["ranges"] = [snap_range(r, words_for(edit, r["source"], cache), args.pad_in, args.pad_out)
                     for r in edl["ranges"]]
    out = Path(args.out) if args.out else p
    write_json(out, edl)
    log(f"✓ snapped {len(edl['ranges'])} ranges → {out}")


def cmd_tighten(args) -> None:
    edl, p, edit = load_edl(args.edl)
    cache: dict = {}
    before = build_timeline(edl)[-1]["out_end"]
    new = []
    for r in edl["ranges"]:
        new += tighten_range(r, words_for(edit, r["source"], cache), args.max_gap, args.keep_gap, args.fillers)
    edl["ranges"] = new
    out = Path(args.out) if args.out else p
    write_json(out, edl)
    after = build_timeline(edl)[-1]["out_end"]
    log(f"✓ tightened: {fmt_t(before)} → {fmt_t(after)} ({len(new)} ranges) → {out}")


def _fill(obj, title: str):
    if isinstance(obj, str):
        return obj.replace("{title}", title)
    if isinstance(obj, list):
        return [_fill(x, title) for x in obj]
    if isinstance(obj, dict):
        return {k: _fill(v, title) for k, v in obj.items()}
    return obj


def cmd_clips(args) -> None:
    clips = read_json(args.clips)
    tpl = read_json(args.template) if args.template else {}
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    clips_path = Path(args.clips).resolve()
    edit = clips_path.parent
    while edit.name != "edit" and edit.parent != edit and not (edit / "sources.json").exists():
        edit = edit.parent
    cache: dict = {}
    made = []
    for c in clips:
        edl = _fill(copy.deepcopy(tpl), c.get("title", ""))
        edl.pop("ranges", None)
        edl["name"] = c.get("id") or c.get("title", "clip")
        sid = c["source"]
        words = words_for(edit, sid, cache)
        main = {"source": sid, "start": parse_t(c["start"]), "end": parse_t(c["end"]), "beat": "BODY"}
        ranges = []
        if c.get("hook"):
            h0, h1 = parse_t(c["hook"][0]), parse_t(c["hook"][1])
            ranges.append(snap_range({"source": sid, "start": h0, "end": h1, "beat": "COLD-OPEN"}, words,
                                     args.pad_in, args.pad_out))
        body = snap_range(main, words, args.pad_in, args.pad_out)
        ranges += tighten_range(body, words, args.max_gap, args.keep_gap, True) if not args.no_tighten else [body]
        edl["ranges"] = ranges
        if c.get("highlight"):
            edl.setdefault("captions", {}).setdefault("highlight", [])
            edl["captions"]["highlight"] = list(dict.fromkeys(edl["captions"]["highlight"] + c["highlight"]))
        edl["meta"] = {k: v for k, v in c.items() if k not in ("source", "start", "end")}
        if "variants" in edl:
            for v in edl["variants"]:
                v["name"] = f"{edl['name']}_{v.get('name', 'v')}"
        out = outdir / f"{edl['name']}.json"
        write_json(out, edl)
        made.append((out, build_timeline(edl)[-1]["out_end"], c.get("title", "")))
    for out, d, t in made:
        print(f"{out.name:<24} {fmt_t(d):>8}  {t}")
    print(f"\n{len(made)} clip EDL(s) → {outdir}. Render all: python render.py '{outdir}/*.json' --preview")


def cmd_show(args) -> None:
    edl, p, edit = load_edl(args.edl)
    cache: dict = {}
    tl = build_timeline(edl)
    srcmap = source_map(edl, p, edit)
    for r, seg in zip(edl["ranges"], tl):
        txt = range_text(r, words_for(edit, r["source"], cache)) if r["source"] in srcmap else ""
        extra = []
        for k in ("zoom", "speed", "crop_x", "grade", "fade_in", "fade_out"):
            if k in r:
                extra.append(f"{k}={r[k]}")
        print(f"[{fmt_t(seg['out_start'])}] {r['source']} {parse_t(r['start']):.2f}-{parse_t(r['end']):.2f}"
              f" ({seg['dur']:.2f}s) {r.get('beat', '')} {' '.join(extra)}\n    {txt}")
    print(f"\nTOTAL {fmt_t(tl[-1]['out_end'] if tl else 0)} · {len(tl)} ranges")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("snap", "tighten", "show"):
        p = sub.add_parser(name)
        p.add_argument("edl")
        p.add_argument("-o", "--out")
        p.add_argument("--pad-in", type=float, default=0.05)
        p.add_argument("--pad-out", type=float, default=0.08)
        p.add_argument("--max-gap", type=float, default=0.45)
        p.add_argument("--keep-gap", type=float, default=0.18)
        p.add_argument("--fillers", action="store_true", help="also drop isolated fillers")
    c = sub.add_parser("clips")
    c.add_argument("clips")
    c.add_argument("--template")
    c.add_argument("--outdir", required=True)
    c.add_argument("--pad-in", type=float, default=0.05)
    c.add_argument("--pad-out", type=float, default=0.12)
    c.add_argument("--max-gap", type=float, default=0.6)
    c.add_argument("--keep-gap", type=float, default=0.22)
    c.add_argument("--no-tighten", action="store_true")
    args = ap.parse_args()
    {"snap": cmd_snap, "tighten": cmd_tighten, "clips": cmd_clips, "show": cmd_show}[args.cmd](args)


if __name__ == "__main__":
    main()

_ = json  # noqa
