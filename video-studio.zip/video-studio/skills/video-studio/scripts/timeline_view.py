#!/usr/bin/env python3
"""Visual drill-down: filmstrip + waveform + words + silences for a time range → PNG.

Use at DECISION POINTS (ambiguous pause, retake comparison, cut sanity check,
self-eval of a rendered cut) — not to scan whole videos.

  python timeline_view.py --edit <dir> --src C01 12.0 18.5
  python timeline_view.py --edit <dir> --file edit/out/final.mp4 30 34 --marks 32.1
  python timeline_view.py --edit <dir> --src C01 1:02:00 1:02:20 --frames 10 -o /tmp/x.png

--file on a render produced by render.py automatically picks up its
<name>.words.json (output-timeline words) so you can read captions vs picture.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import (find_edit_dir, fmt_t, load_audio, load_sources, parse_t, pil_font,  # noqa: E402
                       probe, read_json, rms_envelope)

W = 1600
BG = (18, 18, 20)
FG = (230, 230, 230)
DIM = (120, 120, 128)
ACC = (255, 120, 40)
FILL = (255, 196, 0)


def grab(path: str, t: float, h: int) -> Image.Image:
    res = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", path, "-frames:v", "1",
                          "-vf", f"scale=-2:{h}", "-f", "image2pipe", "-vcodec", "png", "-"],
                         stdout=subprocess.PIPE)
    if not res.stdout:
        return Image.new("RGB", (int(h * 16 / 9), h), (40, 0, 0))
    return Image.open(BytesIO(res.stdout)).convert("RGB")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--edit", default=".", help="edit dir or videos dir (default: cwd)")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--src")
    g.add_argument("--file")
    ap.add_argument("start")
    ap.add_argument("end")
    ap.add_argument("--frames", type=int, default=8)
    ap.add_argument("--marks", default="", help="comma separated times to draw as red lines (cut points)")
    ap.add_argument("--words", help="words json override")
    ap.add_argument("-o", "--out")
    args = ap.parse_args()

    edit = find_edit_dir(args.edit)
    a, b = parse_t(args.start), parse_t(args.end)
    if b <= a:
        sys.exit("end must be > start")
    words: list[dict] = []
    silences: list = []
    if args.src:
        srcs = load_sources(edit)
        vpath = srcs[args.src]["path"]
        tr = read_json(edit / "transcripts" / f"{args.src}.json") or {}
        words = tr.get("words", [])
        silences = (read_json(edit / "analysis" / f"{args.src}.json") or {}).get("silences", [])
        label = args.src
    else:
        vpath = str(Path(args.file).resolve())
        wj = Path(args.words) if args.words else Path(vpath).with_suffix(".words.json")
        words = (read_json(wj) or {}).get("words", []) if wj.exists() else []
        label = Path(vpath).name
    if args.words and args.src:
        words = (read_json(args.words) or {}).get("words", [])
    info = probe(vpath)
    dur = b - a
    portrait = info.get("orientation") == "portrait"

    fh = 260 if portrait else 150
    n = max(2, args.frames)
    times = [a + dur * (i + 0.5) / n for i in range(n)]
    thumbs = [grab(vpath, t, fh) for t in times] if info.get("has_video") else []
    tw = thumbs[0].width if thumbs else 0
    cols = n
    if thumbs and tw * n > W - 20:
        scale = (W - 20) / (tw * n)
        thumbs = [im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale)))) for im in thumbs]
        fh = thumbs[0].height
        tw = thumbs[0].width

    wave_h, word_h, head_h, axis_h = 120, 84, 34, 22
    H = head_h + (fh + 22 if thumbs else 0) + wave_h + word_h + axis_h + 10
    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)
    f_small, f_mid = pil_font(15), pil_font(18)
    d.text((10, 8), f"{label}   {fmt_t(a)} → {fmt_t(b)}   ({dur:.2f}s)", font=f_mid, fill=FG)

    y = head_h
    x0, x1 = 10, W - 10

    def tx(t: float) -> float:
        return x0 + (t - a) / dur * (x1 - x0)

    if thumbs:
        gap = ((x1 - x0) - tw * cols) / max(1, cols - 1) if cols > 1 else 0
        for i, (im, t) in enumerate(zip(thumbs, times)):
            px = int(x0 + i * (tw + gap))
            img.paste(im, (px, y))
            d.text((px + 3, y + fh + 2), fmt_t(t), font=f_small, fill=DIM)
        y += fh + 22

    # waveform
    if info.get("has_audio"):
        sr = 8000
        x = load_audio(vpath, sr=sr, start=a, duration=dur)
        env = rms_envelope(x, sr, hop_s=dur / (x1 - x0) if dur / (x1 - x0) > 1 / sr else 1 / sr)
        for s, e in silences:
            if e > a and s < b:
                d.rectangle([tx(max(s, a)), y, tx(min(e, b)), y + wave_h], fill=(34, 40, 58))
        mid = y + wave_h / 2
        if len(env):
            lo, hi = -60.0, max(-6.0, float(env.max()))
            for i, v in enumerate(env):
                px = x0 + i * (x1 - x0) / len(env)
                amp = (min(max(v, lo), hi) - lo) / (hi - lo) * (wave_h / 2 - 4)
                d.line([(px, mid - amp), (px, mid + amp)], fill=(90, 170, 255))
        d.text((x0 + 4, y + 2), "waveform  (blue band = detected silence)", font=f_small, fill=DIM)
    y += wave_h

    # words, two staggered lanes
    lane_y = [y + 8, y + 44]
    last_x = [-1e9, -1e9]
    for w in words:
        if w["end"] < a or w["start"] > b:
            continue
        sx, ex = tx(max(w["start"], a)), tx(min(w["end"], b))
        col = FILL if w.get("type") == "filler" else (ACC if w.get("type") == "event" else FG)
        lane = 0 if sx > last_x[0] else (1 if sx > last_x[1] else 0)
        d.rectangle([sx, lane_y[lane] + 26, max(sx + 1, ex), lane_y[lane] + 30], fill=col)
        d.text((sx, lane_y[lane]), w["text"], font=f_mid, fill=col)
        last_x[lane] = sx + d.textlength(w["text"], font=f_mid) + 4
    y += word_h

    # axis
    step = next(s for s in (0.1, 0.25, 0.5, 1, 2, 5, 10, 30, 60, 120, 300) if dur / s <= 16)
    t = (int(a / step) + 1) * step
    while t < b:
        px = tx(t)
        d.line([(px, y), (px, y + 6)], fill=DIM)
        d.text((px + 2, y + 4), f"{t:.2f}" if step < 1 else fmt_t(t), font=f_small, fill=DIM)
        t += step
    for m in [parse_t(v) for v in args.marks.split(",") if v.strip()]:
        if a <= m <= b:
            d.line([(tx(m), head_h), (tx(m), H - 4)], fill=(255, 40, 60), width=2)

    out = Path(args.out) if args.out else edit / "verify" / f"tv_{label.replace('.', '_')}_{a:.2f}_{b:.2f}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out)
    print(out)


if __name__ == "__main__":
    main()
