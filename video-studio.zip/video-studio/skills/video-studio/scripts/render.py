#!/usr/bin/env python3
"""Render an EDL to a finished video.

Pipeline (order is load-bearing, see SKILL.md hard rules):
  1. per-range extract → reframe/zoom/grade/speed/fades, video+PCM audio, frame-exact,
     cached by content hash (re-renders only touch changed ranges)
  2. assemble: lossless concat, or xfade/acrossfade chain when transitions are set
  3. compose: overlays (PTS-shifted) → logo → progress bar → captions/titles LAST,
     audio bus: dialogue (+voiceover) → BGM ducked by sidechain → SFX
  4. master: two-pass loudnorm (-14 LUFS, -1 dBTP default) → AAC, +faststart
  5. write <name>.render.json (timeline, cut points) + <name>.words.json for QC

Usage:
  python render.py edit/edl.json                    # all variants, final quality
  python render.py edit/edl.json --draft            # half-res, fastest: check cuts
  python render.py edit/edl.json --preview          # full-res, fast preset
  python render.py edit/edl.json --variant vertical -o out.mp4
  python render.py edit/clips/*.json                # batch (live-stream slices)
  python render.py edit/edl.json --validate         # check only
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import math
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import captions as capmod  # noqa: E402
from vs_common import find_cjk_font, fmt_t, log, parse_t, probe, run, write_json  # noqa: E402
from vs_edl import (IMAGE_EXT, EDLError, build_timeline, load_edl, output_spec, resolve,  # noqa: E402
                    source_map, validate)

GRADES = {
    "none": "",
    "neutral_punch": "eq=contrast=1.05:saturation=1.05,unsharp=5:5:0.35",
    "bright_clean": "eq=brightness=0.035:contrast=1.04:saturation=1.08:gamma=1.07,unsharp=5:5:0.45",
    "warm_cinematic": "colorbalance=rs=0.04:bs=-0.04:rh=0.03:bh=-0.03,eq=contrast=1.05:saturation=0.92,"
                      "curves=all='0/0.03 0.5/0.5 1/0.97'",
    "vivid": "eq=contrast=1.08:saturation=1.22,unsharp=5:5:0.55",
    "teal_orange": "colorbalance=rs=-0.05:bs=0.08:rh=0.07:bh=-0.06,eq=contrast=1.06:saturation=1.05",
    "film_fade": "curves=all='0/0.06 0.5/0.5 1/0.94',eq=saturation=0.86",
    "bw": "hue=s=0,eq=contrast=1.12",
}
VOICE_ENHANCE = ("highpass=f=80,lowpass=f=12000,afftdn=nr=12:nf=-30:tn=1,"
                 "acompressor=threshold=-20dB:ratio=3:attack=5:release=80:makeup=2,"
                 "equalizer=f=3200:t=q:w=1.2:g=2.5")
TONEMAP = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
           "zscale=t=bt709:m=bt709:r=tv,format=yuv420p")
QUALITY = {  # preset, crf
    "draft": ("ultrafast", "28"), "preview": ("veryfast", "22"), "final": ("medium", "18"),
}

_probe_cache: dict[str, dict] = {}


def pinfo(p: Path) -> dict:
    k = str(p)
    if k not in _probe_cache:
        _probe_cache[k] = probe(p) if p.suffix.lower() not in IMAGE_EXT else {"image": True, "has_audio": False,
                                                                               "has_video": True}
    return _probe_cache[k]


# --------------------------------------------------------------------- filters


def atempo_chain(speed: float) -> list[str]:
    out, s = [], speed
    while s > 2.0:
        out.append("atempo=2.0")
        s /= 2.0
    while s < 0.5:
        out.append("atempo=0.5")
        s /= 0.5
    if abs(s - 1.0) > 1e-3:
        out.append(f"atempo={s:.4f}")
    return out


def auto_grade(src: Path, start: float, dur: float) -> str:
    vals = []
    for k in range(3):
        t = start + dur * (k + 1) / 4
        res = subprocess.run(["ffmpeg", "-v", "info", "-ss", f"{t:.2f}", "-i", str(src), "-frames:v", "1",
                              "-vf", "scale=320:-2,signalstats,metadata=print:key=lavfi.signalstats.YAVG",
                              "-f", "null", "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        for line in res.stderr.decode("utf-8", "replace").splitlines():
            if "YAVG=" in line:
                try:
                    vals.append(float(line.split("YAVG=")[1]))
                except ValueError:
                    pass
    if not vals:
        return GRADES["neutral_punch"]
    y = sum(vals) / len(vals) / 255.0
    target = 0.46
    g = math.log(target) / math.log(max(0.05, min(0.95, y)))
    g = max(0.8, min(1.35, 1 / g)) if g > 0 else 1.0
    return f"eq=gamma={g:.3f}:contrast=1.04:saturation=1.05,unsharp=5:5:0.35"


def grade_filter(name: str | None, src: Path, start: float, dur: float) -> str:
    if not name:
        return ""
    if name == "auto":
        return auto_grade(src, start, dur)
    if name in GRADES:
        return GRADES[name]
    return name  # raw ffmpeg filter string


def reframe_mode(mode: str, info: dict, W: int, H: int, r: dict) -> str:
    if mode != "auto":
        return mode
    if info.get("image"):
        return "cover"
    iw, ih = info.get("width", W), info.get("height", H)
    a_in, a_out = iw / ih, W / H
    if abs(a_in - a_out) / a_out < 0.12:
        return "cover"
    if "crop_x" in r or "crop_y" in r:
        return "cover"
    return "blur"


def video_chain(info: dict, r: dict, W: int, H: int, fps: float, mode: str, grade: str,
                dur: float) -> str:
    """Returns a filter_complex string from [0:v] to [v]."""
    z = float(r.get("zoom", 1.0))
    cx, cy = float(r.get("crop_x", 0.5)), float(r.get("crop_y", 0.45 if H > W else 0.5))
    pre = []
    if info.get("hdr"):
        pre.append(TONEMAP)
    sp = float(r.get("speed", 1.0))
    pre.append(f"setpts=(PTS-STARTPTS)/{sp:.5f}" if abs(sp - 1) > 1e-3 else "setpts=PTS-STARTPTS")
    pre_s = ",".join(pre)
    zw, zh = int(W * z) // 2 * 2, int(H * z) // 2 * 2
    push = r.get("zoom_to")
    crop_xy = (f"x='min(max({cx}*iw-ow/2,0),iw-ow)':y='min(max({cy}*ih-oh/2,0),ih-oh)'")
    if push:  # animated push-in/out over the range (eval per frame)
        z2 = float(push)
        zexpr = f"({z}+({z2}-{z})*min(t/{dur:.3f},1))"
        scale_cover = (f"scale=w='ceil(max({W}/iw,{H}/ih)*iw*{zexpr}/2)*2':h='ceil(max({W}/iw,{H}/ih)*ih*{zexpr}/2)*2'"
                       f":eval=frame")
    else:
        scale_cover = f"scale={zw}:{zh}:force_original_aspect_ratio=increase"
    post = [f"fps={fps}"]
    if grade:
        post.append(grade)
    fi, fo = float(r.get("fade_in", 0)), float(r.get("fade_out", 0))
    fc = r.get("fade_color", "black")
    if fi > 0:
        post.append(f"fade=t=in:st=0:d={fi}:color={fc}")
    if fo > 0:
        post.append(f"fade=t=out:st={max(0, dur - fo):.3f}:d={fo}:color={fc}")
    post += ["setsar=1", "format=yuv420p", "tpad=stop_mode=clone:stop_duration=2"]
    post_s = ",".join(post)

    if mode == "cover":
        return (f"[0:v]{pre_s},{scale_cover},crop={W}:{H}:{crop_xy},{post_s}[v]")
    if mode == "fit":
        return (f"[0:v]{pre_s},scale={W}:{H}:force_original_aspect_ratio=decrease,"
                f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:color={r.get('pad_color', 'black')},{post_s}[v]")
    if mode == "blur":
        fg_w = int(W * float(r.get("fg_scale", 1.0)) * z) // 2 * 2
        fy = r.get("fg_y", "center")
        ypos = {"center": "(H-h)/2", "top": f"{int(H * 0.16)}", "upper": "(H-h)*0.35"}.get(fy, str(fy))
        return (f"[0:v]{pre_s},split=2[bgsrc][fgsrc];"
                f"[bgsrc]scale={W // 4}:{H // 4}:force_original_aspect_ratio=increase,crop={W // 4}:{H // 4},"
                f"boxblur=10:2,eq=brightness=-0.10:saturation=0.85,scale={W}:{H}[bg];"
                f"[fgsrc]scale={fg_w}:-2[fg];"
                f"[bg][fg]overlay=x='(W-w)/2':y='{ypos}'[comp];[comp]{post_s}[v]")
    raise EDLError(f"unknown reframe mode {mode}")


def audio_chain(has_audio: bool, r: dict, enhance: bool, dur: float) -> str:
    sp = float(r.get("speed", 1.0))
    parts = ["asetpts=PTS-STARTPTS"]
    if enhance:
        parts.append(VOICE_ENHANCE)
    parts += atempo_chain(sp)
    if r.get("mute"):
        parts.append("volume=0")
    elif r.get("volume_db"):
        parts.append(f"volume={float(r['volume_db'])}dB")
    fi = max(0.03, float(r.get("fade_in", 0)) if r.get("audio_fade", True) else 0.03)
    fo = max(0.03, float(r.get("fade_out", 0)) if r.get("audio_fade", True) else 0.03)
    parts += [f"afade=t=in:st=0:d={fi}", f"afade=t=out:st={max(0, dur - fo):.3f}:d={fo}",
              "aresample=48000", "aformat=sample_fmts=s16:channel_layouts=stereo", "apad"]
    src = "[0:a]" if has_audio else "[1:a]"
    return f"{src}{','.join(parts)}[a]"


# ------------------------------------------------------------------- segments


def seg_key(*parts) -> str:
    return hashlib.sha1(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()[:20]


def extract(src: Path, r: dict, seg: dict, spec: dict, quality: str, enhance: bool,
            grade_name: str | None, cache: Path) -> Path:
    info = pinfo(src)
    W, H, fps = spec["width"], spec["height"], float(spec["fps"])
    n_frames = max(1, int(round(seg["dur"] * fps)))
    dur = n_frames / fps
    mode = reframe_mode(r.get("reframe", spec.get("reframe", "auto")), info, W, H, r)
    st = src.stat()
    key = seg_key(str(src), st.st_size, int(st.st_mtime), {k: v for k, v in r.items()
                  if k not in ("beat", "quote", "reason", "note", "caption")},
                  W, H, fps, quality, enhance, grade_name, mode, spec.get("reframe"))
    out = cache / f"seg_{key}.mkv"
    if out.exists() and out.stat().st_size > 0:
        return out
    gfilter = grade_filter(r.get("grade", grade_name), src, seg["src_start"], seg["dur"])
    vchain = video_chain(info, r, W, H, fps, mode, gfilter, dur)
    has_a = bool(info.get("has_audio"))
    achain = audio_chain(has_a, r, enhance, dur)
    cmd = ["ffmpeg", "-y", "-v", "error"]
    if info.get("image"):
        cmd += ["-loop", "1", "-framerate", str(fps), "-t", f"{dur + 1:.3f}", "-i", str(src)]
    else:
        src_dur = seg["src_end"] - seg["src_start"]
        cmd += ["-ss", f"{seg['src_start']:.3f}", "-t", f"{src_dur + 0.5:.3f}", "-i", str(src)]
    if not has_a:
        cmd += ["-f", "lavfi", "-t", f"{dur + 1:.3f}", "-i", "anullsrc=r=48000:cl=stereo"]
    preset, crf = QUALITY[quality]
    cmd += ["-filter_complex", f"{vchain};{achain}", "-map", "[v]", "-map", "[a]",
            "-frames:v", str(n_frames), "-t", f"{dur:.6f}",
            "-c:v", "libx264", "-preset", preset, "-crf", crf, "-pix_fmt", "yuv420p",
            "-g", str(int(fps * 2)), "-r", str(fps),
            "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", str(out)]
    tmp = out.with_suffix(".part.mkv")
    cmd[-1] = str(tmp)
    run(cmd)
    tmp.rename(out)
    return out


# -------------------------------------------------------------------- assemble


def assemble(segs: list[Path], tl: list[dict], work: Path, quality: str, fps: float) -> Path:
    out = work / "base.mkv"
    if not any(s["td"] > 0 for s in tl):
        lst = work / "concat.txt"
        lst.write_text("".join(f"file '{p.as_posix()}'\n" for p in segs), encoding="utf-8")
        run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", out])
        return out
    cmd = ["ffmpeg", "-y", "-v", "error"]
    for p in segs:
        cmd += ["-i", p]
    fc, vprev, aprev = [], "[0:v]", "[0:a]"
    acc = tl[0]["dur"]
    for i in range(1, len(segs)):
        s = tl[i]
        vo, ao = f"[v{i}]", f"[a{i}]"
        if s["td"] > 0:
            ttype = (s["transition"] or {}).get("type", "fade")
            off = acc - s["td"]
            fc.append(f"{vprev}[{i}:v]xfade=transition={ttype}:duration={s['td']:.3f}:offset={off:.4f}{vo}")
            fc.append(f"{aprev}[{i}:a]acrossfade=d={s['td']:.3f}:c1=tri:c2=tri{ao}")
            acc = off + s["dur"]
        else:
            fc.append(f"{vprev}[{i}:v]concat=n=2:v=1:a=0{vo}")
            fc.append(f"{aprev}[{i}:a]concat=n=2:v=0:a=1{ao}")
            acc += s["dur"]
        vprev, aprev = vo, ao
    preset, crf = QUALITY[quality]
    cmd += ["-filter_complex", ";".join(fc), "-map", vprev, "-map", aprev, "-c:v", "libx264",
            "-preset", preset, "-crf", crf, "-pix_fmt", "yuv420p", "-r", str(fps),
            "-c:a", "pcm_s16le", out]
    run(cmd)
    return out


# --------------------------------------------------------------------- compose


def overlay_xy(ov: dict, W: int, H: int, k: float) -> tuple[str, str]:
    pos = ov.get("position")
    m = float(ov.get("margin", 0.04))
    mx, my = int(W * m), int(H * m)
    table = {
        "center": ("(W-w)/2", "(H-h)/2"), "full": ("0", "0"),
        "top": ("(W-w)/2", str(my)), "bottom": ("(W-w)/2", f"H-h-{my}"),
        "top-left": (str(mx), str(my)), "top-right": (f"W-w-{mx}", str(my)),
        "bottom-left": (str(mx), f"H-h-{my}"), "bottom-right": (f"W-w-{mx}", f"H-h-{my}"),
    }
    if pos in table:
        return table[pos]

    def conv(v, total):
        if v is None:
            return "0"
        if isinstance(v, str):
            return v
        v = float(v)
        return str(int(v * total)) if 0 < abs(v) < 1 else str(int(v * k))
    return conv(ov.get("x"), W), conv(ov.get("y"), H)


def compose(base: Path, edl: dict, edl_path: Path, edit: Path, spec: dict, ass: Path | None,
            work: Path, quality: str, k: float, D: float) -> tuple[Path, bool]:
    W, H, fps = spec["width"], spec["height"], float(spec["fps"])
    overlays = list(spec.get("_overlays", edl.get("overlays", [])))
    logo = edl.get("logo")
    if logo:
        overlays.append({"file": logo["file"], "start": 0, "duration": D, "position": logo.get("position", "top-right"),
                         "width": logo.get("width", 0.14), "opacity": logo.get("opacity", 0.9),
                         "margin": logo.get("margin", 0.035)})
    aud = edl.get("audio") or {}
    pb = edl.get("progress_bar")
    need_v = bool(overlays or ass or pb)
    need_a = bool(aud.get("bgm") or aud.get("sfx") or aud.get("voiceover") or
                  any(o.get("audio") for o in overlays))
    if not need_v and not need_a:
        return base, False

    cmd = ["ffmpeg", "-y", "-v", "error", "-i", base]
    fc: list[str] = []
    idx = 1
    vlast = "[0:v]"
    amix_inputs: list[str] = []
    if need_v:
        for j, ov in enumerate(overlays):
            f = resolve(ov["file"], edl_path, edit)
            st = float(parse_t(ov.get("start", 0)))
            is_img = f.suffix.lower() in IMAGE_EXT
            od = float(ov.get("duration", (pinfo(f).get("duration") if not is_img else D - st) or (D - st)))
            if is_img:
                cmd += ["-loop", "1", "-framerate", str(fps), "-t", f"{od:.3f}", "-i", f]
            else:
                if f.suffix.lower() == ".webm":
                    cmd += ["-c:v", "libvpx-vp9"]  # keep alpha
                if ov.get("loop"):
                    cmd += ["-stream_loop", "-1"]
                cmd += ["-i", f]
            chain = [f"trim=duration={od:.3f}", "setpts=PTS-STARTPTS", f"fps={fps}", "format=rgba"]
            wv = ov.get("width")
            if ov.get("position") == "full":
                chain.append(f"scale={W}:{H}")
            elif wv:
                wpx = int(float(wv) * W) if float(wv) <= 1 else int(float(wv) * k)
                chain.append(f"scale={wpx // 2 * 2}:-2")
            elif k != 1.0:
                chain.append(f"scale=iw*{k}:-2")
            op = float(ov.get("opacity", 1.0))
            if op < 1:
                chain.append(f"colorchannelmixer=aa={op}")
            fi, fo = float(ov.get("fade_in", 0)), float(ov.get("fade_out", 0))
            if fi:
                chain.append(f"fade=t=in:st=0:d={fi}:alpha=1")
            if fo:
                chain.append(f"fade=t=out:st={max(0, od - fo):.3f}:d={fo}:alpha=1")
            chain.append(f"setpts=PTS-STARTPTS+{st:.4f}/TB")
            fc.append(f"[{idx}:v]{','.join(chain)}[ov{j}]")
            x, y = overlay_xy(ov, W, H, k)
            fc.append(f"{vlast}[ov{j}]overlay=x={x}:y={y}:eof_action=pass:"
                      f"enable='between(t,{st:.3f},{st + od:.3f})'[vo{j}]")
            vlast = f"[vo{j}]"
            if ov.get("audio") and not is_img and pinfo(f).get("has_audio"):
                amix_inputs.append(f"[{idx}:a]atrim=duration={od:.3f},asetpts=PTS-STARTPTS,"
                                   f"volume={float(ov.get('volume_db', 0))}dB,"
                                   f"adelay={int(st * 1000)}|{int(st * 1000)},aresample=48000[oa{j}]")
            idx += 1
        if pb:
            color = pb.get("color", "#FFD400").replace("#", "0x")
            ph = max(4, int(pb.get("height", 0.006) * H if pb.get("height", 0.006) < 1 else pb["height"] * k))
            yb = 0 if pb.get("position", "top") == "top" else H - ph
            cmd += ["-f", "lavfi", "-i", f"color=c={color}:s={W}x{ph}:r={fps}:d={D:.3f}"]
            fc.append(f"{vlast}[{idx}:v]overlay=x='-W+W*t/{D:.3f}':y={yb}:shortest=1[vpb]")
            vlast = "[vpb]"
            idx += 1
        if ass:
            shutil.copy(ass, work / "captions.ass")
            ffile, _fam = find_cjk_font((edl.get("captions") or {}).get("font"))
            fdir = Path(ffile).parent.as_posix() if ffile else None
            fd_esc = fdir.replace("\\", "/").replace(":", "\\:") if fdir else None  # C:/ → C\:/ (Windows)
            opt = "ass=captions.ass" + (f":fontsdir='{fd_esc}'" if fd_esc else "")
            fc.append(f"{vlast}{opt}[vcap]")  # captions LAST
            vlast = "[vcap]"

    # ---- audio bus
    alast = "[0:a]"
    if need_a:
        dlg = ["[0:a]"]
        vo = aud.get("voiceover")
        if vo:
            f = resolve(vo["file"], edl_path, edit)
            cmd += ["-i", f]
            st = float(vo.get("start", 0))
            fc.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,"
                      f"volume={float(vo.get('volume_db', 0))}dB,adelay={int(st * 1000)}|{int(st * 1000)}[vo]")
            dlg.append("[vo]")
            idx += 1
        if len(dlg) > 1:
            fc.append(f"{''.join(dlg)}amix=inputs={len(dlg)}:normalize=0:duration=first[dlg]")
            dl = "[dlg]"
        else:
            dl = "[0:a]"
        bus = []
        bgm = aud.get("bgm")
        if bgm:
            f = resolve(bgm["file"], edl_path, edit)
            cmd += ["-stream_loop", "-1", "-i", f]
            vol = float(bgm.get("volume_db", -16))
            off = float(bgm.get("offset", 0))
            fin, fout = float(bgm.get("fade_in", 1.0)), float(bgm.get("fade_out", 2.5))
            fc.append(f"{dl}asplit=2[dlgmain][dlgkey]")
            fc.append(f"[{idx}:a]atrim=start={off}:duration={D:.3f},asetpts=PTS-STARTPTS,aresample=48000,"
                      f"aformat=channel_layouts=stereo,volume={vol}dB,afade=t=in:st=0:d={fin},"
                      f"afade=t=out:st={max(0, D - fout):.3f}:d={fout}[bgmraw]")
            if bgm.get("duck", True):
                ratio = float(bgm.get("duck_ratio", 8))
                fc.append(f"[bgmraw][dlgkey]sidechaincompress=threshold=0.025:ratio={ratio}:attack=20:"
                          f"release=350:makeup=1[bgm]")
            else:
                fc.append("[dlgkey]anullsink")
                fc.append("[bgmraw]anull[bgm]")
            bus += ["[dlgmain]", "[bgm]"]
            idx += 1
        else:
            bus.append(dl)
        for j, s in enumerate(aud.get("sfx", [])):
            f = resolve(s["file"], edl_path, edit)
            cmd += ["-i", f]
            at = int(float(parse_t(s["at"])) * 1000)
            fc.append(f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,"
                      f"volume={float(s.get('volume_db', -6))}dB,adelay={at}|{at}[sfx{j}]")
            bus.append(f"[sfx{j}]")
            idx += 1
        bus += [f"[oa{j}]" for j in range(len(overlays)) if f"[oa{j}]" in ";".join(amix_inputs)]
        fc += amix_inputs
        if len(bus) > 1:
            fc.append(f"{''.join(bus)}amix=inputs={len(bus)}:normalize=0:duration=first,"
                      f"alimiter=limit=0.95[mix]")
            alast = "[mix]"
        else:
            alast = bus[0]

    out = work / "comp.mkv"
    preset, crf = QUALITY[quality]
    cmd += ["-filter_complex", ";".join(fc) if fc else "anull", "-map", vlast if need_v else "0:v",
            "-map", alast if alast != "[0:a]" else "0:a"]
    cmd += (["-c:v", "libx264", "-preset", preset, "-crf", crf, "-pix_fmt", "yuv420p", "-r", str(fps)]
            if need_v else ["-c:v", "copy"])
    cmd += ["-c:a", "pcm_s16le", "-t", f"{D:.4f}", "comp.mkv"]
    if not fc:
        cmd = [c for c in cmd if c not in ("-filter_complex", "anull")]
    cmd = [str(c) for c in cmd]
    res = subprocess.run(cmd, cwd=work, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode != 0:
        (work / "compose_cmd.txt").write_text(" ".join(cmd), encoding="utf-8")
        raise RuntimeError("compose failed:\n" + res.stderr.decode("utf-8", "replace")[-3000:])
    return out, True


# ---------------------------------------------------------------------- master


def master(src: Path, out: Path, lufs: float, tp: float, quick: bool, dur: float | None = None) -> dict:
    meas = {}
    if not quick:
        res = subprocess.run(["ffmpeg", "-v", "info", "-i", str(src), "-vn", "-af",
                              f"loudnorm=I={lufs}:TP={tp}:LRA=11:print_format=json", "-f", "null", "-"],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        txt = res.stderr.decode("utf-8", "replace")
        try:
            meas = json.loads(txt[txt.rindex("{"): txt.rindex("}") + 1])
        except ValueError:
            meas = {}
    if meas and meas.get("input_i") not in (None, "-inf"):
        af = (f"loudnorm=I={lufs}:TP={tp}:LRA=11:measured_I={meas['input_i']}:measured_TP={meas['input_tp']}:"
              f"measured_LRA={meas['input_lra']}:measured_thresh={meas['input_thresh']}:"
              f"offset={meas['target_offset']}:linear=true")
    else:
        af = f"loudnorm=I={lufs}:TP={tp}:LRA=11"
    tcap = ["-t", f"{dur:.4f}"] if dur else []
    run(["ffmpeg", "-y", "-v", "error", "-i", src, "-map", "0:v", "-map", "0:a", "-c:v", "copy",
         "-af", af + ",aresample=48000", "-c:a", "aac", "-b:a", "192k", *tcap, "-movflags", "+faststart", out])
    return meas


# ------------------------------------------------------------------------ main


def render_variant(edl: dict, edl_path: Path, edit: Path, variant: dict | None, args) -> Path:
    t0 = time.time()
    srcmap = source_map(edl, edl_path, edit)
    first = srcmap[edl["ranges"][0]["source"]]
    spec = output_spec(edl, variant, pinfo(first) if first.suffix.lower() not in IMAGE_EXT else None)
    quality = "draft" if args.draft else ("preview" if args.preview else "final")
    k = 0.5 if args.draft else 1.0
    if k != 1.0:
        spec["width"], spec["height"] = int(spec["width"] * k) // 2 * 2, int(spec["height"] * k) // 2 * 2
    if variant and "overlays" in variant:
        spec["_overlays"] = variant["overlays"]
    cap_cfg = dict(edl.get("captions") or {})
    if variant and "captions" in variant:
        cap_cfg = {**cap_cfg, **(variant["captions"] or {})} if variant["captions"] else {}
    if args.no_captions:
        cap_cfg = {}

    tl = build_timeline(edl, float(spec["fps"]))
    D = tl[-1]["out_end"]
    name = spec["name"] + ("_draft" if args.draft else ("_preview" if args.preview else ""))
    outdir = edit / "out"
    outdir.mkdir(parents=True, exist_ok=True)
    final = Path(args.out) if (args.out and not args._multi) else outdir / f"{name}.mp4"
    cache = edit / "cache" / "segments"
    cache.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="vs_", dir=str(edit / "cache")))
    log(f"▶ {name}: {spec['width']}x{spec['height']}@{spec['fps']}  {len(tl)} ranges  → {fmt_t(D)}  [{quality}]")

    enhance = bool((edl.get("audio") or {}).get("voice_enhance"))
    segs = []
    for r, seg in zip(edl["ranges"], tl):
        src = srcmap[r["source"]]
        seg["silent"] = bool(r.get("mute") or not pinfo(src).get("has_audio"))
        p = extract(src, r, seg, spec, quality, enhance, edl.get("grade"), cache)
        segs.append(p)
        log(f"   [{seg['i']:02d}] {r['source']:<14} {seg['src_start']:8.2f}-{seg['src_end']:8.2f} → "
            f"{fmt_t(seg['out_start'])}  {r.get('beat', '')}")
    base = assemble(segs, tl, work, quality, float(spec["fps"]))
    ass = capmod.make_captions(edl, edl_path, edit, spec["width"], spec["height"], outdir / f"{name}.ass",
                               cap_cfg, float(spec["fps"])) if (cap_cfg or edl.get("titles")) else None
    if edl.get("titles"):
        ass = capmod.add_titles(ass, edl["titles"], spec["width"], spec["height"], outdir / f"{name}.ass",
                                cap_cfg)
    comp, _ = compose(base, edl, edl_path, edit, spec, ass, work, quality, k, D)
    aud = edl.get("audio") or {}
    meas = master(comp, final, float(aud.get("loudness", -14)), float(aud.get("true_peak", -1.0)),
                  quick=args.draft, dur=D)
    words = outdir / f"{name}.words.json"
    if ass and ass.with_suffix(".words.json").exists() and ass.with_suffix(".words.json") != words:
        shutil.copy(ass.with_suffix(".words.json"), words)
    if final.parent != outdir:
        for ext in (".words.json", ".srt"):
            sidecar = outdir / f"{name}{ext}"
            if sidecar.exists():
                shutil.copy(sidecar, final.with_suffix(ext))
    write_json(final.with_suffix(".render.json"), {
        "edl": str(edl_path), "variant": (variant or {}).get("name"), "spec": {k_: v for k_, v in spec.items()
                                                                              if not k_.startswith("_")},
        "quality": quality, "duration": round(D, 3),
        "cuts": [round(s["out_start"], 3) for s in tl[1:]],
        "timeline": tl, "loudnorm_input": meas, "captions": str(ass) if ass else None,
    })
    if not args.keep_temp:
        shutil.rmtree(work, ignore_errors=True)
    got = probe(final)["duration"]
    log(f"✓ {final}  ({fmt_t(got)}, expected {fmt_t(D)}, {time.time() - t0:.0f}s)")
    if abs(got - D) > 0.1:
        log(f"  ⚠ duration differs from timeline by {got - D:+.2f}s")
    return final


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("edl", nargs="+")
    ap.add_argument("-o", "--out")
    ap.add_argument("--variant", help="render only this variant name")
    ap.add_argument("--draft", action="store_true")
    ap.add_argument("--preview", action="store_true")
    ap.add_argument("--no-captions", action="store_true")
    ap.add_argument("--validate", action="store_true")
    ap.add_argument("--keep-temp", action="store_true")
    args = ap.parse_args()
    files = []
    for e in args.edl:
        files += sorted(glob.glob(e)) or [e]
    args._multi = len(files) > 1
    rc = 0
    for f in files:
        try:
            edl, edl_path, edit = load_edl(f)
            errs = validate(edl, edl_path, edit)
            if errs:
                log(f"✗ {f}:\n  - " + "\n  - ".join(errs))
                rc = 1
                continue
            if args.validate:
                log(f"✓ {f} valid · {len(edl['ranges'])} ranges · {fmt_t(build_timeline(edl)[-1]['out_end'])}")
                continue
            variants = edl.get("variants") or [None]
            if args.variant:
                variants = [v for v in variants if v and v.get("name") == args.variant]
                if not variants:
                    log(f"✗ variant {args.variant} not in EDL")
                    rc = 1
                    continue
            if len(variants) > 1:
                args._multi = True
            for v in variants:
                render_variant(edl, edl_path, edit, v, args)
        except (EDLError, RuntimeError, KeyError) as e:
            log(f"✗ {f}: {e}")
            rc = 1
    sys.exit(rc)


if __name__ == "__main__":
    main()
