#!/usr/bin/env python3
"""Acoustic + visual analysis per source (no ASR needed, works on 5h streams).

Writes edit/analysis/<ID>.json and <ID>.env.npy:
  - RMS loudness envelope (50 ms hops, dBFS), streamed so memory stays flat
  - silences (adaptive threshold), speech ratio, loudness percentiles
  - optional scene cuts (--scenes), sampled at low res so it's cheap

Usage:
  python analyze.py <edit_dir|videos_dir> [--ids A B] [--scenes] [--force]
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import find_edit_dir, fmt_t, load_sources, log, read_json, write_json  # noqa: E402

HOP = 0.05
SR = 8000


def stream_envelope(path: str) -> np.ndarray:
    hop = int(SR * HOP)
    proc = subprocess.Popen(["ffmpeg", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(SR),
                             "-f", "f32le", "-"], stdout=subprocess.PIPE)
    out: list[np.ndarray] = []
    rest = np.zeros(0, dtype=np.float32)
    chunk_bytes = hop * 4 * 2000
    while True:
        b = proc.stdout.read(chunk_bytes)
        if not b:
            break
        x = np.concatenate([rest, np.frombuffer(b, dtype=np.float32)])
        n = len(x) // hop
        if n:
            blk = x[: n * hop].reshape(n, hop)
            out.append((20 * np.log10(np.sqrt(np.mean(blk * blk, axis=1) + 1e-12) + 1e-9)).astype(np.float32))
        rest = x[n * hop:]
    proc.wait()
    return np.concatenate(out) if out else np.zeros(0, dtype=np.float32)


def find_silences(env: np.ndarray, min_dur: float = 0.25) -> tuple[list[list[float]], float]:
    if len(env) == 0:
        return [], -40.0
    floor = float(np.percentile(env, 10))
    speech = float(np.percentile(env, 90))
    thr = floor + 0.35 * (speech - floor)
    thr = float(min(max(thr, -55.0), -22.0))
    quiet = env < thr
    sil, i, n = [], 0, len(env)
    while i < n:
        if quiet[i]:
            j = i
            while j < n and quiet[j]:
                j += 1
            if (j - i) * HOP >= min_dur:
                sil.append([round(i * HOP, 3), round(j * HOP, 3)])
            i = j
        else:
            i += 1
    return sil, thr


def scene_cuts(path: str, thresh: float = 0.32) -> list[float]:
    cmd = ["ffmpeg", "-v", "info", "-i", path, "-an", "-vf",
           f"fps=4,scale=256:-2,select='gt(scene,{thresh})',showinfo", "-f", "null", "-"]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    cuts = []
    for line in res.stderr.decode("utf-8", "replace").splitlines():
        if "pts_time:" in line and "showinfo" in line:
            try:
                cuts.append(round(float(line.split("pts_time:")[1].split()[0]), 2))
            except ValueError:
                pass
    return cuts


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=".")
    ap.add_argument("--ids", nargs="*")
    ap.add_argument("--scenes", action="store_true", help="detect visual scene cuts (multi-cam / screen switches)")
    ap.add_argument("--min-silence", type=float, default=0.25)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    edit = find_edit_dir(args.path)
    srcs = load_sources(edit)
    if not srcs:
        log("no sources.json — run ingest.py first")
        sys.exit(1)
    adir = edit / "analysis"
    adir.mkdir(parents=True, exist_ok=True)
    for sid, info in srcs.items():
        if args.ids and sid not in args.ids:
            continue
        out = adir / f"{sid}.json"
        prev = read_json(out)
        if prev and not args.force and (not args.scenes or prev.get("scenes") is not None):
            log(f"  {sid}: cached")
            continue
        if not info.get("has_audio"):
            log(f"  {sid}: no audio track, skipping envelope")
            env = np.zeros(0, dtype=np.float32)
        else:
            log(f"  {sid}: envelope ({fmt_t(info.get('duration', 0))}) …")
            env = stream_envelope(info["path"])
        np.save(adir / f"{sid}.env.npy", env)
        sil, thr = find_silences(env, args.min_silence)
        sil_total = sum(e - s for s, e in sil)
        dur = len(env) * HOP or info.get("duration", 0)
        data = {
            "source": sid, "hop": HOP, "threshold_db": round(thr, 1),
            "duration": round(dur, 3),
            "speech_ratio": round(1 - sil_total / dur, 3) if dur else 0,
            "loudness_db": {k: round(float(np.percentile(env, p)), 1) for k, p in
                            (("p10", 10), ("p50", 50), ("p90", 90), ("max", 100))} if len(env) else {},
            "silences": sil,
            "scenes": scene_cuts(info["path"]) if (args.scenes and info.get("has_video")) else
            (prev or {}).get("scenes"),
        }
        write_json(out, data)
        log(f"  {sid}: {len(sil)} silences ≥{args.min_silence}s, speech {data['speech_ratio']:.0%}, "
            f"thr {thr:.1f} dB" + (f", {len(data['scenes'])} scene cuts" if data["scenes"] else ""))


if __name__ == "__main__":
    main()
