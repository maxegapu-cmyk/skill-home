#!/usr/bin/env python3
"""Voiceover with word timings → audio + <name>.words.json (drives captions & scene timing).

Backends:
  edge      Microsoft Edge neural voices via `pip install edge-tts`. Free, excellent Mandarin.
            zh-CN-YunxiNeural (男·活泼) · zh-CN-XiaoxiaoNeural (女·温暖) · zh-CN-YunjianNeural (男·激昂)
            zh-CN-XiaoyiNeural (女·活泼) · zh-CN-YunyangNeural (男·新闻) · en-US-AndrewNeural …
  eleven    ElevenLabs (ELEVENLABS_API_KEY, optional VS_ELEVEN_VOICE). Character-level timestamps.
  say       macOS `say` offline fallback (timings interpolated).

  python tts.py text "首付只要一万九" -o edit/audio/hook.mp3 [--voice zh-CN-YunxiNeural --rate +8%]
  python tts.py scenes motion_spec.json --out edit/audio/vo [--lead 0.25 --tail 0.45]
      → per-scene narration (scene["narration"]), scene durations written back into the spec,
        vo.mp3 + vo.words.json aligned to scene starts, timing.json
  python tts.py voices [zh]
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import PUNCT, is_cjk, log, probe, read_json, write_json  # noqa: E402

DEFAULT_VOICE = os.environ.get("VS_VOICE", "zh-CN-YunxiNeural")


def _words_from_text_span(text: str, a: float, b: float) -> list[dict]:
    toks = re.findall(r"[㐀-鿿]|[A-Za-z0-9][A-Za-z0-9'.%-]*|[^\s]", text)
    out: list[dict] = []
    for t in toks:
        if t in PUNCT and out:
            out[-1]["text"] += t
        elif t not in PUNCT:
            out.append({"text": t})
    n = max(1, len(out))
    weights = [max(1, len(w["text"].strip("".join(PUNCT)))) if not is_cjk(w["text"]) else 1 for w in out]
    tot = sum(weights) or 1
    cur = a
    for w, wt in zip(out, weights):
        d = (b - a) * wt / tot
        w.update(start=round(cur, 3), end=round(cur + d, 3), type="word", speaker="VO")
        cur += d
    return out[:n]


# ------------------------------------------------------------------ backends


async def _edge(text: str, voice: str, rate: str, pitch: str, out: Path) -> list[dict]:
    import edge_tts
    try:
        comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch, boundary="WordBoundary")
    except TypeError:
        comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    bounds = []
    with open(out, "wb") as f:
        async for ch in comm.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] in ("WordBoundary", "SentenceBoundary"):
                bounds.append((ch["type"], ch["offset"] / 1e7, ch["duration"] / 1e7, ch.get("text", "")))
    words: list[dict] = []
    wb = [b for b in bounds if b[0] == "WordBoundary"]
    if wb:
        for _t, off, dur, txt in wb:
            words += _words_from_text_span(txt, off, off + dur)
    else:
        for _t, off, dur, txt in bounds:
            words += _words_from_text_span(txt, off, off + dur)
    _attach_punct(words, text)
    return words


def _attach_punct(words: list[dict], text: str) -> None:
    """Edge boundaries drop punctuation; re-attach it so captions can break on it."""
    i = 0
    flat = text
    for w in words:
        core = w["text"]
        j = flat.find(core, i)
        if j < 0:
            continue
        k = j + len(core)
        while k < len(flat) and flat[k] in PUNCT:
            k += 1
        w["text"] = flat[j:k]
        i = k


def _eleven(text: str, voice: str | None, out: Path) -> list[dict]:
    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        raise SystemExit("ELEVENLABS_API_KEY not set")
    vid = voice or os.environ.get("VS_ELEVEN_VOICE") or "JBFqnCBsd6RMkjVDRZzb"
    body = json.dumps({"text": text, "model_id": os.environ.get("VS_ELEVEN_MODEL", "eleven_multilingual_v2")}).encode()
    req = urllib.request.Request(f"https://api.elevenlabs.io/v1/text-to-speech/{vid}/with-timestamps", data=body,
                                 headers={"xi-api-key": key, "Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=600) as r:
        data = json.loads(r.read())
    out.write_bytes(base64.b64decode(data["audio_base64"]))
    al = data.get("alignment") or {}
    chars, st, en = al.get("characters", []), al.get("character_start_times_seconds", []), \
        al.get("character_end_times_seconds", [])
    words: list[dict] = []
    buf, bs, be = "", None, None
    for c, a, b in zip(chars, st, en):
        if is_cjk(c):
            if buf:
                words.append({"text": buf, "start": bs, "end": be, "type": "word", "speaker": "VO"})
                buf = ""
            words.append({"text": c, "start": a, "end": b, "type": "word", "speaker": "VO"})
        elif c.isspace():
            if buf:
                words.append({"text": buf, "start": bs, "end": be, "type": "word", "speaker": "VO"})
                buf = ""
        elif c in PUNCT:
            if buf:
                buf += c
            elif words:
                words[-1]["text"] += c
        else:
            if not buf:
                bs = a
            buf += c
            be = b
    if buf:
        words.append({"text": buf, "start": bs, "end": be, "type": "word", "speaker": "VO"})
    return words


def _say(text: str, voice: str | None, out: Path) -> list[dict]:
    if not shutil.which("say"):
        raise SystemExit("`say` not available (macOS only)")
    aiff = out.with_suffix(".aiff")
    subprocess.run(["say", "-v", voice or "Tingting", "-o", str(aiff), text], check=True)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(aiff), str(out)], check=True)
    aiff.unlink(missing_ok=True)
    return _words_from_text_span(text, 0.05, probe(out)["duration"] - 0.05)


def synth(text: str, out: Path, backend: str, voice: str | None, rate: str, pitch: str) -> list[dict]:
    out.parent.mkdir(parents=True, exist_ok=True)
    if backend == "auto":
        import importlib.util
        if importlib.util.find_spec("edge_tts"):
            backend = "edge"
        else:
            backend = "eleven" if os.environ.get("ELEVENLABS_API_KEY") else "say"
    if backend == "edge":
        words = asyncio.run(_edge(text, voice or DEFAULT_VOICE, rate, pitch, out))
    elif backend == "eleven":
        words = _eleven(text, voice, out)
    elif backend == "say":
        words = _say(text, voice, out)
    else:
        raise SystemExit(f"unknown backend {backend}")
    write_json(out.with_suffix(".words.json"), {"text": text, "backend": backend, "voice": voice, "words": words})
    return words


# ---------------------------------------------------------------------- modes


def scenes_mode(spec_path: Path, out_dir: Path, args) -> None:
    spec = read_json(spec_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    timing, t0, all_words, parts = [], 0.0, [], []
    for i, sc in enumerate(spec["scenes"]):
        narr = (sc.get("narration") or "").strip()
        if not narr:
            d = float(sc.get("duration", 3))
            timing.append({"scene": i, "start": t0, "duration": d, "audio": None})
            t0 += d
            continue
        f = out_dir / f"scene_{i:02d}.mp3"
        words = synth(narr, f, args.backend, args.voice, args.rate, args.pitch)
        ad = probe(f)["duration"]
        d = round(max(float(sc.get("min_duration", 2.0)), args.lead + ad + args.tail), 2)
        sc["duration"] = d
        for w in words:
            all_words.append({**w, "start": round(w["start"] + t0 + args.lead, 3),
                              "end": round(w["end"] + t0 + args.lead, 3)})
        parts.append((f, t0 + args.lead))
        timing.append({"scene": i, "start": round(t0, 3), "duration": d, "audio": str(f), "speech": round(ad, 3)})
        t0 += d
    write_json(spec_path, spec)
    write_json(out_dir / "timing.json", {"total": round(t0, 3), "scenes": timing})
    vo = out_dir / "vo.mp3"
    if parts:
        cmd = ["ffmpeg", "-y", "-v", "error"]
        for f, _ in parts:
            cmd += ["-i", str(f)]
        fc = ";".join(f"[{k}:a]aresample=48000,adelay={int(st * 1000)}|{int(st * 1000)}[a{k}]"
                      for k, (_f, st) in enumerate(parts))
        fc += ";" + "".join(f"[a{k}]" for k in range(len(parts))) + \
            f"amix=inputs={len(parts)}:normalize=0,apad=whole_dur={t0:.3f}[out]"
        cmd += ["-filter_complex", fc, "-map", "[out]", "-t", f"{t0:.3f}", "-c:a", "libmp3lame", "-q:a", "2", str(vo)]
        subprocess.run(cmd, check=True)
        write_json(vo.with_suffix(".words.json"), {"words": all_words})
    log(f"✓ narration for {len(parts)} scene(s), total {t0:.1f}s → {vo}")
    log(f"  scene durations written back into {spec_path.name}; rebuild with motion.py build")


EDGE_ZH = ["zh-CN-YunxiNeural", "zh-CN-XiaoxiaoNeural", "zh-CN-YunjianNeural", "zh-CN-XiaoyiNeural",
           "zh-CN-YunyangNeural", "zh-CN-YunxiaNeural", "zh-CN-liaoning-XiaobeiNeural", "zh-CN-shaanxi-XiaoniNeural",
           "zh-TW-HsiaoChenNeural", "zh-HK-HiuMaanNeural"]


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("text", "scenes"):
        p = sub.add_parser(name)
        p.add_argument("input")
        p.add_argument("--backend", default=os.environ.get("VS_TTS", "auto"), choices=["auto", "edge", "eleven", "say"])
        p.add_argument("--voice")
        p.add_argument("--rate", default="+0%")
        p.add_argument("--pitch", default="+0Hz")
        if name == "text":
            p.add_argument("-o", "--out", required=True)
        else:
            p.add_argument("--out", required=True)
            p.add_argument("--lead", type=float, default=0.25)
            p.add_argument("--tail", type=float, default=0.45)
    v = sub.add_parser("voices")
    v.add_argument("lang", nargs="?", default="zh")
    args = ap.parse_args()
    if args.cmd == "text":
        words = synth(args.input, Path(args.out), args.backend, args.voice, args.rate, args.pitch)
        log(f"✓ {args.out} ({len(words)} words, {probe(args.out)['duration']:.2f}s)")
    elif args.cmd == "scenes":
        scenes_mode(Path(args.input), Path(args.out), args)
    else:
        try:
            import edge_tts
            vs = asyncio.run(edge_tts.list_voices())
            for x in vs:
                if x["Locale"].lower().startswith(args.lang.lower()):
                    print(f"{x['ShortName']:<36} {x['Gender']:<7} {', '.join(x.get('VoiceTag', {}).get('VoicePersonalities', []))}")
        except Exception:
            print("\n".join(EDGE_ZH))


if __name__ == "__main__":
    main()
