#!/usr/bin/env python3
"""Built-in motion cards (no browser, no Node) → transparent .mov overlays or opaque .mp4 inserts.

Fast path for the graphics every 口播 / 直播切片 / 数据讲解 needs. For anything more
designed (kinetic typography, charts with real layout, product UI motion) use
HyperFrames (references/motion.md) — these cards are the 80% case, rendered in seconds.

Types: title · lower_third · counter · stat_cards · bullets · bar_chart · price_tag ·
       end_card · callout · quote

  python cards.py spec.json                     # one spec or a list of specs
  python cards.py --type counter --value 2099 --prefix ¥ --label 月供 --size 9:16 -o c.mov
  python cards.py --demo outdir                 # render one of each (to preview the look)

Spec (JSON):
  {"type": "counter", "size": "9:16" | "1080x1920", "duration": 4, "fps": 30,
   "region": "center|upper|lower|top|bottom",   # where on the frame
   "background": null | "#0B0F14",               # null → transparent .mov (overlay "position":"full")
   "theme": {"fg": "#FFFFFF", "accent": "#FFD400", "accent2": "#E8322E", "panel": "#000000B0",
             "font": "/path/font.ttc", "muted": "#C8C8C8"},
   ...type fields (see TYPE_FIELDS below), "out": "edit/animations/price.mov"}
Theme defaults come from edit/brand.json → "theme" when present.
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import find_edit_dir, log, pil_font, read_json  # noqa: E402

SIZES = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "3:4": (1080, 1440),
         "4:5": (1080, 1350)}
TYPE_FIELDS = {
    "title": "text (\\n for lines), sub, band(bool)",
    "lower_third": "name, role",
    "counter": "value, start_value, prefix, suffix, label, decimals",
    "stat_cards": "items:[{label,value,prefix,suffix}] (≤4), title",
    "bullets": "title, items:[str]",
    "bar_chart": "title, items:[{label,value}], unit, highlight(index)",
    "price_tag": "old, new, label, note",
    "end_card": "text, button, sub",
    "callout": "x, y (0-1 of frame), text",
    "quote": "text, author",
}
DEFAULT_THEME = {"fg": "#FFFFFF", "accent": "#FFD400", "accent2": "#E8322E", "panel": "#0B0F14C8",
                 "muted": "#D0D0D0", "font": None}


# ---------------------------------------------------------------- easing/util


def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def ease_out(t):
    t = clamp(t)
    return 1 - (1 - t) ** 3


def ease_in_out(t):
    t = clamp(t)
    return 4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


def ease_back(t, s=1.70158):
    t = clamp(t) - 1
    return t * t * ((s + 1) * t + s) + 1


def prog(t, start, dur):
    return clamp((t - start) / dur) if dur > 0 else float(t >= start)


def rgba(hexs: str, alpha: float = 1.0) -> tuple:
    h = hexs.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    a = int(h[6:8], 16) if len(h) == 8 else 255
    return (r, g, b, int(a * clamp(alpha)))


def fmt_num(v: float, decimals: int = 0) -> str:
    return f"{v:,.{decimals}f}"


class Canvas:
    def __init__(self, W, H, theme, bg):
        self.W, self.H, self.th = W, H, theme
        self.s = min(W, H) / 1080
        self.vertical = H > W
        self.bg = bg

    def new(self):
        if self.bg:
            return Image.new("RGBA", (self.W, self.H), rgba(self.bg))
        return Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))

    def font(self, px, bold=True):
        return pil_font(int(px * self.s), self.th.get("font"), weight="bold" if bold else "regular")

    def text(self, img, xy, txt, px, color, alpha=1.0, anchor="mm", bold=True, stroke=0, shadow=True,
             scale=1.0):
        """Draw text into a bbox-sized layer (fast), with optional soft drop shadow."""
        if alpha <= 0.01 or not txt:
            return
        f = self.font(px * scale, bold)
        sw = int(stroke * self.s)
        probe_d = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
        x0, y0, x1, y1 = probe_d.textbbox(xy, txt, font=f, anchor=anchor, stroke_width=sw)
        pad = int(24 * self.s) + sw
        bx, by = int(x0) - pad, int(y0) - pad
        bw, bh = int(x1 - x0) + 2 * pad, int(y1 - y0) + 2 * pad
        if bw <= 0 or bh <= 0:
            return
        local = (xy[0] - bx, xy[1] - by)
        layer = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
        if shadow and not self.bg:
            sh = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
            ImageDraw.Draw(sh).text((local[0] + 3 * self.s, local[1] + 4 * self.s), txt, font=f, anchor=anchor,
                                    fill=(0, 0, 0, int(150 * alpha)), stroke_width=sw,
                                    stroke_fill=(0, 0, 0, int(150 * alpha)))
            layer.alpha_composite(sh.filter(ImageFilter.GaussianBlur(6 * self.s)))
        ImageDraw.Draw(layer).text(local, txt, font=f, anchor=anchor, fill=rgba(color, alpha), stroke_width=sw,
                                   stroke_fill=(0, 0, 0, int(255 * alpha)))
        self._paste(img, layer, bx, by)

    @staticmethod
    def _paste(img, layer, bx, by):
        W, H = img.size
        sx0, sy0 = max(0, -bx), max(0, -by)
        dx0, dy0 = max(0, bx), max(0, by)
        w = min(layer.width - sx0, W - dx0)
        h = min(layer.height - sy0, H - dy0)
        if w > 0 and h > 0:
            img.alpha_composite(layer.crop((sx0, sy0, sx0 + w, sy0 + h)), (dx0, dy0))

    def tlen(self, txt, px, bold=True):
        return ImageDraw.Draw(Image.new("RGBA", (4, 4))).textlength(txt, font=self.font(px, bold))

    def rrect(self, img, box, radius, color, alpha=1.0):
        if alpha <= 0.01:
            return
        x0, y0, x1, y1 = [int(round(v)) for v in box]
        if x1 <= x0 or y1 <= y0:
            return
        layer = Image.new("RGBA", (x1 - x0 + 1, y1 - y0 + 1), (0, 0, 0, 0))
        r = int(min(radius * self.s, (x1 - x0) / 2, (y1 - y0) / 2))
        ImageDraw.Draw(layer).rounded_rectangle([0, 0, x1 - x0, y1 - y0], radius=max(0, r), fill=rgba(color, alpha))
        self._paste(img, layer, x0, y0)

    def region_y(self, region):
        H = self.H
        return {"center": H * 0.5, "upper": H * (0.3 if self.vertical else 0.32), "top": H * 0.16,
                "lower": H * (0.64 if self.vertical else 0.7), "bottom": H * 0.82}.get(region, H * 0.5)


def out_alpha(t, D, fade=0.35):
    return 1.0 - prog(t, D - fade, fade)


# ------------------------------------------------------------------ card types


def card_title(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    lines = str(sp.get("text", "标题")).split("\n")
    cy = c.region_y(sp.get("region", "center"))
    px = sp.get("font_size", 96 if c.vertical else 110)
    lh = px * 1.28 * c.s
    total = lh * len(lines)
    a_out = out_alpha(t, D)
    if sp.get("band"):
        w = max(c.tlen(l, px) for l in lines) + 120 * c.s
        k = ease_out(prog(t, 0, 0.35))
        c.rrect(img, [c.W / 2 - w / 2 * k, cy - total / 2 - 30 * c.s, c.W / 2 + w / 2 * k,
                      cy + total / 2 + 30 * c.s], 18, th["accent2"], a_out)
    for i, line in enumerate(lines):
        p = ease_out(prog(t, 0.08 + i * 0.12, 0.5))
        y = cy - total / 2 + lh * (i + 0.5) + (1 - p) * 60 * c.s
        c.text(img, (c.W / 2, y), line, px, th["fg"], p * a_out, stroke=0 if sp.get("band") else 4)
    bar_p = ease_in_out(prog(t, 0.35, 0.55))
    if not sp.get("band") and bar_p > 0:
        bw = 180 * c.s * bar_p
        yb = cy + total / 2 + 22 * c.s
        c.rrect(img, [c.W / 2 - bw / 2, yb, c.W / 2 + bw / 2, yb + 10 * c.s], 5, th["accent"], a_out)
    if sp.get("sub"):
        p = ease_out(prog(t, 0.5, 0.5))
        c.text(img, (c.W / 2, cy + total / 2 + 80 * c.s), sp["sub"], px * 0.42, th["muted"], p * a_out,
               bold=False, stroke=2)
    return img


def card_lower_third(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    name, role = sp.get("name", "姓名"), sp.get("role", "")
    px = 64 if c.vertical else 58
    x0 = c.W * (0.08 if c.vertical else 0.06)
    y0 = c.region_y(sp.get("region", "lower"))
    a_out = out_alpha(t, D)
    slide = ease_out(prog(t, 0, 0.4))
    exit_k = prog(t, D - 0.4, 0.4)
    nw = c.tlen(name, px) + 70 * c.s
    rw = (c.tlen(role, px * 0.55, False) + 60 * c.s) if role else 0
    w = max(nw, rw)
    dx = -(1 - slide) * (w + x0) - exit_k * (w + x0)
    c.rrect(img, [x0 + dx, y0 - 52 * c.s, x0 + dx + 14 * c.s, y0 + (60 if role else 40) * c.s], 4, th["accent"])
    c.rrect(img, [x0 + dx + 22 * c.s, y0 - 52 * c.s, x0 + dx + 22 * c.s + nw, y0 + 40 * c.s], 10, th["panel"][:7],
            0.88)
    c.text(img, (x0 + dx + 22 * c.s + 34 * c.s, y0 - 6 * c.s), name, px, th["fg"], 1.0, anchor="lm", shadow=False)
    if role:
        p = ease_out(prog(t, 0.3, 0.4))
        c.rrect(img, [x0 + dx + 22 * c.s, y0 + 46 * c.s, x0 + dx + 22 * c.s + rw, y0 + 46 * c.s + px * 0.85 * c.s],
                8, th["accent"], p * a_out)
        c.text(img, (x0 + dx + 22 * c.s + 30 * c.s, y0 + 46 * c.s + px * 0.43 * c.s), role, px * 0.55, "#111111",
               p * a_out, anchor="lm", bold=True, shadow=False)
    return img


def card_counter(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    v1 = float(sp.get("value", 100))
    v0 = float(sp.get("start_value", 0))
    dec = int(sp.get("decimals", 0 if float(v1).is_integer() else 1))
    run_t = float(sp.get("count_time", min(1.4, D * 0.45)))
    k = ease_out(prog(t, 0.2, run_t))
    val = v0 + (v1 - v0) * k
    cy = c.region_y(sp.get("region", "center"))
    a_out = out_alpha(t, D)
    pop = 1 + 0.08 * math.sin(math.pi * prog(t, 0.2 + run_t, 0.25))
    big = sp.get("font_size", 190 if c.vertical else 210)
    txt = f"{sp.get('prefix', '')}{fmt_num(val, dec)}{sp.get('suffix', '')}"
    if sp.get("label"):
        p = ease_out(prog(t, 0, 0.4))
        lw = c.tlen(sp["label"], 56) + 70 * c.s
        c.rrect(img, [c.W / 2 - lw / 2, cy - big * 0.95 * c.s - 44 * c.s, c.W / 2 + lw / 2,
                      cy - big * 0.95 * c.s + 44 * c.s], 44, th["accent2"], p * a_out)
        c.text(img, (c.W / 2, cy - big * 0.95 * c.s), sp["label"], 56, th["fg"], p * a_out, shadow=False)
    c.text(img, (c.W / 2, cy + 10 * c.s), txt, big, th["accent"], ease_out(prog(t, 0.1, 0.3)) * a_out,
           stroke=6, scale=pop)
    if sp.get("note"):
        c.text(img, (c.W / 2, cy + big * 0.8 * c.s), sp["note"], 50, th["fg"],
               ease_out(prog(t, 0.2 + run_t, 0.4)) * a_out, bold=False, stroke=3)
    return img


def card_stat_cards(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    items = sp.get("items", [])[:4]
    n = max(1, len(items))
    cols = 2 if (c.vertical and n > 2) else n
    rows = math.ceil(n / cols)
    gw = c.W * (0.84 if c.vertical else 0.86)
    tile_w = (gw - (cols - 1) * 30 * c.s) / cols
    tile_h = (300 if c.vertical else 280) * c.s
    cy = c.region_y(sp.get("region", "center"))
    top = cy - (rows * tile_h + (rows - 1) * 30 * c.s) / 2
    a_out = out_alpha(t, D)
    if sp.get("title"):
        c.text(img, (c.W / 2, top - 90 * c.s), sp["title"], 72, th["fg"], ease_out(prog(t, 0, 0.4)) * a_out, stroke=3)
    for i, it in enumerate(items):
        r, col = divmod(i, cols)
        x = (c.W - gw) / 2 + col * (tile_w + 30 * c.s)
        y = top + r * (tile_h + 30 * c.s)
        st = 0.15 + i * 0.22
        p = ease_back(prog(t, st, 0.45))
        if p <= 0:
            continue
        cx, cyy = x + tile_w / 2, y + tile_h / 2
        sw, sh = tile_w * (0.85 + 0.15 * p), tile_h * (0.85 + 0.15 * p)
        al = clamp(prog(t, st, 0.25)) * a_out
        c.rrect(img, [cx - sw / 2, cyy - sh / 2, cx + sw / 2, cyy + sh / 2], 26, th["panel"][:7], 0.86 * al)
        c.rrect(img, [cx - sw / 2, cyy - sh / 2, cx - sw / 2 + 12 * c.s, cyy + sh / 2], 6, th["accent"], al)
        v1 = float(it.get("value", 0))
        dec = int(it.get("decimals", 0 if float(v1).is_integer() else 1))
        val = v1 * ease_out(prog(t, st + 0.1, 1.0))
        c.text(img, (cx, cyy - 26 * c.s), f"{it.get('prefix', '')}{fmt_num(val, dec)}{it.get('suffix', '')}",
               96 if cols <= 2 else 80, th["accent"], al, shadow=False)
        c.text(img, (cx, cyy + 70 * c.s), it.get("label", ""), 44, th["muted"], al, bold=False, shadow=False)
    return img


def card_bullets(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    items = sp.get("items", [])
    px = 62 if c.vertical else 56
    lh = px * 1.75 * c.s
    cy = c.region_y(sp.get("region", "center"))
    top = cy - lh * len(items) / 2
    x0 = c.W * (0.12 if c.vertical else 0.2)
    a_out = out_alpha(t, D)
    if sp.get("title"):
        c.text(img, (c.W / 2, top - 70 * c.s), sp["title"], 80, th["accent"], ease_out(prog(t, 0, 0.4)) * a_out,
               stroke=4)
        top += 30 * c.s
    gap = float(sp.get("stagger", min(0.6, (D - 1.2) / max(1, len(items)))))
    for i, txt in enumerate(items):
        st = 0.35 + i * gap
        p = ease_out(prog(t, st, 0.4))
        if p <= 0:
            continue
        y = top + lh * (i + 0.5)
        dx = (1 - p) * 50 * c.s
        r = px * 0.42 * c.s
        c.rrect(img, [x0 + dx - r, y - r, x0 + dx + r, y + r], 100, th["accent"], p * a_out)
        c.text(img, (x0 + dx, y + 2 * c.s), "✓" if sp.get("check", True) else str(i + 1), px * 0.6, "#111111",
               p * a_out, shadow=False)
        c.text(img, (x0 + dx + r + 30 * c.s, y), txt, px, th["fg"], p * a_out, anchor="lm", stroke=3)
    return img


def card_bar_chart(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    items = sp.get("items", [])
    if not items:
        return img
    mx = max(float(i["value"]) for i in items) or 1
    unit = sp.get("unit", "")
    hl = sp.get("highlight")
    cy = c.region_y(sp.get("region", "center"))
    bh = (70 if c.vertical else 56) * c.s
    gap = 34 * c.s
    total = len(items) * (bh + gap)
    top = cy - total / 2
    lab_w = max(c.tlen(i["label"], 46, False) for i in items) + 30 * c.s
    x0 = c.W * 0.08 + lab_w
    full = c.W * 0.84 - lab_w - 160 * c.s
    a_out = out_alpha(t, D)
    if sp.get("title"):
        c.text(img, (c.W / 2, top - 90 * c.s), sp["title"], 70, th["fg"], ease_out(prog(t, 0, 0.4)) * a_out, stroke=3)
    for i, it in enumerate(items):
        st = 0.3 + i * 0.18
        p = ease_out(prog(t, st, 0.9))
        y = top + i * (bh + gap)
        al = clamp(prog(t, st - 0.1, 0.3)) * a_out
        c.text(img, (x0 - 24 * c.s, y + bh / 2), it["label"], 46, th["fg"], al, anchor="rm", bold=False, stroke=2)
        w = max(bh * 0.3, full * float(it["value"]) / mx * p)
        color = th["accent"] if (hl is None or hl == i) else th["muted"]
        c.rrect(img, [x0, y, x0 + w, y + bh], 12, color, al * (1 if hl in (None, i) else 0.55))
        val = float(it["value"]) * p
        dec = 0 if float(it["value"]).is_integer() else 1
        c.text(img, (x0 + w + 20 * c.s, y + bh / 2), f"{fmt_num(val, dec)}{unit}", 46, th["fg"], al, anchor="lm",
               stroke=2)
    return img


def card_price_tag(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    cy = c.region_y(sp.get("region", "center"))
    a_out = out_alpha(t, D)
    if sp.get("label"):
        c.text(img, (c.W / 2, cy - 230 * c.s), sp["label"], 64, th["fg"], ease_out(prog(t, 0, 0.35)) * a_out, stroke=4)
    old = str(sp.get("old", ""))
    if old:
        p = ease_out(prog(t, 0.15, 0.35))
        c.text(img, (c.W / 2, cy - 110 * c.s), old, 80, th["muted"], p * a_out, stroke=3)
        lw = c.tlen(old, 80)
        k = ease_in_out(prog(t, 0.55, 0.35))
        if k > 0:
            c.rrect(img, [c.W / 2 - lw / 2 - 10 * c.s, cy - 116 * c.s, c.W / 2 - lw / 2 - 10 * c.s + (lw + 20 * c.s) * k,
                          cy - 104 * c.s], 4, th["accent2"], a_out)
    p = ease_back(prog(t, 0.85, 0.5))
    if p > 0:
        burst = prog(t, 0.85, 0.6)
        r = (330 + 120 * burst) * c.s
        c.rrect(img, [c.W / 2 - r, cy + 60 * c.s - r * 0.5, c.W / 2 + r, cy + 60 * c.s + r * 0.5], 300, th["accent"],
                (1 - burst) * 0.35 * a_out)
        c.text(img, (c.W / 2, cy + 60 * c.s), str(sp.get("new", "")), 170, th["accent"], clamp(p) * a_out, stroke=7,
               scale=0.6 + 0.4 * p)
    if sp.get("note"):
        c.text(img, (c.W / 2, cy + 210 * c.s), sp["note"], 48, th["fg"], ease_out(prog(t, 1.3, 0.4)) * a_out,
               bold=False, stroke=3)
    return img


def card_end_card(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    cy = c.region_y(sp.get("region", "center"))
    a_out = out_alpha(t, D, 0.25)
    c.text(img, (c.W / 2, cy - 120 * c.s), sp.get("text", "关注我们"), 92, th["fg"], ease_out(prog(t, 0, 0.45)) * a_out,
           stroke=4)
    if sp.get("button"):
        p = ease_back(prog(t, 0.35, 0.5))
        pulse = 1 + 0.045 * math.sin(max(0, t - 0.9) * 2 * math.pi * 1.2) if t > 0.9 else 1
        bw = (c.tlen(sp["button"], 64) + 140 * c.s) * pulse * max(0.01, p)
        bh = 130 * c.s * pulse * max(0.01, p)
        c.rrect(img, [c.W / 2 - bw / 2, cy + 40 * c.s - bh / 2, c.W / 2 + bw / 2, cy + 40 * c.s + bh / 2], 70,
                th["accent2"], clamp(p) * a_out)
        c.text(img, (c.W / 2, cy + 40 * c.s), sp["button"], 64, th["fg"], clamp(p) * a_out, shadow=False,
               scale=pulse)
    if sp.get("sub"):
        c.text(img, (c.W / 2, cy + 190 * c.s), sp["sub"], 46, th["muted"], ease_out(prog(t, 0.7, 0.4)) * a_out,
               bold=False, stroke=2)
    return img


def card_callout(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    x, y = float(sp.get("x", 0.5)) * c.W, float(sp.get("y", 0.5)) * c.H
    a_out = out_alpha(t, D)
    p = ease_back(prog(t, 0, 0.4))
    r = 70 * c.s * p
    ring = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(ring)
    d.ellipse([x - r, y - r, x + r, y + r], outline=rgba(th["accent"], a_out), width=int(10 * c.s))
    pr = prog(t, 0.4, 0.9) % 1 if t > 0.4 else 0
    rr = 70 * c.s * (1 + pr * 0.8)
    d.ellipse([x - rr, y - rr, x + rr, y + rr], outline=rgba(th["accent"], (1 - pr) * 0.7 * a_out), width=int(5 * c.s))
    img.alpha_composite(ring)
    if sp.get("text"):
        k = ease_out(prog(t, 0.3, 0.4))
        side = -1 if x > c.W * 0.55 else 1
        tx = x + side * (110 * c.s + 40 * c.s * k)
        ty = y - 110 * c.s
        ImageDraw.Draw(img).line([(x + side * 50 * c.s, y - 50 * c.s), (tx, ty)], fill=rgba(th["accent"], k * a_out),
                                 width=int(6 * c.s))
        tw = c.tlen(sp["text"], 52) + 50 * c.s
        bx = tx if side > 0 else tx - tw
        c.rrect(img, [bx, ty - 45 * c.s, bx + tw, ty + 45 * c.s], 16, th["accent"], k * a_out)
        c.text(img, (bx + tw / 2, ty), sp["text"], 52, "#111111", k * a_out, shadow=False)
    return img


def card_quote(c: Canvas, sp, t, D):
    img = c.new()
    th = c.th
    cy = c.region_y(sp.get("region", "center"))
    a_out = out_alpha(t, D)
    txt = str(sp.get("text", ""))
    per = max(6, int((c.W * 0.78) / (64 * c.s)))
    lines = [txt[i:i + per] for i in range(0, len(txt), per)]
    c.text(img, (c.W * 0.14, cy - len(lines) * 50 * c.s - 80 * c.s), "“", 200, th["accent"],
           ease_out(prog(t, 0, 0.4)) * a_out, anchor="lm", shadow=False)
    for i, l in enumerate(lines):
        p = ease_out(prog(t, 0.2 + i * 0.15, 0.45))
        c.text(img, (c.W / 2, cy - (len(lines) - 1) * 50 * c.s + i * 100 * c.s + (1 - p) * 30 * c.s), l, 64, th["fg"],
               p * a_out, stroke=3)
    if sp.get("author"):
        c.text(img, (c.W * 0.86, cy + len(lines) * 50 * c.s + 70 * c.s), f"—— {sp['author']}", 44, th["muted"],
               ease_out(prog(t, 0.6, 0.4)) * a_out, anchor="rm", bold=False, stroke=2)
    return img


RENDERERS = {"title": card_title, "lower_third": card_lower_third, "counter": card_counter,
             "stat_cards": card_stat_cards, "bullets": card_bullets, "bar_chart": card_bar_chart,
             "price_tag": card_price_tag, "end_card": card_end_card, "callout": card_callout,
             "quote": card_quote}


# ---------------------------------------------------------------------- render


def theme_for(sp: dict, edit: Path | None) -> dict:
    th = dict(DEFAULT_THEME)
    if edit:
        brand = read_json(edit / "brand.json") or {}
        th.update(brand.get("theme") or {})
    th.update(sp.get("theme") or {})
    return th


def render_card(sp: dict, edit: Path | None = None) -> Path:
    typ = sp["type"]
    if typ not in RENDERERS:
        raise SystemExit(f"unknown card type {typ}. Types: {', '.join(RENDERERS)}")
    size = sp.get("size", "9:16")
    W, H = SIZES[size] if size in SIZES else tuple(int(x) for x in str(size).lower().split("x"))
    fps = float(sp.get("fps", 30))
    D = float(sp.get("duration", 4.0))
    bg = sp.get("background")
    th = theme_for(sp, edit)
    cv = Canvas(W, H, th, bg)
    out = Path(sp.get("out") or (f"{typ}.mp4" if bg else f"{typ}.mov"))
    out.parent.mkdir(parents=True, exist_ok=True)
    if bg:
        enc = ["-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p"]
        if out.suffix != ".mp4":
            out = out.with_suffix(".mp4")
    else:
        enc = ["-c:v", "qtrle", "-pix_fmt", "argb"]
        if out.suffix != ".mov":
            out = out.with_suffix(".mov")
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}", "-r", str(fps),
           "-i", "-", *enc, str(out)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    n = int(round(D * fps))
    fn = RENDERERS[typ]
    for i in range(n):
        img = fn(cv, sp, i / fps, D)
        proc.stdin.write(img.tobytes())
    proc.stdin.close()
    if proc.wait() != 0:
        raise SystemExit("ffmpeg failed while encoding card")
    log(f"✓ {typ} → {out} ({W}x{H}, {D}s, {'opaque' if bg else 'alpha'})")
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("spec", nargs="?")
    ap.add_argument("--type")
    ap.add_argument("--size", default="9:16")
    ap.add_argument("--duration", type=float, default=4.0)
    ap.add_argument("--background")
    ap.add_argument("--text")
    ap.add_argument("--sub")
    ap.add_argument("--name")
    ap.add_argument("--role")
    ap.add_argument("--value", type=float)
    ap.add_argument("--prefix", default="")
    ap.add_argument("--suffix", default="")
    ap.add_argument("--label")
    ap.add_argument("--region")
    ap.add_argument("--demo", metavar="OUTDIR")
    ap.add_argument("--edit", default=".")
    ap.add_argument("-o", "--out")
    args = ap.parse_args()
    edit = find_edit_dir(args.edit)
    edit = edit if edit.exists() else None

    if args.demo:
        d = Path(args.demo)
        demos = [
            {"type": "title", "text": "首付1.9万\n开回家", "sub": "限时活动 · 名额有限"},
            {"type": "lower_third", "name": "李经理", "role": "喜相逢 · 资深顾问"},
            {"type": "counter", "value": 2099, "prefix": "¥", "label": "月供低至", "note": "36期 · 0手续费"},
            {"type": "stat_cards", "title": "本月成绩", "items": [{"label": "成交", "value": 128, "suffix": "台"},
                                                              {"label": "线索", "value": 3560},
                                                              {"label": "转化率", "value": 3.6, "suffix": "%"},
                                                              {"label": "好评", "value": 98, "suffix": "%"}]},
            {"type": "bullets", "title": "三步开回家", "items": ["线上预约看车", "门店试驾签约", "当天提车上路"]},
            {"type": "bar_chart", "title": "各渠道线索量", "items": [{"label": "抖音", "value": 1520},
                                                                  {"label": "视频号", "value": 860},
                                                                  {"label": "小红书", "value": 640}],
             "highlight": 0},
            {"type": "price_tag", "label": "直播间专享", "old": "¥129,800", "new": "¥99,800", "note": "仅限今晚"},
            {"type": "end_card", "text": "想了解更多？", "button": "点击预约试驾", "sub": "评论区留言 · 专人回复"},
            {"type": "callout", "x": 0.62, "y": 0.42, "text": "全景天窗"},
        ]
        for sp in demos:
            sp.update({"size": args.size, "duration": 3.5, "out": str(d / f"{sp['type']}.mov")})
            render_card(sp, edit)
        return
    if args.spec:
        data = read_json(args.spec)
        for sp in (data if isinstance(data, list) else [data]):
            render_card(sp, edit)
        return
    if not args.type:
        ap.error("give a spec file, --type, or --demo")
    sp = {k: v for k, v in vars(args).items() if v is not None and k not in ("spec", "demo", "edit", "type")}
    sp["type"] = args.type
    if args.out:
        sp["out"] = args.out
    render_card(sp, edit)


if __name__ == "__main__":
    main()

_ = json  # noqa
