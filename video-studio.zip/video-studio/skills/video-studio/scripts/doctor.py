#!/usr/bin/env python3
"""Environment check for video-studio. Run once per machine (and when something breaks).

  python doctor.py          # human readable, with install commands for this OS
  python doctor.py --json
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import find_cjk_font, os_name  # noqa: E402


def mod(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def out(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout
    except Exception:
        return ""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    osn = os_name()
    arm = platform.machine() in ("arm64", "aarch64")
    pipi = f"{sys.executable} -m pip install"
    checks = []

    def add(name, ok, detail="", fix="", required=True):
        checks.append({"name": name, "ok": bool(ok), "detail": detail, "fix": fix, "required": required})

    ff = shutil.which("ffmpeg")
    filt = out(["ffmpeg", "-hide_banner", "-filters"]) if ff else ""
    enc = out(["ffmpeg", "-hide_banner", "-encoders"]) if ff else ""
    ver = out(["ffmpeg", "-version"]).splitlines()[0] if ff else ""
    ff_fix = {"mac": "brew install ffmpeg-full   # 带 libass/zimg (字幕+HDR)；若已装 ffmpeg 先 brew uninstall ffmpeg",
              "windows": "winget install Gyan.FFmpeg   # full build",
              "linux": "sudo apt install ffmpeg"}[osn]
    add("ffmpeg", ff, ver, ff_fix)
    add("ffmpeg: libass (burn captions)", " ass " in filt or " subtitles " in filt, "", ff_fix)
    add("ffmpeg: libx264", "libx264" in enc, "", ff_fix)
    add("ffmpeg: zscale (HDR/iPhone HLG→SDR)", " zscale " in filt, "", ff_fix, required=False)
    add("ffmpeg: sidechaincompress/loudnorm", " sidechaincompress " in filt and " loudnorm " in filt, "", ff_fix)
    add("ffprobe", shutil.which("ffprobe"), "", ff_fix)
    add("python ≥ 3.9", sys.version_info >= (3, 9), sys.version.split()[0], "")
    add("numpy", mod("numpy"), "", f"{pipi} numpy")
    add("Pillow", mod("PIL"), "", f"{pipi} pillow")
    font, fam = find_cjk_font()
    add("CJK font", font, f"{fam} · {font}", "install Noto Sans CJK / set VS_FONT=/path/to/font.ttf")

    # ASR
    asr = []
    if mod("funasr"):
        asr.append("funasr")
    if mod("mlx_whisper"):
        asr.append("mlx")
    if mod("faster_whisper"):
        asr.append("faster-whisper")
    if os.environ.get("ELEVENLABS_API_KEY"):
        asr.append("scribe")
    rec = (f"{pipi} funasr modelscope torch torchaudio   # 中文最准，本地\n"
           + (f"      {pipi} mlx-whisper   # Apple Silicon 加速\n" if osn == "mac" and arm else "")
           + f"      {pipi} faster-whisper   # 通用")
    add("ASR backend (word timestamps)", asr, ", ".join(asr) or "none", rec)
    add("jieba (Chinese line breaks)", mod("jieba"), "", f"{pipi} jieba", required=False)
    add("opencc (繁→简)", mod("opencc"), "", f"{pipi} opencc-python-reimplemented", required=False)
    fb = "none"
    try:
        from vs_faces import backend
        os.environ.setdefault("VS_NO_DOWNLOAD", "1")
        fb = backend()
    except Exception:
        pass
    add("face detector (reframe, covers)", fb != "none", fb, f'{pipi} "opencv-python-headless>=4.8,<5"',
        required=False)
    add("edge-tts (free Mandarin voiceover)", mod("edge_tts"), "", f"{pipi} edge-tts", required=False)
    add("fontTools+brotli (motion font subset)", mod("fontTools") and mod("brotli"), "", f"{pipi} fonttools brotli",
        required=False)
    node = shutil.which("node")
    nv = out(["node", "-v"]).strip() if node else ""
    try:
        major = int(nv.lstrip("v").split(".")[0]) if nv else 0
    except ValueError:
        major = 0
    add("Node.js ≥ 22 (HyperFrames motion)", major >= 22, nv or "missing",
        {"mac": "brew install node", "windows": "winget install OpenJS.NodeJS.LTS",
         "linux": "https://nodejs.org (v22+)"}[osn], required=False)
    add("yt-dlp (download links)", shutil.which("yt-dlp"), "", "brew install yt-dlp  |  pip install yt-dlp",
        required=False)
    gpu = "nvidia" if shutil.which("nvidia-smi") else ("apple" if osn == "mac" and arm else "cpu")
    add("acceleration", True, gpu, "", required=False)

    if a.json:
        print(json.dumps({"ok": all(c["ok"] for c in checks if c["required"]), "checks": checks}, ensure_ascii=False,
                         indent=2))
        return
    print(f"video-studio doctor · {osn} {platform.machine()} · python {sys.version.split()[0]}\n")
    for c in checks:
        mark = "✓" if c["ok"] else ("✗" if c["required"] else "·")
        print(f"  {mark} {c['name']:<42} {c['detail'] if c['ok'] else ''}")
        if not c["ok"] and c["fix"]:
            print(f"      → {c['fix']}")
    bad = [c for c in checks if c["required"] and not c["ok"]]
    print("\n" + ("All required checks passed." if not bad else f"{len(bad)} required item(s) missing."))


if __name__ == "__main__":
    main()
