#!/usr/bin/env python3
"""Code-generated videos (数据讲解 / 产品讲解 / 片头片尾) as HyperFrames projects.

A scene spec (JSON) → a lint-clean HyperFrames composition with:
  · subsetted CJK font embedded (no silent fallback to the wrong face)
  · GSAP vendored locally (no CDN at render time)
  · one paused timeline, seek-safe counters/bars, per-scene enter/exit motion
Then HyperFrames renders it deterministically (headless Chrome + FFmpeg).

  python motion.py build spec.json edit/motion/explainer      # write the project
  python motion.py render edit/motion/explainer [--draft] [--alpha]   # check + render → render.mp4
  python motion.py sync spec.json --vo edit/audio/vo            # set scene durations from TTS timing
  python motion.py example > spec.json                          # starter spec

Scene types: hook · kpis · bars · compare · steps · quote · image · cta · text
Every scene takes "duration" (s); see example for fields. "background": null on the spec
renders a transparent overlay (use --alpha → .webm with alpha) for 口播 inserts.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import SKILL_DIR, bold_face_index, find_cjk_font, log, read_json, text_units, write_json  # noqa: E402

SIZES = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "3:4": (1080, 1440),
         "4:5": (1080, 1350)}
THEME = {"bg": "#0B0F14", "bg2": "#16202B", "fg": "#FFFFFF", "accent": "#FFD400", "accent2": "#E8322E",
         "muted": "#9AA4B2", "panel": "#141C26"}

EXAMPLE = {
    "size": "9:16", "fps": 30,
    "theme": {"bg": "#0B0F14", "accent": "#FFD400", "accent2": "#E8322E"},
    "music": None,
    "scenes": [
        {"type": "hook", "duration": 3, "kicker": "算笔账", "title": "开一辆车\n每月到底花多少？"},
        {"type": "kpis", "duration": 4.5, "title": "以租代购 · 月度成本",
         "items": [{"label": "月供", "value": 2099, "prefix": "¥"}, {"label": "首付", "value": 1.9, "suffix": "万"},
                   {"label": "期限", "value": 36, "suffix": "期"}, {"label": "手续费", "value": 0, "prefix": "¥"}]},
        {"type": "bars", "duration": 5, "title": "三年总成本对比", "unit": "万",
         "items": [{"label": "全款购车", "value": 13.8}, {"label": "贷款购车", "value": 15.2},
                   {"label": "以租代购", "value": 9.4}], "highlight": 2},
        {"type": "compare", "duration": 4.5, "left": {"title": "传统买车", "points": ["首付高", "手续多", "贬值快"]},
         "right": {"title": "以租代购", "points": ["低首付", "当天提车", "到期可换"]}},
        {"type": "steps", "duration": 4, "title": "三步开回家", "items": ["线上预约", "门店签约", "当天提车"]},
        {"type": "cta", "duration": 3, "title": "想了解更多？", "button": "预约试驾", "sub": "评论区留言 · 专人回复"},
    ],
}


# --------------------------------------------------------------------- fonts


def subset_font(texts: list[str], out_dir: Path, font: str | None) -> tuple[str, str]:
    """Subset the CJK bold face to the characters actually used → fonts/brand.woff2."""
    ffile, _fam = find_cjk_font(font)
    if not ffile:
        raise SystemExit("no CJK font found; set VS_FONT=/path/to/font.ttf")
    chars = set("".join(texts))
    chars |= set("0123456789.,%+-¥$€:/()·—–|×！？，。、：；“”‘’《》【】 "
                 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / "brand.woff2"
    txt = out_dir / "chars.txt"
    txt.write_text("".join(sorted(chars)), encoding="utf-8")
    cmd = [sys.executable, "-m", "fontTools.subset", ffile, f"--text-file={txt}", "--flavor=woff2",
           f"--output-file={out}", "--layout-features=*", "--no-hinting"]
    if ffile.lower().endswith((".ttc", ".otc")):
        cmd.append(f"--font-number={bold_face_index(ffile, 'bold')}")
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        log(res.stderr[-800:])
        if "brotli" in res.stderr.lower():
            raise SystemExit("pip install brotli  (needed for woff2)")
        raise SystemExit("font subsetting failed")
    txt.unlink()
    return "fonts/brand.woff2", "VSBrand"


# --------------------------------------------------------------------- scenes


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""))


AVAIL_U = 900.0  # usable text width in --u units (set per build from the canvas)


def lines_html(s: str, cls: str = "") -> str:
    return "".join(f'<span class="ln {cls}">{esc(x)}</span>' for x in str(s).split("\n"))


def fit(s: str, base: float, avail: float | None = None) -> str:
    """Inline font-size so the longest line fits on one row (CJK ≈ 1em per char)."""
    longest = max((text_units(x) for x in str(s).split("\n")), default=1) or 1
    size = min(base, (avail or AVAIL_U) * 0.97 / (longest * 1.03))
    return f' style="font-size: calc(var(--u) * {size:.1f})"' if size < base else ""


def num_attrs(it: dict) -> str:
    v = float(it.get("value", 0))
    dec = int(it.get("decimals", 0 if v.is_integer() else 1))
    return (f'data-to="{v}" data-dec="{dec}" data-pre="{esc(it.get("prefix", ""))}" '
            f'data-suf="{esc(it.get("suffix", ""))}"')


def scene_html(i: int, sc: dict, start: float, assets: dict) -> str:
    t = sc["type"]
    sid = f"s{i}"
    d = float(sc["duration"])
    head = f'<section id="{sid}" class="clip scene scene-{t}" data-start="{start:.3f}" data-duration="{d:.3f}" ' \
           f'data-track-index="1"><div class="inner" id="{sid}-in">'
    tail = "</div></section>"
    if t == "hook":
        body = (f'<div class="kicker a" id="{sid}-k">{esc(sc.get("kicker", ""))}</div>' if sc.get("kicker") else "")
        body += f'<h1 class="title big a" id="{sid}-t"{fit(sc.get("title", ""), 118)}>{lines_html(sc.get("title", ""))}</h1>'
        body += '<div class="rule a" id="%s-r"></div>' % sid
    elif t == "text":
        body = f'<h2 class="title a" id="{sid}-t"{fit(sc.get("title", ""), 82)}>{lines_html(sc.get("title", ""))}</h2>'
        if sc.get("body"):
            body += f'<p class="body a" id="{sid}-b">{esc(sc["body"])}</p>'
    elif t == "kpis":
        items = sc.get("items", [])[:6]
        body = f'<h2 class="title a" id="{sid}-t"{fit(sc.get("title", ""), 82)}>{esc(sc.get("title", ""))}</h2><div class="grid n{len(items)}">'
        for k, it in enumerate(items):
            body += (f'<div class="tile a" id="{sid}-i{k}"><div class="num" {num_attrs(it)}>'
                     f'{esc(it.get("prefix", ""))}0{esc(it.get("suffix", ""))}</div>'
                     f'<div class="lab">{esc(it.get("label", ""))}</div></div>')
        body += "</div>"
    elif t == "bars":
        items = sc.get("items", [])
        mx = max([float(x["value"]) for x in items] or [1]) or 1
        hl = sc.get("highlight")
        body = f'<h2 class="title a" id="{sid}-t"{fit(sc.get("title", ""), 82)}>{esc(sc.get("title", ""))}</h2><div class="bars">'
        for k, it in enumerate(items):
            pct = 100 * float(it["value"]) / mx
            on = " on" if (hl is None or hl == k) else ""
            body += (f'<div class="row a" id="{sid}-i{k}"><div class="blab">{esc(it["label"])}</div>'
                     f'<div class="track"><div class="bar{on}" data-pct="{pct:.2f}"></div></div>'
                     f'<div class="bval num" {num_attrs({**it, "suffix": it.get("suffix", sc.get("unit", ""))})}>0</div></div>')
        body += "</div>"
    elif t == "compare":
        L, R = sc.get("left", {}), sc.get("right", {})
        def col(c, side):
            pts = "".join(f'<li class="a" id="{sid}-{side}{k}">{esc(p)}</li>' for k, p in enumerate(c.get("points", [])))
            return f'<div class="col {side} a" id="{sid}-{side}"><h3>{esc(c.get("title", ""))}</h3><ul>{pts}</ul></div>'
        body = (f'<h2 class="title a" id="{sid}-t"{fit(sc.get("title", ""), 82)}>{esc(sc.get("title", ""))}</h2>' if sc.get("title") else "")
        body += f'<div class="cmp">{col(L, "l")}<div class="vs a" id="{sid}-vs">VS</div>{col(R, "r")}</div>'
    elif t == "steps":
        body = f'<h2 class="title a" id="{sid}-t"{fit(sc.get("title", ""), 82)}>{esc(sc.get("title", ""))}</h2><ol class="steps">'
        for k, s in enumerate(sc.get("items", [])):
            body += f'<li class="a" id="{sid}-i{k}"><span class="dot">{k + 1}</span><span>{esc(s)}</span></li>'
        body += "</ol>"
    elif t == "quote":
        body = (f'<div class="qmark a" id="{sid}-q">“</div><blockquote class="a" id="{sid}-t">{esc(sc.get("text", ""))}'
                f'</blockquote><div class="author a" id="{sid}-a">{("—— " + esc(sc["author"])) if sc.get("author") else ""}</div>')
    elif t == "image":
        src = assets.get(sc["src"], sc["src"])
        body = (f'<div class="imgwrap"><img id="{sid}-img" class="photo" src="{esc(src)}" alt=""></div>'
                + (f'<div class="cap a" id="{sid}-c">{esc(sc["caption"])}</div>' if sc.get("caption") else ""))
    elif t == "cta":
        body = f'<h2 class="title big a" id="{sid}-t"{fit(sc.get("title", ""), 118)}>{lines_html(sc.get("title", ""))}</h2>'
        if sc.get("button"):
            body += f'<div class="btn a" id="{sid}-btn">{esc(sc["button"])}</div>'
        if sc.get("sub"):
            body += f'<div class="sub a" id="{sid}-s">{esc(sc["sub"])}</div>'
    else:
        raise SystemExit(f"unknown scene type {t}")
    return head + body + tail


CSS = """
@font-face { font-family: "VSBrand"; src: url("%(font)s") format("woff2"); font-weight: 400 900; }
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { width: 100%%; height: 100%%; background: %(page_bg)s; }
body { font-family: "VSBrand", sans-serif; color: %(fg)s; -webkit-font-smoothing: antialiased; }
#root { position: relative; width: 100%%; height: 100%%; overflow: hidden; --u: %(u)spx; }
.bgfill { position: absolute; inset: 0; background: radial-gradient(120%% 80%% at 20%% 10%%, %(bg2)s 0%%, %(bg)s 60%%); }
.glow { position: absolute; width: calc(var(--u) * 900); height: calc(var(--u) * 900); border-radius: 50%%;
        background: radial-gradient(circle, %(accent)s33 0%%, transparent 65%%); left: -20%%; top: -10%%; }
.scene { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; }
.inner { width: 100%%; height: 100%%; display: flex; flex-direction: column; align-items: center; justify-content: center;
         padding: calc(var(--u) * 110) calc(var(--u) * 80); gap: calc(var(--u) * 46); text-align: center; }
.title { font-weight: 800; font-size: calc(var(--u) * 82); line-height: 1.22; letter-spacing: 0.01em; }
.title.big { font-size: calc(var(--u) * 118); }
.ln { display: block; white-space: nowrap; }
.kicker { display: inline-block; font-weight: 800; font-size: calc(var(--u) * 46); color: #111; background: %(accent)s;
          padding: calc(var(--u) * 10) calc(var(--u) * 30); border-radius: calc(var(--u) * 14); }
.rule { width: calc(var(--u) * 200); height: calc(var(--u) * 12); border-radius: 99px; background: %(accent)s; }
.body { font-size: calc(var(--u) * 46); color: %(muted)s; max-width: 90%%; line-height: 1.5; font-weight: 500; }
.grid { display: grid; gap: calc(var(--u) * 30); width: 100%%; grid-template-columns: repeat(%(cols)s, 1fr); }
.grid.n1 { grid-template-columns: 1fr; } .grid.n3 { grid-template-columns: repeat(%(cols3)s, 1fr); }
.tile { background: %(panel)s; border-radius: calc(var(--u) * 28); padding: calc(var(--u) * 46) calc(var(--u) * 20);
        border-left: calc(var(--u) * 12) solid %(accent)s; display: flex; flex-direction: column; gap: calc(var(--u) * 12); }
.num { font-weight: 900; font-size: calc(var(--u) * 92); color: %(accent)s; font-variant-numeric: tabular-nums; }
.lab { font-size: calc(var(--u) * 40); color: %(muted)s; font-weight: 500; }
.bars { width: 100%%; display: flex; flex-direction: column; gap: calc(var(--u) * 36); }
.row { display: grid; grid-template-columns: calc(var(--u) * 230) 1fr calc(var(--u) * 190); align-items: center;
       gap: calc(var(--u) * 20); }
.blab { text-align: right; font-size: calc(var(--u) * 42); font-weight: 600; }
.track { height: calc(var(--u) * 72); background: #ffffff10; border-radius: calc(var(--u) * 14); overflow: hidden; }
.bar { display: block; height: 100%%; width: 0%%; background: %(muted)s; border-radius: calc(var(--u) * 14); }
.bar.on { background: %(accent)s; }
.bval { font-size: calc(var(--u) * 52); text-align: left; color: %(fg)s; }
.cmp { width: 100%%; display: flex; align-items: stretch; justify-content: center; gap: calc(var(--u) * 24); %(cmp_dir)s }
.col { flex: 1; background: %(panel)s; border-radius: calc(var(--u) * 28); padding: calc(var(--u) * 40);
       display: flex; flex-direction: column; gap: calc(var(--u) * 24); }
.col h3 { font-size: calc(var(--u) * 58); font-weight: 800; }
.col.l h3 { color: %(muted)s; } .col.r { outline: calc(var(--u) * 6) solid %(accent)s; } .col.r h3 { color: %(accent)s; }
.col ul { list-style: none; display: flex; flex-direction: column; gap: calc(var(--u) * 18); }
.col li { font-size: calc(var(--u) * 46); font-weight: 600; }
.col.l li { color: %(muted)s; text-decoration: line-through; text-decoration-color: %(accent2)s; }
.vs { align-self: center; font-weight: 900; font-size: calc(var(--u) * 64); color: %(accent2)s; }
.steps { list-style: none; display: flex; flex-direction: column; gap: calc(var(--u) * 34); width: 88%%; }
.steps li { display: flex; align-items: center; gap: calc(var(--u) * 30); font-size: calc(var(--u) * 60); font-weight: 700;
            background: %(panel)s; border-radius: calc(var(--u) * 24); padding: calc(var(--u) * 30) calc(var(--u) * 40); }
.dot { display: flex; align-items: center; justify-content: center; flex: none; width: calc(var(--u) * 92);
       height: calc(var(--u) * 92); border-radius: 50%%; background: %(accent)s; color: #111; font-weight: 900; }
.qmark { font-size: calc(var(--u) * 220); line-height: 0.6; color: %(accent)s; font-weight: 900; }
blockquote { font-size: calc(var(--u) * 68); font-weight: 700; line-height: 1.45; max-width: 92%%; }
.author { font-size: calc(var(--u) * 42); color: %(muted)s; }
.imgwrap { position: absolute; inset: 0; overflow: hidden; }
.photo { display: block; width: 100%%; height: 100%%; object-fit: cover; }
.cap { position: absolute; left: 6%%; right: 6%%; bottom: 14%%; font-size: calc(var(--u) * 58); font-weight: 800;
       background: #000000a0; border-radius: calc(var(--u) * 18); padding: calc(var(--u) * 20) calc(var(--u) * 30); }
.btn { display: inline-block; font-size: calc(var(--u) * 62); font-weight: 800; background: %(accent2)s; color: #fff;
       padding: calc(var(--u) * 30) calc(var(--u) * 80); border-radius: 999px; }
.sub { font-size: calc(var(--u) * 42); color: %(muted)s; }
"""

JS = r"""
const tl = gsap.timeline({ paused: true });
const SCENES = %(scenes)s;
function countUp(el, at, dur) {
  const to = parseFloat(el.dataset.to), dec = parseInt(el.dataset.dec || "0", 10);
  const pre = el.dataset.pre || "", suf = el.dataset.suf || "";
  const o = { v: 0 };
  const fmt = (v) => pre + v.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suf;
  el.textContent = fmt(0);
  tl.to(o, { v: to, duration: dur, ease: "power3.out", onUpdate: () => { el.textContent = fmt(o.v); } }, at);
}
SCENES.forEach((sc) => {
  const s = sc.start, d = sc.duration, root = document.getElementById(sc.id + "-in");
  const items = root.querySelectorAll(".a");
  items.forEach((el, k) => {
    tl.fromTo(el, { opacity: 0, y: 40 * U }, { opacity: 1, y: 0, duration: 0.55, ease: "power3.out" },
              s + 0.12 + k * sc.stagger);
  });
  root.querySelectorAll(".num").forEach((el, k) => countUp(el, s + 0.35 + k * sc.stagger, Math.min(1.4, d * 0.4)));
  root.querySelectorAll(".bar").forEach((el, k) => {
    tl.fromTo(el, { width: "0%%" }, { width: el.dataset.pct + "%%", duration: 1.0, ease: "power3.out" },
              s + 0.45 + k * sc.stagger);
  });
  const img = root.querySelector(".photo");
  if (img) tl.fromTo(img, { scale: 1.0 }, { scale: 1.12, duration: d, ease: "none" }, s);
  const btn = root.querySelector(".btn");
  if (btn) tl.fromTo(btn, { scale: 1 }, { scale: 1.06, duration: 0.45, ease: "sine.inOut", yoyo: true,
                     repeat: Math.max(0, Math.floor((d - 1.2) / 0.45) - 1) }, s + 1.0);
  if (!sc.last) tl.to(root, { opacity: 0, duration: 0.3, ease: "power2.in" }, s + d - 0.3);
});
const glow = document.querySelector(".glow");
if (glow) tl.fromTo(glow, { x: 0, y: 0 }, { x: 260 * U, y: 520 * U, duration: TOTAL, ease: "sine.inOut" }, 0);
window.__timelines["main"] = tl;
"""


def build(spec: dict, out: Path, spec_dir: Path) -> Path:
    size = spec.get("size", "9:16")
    W, H = SIZES[size] if size in SIZES else tuple(int(x) for x in str(size).lower().split("x"))
    fps = spec.get("fps", 30)
    th = {**THEME, **(spec.get("theme") or {})}
    transparent = spec.get("background", "x") is None
    out.mkdir(parents=True, exist_ok=True)
    (out / "assets").mkdir(exist_ok=True)
    vendor = SKILL_DIR / "assets" / "vendor" / "gsap.min.js"
    shutil.copy(vendor, out / "assets" / "gsap.min.js")
    # copy referenced media
    assets: dict = {}
    for sc in spec["scenes"]:
        if sc.get("type") == "image":
            p = Path(sc["src"])
            p = p if p.is_absolute() else (spec_dir / p)
            if not p.exists():
                raise SystemExit(f"image not found: {p}")
            shutil.copy(p, out / "assets" / p.name)
            assets[sc["src"]] = f"assets/{p.name}"
    texts = []
    for sc in spec["scenes"]:
        texts.append(json.dumps(sc, ensure_ascii=False))
    font_rel, _fam = subset_font(texts, out / "fonts", spec.get("font"))

    global AVAIL_U
    u0 = W / 1080 if H >= W else H / 1080
    AVAIL_U = min(W / u0 - 160, 1500)
    start, scene_meta, parts = 0.0, [], []
    for i, sc in enumerate(spec["scenes"]):
        d = float(sc.get("duration", 3))
        sc["duration"] = d
        n_anim = max(1, {"kpis": len(sc.get("items", [])) + 1, "bars": len(sc.get("items", [])) + 1,
                         "steps": len(sc.get("items", [])) + 1}.get(sc["type"], 3))
        stagger = float(sc.get("stagger", min(0.28, max(0.08, (d * 0.45) / n_anim))))
        parts.append(scene_html(i, sc, start, assets))
        scene_meta.append({"id": f"s{i}", "start": round(start, 3), "duration": d, "stagger": stagger,
                           "last": i == len(spec["scenes"]) - 1})
        start += d
    D = round(start, 3)
    music = ""
    if spec.get("music"):
        p = Path(spec["music"])
        p = p if p.is_absolute() else spec_dir / p
        shutil.copy(p, out / "assets" / p.name)
        vol = float(spec.get("music_volume", 0.35))
        music = (f'<audio id="bgm" class="clip" data-start="0" data-duration="{D}" data-track-index="9" '
                 f'data-volume="{vol}" src="assets/{esc(p.name)}"></audio>')
    u = W / 1080 if H >= W else H / 1080
    vertical = H > W
    css = CSS % {**th, "font": font_rel, "u": f"{u:.4f}", "page_bg": "transparent" if transparent else th["bg"],
                 "cols": 2, "cols3": 1 if vertical else 3,
                 "cmp_dir": "flex-direction: column;" if vertical else ""}
    bg_layers = "" if transparent else '<div class="bgfill"></div><div class="glow"></div>'
    js = JS % {"scenes": json.dumps(scene_meta)}
    doc = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width={W}, height={H}" />
<title>{esc(spec.get('title', 'video-studio motion'))}</title>
<script src="assets/gsap.min.js"></script>
<style>{css}</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-width="{W}" data-height="{H}" data-duration="{D}" data-fps="{fps}">
{bg_layers}
{chr(10).join(parts)}
{music}
</div>
<script>
const U = {u:.4f}; const TOTAL = {D};
document.fonts.load('800 80px "VSBrand"').then(() => {{
{js}
}});
</script>
</body>
</html>
"""
    (out / "index.html").write_text(doc, encoding="utf-8")
    write_json(out / "vs_motion.json", {"spec": spec, "duration": D, "size": [W, H], "fps": fps,
                                        "transparent": transparent})
    log(f"✓ HyperFrames project → {out}  ({W}x{H}, {D}s, {len(parts)} scenes)")
    log(f"  next: python motion.py render {out} --draft")
    return out


def hf_env() -> dict:
    env = dict(os.environ)
    env.setdefault("HYPERFRAMES_NO_TELEMETRY", "1")
    return env


def render(proj: Path, draft: bool, alpha: bool, out: Path | None) -> Path:
    npx = shutil.which("npx") or shutil.which("npx.cmd")
    if npx is None:
        raise SystemExit("Node.js 22+ required for HyperFrames (npx not found)")
    env = hf_env()
    log("· npx hyperframes check")
    chk = subprocess.run([npx, "--yes", "hyperframes", "check"], cwd=proj, env=env, capture_output=True, text=True,
                         encoding="utf-8", errors="replace")
    print(chk.stdout[-2500:])
    if chk.returncode != 0:
        log(chk.stderr[-1500:])
        log("✗ check failed — fix the findings above (see references/motion.md → troubleshooting)")
        sys.exit(1)
    meta = read_json(proj / "vs_motion.json", {}) or {}
    fmt = "webm" if (alpha or meta.get("transparent")) else "mp4"
    target = out or proj / f"render{'_draft' if draft else ''}.{fmt}"
    cmd = [npx, "--yes", "hyperframes", "render", "--quality", "draft" if draft else "delivery",
           "--output", str(target.resolve())]
    if fmt == "webm":
        cmd += ["--format", "webm"]
    log("· " + " ".join(cmd[2:]))
    res = subprocess.run(cmd, cwd=proj, env=env)
    if res.returncode != 0 or not target.exists():
        raise SystemExit("✗ render failed")
    log(f"✓ {target}")
    return target


def sync(spec_path: Path, vo_dir: Path) -> None:
    """Set scene durations from per-scene TTS output (tts.py --per-scene writes timing.json)."""
    spec = read_json(spec_path)
    timing = read_json(vo_dir / "timing.json")
    if not timing:
        raise SystemExit(f"{vo_dir}/timing.json not found — run tts.py with a scene spec first")
    for sc, tm in zip(spec["scenes"], timing["scenes"]):
        sc["duration"] = round(max(float(sc.get("min_duration", 2.0)), tm["duration"] + float(sc.get("tail", 0.5))), 2)
    write_json(spec_path, spec)
    log(f"✓ durations synced from narration → total {sum(s['duration'] for s in spec['scenes']):.1f}s")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("spec")
    b.add_argument("out")
    r = sub.add_parser("render")
    r.add_argument("project")
    r.add_argument("--draft", action="store_true")
    r.add_argument("--alpha", action="store_true")
    r.add_argument("-o", "--out")
    s = sub.add_parser("sync")
    s.add_argument("spec")
    s.add_argument("--vo", required=True)
    sub.add_parser("example")
    a = ap.parse_args()
    if a.cmd == "build":
        sp = Path(a.spec).resolve()
        build(read_json(sp), Path(a.out).resolve(), sp.parent)
    elif a.cmd == "render":
        render(Path(a.project).resolve(), a.draft, a.alpha, Path(a.out) if a.out else None)
    elif a.cmd == "sync":
        sync(Path(a.spec), Path(a.vo))
    else:
        print(json.dumps(EXAMPLE, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
