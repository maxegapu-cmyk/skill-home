"""Shared helpers for video-studio scripts.

Everything here is dependency-light (stdlib + numpy + Pillow) so every script
can import it. Heavy/optional deps (faster-whisper, funasr, cv2, edge-tts) are
imported lazily inside the scripts that need them.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any

# Windows consoles default to GBK/cp1252: force UTF-8 so ✓/中文 output never crashes a script.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

SKILL_DIR = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = SKILL_DIR / "scripts"

MEDIA_EXT = {".mp4", ".mov", ".mkv", ".m4v", ".avi", ".webm", ".flv", ".ts", ".mts",
             ".m2ts", ".mxf", ".wmv", ".3gp"}
AUDIO_EXT = {".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus"}

# --------------------------------------------------------------------------- io


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def die(msg: str, code: int = 1) -> None:
    log(f"✗ {msg}")
    sys.exit(code)


def run(cmd: list[Any], quiet: bool = True, check: bool = True,
        capture: bool = False, input_bytes: bytes | None = None) -> subprocess.CompletedProcess:
    cmd = [str(c) for c in cmd]
    if not quiet:
        log("  $ " + " ".join(cmd[:8]) + (" …" if len(cmd) > 8 else ""))
    res = subprocess.run(cmd, input=input_bytes,
                         stdout=subprocess.PIPE if (capture or quiet) else None,
                         stderr=subprocess.PIPE if (capture or quiet) else None)
    if check and res.returncode != 0:
        err = (res.stderr or b"").decode("utf-8", "replace")[-3000:]
        raise RuntimeError(f"command failed ({res.returncode}): {' '.join(cmd[:10])}\n{err}")
    return res


def read_json(p: Path | str, default: Any = None) -> Any:
    p = Path(p)
    if not p.exists():
        return default
    return json.loads(p.read_text(encoding="utf-8"))


def write_json(p: Path | str, data: Any) -> None:
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def fmt_t(t: float) -> str:
    """Seconds → H:MM:SS.ss / M:SS.ss."""
    t = max(0.0, float(t))
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    if h >= 1:
        return f"{int(h)}:{int(m):02d}:{s:05.2f}"
    return f"{int(m)}:{s:05.2f}"


def parse_t(v: Any) -> float:
    """Accept 12.5, "12.5", "1:02.3", "1:02:03.5"."""
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if ":" not in s:
        return float(s)
    parts = [float(x) for x in s.split(":")]
    t = 0.0
    for p in parts:
        t = t * 60 + p
    return t


# ---------------------------------------------------------------------- edit dir


def find_edit_dir(start: Path | str | None = None) -> Path:
    """The working dir is <videos_dir>/edit. Accept either the videos dir or edit dir."""
    p = Path(start or os.getcwd()).resolve()
    if p.name == "edit" and p.is_dir():
        return p
    if (p / "edit").is_dir():
        return p / "edit"
    return p / "edit"


def edit_subdir(edit_dir: Path, name: str) -> Path:
    d = edit_dir / name
    d.mkdir(parents=True, exist_ok=True)
    return d


# ------------------------------------------------------------------------ probe


def has_bin(name: str) -> bool:
    return shutil.which(name) is not None


def ffprobe_json(path: Path | str) -> dict:
    res = run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format",
               "-show_streams", path], capture=True)
    return json.loads(res.stdout.decode("utf-8", "replace") or "{}")


def parse_rate(v: str | None) -> float:
    if not v or v in ("0/0", "N/A"):
        return 0.0
    try:
        return float(Fraction(v))
    except Exception:
        return 0.0


def probe(path: Path | str) -> dict:
    """Normalized media info. Width/height are DISPLAY dims (rotation applied)."""
    j = ffprobe_json(path)
    fmt = j.get("format", {})
    info: dict[str, Any] = {
        "path": str(Path(path).resolve()),
        "duration": float(fmt.get("duration") or 0.0),
        "size_mb": round(int(fmt.get("size") or 0) / 1e6, 2),
        "has_video": False, "has_audio": False,
    }
    for s in j.get("streams", []):
        if s.get("codec_type") == "video" and not info["has_video"]:
            if s.get("disposition", {}).get("attached_pic"):
                continue
            w, h = int(s.get("width") or 0), int(s.get("height") or 0)
            rot = 0
            for sd in s.get("side_data_list") or []:
                if sd.get("rotation") is not None:
                    rot = int(round(float(sd["rotation"])))
            if "rotate" in (s.get("tags") or {}):
                try:
                    rot = int(s["tags"]["rotate"])
                except ValueError:
                    pass
            if abs(rot) % 180 == 90:
                w, h = h, w
            fps = parse_rate(s.get("avg_frame_rate")) or parse_rate(s.get("r_frame_rate"))
            info.update({
                "has_video": True, "width": w, "height": h, "rotation": rot,
                "fps": round(fps, 3), "vcodec": s.get("codec_name"),
                "pix_fmt": s.get("pix_fmt"),
                "hdr": s.get("color_transfer") in ("smpte2084", "arib-std-b67"),
                "vfr": abs(parse_rate(s.get("avg_frame_rate")) - parse_rate(s.get("r_frame_rate"))) > 0.5,
            })
            if not info["duration"] and s.get("duration"):
                info["duration"] = float(s["duration"])
        elif s.get("codec_type") == "audio" and not info["has_audio"]:
            info.update({
                "has_audio": True, "acodec": s.get("codec_name"),
                "sample_rate": int(s.get("sample_rate") or 0),
                "channels": int(s.get("channels") or 0),
            })
    if info["has_video"]:
        w, h = info["width"], info["height"]
        info["orientation"] = "portrait" if h > w else ("square" if h == w else "landscape")
    return info


# ------------------------------------------------------------------------ audio


def load_audio(path: Path | str, sr: int = 16000, start: float = 0.0,
               duration: float | None = None):
    """Decode mono float32 PCM via ffmpeg. Returns numpy array."""
    import numpy as np
    cmd = ["ffmpeg", "-v", "error"]
    if start > 0:
        cmd += ["-ss", f"{start:.3f}"]
    cmd += ["-i", str(path)]
    if duration is not None:
        cmd += ["-t", f"{duration:.3f}"]
    cmd += ["-vn", "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]
    res = run(cmd, capture=True)
    return np.frombuffer(res.stdout, dtype=np.float32).copy()


def rms_envelope(samples, sr: int = 16000, hop_s: float = 0.05):
    """RMS in dBFS per hop. Returns numpy array."""
    import numpy as np
    hop = max(1, int(sr * hop_s))
    n = len(samples) // hop
    if n == 0:
        return np.zeros(0, dtype=np.float32)
    x = samples[: n * hop].reshape(n, hop)
    rms = np.sqrt(np.mean(x * x, axis=1) + 1e-12)
    return (20 * np.log10(rms + 1e-9)).astype(np.float32)


# ------------------------------------------------------------------------ fonts

_CJK_FONT_CANDIDATES = [
    # macOS
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
    # Windows
    "C:/Windows/Fonts/msyhbd.ttc", "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/Deng.ttf",
    # Linux (Noto / Source Han / WenQuanYi)
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/noto-cjk/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/google-noto-cjk/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    "/usr/share/fonts/wqy-zenhei/wqy-zenhei.ttc",
]

# Family names libass/fontconfig will resolve for the files above.
_FAMILY_FOR = {
    "PingFang": "PingFang SC", "Hiragino Sans GB": "Hiragino Sans GB",
    "STHeiti": "Heiti SC", "Arial Unicode": "Arial Unicode MS",
    "msyh": "Microsoft YaHei", "simhei": "SimHei", "Deng": "DengXian",
    "NotoSansCJK": "Noto Sans CJK SC", "wqy-zenhei": "WenQuanYi Zen Hei",
}


def find_cjk_font(prefer: str | None = None) -> tuple[str | None, str]:
    """Return (font_file, family_name). prefer may be a file path or family."""
    env = prefer or os.environ.get("VS_FONT")
    if env and Path(env).exists():
        fam = Path(env).stem
        for k, v in _FAMILY_FOR.items():
            if k.lower() in Path(env).name.lower():
                fam = v
        return env, fam
    brand_font = None
    for cand in _CJK_FONT_CANDIDATES:
        if Path(cand).exists():
            brand_font = cand
            break
    if brand_font is None and has_bin("fc-list"):
        try:
            out = run(["fc-list", ":lang=zh", "file", "family"], capture=True).stdout.decode()
            for line in out.splitlines():
                f = line.split(":")[0].strip()
                if f and Path(f).exists():
                    fam = line.split(":")[1].split(",")[0].strip() if ":" in line else Path(f).stem
                    return f, fam
        except Exception:
            pass
    if brand_font is None:
        return None, env or "Sans"
    fam = "Sans"
    for k, v in _FAMILY_FOR.items():
        if k.lower() in Path(brand_font).name.lower():
            fam = v
            break
    if env and not Path(env).exists():
        fam = env  # user gave a family name
    return brand_font, fam


_BOLD_CACHE: dict = {}


def bold_face_index(path: str, weight: str = "bold") -> int:
    """Find a bold (or regular) Simplified-Chinese face inside a .ttc collection."""
    key = (path, weight)
    if key in _BOLD_CACHE:
        return _BOLD_CACHE[key]
    from PIL import ImageFont
    want = ("Heavy", "Black", "Bold", "Semibold", "Medium") if weight == "bold" else ("Regular", "Medium")
    best, best_rank, first_sc = 0, 99, None
    for i in range(24):
        try:
            fam, style = ImageFont.truetype(path, size=12, index=i).getname()
        except Exception:
            break
        sc_ok = ("SC" in fam) or ("GB" in fam) or ("YaHei" in fam) or not any(x in fam for x in ("TC", "HK", "JP", "KR"))
        if sc_ok and first_sc is None:
            first_sc = i
        for rank, w in enumerate(want):
            if w.lower() == (style or "").lower() and sc_ok and rank < best_rank:
                best, best_rank = i, rank
    if best_rank == 99 and first_sc is not None:
        best = first_sc
    _BOLD_CACHE[key] = best
    return best


def pil_font(size: int, path: str | None = None, index: int | None = None, weight: str = "regular"):
    from PIL import ImageFont
    fpath = path or find_cjk_font()[0]
    if fpath is None:
        return ImageFont.load_default()
    if index is None:
        index = bold_face_index(fpath, weight) if fpath.lower().endswith((".ttc", ".otc")) else 0
    try:
        return ImageFont.truetype(fpath, size=size, index=index)
    except Exception:
        return ImageFont.truetype(fpath, size=size)


# ------------------------------------------------------------------------- text

CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]")
PUNCT = set("，。！？、；：,.!?;:…—～~·「」『』“”\"'()（）《》<>[]【】")
SENT_END = set("。！？!?…")


def is_cjk(s: str) -> bool:
    return bool(CJK_RE.search(s or ""))


def text_units(s: str) -> int:
    """Display length: CJK char = 1, latin char = 0.55."""
    n = 0.0
    for ch in s:
        n += 1.0 if CJK_RE.match(ch) else (0.0 if ch.isspace() else 0.55)
    return int(round(n))


def join_tokens(tokens: list[str]) -> str:
    """Join ASR tokens: no spaces between CJK, single spaces between latin words."""
    out = ""
    for t in tokens:
        t = t.strip()
        if not t:
            continue
        if out and not is_cjk(out[-1]) and not is_cjk(t[0]) and t[0] not in PUNCT:
            out += " "
        out += t
    return out


# Unambiguous fillers. Ambiguous ones (那个/就是/然后/like/so) are left to the LLM.
FILLERS_ZH = {"嗯", "啊", "呃", "额", "唔", "嗯嗯", "啊啊", "呃呃", "哎", "诶", "欸", "emm", "em", "嗯哼"}
FILLERS_EN = {"um", "uh", "er", "erm", "ah", "hmm", "mm", "uhm", "umm", "uhh"}


def is_filler(tok: str) -> bool:
    t = tok.strip().strip("".join(PUNCT)).lower()
    return t in FILLERS_ZH or t in FILLERS_EN


# ------------------------------------------------------------------- transcripts


def load_transcript(edit_dir: Path, src_id: str) -> dict | None:
    return read_json(edit_dir / "transcripts" / f"{src_id}.json")


def load_sources(edit_dir: Path) -> dict:
    return read_json(edit_dir / "sources.json", {}) or {}


def source_path(edit_dir: Path, src_id: str, edl: dict | None = None) -> Path:
    if edl and src_id in (edl.get("sources") or {}):
        p = Path(edl["sources"][src_id])
        if not p.is_absolute():
            for base in (edit_dir, edit_dir.parent):
                if (base / p).exists():
                    return (base / p).resolve()
        return p
    srcs = load_sources(edit_dir)
    if src_id in srcs:
        return Path(srcs[src_id]["path"])
    raise KeyError(f"unknown source id {src_id}")


def os_name() -> str:
    s = platform.system().lower()
    return {"darwin": "mac", "windows": "windows"}.get(s, "linux")
