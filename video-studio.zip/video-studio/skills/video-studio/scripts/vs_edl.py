"""EDL model: loading, path resolution, validation and the output timeline.

The output timeline is computed in ONE place (build_timeline) and used by the
renderer, the caption builder and QC, so captions can never drift from picture.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import load_sources, parse_t, probe, read_json  # noqa: E402

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}

ASPECTS = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "3:4": (1080, 1440),
           "4:5": (1080, 1350), "4:3": (1440, 1080), "21:9": (2560, 1080)}


class EDLError(ValueError):
    pass


def load_edl(path: Path | str) -> tuple[dict, Path, Path]:
    """Returns (edl, edl_path, edit_dir)."""
    p = Path(path).resolve()
    edl = read_json(p)
    if edl is None:
        raise EDLError(f"EDL not found: {p}")
    edit = p.parent
    while edit.name != "edit" and edit.parent != edit:
        if (edit / "sources.json").exists():
            break
        edit = edit.parent
    if edit.parent == edit:
        edit = p.parent
    return edl, p, edit


def resolve(path: str, edl_path: Path, edit: Path) -> Path:
    q = Path(path).expanduser()
    if q.is_absolute():
        return q
    for base in (edl_path.parent, edit, edit.parent, Path.cwd()):
        if (base / q).exists():
            return (base / q).resolve()
    return (edl_path.parent / q).resolve()


def source_map(edl: dict, edl_path: Path, edit: Path) -> dict[str, Path]:
    out: dict[str, Path] = {}
    ingested = load_sources(edit)
    for k, v in (edl.get("sources") or {}).items():
        out[k] = resolve(v, edl_path, edit)
    for r in edl.get("ranges", []):
        sid = r.get("source")
        if sid and sid not in out:
            if sid in ingested:
                out[sid] = Path(ingested[sid]["path"])
            else:
                cand = resolve(sid, edl_path, edit)
                if cand.exists():
                    out[sid] = cand
    return out


def output_spec(edl: dict, variant: dict | None, first_info: dict | None) -> dict:
    o = dict(edl.get("output") or {})
    if variant:
        o.update({k: v for k, v in variant.items() if k not in ("captions", "overlays")})
    if "aspect" in o and ("width" not in o or "height" not in o):
        o["width"], o["height"] = ASPECTS[o["aspect"]]
    if "width" not in o or "height" not in o:
        w, h = (first_info or {}).get("width", 1920), (first_info or {}).get("height", 1080)
        long_side = max(w, h)
        if long_side > 1920:
            k = 1920 / long_side
            w, h = int(round(w * k / 2) * 2), int(round(h * k / 2) * 2)
        o["width"], o["height"] = w, h
    o["width"], o["height"] = int(o["width"]) // 2 * 2, int(o["height"]) // 2 * 2
    if "fps" not in o:
        fps = (first_info or {}).get("fps") or 30
        o["fps"] = 30 if fps > 31 and not o.get("keep_hfr") else (25 if 24.5 < fps < 25.5 else round(fps, 3) or 30)
    o.setdefault("reframe", "auto")
    o.setdefault("name", (variant or {}).get("name") or edl.get("name") or "final")
    return o


def range_duration(r: dict, src_dur: float | None = None) -> float:
    if "duration" in r and "start" not in r:
        d = parse_t(r["duration"])
    else:
        d = parse_t(r["end"]) - parse_t(r["start"])
    return d / float(r.get("speed", 1.0))


def build_timeline(edl: dict, fps: float | None = None) -> list[dict]:
    """Per range: output start/end, accounting for speed and transitions (overlap).

    Durations are quantized to whole output frames — exactly what render.py encodes — so caption
    times computed from this timeline match the concatenated video even after 100+ cuts."""
    fps = float(fps or (edl.get("output") or {}).get("fps") or 30)
    tl = []
    t = 0.0
    default_tr = edl.get("transition")
    for i, r in enumerate(edl.get("ranges", [])):
        d = max(1, round(range_duration(r) * fps)) / fps
        tr = r.get("transition_in", default_tr if i > 0 else None)
        td = float((tr or {}).get("duration", 0.0)) if tr and i > 0 else 0.0
        td = min(td, d / 2, (tl[-1]["dur"] / 2) if tl else 0)
        start = t - td
        tl.append({"i": i, "out_start": round(start, 4), "out_end": round(start + d, 4), "dur": d,
                   "src_start": parse_t(r.get("start", 0)), "src_end": parse_t(r.get("end", d)),
                   "speed": float(r.get("speed", 1.0)), "transition": tr if td > 0 else None,
                   "td": td, "source": r.get("source")})
        t = start + d
    return tl


def total_duration(edl: dict, fps: float | None = None) -> float:
    tl = build_timeline(edl, fps)
    return tl[-1]["out_end"] if tl else 0.0


def validate(edl: dict, edl_path: Path, edit: Path) -> list[str]:
    errs: list[str] = []
    srcmap = source_map(edl, edl_path, edit)
    probes: dict[str, dict] = {}
    if not edl.get("ranges"):
        errs.append("EDL has no ranges")
    for i, r in enumerate(edl.get("ranges", [])):
        sid = r.get("source")
        if not sid:
            errs.append(f"range {i}: missing source")
            continue
        if sid not in srcmap or not srcmap[sid].exists():
            errs.append(f"range {i}: source '{sid}' not found")
            continue
        p = srcmap[sid]
        if p.suffix.lower() in IMAGE_EXT:
            if "duration" not in r and "end" not in r:
                errs.append(f"range {i}: image source needs 'duration'")
            continue
        if sid not in probes:
            probes[sid] = probe(p)
        dur = probes[sid]["duration"]
        s, e = parse_t(r.get("start", 0)), parse_t(r.get("end", 0))
        if e <= s:
            errs.append(f"range {i}: end ({e}) <= start ({s})")
        if s < 0 or e > dur + 0.05:
            errs.append(f"range {i}: {s:.2f}-{e:.2f} outside source duration {dur:.2f}")
        if not (0.25 <= float(r.get("speed", 1)) <= 4):
            errs.append(f"range {i}: speed must be 0.25–4")
    for j, ov in enumerate(edl.get("overlays", [])):
        if not resolve(ov["file"], edl_path, edit).exists():
            errs.append(f"overlay {j}: file not found {ov['file']}")
    aud = edl.get("audio") or {}
    for key in ("bgm", "voiceover"):
        if aud.get(key) and not resolve(aud[key]["file"], edl_path, edit).exists():
            errs.append(f"audio.{key}: file not found")
    for j, s in enumerate(aud.get("sfx", [])):
        if not resolve(s["file"], edl_path, edit).exists():
            errs.append(f"audio.sfx {j}: file not found {s['file']}")
    return errs


def apply_variant_overrides(base: Any, override: Any) -> Any:
    if isinstance(base, dict) and isinstance(override, dict):
        out = dict(base)
        for k, v in override.items():
            out[k] = apply_variant_overrides(base.get(k), v) if k in base else v
        return out
    return override if override is not None else base
