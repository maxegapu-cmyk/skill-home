#!/usr/bin/env python3
"""Delivery: covers (封面) and platform-ready exports.

  python deliver.py cover edit/out/final.mp4 --title "首付1.9万\\n开回家" [--sub "限时福利"]
         [--highlight 1.9万] [--sizes 3:4,9:16,16:9] [--at 12.5]
      → picks the best frame (sharp, face, well exposed, eyes-open-ish) unless --at is given,
        writes edit/deliver/cover_<size>.jpg + cover_candidates.png (top 6 for you to choose)
  python deliver.py export edit/out/final.mp4 --platforms douyin,xiaohongshu,bilibili
      → platform-tuned encodes + a spec check table
  python deliver.py specs     # print platform specs

Platform notes live in references/platforms.md.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from io import BytesIO
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from vs_common import fmt_t, log, pil_font, probe, read_json  # noqa: E402

PLATFORMS = {
    # name: (W, H, fps_max, maxrate, note)
    "douyin":      (1080, 1920, 60, "16M", "抖音: 9:16, ≥720p, 字幕避开底部25%与右侧按钮区"),
    "shipinhao":   (1080, 1920, 60, "12M", "视频号: 9:16 或 横屏, 封面 3:4 裁切显示"),
    "xiaohongshu": (1080, 1440, 60, "12M", "小红书: 3:4 最佳 (也支持 9:16), 封面决定点击率"),
    "kuaishou":    (1080, 1920, 60, "12M", "快手: 9:16"),
    "bilibili":    (1920, 1080, 60, "20M", "B站: 16:9 1080p60 高码率, 封面 16:10/16:9"),
    "youtube":     (1920, 1080, 60, "24M", "YouTube: 16:9; Shorts 用 9:16 ≤ 60s"),
    "shorts":      (1080, 1920, 60, "16M", "YouTube Shorts: 9:16, ≤ 60s"),
    "wechat":      (1080, 1920, 30, "8M", "微信群/朋友圈分享: 文件小, 30fps"),
}
COVER_SIZES = {"3:4": (1080, 1440), "9:16": (1080, 1920), "16:9": (1920, 1080), "4:3": (1440, 1080),
               "1:1": (1080, 1080), "16:10": (1920, 1200)}


def grab(path: str, t: float, h: int | None = None) -> Image.Image | None:
    vf = ["-vf", f"scale=-2:{h}"] if h else []
    res = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", path, "-frames:v", "1", *vf,
                          "-f", "image2pipe", "-vcodec", "png", "-"], stdout=subprocess.PIPE)
    return Image.open(BytesIO(res.stdout)).convert("RGB") if res.stdout else None


def score_frame(im: Image.Image) -> tuple[float, dict]:
    g = np.asarray(im.convert("L").resize((480, int(480 * im.height / im.width))), dtype=np.float32)
    lap = (g[1:-1, 2:] + g[1:-1, :-2] + g[2:, 1:-1] + g[:-2, 1:-1] - 4 * g[1:-1, 1:-1])
    sharp = float(lap.var())
    mean = float(g.mean())
    expo = 1 - abs(mean - 120) / 120
    faces = 0
    try:
        from vs_faces import detect
        faces = len(detect(g.astype(np.uint8)))
    except Exception:
        pass
    s = np.log1p(sharp) * 1.0 + expo * 2.0 + (1.5 if faces else 0) - (2 if mean < 25 else 0)
    return float(s), {"sharp": round(sharp, 1), "mean": round(mean, 1), "faces": faces}


def cover_from(frame: Image.Image, size: tuple[int, int], title: str, sub: str | None, highlight: list[str],
               accent: str, band: str | None) -> Image.Image:
    W, H = size
    # cover-crop the frame (bias upward to keep faces)
    k = max(W / frame.width, H / frame.height)
    im = frame.resize((int(frame.width * k + 0.5), int(frame.height * k + 0.5)), Image.LANCZOS)
    x0 = (im.width - W) // 2
    y0 = int((im.height - H) * 0.35)
    im = im.crop((x0, y0, x0 + W, y0 + H)).convert("RGBA")
    # bottom gradient for legibility
    grad = Image.new("L", (1, H))
    for y in range(H):
        grad.putpixel((0, y), int(max(0, (y / H - 0.45) / 0.55) ** 1.4 * 210))
    shade = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    shade.putalpha(grad.resize((W, H)))
    im.alpha_composite(shade)
    d = ImageDraw.Draw(im)
    lines = title.replace("\\n", "\n").split("\n")
    s = min(W, H)
    size_px = int(s * (0.13 if H > W else 0.11))
    longest = max(len(l) for l in lines) or 1
    size_px = min(size_px, int(W * 0.88 / longest))
    f = pil_font(size_px, weight="bold")
    lh = int(size_px * 1.18)
    total = lh * len(lines)
    y = int(H * (0.62 if H > W else 0.56)) - total // 2
    for line in lines:
        x = (W - d.textlength(line, font=f)) / 2
        # draw piecewise so highlighted words get the accent color
        segs, rest = [], line
        while rest:
            hit = min(((rest.find(h), h) for h in highlight if h and rest.find(h) >= 0), default=(-1, ""))
            if hit[0] < 0:
                segs.append((rest, "#FFFFFF"))
                break
            if hit[0] > 0:
                segs.append((rest[:hit[0]], "#FFFFFF"))
            segs.append((hit[1], accent))
            rest = rest[hit[0] + len(hit[1]):]
        if band:
            bw = d.textlength(line, font=f)
            d.rounded_rectangle([x - size_px * 0.25, y - size_px * 0.1, x + bw + size_px * 0.25, y + lh - size_px * 0.05],
                                radius=int(size_px * 0.18), fill=band)
        for txt, col in segs:
            d.text((x, y), txt, font=f, fill=col, stroke_width=max(3, size_px // 14), stroke_fill="#000000")
            x += d.textlength(txt, font=f)
        y += lh
    if sub:
        fs = pil_font(int(size_px * 0.42), weight="bold")
        tw = d.textlength(sub, font=fs)
        py = y + int(size_px * 0.25)
        pad = int(size_px * 0.22)
        d.rounded_rectangle([(W - tw) / 2 - pad, py - pad * 0.5, (W + tw) / 2 + pad, py + size_px * 0.42 + pad * 0.9],
                            radius=pad, fill=accent)
        d.text(((W - tw) / 2, py), sub, font=fs, fill="#111111")
    return im.convert("RGB")


def clean_source_frame(vp: Path, t: float) -> Image.Image | None:
    """Map an output time back to the untouched source frame (no burned captions/titles)."""
    meta = read_json(vp.with_suffix(".render.json")) or {}
    if not meta.get("timeline") or not meta.get("edl"):
        return None
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from vs_edl import load_edl, source_map
        edl, ep, edit = load_edl(meta["edl"])
        srcmap = source_map(edl, ep, edit)
    except Exception:
        return None
    for seg in meta["timeline"]:
        if seg["out_start"] <= t < seg["out_end"]:
            src = srcmap.get(seg["source"])
            if src is None:
                return None
            return grab(str(src), seg["src_start"] + (t - seg["out_start"]) * seg.get("speed", 1.0))
    return None


def cmd_cover(a) -> None:
    vp = Path(a.video).resolve()
    info = probe(vp)
    outdir = Path(a.outdir) if a.outdir else (vp.parent.parent / "deliver" if vp.parent.name == "out" else vp.parent)
    outdir.mkdir(parents=True, exist_ok=True)
    D = info["duration"]
    if a.at is not None:
        best_t = float(a.at)
        cands = []
    else:
        ts = [D * (i + 0.5) / a.samples for i in range(a.samples)]
        cands = []
        for t in ts:
            im = grab(str(vp), t, 540)
            if im is None:
                continue
            sc, m = score_frame(im)
            cands.append((sc, t, m))
        cands.sort(reverse=True)
        best_t = cands[0][1]
        thumbs = [grab(str(vp), t, 300) for _s, t, _m in cands[:6]]
        tw = thumbs[0].width
        sheet = Image.new("RGB", (6 * (tw + 8) + 8, 340), (18, 18, 20))
        dr = ImageDraw.Draw(sheet)
        for k, (im, (_s, t, m)) in enumerate(zip(thumbs, cands[:6])):
            sheet.paste(im, (8 + k * (tw + 8), 32))
            dr.text((8 + k * (tw + 8), 6), f"#{k + 1} {fmt_t(t)} f{m['faces']}", font=pil_font(18), fill=(230, 230, 230))
        sheet.save(outdir / "cover_candidates.png")
        log(f"best frame @ {fmt_t(cands[0][1])}  (candidates sheet: {outdir / 'cover_candidates.png'})")
    best = (None if a.burned else clean_source_frame(vp, best_t)) or grab(str(vp), best_t)
    brand = {}
    for parent in [vp.parent, *vp.parents]:
        if (parent / "brand.json").exists():
            brand = read_json(parent / "brand.json") or {}
            break
    accent = a.accent or (brand.get("theme") or {}).get("accent", "#FFD400")
    hl = [h for h in (a.highlight or "").split(",") if h]
    for sz in a.sizes.split(","):
        W, H = COVER_SIZES[sz]
        im = cover_from(best, (W, H), a.title, a.sub, hl, accent, a.band)
        p = outdir / f"cover_{sz.replace(':', 'x')}.jpg"
        im.save(p, quality=92)
        print(p)


def cmd_export(a) -> None:
    vp = Path(a.video).resolve()
    info = probe(vp)
    outdir = Path(a.outdir) if a.outdir else (vp.parent.parent / "deliver" if vp.parent.name == "out" else vp.parent)
    outdir.mkdir(parents=True, exist_ok=True)
    for name in a.platforms.split(","):
        W, H, fmax, maxrate, note = PLATFORMS[name]
        iw, ih = info["width"], info["height"]
        if (iw > ih) != (W > H) and iw != ih:
            log(f"  ⚠ {name}: source is {'landscape' if iw > ih else 'portrait'} — render the matching variant "
                f"instead of letterboxing. Skipping.")
            continue
        fps = min(fmax, round(info.get("fps") or 30))
        scale = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2"
        out = outdir / f"{vp.stem}_{name}.mp4"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(vp), "-vf", f"{scale},fps={fps},format=yuv420p",
                        "-c:v", "libx264", "-profile:v", "high", "-preset", "slow", "-crf", "18", "-maxrate", maxrate,
                        "-bufsize", str(int(maxrate[:-1]) * 2) + "M", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                        "-movflags", "+faststart", str(out)], check=True)
        o = probe(out)
        print(f"{name:<12} {o['width']}x{o['height']} {o['fps']}fps {fmt_t(o['duration'])} {o['size_mb']}MB  · {note}")
        if name in ("shorts",) and o["duration"] > 60:
            log("  ⚠ Shorts must be ≤ 60 s")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("cover")
    c.add_argument("video")
    c.add_argument("--title", required=True)
    c.add_argument("--sub")
    c.add_argument("--highlight")
    c.add_argument("--accent")
    c.add_argument("--band", help="hex color for a solid band behind title lines")
    c.add_argument("--sizes", default="3:4,9:16")
    c.add_argument("--at", type=float)
    c.add_argument("--samples", type=int, default=24)
    c.add_argument("--burned", action="store_true", help="use the rendered frame (with captions) instead of the clean source")
    c.add_argument("--outdir")
    e = sub.add_parser("export")
    e.add_argument("video")
    e.add_argument("--platforms", default="douyin")
    e.add_argument("--outdir")
    sub.add_parser("specs")
    a = ap.parse_args()
    if a.cmd == "cover":
        cmd_cover(a)
    elif a.cmd == "export":
        cmd_export(a)
    else:
        for k, v in PLATFORMS.items():
            print(f"{k:<12} {v[0]}x{v[1]} ≤{v[2]}fps maxrate {v[3]}  {v[4]}")


if __name__ == "__main__":
    main()

_ = ImageFilter  # noqa
