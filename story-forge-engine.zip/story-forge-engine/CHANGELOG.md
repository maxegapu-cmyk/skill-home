# Changelog

## 1.1.0

- 新增 references/drama-engine.md：创作合同、期待管理、合法加压、两难选择、铺垫与兑现、类型速查、节奏与钩子、戏剧自检。
- 新增 assets/output-formats.md：分支对比、章纲行、隐藏真相判断、审计条目、续写接力包。
- SKILL.md：接入创作合同与戏剧加压步骤，新增"守规不等于平淡"规则与接力包交付。
- 作品导出：专属 Skill 需带入创作合同、戏剧做法与接力包格式。
- evals：新增 drama-under-constraint、genre-payoff、relay-handoff、pure-prose 四条试题及一个加压示范。

## 1.0.0

- 初版：证据分级故事圣经、因果推演、场景落地、连续性检查与采用式更新、作品专属 Skill 导出。
