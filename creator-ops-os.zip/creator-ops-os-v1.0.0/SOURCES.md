# Public references used for design research

This Skill was written from scratch. The following public projects were reviewed for capabilities and failure modes; their code and prompt text are not bundled.

1. Xiangyu-CAS/xiaohongshu-ops-skill
   - Useful idea: end-to-end Xiaohongshu flow covering positioning, topic research, content production, publishing handoff and review; also emphasizes stopping before irreversible publish by default.
   - https://github.com/Xiangyu-CAS/xiaohongshu-ops-skill

2. millennialdreamer/prism
   - Useful idea: one normalized cross-platform analysis schema for Xiaohongshu/Douyin/Bilibili/Kuaishou, plus deeper engagement signals rather than likes-only ranking.
   - https://github.com/millennialdreamer/prism

3. zinan92/content-intelligence (archived in 2026)
   - Useful idea: ingest -> trend detection -> viral attribution -> pattern recognition -> topic recommendation pipeline.
   - https://github.com/zinan92/content-intelligence

4. orangexie05/creator-platform-data
   - Useful idea: creator-center data collection for Douyin/Xiaohongshu and unified output fields for owned-account analytics.
   - https://github.com/orangexie05/creator-platform-data

5. langchain-ai/social-media-agent
   - Useful idea: source/curate/generate/repurpose with explicit human-in-the-loop around posting.
   - https://github.com/langchain-ai/social-media-agent

6. kushalsamani/social-media-ai-agent
   - Useful idea: separated market research, strategy, calendar and content deliverables using structured outputs.
   - https://github.com/kushalsamani/social-media-ai-agent

7. mf-yang/douyin-creator
   - Useful idea: Douyin creator-center operations and analytics as one creator workflow.
   - https://github.com/mf-yang/douyin-creator

8. sylviaooo2026/douyin-analytics-tool
   - Useful idea: owned analytics + comment intelligence + local offline reports, with explicit limitation to data accessible in the current authorized session.
   - https://github.com/sylviaooo2026/douyin-analytics-tool

9. NanmiCoder/MediaCrawler
   - Capability reference only. The repository currently states a non-commercial learning license and instructs users to respect platform terms/robots and avoid large-scale crawling. It is therefore NOT bundled or required by this Skill.
   - https://github.com/NanmiCoder/MediaCrawler

## Original design decisions in Creator Ops OS

- Evidence hierarchy that prefers owned/authorized sources before public scraping.
- Unified content decision loop across research, production and postmortem.
- Platform-native Content Contract instead of one-copy-many-platforms rewriting.
- Explicit distinction between observed metrics, likely explanations, alternatives and next tests.
- Topic score as a prioritization aid, never a virality probability.
- Data-source confidence and sample-bias handling built into the workflow.
- Publishing approval gate and no hidden irreversible actions.
