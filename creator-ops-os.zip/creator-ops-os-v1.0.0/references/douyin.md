# Douyin operating route

## What to research
Collect examples by audience problem and format, not only hashtag.
Look for:
- first 1-3 seconds: visual + verbal promise
- how quickly proof appears
- information/reveal cadence
- scene or framing changes that serve comprehension
- repeatable comments/questions
- ending payoff and series bridge

## Native script contract
Default short-video package:

| Time | Spoken/VO | Visual action | On-screen text | Function |
|---|---|---|---|---|
| 0-3s | hook | strongest visual proof/tension | minimal | stop scroll |
| 3-10s | establish stakes | concrete example | key phrase | validate promise |
| middle | progressive beats | proof/B-roll/demo | only useful text | retention + value |
| ending | payoff | final proof/state change | takeaway | close loop |
| CTA | natural next step | optional | optional | follow/comment/series |

Do not add random pattern interrupts every few seconds. A visual change must improve clarity, emotion, proof, or progression.

## Owned metrics
Use available creator-center metrics and account-relative baselines. Depending on the export, useful groups can include:
- distribution/reach
- early hold / early completion
- average watch / completion
- interactions and shares
- profile visits/follows
- conversions if relevant

Metric names change; preserve source labels and map them to semantic groups.

## Diagnosis hypotheses
- good initial distribution + immediate retention weakness -> test hook expectation vs actual opening;
- decent early hold + later cliff -> inspect the exact beat before the drop;
- strong watch + weak engagement -> test whether the content closes too completely or lacks identity/social value;
- strong engagement + weak follows -> test account promise and next-video bridge.
