# Xiaohongshu operating route

## What to research
Prioritize four signal families:
1. Search intent: what users are actively trying to solve or decide.
2. Save intent: information worth returning to.
3. Identity resonance: "this is me / this is my situation" signals in comments.
4. Proof trust: screenshots, comparisons, process evidence, before/after, concrete experience.

Sample both high performers and ordinary notes. A high-like post with low saves/comments may serve a different job than a lower-reach but high-save note.

## Topic opportunity tests
A useful XHS opportunity normally has at least two of:
- repeated question in comments/search wording;
- obvious sameness in current results;
- a missing comparison/checklist/process;
- creator has first-hand proof or a defensible viewpoint;
- content can be packaged into a save-worthy artifact.

## Native output
For each finished note produce:
- search-intent phrase
- title set: direct utility / tension / identity angle
- cover: one visual hierarchy, not a paragraph
- opening: state why this matters now
- body: progressive information, not padded sections
- proof block
- optional carousel page plan
- tags/keywords where useful
- pinned comment that adds value, not engagement bait only

## Video note
For video, also add:
- first-frame visual
- 0-3s spoken hook
- beat-by-beat shot plan
- subtitle emphasis
- ending frame and comment bridge

## Diagnosis hypotheses
When owned metrics exist:
- reach okay + weak open/click -> test cover/title/query fit;
- open/click okay + shallow consumption -> test promise/content mismatch or slow payoff;
- consumption okay + weak save/share -> test usefulness/novelty/proof density;
- strong deep engagement + weak follows -> test account positioning/series bridge.
These are hypotheses, not guaranteed causes.
