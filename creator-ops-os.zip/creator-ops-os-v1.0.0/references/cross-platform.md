# Cross-platform adaptation

Repurposing rule: preserve the core truth/story, rebuild the consumption experience.

## Platform roles
- Xiaohongshu: searchable decision aid, lived experience, save-worthy artifact.
- Douyin: immediate audiovisual promise, progressive proof, retention-driven story/value.
- Bilibili: deeper explanation/story arc, chapterable value, community credibility.
- Kuaishou: direct human connection, practical clarity, creator trust and continuity.
- WeChat Official Account: long-form argument, context, evidence and durable reference value.
- Weibo: timely framing, conversation, stance and spreadable fragments.
- Zhihu: question-led reasoning, evidence, counterargument, durable search value.
- TikTok: audiovisual hook, fast proof, native trend grammar where relevant.
- YouTube: title/thumbnail promise + sustained value arc; Shorts route distinct from long-form.
- Instagram: visual identity, carousel/reel native composition, save/share utility.
- X: concise insight, thread logic, timely context and reply conversation.

When one asset is repurposed, explicitly rewrite:
- hook
- information order
- evidence density
- visual grammar
- CTA
- length
Do not merely trim words.
