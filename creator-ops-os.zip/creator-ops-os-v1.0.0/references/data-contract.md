# Unified data contract

Minimum normalized market record:

```json
{
  "platform": "xiaohongshu",
  "content_id": "optional",
  "url": "optional",
  "query": "espresso beginner",
  "creator": "creator name",
  "followers": 12000,
  "published_at": "2026-10-01T10:00:00+08:00",
  "collected_at": "2026-10-06T20:00:00+08:00",
  "title": "...",
  "text": "...",
  "topic": "espresso beginner",
  "views": 0,
  "impressions": 0,
  "likes": 0,
  "comments": 0,
  "shares": 0,
  "saves": 0,
  "duration_sec": null,
  "source_type": "public_search|owned_export|authorized_browser|official_api|user_file",
  "notes": ""
}
```

Rules:
- Unknown numeric values should be null/blank, not zero, unless the source explicitly says zero.
- Preserve raw source file and collection timestamp.
- Never compare metrics that mean different things without labeling the mismatch.
- For cross-platform analysis, use semantic groups (reach, open/click, consumption, deep engagement, conversion) rather than assuming identical metric definitions.
