# Performance diagnosis

## Principle
Metrics are symptoms. Diagnose the content journey stage-by-stage and compare against a relevant baseline.

## Funnel groups
1. Distribution: was it shown?
2. Open/stop: did the packaging/hook earn the next second/click?
3. Consumption: did viewers continue?
4. Deep engagement: did they save/share/comment/revisit?
5. Relationship: did they follow/profile-visit/subscribe?
6. Conversion: did the intended business/action outcome happen?

Not every platform exposes every stage.

## Baseline priority
1. Same account + same platform + same format + recent window.
2. Same account + same platform.
3. Collected cohort with explicit limitation.
4. No baseline -> no hard diagnosis; use hypotheses only.

## Report format

### OBSERVED
Only metric facts and comparisons.

### LIKELY
The smallest explanation consistent with most observations.

### ALTERNATIVES
At least one plausible competing explanation if evidence is not decisive.

### NEXT TEST
Change one major variable where possible. State success metric and decision rule before the test.

## Do not
- blame "the algorithm" without evidence;
- call one post a trend;
- average unlike formats together;
- optimize all metrics at once;
- confuse correlation with causality.
