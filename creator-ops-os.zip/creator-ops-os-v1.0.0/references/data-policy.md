# Data and action policy

- Prefer official exports, APIs, or authorized sessions.
- Respect platform terms, authentication boundaries and applicable law.
- Keep collection volume proportional to the research question.
- Do not ship credential bypass, CAPTCHA bypass or anti-bot evasion.
- Preserve source timestamps and URLs/IDs when available.
- Treat third-party collectors as optional adapters with their own licenses.
- Publishing is an external side effect: stop at ready-to-publish unless explicitly authorized.
