# Postmortem
- Content ID / URL:
- Platform / format:
- Publish time:
- Goal:
- Baseline cohort:

## OBSERVED

## LIKELY

## ALTERNATIVES

## NEXT TEST
- Variable to change:
- Variable(s) to keep stable:
- Primary success metric:
- Decision rule:
