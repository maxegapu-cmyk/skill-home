---
name: creator-ops-os
description: Cross-platform creator operations skill that turns live market evidence and owned-account metrics into topic decisions, platform-native content packages, publishing briefs, and post-publication learning loops. Strongest for Xiaohongshu and Douyin; also supports Bilibili, Kuaishou, WeChat Official Accounts, Weibo, Zhihu, TikTok, YouTube, Instagram and X.
version: 1.0.0
---

# Creator Ops OS v1.0.0

## Mission
Operate a creator account as an evidence-driven content system, not a copy generator.

Default loop:

`market evidence -> audience demand -> topic board -> platform-native concept -> production package -> preflight -> publish handoff -> performance diagnosis -> memory update`

Never invent market data. If live data cannot be fetched, explicitly switch to one of: user-provided exports, authorized account analytics, public web evidence, or hypothesis mode.

## 1. Operating modes

Choose the lightest mode that can answer the user's goal.

- `QUICK_SHOT`: 10-30 relevant market items, 3-5 candidate topics, one finished content package.
- `MARKET_SCAN`: 30-150 items across query clusters, competitor/account comparison, opportunity map and topic board.
- `ACCOUNT_OPS`: owned-account metrics + market evidence + recurring diagnosis and next-round plan.
- `CAMPAIGN`: one theme expanded into a multi-post sequence with differentiated platform roles.
- `REPURPOSE_NATIVE`: one source asset becomes distinct platform-native outputs; do not merely shorten the same copy.
- `POSTMORTEM`: diagnose a published post/video, separate observations from causal hypotheses, and produce the next experiment.

## 2. Required evidence hierarchy

Use the best available source in this order:

1. User's own creator-center exports / analytics.
2. Authorized platform session, official API, connected tool, or user-approved browser workflow.
3. Publicly accessible platform/search evidence gathered at reasonable volume.
4. Existing structured datasets supplied by the user.
5. General web/search trends as a secondary signal.
6. Hypothesis mode only when the above are unavailable.

For every market dataset keep: platform, query/source, collection time, URL or content id when available, creator/account, publish time, visible engagement metrics, and text/title/transcript excerpt.

Do not treat likes as the only success metric. Compare signals that match the platform and content goal.

## 3. Market intelligence workflow

### 3.1 Define the decision
Before collecting, state the decision in one sentence, e.g.:
- "Find three under-served Xiaohongshu angles for first-time home coffee buyers."
- "Find Douyin hooks in AI filmmaking that generate sustained discussion rather than raw views."

### 3.2 Build query clusters
Use 3-6 clusters, not one keyword:
- core demand term
- pain/problem term
- desired outcome term
- comparison/versus term
- beginner mistake term
- adjacent trend term

### 3.3 Collect a balanced sample
Avoid selecting only already-famous creators. When possible include:
- top-performing items
- recent rising items
- mid-tier creators
- low-performing examples for contrast
- comments/questions indicating unmet demand

### 3.4 Normalize
Map raw records to the schema documented in `references/data-contract.md`.
If local files are available, `scripts/normalize_market_data.py` can normalize CSV/JSON/JSONL.

### 3.5 Extract signals
For each cluster identify:
- recurring audience jobs-to-be-done
- repeated pains/questions
- emotional triggers
- proof formats that appear trusted
- content structures that repeatedly work
- saturation / sameness
- comments that ask for the missing next step
- contradictions between high views and weak deep engagement

### 3.6 Opportunity map
Create four buckets:
- `PROVEN`: demand and format both validated.
- `GAP`: demand exists but current answers are weak/samey.
- `RISING`: recent acceleration but evidence still thin.
- `TRAP`: high raw heat but poor account fit, weak conversion value, excessive competition, or policy/reputation risk.

## 4. Topic board

Every candidate topic must contain:
- audience + situation
- tension/problem
- one-sentence promise
- evidence summary
- platform fit
- differentiation angle
- production cost
- risk
- next-action goal (save/share/comment/follow/click/etc.)

Use `scripts/score_topics.py` only as a prioritization aid. The score is NOT a predicted probability of virality.

Default scoring dimensions (0-100):
- Demand evidence 25
- Momentum / recency 15
- Account fit 20
- Differentiation gap 15
- Proof availability 10
- Platform-native fit 10
- Production efficiency 5
Then apply explicit saturation/risk penalties.

Choose 1 primary topic, 1 safer backup, and 1 exploration bet when the user asks for a plan.

## 5. Content production kernel

Before writing, lock:
- target audience
- one change in the viewer's understanding/emotion/action
- platform
- format and approximate duration/length
- evidence that must survive editing
- creator voice/persona constraints
- desired next action

Then produce a `Content Contract`:
1. Core claim/story.
2. Hook promise.
3. Proof payload.
4. Retention/progression device.
5. Ending payoff.
6. CTA/interaction mechanism.
7. Visual/asset needs.
8. Claims needing verification.

Never copy a competitor's wording, visual assets, or distinctive expression. Learn the mechanism, not the surface.

## 6. Xiaohongshu native route (priority)

Read `references/xiaohongshu.md`.

Default deliverable:
- audience + search intent
- 3 title candidates (distinct mechanisms)
- cover concept + cover copy
- first-screen/opening hook
- full note body OR video script
- carousel/page plan or shot list
- proof/examples to include
- keywords/topics
- pinned-comment idea
- comment follow-up prompts
- visual brief
- risk/claim check

Optimize for usefulness, save-worthiness, identity resonance and search discoverability. Do not optimize only for outrage.

## 7. Douyin native route (priority)

Read `references/douyin.md`.

Default deliverable:
- viewer state before click
- 0-3s hook
- time-coded script / beat sheet
- visual action per beat
- on-screen text
- proof/reveal sequence
- pattern interrupts only where they serve comprehension
- ending payoff
- CTA/comment prompt
- cover title + caption + topics
- B-roll / asset list
- production constraints
- risk/claim check

When owned metrics are available, prefer retention and follow/conversion outcomes over vanity views.

## 8. Other platforms

Use `config/platform_profiles.json` and `references/cross-platform.md`.
Repurposing means changing the content contract to the platform's consumption behavior, not mechanically changing length.

## 9. Preflight gate

Before declaring content ready, check:
- evidence: important factual claims are sourced or clearly framed as opinion/hypothesis
- novelty: not a near-copy of sampled content
- platform-native structure
- audience promise is fulfilled, not clickbait-only
- opening and ending match each other
- visual production is feasible
- CTA matches account goal
- safety/platform/reputation concerns are flagged
- no fabricated numbers, testimonials, quotes, or "market data"

Output verdict: `READY`, `READY_WITH_FIXES`, or `NOT_READY`, with the minimum fixes.

## 10. Publishing handoff

By default, prepare the content and publishing checklist but do NOT perform the irreversible publish action unless the user explicitly authorizes publishing.

If publishing tools exist, preserve human approval for:
- final text/assets
- account selection
- publish time
- any paid promotion

## 11. Performance diagnosis

Read `references/performance-diagnosis.md`.

Use account-relative baselines whenever possible. Never diagnose from one absolute number alone.
Separate:
- `OBSERVED`: what the metrics actually show
- `LIKELY`: best-supported explanation
- `ALTERNATIVES`: plausible competing explanations
- `NEXT TEST`: smallest experiment that can distinguish them

Recommended checkpoints when data exists:
- early distribution / click-open stage
- consumption / retention stage
- deep engagement stage
- follow/conversion stage
- delayed search/save tail

Use `scripts/diagnose_content.py` for deterministic baseline comparisons on exported CSV/JSON data.

## 12. Learning memory

After a useful postmortem, record:
- what was tried
- exact platform/format
- evidence window
- what over/under-performed relative to account baseline
- what remains uncertain
- reusable pattern
- pattern expiry condition
- next experiment

Do not promote a pattern to a rule from one success.

## 13. Failure modes

- No live data -> switch to export/public evidence/hypothesis mode and label it.
- Small sample -> lower confidence; do not manufacture precision.
- Conflicting signals -> preserve both and explain which decision each supports.
- Missing owned baseline -> compare within the collected cohort and label limitation.
- Scraper/tool failure -> keep collected evidence, change source route, avoid repeated blind retries.
- Platform UI/metric changes -> use semantic metric groups rather than brittle hard-coded names.

## 14. Output style

For execution tasks, give the finished artifact first, then the evidence/why.
For research tasks, give the decision first, then the evidence table and confidence.
For account plans, finish with the next 3 executable actions, not generic advice.

## 15. Mandatory honesty

Never say a topic is "guaranteed viral".
Never invent a platform trend because it sounds plausible.
Never infer causality from correlation without saying it is a hypothesis.
Never claim a scraper or browser route is compliant merely because it works.
