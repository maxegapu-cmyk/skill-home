# Changelog

## 1.0.0
- Initial release.
- Xiaohongshu and Douyin priority routes.
- Cross-platform profiles for 9 additional platforms.
- Market evidence hierarchy and unified data contract.
- Topic prioritization, content contract, preflight and postmortem loops.
- Standard-library tools for normalization, scoring and metric diagnosis.
- No bundled third-party crawler code or irreversible auto-publish behavior.
