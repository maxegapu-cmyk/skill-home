# Creator Ops OS v1.0.0

An original, platform-aware social-media operations Skill focused on **market evidence -> topic choice -> finished content -> postmortem -> next experiment**.

Strongest routes: Xiaohongshu and Douyin. Additional profiles: Bilibili, Kuaishou, WeChat Official Accounts, Weibo, Zhihu, TikTok, YouTube, Instagram, X.

## Why this package exists
Most social-media agents stop at copy generation. This package treats content operations as a measurable loop:

1. collect evidence from owned analytics / authorized sources / public market samples;
2. normalize signals across platforms;
3. score and select topics without pretending to predict virality;
4. create platform-native production packages;
5. preflight factual, originality and production risks;
6. diagnose published performance relative to account baselines;
7. turn the diagnosis into the next experiment.

## Fast use
Give the agent a task such as:

- "Scan the last 30 days of Xiaohongshu content around beginner espresso, find 5 opportunity gaps, and write the best note."
- "Use my Douyin export plus current competitor samples to tell me why my recent videos stall and give me the next three scripts."
- "Take this long-form article and create genuinely native Xiaohongshu, Douyin, Bilibili and WeChat versions."

If no live-platform tool exists, provide CSV/JSON/JSONL exports. The included scripts are standard-library-only.

## Scripts

- `normalize_market_data.py`: normalize heterogeneous CSV/JSON/JSONL into a unified JSONL schema.
- `score_topics.py`: deterministic topic prioritization from explicit evidence scores.
- `diagnose_content.py`: compare owned content metrics against account/platform-format medians and emit hypotheses.
- `validate_skill.py`: package validation.

## Important
This package contains no third-party crawler code and no credential bypass. It can consume exports from external collectors, but licensing and platform terms remain the operator's responsibility.
