#!/usr/bin/env python3
from pathlib import Path
import json, sys, py_compile

ROOT=Path(__file__).resolve().parents[1]
required=[
    "SKILL.md","README.md","SOURCES.md",
    "config/platform_profiles.json","config/topic_scoring.json",
    "references/data-contract.md","references/xiaohongshu.md","references/douyin.md",
    "references/cross-platform.md","references/performance-diagnosis.md","references/data-policy.md",
    "scripts/normalize_market_data.py","scripts/score_topics.py","scripts/diagnose_content.py"
]
errors=[]
for rel in required:
    if not (ROOT/rel).exists(): errors.append(f"missing:{rel}")
for rel in ["config/platform_profiles.json","config/topic_scoring.json"]:
    try: json.loads((ROOT/rel).read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"bad-json:{rel}:{e}")
for rel in ["scripts/normalize_market_data.py","scripts/score_topics.py","scripts/diagnose_content.py"]:
    try: py_compile.compile(str(ROOT/rel), doraise=True)
    except Exception as e: errors.append(f"compile:{rel}:{e}")
text=(ROOT/"SKILL.md").read_text(encoding="utf-8")
for phrase in ["Never invent market data","NOT a predicted probability of virality","do NOT perform the irreversible publish action"]:
    if phrase not in text: errors.append(f"guardrail-missing:{phrase}")
print(json.dumps({"ok":not errors,"errors":errors,"root":str(ROOT)},ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
