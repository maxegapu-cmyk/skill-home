#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path

WEIGHTS = {
    "demand":25,"momentum":15,"account_fit":20,"differentiation":15,
    "proof":10,"platform_fit":10,"production_efficiency":5
}
PENALTIES = {"saturation":15,"risk":20}

def val(row, key):
    try: return max(0.0, min(10.0, float(row.get(key, 0))))
    except (TypeError, ValueError): return 0.0

def score(row):
    base = sum(val(row,k)/10*w for k,w in WEIGHTS.items())
    penalty = sum(val(row,k)/10*w for k,w in PENALTIES.items())
    return round(max(0, min(100, base-penalty)), 2)

def main():
    ap=argparse.ArgumentParser(description="Topic priority score, not virality probability")
    ap.add_argument("input_csv")
    ap.add_argument("output_csv")
    args=ap.parse_args()
    with open(args.input_csv, encoding="utf-8-sig", newline="") as f:
        rows=list(csv.DictReader(f))
    for r in rows: r["priority_score"] = score(r)
    rows.sort(key=lambda r: float(r["priority_score"]), reverse=True)
    fields=list(rows[0].keys()) if rows else ["topic","priority_score"]
    with open(args.output_csv,"w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(json.dumps({"ok":True,"topics":len(rows),"output":args.output_csv},ensure_ascii=False))

if __name__ == "__main__": main()
