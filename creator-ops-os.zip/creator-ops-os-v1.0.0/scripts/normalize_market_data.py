#!/usr/bin/env python3
import argparse, csv, json
from pathlib import Path
from datetime import datetime, timezone

ALIASES = {
    "platform": ["platform", "平台"],
    "content_id": ["content_id", "id", "note_id", "aweme_id", "作品id", "笔记id"],
    "url": ["url", "link", "链接"],
    "query": ["query", "keyword", "关键词"],
    "creator": ["creator", "author", "nickname", "博主", "作者"],
    "followers": ["followers", "fans", "粉丝", "粉丝数"],
    "published_at": ["published_at", "publish_time", "发布时间"],
    "title": ["title", "标题"],
    "text": ["text", "desc", "content", "正文", "文案"],
    "topic": ["topic", "cluster", "主题"],
    "views": ["views", "play_count", "播放", "观看"],
    "impressions": ["impressions", "exposure", "曝光"],
    "likes": ["likes", "like_count", "点赞"],
    "comments": ["comments", "comment_count", "评论"],
    "shares": ["shares", "share_count", "分享"],
    "saves": ["saves", "collect_count", "favorites", "收藏"],
    "duration_sec": ["duration_sec", "duration", "时长"],
    "source_type": ["source_type", "source", "来源"]
}

NUMERIC = {"followers","views","impressions","likes","comments","shares","saves","duration_sec"}

def pick(row, keys):
    low = {str(k).strip().lower(): v for k,v in row.items()}
    for key in keys:
        if key in row and row[key] not in (None, ""):
            return row[key]
        v = low.get(str(key).lower())
        if v not in (None, ""):
            return v
    return None

def num(v):
    if v in (None, ""): return None
    s = str(v).strip().replace(",", "")
    mult = 1
    if s.endswith("万"):
        mult, s = 10000, s[:-1]
    elif s.lower().endswith("k"):
        mult, s = 1000, s[:-1]
    try:
        return float(s) * mult
    except ValueError:
        return None

def normalize(row, platform_default=None, source_type_default="user_file"):
    out = {}
    for field, aliases in ALIASES.items():
        v = pick(row, aliases)
        out[field] = num(v) if field in NUMERIC else v
    out["platform"] = out["platform"] or platform_default or "unknown"
    out["source_type"] = out["source_type"] or source_type_default
    out["collected_at"] = datetime.now(timezone.utc).isoformat()
    out["notes"] = ""
    return out

def load(path):
    ext = path.suffix.lower()
    if ext == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            return list(csv.DictReader(f))
    if ext == ".jsonl":
        return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    if ext == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, list): return data
        for key in ("items","notes","data","results"):
            if isinstance(data.get(key), list): return data[key]
        return [data]
    raise SystemExit(f"Unsupported input: {ext}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--platform")
    ap.add_argument("--source-type", default="user_file")
    args = ap.parse_args()
    rows = load(Path(args.input))
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(normalize(row, args.platform, args.source_type), ensure_ascii=False) + "\n")
    print(json.dumps({"ok": True, "rows": len(rows), "output": str(out)}, ensure_ascii=False))

if __name__ == "__main__":
    main()
