#!/usr/bin/env python3
import argparse, csv, json, statistics
from pathlib import Path

METRICS = ["impressions","views","likes","comments","shares","saves","watch_time","completion_rate","follows"]

def fnum(v):
    try: return float(v)
    except (TypeError, ValueError): return None

def median(values):
    vals=[x for x in values if x is not None]
    return statistics.median(vals) if vals else None

def load(path):
    p=Path(path)
    if p.suffix.lower()==".csv":
        with p.open(encoding="utf-8-sig",newline="") as f: return list(csv.DictReader(f))
    data=json.loads(p.read_text(encoding="utf-8"))
    return data if isinstance(data,list) else data.get("items",[data])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--target-id")
    args=ap.parse_args()
    rows=load(args.input)
    if not rows: raise SystemExit("No rows")
    baselines={m:median([fnum(r.get(m)) for r in rows]) for m in METRICS}
    target=None
    if args.target_id:
        for r in rows:
            if str(r.get("content_id") or r.get("id") or "")==args.target_id: target=r; break
    target=target or rows[-1]
    observed=[]
    for m in METRICS:
        tv, bv=fnum(target.get(m)), baselines[m]
        if tv is None or bv is None or bv==0: continue
        ratio=tv/bv
        observed.append({"metric":m,"target":tv,"baseline_median":bv,"ratio":round(ratio,2),"band":"high" if ratio>=1.25 else "low" if ratio<=0.75 else "normal"})
    hypotheses=[]
    bands={x["metric"]:x["band"] for x in observed}
    if bands.get("impressions")=="high" and bands.get("views")=="low": hypotheses.append("Packaging/opening may be under-converting available distribution; test title/cover/first-frame fit.")
    if bands.get("views")=="high" and bands.get("shares")=="low" and bands.get("saves")=="low": hypotheses.append("Consumption is stronger than deep utility/social value; test proof density, novelty or save/share payoff.")
    if bands.get("completion_rate")=="low": hypotheses.append("Inspect the exact retention drop before blaming the topic; test promise-payoff speed and beat order.")
    if bands.get("likes")=="high" and bands.get("follows")=="low": hypotheses.append("The post may satisfy in isolation without strengthening the account promise; test series bridge and positioning.")
    print(json.dumps({"target": target.get("content_id") or target.get("id"), "baseline_n":len(rows), "observed":observed, "likely_hypotheses":hypotheses, "warning":"Hypotheses are not causal proof."},ensure_ascii=False,indent=2))

if __name__=="__main__": main()
