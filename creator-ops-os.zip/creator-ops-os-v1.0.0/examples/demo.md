# Demo: one topic, two native outputs

Input goal: "做新手第一台咖啡机避坑，小红书和抖音各出一个版本。"

## Shared evidence contract
- Audience: first-time buyers with limited budget.
- Tension: spec sheets are hard to translate into daily use.
- Proof needed: 3 concrete failure scenarios + side-by-side result.
- Goal: save on Xiaohongshu; watch + follow on Douyin.

## Xiaohongshu direction
- Search intent: 第一台咖啡机怎么选
- Cover: "第一台咖啡机，先别看参数"
- Structure: 3 buying traps -> who each trap hurts -> compact checklist -> decision tree.
- Save artifact: one-screen checklist / carousel summary.

## Douyin direction
- 0-3s: show two visibly different failed/successful extractions while saying "第一台咖啡机最容易买错的，不是参数低。"
- 3-10s: reveal trap #1 through physical demo.
- Middle: trap #2/#3 with visual comparisons.
- Ending: one-sentence selection rule + next episode bridge.

Same truth, different consumption design.
