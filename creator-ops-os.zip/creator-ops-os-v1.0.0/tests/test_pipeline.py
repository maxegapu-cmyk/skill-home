#!/usr/bin/env python3
import json, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def run(*args):
    return subprocess.run(args,capture_output=True,text=True,check=True)

with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    norm=td/"market.jsonl"
    scored=td/"topics.csv"
    a=run("python3",str(ROOT/"scripts/normalize_market_data.py"),str(ROOT/"tests/sample_market.csv"),str(norm))
    assert json.loads(a.stdout)["rows"]==3
    lines=[json.loads(x) for x in norm.read_text(encoding="utf-8").splitlines()]
    assert len(lines)==3 and lines[0]["likes"]==1800
    b=run("python3",str(ROOT/"scripts/score_topics.py"),str(ROOT/"tests/sample_topics.csv"),str(scored))
    assert json.loads(b.stdout)["topics"]==3
    text=scored.read_text(encoding="utf-8-sig")
    assert "priority_score" in text and "新手第一台咖啡机避坑" in text
    c=run("python3",str(ROOT/"scripts/diagnose_content.py"),str(ROOT/"tests/sample_owned.csv"),"--target-id","p4")
    diagnosis=json.loads(c.stdout)
    assert diagnosis["baseline_n"]==4 and diagnosis["observed"]
print("PASS")
