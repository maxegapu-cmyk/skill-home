# 独立归集管理中心套件

这是一个**不附属任何元 skill**的独立归集管理中心套件。

## 内容
- `skill-archive-manager/`：归集、审计、管理与归档快照工具。
- `archive-center/`：管理中心 HTML 与说明。
- `desktop-entry/`：可移植 CMD/VBS 桌面入口模板。

## 使用
1. 打开 `archive-center/Skill发布归集管理中心.html` 查看管理页。
2. 需要桌面入口时，在套件根目录运行 `desktop-entry/创建桌面入口.vbs`。
3. 目标机安装 skill 时，进入 `skill-archive-manager/` 后运行 `python install.py --dry-run`。

本包不包含本机归档历史、冲突留证、清理备份、运行时安装标记或本机绝对路径。
