Set shell = CreateObject("WScript.Shell")
base = shell.CurrentDirectory
Set link = shell.CreateShortcut(shell.SpecialFolders("Desktop") & "\归集管理中心.lnk")
link.TargetPath = base & "\启动归集管理中心.cmd"
link.WorkingDirectory = base
link.Description = "独立归集管理中心套件"
link.Save
