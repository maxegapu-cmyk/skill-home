@echo off
set "ROOT=%~dp0.."
start "" "%ROOT%\archive-center\Skill发布归集管理中心.html"
