# Skill 发布归集管理中心

> 打开同目录 `Skill发布归集管理中心.html`，可在一个页面查找所有用户级 skill 的发布包。

## 归档结构

```text
<归档根>/
├─ 00-管理入口/                    # 顶层检索页与本说明
├─ MANAGED_SKILLS.json             # 所有已发现 skill 的登记表
└─ <skill-name>/                   # 每个 skill 一份独立归档
   ├─ history/                     # 常规版本包
   ├─ migrations/                  # 仅按需生成的跨机迁移包
   ├─ conflicts/                   # 同名不同内容的留证包
   ├─ INDEX.md                     # 人可读哈希台账
   └─ INDEX.json                   # 机器可读哈希台账
```

## 日常使用

1. 双击打开 `Skill发布归集管理中心.html`。
2. 先用 Skill 下拉框筛选，再按版本号、文件名或用途搜索。
3. “常规历史包”用于安装、查看或回退；“迁移包”只在明确要换电脑时使用；“冲突留证”只用于核对差异。
4. 新版本常规包由 本套件的内部工具链 的打包流程自动进入对应 skill 目录并刷新本页。

## 核验与刷新

```bash
python <本套件>/skill-archive-manager/scripts/skill_release_hub.py --refresh
python <本套件>/skill-archive-manager/scripts/skill_release_hub.py --verify
```

归集和接纳均只复制，不会自动删除原始发布包或旧归档。
