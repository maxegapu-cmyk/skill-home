#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""归集管理中心统一管理器。

管理职责：健康扫描、双向对账、问题队列、生命周期状态、版本门禁、冲突/隔离建议、
管理状态快照、迁移后复核。默认只读；--apply 仅写入 MANAGEMENT-STATE.json、
ACTION-QUEUE.json、ACTION-QUEUE.md，不删除/移动/覆盖归档实物。
"""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
AUDIT = HERE / "audit_archive.py"

def now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def load_audit():
    import importlib.util
    spec = importlib.util.spec_from_file_location("audit_archive", AUDIT)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1<<20), b""): h.update(b)
    return h.hexdigest()

def issue(kind, severity, name, detail, action, evidence=None):
    iid = hashlib.sha256((kind+"|"+name+"|"+detail).encode()).hexdigest()[:16]
    return {"finding_id":iid,"kind":kind,"severity":severity,"name":name,
            "detail":detail,"recommended_action":action,"status":"open",
            "evidence":evidence or [],"first_seen":now()}

def build_state(archive_root, skills_root):
    audit=load_audit(); f=audit.audit(archive_root)
    if skills_root:
        f["skills_root_findings"]=audit.audit_skills_root(skills_root, archive_root)
        f["total"] += f["skills_root_findings"]["total"]
    issues=[]
    for r in f.get("ledger_no_warehouse",[]):
        issues.append(issue("ledger_no_warehouse","P0",r["name"],"总台账登记但归档仓库无目录","生成正式发布包后归集；归集完成前不得标记 resolved",[r.get("source_path","")]))
    for r in f.get("warehouse_no_ledger",[]):
        issues.append(issue("warehouse_no_ledger","P0",r["name"],"仓库有目录/索引但总台账未登记","判定正式/测试/废弃后执行接纳或标记豁免",[r["name"]]))
    for r in f.get("version_stale",[]):
        issues.append(issue("version_stale","P1",r["name"],f"台账 {r['ledger_version']} ≠ 源码 {r['source_version']}","刷新管理页并重新对账",[]))
    for kind in ("unreadable","orphan","missing","size_outlier"):
        for r in f.get(kind,[]): issues.append(issue(kind,"P0",r.get("path",r.get("skill","unknown")),json.dumps(r,ensure_ascii=False),"隔离/补登记/修复后重新审计",[r.get("path","")]))
    for kind in ("version_gap","version_span_jump"):
        for r in f.get(kind,[]):
            if not r.get("exempted"):
                issues.append(issue(kind,"P1",r["skill"],f"{r['from']} → {r['to']}","寻找历史包或登记有证据的豁免",[]))
    health="blocked" if any(x["severity"]=="P0" for x in issues) else ("attention" if issues else "healthy")
    return {"schema":1,"generated_at":now(),"role":"archive-manager","health":health,
            "archive_root":str(archive_root),"skills_root":str(skills_root) if skills_root else "",
            "hard_findings":f.get("total",0),"issue_count":len(issues),
            "issues":issues,"audit_summary":{k:len(f.get(k,[])) for k in ("unreadable","orphan","missing","size_outlier","ledger_no_warehouse","warehouse_no_ledger","version_stale","version_gap","version_span_jump")}}

def write_state(state, root):
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    (root/"MANAGEMENT-STATE.json").write_text(json.dumps(state,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    lines=["# 归集管理行动队列","",f"> 生成于 {state['generated_at']}；管理状态：**{state['health']}**；默认只读。","",
           "| ID | 优先级 | 类型 | 对象 | 状态 | 建议动作 |","|---|---|---|---|---|---|"]
    for x in state["issues"]:
        lines.append(f"| `{x['finding_id']}` | {x['severity']} | `{x['kind']}` | `{x['name']}` | `{x['status']}` | {x['recommended_action']} |")
    if not state["issues"]: lines.append("| — | — | — | — | closed | 当前无待处理事项 |")
    (root/"ACTION-QUEUE.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    (root/"ACTION-QUEUE.json").write_text(json.dumps(state["issues"],ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def main():
    p=argparse.ArgumentParser(description="归集中心统一管理器：健康、队列、门禁、迁移复核")
    p.add_argument("--archive-root",default=str(Path.home()/".workbuddy"/"skill-release-archive"))
    p.add_argument("--skills-root",default=str(Path.home()/".workbuddy"/"skills"))
    p.add_argument("--apply",action="store_true",help="写入管理状态与行动队列；不删除/移动归档实物")
    p.add_argument("--check-migration",help="复核已解压的归档中心随迁目录")
    a=p.parse_args(); ar=Path(a.archive_root).expanduser().resolve(); sr=Path(a.skills_root).expanduser().resolve()
    if a.check_migration:
        root=Path(a.check_migration).resolve(); ok=(root/"MANIFEST.json").is_file() and (root/"MANAGED_SKILLS.json").is_file()
        print("[migration-check][%s] manifest + MANAGED_SKILLS.json" % ("OK" if ok else "FAIL")); return 0 if ok else 1
    state=build_state(ar,sr)
    print(f"管理状态：{state['health']}；硬发现：{state['hard_findings']}；行动项：{state['issue_count']}")
    for x in state["issues"][:20]: print(f"[{x['severity']}] {x['kind']} {x['name']} -> {x['recommended_action']}")
    if a.apply:
        write_state(state,ar); print("已写入 MANAGEMENT-STATE.json / ACTION-QUEUE.json / ACTION-QUEUE.md")
    return 0 if state["health"]=="healthy" else 1
if __name__=="__main__": raise SystemExit(main())
