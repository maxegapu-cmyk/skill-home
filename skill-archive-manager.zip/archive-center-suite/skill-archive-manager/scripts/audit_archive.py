#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""归档中心「记录外完整性」审计 + skills 根卫生体检 + 版本区间空洞提示（skill-archive-manager 自带）。

补元 skill 归档器的盲区：它只校验 INDEX.json **已登记记录**（哈希 / zip CRC /
条目数），从不扫描「存在但未登记」的文件。于是一个 2.33 GB 的截断 zip 可以在归档里
长期潜伏，而校验依然全绿。

本脚本只读扫描，产出三段发现。

A. 归档中心（--archive-root）
  unreadable    .zip 无法作为 zip 打开（截断 / 损坏 / 写入中断）
  orphan        文件落在 history/ migrations/ conflicts/ 却未被任何 INDEX.json 登记
  missing       记录声称的文件不存在
  size_outlier  同 skill 同类型包体积远超中位数（误打包 / 截断信号）

B. skills 根（可选 --skills-root）
  backup_dir_in_root    备份目录留在 skills 根内 —— 加载器会把它当同名 skill 解析并抢占真身
  dir_without_skill_md  目录缺 SKILL.md，不是合法 skill
  zip_unique            杂散 zip 且归档里没有对应内容 —— 移走即失传，必须先归集
  zip_redundant         杂散 zip 但与归档内容逐字节相同 —— 纯冗余，可安全移出

C. 版本区间空洞（**提示**，非缺陷断言）
  version_gap       同一主次版本号内，相邻在档版本之间缺补丁号（可精确枚举缺失版本）
  version_span_jump 相邻在档版本之间跨了整段（次版本号差 >1 或大版本号不同，无法枚举）

A 段与 B 段的发现计入失败数；C 段默认只提示、不计入失败 —— 因为 semver 补丁号并非必然
发布，缺少某个号不等于该号发布过，无外部依据时不可断言为缺陷。需要把 C 段当门禁时加
`--strict-gaps`（只对**未豁免**的空洞生效）。已确认可接受的缺失登记在
`<归档根>/<skill>/known-gaps.json` 的 known_missing 列表里，按「kind + from + to」精确匹配：
  {"schema": 1, "skill": "<name>", "known_missing": [
     {"kind": "patch", "from": "1.0.6", "to": "1.0.9",
      "reason": "…", "recorded_at": "YYYY-MM-DD", "evidence": "…"}]}
kind 取 "patch"（对应 version_gap）或 "span"（对应 version_span_jump）。

用法:
    python audit_archive.py --archive-root <目录>
    python audit_archive.py --archive-root <目录> --skills-root <skills目录>
    python audit_archive.py --archive-root <目录> --skills-root <目录> --json <报告.json>
    python audit_archive.py --archive-root <目录> --gaps-list <待寻清单.md>
    python audit_archive.py --archive-root <目录> --strict-gaps
    python audit_archive.py --archive-root <目录> --max-outlier-ratio 20
    python audit_archive.py --self-check

退出码: 0 = 无发现；1 = 有发现或执行失败（--strict-gaps 时未豁免的空洞也计为发现）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
import tempfile
import zipfile
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass

IGNORED = {"__pycache__", ".DS_Store", ".git"}
SCAN_FOLDERS = ("history", "migrations", "conflicts")
ZIP_EXT = ".zip"
DEFAULT_OUTLIER_RATIO = 20.0
MIN_OUTLIER_BYTES = 1_000_000
KNOWN_GAPS_NAME = "known-gaps.json"
VER_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)")

# skills 根内由宿主/安装器自管的条目，卫生体检一律跳过。
HOST_MANAGED = {".deps", ".skill-install-backups", "node_modules"}
# 备份目录命名特征：历史事故根因 —— 备份若留在 skills 根内，会被加载器当同名 skill 解析。
BACKUP_DIR_RE = re.compile(r"^(\.backup[-_].+|_backup[-_].+|.+[-_]backup([-_].+)?)$", re.IGNORECASE)
# 宿主自管的迁移标记文件，不是杂物。
HOST_MANAGED_FILE_RE = re.compile(r"^[._].+migration\.json$", re.IGNORECASE)


def is_readable_zip(path: Path) -> tuple[bool, str]:
    """能打开并读到中央目录才算可读；截断包会在这一步暴露。"""
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
        return True, f"{len(names)} 条目"
    except (zipfile.BadZipFile, OSError, ValueError, EOFError) as e:
        return False, type(e).__name__ + ": " + str(e)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_records(archive_root: Path) -> dict:
    """返回 {skill 目录名: {"archive_paths": set, "versions": set, "history_versions": set}}。

    history_versions 只收 kind=history 且路径落在 history/ 下的记录 —— 这是「权威版本
    序列」的口径；conflicts/ 是留证副本，其版本不代表该版本已作为发布物在档。
    """
    out = {}
    for index in sorted(archive_root.glob("*/INDEX.json")):
        skill_dir = index.parent
        try:
            data = json.loads(index.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            entry = out.setdefault(skill_dir.name, {"archive_paths": set(), "versions": set(),
                                                    "history_versions": set()})
            entry["index_error"] = True
            continue
        entry = out.setdefault(skill_dir.name, {"archive_paths": set(), "versions": set(),
                                                "history_versions": set()})
        for rec in data.get("records", []) or []:
            ap = rec.get("archive_path") or ""
            if ap:
                entry["archive_paths"].add(Path(ap).as_posix())
            ver = rec.get("version")
            if ver:
                entry["versions"].add(str(ver))
                norm = str(ap).replace("\\", "/")
                if rec.get("kind") == "history" and "history/" in norm:
                    entry["history_versions"].add(str(ver))
    return out


def scan_candidates(archive_root: Path):
    """归档中心内所有落在 history/ migrations/ conflicts/ 下的文件，相对归档根。"""
    found = []
    for p in sorted(archive_root.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(archive_root)
        if any(part in IGNORED for part in rel.parts):
            continue
        parent = rel.parts[0] if len(rel.parts) == 1 else rel.parts[1] if len(rel.parts) > 1 else ""
        if any(folder in rel.parts[:-1] for folder in SCAN_FOLDERS) or parent in SCAN_FOLDERS:
            found.append((p, rel))
    return found


def archive_digests(archive_root: Path) -> dict:
    """归档中心全部 zip 的 sha256 -> 相对路径。用于判定 skills 根杂散 zip 是冗余还是唯一。"""
    out = {}
    if not Path(archive_root).is_dir():
        return out
    for p in sorted(Path(archive_root).rglob("*" + ZIP_EXT)):
        if not p.is_file() or any(part in IGNORED for part in p.parts):
            continue
        try:
            out.setdefault(digest(p), p.relative_to(archive_root).as_posix())
        except OSError:
            pass
    return out


def version_key(text: str):
    """x.y.z -> (x, y, z)；非规范版本号返回 None（不参与空洞判定，避免假报）。"""
    m = VER_RE.match(str(text).strip())
    return tuple(int(x) for x in m.groups()) if m else None


def load_known_gaps(skill_dir: Path) -> list:
    """读该 skill 的已知缺失豁免清单；缺失/损坏一律当作空清单（不静默放过，报告里体现）。"""
    path = Path(skill_dir) / KNOWN_GAPS_NAME
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    rows = data.get("known_missing")
    return rows if isinstance(rows, list) else []


def _frontmatter_version(path: Path) -> str:
    """从 SKILL.md frontmatter 抽 version（x.y.z）。读不到或格式不符返回空串。"""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return ""
    fm = m.group(1)
    vm = re.search(r"^\s*version\s*:\s*([0-9]+\.[0-9]+\.[0-9]+)", fm, re.MULTILINE)
    return vm.group(1) if vm else ""


def reconcile_ledger(archive_root: Path) -> dict:
    """登记员（MANAGED_SKILLS.json 总台账 + 各 skill 的 INDEX.json）⇄ 仓库（实际目录）双向对账。

    这是 skill-archive-manager（登记员）与归集管理中心（仓库）的**强联动**检查：
    - 方向一「登记了但仓库无实物」：总台账登记了某 skill，但归档中心没有对应子目录 → 未归集 / 登记缺物。
    - 方向二「收集了但总台账没登记」：归档中心存在含有效内容的 skill 目录，但总台账漏登 → 收集未登记。
    - 版本陈旧（提示）：总台账版本 ≠ 来源源码 SKILL.md 版本 → 台账过期，刷新管理页时应带回。

    无 MANAGED_SKILLS.json 时返回空结果（不误报）；该检查只扫描目录与台账，不读 zip。
    """
    archive_root = Path(archive_root)
    ms_path = archive_root / "MANAGED_SKILLS.json"
    if not ms_path.is_file():
        return {"ledger_missing": True, "ledger_no_warehouse": [],
                "warehouse_no_ledger": [], "version_stale": []}

    try:
        ms = json.loads(ms_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"ledger_unreadable": True, "ledger_no_warehouse": [],
                "warehouse_no_ledger": [], "version_stale": []}

    reg = {s["name"]: s for s in ms.get("skills", []) if s.get("name")}
    reg_names = set(reg)
    governance = archive_root / "ARCHIVE-GOVERNANCE.json"
    excluded = set()
    if governance.is_file():
        try:
            gd = json.loads(governance.read_text(encoding="utf-8"))
            excluded = {x.get("name") for x in gd.get("excluded_assets", [])
                        if x.get("status") == "waived" and x.get("name")}
        except (OSError, json.JSONDecodeError):
            excluded = set()
    ctrl = {"00-管理入口", "MANAGED_SKILLS.json", "MANIFEST.json", "MANIFEST.sha256",
            "launch_center.py", "管理中心服务.log", "ARCHIVE-GOVERNANCE.json",
            "MANAGEMENT-STATE.json", "ACTION-QUEUE.json", "ACTION-QUEUE.md"}
    excluded = set()
    governance = archive_root / "ARCHIVE-GOVERNANCE.json"
    if governance.is_file():
        try:
            gd = json.loads(governance.read_text(encoding="utf-8"))
            excluded = {x.get("name") for x in gd.get("excluded_assets", [])
                        if x.get("status") == "waived" and x.get("name")}
        except (OSError, json.JSONDecodeError):
            excluded = set()
    dirs = {d.name for d in archive_root.iterdir()
            if d.is_dir() and d.name not in ctrl and d.name not in excluded}

    ledger_no_warehouse, warehouse_no_ledger, version_stale = [], [], []

    # 方向一：登记了但仓库无目录
    for n in sorted(reg_names - dirs):
        s = reg[n]
        src = s.get("source_path", "")
        ledger_no_warehouse.append({
            "name": n, "version": s.get("version", ""),
            "source_path": src, "has_source": bool(src) and Path(src).is_dir(),
        })

    # 方向二：仓库有目录但总台账未登记
    for n in sorted(dirs - reg_names):
        d = archive_root / n
        has_zip = any(z.suffix.lower() == ZIP_EXT for z in d.rglob("*"))
        has_index = (d / "INDEX.json").is_file()
        likely_junk = (n.startswith("demo-") or n.startswith("test-")) and not has_zip
        warehouse_no_ledger.append({
            "name": n, "has_zip": has_zip, "has_index": has_index,
            "likely_junk": likely_junk,
        })

    # 版本陈旧：台账版本 vs 来源源码 frontmatter（仅提示）
    for n in sorted(reg_names & dirs):
        src = reg[n].get("source_path", "")
        if src:
            sf = Path(src) / "SKILL.md"
            if sf.is_file():
                sv = _frontmatter_version(sf)
                if sv and sv != reg[n].get("version", ""):
                    version_stale.append({
                        "name": n, "ledger_version": reg[n].get("version", ""),
                        "source_version": sv,
                    })

    return {"ledger_missing": False, "ledger_no_warehouse": ledger_no_warehouse,
            "warehouse_no_ledger": warehouse_no_ledger, "version_stale": version_stale}


def detect_version_gaps(archive_root: Path, records: dict) -> tuple[list, list]:
    """按在档 history 版本序列检出两类区间提示，并按 known-gaps.json 标注豁免。

    排序必须按版本号而非文件名 —— `v0.91.10` 按名字会排到 `v0.91.3` 之前，用文件名
    排序会把真实空洞判错。
    """
    gaps, jumps = [], []
    for skill, info in sorted(records.items()):
        keyed = []
        for v in info.get("history_versions", set()):
            k = version_key(v)
            if k:
                keyed.append((k, str(v)))
        if len(keyed) < 2:
            continue
        keyed.sort()
        exemptions = load_known_gaps(Path(archive_root) / skill)
        for (ka, va), (kb, vb) in zip(keyed, keyed[1:]):
            ex = next((e for e in exemptions
                       if str(e.get("from")) == va and str(e.get("to")) == vb
                       and e.get("kind") in ("patch", "span")), None)
            exempt = {"exempted": bool(ex),
                      "exempt_reason": (ex or {}).get("reason", ""),
                      "exempt_recorded_at": (ex or {}).get("recorded_at", "")}
            if ka[0] != kb[0] or kb[1] - ka[1] > 1:
                jumps.append({"skill": skill, "kind": "span", "from": va, "to": vb,
                              "major_delta": kb[0] - ka[0], "minor_delta": kb[1] - ka[1],
                              "note": "相邻在档版本之间跨整段，无法枚举缺失版本号", **exempt})
            elif kb[1] == ka[1] and kb[2] - ka[2] > 1:
                miss = ["%d.%d.%d" % (ka[0], ka[1], i) for i in range(ka[2] + 1, kb[2])]
                gaps.append({"skill": skill, "kind": "patch", "from": va, "to": vb,
                             "missing_count": len(miss), "missing": miss, **exempt})
    return gaps, jumps


def audit(archive_root: Path, outlier_ratio: float = DEFAULT_OUTLIER_RATIO, read_zip: bool = True) -> dict:
    archive_root = Path(archive_root)
    if not archive_root.is_dir():
        raise FileNotFoundError("归档根不存在: " + str(archive_root))
    records = load_records(archive_root)
    candidates = scan_candidates(archive_root)

    unreadable, orphans, size_groups = [], [], {}
    for p, rel in candidates:
        if p.suffix.lower() == ZIP_EXT and read_zip:
            ok, detail = is_readable_zip(p)
            if not ok:
                unreadable.append({"path": rel.as_posix(), "size": p.stat().st_size, "detail": detail})
        parts = rel.as_posix().split("/")
        top = parts[0]
        tail = "/".join(parts[1:])
        # conflicts/ 是留证副本，按设计不入 INDEX 记录，不参与 orphan 判定。
        if "conflicts" not in parts[:-1] and not parts[-1] == "conflicts":
            recorded = records.get(top, {}).get("archive_paths", set())
            if tail not in recorded and rel.as_posix() not in recorded:
                orphans.append({"path": rel.as_posix(), "size": p.stat().st_size})
        if p.suffix.lower() == ZIP_EXT:
            key = top + "/" + (parts[1] if len(parts) > 2 else "")
            size_groups.setdefault(key, []).append((rel.as_posix(), p.stat().st_size))

    # 记录里的 archive_path 是相对「该 skill 的归档目录」写的（形如 history/xxx.zip）；
    # 也兼容相对归档根的历史写法，两种口径都试，避免把已存在的文件误判成 missing。
    missing = []
    for skill, info in records.items():
        for ap in sorted(info.get("archive_paths", set())):
            rel = Path(ap)
            if (archive_root / skill / rel).is_file() or (archive_root / rel).is_file():
                continue
            missing.append({"skill": skill, "path": ap})

    outliers = []
    for key, items in size_groups.items():
        if len(items) < 3:
            continue
        sizes = sorted(s for _, s in items)
        mid = sizes[len(sizes) // 2]
        if mid <= 0:
            continue
        threshold = max(mid * outlier_ratio, float(MIN_OUTLIER_BYTES))
        for path, size in items:
            if size > threshold:
                outliers.append({"path": path, "size": size, "median": mid,
                                 "ratio": round(size / mid, 1)})

    gaps, jumps = detect_version_gaps(archive_root, records)
    ledger = reconcile_ledger(archive_root)

    findings = {
        "archive_root": str(archive_root),
        "skills_scanned": sorted(records),
        "files_scanned": len(candidates),
        "unreadable": unreadable,
        "orphan": orphans,
        "missing": missing,
        "size_outlier": outliers,
        "version_gap": gaps,
        "version_span_jump": jumps,
        "ledger_no_warehouse": ledger["ledger_no_warehouse"],
        "warehouse_no_ledger": ledger["warehouse_no_ledger"],
        "version_stale": ledger["version_stale"],
        "ledger_missing": ledger.get("ledger_missing", False),
        "ledger_unreadable": ledger.get("ledger_unreadable", False),
        "advisory": len([r for r in gaps + jumps if not r["exempted"]]),
        "advisory_exempted": len([r for r in gaps + jumps if r["exempted"]]),
        "ledger_total": len(ledger["ledger_no_warehouse"]) + len(ledger["warehouse_no_ledger"]),
        "total": (len(unreadable) + len(orphans) + len(missing) + len(outliers)
                  + len(ledger["ledger_no_warehouse"]) + len(ledger["warehouse_no_ledger"])),
    }
    return findings


def audit_skills_root(skills_root: Path, archive_root: Path) -> dict:
    """skills 根卫生体检：备份污染、非法目录、杂散 zip（区分唯一与冗余）。"""
    skills_root = Path(skills_root)
    if not skills_root.is_dir():
        raise FileNotFoundError("skills 根不存在: " + str(skills_root))

    backup_dirs, no_skill_md, strays, host_files = [], [], [], 0
    for p in sorted(skills_root.iterdir()):
        name = p.name
        if name in HOST_MANAGED:
            continue
        if p.is_dir():
            if BACKUP_DIR_RE.match(name):
                backup_dirs.append({"name": name})
            elif name.startswith("."):
                continue
            elif not (p / "SKILL.md").is_file():
                no_skill_md.append({"name": name})
            continue
        if not p.is_file():
            continue
        if HOST_MANAGED_FILE_RE.match(name):
            host_files += 1
            continue
        if p.suffix.lower() == ZIP_EXT:
            strays.append(p)
        else:
            host_files += 1

    redundant, unique = [], []
    if strays:
        arc = archive_digests(archive_root)
        for p in strays:
            try:
                dg = digest(p)
            except OSError:
                dg = ""
            row = {"name": p.name, "size": p.stat().st_size, "sha256": dg}
            if dg and dg in arc:
                row["archive_counterpart"] = arc[dg]
                redundant.append(row)
            else:
                unique.append(row)

    return {
        "skills_root": str(skills_root),
        "backup_dir_in_root": backup_dirs,
        "dir_without_skill_md": no_skill_md,
        "zip_unique": unique,
        "zip_redundant": redundant,
        "host_managed_files": host_files,
        "total": len(backup_dirs) + len(no_skill_md) + len(unique) + len(redundant),
    }


def report(f: dict) -> None:
    print("== 归档中心记录外完整性审计 ==")
    print(f"归档根：{f['archive_root']}")
    print(f"已登记 skill：{len(f['skills_scanned'])} · 扫描文件：{f['files_scanned']}")
    head = ("unreadable", "orphan", "missing", "size_outlier")
    for kind in head:
        rows = f[kind]
        mark = "OK" if not rows else "!!"
        print(f"[{mark}] {kind}: {len(rows)} 项")
        for r in rows[:8]:
            print("     - " + json.dumps(r, ensure_ascii=False))
        if len(rows) > 8:
            print(f"     ... 另有 {len(rows) - 8} 项")

    sr = f.get("skills_root_findings")
    if sr:
        print()
        print("== skills 根卫生体检 ==")
        print(f"skills 根：{sr['skills_root']}（宿主自管文件 {sr['host_managed_files']} 个已跳过）")
        for kind, hint in (
            ("backup_dir_in_root", "备份目录留在根内会抢占同名 skill，必须移出"),
            ("dir_without_skill_md", "不是合法 skill 目录"),
            ("zip_unique", "归档无此内容，移走即失传，必须先归集"),
            ("zip_redundant", "与归档逐字节相同，纯冗余可移出"),
        ):
            rows = sr[kind]
            mark = "OK" if not rows else "!!"
            print(f"[{mark}] {kind}: {len(rows)} 项  —— {hint}")
            for r in rows[:8]:
                print("     - " + json.dumps(r, ensure_ascii=False))
            if len(rows) > 8:
                print(f"     ... 另有 {len(rows) - 8} 项")

    print()
    print("== 版本区间空洞（提示，非缺陷断言）==")
    for kind, hint in (("version_gap", "同段补丁号缺失，可精确枚举"),
                       ("version_span_jump", "跨整段缺失，无法枚举")):
        rows = f[kind]
        pending = [r for r in rows if not r["exempted"]]
        mark = "--" if not pending else "??"
        print(f"[{mark}] {kind}: {len(rows)} 处（未豁免 {len(pending)}）—— {hint}")
        for r in rows[:8]:
            flag = "已豁免" if r["exempted"] else "待确认"
            print(f"     - [{flag}] " + json.dumps(r, ensure_ascii=False))
        if len(rows) > 8:
            print(f"     ... 另有 {len(rows) - 8} 处")

    print()
    print("== 登记员 ⇄ 仓库 双向对账（skill-archive-manager 与归集管理中心的强联动）==")
    if f.get("ledger_missing"):
        print("[!!] 未找到 MANAGED_SKILLS.json（登记员总台账缺失）—— 无法进行双向对账")
    elif f.get("ledger_unreadable"):
        print("[!!] MANAGED_SKILLS.json 损坏无法解析 —— 无法进行双向对账")
    else:
        for kind, hint in (
            ("ledger_no_warehouse", "登记了但仓库无目录：未归集 / 登记缺实物，台账是空头账"),
            ("warehouse_no_ledger", "仓库有目录但总台账没登记：收集未登记，台账漏登"),
        ):
            rows = f[kind]
            mark = "OK" if not rows else "!!"
            print(f"[{mark}] {kind}: {len(rows)} 项  —— {hint}")
            for r in rows[:12]:
                print("     - " + json.dumps(r, ensure_ascii=False))
            if len(rows) > 12:
                print(f"     ... 另有 {len(rows) - 12} 项")
        vs = f.get("version_stale", [])
        mark = "--" if not vs else "??"
        print(f"[{mark}] version_stale: {len(vs)} 项  —— 台账版本≠源码版本（刷新管理页可带回，默认不计入失败）")
        for r in vs[:8]:
            print("     - " + json.dumps(r, ensure_ascii=False))
        if len(vs) > 8:
            print(f"     ... 另有 {len(vs) - 8} 项")

    adv = f.get("advisory", 0)
    ledger_hard = len(f.get("ledger_no_warehouse", [])) + len(f.get("warehouse_no_ledger", []))
    if f["total"] == 0 and ledger_hard == 0:
        print("审计结论：无发现 ✅ 归档中心记录内外一致，登记员与仓库双向吻合")
    else:
        print(f"审计结论：硬发现 {f['total']} 项 ❌ 先处理再随迁")
    if adv or f.get("version_stale"):
        vstale = len(f.get("version_stale", []))
        print(f"        另有 {adv} 处未豁免的版本区间提示 + {vstale} 处台账版本陈旧（默认不计入失败；"
              f"需当门禁时加 --strict-gaps，并刷新管理页带回版本）")


def write_gaps_list(findings: dict, path: Path) -> None:
    """把版本空洞写成「待寻清单」：拿去另一台机器按图索骥补历史包。"""
    gaps = [r for r in findings["version_gap"] if not r["exempted"]]
    jumps = [r for r in findings["version_span_jump"] if not r["exempted"]]
    ex_rows = [r for r in findings["version_gap"] + findings["version_span_jump"] if r["exempted"]]
    by_skill = {}
    for r in gaps:
        by_skill.setdefault(r["skill"], {"gap": [], "jump": []})["gap"].append(r)
    for r in jumps:
        by_skill.setdefault(r["skill"], {"gap": [], "jump": []})["jump"].append(r)

    lines = ["# 版本空洞待寻清单", "",
             "> 来源：`audit_archive.py --gaps-list`（只读扫描归档中心 INDEX 的 history 记录）",
             "> 口径：semver 补丁号并非必然发布，下列为**在档序列相邻版本之间的缺失提示**，"
             "不是「这些版本一定发布过」的断言。",
             "> 补齐方式：把找到的发布包聚到一个目录，再跑 "
             "`archive_releases.py --skill-dir <skill> --archive-dir <归档>/<skill> "
             "--history-source <该目录>`；补齐后本清单对应项自动消失。", ""]
    if not by_skill:
        lines.append("当前无未豁免的版本空洞。✅")
    for skill in sorted(by_skill):
        lines.append(f"## {skill}")
        lines.append("")
        rows = by_skill[skill]["gap"]
        if rows:
            lines.append("### 可精确枚举（同段补丁号缺失）")
            lines.append("")
            lines.append("| 区间 | 缺失数 | 缺失版本 |")
            lines.append("|---|---|---|")
            for r in rows:
                lines.append(f"| {r['from']} → {r['to']} | {r['missing_count']} | "
                             + ", ".join(r["missing"]) + " |")
            lines.append("")
        rows = by_skill[skill]["jump"]
        if rows:
            lines.append("### 无法枚举（跨整段缺失）")
            lines.append("")
            lines.append("| 区间 | 跨段幅度 | 说明 |")
            lines.append("|---|---|---|")
            for r in rows:
                span = (f"大版本 +{r['major_delta']}" if r["major_delta"]
                        else f"次版本 +{r['minor_delta']}")
                lines.append(f"| {r['from']} → {r['to']} | {span} | {r['note']} |")
            lines.append("")
    if ex_rows:
        lines += ["## 已豁免（known-gaps.json 已登记，无需再找）", "",
                  "| skill | 区间 | 类型 | 理由 |", "|---|---|---|---|"]
        for r in ex_rows:
            lines.append(f"| {r['skill']} | {r['from']} → {r['to']} | {r['kind']} | "
                         f"{r['exempt_reason'] or '（未填理由）'} |")
        lines.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def self_check() -> int:
    """证明：归档四类发现、skills 根四类发现、版本空洞两类+豁免都能被检出，干净样本不误报。"""
    with tempfile.TemporaryDirectory(prefix="audit-archive-selfcheck-") as raw:
        base = Path(raw)

        def make_zip(path: Path, entries: int = 1) -> None:
            path.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(path, "w") as z:
                for i in range(entries):
                    z.writestr(f"f{i}.txt", "x" * 64)

        def write_index(dirpath: Path, skill: str, versions: list) -> None:
            (dirpath / "INDEX.json").write_text(json.dumps({
                "schema": 1, "skill": skill,
                "records": [{"kind": "history", "version": v,
                             "archive_path": f"{skill}/history/{skill}-v{v}.zip"}
                            for v in versions],
            }, ensure_ascii=False), encoding="utf-8")

        # --- 脏归档 ---
        dirty = base / "dirty"
        make_zip(dirty / "demo-skill" / "history" / "demo-skill-v1.0.0.zip")
        make_zip(dirty / "demo-skill" / "history" / "demo-skill-v1.1.0.zip")          # 未登记
        bad = dirty / "demo-skill" / "history" / "demo-skill-v1.2.0.zip"              # 截断
        bad.write_bytes(b"PK\x03\x04" + b"\x00" * 4096)
        for i in range(4):                                                            # 体积离群
            make_zip(dirty / "demo-skill" / "history" / f"demo-skill-v1.3.{i}.zip")
        with (dirty / "demo-skill" / "history" / "demo-skill-v9.9.9.zip").open("wb") as z:
            z.write(b"PK\x03\x04" + b"\x00" * (3_000_000))
        (dirty / "demo-skill" / "INDEX.json").write_text(json.dumps({
            "schema": 1, "skill": "demo-skill",
            "records": [
                {"kind": "history", "version": "1.0.0",
                 "archive_path": "demo-skill/history/demo-skill-v1.0.0.zip"},
                {"kind": "history", "version": "2.0.0",
                 "archive_path": "demo-skill/history/demo-skill-v2.0.0.zip"},  # 文件缺失
            ] + [{"kind": "history", "version": f"1.3.{i}",
                  "archive_path": f"demo-skill/history/demo-skill-v1.3.{i}.zip"} for i in range(4)],
        }, ensure_ascii=False), encoding="utf-8")
        f = audit(dirty, read_zip=True)
        caught = {
            "unreadable": any("v1.2.0" in r["path"] or "v9.9.9" in r["path"] for r in f["unreadable"]),
            "orphan": any("v1.1.0" in r["path"] for r in f["orphan"]),
            "missing": any("v2.0.0" in r["path"] for r in f["missing"]),
            "size_outlier": any("v9.9.9" in r["path"] for r in f["size_outlier"]),
        }
        missing_kinds = [k for k, v in caught.items() if not v]
        print(("  PASS" if not missing_kinds else "  FAIL") +
              "  归档四类发现全部检出" + ("" if not missing_kinds else f"（漏: {missing_kinds}）"))
        # 提示段不得污染失败计数：脏归档的 total 只来自四类
        core_only = f["total"] == (len(f["unreadable"]) + len(f["orphan"])
                                   + len(f["missing"]) + len(f["size_outlier"]))
        print(("  PASS" if core_only else "  FAIL") +
              "  版本提示不计入失败计数（提示与失败分离）")

        # --- 干净归档（反证：不应误报） ---
        clean = base / "clean"
        make_zip(clean / "demo-skill" / "history" / "demo-skill-v1.0.0.zip")
        make_zip(clean / "demo-skill" / "history" / "demo-skill-v1.1.0.zip")
        make_zip(clean / "demo-skill" / "migrations" / "demo-skill-migration-v1.1.0.zip")
        make_zip(clean / "demo-skill" / "conflicts" / "demo-skill-v1.0.0--deadbeef.zip")
        (clean / "demo-skill" / "INDEX.json").write_text(json.dumps({
            "schema": 1, "skill": "demo-skill",
            "records": [
                {"kind": "history", "version": "1.0.0",
                 "archive_path": "demo-skill/history/demo-skill-v1.0.0.zip"},
                {"kind": "history", "version": "1.1.0",
                 "archive_path": "demo-skill/history/demo-skill-v1.1.0.zip"},
                {"kind": "migration", "version": "1.1.0",
                 "archive_path": "demo-skill/migrations/demo-skill-migration-v1.1.0.zip"},
                {"kind": "history", "version": "1.0.0",
                 "archive_path": "demo-skill/conflicts/demo-skill-v1.0.0--deadbeef.zip"},
            ],
        }, ensure_ascii=False), encoding="utf-8")
        fc = audit(clean, read_zip=True)
        negative = fc["total"] == 0 and not fc["version_gap"] and not fc["version_span_jump"]
        print(("  PASS" if negative else "  FAIL") +
              f"  干净归档零误报（发现 {fc['total']} 项，提示 {fc['advisory']} 处）")

        # --- 关闭 zip 读取时应只丢 unreadable，其余仍报 ---
        fb = audit(dirty, read_zip=False)
        partial = not fb["unreadable"] and fb["orphan"] and fb["missing"]
        print(("  PASS" if partial else "  FAIL") + "  --no-zip-read 时跳过可读性、保留其余三类")

        # --- 版本空洞：可枚举的补丁空洞 + 跨段跳跃，且豁免清单精确生效 ---
        chain = base / "chain"
        # 序列刻意只留两处：1.0.1 → 1.0.4 为补丁空洞（缺 1.0.2/1.0.3），
        # 1.0.4 → 1.2.0 为跨段跳跃（次版本 +2，中间整段无在档版本）。
        vs = ["1.0.0", "1.0.1", "1.0.4", "1.2.0"]
        for v in vs:
            make_zip(chain / "chain-skill" / "history" / f"chain-skill-v{v}.zip")
        write_index(chain / "chain-skill", "chain-skill", vs)
        fg = audit(chain, read_zip=False)
        gap = next((r for r in fg["version_gap"] if r["from"] == "1.0.1"), None)
        jump = next((r for r in fg["version_span_jump"] if r["from"] == "1.0.4"), None)
        gap_ok = bool(gap) and gap["missing"] == ["1.0.2", "1.0.3"] and gap["missing_count"] == 2
        jump_ok = bool(jump) and jump["major_delta"] == 0 and jump["minor_delta"] == 2
        print(("  PASS" if gap_ok and jump_ok else "  FAIL") +
              "  补丁空洞可精确枚举 + 跨段跳跃可检出"
              + ("" if gap_ok else "（补丁空洞判据不符）")
              + ("" if jump_ok else "（跨段跳跃判据不符）"))
        (chain / "chain-skill" / KNOWN_GAPS_NAME).write_text(json.dumps({
            "schema": 1, "skill": "chain-skill",
            "known_missing": [{"kind": "patch", "from": "1.0.1", "to": "1.0.4",
                               "reason": "自证夹具：确认 1.0.2/1.0.3 从未发布",
                               "recorded_at": "2026-01-01", "evidence": "self-check"}],
        }, ensure_ascii=False), encoding="utf-8")
        fe = audit(chain, read_zip=False)
        ex_gap = next((r for r in fe["version_gap"] if r["from"] == "1.0.1"), None)
        ex_ok = (bool(ex_gap) and ex_gap["exempted"]
                 and fe["advisory"] == 1 and fe["advisory_exempted"] == 1
                 and fe["total"] == 0)
        print(("  PASS" if ex_ok else "  FAIL") +
              "  豁免清单精确生效：已登记空洞不再计入未豁免，跨段跳跃仍待确认")

        # --- skills 根卫生：四类发现全部检出 + 宿主自管项不误报 ---
        sk = base / "skills"
        (sk / "real-skill").mkdir(parents=True)
        (sk / "real-skill" / "SKILL.md").write_text("---\nname: real-skill\n---\n", encoding="utf-8")
        (sk / "not-a-skill").mkdir(parents=True)                       # 缺 SKILL.md
        (sk / ".backup_20260101_demo").mkdir(parents=True)             # 备份污染
        (sk / ".deps").mkdir(parents=True)                             # 宿主自管，应跳过
        (sk / ".skill-install-backups").mkdir(parents=True)            # 宿主自管，应跳过
        (sk / ".model_invocation_to_override_migration.json").write_text("{}", encoding="utf-8")
        make_zip(clean / "real-skill" / "history" / "real-skill-v1.0.0.zip")
        (clean / "real-skill" / "INDEX.json").write_text(json.dumps({
            "schema": 1, "skill": "real-skill",
            "records": [{"kind": "history", "version": "1.0.0",
                         "archive_path": "real-skill/history/real-skill-v1.0.0.zip"}],
        }, ensure_ascii=False), encoding="utf-8")
        # 冗余杂散：与归档同内容
        (sk / "real-skill-v1.0.0.zip").write_bytes(
            (clean / "real-skill" / "history" / "real-skill-v1.0.0.zip").read_bytes())
        # 唯一杂散：归档里没有（条目数刻意不同，避免与上面那个包字节撞车而误归为冗余）
        make_zip(sk / "lonely-skill-v0.1.0.zip", entries=7)
        sr = audit_skills_root(sk, clean)
        sr_caught = {
            "backup_dir_in_root": any("backup" in r["name"] for r in sr["backup_dir_in_root"]),
            "dir_without_skill_md": any(r["name"] == "not-a-skill" for r in sr["dir_without_skill_md"]),
            "zip_unique": any(r["name"] == "lonely-skill-v0.1.0.zip" for r in sr["zip_unique"]),
            "zip_redundant": any(r["name"] == "real-skill-v1.0.0.zip" for r in sr["zip_redundant"]),
        }
        sr_missing = [k for k, v in sr_caught.items() if not v]
        host_ok = sr["host_managed_files"] == 1 and len(sr["backup_dir_in_root"]) == 1
        print(("  PASS" if not sr_missing and host_ok else "  FAIL") +
              "  skills 根四类发现全部检出且宿主自管项不误报"
              + ("" if not sr_missing else f"（漏: {sr_missing}）")
              + ("" if host_ok else "（宿主自管项计数不符）"))

        ok = (not missing_kinds and core_only and negative and partial
              and gap_ok and jump_ok and ex_ok and not sr_missing and host_ok)
        if ok:
            print("audit_archive 自证: 7/7 PASS")
            return 0
        return 1


def main() -> int:
    p = argparse.ArgumentParser(description="归档中心记录外完整性审计 + skills 根卫生体检 + 版本空洞提示（只读）")
    p.add_argument("--archive-root", default=str(Path.home() / ".workbuddy" / "skill-release-archive"))
    p.add_argument("--skills-root", default="", help="可选：一并体检 skills 根（备份污染 / 非法目录 / 杂散 zip）")
    p.add_argument("--json", dest="json_out")
    p.add_argument("--gaps-list", dest="gaps_list", help="可选：把未豁免的版本空洞写成待寻清单（markdown）")
    p.add_argument("--strict-gaps", action="store_true",
                   help="把未豁免的版本区间空洞计入失败（默认只提示，不计入）")
    p.add_argument("--max-outlier-ratio", type=float, default=DEFAULT_OUTLIER_RATIO)
    p.add_argument("--no-zip-read", action="store_true", help="跳过 zip 可读性检查（省时，用于超大归档）")
    p.add_argument("--self-check", action="store_true")
    a = p.parse_args()
    try:
        if a.self_check:
            return self_check()
        if a.max_outlier_ratio <= 0 or math.isnan(a.max_outlier_ratio):
            raise ValueError("--max-outlier-ratio 须为正数")
        root = Path(a.archive_root).expanduser()
        f = audit(root, a.max_outlier_ratio, not a.no_zip_read)
        if a.skills_root:
            sr = audit_skills_root(Path(a.skills_root).expanduser(), root)
            f["skills_root_findings"] = sr
            f["total"] += sr["total"]
        report(f)
        if a.gaps_list:
            write_gaps_list(f, Path(a.gaps_list))
            print("[audit] 待寻清单: " + str(Path(a.gaps_list)))
        if a.json_out:
            outp = Path(a.json_out)
            outp.parent.mkdir(parents=True, exist_ok=True)
            outp.write_text(json.dumps(f, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print("[audit] 报告: " + str(outp))
        total = f["total"] + (f["advisory"] if a.strict_gaps else 0)
        return 0 if total == 0 else 1
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError, zipfile.BadZipFile) as e:
        print("[audit-archive][ERROR] " + str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
