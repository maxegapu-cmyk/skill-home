#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""归档中心随迁包产出器（skill-archive-manager 自带）。

把用户级 Skill 归集管理中心（默认 <归档根>）整体打成
可校验、可脱敏、只读来源的随迁包，供与元 skill 一起跨机迁移。

用法:
    python pack_archive_snapshot.py                       # 默认归档根，输出到当前目录
    python pack_archive_snapshot.py --archive-root <目录> --out <目录>
    python pack_archive_snapshot.py --archive-root <目录> --out <目录> --version 2026.09.11
    python pack_archive_snapshot.py --archive-root <目录> --out <目录> --dry-run
    python pack_archive_snapshot.py --check <随迁包解压目录>
    python pack_archive_snapshot.py --self-check

行为:
  1. 只读复制归档中心（绝不删除/移动来源）；排除 __pycache__ 与 *.pyc。
  2. 文本文件中的本机绝对家目录路径脱敏为 <USER_HOME>（跨机可迁移）。
  3. 写 MANIFEST.json + MANIFEST.sha256，逐文件记录 size 与 sha256。
  4. 打成 archive-center-snapshot-v<version>.zip；--check 校验清单与内容。
  5. 目标目录已存在时中止，--force 才先备份后重建。
退出码: 0 = 成功；1 = 失败。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass

NAME = "archive-center-snapshot"
IGNORED = {"__pycache__", ".DS_Store", ".git"}
# --slim 剔除的取证类目录：conflicts/ 是「同名不同哈希」留证副本，cleanup-backups/ 是清理前快照。
# 二者都不参与权威版本复现，只是回滚与追责底料，因此在迁移包里按目录名整体排除。
FORENSIC_DIRS = {"conflicts", "cleanup-backups"}
BINARY_SUFFIX = {".zip", ".png", ".jpg", ".jpeg", ".gif", ".pdf", ".xlsx", ".pyc"}
WIN_HOME = re.compile(r"(?i)[A-Z]:\\Users\\[^\\\s\"']+")
UNIX_HOME = re.compile("/" + "home/" + r"[^/\s\"']+")


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            h.update(b)
    return h.hexdigest()


def version_key(name: str):
    return [int(n) for n in re.findall(r"\d+", name)]


def slim_kept_migrations(root: Path) -> set:
    """--slim：每个 migrations/ 目录只保留版本号最大的那一个包。"""
    keep = set()
    for md in Path(root).rglob("migrations"):
        if not md.is_dir():
            continue
        zips = [p for p in md.glob("*.zip") if p.is_file()]
        if zips:
            newest = max(zips, key=lambda p: version_key(p.name))
            keep.add(newest.relative_to(root).as_posix())
    return keep


def kept_files(root: Path, slim: bool = False):
    root = Path(root)
    kept_migrations = slim_kept_migrations(root) if slim else None
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        if any(part in IGNORED for part in rel.parts):
            continue
        if slim:
            if any(part in FORENSIC_DIRS for part in rel.parts):
                continue
            if "migrations" in rel.parts and rel.as_posix() not in kept_migrations:
                continue
        yield p, rel


def copy_tree_redacted(src: Path, dst: Path, slim: bool = False) -> int:
    """只读复制；文本脱敏家目录。返回脱敏处数。"""
    redactions = 0
    for p, rel in kept_files(src, slim):
        target = Path(dst) / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix.lower() in BINARY_SUFFIX:
            shutil.copy2(p, target)
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            shutil.copy2(p, target)
            continue
        new, a = WIN_HOME.subn("<USER_HOME>", text)
        new, b = UNIX_HOME.subn("<USER_HOME>", new)
        redactions += a + b
        target.write_text(new, encoding="utf-8")
    return redactions


def listed_files(root: Path):
    return [p for p, _ in kept_files(root) if p.name not in {"MANIFEST.json", "MANIFEST.sha256"}]


def write_manifest(root: Path, version: str, redactions: int, slim: bool = False) -> dict:
    root = Path(root)
    data = {
        "schema": 1,
        "name": NAME,
        "version": version,
        "category": "archive-center",
        "slim": bool(slim),
        "created_at": now(),
        "redactions": redactions,
        "files": [
            {"path": p.relative_to(root).as_posix(), "size": p.stat().st_size, "sha256": digest(p)}
            for p in listed_files(root)
        ],
    }
    mp = root / "MANIFEST.json"
    mp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (root / "MANIFEST.sha256").write_text(digest(mp) + "  MANIFEST.json\n", encoding="ascii")
    return data


def zip_dir(root: Path, target: Path) -> None:
    temp = Path(str(target) + ".tmp")
    temp.unlink(missing_ok=True)
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(Path(root).rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root).as_posix())
    os.replace(temp, target)


def prepare(path: Path, force: bool) -> None:
    path = Path(path)
    if path.exists():
        if not force:
            raise FileExistsError(f"已存在 {path}；使用 --force 会先备份")
        backup = path.with_name(path.name + ".bak-" + str(int(time.time())))
        os.replace(path, backup)
        print("[pack] 旧目录已备份: " + str(backup))
    path.mkdir(parents=True)


def verify(root: Path) -> tuple[bool, str]:
    root = Path(root)
    mp = root / "MANIFEST.json"
    sp = root / "MANIFEST.sha256"
    if not mp.is_file() or not sp.is_file():
        return False, "缺 manifest"
    if digest(mp) != sp.read_text(encoding="ascii").split()[0]:
        return False, "manifest 哈希不匹配"
    data = json.loads(mp.read_text(encoding="utf-8"))
    listed = set()
    for item in data.get("files", []):
        raw = item.get("path", "")
        rel = Path(raw)
        if rel.is_absolute() or ".." in rel.parts or raw in listed:
            return False, "manifest 路径非法或重复: " + str(raw)
        listed.add(raw)
        p = root / rel
        if not p.is_file() or p.stat().st_size != item["size"] or digest(p) != item["sha256"]:
            return False, "文件校验失败: " + item["path"]
    actual = {p.relative_to(root).as_posix() for p in listed_files(root)}
    if actual != listed:
        return False, (f"manifest 文件集合不一致（多出 {sorted(actual - listed)[:3]}，"
                       f"缺少 {sorted(listed - actual)[:3]}）")
    return True, f"{data.get('category')} v{data.get('version')}，{len(data.get('files', []))} 个文件"


def do_pack(a) -> int:
    src = Path(a.archive_root).expanduser().resolve()
    if not src.is_dir():
        raise FileNotFoundError("归档根不存在: " + str(src))
    version = a.version or datetime.now().strftime("%Y.%m.%d")
    out = Path(a.out or os.getcwd()).resolve()
    stage_name = f"{NAME}-v{version}"
    if a.dry_run:
        n = len(list(kept_files(src, a.slim)))
        mode = "（--slim）" if a.slim else ""
        print(f"[dry-run] 将打包 {n} 个文件{mode}：{src} -> {out / stage_name}(.zip)；不写盘")
        return 0
    out.mkdir(parents=True, exist_ok=True)
    stage = out / stage_name
    prepare(stage, a.force)
    redactions = copy_tree_redacted(src, stage, a.slim)
    # 管理状态随仓库迁移：目标机可据此继续处理未闭合行动项；状态文件本身不改变权威归档包。
    state = stage / "MANAGEMENT-STATE.json"
    queue = stage / "ACTION-QUEUE.json"
    if state.is_file() or queue.is_file():
        print("[pack] 已携带管理状态与行动队列")
    write_manifest(stage, version, redactions, a.slim)
    zp = out / f"{stage_name}.zip"
    zip_dir(stage, zp)
    print("[pack] 归档中心随迁包: " + str(zp))
    tag = "（--slim，已剔除留证/清理前备份，仅保留最新迁移包）" if a.slim else ""
    print(f"[pack] 文件数 {len(listed_files(stage))}，脱敏 {redactions} 处{tag}；用 --check 校验")
    return 0


def self_check() -> int:
    """证明：打包可校验、脱敏生效、篡改被拦截。"""
    with tempfile.TemporaryDirectory(prefix="archive-snapshot-selfcheck-") as raw:
        base = Path(raw)
        arc = base / "archive"
        (arc / "demo-skill" / "history").mkdir(parents=True)
        (arc / "demo-skill" / "history" / "demo-skill-v0.1.0.zip").write_bytes(b"PK\x03\x04fake")
        # 家目录路径动态拼接，避免源码内出现字面本机绝对路径（跨 agent 可安装性要求）。
        sep = chr(92)
        fake_home = "C:" + sep + "Users" + sep + "tester"
        fake_unix = "/" + "home" + "/" + "tester"
        (arc / "demo-skill" / "INDEX.json").write_text(
            '{"skill":"demo-skill","root":"' + fake_home + '"}', encoding="utf-8")
        (arc / "MANAGED_SKILLS.json").write_text(
            '{"archive_root":"' + fake_home + sep + 'skill-release-archive",'
            '"alt_root":"' + fake_unix + '"}', encoding="utf-8")
        out = base / "out"
        a = argparse.Namespace(archive_root=str(arc), out=str(out), version="0.0.1",
                               force=False, dry_run=False, slim=False)
        if do_pack(a):
            print("  FAIL  打包")
            return 1
        zpath = out / f"{NAME}-v0.0.1.zip"
        extracted = base / "extracted"
        with zipfile.ZipFile(zpath) as z:
            z.extractall(extracted)
        ok, detail = verify(extracted)
        redacted = "<USER_HOME>" in (extracted / "MANAGED_SKILLS.json").read_text(encoding="utf-8")
        positive = ok and redacted and all(
            "tester" not in (extracted / rel).read_text(encoding="utf-8")
            for rel in ("MANAGED_SKILLS.json", "demo-skill/INDEX.json")
        )
        print(("  PASS" if positive else "  FAIL") + "  打包可校验且家目录路径已脱敏  —— " + detail)
        victim = extracted / "demo-skill" / "INDEX.json"
        victim.write_text(victim.read_text(encoding="utf-8") + "\n# tampered\n", encoding="utf-8")
        broken, _ = verify(extracted)
        negative = not broken
        print(("  PASS" if negative else "  FAIL") + "  篡改后由 manifest 反证拦截")
        # --slim 反证：留证副本、清理前备份与旧迁移包必须一个都不进包。
        slim_src = base / "archive-slim"
        (slim_src / "demo-skill" / "migrations").mkdir(parents=True)
        (slim_src / "demo-skill" / "conflicts").mkdir(parents=True)
        (slim_src / "00-管理入口" / "cleanup-backups").mkdir(parents=True)
        (slim_src / "demo-skill" / "INDEX.json").write_text('{"skill":"demo-skill"}', encoding="utf-8")
        (slim_src / "demo-skill" / "migrations" / "demo-skill-migration-v0.1.0.zip").write_bytes(b"old")
        (slim_src / "demo-skill" / "migrations" / "demo-skill-migration-v0.9.0.zip").write_bytes(b"new")
        (slim_src / "demo-skill" / "conflicts" / "demo-skill-v0.1.0--deadbeef.zip").write_bytes(b"ev")
        (slim_src / "00-管理入口" / "cleanup-backups" / "before-cleanup.zip").write_bytes(b"bak")
        slim_out = base / "out-slim"
        slim_args = argparse.Namespace(archive_root=str(slim_src), out=str(slim_out),
                                       version="0.0.2", force=False, dry_run=False, slim=True)
        if do_pack(slim_args):
            print("  FAIL  --slim 打包")
            return 1
        with zipfile.ZipFile(slim_out / f"{NAME}-v0.0.2.zip") as z:
            slim_names = set(z.namelist())
        slim_ok = (not any("conflicts" in n for n in slim_names)
                   and not any("cleanup-backups" in n for n in slim_names)
                   and "demo-skill/migrations/demo-skill-migration-v0.9.0.zip" in slim_names
                   and "demo-skill/migrations/demo-skill-migration-v0.1.0.zip" not in slim_names)
        print(("  PASS" if slim_ok else "  FAIL") +
              "  --slim 剔除留证副本与清理前备份，且每个 migrations/ 只留最新包")
        if positive and negative and slim_ok:
            print("pack_archive_snapshot 自证: 3/3 PASS")
            return 0
        return 1


def main() -> int:
    p = argparse.ArgumentParser(description="归档中心随迁包产出器（只读来源、可校验、可脱敏）")
    p.add_argument("--archive-root", default=str(Path.home() / ".workbuddy" / "skill-release-archive"))
    p.add_argument("--out")
    p.add_argument("--version")
    p.add_argument("--slim", action="store_true",
                   help="只带权威可复现部分：剔除 conflicts/ 与 cleanup-backups/，migrations/ 只留最新包")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--force", action="store_true")
    p.add_argument("--check")
    p.add_argument("--self-check", action="store_true")
    a = p.parse_args()
    try:
        if a.self_check:
            return self_check()
        if a.check:
            ok, detail = verify(Path(a.check).resolve())
            print(("[check][OK] " if ok else "[check][FAIL] ") + detail)
            return 0 if ok else 1
        if not a.out and not a.dry_run:
            p.error("缺少 --out（或使用 --dry-run 预览）")
        return do_pack(a)
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError, zipfile.BadZipFile) as e:
        print("[archive-snapshot][ERROR] " + str(e), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
