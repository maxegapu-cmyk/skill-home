> 摘要：用户级 Skill 归集管理中心的目录结构、各级文件角色与 INDEX 字段说明；用于判断「该改哪一层、--archive-dir 到底是哪个目录」。何时读全文：第一次接触归档目录、需要定位权威登记表、或排查校验漂移时。

# 归集中心目录结构

默认归档根：`ARCHIVE = <归档根>`（可用 `--archive-root` 覆盖）。

```text
ARCHIVE/
  00-管理入口/
    README.md
    Skill发布归集管理中心.html     # 顶层管理页（--refresh 生成）
  MANAGED_SKILLS.json               # 跨 skill 统一登记表（--refresh 生成）
  <skill-name>/                     # 每个 skill 一个子目录 = archive-dir
    INDEX.json                      # 权威登记（机器读）
    INDEX.md                        # 权威登记（人读）
    history/                        # 常规发布包：<name>-v<x.y.z>.zip
    migrations/                     # 一键迁移包
    conflicts/                      # 同名不同哈希的留证副本
```

## 三层职责

| 层 | 路径 | 谁生成 | 作用 |
|---|---|---|---|
| 顶层 | `ARCHIVE/00-管理入口/`、MANAGED_SKILLS.json | skill_release_hub.py --refresh | 跨 skill 总览与管理页 |
| 单 skill | `ARCHIVE/<skill>/INDEX.json\|INDEX.md` | archive_releases.py | 该 skill 的权威版本台账 |
| 包 | `<skill>/history/`、`migrations/`、`conflicts/` | 打包器 + 归集器 | 实际发布物 / 迁移包 / 留证副本 |

## 关键判据

- **`--archive-dir` = `<ARCHIVE>/<skill-name>`（单 skill 子目录）**，不是归档根。用归档根跑 `archive_releases.py --verify` 会报「缺 INDEX.json」。
- **`--archive-root` = `ARCHIVE`**，只给 skill_release_hub.py 用。
- `conflicts/` 里的文件名形如 `<name>-v<x.y.z>--superseded-<hash12>.zip` 或 `<name>-v<x.y.z>--<hash12>.zip`；它们是证据，不得删。

## INDEX 记录字段（每条）

`kind`（history/migration/conflict）、`version`、`file`、`sha256`、`zip_entries`、`bytes`、`collected_at`（真实归集时刻；历史记录可能标「未知」）。

## 常见异常

| 现象 | 含义 | 处理 |
|---|---|---|
| `缺 INDEX.json` | 该目录不是单 skill archive-dir | 换到 `<ARCHIVE>/<skill>` |
| `哈希漂移` | 归档包被改动或与登记不符 | 查来源，重打包重归集，勿改登记表 |
| `同名不同哈希` | 版本碰撞 | 见 SKILL.md 阶段三 |
