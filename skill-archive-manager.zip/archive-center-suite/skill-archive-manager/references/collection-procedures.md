> 摘要：归集管理中心的完整标准命令集——归集、校验、冲突处理、刷新管理页、以及自证自检；含参数口径与完成判据。何时读全文：执行任一阶段需要照抄命令、或确认参数含义时。

# 归集中心标准命令集

所有脚本位于元 skill 的脚本目录：`SKILL_ARCH = <本套件的内部工具链 安装目录>/scripts`（默认 `<skills根>/本套件的内部工具链/scripts`）。变量：`SKILLS`=skills 根（默认 `~/.workbuddy/skills`）、`ARCHIVE`=归档根（默认 `<归档根>`）。

## 一、归集（Collect）

```bash
cd "$SKILL_ARCH"
python pack_skill.py "$SKILLS/<skill>" --zip-dir <staging> --archive-dir "$ARCHIVE/<skill>"
```

- 打包后自校验：源目录与 zip **文件集合 + 逐文件 sha256 完全一致**才继续。
- 目标 zip 已同名存在 → 报错中止（防覆盖历史回滚源）；确需重打同版本才加 `--force`。
- `--force` 同时等价 `--promote`（详见阶段三）。
- **`--zip-dir` 可省略（v0.93.4 起）**：元 skill 的默认落点已是 skills 根之外的暂存目录（`$SKILL_ARCHITECT_BUILD_DIR/<skill>` 或 `~/.workbuddy/skill-builds/<skill>`，由元 skill 的 scripts/_paths.py 统一解析）；省略不会再污染运行目录。仅当元 skill 版本 ≤v0.93.3（默认值仍为 skill 父目录 = skills 根）时，才必须显式指向临时 staging。包归集后可清理 staging。

## 二、校验（Verify）

```bash
# 记录内一致性（已登记记录的哈希 / zip CRC / 条目数）
python archive_releases.py --verify "$ARCHIVE/<skill>"
python skill_release_hub.py --skills-root "$SKILLS" --archive-root "$ARCHIVE" --verify
# 记录外完整性（未登记文件 / 不可读 zip / 体积离群）——本 skill 负责
python <本 skill>/scripts/audit_archive.py --archive-root "$ARCHIVE" --json <报告.json>
# 发布物落点体检（备份污染 / 非法目录 / 杂散 zip）
python <本 skill>/scripts/audit_archive.py --archive-root "$ARCHIVE" --skills-root "$SKILLS"
# 版本区间空洞（提示）：打印 + 写待寻清单
python <本 skill>/scripts/audit_archive.py --archive-root "$ARCHIVE" --gaps-list <待寻清单.md>
# 需要把未豁免空洞当门禁时
python <本 skill>/scripts/audit_archive.py --archive-root "$ARCHIVE" --strict-gaps
# 随迁包自身校验
python <本 skill>/scripts/pack_archive_snapshot.py --check <随迁包目录>
```

完成判据：`[verify][OK] / [check][OK]`，且审计输出 `审计结论：无发现`（含 skills 根四类体检项）。

- 审计四类发现：`unreadable`（zip 截断/损坏）、`orphan`（未被 INDEX 登记）、`missing`（记录的文件不存在）、`size_outlier`（体积远超同类型中位数）。
- `conflicts/` 是设计上不入册的留证目录，不参与 orphan 判定；发现坏包先**隔离后重跑**，不在归档内直接删。
- 版本层两类提示：`version_gap`（同段补丁号缺失，可精确枚举）、`version_span_jump`（跨整段缺失，无法枚举）。**默认不计入失败**——补丁号并非必然发布；`--strict-gaps` 才把未豁免项计入失败（退出码 1）。

## 二·补、版本空洞与豁免清单

三个盲区分工要记住：**记录内**（`--verify`）管已登记记录自洽；**记录外**（第一段）管「有文件、无登记」；**版本层**（本段）管「无文件、也无登记」的谱系空洞——曾有一个跨 24 个版本的整段空洞长期存在，前两种校验全部报绿。

```bash
# 写待寻清单（markdown）：拿去持有历史包的机器按图索骥
python <本 skill>/scripts/audit_archive.py --archive-root "$ARCHIVE" --gaps-list <待寻清单.md>
# 找到包后补齐（来源目录里放 <name>-v<x.y.z>.zip）
cd "$SKILL_ARCH"
python archive_releases.py --skill-dir "$SKILLS/<skill>" --archive-dir "$ARCHIVE/<skill>" --history-source <来源目录>
```

已确认可接受的缺失，登记在该 skill 归档目录下的 known-gaps.json（按 kind + from + to 精确匹配）：

```json
{"schema": 1, "skill": "<name>", "known_missing": [
  {"kind": "patch", "from": "1.0.6", "to": "1.0.9",
   "reason": "与持有人确认 1.0.7/1.0.8 从未发布", "recorded_at": "YYYY-MM-DD", "evidence": "…"}]}
```

- kind 取 `patch`（对应同段补丁空洞）或 `span`（对应跨段跳跃）。
- 登记后该项转为「已豁免」，不再进待寻清单；未豁免项在报告里标 `[待确认]`。该文件放在 skill 归档目录根下，不在 history/migrations/conflicts 内，不参与 orphan 判定。
- 边界：**只有拿到依据才登记豁免**。没有依据时，空洞就以提示形式留在报告里——不得为了「报告变干净」而豁免或改判据。

## 三、冲突处理（Conflict）

默认（留证不晋升，安全）：

```bash
# 直接归集即可：同名不同哈希的包会自动落入 conflicts/，权威不动
python pack_skill.py "$SKILLS/<skill>" --zip-dir <staging> --archive-dir "$ARCHIVE/<skill>"
```

显式晋升（仅当用户明确认定新来源为权威）：

```bash
python pack_skill.py "$SKILLS/<skill>" --zip-dir <staging> --archive-dir "$ARCHIVE/<skill>" --force
# 旧权威 → conflicts/<name>-v<x>--superseded-<hash12>.zip
```

## 四、刷新管理页（Refresh）

```bash
python skill_release_hub.py --skills-root "$SKILLS" --archive-root "$ARCHIVE" --refresh
```

前置：`$SKILLS` 下不得有 `.backup_*` / `_backup-*` 等同名备份目录，否则会被登记成 skill 污染 MANAGED_SKILLS.json。

## 五、随迁（Migrate）

```bash
# 归档中心随迁包（跨机迁移加 --slim；要完整取证快照则不加）
python <本 skill>/scripts/pack_archive_snapshot.py --archive-root "$ARCHIVE" --out <out> --slim
# 元 skill + 全部配套迁移包
python "$SKILL_ARCH/pack_migration.py" "$SKILLS/本套件的内部工具链" --out <out> \
  --with-companion "$SKILLS/skill-scorer" \
  --with-companion "$SKILLS/agent-harness-loop" \
  --with-companion "$SKILLS/skill-archive-manager"
```

- `--slim` 口径：剔除 `conflicts/` 与 `cleanup-backups/`，每个 `migrations/` 只留最新包。这三类是取证与回滚底料，迁移时无用却占主体（实测 314 文件 / 304 MB → 159 文件 / 68 MB）。
- 迁移包只负责「搬走」档案，**不清理来源**：`conflicts/` 与 `cleanup-backups/` 在原机原地保留。

## 六、skills 根卫生体检

`$SKILLS` 既是加载器的扫描面，也是发布物最容易堆错的地方。四类发现与处置：

| 发现 | 含义 | 处置 |
|---|---|---|
| `backup_dir_in_root` | 备份目录（`.backup_*` / `_backup-*`）留在根内 | **必须移出**到 `~/.workbuddy/skills-backups/`——否则加载器把它当同名 skill 解析并抢占真身 |
| `dir_without_skill_md` | 目录缺 SKILL.md | 确认用途后移出或补 SKILL.md |
| `zip_unique` | 杂散 zip 且归档无此内容 | **先归集再移**——先移即失传 |
| `zip_redundant` | 杂散 zip 与归档逐字节相同 | 纯冗余，可安全移出（保留不删 + 留 MANIFEST 可回滚） |

移出冗余包的准则（实测流程）：① 先按 sha256 与归档中心全量比对，只挑**确已存在**的；② 分批移动（每批 10 个），批后逐个复核哈希一致，任一不符即停；③ 目标目录附一份 MANIFEST.json 记录原始路径 / 体积 / 哈希 / 归档对照，可原路回滚；④ 宿主自管项（`.deps`、`.skill-install-backups`、`*migration.json`）一律不碰。

## 自证自检（改脚本后必跑）

```bash
python archive_releases.py --self-test
python skill_release_hub.py --self-test
python pack_migration.py --self-check
python <本 skill>/scripts/pack_archive_snapshot.py --self-check
python <本 skill>/scripts/audit_archive.py --self-check
```

任一 `FAIL` 即阻断；`--self-test` 用正反例比对完整 FAIL 集合，防机制静默失效。
