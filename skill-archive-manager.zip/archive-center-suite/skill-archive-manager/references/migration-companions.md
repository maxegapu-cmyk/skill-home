> 摘要：元 skill `本套件的内部工具链` 的配套清单（哪些 skill 与数据必须一起迁移）、配套打包规则、以及一条可照抄的「元 skill + 全部配套 + 归集中心」迁移命令。何时读全文：要跨机迁移元 skill、或核对配套是否齐全时。

# 配套清单与随迁规则

「配套」= 迁移元 skill 时必须一起带走的资产。分两类：**配套 skill** 与 **数据资产**。

## 一、配套清单（canonical）

| 类型 | 名称 | 说明 |
|---|---|---|
| 配套 skill | `skill-scorer` | 元 skill 的评分伴生 skill |
| 配套 skill | `agent-harness-loop` | 元 skill 交叉引用的护栏/循环 skill（外置一致性承接方） |
| 配套 skill | `skill-archive-manager` | 本 skill，归集中心操作入口 |
| 配套 skill | `skill-distribution-manager` | 便携分发与外层包组装入口 |
| 配套 skill | `code-repair-regression` | 元级程序员：代码分析、重构、修复与真实回归验收 |
| 配套 skill | `skill-bidirectional-migration` | 双向互迁增量包工作流：前向复用元 skill 体系，反向 JIT 构建本机→源机增量包（实时 diff + 自研增量+历史+本机检查点，自动排除第三方） |
| 数据资产 | 归集管理中心 `ARCHIVE`（默认 `<归档根>`） | 全部版本历史/迁移包/冲突留证，非 skill 目录（无 SKILL.md） |

该清单是权威口径：新增/退役配套须同步本表与 SKILL.md「配套与迁移」小节。

## 二、打包规则（与元 skill 一致）

- **主 skill**（`本套件的内部工具链`）可带历史与私有上下文（`--with-history` / `--with-memory`）。
- **配套 skill** 只带**最新版本源码、安装器与最新常规包**，不带历史 / 冲突 / 旧迁移包（元 skill 的迁移包产出器自动剥离 history/ migrations/ conflicts/ memory/）。
- **配套只打包、不自动安装**：目标机需显式 `python migrate.py --with-companion <名称> --apply` 才安装。
- **数据资产**（归档中心）无 SKILL.md，**不能**当 `--with-companion`；由本 skill 的 `pack_archive_snapshot.py` 打成独立随迁包，随迁移集一起传送。

## 三、标准迁移流程

```bash
SKILLS=~/.workbuddy/skills
ARCHIVE=<归档根>
ARCH=<skills根>/本套件的内部工具链/scripts
OUT=<迁移输出目录>

# 1) 元 skill 核心包 + 全部配套（逐个 --with-companion）
python "$ARCH/pack_migration.py" "$SKILLS/本套件的内部工具链" --out "$OUT" \
  --with-history "$ARCHIVE/本套件的内部工具链/history" \
  --with-companion "$SKILLS/skill-scorer" \
  --with-companion "$SKILLS/agent-harness-loop" \
  --with-companion "$SKILLS/skill-archive-manager" \
  --with-companion "$SKILLS/skill-distribution-manager" \
  --with-companion "$SKILLS/code-repair-regression" \
  --with-companion "$SKILLS/skill-bidirectional-migration"

# 2) 归集中心随迁包（本 skill 负责）
python "$SKILLS/skill-archive-manager/scripts/pack_archive_snapshot.py" \
  --archive-root "$ARCHIVE" --out "$OUT"

# 3) 校验
python "$ARCH/pack_migration.py" --check "$OUT/本套件的内部工具链-migration-v<版本>"
python "$SKILLS/skill-archive-manager/scripts/pack_archive_snapshot.py" --check "$OUT/archive-center-snapshot-v<版本>"
```

## 四、验收判据

- 迁移说明 MIGRATE.md 的「随迁资产清单」列出主 skill、历史、私有上下文、**全部配套 skill**、Python 依赖五类；配套一栏须含上表六个 skill。
- 核心迁移包 `--check` OK；归档中心随迁包 `--check` OK。
- 目标机安装后：元 skill 版本不变、六个配套各带自身 `name/version`、归档中心随迁包可解压并 `verify`。
