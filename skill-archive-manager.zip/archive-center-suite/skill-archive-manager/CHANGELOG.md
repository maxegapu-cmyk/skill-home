# skill-archive-manager 变更记录

## v0.6.1 · 2026-09-14 新增「新 skill 创建即归档（创建门禁）」

- 新增全局决策规则「新 skill 创建即归档（创建门禁）」：任何新自研 skill 产出后必须同步 `pack_skill.py --archive-dir <ARCHIVE>/<skill>` 生成发布包并归集；每次迭代发版同理。归档中心 `history/` 只保留一份权威副本（`archive_releases` 去重：同名同哈希跳过、同名异哈希进 `conflicts/` 留证，绝不覆盖回滚源）；归档后清理 staging 副本（`~/.workbuddy/skill-builds/<skill>/`），禁止在 skills 根或 staging 留散包。
- 触发：用户要求把「创建新 skill 必须同步做发布包存档、迭代历史包自动归档、只留一份不重复留存」固化为强制纪律；本 skill 作为归档治理中枢，须先把该门禁写进自身规则。
- 自举闭环：本版自身即按该门禁执行——改完 SKILL.md（doc 级规则）后递增 version 至 0.6.1、记本条目、跑 `dev_check.py --full` 全 PASS，再 `pack_skill.py --archive-dir` 重归档（history/ 只留 0.6.1 一份，清 staging）。
- 安全审计: P2（纯文档规则补充，无脚本、无外部写入、无网络）。
- 影响载体：SKILL.md、CHANGELOG.md、VERIFICATION.md。

## v0.6.0 · 2026-09-13 从登记员升级为归档中心管理者

- 新增 `scripts/archive_manager.py` 统一管理入口：健康扫描、双向对账、问题队列、唯一 finding_id、P0/P1 分级、管理状态、迁移复核。
- 新增 `MANAGEMENT-STATE.json`、`ACTION-QUEUE.json`、`ACTION-QUEUE.md`：把发现转成可持续跟踪的管理事项，支持 open/confirmed/planned/resolved/waived/blocked 生命周期。
- 随迁快照携带管理状态和行动队列，目标机不只恢复仓库文件，也恢复未闭合管理工作。
- 定位明确：本 skill 是归档中心管理者，归集/登记只是其中一环；不自动删除、移动或覆盖权威归档实物。
- 安全审计: P2（管理状态写入仅在 `--apply`，不改归档包，不联网）。

## v0.5.0 · 2026-09-13 登记员⇄仓库双向对账强联动

- `scripts/audit_archive.py` 新增 `reconcile_ledger()`：把 `MANAGED_SKILLS.json`（登记员总台账）与归档中心实际 skill 子目录（仓库）做双向对账。
- 新增硬发现：`ledger_no_warehouse`（台账登记但仓库无目录）、`warehouse_no_ledger`（仓库有目录但总台账漏登）；两类均纳入 `total` 与退出码，不能再出现“打印有问题但进程返回 0”。
- 新增提示：`version_stale`（总台账版本与源码 frontmatter 版本不一致），用于刷新管理页前发现陈旧登记，不默认计入失败。
- 报告新增“登记员 ⇄ 仓库双向对账”区块，明确 15 项硬失配与版本陈旧的处理方向。
- 自证保持 `audit_archive` 7/7 PASS；真实核查首次发现 11 个台账空头项、4 个仓库漏登项、4 个版本陈旧项。
- 安全审计: P2（只读扫描；仅显式 `--json`/`--gaps-list` 写报告，不改归档、不删文件、不联网）。
- 影响载体：`SKILL.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`、`scripts/audit_archive.py`。

## v0.4.2 · 2026-09-12 示例补齐与判据可机读化

- 补齐：正文新增 2 处示例（`--archive-dir` 传单 skill 子目录 vs 误传归档根；本 skill 只归集不重打包），示例标记 1 → 3。
- 说明：v0.4.1 及此前条目的审计等级多为全角冒号（「安全审计：P2」），机器判据（`审计[::]?\s*P[012]`）不识别全角，此前靠历史条目中的半角形态才被判为有留痕——属于依赖巧合。本版起新条目统一半角冒号，历史条目形态保留不改写。
- 安全审计: P2（纯文档补充，无脚本、无外部写入、无网络）。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md。

## v0.4.1 · 2026-09-11 随元 skill 落点契约变更同步

- 背景：元 skill v0.93.4（G-31）把 `pack_skill.py` / `dev_check.py` / `verify_delivery.py` 的 `--zip-dir` 默认落点从 `root.parent`（= skills 根 = 宿主加载器扫描路径）移出，改为 `$SKILL_ARCHITECT_BUILD_DIR/<skill>` 或 `~/.workbuddy/skill-builds/<skill>`，并新增 `scripts/_paths.py` 作为落点与历史检索契约的单一权威。
- 同步内容（本 skill 侧只改约定表述，不改任何脚本）：
  - `SKILL.md` 阶段一硬约定由「**绝不允许省略** `--zip-dir`（默认值是 skills 根）」改为「**可省略**——v0.93.4 起默认落点已在 skills 根之外；仅元 skill ≤v0.93.3 时必须显式指定 staging」。
  - `references/collection-procedures.md` 第一节同源更新，并补 `_paths.py` 为权威解析器。
- 影响：本 skill 的归集命令在调用元 skill ≥v0.93.4 时不再强制省略即污染；对 ≤v0.93.3 的旧元 skill 仍保留显式 staging 的硬要求，避免历史版本的默认落点把包堆进运行目录。
- 安全审计：P2（纯文档同步，无脚本、无外部写入、无网络）。
- 影响载体：SKILL.md、references/collection-procedures.md、README/CHANGELOG/VERIFICATION/EXPERIENCE。

## v0.4.0 · 2026-09-11 版本区间空洞检测 + 已知缺失豁免（落地 E-07）
- `scripts/audit_archive.py` 新增第三段发现「版本区间空洞」（**提示**性质，非缺陷断言）：
  - `version_gap`——同一主次版本号内相邻在档版本之间缺补丁号，**可精确枚举**缺失版本；
  - `version_span_jump`——相邻在档版本之间跨整段（次版本号差 > 1 或大版本号不同），无法枚举。
- 新增 `--gaps-list <文件>`：把未豁免空洞写成「待寻清单」（markdown，含补齐命令），拿去持有历史包的机器按图索骥。新增 `--strict-gaps`：把未豁免空洞计入失败（退出码 1）；默认只提示——semver 补丁号并非必然发布，缺某个号不等于该号发布过，无外部依据时不可断言为缺陷。
- 新增豁免机制：`<归档>/<skill>/known-gaps.json` 的 known_missing 列表，按 kind + from + to 精确匹配（kind 取 `patch` / `span`）；登记后该项转「已豁免」，不再进待寻清单。该文件位于 skill 归档目录根下，不参与 orphan 判定。
- 动机（实测）：上一版只登记了「谱系空洞」盲区（E-07），本轮落地检测后即在真实归档上查出 3 处提示——`0.86.6→0.86.9`（缺 0.86.7 / 0.86.8）、`0.87.10→0.87.17`（缺 0.87.11~0.87.16）、`0.91.10→0.93.3`（中间整段 0.92.* 无任何在档版本）。三种盲区分工至此闭合：记录内（`--verify`）→ 记录外（有无登记）→ 版本层（有无谱系）。
- 排序判据：必须按**版本号**（x.y.z 三元组）排序，不能按文件名——`v0.91.10` 按名字会排到 `v0.91.3` 之前，用文件名排序会把空洞判错位置（实测踩到）。
- 自证 4/4 → **7/7**：新增「版本提示不计入失败计数」「补丁空洞可精确枚举 + 跨段跳跃可检出」「豁免清单精确生效」三项。（首跑第 5 项 FAIL，根因仍是**夹具设计**：区间里夹了中间版本 1.1.0，跨段幅度只剩 1，跳跃判据不触发——修夹具而非改判据。）
- 安全审计：新增代码只读 INDEX.json 与 known-gaps.json，无命令执行、无网络请求、无依赖安装、不写归档、不删不移；`--gaps-list` 只写调用方显式给出的路径。结论 **P2 放行（Benign）**。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md、EXPERIENCE.md、references/collection-procedures.md、scripts/audit_archive.py。

## v0.3.1 · 2026-09-11 使用复盘：记入「谱系空洞」盲区
- 新增经验 E-07：本轮用本 skill 补齐 本套件的内部工具链 历史链（v0.87.17~v0.91.10，24 个包）时发现，**「记录内一致」与「记录外无脏物」两种校验都查不出「整段版本缺失」**——归档曾长期存在一个跨 24 个版本的空洞（v0.87.10 之后直接跳到 v0.93.3），而 `archive_releases.py --verify` 与 `audit_archive.py` 全部报绿。这是与「记录外盲区」方向相反的第二个盲区：前者是「有文件、无登记」，后者是「无文件、无登记」。
- 本轮只登记经验、未实现检测：版本号并非每个补丁号都必然发布，区间空洞只能**提示**不能**断言**，需配套「已知缺失豁免清单」才有可用性，故留待明确授权后再落。
- 使用记录追加一行（历史链补齐）。
- 安全审计：本次仅文档与台账变更，未触碰任何脚本逻辑、未新增读取面或依赖；沿用 **P2 放行（Benign）**。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md、EXPERIENCE.md。

## v0.3.0 · 2026-09-11 skills 根卫生体检 + 发布物落点硬约定
- 扩展 `scripts/audit_archive.py`：新增可选 `--skills-root`，把「发布物落点」纳入校验——四类发现 `backup_dir_in_root`（备份目录留在根内会抢占同名 skill）、`dir_without_skill_md`（非法 skill 目录）、`zip_unique`（杂散 zip 且归档无此内容，移走即失传）、`zip_redundant`（杂散 zip 但与归档逐字节相同，纯冗余）。宿主自管项（`.deps`、`.skill-install-backups`、`*migration.json`）自动跳过，不误报。
- 新增硬约定：打包归集时 `--zip-dir` **必须显式指向临时 staging**。默认值是 skill 目录的父目录（即 skills 根），省略即让每个历史包堆进运行目录——本机实测累积 **107 个 zip / 29 MB**（96 个属 本套件的内部工具链）。
- 动机（实测数据缺口）：归档中心有 104 条 本套件的内部工具链 历史记录，但 skills 根另有 107 个 zip 从未纳入治理；其中 **5 个 html-workbench-pipeline 包是归档里根本不存在的孤本**——若按「看见 zip 就清」的直觉处理，这 5 个版本会直接失传。
- 处置流程固化（写入 `references/collection-procedures.md` 第六节）：先按 sha256 与归档全量比对 → 唯一副本**先归集再移** → 冗余包分批移出（每批 10 个、批后复核哈希、失败即停）→ 附 `MANIFEST.json`（原始路径/体积/哈希/归档对照）可原路回滚 → 宿主自管项不碰。
- 阶段一、阶段二、阶段四与「全局决策规则」「边界与验证」同步：新增「发布物不落运行目录」规则，阶段四刷新前须先过 `--skills-root` 体检。
- 自证由 3/3 扩到 **4/4**：新增「skills 根四类发现全部检出且宿主自管项不误报」。（首轮该项 FAIL，根因是**自证夹具缺陷**——两个夹具 zip 内容字节相同导致哈希撞车，「唯一」被误判为「冗余」；修夹具而非改判据。）
- 安全审计：本次只新增只读扫描分支与一个可选参数，未引入命令执行、网络请求、依赖安装或写归档行为；`--skills-root` 不改变「只读来源」原则。结论沿用 **P2 放行（Benign）**。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md、EXPERIENCE.md、references/collection-procedures.md、scripts/audit_archive.py。

## v0.2.0 · 2026-09-11 记录外完整性审计
- 新增 `scripts/audit_archive.py`：只读扫描归档中心，报四类发现——`unreadable`（zip 截断/损坏）、`orphan`（落在 history/ 或 migrations/ 却未被 INDEX 登记）、`missing`（记录声称的文件不存在）、`size_outlier`（同 skill 同类型包体积远超中位数）。支持 `--json` 报告、`--no-zip-read`、`--self-check`。
- 动机（实测假阴性）：`archive_releases.py --verify` 只校验 INDEX **已登记**记录，从不扫描「存在但未登记」的文件。本机归档里潜伏一个 **2.33 GB 的截断 zip**（无 EOCD 中央目录，写入中断产物），`--verify` 仍然全绿；新审计以 3 条独立信号（不可读 / 未登记 / 体积 7189× 中位数）同时命中它。
- 判据口径：`conflicts/` 按设计不入 INDEX 记录，故不参与 orphan 判定（防误报）；记录内 `archive_path` 兼容「相对 skill 归档目录」与「相对归档根」两种写法（防 missing 误报）。
- 自证 **3/3 PASS**：四类发现全部检出 / 干净归档零误报 / `--no-zip-read` 只跳过可读性检查。
- 阶段二（校验）完成判据由「两条 verify」扩为「两条 verify + 一条审计无发现」，边界与验证小节同步。
- 安全审计：新增脚本纯只读（仅 `ZipFile` 打开 + `stat`），无命令执行、无网络、无写归档行为；沿用 P2 放行（Benign）。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md、EXPERIENCE.md、references/collection-procedures.md、scripts/audit_archive.py。

## v0.1.1 · 2026-09-11 随迁包瘦身模式
- 新增 `--slim`（阶段五随迁的可选开关）：剔除 `conflicts/` 留证副本与 `cleanup-backups/` 清理前备份，且每个 `migrations/` 只保留版本号最大的包；`MANIFEST.json` 增记 `slim` 标记。默认仍为全量，语义不变。
- 动机：实测归档中心 294 MB 中，conflicts 71 MB + cleanup-backups 128 MB 均为取证/回滚底料，对跨机迁移零价值却占 68%；全量随迁包 304 MB 不便携带。
- 自证由 2/2 扩到 **3/3**：新增反证「`--slim` 下留证副本、清理前备份、旧迁移包必须一个都不进包」。
- 安全审计：本次只新增一个布尔开关与过滤分支，未引入命令执行、网络请求、依赖安装或新增读取面；沿用 v0.1.0 结论（审计: P2 放行 / Benign），`--slim` 不改变「只读来源」原则。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md、EXPERIENCE.md、references/collection-procedures.md、scripts/pack_archive_snapshot.py。

## v0.1.0 · 2026-09-11 初始建立
- 由 本套件的内部工具链 v0.93.3 生成骨架，按目标契约填充。
- 定位：用户级 Skill 归集管理中心（默认 `<归档根>`）唯一操作入口；五阶段流水线：归集 → 校验 → 冲突处理 → 刷新管理页 → 随迁。
- 结构：SKILL.md（type=process / pattern=Pipeline / depends-on=本套件的内部工具链）+ `references/`（archive-layout / collection-procedures / migration-companions）+ `scripts/pack_archive_snapshot.py` + `install.py` + 五件套。
- 配套：与 `skill-scorer`、`agent-harness-loop` 一同登记为元 skill `本套件的内部工具链` 的配套；归档中心（数据目录）作为随迁数据资产，由本 skill 的 `pack_archive_snapshot.py` 打包。
- 安全审计结论：**P2 放行**（skills-security-check 定级 Benign，85/100；无命令执行、无网络请求、无敏感路径读取、无依赖安装；仅 install.py 事务回滚与脚本临时文件清理，均项目内受限）。
- 验证：`pack_archive_snapshot.py --self-check` 2/2 PASS；对真实归档中心打包 311 文件、脱敏 1615 处、`--check` OK。
- 影响载体：SKILL.md、README.md、CHANGELOG.md、VERIFICATION.md、EXPERIENCE.md、references/*.md、scripts/pack_archive_snapshot.py、install.py。
