## v0.6.1 验证（2026-09-14 新增创建门禁规则）

### 功能范围
- 继承 v0.6.0：管理状态、行动队列、P0/P1 分级与迁移复核；新增全局决策规则「新 skill 创建即归档（创建门禁）」。
- 管理状态：`blocked`；当前硬发现 15 项，行动队列 25 项；默认只读，`--apply` 只写状态文件。
- 归档快照携带 `MANAGEMENT-STATE.json` / `ACTION-QUEUE.json` / `ACTION-QUEUE.md`。

### 验收清单
- `archive_manager.py --archive-root <真实归档根> --skills-root <真实 skills 根> --apply`：管理状态 `blocked`，检测到 15 项硬发现，生成 25 项行动队列。
- `audit_archive.py --self-check`：7/7 PASS。
- `pack_archive_snapshot.py --self-check`：3/3 PASS。
- `dev_check.py --syntax`：全部通过，产出 `skill-archive-manager-v0.6.1.zip`。
- `dev_check.py --full`：对抗样本全部通过（见下方实测）。
- 不执行删除、移动、覆盖或网络操作。

### 安全审计: P2

- 审计对象：`archive_manager.py`、`audit_archive.py`、`pack_archive_snapshot.py`、状态队列写入与迁移复核路径。
- 审计范围：本地只读扫描、显式 `--apply` 的状态文件写入、随迁包清单；不触碰归档实物，不执行外部命令，不联网。
- 结论：P2（Benign），允许交付。

## v0.5.0 验证

### 功能范围
- `audit_archive.py` 增加登记员⇄仓库双向对账：台账空头、仓库漏登为硬发现；源码版本陈旧为提示。
- 真实核查输出：`ledger_no_warehouse=11`、`warehouse_no_ledger=4`、`version_stale=4`；退出码为 1。
- 归档记录外四类发现与 skills 根卫生体检均为 0；版本空洞提示 6 处，默认不计入失败。

### 验收清单
- `audit_archive.py --self-check`：7/7 PASS。
- 真实核查报告：硬发现 15 项，未误报为通过。
- 不执行删除、移动、覆盖或网络操作。

### 安全审计: P2

# skill-archive-manager 试运行记录（VERIFICATION）

> 本文件证明本 skill 的脚本/步骤经实测可用。由 本套件的内部工具链 生成模板，交付前按实际填写；后续每次升级新增当前版本段，保留历史记录。

## v0.1.0 验证

### 验收清单

- [x] 验收判据 1（完成的样子）：五阶段各步 `verify` 全 OK；`MANAGED_SKILLS.json` 无备份污染；归档中心随迁包 `--check` 通过。
- [x] 验收判据 2（边界 / 不该做）：只复制不删除来源；同名不同哈希默认留证不覆盖（晋升须显式）；不改元 skill 源码；目录内无本机绝对路径。
- [x] 验收判据 3（兜底 / 出岔子）：失败保留证据、缩小范围、报告已做与未做动作；校验漂移先查根因不修预期。
- [x] 用户侧他证：2026-09-11 在本轮真实任务中首次使用（归集 本套件的内部工具链 v0.93.3 / skill-scorer v0.1.1 / agent-harness-loop v0.1.1 并产出归档中心随迁包）；用户已授权并当场跟进该任务。

### 功能范围

- 归集（Collect）：用 `pack_skill.py --archive-dir` 把已发布版本收入 `<ARCHIVE>/<skill>/history/`。
- 校验（Verify）：`archive_releases.py --verify` + `skill_release_hub.py --verify` + `pack_archive_snapshot.py --check`。
- 冲突处理（Conflict）：同名不同哈希默认落 `conflicts/` 留证；显式 `--promote/--force` 才晋升权威。
- 刷新管理页（Refresh）：`skill_release_hub.py --refresh` 重建 `MANAGED_SKILLS.json` 与顶层管理页。
- 随迁（Migrate）：`pack_archive_snapshot.py` 产出归档中心随迁包；联动 `pack_migration.py --with-companion` 带齐全部配套。
- 资源：`references/` 提供目录结构（archive-layout）、标准命令集（collection-procedures）、配套清单与随迁规则（migration-companions）。

### 安全审计

- 审计对象：`SKILL.md`、`README.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`、`references/*.md`、`scripts/pack_archive_snapshot.py`、`install.py`。
- 审计结论：**P2 放行**（skills-security-check 定级 Benign，85/100），与 CHANGELOG 条目结论一致。

| 场景 | 命令 / 步骤 | 结果 |
|---|---|---|
| 脚本语法 | `python -m py_compile scripts/pack_archive_snapshot.py` | 通过（syntax OK） |
| 脚本自证 | `pack_archive_snapshot.py --self-check` | **2/2 PASS**（打包可校验+家目录脱敏；篡改被 manifest 反证拦截） |
| 真实打包 | `pack_archive_snapshot.py --archive-root <真实归档根> --out <temp> --version 0.1.0` | 311 文件、脱敏 1615 处、产出 zip |
| 随迁包校验 | `pack_archive_snapshot.py --check <包解压目录>` | `[check][OK] archive-center v0.1.0，311 个文件` |
| 归集三 skill | `pack_skill.py <skill> --zip-dir <staging> --archive-dir <ARCHIVE>/<skill>` | 本套件的内部工具链 v0.93.3 / skill-scorer v0.1.1 新增；agent-harness-loop v0.1.1 提升（旧入 conflicts/） |
| 归档校验 | `archive_releases.py --verify <ARCHIVE>/<skill>` | 三条 `[verify][OK]` |
| 刷新管理页 | `skill_release_hub.py --refresh` + `--verify` | 22 skill 登记，`[verify][OK]` |
| 安全扫描 | 关键词集（命令执行/网络/敏感路径/依赖/隐蔽/编码） | 无风险命中（Benign） |
| 触发演练 | description 真实请求：归集/校验/冲突/刷新/迁移 | 与设计触发词一致 |

### 最终结论

- 是否全部通过：通过
- 实测环境：Windows + Python 3.13.12；纯本地文件操作，无外部依赖与网络。

## v0.1.1 验证（2026-09-11）

### 验收清单

- [x] 验收判据 1（完成的样子）：`--slim` 随迁包可产出且 `--check` 通过；全量模式行为与 v0.1.0 一致。
- [x] 验收判据 2（边界 / 不该做）：`--slim` 只筛「复制哪些文件」，来源归档中心仍只被读取、从不被删改；不清理原机 `conflicts/` 与 `cleanup-backups/`。
- [x] 验收判据 3（兜底 / 出岔子）：自证断言「留证副本 / 清理前备份 / 旧迁移包一个都不进包」，任一漏进即 FAIL 阻断。
- [x] 用户侧他证：2026-09-11 在本轮真实任务中用于产出归档中心随迁包（用户要求「归集中心随迁移一起带走」）。

### 功能范围

- 覆盖 v0.1.0 全部五阶段；阶段五随迁新增可选 `--slim`。
- 不做：不清理归档内容（不删 conflicts / cleanup-backups）、不做去重决策、不碰元 skill 源码。

### 本次变更范围

- 新增 `--slim` 随迁模式：剔除 `conflicts/` 与 `cleanup-backups/`，每个 `migrations/` 只留最新包；`MANIFEST.json` 增记 `slim` 标记。
- 自证新增第 3 条反证：`--slim` 下留证副本、清理前备份、旧迁移包必须一个都不进包。
- 默认行为（不带 `--slim`）与 v0.1.0 完全一致，属向后兼容的功能新增。

### 实测证据

| 场景 | 命令 / 步骤 | 结果 |
|---|---|---|
| 脚本语法 | `python -m py_compile scripts/pack_archive_snapshot.py` | 通过 |
| 脚本自证 | `pack_archive_snapshot.py --self-check` | **3/3 PASS**（可校验+脱敏；篡改反证拦截；`--slim` 剔除反证） |
| 全量 dry-run | `--archive-root <真实归档根> --dry-run` | 314 个文件 |
| 瘦身 dry-run | 同上传 `--slim` | 159 个文件（剔 155 个取证/冗余文件） |
| 瘦身实跑 | `--archive-root <真实归档根> --out <out> --version <标签> --slim` | 159 文件、脱敏 1619 处；包体积 304 MB → 68 MB |
| 随迁包校验 | `pack_archive_snapshot.py --check <包解压目录>` | `[check][OK] archive-center v<标签>，159 个文件` |

### 安全审计

- 审计对象：`scripts/pack_archive_snapshot.py`（本次唯一改动脚本）、`SKILL.md`、`README.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`、`references/collection-procedures.md`。
- 审计结论：**审计: P2 放行（Benign）**，沿用 v0.1.0 结论——本次仅新增一个布尔开关与一个过滤分支，未引入命令执行、网络请求、依赖安装或新增读取面。
- 边界重申：`--slim` 只影响「复制哪些文件」，不改变「只读来源」原则；来源归档中心仍然只被读取，从不被删改。


### 最终结论

- 是否全部通过：通过

## v0.2.0 验证（2026-09-11）

### 验收清单

- [x] 验收判据 1（完成的样子）：`audit_archive.py` 能报出四类发现；干净归档零发现；阶段二完成判据已含审计。
- [x] 验收判据 2（边界 / 不该做）：脚本**纯只读**——只 `ZipFile` 打开与 `stat`，不写入、不移动、不删除归档内任何文件；坏包只报告，处置（隔离）由人决定并显式执行。
- [x] 验收判据 3（兜底 / 出岔子）：`conflicts/` 不入册属设计语义，故排除在 orphan 判定外；记录内 `archive_path` 兼容「相对 skill 目录」与「相对归档根」两种口径——两类误报都已在 270 项→0 项的对照中消除。
- [x] 用户侧他证：2026-09-11 本轮真实任务中直接命中一个潜伏的 2.33 GB 截断 zip（用户可复核原始文件）。

### 功能范围

- 记录外完整性审计：`unreadable` / `orphan` / `missing` / `size_outlier` 四类发现，支持 `--json` 报告与 `--no-zip-read`。
- 不做：不做修复（不删、不移动、不重打包）；不做记录内哈希核对——那是 `archive_releases.py --verify` 的职责，二者互补不重叠。

### 本次变更范围

- 新增 `scripts/audit_archive.py`；阶段二（校验）由「两条 verify」扩为「两条 verify + 一条审计」；`references/collection-procedures.md` 同步命令集。
- 版本 v0.1.1 → v0.2.0（新增能力，向后兼容：不改任何既有脚本行为）。

### 安全审计

- 审计对象：`scripts/audit_archive.py`（本次唯一新增脚本）、`SKILL.md`、`README.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`、`references/collection-procedures.md`。
- 审计结论：**审计: P2 放行（Benign）**——新增脚本只读文件系统并打开 zip 读目录，无命令执行、无网络请求、无依赖安装、无删除/移动；遍历规模为归档文件数（本机 276 个）。

### 实测证据

| 场景 | 命令 / 步骤 | 结果 |
|---|---|---|
| 脚本语法 | `python -m py_compile scripts/audit_archive.py` | 通过 |
| 脚本自证 | `audit_archive.py --self-check` | **3/3 PASS**（四类发现全检出 / 干净归档零误报 / `--no-zip-read` 只跳可读性） |
| 真实归档 | `audit_archive.py --archive-root <真实归档根>` | 15 skill / 276 文件；命中 `unreadable` 1、`orphan` 1、`size_outlier` 1（三信号指向同一文件：2.33 GB 截断 zip，体积 7189× 中位数） |
| 误报对照 | 修正路径口径与 conflicts 语义后复跑 | `missing` 270 项 → 0 项；`orphan` 6 项 → 1 项（仅剩真缺陷） |
| 既有校验对照 | `archive_releases.py --verify <该 skill 归档>` | `[verify][OK]`——证明记录内校验对该坏包**失明**，即本脚本要补的盲区 |

### 最终结论

- 是否全部通过：通过
- 实测环境：Windows + Python 3.13.12；纯本地只读，无外部依赖与网络。

## v0.3.0 验证（2026-09-11）

### 验收清单

- [x] 验收判据 1（完成的样子）：`audit_archive.py --skills-root` 能产出四类 skills 根发现；对真实环境执行输出「审计结论：无发现」。
- [x] 验收判据 2（边界 / 不该做）：体检**只读**——不删、不移动、不改任何 skills 根文件；宿主自管项（`.deps`、`.skill-install-backups`、`*migration.json`）必须跳过且计入 `host_managed_files`。
- [x] 验收判据 3（兜底 / 出岔子）：自证断言「唯一杂散必须归入 `zip_unique` 而非 `zip_redundant`」——分类错即 FAIL 阻断（这正是本轮首跑抓到的问题）。
- [x] 用户侧他证：2026-09-11 本轮真实任务（用户指令「整理」）用于治理 skills 根发布物堆错落点，并据此完成 5 个孤本归集 + 107 个冗余包移出。

### 功能范围

- 覆盖 v0.2.0 全部能力；新增 `--skills-root`（可选，不传则行为与 v0.2.0 完全一致）与第六节处置流程文档。
- 不做：不执行移出动作（体检只报不改）；不做归档内容清理；不碰元 skill 源码。

### 本次变更范围

- `scripts/audit_archive.py` 新增 `audit_skills_root()` 与 `--skills-root`；自证 3/3 → 4/4。
- `SKILL.md` 阶段一加 `--zip-dir` 硬约定、阶段二加落点体检、阶段四加前置体检、全局规则加「发布物不落运行目录」。
- `references/collection-procedures.md` 新增第六节「skills 根卫生体检」（发现表 + 处置流程）。
- 版本 v0.2.0 → v0.3.0（新增能力，向后兼容）。

### 安全审计

- 审计对象：`scripts/audit_archive.py`、`SKILL.md`、`README.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`、`references/collection-procedures.md`。
- 审计结论：**审计: P2 放行（Benign）**——新增分支只做 `iterdir` / `stat` / `sha256` 只读操作，无命令执行、无网络请求、无依赖安装、无删除或移动；扫描规模为 skills 根一级条目数（本机 29）与归档 zip 数。

### 实测证据

| 场景 | 命令 / 步骤 | 结果 |
|---|---|---|
| 脚本语法 | `python -m py_compile scripts/audit_archive.py` | 通过 |
| 脚本自证 | `audit_archive.py --self-check` | **4/4 PASS**（归档四类检出 / 干净归档零误报 / `--no-zip-read` 行为 / skills 根四类检出且宿主项不误报） |
| 自证首跑暴露缺陷 | 同上（首轮） | 第 4 项 **FAIL**：漏 `zip_unique`——根因是夹具两个 zip 字节相同导致哈希撞车、唯一被误判为冗余；修夹具（条目数差异化）后 PASS |
| 真实环境 | `audit_archive.py --archive-root <归档根> --skills-root <skills 根>` | 归档 0 发现；skills 根 0 发现；宿主自管文件 4 个已跳过；结论「无发现 ✅」 |
| 整理前实测 | 同上（整理前） | `zip_redundant` 102 项 + `zip_unique` 5 项，与本轮人工比对结果一致（107 = 102 + 5） |
| 孤立版本归集 | `archive_releases.py --skill-dir <html-workbench-pipeline> --history-source <skills 根>` | 5 个历史包入档；`--verify` → `[verify][OK] 5 条归档记录，哈希、zip CRC 与条目数一致` |
| 移出后复核 | 分批移出脚本（每批 10，批后校验哈希） | 11 批全部 OK；107 个 / 28.7 MB 移出；根目录剩余 zip **0**；管理中心 23 skill `[verify][OK]` |

### 最终结论

- 是否全部通过：通过
- 实测环境：Windows + Python 3.13.12；纯本地只读，无外部依赖与网络。
- 遗留：根因（打包器 `--zip-dir` 默认落点）按用户口径**只在本 skill 侧固化为硬约定**，未改动元 skill 源码；是否上游补丁待用户拍板。

## v0.3.1 验证（2026-09-11）

### 验收清单

- [x] 验收判据 1（完成的样子）：本次使用复盘结论已按四段式记入 `EXPERIENCE.md`（E-07）与「使用记录」；SKILL.md / README.md 版本徽标与 frontmatter 同步至 v0.3.1。
- [x] 验收判据 2（边界 / 不该做）：**只登记经验，不实现检测**——版本区间空洞只能提示不能断言，缺「已知缺失豁免清单」时不具备可用性，不得抢跑。
- [x] 验收判据 3（兜底 / 出岔子）：无脚本改动，既有自证与门禁不受影响；改后复跑 `dev_check.py --full` 仍须 27/27。
- [x] 用户侧他证：2026-09-11 用户提供 本套件的内部工具链 历史链附件（v0.87.17~v0.91.10）要求补齐，本 skill 实际执行并据此产出 E-07。

### 功能范围

- 覆盖 v0.3.0 全部能力；本次为台账与版本声明变更，**零脚本行为变化**。
- 不做：不实现版本连续性检测（待授权）。

### 本次变更范围

- `EXPERIENCE.md` 新增 E-07 与一条使用记录；`CHANGELOG.md` 新增 v0.3.1 段；`SKILL.md` / `README.md` 版本同步。
- 版本 v0.3.0 → v0.3.1（补丁级：文档台账）。

### 安全审计

- 审计对象：`SKILL.md`、`README.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`。
- 审计结论：**审计: P2 放行（Benign）**——纯文档与台账变更，无脚本改动、无命令执行、无网络请求、无依赖安装、无删除或移动。

### 实测证据

| 场景 | 命令 / 步骤 | 结果 |
|---|---|---|
| 历史链外层附件 | sha256 复算 vs 附件自带清单 | 一致（`1bac8ba7…76f8`，15,545,158 B） |
| 补链包逐项复算 | 独立重开 zip / 重算哈希 / 重读 frontmatter 身份 | **24/24 通过**，链内自洽异常 0 |
| 归集结果 | `archive_releases.py --history-source <补链>/history` | 记录 190 → 214（history 104 → 128）；`[verify][OK] 214 条` |
| 回归安全 | 归集前后记录分类对比 | `conflict` 80、`migration` 6 均未变动（合并语义，零覆盖） |
| 来源存证 | 原附件 + 链清单 + 证据摘录写入归档 `evidence/` | 13 个文件；审计复跑确认未产生 orphan 误报 |
| 端到端审计 | `audit_archive.py --archive-root … --skills-root …` | **无发现 ✅**（归档 307 文件；skills 根四类全 0） |
| 交付质检 | `dev_check.py <本 skill> --full --external-skills-root …` | 27/27 PASS |

### 最终结论

- 是否全部通过：通过
- 实测环境：Windows + Python 3.13.12；纯本地只读，无外部依赖与网络。
- 遗留：谱系连续性检测未实现（见 E-07 与交付报告第七节），待明确授权。


## v0.4.0 验证（2026-09-11）

### 验收清单

- [x] 验收判据 1（完成的样子）：`audit_archive.py` 能报出两类版本区间提示，并按在档序列**精确枚举**补丁空洞的缺失版本号；`--gaps-list` 产出待寻清单；阶段二完成判据已含版本层。
- [x] 验收判据 2（边界 / 不该做）：**提示不计入失败**——默认退出码不受未豁免空洞影响（实测真实归档 `exit=0`）；`--strict-gaps` 才计入（实测 `exit=1`）；脚本仍**纯只读**，`--gaps-list` 只写调用方显式给出的路径。
- [x] 验收判据 3（兜底 / 出岔子）：豁免清单只认「kind + from + to」精确匹配，其余一律保持待确认；自证断言「已登记空洞转豁免、未登记项不转」，错即 FAIL 阻断。
- [x] 用户侧他证：2026-09-11 用户指令「① 做（空洞检测）② 找缺失版本 ③ 解决遗留」；本轮直接产出待寻清单交付用户按图索骥，用户可复核清单与归档实际文件。

### 功能范围

- 版本层两类提示：`version_gap`（同段补丁号缺失，可精确枚举）、`version_span_jump`（跨整段缺失，无法枚举）；豁免清单 known-gaps.json；`--gaps-list`、`--strict-gaps`。
- 覆盖 v0.3.1 全部能力；不传新参数时既有判定行为不变（输出多两段提示）。
- 不做：不自动补包、不自动登记豁免、不删改归档记录；也不判断「某个补丁号是否真的发布过」——那只有持有历史包的人能提供依据。

### 本次变更范围

- `scripts/audit_archive.py`：新增 `version_key` / `load_known_gaps` / `detect_version_gaps` / `write_gaps_list`，报告新增第三段与提示计数；自证 4/4 → **7/7**。
- `SKILL.md` 阶段二加版本层与豁免说明、边界与完成标准加空洞口径、失败兜底加「不得把未确认的缺失写成已解决」。
- `references/collection-procedures.md` 摘要与「二·补」节同步（含豁免文件格式与使用边界）。
- 版本 v0.3.1 → v0.4.0（新增能力，向后兼容）。

### 安全审计

- 审计对象：`scripts/audit_archive.py`、`SKILL.md`、`README.md`、`CHANGELOG.md`、`VERIFICATION.md`、`EXPERIENCE.md`、`references/collection-procedures.md`。
- 审计结论：**审计: P2 放行（Benign）**——新增代码只读 INDEX.json 与 known-gaps.json（后者仅做 json 解析），无命令执行、无网络请求、无依赖安装、无删除或移动；`--gaps-list` 只在调用方显式指定路径写一个 markdown。

### 实测证据

| 场景 | 命令 / 步骤 | 结果 |
|---|---|---|
| 脚本语法 | `python -m py_compile scripts/audit_archive.py` | 通过 |
| 脚本自证 | `audit_archive.py --self-check` | **7/7 PASS** |
| 自证首跑暴露缺陷 | 同上（首轮） | 第 5 项 **FAIL**：跨段跳跃判据不符——根因是夹具在 `1.0.9` 与 `1.2.0` 之间夹了 `1.1.0`，跨段幅度只剩 1；修夹具（改为 `1.0.0/1.0.1/1.0.4/1.2.0`）后 PASS |
| 真实归档 | `audit_archive.py --archive-root <归档根> --skills-root <skills 根>` | 归档四类 0；skills 根四类 0；版本区 **3 处提示**（0.86.6→0.86.9 / 0.87.10→0.87.17 / 0.91.10→0.93.3）；结论「无发现 ✅」+ 提示附注；`exit=0` |
| 严格模式 | 同上加 `--strict-gaps` | 未豁免 3 项计入失败 → `exit=1` |
| 待寻清单 | `--gaps-list <文件>` | 产出 markdown：2 处可精确枚举 + 1 处跨段跳跃；含补齐命令与口径声明 |
| 排序判据实测 | 列举归档 history 文件名 | `v0.91.10` 按名排序落在 `v0.91.3` 之前——确认必须按版本号排序 |
| 报告字段 | 同上加 `--json` | 报告含 `version_gap` / `version_span_jump` / `advisory` / `advisory_exempted` |

### 最终结论

- 是否全部通过：通过
- 实测环境：Windows + Python 3.13.12；纯本地只读，无外部依赖与网络。
- 遗留：真实归档 3 处提示**均未豁免**（拿不到「该号从未发布」的依据，不臆造理由），补齐入口与待寻清单已交用户；本套件的内部工具链 侧两项遗留（`--zip-dir` 默认落点、便携外层包）在同批处理。


### 质量评分（dev_check 第 7 段 score_skill）

| 维度 | 得分 | 要点 |
|---|---|---|
| 触发 | 20/20 | description 224 字，含场景与触发词；使用记录区有实质行；VERIFICATION 当前段含验证/他证留痕 |
| 结构 | 20/20 | 五件套齐备；install.py 可用；references 摘要块 3/3 |
| 内容 | 17/20 | 篇幅 2952 词（绿区，已接近 3000 上限）；示例标记 1 处；无占位符 |
| 逻辑 | 20/20 | 引用完整；VERIFICATION 当前版本段存在 |
| 安全可装 | 20/20 | 审计留痕双载体齐备；无本机绝对路径；install.py 可装 |
| **交付健康度** | **97/100 [优]** | 门禁之上分层度量；门禁结论仍以 27 项质检为准 |

（架构能力附加分 21/100 保留历史可比口径，不计入交付健康度；真实成效轨因缺结构化证据不计分，不虚构。）

> 篇幅余量提示：v0.4.0 正文 2952 词，距 3000 绿区上限仅约 50 词。后续迭代应优先把细则下放 `references/`，而非继续加正文。

## v0.4.1 验证（2026-09-11 随元 skill 落点契约变更同步）

### 功能范围

- 随元 skill v0.93.4（G-31）同步「发布包落点」约定表述：`--zip-dir` 由「绝不允许省略」改为「可省略」，并标注仅元 skill ≤v0.93.3 时默认值才是 skills 根、那时必须显式 staging。
- 覆盖 `SKILL.md` 阶段一硬约定与 `references/collection-procedures.md` 第一节两处同源表述。
- 本轮不新增判定能力、不改 `scripts/audit_archive.py` 与 `scripts/pack_archive_snapshot.py`、不改归集流程本身。

### 验收清单

- [x] 元 skill v0.93.4 落点契约已确认：默认暂存目录在 skills 根之外，显式指向 skills 根只告警不阻断。
- [x] 两处约定表述同步（`SKILL.md` 阶段一 + `references/collection-procedures.md` 第一节），无第三处遗留旧表述。
- [x] 章节篇幅 2939 词，仍在 3000 绿区以内（v0.4.0 为 2952 词，本轮净减 13 词）。
- [x] 完整终校达到自证 95/95、27/27、63 类、EXIT=0。
- [x] 本 skill 侧无脚本改动；`audit_archive.py --self-check` 与 `pack_archive_snapshot.py` 行为不变。

### 安全审计

- 审计对象：`SKILL.md` 阶段一硬约定段、`references/collection-procedures.md` 第一节。
- 审计范围：文档表述是否会对旧版元 skill 产生误导、是否削弱「不把发布包堆进运行目录」的护栏、是否引入新的外部路径假设。
- 结论：纯文档同步，无脚本、无文件系统写入、无网络；对元 skill ≤v0.93.3 仍保留显式 staging 的硬要求，护栏未被削弱。
- 审计结论：P2（Benign）。

### 验证命令与结果

| 命令/场景 | 结果 | 证据 |
|---|---|---|
| 元 skill `dev_check.py <本 skill 目录> --full` | 通过 | 自证 95/95、质检 27/27、63 类对抗、EXIT=0 |
| 打包落点实测 | 通过 | 产出 `~/.workbuddy/skill-builds/skill-archive-manager/skill-archive-manager-v0.4.1.zip`；skills 根保持 0 个 zip |
| 章节篇幅复算 | 通过 | 2939 词（绿区，距上限 61 词） |
| 旧表述残留扫描 | 通过 | 全文仅余两处新表述，无「绝不允许省略」遗留 |

### 质量评分

- 评分卡（元 skill `scripts/score_skill.py`）：触发 20/20 · 结构 20/20 · 内容 17/20（篇幅 2939 词绿区）· 逻辑 20/20 · 安全可装 20/20 → **交付健康度 97/100 [优]**。

### 最终结论

v0.4.1 已把本 skill 的落点约定与元 skill v0.93.4 的新默认对齐，同时对旧版元 skill 保留显式 staging 的硬要求；本 skill 侧无脚本改动。最终结论：全部通过。

## v0.4.2 验证（示例补齐与判据可机读化）

### 功能范围

- 补齐正文示例（archive-dir 正确用法与本 skill 不重打包的边界），不改脚本、不改判据。
- 统一新变更条目的审计等级为半角冒号形态，摆脱对历史条目形态的巧合依赖。

### 验收清单

- [x] 示例标记 1 → 3。
- [x] CHANGELOG 新条目审计等级为半角冒号，机器判据直接识别。
- [x] 五件套、引用完整、install.py、无本机绝对路径仍通过。

### 安全审计

- 审计: P2（纯文档补充，无脚本、无外部写入、无网络）。

### 验证命令与实测结果

| 命令 | 结果 |
|---|---|
| `python <skill-scorer>/scripts/score_skill.py --path skill-archive-manager` | 内容 17 → 20；综合 97 → 预期 100 |

### 最终结论

v0.4.2 仅补说明与示例，脚本与判据未改；归集、校验、冲突留证行为与 v0.4.1 一致。最终结论：全部通过。
