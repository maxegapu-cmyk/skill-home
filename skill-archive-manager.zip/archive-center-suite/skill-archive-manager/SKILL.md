---
name: skill-archive-manager
version: 0.6.1
type: process
pattern: Pipeline
depends-on: 本套件的内部工具链
description: 管理用户级 Skill 归集管理中心（默认 <归档根>）：负责 Skill 资产全生命周期管理，包括资产发现、归集登记、版本与发布状态管理、索引与哈希校验、完整性审计、冲突裁决、质量与证据留痕、问题处置闭环、管理页刷新、跨机随迁与恢复验收。归集登记只是其中一个子职责。当用户要求管理、归集/归档、校验、审计、版本治理、冲突处理、发布状态管理、修复归档问题、刷新发布管理页，或把归集中心连同元 skill 一起迁移时使用。触发词：归集管理、资产治理、归集、归档、发布总库、版本治理、完整性审计、冲突处理、问题闭环、promote、迁移包、随迁。
---

# skill-archive-manager（Skill 资产治理与归集管理者）

> **当前版本：v0.6.1**（2026-09-14）· 变更记录见 `CHANGELOG.md`

## 定位

本 skill 不是简单的“登记员”，而是用户级 Skill 资产的**管理者与治理中枢**。它负责从资产发现、归集登记、版本治理、发布状态、完整性与质量证据、冲突裁决、问题处置、管理页、迁移恢复到审计复盘的全生命周期管理。

五阶段 Pipeline 是当前主流程，但不是全部职责：**归集（Collect）→ 校验（Verify）→ 冲突处理（Conflict）→ 刷新管理页（Refresh）→ 随迁（Migrate）**，外围还必须覆盖资产发现、状态治理、问题闭环与恢复验收。

其与归集管理中心的关系是：本 skill 是**管理者/治理中枢**，归集管理中心是受其管理的**资产仓库与管理界面**；归档总台账、各 skill 的独立索引和管理页是它维护的登记、证据与呈现载体，不等于本 skill 的全部定位。

它不负责创作领域 skill，也不替代 `本套件的内部工具链` 的创作、打包和质检职责；但它负责决定资产如何进入管理体系、如何被验证、如何处理异常、何时可发布/迁移，以及问题是否真正闭环。

## 模型适配（省 token）

分三层：**L0 元数据**：frontmatter 常驻（判断是否触发）→ **L1 正文**：五阶段流程与规则 → **L2 资源**：`references/` 按需加载（文件头带摘要块）。规则：先读 L0 决定是否触发；先读 references 摘要块再决定读全文；单次运行预算 = 上下文窗口 × 1/3，超预算按 L2→L1 裁剪。

## 归集中心是什么

默认归档根 `ARCHIVE = <归档根>`，结构固定：

```text
ARCHIVE/
  <skill-name>/           # 每个 skill 一个子目录（= archive-dir）
    独立索引文件  INDEX.md  # 权威登记表（版本/文件/SHA-256/条目/归集时间）
    history/              # 常规发布包 <name>-v<x.y.z>.zip
    migrations/           # 一键迁移包
    conflicts/            # 同名不同哈希的留证副本，绝不覆盖权威
  00-管理入口/            # Skill发布归集管理中心.html（顶层管理页）
  归档总台账文件     # 跨 skill 统一登记表
```

关键判据：**`--archive-dir` 指单 skill 子目录**（如 `ARCHIVE/skill-scorer`），不是归档根；归档根只用于顶层管理页（`--archive-root`）。示例：`--archive-dir` 传 `ARCHIVE/skill-scorer` 正常，传 `ARCHIVE` 判为误用。细则见 `references/archive-layout.md`。

## 主流程（五阶段 Pipeline）

### 阶段一：归集（Collect）

把已发布版本收进中心。步骤：1) 先确保源码目录的 frontmatter `version` 已递增；2) 调用元 skill 打包并归集：

```bash
cd <本套件的内部工具链 安装目录>/scripts
python pack_skill.py <目标 skill 目录> --zip-dir <临时 staging> --archive-dir <ARCHIVE>/<skill-name>
```

- `--zip-dir` 可省略：v0.93.4 起默认落点已是 skills 根之外的暂存目录（`$SKILL_ARCHITECT_BUILD_DIR/<skill>` 或 `~/.workbuddy/skill-builds/<skill>`）。仅元 skill ≤v0.93.3 时默认值才是 skills 根，那时必须显式指定 staging。
- 完成判据：输出「常规历史包: N 个」且 INDEX.md 生成/更新。
- 决策点：若版本号与既有权威**同名**——先停，进入阶段三判定，不要盲打包。

### 阶段二：校验（Verify）

```bash
python archive_releases.py --verify <ARCHIVE>/<skill-name>
python skill_release_hub.py --skills-root <skills 根> --archive-root <ARCHIVE> --verify
python <本 skill>/scripts/audit_archive.py --archive-root <ARCHIVE> --skills-root <skills 根>
python <本 skill>/scripts/audit_archive.py --archive-root <ARCHIVE> --gaps-list <待寻清单.md>
```

**强联动对账（登记员 ⇄ 仓库）**：上述审计同时读取归档根的 `归档总台账文件`，对账台账与实际 skill 子目录。`ledger_no_warehouse` 表示登记了但未归集，`warehouse_no_ledger` 表示已收集但管理中心漏登；两类均为硬失败并返回退出码 1。`version_stale` 表示台账版本落后于源码，只作提示，刷新管理页后应消除。归集管理 skill 是登记员，归集管理中心是仓库，任何一边单独“看起来正常”都不能代替双向对账。

- 完成判据：前两条 `[verify][OK]` 管**记录内**一致性（哈希、zip CRC、条目数）；第三条 `审计结论：无发现` 管**记录外**完整性（未登记文件、不可读 zip、体积离群）。第四条只写待寻清单，不改变判据。
- 为什么前两条不够：`archive_releases.py --verify` 只核对 INDEX 已登记记录，从不扫描「存在但未登记」的文件。实测一个 2.33 GB 的截断 zip 潜伏在 `history/` 里，`--verify` 依然 `[verify][OK]` —— 记录内全绿 ≠ 归档健康。
- 记录外审计另含 **skills 根卫生体检**（`--skills-root`）：`backup_dir_in_root`（备份目录留在根内会抢占同名 skill）、`dir_without_skill_md`（非法目录）、`zip_unique`（归档无此内容的杂散 zip，**移走即失传，必须先归集再移**）、`zip_redundant`（与归档逐字节相同的纯冗余，可安全移出）。宿主自管项（`.deps`、`.skill-install-backups`、`*migration.json`）自动跳过。
- **版本区间空洞（第三段发现，提示性质）**：按在档 history 序列检出两类——`version_gap`（同一主次版本号内相邻版本之间缺补丁号，可精确枚举缺失版本）与 `version_span_jump`（相邻在档版本之间跨整段，如次版本号差 > 1，无法枚举）。它**默认不计入失败**：semver 补丁号并非必然发布，缺某个号不等于该号发布过，无外部依据时不可断言为缺陷。补齐入口是 `--gaps-list <文件>` 写出的待寻清单，拿去持有历史包的机器按图索骥。
  - 注意两种盲区的分工：记录外扫描（上一条）查「有文件、无登记」；本段查「无文件、也无登记」的**谱系空洞**——一个跨 24 个版本的整段空洞曾长期存在，而两种校验都报绿。
  - **已确认可接受的缺失**：在该 skill 归档目录下的 known-gaps.json 登记 known_missing 条目（按 kind + from + to 精确匹配，kind 取 patch 或 span），登记后该项转为「已豁免」，不再进待寻清单。需要把空洞当门禁时加 `--strict-gaps`（只对未豁免项生效）。
- 决策点：报「哈希漂移 / 缺独立索引」→ 不修改证据，先查根因（多为源码被改动未重打包）；报 `unreadable / orphan / size_outlier` → 先把坏包**隔离**（移出归档到隔离目录，保留不删、留证），再重跑本阶段；报未豁免的 `version_gap` → 先按待寻清单找包补齐，或与持有人确认「该号从未发布」后登记豁免，**不得改判据或删记录**。

### 阶段三：冲突处理（Conflict）

同名不同 SHA-256 是**版本碰撞**（同版本号、内容不同）。归集器铁律：默认把**新来源丢进 `conflicts/` 留证，不覆盖权威**。

- 决策点：仅当用户**明确认定新来源才是权威**时，才显式晋升：`pack_skill.py ... --force`（`--force` = `--promote`），旧权威自动复制到 `conflicts/…--superseded-<hash>.zip`。
- 示例：agent-harness-loop 新旧同为 v0.1.1 但内容不同，属版本碰撞——默认留证，须用户确认后才显式晋升。
- 未获明确授权 → 保持默认（留证不晋升），并报告碰撞事实。

### 阶段四：刷新管理页（Refresh）

```bash
python skill_release_hub.py --skills-root <skills 根> --archive-root <ARCHIVE> --refresh
```

- 完成判据：输出 `已登记 skill：N` 且 `00-管理入口/Skill发布归集管理中心.html` 刷新。
- 重要：刷新前先跑阶段二的 `--skills-root` 体检，确认 skills 根**无备份目录、无同名重复**（`.backup_*`、`_backup-*`）且无杂散发布物，否则会把备份登记成 skill、污染 归档总台账文件。

### 阶段五：随迁（Migrate）

让归档中心随元 skill 一起迁移（元 skill 不变，本 skill 负责归档侧）：

```bash
# 归档中心随迁包（本 skill 自带脚本）；跨机迁移默认加 --slim
python <本 skill>/scripts/pack_archive_snapshot.py --archive-root <ARCHIVE> --out <out 目录> --slim
```

`--slim` 只带走「权威可复现」部分：剔除 `conflicts/` 留证副本与 `cleanup-backups/` 清理前备份，且每个 `migrations/` 只保留版本号最大的包。这三类是取证与回滚底料，对跨机迁移没有价值，却常在归档中心里占到三分之二以上（实测 314 文件 / 304 MB → 159 文件 / 68 MB）。需要完整取证快照（带全部冲突留证与历史回滚底料）时才不加该参数。

元 skill 及其全部配套的迁移包命令见 `references/migration-companions.md`（按其中的标准流程执行，逐个声明配套）。

- 完成判据：随迁包 `--check` 通过；元 skill 迁移包的「随迁资产清单」列出全部配套 + 归档中心。
- 配套清单与边界见 `references/migration-companions.md`。

## 管理者能力（不止登记归档）

本 skill 的定位是归集管理中心的**管理者**，归集/登记只是其中一个动作。管理范围包括：

- 健康扫描与硬门禁：记录内、记录外、源码根、总台账、版本和迁移状态统一核查；
- 问题队列：把每个发现生成唯一 `finding_id`，跟踪 `open / confirmed / planned / resolved / waived / blocked` 生命周期；
- 版本门禁：区分 `source_ahead`、`ledger_ahead`、`package_ahead`、`aligned`，禁止陈旧台账静默通过；
- 目录治理：对正式、测试、待确认、废弃目录分类，未分类仓库目录不得静默进入正常状态；
- 冲突与隔离：保留冲突证据，坏包/篡改包进入隔离建议，不直接覆盖权威；
- 管理状态与迁移：把归档根中的 管理状态文件和行动队列文件 随仓库快照携带，目标机恢复后继续处理；
- 闭环验收：修复后重新审计，只有硬发现为零、台账/仓库/源码一致才允许标记健康。

统一管理器：

```bash
python <本 skill>/scripts/archive_manager.py --archive-root <ARCHIVE> --skills-root <skills根>
python <本 skill>/scripts/archive_manager.py --archive-root <ARCHIVE> --skills-root <skills根> --apply
python <本 skill>/scripts/archive_manager.py --check-migration <随迁解压目录>
```

默认只读；`--apply` 只写管理状态与行动队列，不删除、移动或覆盖归档实物。

## 全局决策规则

- **只复制、不删除**：归集/随迁一律复制来源，绝不删除或移动原始 skills。
- **权威优先、留证不覆盖**：同名不同哈希默认进 `conflicts/`；晋升须显式 `--promote/--force`。
- **先校验后动作**：任何清理/晋升前先 `--verify` 拿到证据。
- **发布物不落运行目录**：历史包一律先打包到 staging 再归集，skills 根只留 skill 目录与宿主自管文件。
- **新 skill 创建即归档（创建门禁）**：任何新自研 skill 产出后必须同步 `pack_skill.py --archive-dir <ARCHIVE>/<skill>` 生成发布包并归集；每次迭代发版同理。归档中心 `history/` 只保留一份权威副本（`archive_releases` 去重：同名同哈希跳过、同名异哈希进 `conflicts/` 留证，绝不覆盖回滚源）；归档后清理 staging 副本（`~/.workbuddy/skill-builds/<skill>/`），禁止在 skills 根或 staging 留散包。
- **不碰元 skill**：本 skill 不改 `本套件的内部工具链` 源码；只调用其脚本。

## 边界与验证

- 不做：创作/质检 skill、修改元 skill 源码、把归档包自动安装到运行目录。
- 完成标准：五阶段各步 `verify` 全 OK，且 `audit_archive.py`（含 `--skills-root`）审计结论为「无发现」；归档总台账文件 无备份污染；随迁包可校验；归档来源零删除。

## 失败兜底

- 归集失败 → 保留 staging zip，查 frontmatter 版本与 zip 名冲突，报告不晋升。
- 校验漂移 → 先定位改动来源（源码未重打包 / 手改归档），修根因后全量重打包，不改预期。
- 管理页登记到备份 → 移出备份目录后 `--refresh` 重建登记表（来源零删除）。
- 版本空洞待确认 → 写待寻清单交历史包持有人补齐；只有拿到「该号从未发布」的依据才登记豁免，**不得把未确认的缺失写成已解决**（提示即提示，不粉饰成通过）。
- 影响面超出「归档管理」授权 → 立即停止，报告已做与未做动作。

## 证据推理模式（强制）

- **自证**：触发于归集/刷新/随迁前；把预期结果（登记表应记的版本与条目数）与实际归档包逐项比对，输入一条已发布版本、一次校验；通过标准：预期与实际一致、哈希自洽；停止条件：正常、重复运行均稳定；失败处理：修根因后全量重跑。
- **反证**：触发于自证通过后；构造两类变异与冲突输入——「同名不同哈希」与「篡改后 zip」；通过标准：默认被留证/拦截、合法包不误报；停止条件：对抗集不再发现漏检；失败处理：补判据并固化反例。
- **旁证迁移**：同时对源码目录、`history/` zip、独立索引三载体取证比对版本与哈希；通过标准：三载体一致且可定位；失败处理：同步载体后重打包重校验。

## 配套与迁移

本 skill 与「归集管理中心」**同为元 skill 独立归集管理中心套件 的配套**，迁移必须一起走：配套 skill 集合 = `skill-scorer`、`agent-harness-loop`、`skill-archive-manager`、`skill-distribution-manager`、`code-repair-regression`、`skill-bidirectional-migration`；数据资产 = 归档中心随迁包。迁移命令与「随迁资产清单」的登记方式见 `references/migration-companions.md`。

## 逻辑链自检（防错漏与矛盾）

交付前逐项核对：引用完整（正文提到的 `references/`、`scripts/` 真实存在）；步骤连续（阶段一~五无跳号）；数字一致（如备份清理判据全文一个口径）；定义一致（`ARCHIVE`、`archive-dir`、归档根写法统一）；条件出口（每个决策点都有去向）；规则冲突（默认留证与显式晋升互不矛盾）——人工维度由 独立归集管理中心套件 交付质检复核。

## 安装（跨 agent）

平台无关。**首选一键安装**：解压本包后在 `skill-archive-manager/` 目录运行 `python install.py --agent <宿主名>`；也可 `--target` 指定、`--dry-run` 预览。手动方式：整体复制本目录到目标 agent 的 skills 目录（常见如 `<skills根>/`、`~/.claude/skills/`、`~/.agents/skills/`），目录名即 skill 名。目录内不得含本机专属绝对路径——拷到任何机器均可直接用。跨 agent 目录对照见元 skill 独立归集管理中心套件 的跨 agent 适配说明。

## 经验台账

本 skill 的经验条目统一登记在 `EXPERIENCE.md`（编号 E-01…）；迭代时逐条保留，删改须在状态列标注原因（迁移→新位置 / 废弃→理由），不得静默删除。

## 使用后复盘（强制）

每次使用后四段式复盘，结论在回复中明示（「本次复盘：无改进点」或「本次复盘：已更新 XX」）：

1. **反思**：这次归集/校验/随迁哪一步卡壳、缺信息、指令歧义或工具不适用？
2. **评估**：该改进是否值得做（显著提升下次执行效率或正确性，而非风格偏好）？
3. **更新**：有意义的改进立即更新本 skill（递增 frontmatter `version` 并记 `CHANGELOG.md`）；更新前核对 `EXPERIENCE.md` 逐条保留；无改进跳过。
4. **验证**：更新后运行 `<本套件的内部工具链 安装目录>/scripts/dev_check.py <本 skill 目录> --full`（或说「@skill:本套件的内部工具链 帮我质检」），全 PASS 才可再交付。
