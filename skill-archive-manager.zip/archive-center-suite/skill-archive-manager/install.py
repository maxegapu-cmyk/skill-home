#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""skill-archive-manager 自动化安装引导（跨 agent 通用）—— 质检 [15] 强制自带的「一键安装」脚本。

用法（在 skill 目录内运行）:
    python install.py                 # 安全默认：列出候选位置与用法，不安装
    python install.py --agent claude  # 装入 Claude Code（同理 codex/gemini/cursor/opencode/windsurf/copilot/agents）
    python install.py --agent codex   # 装入 OpenAI Codex
    python install.py --target <目录> # 装入手动指定的 skills 目录
    python install.py --dry-run       # 预览将装入哪里，不实际复制（可单独用，
                                      # 也可搭配 --agent/--target 预览具体路径）
    python install.py --agent workbuddy --force  # 目标已存在时覆盖更新（升级版本用）
"""
import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, OSError):
        pass

# 已知 agent 的 skills 目录（动态拼接，不写死本机绝对路径——拷到任何机器均可运行，质检 [14] 扫描本文件）。
# 值为 (相对路径, 作用域)：scope="home" → 相对用户主目录（跨项目用户级）；scope="cwd" → 相对当前工作目录（工程级，随仓库走）。
# 完整目录对照与「可移植 frontmatter」约定见 本套件的内部工具链 references/adaptation-guide.md「跨 agent 适配」。
AGENTS = {
    "workbuddy": (".workbuddy/skills", "home"),           # WorkBuddy（本平台，跨项目用户级）
    "claude":    (".claude/skills", "home"),              # Claude Code（全局）
    "codex":     (".agents/skills", "home"),               # OpenAI Codex 用户级官方发现目录
    "gemini":    (".gemini/skills", "home"),              # Gemini CLI（全局）
    "cursor":    (".cursor/skills", "home"),              # Cursor（编辑器/CLI，工程级为主）
    "opencode":  (".config/opencode/skills", "home"),     # OpenCode（全局配置目录）
    "windsurf":  (".codeium/windsurf/skills", "home"),    # Windsurf Cascade（全局）
    "copilot":   (".copilot/skills", "home"),             # GitHub Copilot（全局；工程级目录为 .github/skills，部分版本用 ~/.config/github-copilot/skills）
    "agents":    (".agents/skills", "cwd"),               # 跨 agent 统一工程目录（Codex/OpenCode/Roo/Amp/Cline 共读；工程级）
}

STATE = ".skill-install-managed.json"

def _existing_parent(path):
    candidate = Path(path)
    while not candidate.exists() and candidate != candidate.parent:
        candidate = candidate.parent
    return candidate

def _files(root):
    return [p.relative_to(root).as_posix() for p in sorted(root.rglob("*"))
            if p.is_file() and p.name != STATE
            and ".skill-install-backups" not in p.parts
            and "__pycache__" not in p.parts and p.suffix != ".pyc"]

def _read_state(target):
    state = target / STATE
    if not state.is_file():
        return []
    try:
        data = json.loads(state.read_text(encoding="utf-8"))
        files = data["files"]
        if not isinstance(files, list) or any(Path(x).is_absolute() or ".." in Path(x).parts for x in files):
            raise ValueError
        return [str(x) for x in files]
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"安装受管清单损坏：{state}") from exc

def _read_skill_name(root):
    """从 SKILL.md frontmatter 读取规范名称，不让临时源码目录名污染安装路径。"""
    skill_file = root / "SKILL.md"
    try:
        text = skill_file.read_text(encoding="utf-8").lstrip("\ufeff")
    except OSError as exc:
        raise RuntimeError(f"无法读取 skill 元数据：{skill_file}") from exc
    frontmatter = re.match(r"\A---\s*\r?\n(.*?)\r?\n---(?:\r?\n|\Z)", text, re.S)
    if not frontmatter:
        raise RuntimeError(f"SKILL.md 缺合法 frontmatter：{skill_file}")
    match = re.search(r"(?m)^name:\s*([a-z0-9]+(?:-[a-z0-9]+)*)\s*$", frontmatter.group(1))
    if not match:
        raise RuntimeError(f"SKILL.md frontmatter 缺合法 kebab-case name：{skill_file}")
    return match.group(1)

def _transactional_copy(src, target, skill_name):
    stage_root = Path(tempfile.mkdtemp(prefix=".skill-install-stage-", dir=str(_existing_parent(target.parent))))
    staged = stage_root / target.name
    backup = None
    moved = False
    try:
        if target.exists():
            shutil.copytree(target, staged, symlinks=False,
                ignore=shutil.ignore_patterns(".skill-install-backups", "__pycache__", "*.pyc"))
        else:
            staged.mkdir()
        previous = set(_read_state(target)) if target.exists() else set()
        incoming = set(_files(src))
        for raw in sorted(previous - incoming):
            stale = staged / Path(raw)
            if stale.is_file() or stale.is_symlink():
                stale.unlink()
        shutil.copytree(src, staged, dirs_exist_ok=True, symlinks=False,
            ignore=shutil.ignore_patterns(".skill-install-backups", "__pycache__", "*.pyc"))
        (staged / STATE).write_text(json.dumps({"schema": 1, "skill": skill_name,
            "files": sorted(incoming)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            backup = target.parent / ".skill-install-backups" / (target.name + "-" + time.strftime("%Y%m%d-%H%M%S"))
            backup.parent.mkdir(parents=True, exist_ok=True)
            os.replace(target, backup)
            moved = True
        os.replace(staged, target)
    except Exception:
        if moved and backup and backup.exists():
            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            os.replace(backup, target)
        raise
    finally:
        shutil.rmtree(stage_root, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="skill-archive-manager 安装引导")
    parser.add_argument("--agent", choices=list(AGENTS),
                        help="指定 agent（workbuddy/claude/codex/gemini/cursor/opencode/windsurf/copilot/agents）")
    parser.add_argument("--target", help="手动指定目标 skills 目录")
    parser.add_argument("--dry-run", action="store_true", help="预览将装入哪里，不实际复制")
    parser.add_argument("--force", action="store_true",
                        help="目标已存在时覆盖更新（默认跳过；仅覆盖含 SKILL.md 或 install.py 的目录，防误删）")
    args = parser.parse_args()

    src = Path(__file__).resolve().parent
    skill_name = _read_skill_name(src)
    if args.target:
        dests = [Path(args.target).expanduser()]
    elif args.agent:
        rel, scope = AGENTS[args.agent]
        base = Path.cwd() if scope == "cwd" else Path.home()
        dests = [base / rel]
    else:
        # 未指定目标：--dry-run 单独使用时预览全部候选位置（v0.22.0 修复——此前文档声称
        # 「只预览」，实现却直接 return 0，文档与实现漂移，且会经 init_skill.py 传播给所有生成的 skill）
        print("候选位置（不存在则自动创建；* 为工程级，相对当前目录）：")
        for name, (rel, scope) in AGENTS.items():
            base = Path.cwd() if scope == "cwd" else Path.home()
            dest = base / rel
            mark = "  <- 将安装到这里" if args.dry_run else ""
            print(f"  {name} [{'工程' if scope == 'cwd' else '全局'}]: {dest}{mark}")
        if args.dry_run:
            print("[dry-run] 以上为预览，未复制任何文件；指定 --agent/--target 可预览具体安装路径")
        print("用法：python install.py --agent <name> | --target <目录> | --dry-run | --force")
        return 0

    for dest in dests:
        if args.dry_run:
            print(f"[dry-run] 将安装到：{dest / skill_name}")
            continue
        dest.mkdir(parents=True, exist_ok=True)
        target = dest / skill_name
        # 自毁防护：在已安装目录内运行本脚本时 src 与 target 是同一目录。
        if target.exists() and target.resolve() == src.resolve():
            print(f"跳过：{target} 即本脚本所在目录（已是安装位置，无需覆盖——防 --force 删除自身）")
            continue
        existed = target.exists()
        if existed:
            if not args.force:
                print(f"跳过：{target} 已存在（升级请加 --force 覆盖更新，或先删除后重跑）")
                continue
            # 防误删：只覆盖「看起来像本 skill 目录」的目标（含 SKILL.md 或 install.py）——
            # 避免 --target 误指到用户目录时把无关目录整个删掉
            if not ((target / "SKILL.md").exists() or (target / "install.py").exists()):
                print(f"中止：{target} 已存在且不含 SKILL.md / install.py —— 疑似非 skill 目录，拒绝覆盖（防误删）")
                return 1
        _transactional_copy(src, target, skill_name)
        print(f"{'已覆盖更新' if existed else '已安装'}：{skill_name} → {target}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
