#!/usr/bin/env python3
"""
steward.py — 本地資料庫的「接管 + 檢索 + 管理」一體化 CLI（僅依賴 Python 標準庫）。

子命令：
  survey    摸底：不改任何檔案，輸出庫的全貌地圖（LIBRARY_MAP）
  init      適配：按摸底結果生成 .steward/config.json
  index     建/更新索引（增量，按 size+mtime 跳過未變檔案，多執行緒算雜湊）
  find      檢索：全文（中文 trigram）+ 檔名 + 過濾；按「同名組」聚合（圖+原詞）
  show      檢視單個檔案/組的全部資訊（雜湊、來源、批次、同組檔案）
  status    現狀：各集合數量、來源、最後索引、未入索引的改動
  source    來源登記：add / list
  ingest    入庫：預設演練，--apply 才執行；去重、不覆蓋、記批次
  undo      撤回某批次（移入 .steward/trash，可 restore），預設演練
  restore   從 trash 恢復某批次
  snapshot  生成版本快照（清單）；diff 比較兩個快照或快照與當前
  verify    完整性校驗（雜湊重算），發現缺失/篡改/未登記檔案
  doctor    環境與庫健康檢查
  selftest  在臨時目錄跑一遍完整流程（含撤回恢復演練），證明本機可用

所有命令支援 --json 輸出，便於 Agent 解析。
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import fnmatch
import hashlib
import html
import json
import os
import re
import shlex
import shutil
import sqlite3
import sys
import tempfile
import time
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

VERSION = "1.0.0"
DATA_DIR = ".steward"

DEFAULT_CONFIG = {
    "version": 1,
    "collection_depth": 1,          # 沒有 collections 對映時，用第 N 層目錄名當集合名
    "collections": {},              # {"集合名": "相對路徑"}，優先於 collection_depth
    "exclude": [".git", ".svn", ".hg", "node_modules", "__pycache__", DATA_DIR,
                ".DS_Store", "Thumbs.db", "desktop.ini", ".venv", "venv", "*.tmp", "~$*"],
    "text_ext": [".txt", ".md", ".markdown", ".json", ".jsonl", ".yaml", ".yml", ".csv", ".tsv",
                 ".html", ".htm", ".xml", ".toml", ".ini", ".caption", ".prompt", ".srt", ".log",
                 ".css", ".js", ".ts", ".py", ".svg"],
    "image_ext": [".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff", ".heic", ".avif", ".psd", ".ai"],
    "doc_ext": [".docx", ".pptx", ".xlsx", ".pdf"],
    "synonyms": {},                 # {"海報": ["poster", "招貼"]}，檢索時自動擴充套件為“任一即可”
    "max_text_bytes": 2000000,
    "hash": True,
    "hash_workers": 8,
}

MAPPING_HINTS = ("manifest", "registry", "index", "catalog", "source", "sources", "readme",
                 "license", "changelog", "metadata", "meta", "登記", "來源", "目錄", "清單", "說明")

# ----------------------------------------------------------------- utils

def _utf8_stdout():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass


def now_iso():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def human(n: float) -> str:
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.0f}{u}" if u == "B" else f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}PB"


def out(args, data, text: str | None = None):
    if getattr(args, "json", False):
        print(json.dumps(data, ensure_ascii=False, indent=2, default=str))
    else:
        print(text if text is not None else json.dumps(data, ensure_ascii=False, indent=2, default=str))


def die(msg, code=2):
    print(f"[steward] 錯誤：{msg}", file=sys.stderr)
    sys.exit(code)


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


PAGE_MARK = "[第{}頁]"
PAGE_RE = re.compile(r"^\[第(\d+)頁\]$")


def read_text(p: Path, limit: int) -> str:
    try:
        raw = p.open("rb").read(limit)
    except OSError:
        return ""
    for enc in ("utf-8-sig", "utf-16", "gb18030", "big5"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "ignore")


def _xml_texts(xml: bytes, tag: str) -> list[str]:
    return [html.unescape(m) for m in re.findall(rf"<{tag}(?: [^>]*)?>([^<]*)</{tag}>", xml.decode("utf-8", "ignore"))]


def extract_doc(p: Path, limit: int) -> str:
    """docx/pptx/xlsx 用標準庫解析；pdf 用 pypdf 或 pdftotext（都沒有則跳過正文）。頁面用 [第N頁] 標記。"""
    ext = p.suffix.lower()
    try:
        if ext == ".docx":
            with zipfile.ZipFile(p) as z:
                xml = z.read("word/document.xml").decode("utf-8", "ignore")
            paras = []
            for para in re.split(r"</w:p>", xml):
                t = "".join(html.unescape(x) for x in re.findall(r"<w:t(?: [^>]*)?>([^<]*)</w:t>", para))
                if t.strip():
                    paras.append(t)
            return "\n".join(paras)[:limit]
        if ext == ".pptx":
            with zipfile.ZipFile(p) as z:
                slides = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                                key=lambda n: int(re.findall(r"\d+", n)[-1]))
                parts = []
                for i, n in enumerate(slides, 1):
                    parts.append(PAGE_MARK.format(i))
                    parts += [t for t in _xml_texts(z.read(n), "a:t") if t.strip()]
            return "\n".join(parts)[:limit]
        if ext == ".xlsx":
            with zipfile.ZipFile(p) as z:
                names = z.namelist()
                shared = []
                if "xl/sharedStrings.xml" in names:
                    for si in re.findall(r"<si>(.*?)</si>", z.read("xl/sharedStrings.xml").decode("utf-8", "ignore"), re.S):
                        shared.append("".join(html.unescape(x) for x in re.findall(r"<t(?: [^>]*)?>([^<]*)</t>", si)))
                lines = []
                sheets = sorted(n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
                for sn in sheets:
                    lines.append(f"## {Path(sn).stem}")
                    x = z.read(sn).decode("utf-8", "ignore")
                    for row in re.findall(r"<row[^>]*>(.*?)</row>", x, re.S):
                        cells = []
                        for attrs, body in re.findall(r"<c([^>]*)>(.*?)</c>", row, re.S):
                            v = re.search(r"<v>([^<]*)</v>", body)
                            if 't="s"' in attrs and v:
                                cells.append(shared[int(v.group(1))] if int(v.group(1)) < len(shared) else "")
                            elif 't="inlineStr"' in attrs:
                                cells.append("".join(_xml_texts(body.encode(), "t")))
                            elif v:
                                cells.append(v.group(1))
                        if any(c.strip() for c in cells):
                            lines.append(" | ".join(cells))
                        if sum(map(len, lines)) > limit:
                            break
            return "\n".join(lines)[:limit]
        if ext == ".pdf":
            pages = []
            try:
                import pypdf  # type: ignore
                for i, pg in enumerate(pypdf.PdfReader(str(p)).pages, 1):
                    pages.append(PAGE_MARK.format(i) + "\n" + (pg.extract_text() or ""))
                    if sum(map(len, pages)) > limit:
                        break
            except ImportError:
                if shutil.which("pdftotext"):
                    import subprocess
                    r = subprocess.run(["pdftotext", "-enc", "UTF-8", str(p), "-"], capture_output=True, timeout=120)
                    for i, t in enumerate(r.stdout.decode("utf-8", "ignore").split("\f"), 1):
                        if t.strip():
                            pages.append(PAGE_MARK.format(i) + "\n" + t)
            return "\n".join(pages)[:limit]
    except Exception:
        return ""
    return ""


def extract_text(p: Path, cfg) -> str:
    ext = p.suffix.lower()
    limit = int(cfg["max_text_bytes"])
    if ext in cfg["text_ext"]:
        return read_text(p, limit)
    if ext in cfg.get("doc_ext", []):
        return extract_doc(p, limit)
    return ""


def excluded(name: str, patterns) -> bool:
    return any(fnmatch.fnmatch(name, pat) for pat in patterns)


def walk_files(root: Path, exclude):
    """快速遍歷（os.scandir），產出 (相對posix路徑, DirEntry)。"""
    stack = [root]
    while stack:
        d = stack.pop()
        try:
            it = os.scandir(d)
        except OSError:
            continue
        with it:
            for e in it:
                if excluded(e.name, exclude):
                    continue
                try:
                    if e.is_dir(follow_symlinks=False):
                        stack.append(Path(e.path))
                    elif e.is_file(follow_symlinks=False):
                        yield Path(e.path).relative_to(root).as_posix(), e
                except OSError:
                    continue


def group_key(rel: str) -> str:
    """同目錄同主名 = 一組（例如 a.png + a.txt + a.json）。"""
    p = rel.rsplit("/", 1)
    d, name = (p[0], p[1]) if len(p) == 2 else ("", p[0])
    stem = name.split(".", 1)[0] if not name.startswith(".") else name
    return f"{d}/{stem}" if d else stem

# ----------------------------------------------------------------- library

class Library:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.dd = self.root / DATA_DIR
        self.cfg_path = self.dd / "config.json"
        self.db_path = self.dd / "index.db"
        self.cfg = dict(DEFAULT_CONFIG)
        if self.cfg_path.exists():
            self.cfg.update(json.loads(self.cfg_path.read_text("utf-8")))
        self._db = None

    @staticmethod
    def locate(root_arg: str | None) -> "Library":
        if root_arg:
            return Library(Path(root_arg))
        env = os.environ.get("STEWARD_ROOT")
        if env:
            return Library(Path(env))
        cur = Path.cwd().resolve()
        for p in [cur, *cur.parents]:
            if (p / DATA_DIR / "config.json").exists():
                return Library(p)
        return Library(cur)

    @property
    def initialized(self):
        return self.cfg_path.exists()

    def need_init(self):
        if not self.initialized:
            die(f"{self.root} 還沒有適配。先執行：steward.py survey --root <庫根>，再 steward.py init --root <庫根>")

    # ---- db
    @property
    def db(self) -> sqlite3.Connection:
        if self._db is None:
            self.dd.mkdir(exist_ok=True)
            c = sqlite3.connect(self.db_path)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.executescript("""
            CREATE TABLE IF NOT EXISTS files(
              id INTEGER PRIMARY KEY, path TEXT UNIQUE, collection TEXT, ext TEXT,
              size INTEGER, mtime_ns INTEGER, sha256 TEXT, grp TEXT,
              indexed_at TEXT, source_id INTEGER, batch_id TEXT);
            CREATE INDEX IF NOT EXISTS ix_files_sha ON files(sha256);
            CREATE INDEX IF NOT EXISTS ix_files_grp ON files(grp);
            CREATE INDEX IF NOT EXISTS ix_files_col ON files(collection);
            CREATE TABLE IF NOT EXISTS sources(
              id INTEGER PRIMARY KEY, name TEXT UNIQUE, url TEXT, collection TEXT,
              notes TEXT, created_at TEXT, last_ingest_at TEXT);
            CREATE TABLE IF NOT EXISTS batches(
              id TEXT PRIMARY KEY, created_at TEXT, source_id INTEGER, collection TEXT,
              incoming TEXT, added INTEGER, skipped INTEGER, status TEXT);
            CREATE TABLE IF NOT EXISTS batch_files(batch_id TEXT, path TEXT, sha256 TEXT);
            CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
            """)
            c.execute("CREATE VIRTUAL TABLE IF NOT EXISTS fts USING fts5("
                      "path, name, collection, body, tokenize='trigram')")
            self._db = c
        return self._db

    def meta_set(self, k, v):
        self.db.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (k, str(v)))

    def meta_get(self, k, default=None):
        r = self.db.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return r[0] if r else default

    # ---- collections
    def collection_of(self, rel: str) -> str:
        cols = self.cfg.get("collections") or {}
        best, blen = None, -1
        for name, prefix in cols.items():
            pre = prefix.strip("/")
            if pre in ("", ".") or rel == pre or rel.startswith(pre + "/"):
                L = 0 if pre in ("", ".") else len(pre)
                if L > blen:
                    best, blen = name, L
        if best is not None:
            return best
        parts = rel.split("/")
        depth = int(self.cfg.get("collection_depth", 1))
        if len(parts) <= depth:
            return "(根目錄)"
        return "/".join(parts[:depth])

    def collection_path(self, name: str) -> Path:
        cols = self.cfg.get("collections") or {}
        if name in cols:
            return self.root / cols[name]
        return self.root / name

    def walk(self):
        return walk_files(self.root, self.cfg["exclude"])

# ----------------------------------------------------------------- survey

def cmd_survey(args):
    root = Path(args.root or ".").resolve()
    if not root.is_dir():
        die(f"不是目錄：{root}")
    t0 = time.time()
    excl = DEFAULT_CONFIG["exclude"]
    ext_c, ext_size = Counter(), Counter()
    top = defaultdict(lambda: {"files": 0, "bytes": 0, "subdirs": set(), "samples": []})
    groups = defaultdict(set)
    mapping_files, depth_c = [], Counter()
    total, total_b, newest = 0, 0, 0
    img_ext = set(DEFAULT_CONFIG["image_ext"]); txt_ext = set(DEFAULT_CONFIG["text_ext"])
    for rel, e in walk_files(root, excl):
        try:
            st = e.stat()
        except OSError:
            continue
        total += 1; total_b += st.st_size; newest = max(newest, st.st_mtime)
        ext = Path(rel).suffix.lower() or "(無副檔名)"
        ext_c[ext] += 1; ext_size[ext] += st.st_size
        parts = rel.split("/")
        depth_c[len(parts) - 1] += 1
        t = parts[0] if len(parts) > 1 else "(根目錄檔案)"
        top[t]["files"] += 1; top[t]["bytes"] += st.st_size
        if len(parts) > 2:
            top[t]["subdirs"].add(parts[1])
        if len(top[t]["samples"]) < 3:
            top[t]["samples"].append(rel)
        groups[group_key(rel)].add(ext)
        low = Path(rel).stem.lower()
        if len(parts) <= 3 and (any(h in low for h in MAPPING_HINTS) or
                                (ext in (".csv", ".json", ".yaml", ".yml", ".xlsx") and len(parts) <= 2)):
            mapping_files.append(rel)
    paired = sum(1 for s in groups.values() if (s & img_ext) and (s & txt_ext))
    img_only = sum(1 for s in groups.values() if (s & img_ext) and not (s & txt_ext))
    max_depth = max(depth_c) if depth_c else 0
    # 推薦集合層級：頂層目錄 >= 2 個且檔案主要在子目錄裡 → depth 1；只有一個頂層目錄 → depth 2
    real_tops = [k for k in top if k != "(根目錄檔案)"]
    suggest_depth = 2 if len(real_tops) == 1 and top[real_tops[0]]["subdirs"] else 1
    data = {
        "root": str(root), "scanned_at": now_iso(), "seconds": round(time.time() - t0, 2),
        "total_files": total, "total_bytes": total_b,
        "newest_change": dt.datetime.fromtimestamp(newest).isoformat(timespec="seconds") if newest else None,
        "max_depth": max_depth,
        "is_git": (root / ".git").exists(), "already_adapted": (root / DATA_DIR / "config.json").exists(),
        "extensions": [{"ext": k, "files": v, "bytes": ext_size[k]} for k, v in ext_c.most_common(15)],
        "top_dirs": sorted([{"name": k, "files": v["files"], "bytes": v["bytes"],
                             "subdirs": len(v["subdirs"]), "samples": v["samples"]}
                            for k, v in top.items()], key=lambda x: -x["files"]),
        "groups": {"total": len(groups), "image_with_text": paired, "image_only": img_only},
        "mapping_files": mapping_files[:30],
        "suggested_collection_depth": suggest_depth,
    }
    md = [f"# 資料庫地圖：{root.name}", "",
          f"- 根目錄：`{root}`",
          f"- 檔案：**{total}** 個，{human(total_b)}；最深 {max_depth} 層；最近改動 {data['newest_change']}",
          f"- Git 倉庫：{'是' if data['is_git'] else '否'}；已適配 steward：{'是' if data['already_adapted'] else '否'}",
          f"- 檔案組（同名主幹）：{len(groups)}；其中「圖 + 文字」配對 **{paired}** 組，只有圖 {img_only} 組",
          f"- 掃描耗時 {data['seconds']}s", "", "## 頂層結構", "",
          "| 目錄 | 檔案 | 體積 | 子目錄 | 樣例 |", "|---|---:|---:|---:|---|"]
    for t in data["top_dirs"][:40]:
        md.append(f"| {t['name']} | {t['files']} | {human(t['bytes'])} | {t['subdirs']} | "
                  f"{'<br>'.join('`'+s+'`' for s in t['samples'])} |")
    md += ["", "## 檔案型別 Top 15", "", "| 副檔名 | 檔案 | 體積 |", "|---|---:|---:|"]
    md += [f"| {x['ext']} | {x['files']} | {human(x['bytes'])} |" for x in data["extensions"]]
    md += ["", "## 疑似登記/說明檔案（優先閱讀）", ""]
    md += [f"- `{m}`" for m in mapping_files[:30]] or ["- （未發現）"]
    md += ["", "## 適配建議", "",
           f"- 建議集合層級 `--collection-depth {suggest_depth}`"
           + ("（頂層只有一個目錄，集合在第二層）" if suggest_depth == 2 else "（每個頂層目錄 = 一個集合）"),
           "- 先讀上面的登記/說明檔案，確認庫裡已有的來源、命名和版本約定，再寫進 ADAPTATION.md。"]
    if args.out:
        Path(args.out).write_text("\n".join(md) + "\n", "utf-8")
    out(args, data, "\n".join(md))

# ----------------------------------------------------------------- init

def cmd_init(args):
    lib = Library(Path(args.root or "."))
    if lib.initialized and not args.force:
        die(f"已適配過（{lib.cfg_path}）。要重寫配置請加 --force")
    lib.dd.mkdir(exist_ok=True)
    cfg = dict(DEFAULT_CONFIG)
    cfg["collection_depth"] = args.collection_depth
    if args.collections:
        cfg["collections"] = json.loads(Path(args.collections).read_text("utf-8")) \
            if Path(args.collections).exists() else json.loads(args.collections)
    if args.exclude:
        cfg["exclude"] = cfg["exclude"] + [x.strip() for x in args.exclude.split(",") if x.strip()]
    if args.no_hash:
        cfg["hash"] = False
    cfg["created_at"] = now_iso()
    lib.cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
    for sub in ("snapshots", "batches", "trash"):
        (lib.dd / sub).mkdir(exist_ok=True)
    lib.cfg = cfg
    _ = lib.db
    out(args, {"ok": True, "config": str(lib.cfg_path)},
        f"已適配：{lib.cfg_path}\n下一步：steward.py index --root \"{lib.root}\"")

# ----------------------------------------------------------------- index

def index_paths(lib: Library, only: set[str] | None = None, full=False, verbose=False):
    db, cfg = lib.db, lib.cfg
    known = {r["path"]: (r["size"], r["mtime_ns"], r["id"]) for r in
             db.execute("SELECT path,size,mtime_ns,id FROM files")}
    seen, todo = set(), []
    for rel, e in lib.walk():
        if only is not None and rel not in only:
            continue
        seen.add(rel)
        try:
            st = e.stat()
        except OSError:
            continue
        k = known.get(rel)
        if not full and k and k[0] == st.st_size and k[1] == st.st_mtime_ns:
            continue
        todo.append((rel, st.st_size, st.st_mtime_ns))
    hashes = {}
    if cfg.get("hash", True) and todo:
        with cf.ThreadPoolExecutor(max_workers=int(cfg.get("hash_workers", 8))) as ex:
            futs = {ex.submit(sha256_file, lib.root / r): r for r, _, _ in todo}
            for f in cf.as_completed(futs):
                try:
                    hashes[futs[f]] = f.result()
                except OSError:
                    hashes[futs[f]] = None
    ts = now_iso()
    with db:
        for rel, size, mt in todo:
            ext = Path(rel).suffix.lower()
            col = lib.collection_of(rel)
            body = extract_text(lib.root / rel, cfg)
            row = db.execute("SELECT id FROM files WHERE path=?", (rel,)).fetchone()
            if row:
                db.execute("UPDATE files SET collection=?,ext=?,size=?,mtime_ns=?,sha256=?,grp=?,indexed_at=? "
                           "WHERE id=?", (col, ext, size, mt, hashes.get(rel), group_key(rel), ts, row["id"]))
                fid = row["id"]
                db.execute("DELETE FROM fts WHERE rowid=?", (fid,))
            else:
                fid = db.execute("INSERT INTO files(path,collection,ext,size,mtime_ns,sha256,grp,indexed_at) "
                                 "VALUES(?,?,?,?,?,?,?,?)",
                                 (rel, col, ext, size, mt, hashes.get(rel), group_key(rel), ts)).lastrowid
            db.execute("INSERT INTO fts(rowid,path,name,collection,body) VALUES(?,?,?,?,?)",
                       (fid, rel, Path(rel).name, col, body))
            if verbose:
                print("  +", rel)
        removed = []
        if only is None:
            for rel, (_, _, fid) in known.items():
                if rel not in seen:
                    removed.append(rel)
                    db.execute("DELETE FROM files WHERE id=?", (fid,))
                    db.execute("DELETE FROM fts WHERE rowid=?", (fid,))
        lib.meta_set("last_index", ts)
    return {"scanned": len(seen), "updated": len(todo), "removed": len(removed) if only is None else 0}


def cmd_index(args):
    lib = Library.locate(args.root); lib.need_init()
    t0 = time.time()
    r = index_paths(lib, full=args.full, verbose=args.verbose)
    r["seconds"] = round(time.time() - t0, 2)
    total = lib.db.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    r["total_indexed"] = total
    out(args, r, f"索引完成：掃描 {r['scanned']}，更新 {r['updated']}，移除 {r['removed']}，"
                 f"共 {total} 條，用時 {r['seconds']}s")

# ----------------------------------------------------------------- find / show / locate

def _fts_phrase(t: str) -> str:
    return '"' + t.replace('"', '""') + '"'


_CC = None


def _st_variants(w: str) -> list[str]:
    """繁簡互通：裝了 opencc（pip install opencc-python-reimplemented）就自動把檢索詞擴充套件成繁/簡兩種寫法。"""
    global _CC
    if _CC is None:
        try:
            import opencc  # type: ignore
            _CC = [opencc.OpenCC("s2t"), opencc.OpenCC("t2s")]
        except Exception:
            _CC = []
    return [c.convert(w) for c in _CC]


def parse_query(q: str, synonyms: dict | None):
    """語法：空格=且；a|b=或；-詞=排除；"帶 空格 的短語"。同義詞自動併入“或”。"""
    try:
        toks = shlex.split(q)
    except ValueError:
        toks = q.split()
    rev = {}
    for k, vs in (synonyms or {}).items():
        grp = [k, *vs]
        for w in grp:
            rev.setdefault(w.lower(), [])
            rev[w.lower()] += [x for x in grp if x not in rev[w.lower()]]
    pos, neg = [], []
    for t in toks:
        if t.startswith("-") and len(t) > 1:
            neg.append(t[1:]); continue
        alts = []
        for a in t.split("|"):
            base = [a, *rev.get(a.lower(), [])]
            for x in base + [v for b in base for v in _st_variants(b)]:
                if x and x not in alts:
                    alts.append(x)
        if alts:
            pos.append(alts)
    return pos, neg


def parse_since(s: str | None):
    if not s:
        return None
    m = re.fullmatch(r"(\d+)\s*([hdwm])", s.strip().lower())
    if m:
        sec = int(m.group(1)) * {"h": 3600, "d": 86400, "w": 604800, "m": 2592000}[m.group(2)]
        return int((time.time() - sec) * 1e9)
    try:
        return int(dt.datetime.fromisoformat(s).timestamp() * 1e9)
    except ValueError:
        die(f"--since 格式不對：{s}（例：7d、12h、2w、2026-10-01）")


def locate(body: str, terms: list[str], max_n=3, ctx=0):
    """在正文裡找命中行：返回 行號 + 頁碼（若有）+ 原文。命中詞越多越靠前。"""
    if not body or not terms or max_n <= 0:
        return []
    lines = body.split("\n")
    lt = [t.lower() for t in terms]
    page, found = None, []
    for i, ln in enumerate(lines, 1):
        m = PAGE_RE.match(ln.strip())
        if m:
            page = int(m.group(1)); continue
        low = ln.lower()
        hit = [t for t in lt if t in low]
        if hit:
            found.append((len(set(hit)), i, page, hit))
    found.sort(key=lambda x: (-x[0], x[1]))
    res = []
    for _, i, pg, hit in found[:max_n]:
        if ctx:
            s0 = max(0, i - 1 - ctx)
            text = "\n".join(f"{n:>6}│ {lines[n-1].rstrip()}" for n in range(s0 + 1, min(len(lines), i + ctx) + 1))
        else:
            text = lines[i - 1].strip()
            if len(text) > 160:
                k = text.lower().find(hit[0]); a = max(0, k - 60)
                text = ("…" if a else "") + text[a:a + 160] + "…"
        res.append({"line": i, "page": pg, "matched": hit, "text": text})
    return sorted(res, key=lambda r: r["line"])


def search(lib: Library, query: str, collection=None, ext=None, source=None, path_glob=None,
           limit=10, files_only=False, name_only=False, since=None, max_loc=3, ctx=0):
    db = lib.db
    pos, neg = parse_query(query, lib.cfg.get("synonyms"))
    fts_clauses, where, wparams = [], [], []
    cols = ["fts.path"] if name_only else ["fts.body", "fts.path"]
    for alts in pos:
        if not name_only and all(len(a) >= 3 for a in alts):
            fts_clauses.append("(" + " OR ".join(_fts_phrase(a) for a in alts) + ")")
        else:
            where.append("(" + " OR ".join(f"{c} LIKE ?" for a in alts for c in cols) + ")")
            wparams += [f"%{a}%" for a in alts for _ in cols]
    match = " AND ".join(fts_clauses)
    for n in neg:
        if match and len(n) >= 3:
            match = f"({match}) NOT {_fts_phrase(n)}"
        else:
            where.append("NOT (fts.body LIKE ? OR fts.path LIKE ?)"); wparams += [f"%{n}%", f"%{n}%"]
    if collection:
        where.append("f.collection=?"); wparams.append(collection)
    if ext:
        exts = [("." + x.strip().lstrip(".")).lower() for x in ext.split(",")]
        where.append(f"f.ext IN ({','.join('?' * len(exts))})"); wparams += exts
    if source:
        where.append("f.source_id=(SELECT id FROM sources WHERE name=?)"); wparams.append(source)
    if path_glob:
        where.append("f.path GLOB ?"); wparams.append(path_glob)
    ts = parse_since(since)
    if ts:
        where.append("f.mtime_ns>=?"); wparams.append(ts)
    if match:
        sql = ("SELECT f.*, bm25(fts, 4.0, 8.0, 1.0, 1.0) AS score, snippet(fts,3,'【','】','…',16) AS snip "
               "FROM fts JOIN files f ON f.id=fts.rowid WHERE fts MATCH ?")
        params = [match] + wparams
        order = " ORDER BY score"
    else:
        sql = "SELECT f.*, 0 AS score, '' AS snip FROM fts JOIN files f ON f.id=fts.rowid WHERE 1=1"
        params = wparams
        order = " ORDER BY f.mtime_ns DESC"
    sql += "".join(" AND " + w for w in where) + order + " LIMIT ?"
    params.append(limit * 5)
    rows = db.execute(sql, params).fetchall()
    terms = [a for alts in pos for a in alts]
    results, seen = [], {}
    for r in rows:
        key = r["path"] if files_only else r["grp"]
        if key in seen:
            seen[key]["hits"].append(r["path"])
            if len(seen[key]["locations"]) < max_loc and not name_only:
                body = db.execute("SELECT body FROM fts WHERE rowid=?", (r["id"],)).fetchone()[0]
                seen[key]["locations"] += [{"path": r["path"], **x} for x in
                                           locate(body, terms, max_loc - len(seen[key]["locations"]), ctx)]
            continue
        locs = []
        if not name_only:
            body = db.execute("SELECT body FROM fts WHERE rowid=?", (r["id"],)).fetchone()[0]
            locs = [{"path": r["path"], **x} for x in locate(body, terms, max_loc, ctx)]
        item = {"group": r["grp"], "hit": r["path"], "hits": [r["path"]], "collection": r["collection"],
                "abs_path": str(lib.root / r["path"]), "locations": locs,
                "snippet": (r["snip"] or "").replace("\n", " ")[:200], "score": round(r["score"], 3)}
        if not files_only:
            item["members"] = [m[0] for m in db.execute(
                "SELECT path FROM files WHERE grp=? ORDER BY ext", (r["grp"],))]
        seen[key] = item; results.append(item)
        if len(results) >= limit:
            break
    return results


def _fmt_loc(l):
    pg = f" 第{l['page']}頁" if l.get("page") else ""
    if "\n" in l["text"]:
        return f"     ▸ {l['path']}:{l['line']}{pg}\n" + l["text"]
    return f"     ▸ {l['path']}:{l['line']}{pg}  {l['text']}"


def cmd_find(args):
    lib = Library.locate(args.root); lib.need_init()
    res = search(lib, args.query, args.collection, args.ext, args.source, args.path, args.limit,
                 args.files, args.name, args.since, args.loc, args.ctx)
    lines = [f"「{args.query}」命中 {len(res)} 組" + ("" if res else "（換同義詞 / 少幾個條件 / 先 status 看索引是否最新）")]
    for i, r in enumerate(res, 1):
        lines.append(f"{i:>2}. [{r['collection']}] {r['group']}")
        if r.get("members") and len(r["members"]) > 1:
            lines.append("     組內：" + " | ".join(Path(m).name for m in r["members"]))
        if r["locations"]:
            lines += [_fmt_loc(l) for l in r["locations"]]
        elif r["snippet"]:
            lines.append("     " + r["snippet"])
    out(args, {"query": args.query, "results": res}, "\n".join(lines))


def cmd_cat(args):
    """精確讀取：按行號區間 / 某行上下文 / 某一頁，只取需要的那一段。"""
    lib = Library.locate(args.root); lib.need_init()
    rel = args.target.replace("\\", "/")
    p = lib.root / rel
    if not p.exists():
        die(f"檔案不存在：{rel}")
    text = extract_text(p, lib.cfg)
    if not text:
        die(f"{rel} 沒有可讀取的文字（圖片/二進位制，或 PDF 缺少 pypdf/pdftotext）")
    lines = text.split("\n")
    total = len(lines)
    if args.page:
        starts = [i for i, l in enumerate(lines, 1) if PAGE_RE.match(l.strip())]
        pages = {int(PAGE_RE.match(lines[i - 1].strip()).group(1)): i for i in starts}
        if args.page not in pages:
            die(f"沒有第 {args.page} 頁（共 {len(pages)} 頁）")
        s = pages[args.page]
        nxt = [i for i in starts if i > s]
        e = (nxt[0] - 1) if nxt else total
    elif args.around:
        s, e = max(1, args.around - args.ctx), min(total, args.around + args.ctx)
    elif args.lines:
        a, _, b = args.lines.partition("-")
        s, e = max(1, int(a)), min(total, int(b) if b else int(a))
    else:
        s, e = 1, min(total, 120)
    seg = [{"n": n, "text": lines[n - 1].rstrip()} for n in range(s, e + 1)]
    out(args, {"path": rel, "abs_path": str(p), "start": s, "end": e, "total_lines": total, "lines": seg},
        f"{rel}  第 {s}-{e} 行 / 共 {total} 行\n" + "\n".join(f"{x['n']:>6}│ {x['text']}" for x in seg))


def cmd_pick(args):
    """呼叫：把檢索結果（整組：圖+原詞）複製到工作目錄，附清單；庫內原件不動。"""
    lib = Library.locate(args.root); lib.need_init()
    db = lib.db
    if args.paths:
        keys = [p.replace("\\", "/") for p in args.paths]
    elif args.query:
        keys = [r["group"] for r in search(lib, args.query, args.collection, args.ext if args.only_hits else None,
                                           args.source, args.path, args.limit, since=args.since, max_loc=0)]
    else:
        die("pick 需要檢索詞，或 --paths")
    files = []
    for k in keys:
        rows = db.execute("SELECT f.path, f.sha256, s.name src FROM files f LEFT JOIN sources s ON s.id=f.source_id "
                          "WHERE f.grp=? OR f.path=? ORDER BY f.path", (k, k)).fetchall()
        for r in rows:
            if args.ext and not args.only_hits:
                if Path(r["path"]).suffix.lower().lstrip(".") not in [x.strip().lstrip(".").lower() for x in args.ext.split(",")]:
                    continue
            if r["path"] not in [f["path"] for f in files]:
                files.append(dict(r))
    dest = Path(args.to).resolve()
    if lib.root == dest or lib.root in dest.parents:
        die("--to 不能指向庫內部")
    dest.mkdir(parents=True, exist_ok=True)
    copied = []
    for f in files:
        target = dest / (Path(f["path"]).name if args.flat else f["path"])
        if target.exists():
            target = target.with_name(f"{target.stem}__{f['sha256'][:6] if f['sha256'] else 'dup'}{target.suffix}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(lib.root / f["path"], target)
        copied.append({"from": f["path"], "to": str(target), "sha256": f["sha256"], "source": f["src"]})
    (dest / "_picked.json").write_text(json.dumps({"picked_at": now_iso(), "library": str(lib.root),
                                                   "query": args.query, "files": copied},
                                                  ensure_ascii=False, indent=2), "utf-8")
    out(args, {"to": str(dest), "count": len(copied), "files": copied},
        f"已取出 {len(copied)} 個檔案（{len(keys)} 組）到 {dest}，清單：_picked.json")


def cmd_vocab(args):
    """庫的高頻中文片段：接入後用來了解主題、討論需求、挑檢索詞。"""
    lib = Library.locate(args.root); lib.need_init()
    db = lib.db
    db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS fts_vocab USING fts5vocab(fts, 'col')")
    rows = db.execute("SELECT term, SUM(doc) d FROM fts_vocab WHERE col IN ('body','name') "
                      "GROUP BY term ORDER BY d DESC LIMIT 20000").fetchall()
    cjk = re.compile(r"^[㐀-鿿]{3}$")
    terms = [(t, d) for t, d in rows if cjk.match(t)]
    # 合併重疊片段：相鄰 trigram 首尾相接且頻次接近 → 拼成更長的詞
    merged, used = [], set()
    by = dict(terms)
    for t, d in terms:
        if t in used:
            continue
        w = t
        while True:
            nxt = [(u, by[u]) for u in by if u not in used and u != t and u[:2] == w[-2:] and by[u] >= d * 0.8 and u[2] not in w]
            if not nxt:
                break
            u = max(nxt, key=lambda x: x[1])[0]; used.add(u); w += u[2]
        used.add(t); merged.append((w, d))
        if len(merged) >= args.n:
            break
    out(args, [{"term": w, "docs": d} for w, d in merged],
        "高頻片段（出現檔案數）：\n" + "  ".join(f"{w}({d})" for w, d in merged))


def cmd_show(args):
    lib = Library.locate(args.root); lib.need_init()
    target = args.target.replace("\\", "/")
    row = lib.db.execute("SELECT * FROM files WHERE path=?", (target,)).fetchone()
    grp = row["grp"] if row else target
    members = [dict(r) for r in lib.db.execute(
        "SELECT f.*, s.name AS source_name, s.url AS source_url FROM files f "
        "LEFT JOIN sources s ON s.id=f.source_id WHERE f.grp=? ORDER BY f.ext", (grp,))]
    if not members:
        die(f"索引裡沒有：{target}")
    for m in members:
        m["abs_path"] = str(lib.root / m["path"])
        m.pop("id", None)
    text = [f"組：{grp}（{len(members)} 個檔案）"]
    for m in members:
        text.append(f"- {m['path']}  {human(m['size'])}  sha256={str(m['sha256'])[:12]}…  "
                    f"來源={m['source_name'] or '-'}  批次={m['batch_id'] or '-'}")
    out(args, {"group": grp, "members": members}, "\n".join(text))

# ----------------------------------------------------------------- status

def stale_check(lib: Library):
    known = {r["path"]: (r["size"], r["mtime_ns"]) for r in lib.db.execute("SELECT path,size,mtime_ns FROM files")}
    new, changed, seen = [], [], set()
    for rel, e in lib.walk():
        seen.add(rel)
        k = known.get(rel)
        if not k:
            new.append(rel); continue
        try:
            st = e.stat()
        except OSError:
            continue
        if (st.st_size, st.st_mtime_ns) != k:
            changed.append(rel)
    missing = [p for p in known if p not in seen]
    return new, changed, missing


def cmd_status(args):
    lib = Library.locate(args.root); lib.need_init()
    db = lib.db
    cols = [dict(r) for r in db.execute(
        "SELECT collection, COUNT(*) files, SUM(size) bytes, COUNT(DISTINCT grp) groups "
        "FROM files GROUP BY collection ORDER BY files DESC")]
    srcs = [dict(r) for r in db.execute(
        "SELECT s.name, s.url, s.collection, s.last_ingest_at, COUNT(f.id) files "
        "FROM sources s LEFT JOIN files f ON f.source_id=s.id GROUP BY s.id ORDER BY s.name")]
    batches = [dict(r) for r in db.execute("SELECT * FROM batches ORDER BY created_at DESC LIMIT 5")]
    new, changed, missing = stale_check(lib)
    data = {"root": str(lib.root), "last_index": lib.meta_get("last_index"),
            "collections": cols, "sources": srcs, "recent_batches": batches,
            "pending": {"new": len(new), "changed": len(changed), "missing": len(missing),
                        "examples": (new + changed + missing)[:10]}}
    t = [f"庫：{lib.root}", f"最後索引：{data['last_index']}",
         f"集合 {len(cols)} 個；獨立來源 {len(srcs)} 個", ""]
    t += [f"  {c['collection']:<28} {c['files']:>7} 檔案 {c['groups']:>7} 組 {human(c['bytes'] or 0):>9}" for c in cols]
    if srcs:
        t += ["", "來源："] + [f"  {s['name']}  ({s['files']} 檔案)  {s['url'] or ''}" for s in srcs]
    p = data["pending"]
    t += ["", f"未入索引的改動：新增 {p['new']}，修改 {p['changed']}，消失 {p['missing']}"
          + ("  → 執行 index" if (p['new'] or p['changed'] or p['missing']) else "  （索引是新的）")]
    out(args, data, "\n".join(t))

# ----------------------------------------------------------------- sources

def cmd_source(args):
    lib = Library.locate(args.root); lib.need_init()
    db = lib.db
    if args.action == "add":
        with db:
            db.execute("INSERT INTO sources(name,url,collection,notes,created_at) VALUES(?,?,?,?,?) "
                       "ON CONFLICT(name) DO UPDATE SET url=COALESCE(excluded.url,url), "
                       "collection=COALESCE(excluded.collection,collection), notes=COALESCE(excluded.notes,notes)",
                       (args.name, args.url, args.collection, args.notes, now_iso()))
        out(args, {"ok": True, "name": args.name}, f"來源已登記：{args.name}")
    else:
        rows = [dict(r) for r in db.execute("SELECT * FROM sources ORDER BY name")]
        out(args, rows, "\n".join(f"- {r['name']}  [{r['collection'] or '-'}]  {r['url'] or ''}  {r['notes'] or ''}"
                                  for r in rows) or "（還沒有登記來源）")

# ----------------------------------------------------------------- ingest / undo / restore

def cmd_ingest(args):
    lib = Library.locate(args.root); lib.need_init()
    db = lib.db
    src_dir = Path(args.incoming).resolve()
    if not src_dir.is_dir():
        die(f"待入庫目錄不存在：{src_dir}")
    if lib.root == src_dir or lib.root in src_dir.parents:
        die("待入庫目錄不能放在庫內部（會被當成庫檔案），請放到庫外。")
    col_root = lib.collection_path(args.collection)
    dest_root = col_root / args.dest if args.dest else col_root
    existing = {}
    for r in db.execute("SELECT sha256,path FROM files WHERE sha256 IS NOT NULL"):
        existing.setdefault(r[0], r[1])
    plan, dup, renamed, in_batch = [], [], 0, {}
    files = sorted(walk_files(src_dir, lib.cfg["exclude"]), key=lambda x: x[0])
    with cf.ThreadPoolExecutor(max_workers=int(lib.cfg.get("hash_workers", 8))) as ex:
        hs = list(ex.map(lambda x: sha256_file(src_dir / x[0]), files))
    for (rel, _), h in zip(files, hs):
        if h in existing:
            dup.append({"file": rel, "already_in_library": existing[h]}); continue
        if h in in_batch:
            dup.append({"file": rel, "already_in_this_batch": in_batch[h]}); continue
        dest = dest_root / rel
        if dest.exists():
            stem, suf, n = dest.name.split(".", 1)[0], "".join(dest.suffixes), 2
            while True:
                cand = dest.with_name(f"{stem}__v{n}{suf}")
                if not cand.exists():
                    dest = cand; renamed += 1; break
                n += 1
        drel = dest.relative_to(lib.root).as_posix()
        in_batch[h] = drel
        plan.append({"from": rel, "to": drel, "sha256": h})
    summary = {"incoming": str(src_dir), "collection": args.collection, "source": args.source,
               "to_add": len(plan), "duplicates_skipped": len(dup), "renamed_to_avoid_overwrite": renamed,
               "applied": False}
    if not args.apply:
        summary["plan_preview"] = plan[:15]; summary["duplicates_preview"] = dup[:10]
        t = [f"【演練】將入庫 {len(plan)} 個檔案到 [{args.collection}]，跳過重複 {len(dup)}，"
             f"避免覆蓋而改名 {renamed}。"]
        t += [f"  {p['from']}  →  {p['to']}" for p in plan[:15]]
        if len(plan) > 15:
            t.append(f"  …… 另 {len(plan)-15} 個")
        t.append("確認無誤後加 --apply 執行。")
        return out(args, summary, "\n".join(t))
    bid = dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + hashlib.sha1(str(src_dir).encode()).hexdigest()[:6]
    with db:
        sid = None
        if args.source:
            db.execute("INSERT OR IGNORE INTO sources(name,url,collection,created_at) VALUES(?,?,?,?)",
                       (args.source, args.url, args.collection, now_iso()))
            sid = db.execute("SELECT id FROM sources WHERE name=?", (args.source,)).fetchone()[0]
            db.execute("UPDATE sources SET last_ingest_at=? WHERE id=?", (now_iso(), sid))
        for p in plan:
            dest = lib.root / p["to"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            (shutil.move if args.move else shutil.copy2)(str(src_dir / p["from"]), str(dest))
            db.execute("INSERT INTO batch_files VALUES(?,?,?)", (bid, p["to"], p["sha256"]))
        db.execute("INSERT INTO batches VALUES(?,?,?,?,?,?,?,?)",
                   (bid, now_iso(), sid, args.collection, str(src_dir), len(plan), len(dup), "applied"))
    index_paths(lib, only={p["to"] for p in plan})
    with db:
        for p in plan:
            db.execute("UPDATE files SET source_id=?, batch_id=? WHERE path=?", (sid, bid, p["to"]))
    (lib.dd / "batches" / f"{bid}.json").write_text(json.dumps(
        {**summary, "batch": bid, "files": plan, "duplicates": dup}, ensure_ascii=False, indent=2), "utf-8")
    summary.update(applied=True, batch=bid)
    out(args, summary, f"已入庫 {len(plan)} 個檔案，批次 {bid}；跳過重複 {len(dup)}。撤回：steward.py undo {bid}")


def _batch_files(lib, bid):
    b = lib.db.execute("SELECT * FROM batches WHERE id=?", (bid,)).fetchone()
    if not b:
        die(f"沒有這個批次：{bid}（steward.py status 可看最近批次）")
    return b, [r[0] for r in lib.db.execute("SELECT path FROM batch_files WHERE batch_id=?", (bid,))]


def cmd_undo(args):
    lib = Library.locate(args.root); lib.need_init()
    b, paths = _batch_files(lib, args.batch)
    if b["status"] != "applied":
        die(f"批次狀態是 {b['status']}，不能撤回")
    present = [p for p in paths if (lib.root / p).exists()]
    if not args.apply:
        return out(args, {"batch": args.batch, "will_move_to_trash": len(present), "applied": False},
                   f"【演練】將把批次 {args.batch} 的 {len(present)} 個檔案移入 .steward/trash/{args.batch}/（可恢復）。加 --apply 執行。")
    trash = lib.dd / "trash" / args.batch
    with lib.db:
        for p in present:
            dst = trash / p; dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(lib.root / p), str(dst))
            fid = lib.db.execute("SELECT id FROM files WHERE path=?", (p,)).fetchone()
            if fid:
                lib.db.execute("DELETE FROM files WHERE id=?", (fid[0],))
                lib.db.execute("DELETE FROM fts WHERE rowid=?", (fid[0],))
        lib.db.execute("UPDATE batches SET status='undone' WHERE id=?", (args.batch,))
    out(args, {"batch": args.batch, "moved": len(present), "applied": True},
        f"已撤回批次 {args.batch}：{len(present)} 個檔案移入回收區。恢復：steward.py restore {args.batch}")


def cmd_restore(args):
    lib = Library.locate(args.root); lib.need_init()
    b, paths = _batch_files(lib, args.batch)
    if b["status"] != "undone":
        die(f"批次狀態是 {b['status']}，只有已撤回的批次可以恢復")
    trash = lib.dd / "trash" / args.batch
    conflicts = [p for p in paths if (lib.root / p).exists()]
    if conflicts:
        die(f"原位置已有同名檔案，未恢復：{conflicts[:5]}")
    for p in paths:
        s = trash / p
        if s.exists():
            (lib.root / p).parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(s), str(lib.root / p))
    index_paths(lib, only=set(paths))
    with lib.db:
        for p in paths:
            lib.db.execute("UPDATE files SET source_id=?, batch_id=? WHERE path=?", (b["source_id"], args.batch, p))
        lib.db.execute("UPDATE batches SET status='applied' WHERE id=?", (args.batch,))
    shutil.rmtree(trash, ignore_errors=True)
    out(args, {"batch": args.batch, "restored": len(paths)}, f"批次 {args.batch} 已恢復 {len(paths)} 個檔案。")

# ----------------------------------------------------------------- snapshot / diff / verify

def current_manifest(lib):
    return {r["path"]: {"sha256": r["sha256"], "size": r["size"]}
            for r in lib.db.execute("SELECT path,sha256,size FROM files")}


def cmd_snapshot(args):
    lib = Library.locate(args.root); lib.need_init()
    index_paths(lib)
    man = current_manifest(lib)
    name = dt.datetime.now().strftime("%Y%m%d-%H%M%S") + (f"-{args.label}" if args.label else "")
    p = lib.dd / "snapshots" / f"{name}.json"
    p.parent.mkdir(exist_ok=True)
    p.write_text(json.dumps({"created_at": now_iso(), "label": args.label, "files": man},
                            ensure_ascii=False), "utf-8")
    out(args, {"snapshot": name, "files": len(man)}, f"快照 {name}：{len(man)} 個檔案")


def _load_snap(lib, name):
    d = lib.dd / "snapshots"
    if name in ("latest", "prev"):
        snaps = sorted(d.glob("*.json"))
        idx = -1 if name == "latest" else -2
        if len(snaps) < (1 if name == "latest" else 2):
            die("快照數量不夠")
        return json.loads(snaps[idx].read_text("utf-8"))["files"], snaps[idx].stem
    p = d / f"{name}.json"
    if not p.exists():
        cands = sorted(d.glob(f"{name}*.json"))
        if not cands:
            die(f"找不到快照 {name}")
        p = cands[-1]
    return json.loads(p.read_text("utf-8"))["files"], p.stem


def cmd_diff(args):
    lib = Library.locate(args.root); lib.need_init()
    a, an = _load_snap(lib, args.a)
    if args.b == "now":
        index_paths(lib); b, bn = current_manifest(lib), "當前"
    else:
        b, bn = _load_snap(lib, args.b)
    added = sorted(set(b) - set(a)); removed = sorted(set(a) - set(b))
    modified = sorted(p for p in set(a) & set(b) if a[p]["sha256"] != b[p]["sha256"])
    data = {"from": an, "to": bn, "added": added, "removed": removed, "modified": modified}
    t = [f"{an} → {bn}：新增 {len(added)}，刪除 {len(removed)}，修改 {len(modified)}"]
    for lab, lst in (("+", added), ("-", removed), ("~", modified)):
        t += [f"  {lab} {x}" for x in lst[:20]]
    out(args, data, "\n".join(t))


def cmd_verify(args):
    lib = Library.locate(args.root); lib.need_init()
    t0 = time.time()
    rows = [dict(r) for r in lib.db.execute(
        "SELECT path,sha256 FROM files" + (" WHERE collection=?" if args.collection else ""),
        (args.collection,) if args.collection else ())]
    missing, bad = [], []

    def chk(r):
        p = lib.root / r["path"]
        if not p.exists():
            return ("missing", r["path"])
        if r["sha256"] and sha256_file(p) != r["sha256"]:
            return ("modified", r["path"])
        return None

    with cf.ThreadPoolExecutor(max_workers=int(lib.cfg.get("hash_workers", 8))) as ex:
        for res in ex.map(chk, rows):
            if res:
                (missing if res[0] == "missing" else bad).append(res[1])
    new, _, _ = stale_check(lib)
    ok = not (missing or bad)
    data = {"checked": len(rows), "missing": missing, "modified": bad, "unregistered": new[:50],
            "unregistered_count": len(new), "ok": ok, "seconds": round(time.time() - t0, 2)}
    out(args, data, f"校驗 {len(rows)} 個檔案（{data['seconds']}s）：缺失 {len(missing)}，內容變化 {len(bad)}，"
                    f"未登記新檔案 {len(new)} → {'通過' if ok else '有問題'}"
        + "".join(f"\n  缺失 {x}" for x in missing[:10]) + "".join(f"\n  變化 {x}" for x in bad[:10]))
    if not ok:
        sys.exit(1)

# ----------------------------------------------------------------- doctor / selftest

def cmd_doctor(args):
    checks = []
    checks.append(("Python ≥ 3.8", sys.version_info >= (3, 8), sys.version.split()[0]))
    try:
        c = sqlite3.connect(":memory:")
        c.execute("CREATE VIRTUAL TABLE t USING fts5(x, tokenize='trigram')")
        checks.append(("SQLite FTS5 trigram（中文檢索）", True, sqlite3.sqlite_version))
    except Exception as e:
        checks.append(("SQLite FTS5 trigram（中文檢索）", False, f"{sqlite3.sqlite_version}: {e}；需 ≥3.34，升級 Python 即可"))
    checks.append(("繁簡互通檢索（可選）", bool(_st_variants("檢索") and _st_variants("檢索")[0] == "檢索"),
                   "已啟用" if _st_variants("檢索") else "未安裝：pip install opencc-python-reimplemented"))
    try:
        import pypdf  # type: ignore  # noqa
        pdf_ok, pdf_d = True, "pypdf"
    except ImportError:
        pdf_ok, pdf_d = bool(shutil.which("pdftotext")), ("pdftotext" if shutil.which("pdftotext") else "未安裝：pip install pypdf")
    checks.append(("PDF 正文（可選）", pdf_ok, pdf_d))
    lib = Library.locate(args.root)
    checks.append(("庫已適配", lib.initialized, str(lib.root)))
    if lib.initialized:
        try:
            ok = lib.db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            checks.append(("索引庫完整", ok, str(lib.db_path)))
        except Exception as e:
            checks.append(("索引庫完整", False, str(e)))
        checks.append(("庫目錄可寫", os.access(lib.root, os.W_OK), ""))
        n = lib.db.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        checks.append(("已有索引", n > 0, f"{n} 條"))
    data = [{"check": a, "ok": b, "detail": c} for a, b, c in checks]
    out(args, data, "\n".join(f"{'✔' if d['ok'] else '✘'} {d['check']}  {d['detail']}" for d in data))


def cmd_selftest(args):
    me = Path(__file__).resolve()
    tmp = Path(tempfile.mkdtemp(prefix="steward-selftest-"))
    lib_dir, inc = tmp / "lib", tmp / "incoming"
    (lib_dir / "海報風格" / "復古").mkdir(parents=True)
    (lib_dir / "字型").mkdir()
    (lib_dir / "海報風格" / "復古" / "p001.png").write_bytes(b"\x89PNG fake 1")
    (lib_dir / "海報風格" / "復古" / "p001.txt").write_text("紅色復古海報，手寫體標題，顆粒質感", "utf-8")
    (lib_dir / "字型" / "說明.md").write_text("思源黑體 用於正文", "utf-8")
    (lib_dir / "規範").mkdir()
    (lib_dir / "規範" / "品牌手冊.md").write_text("# 品牌手冊\n\n## 顏色\n主色为深海蓝，辅色为暖橙。\n\n## 字型\n標題使用思源宋體。\n", "utf-8")
    with zipfile.ZipFile(lib_dir / "規範" / "會議紀要.docx", "w") as z:
        z.writestr("word/document.xml", '<w:document><w:body><w:p><w:r><w:t>第一段：預算討論</w:t></w:r></w:p>'
                   '<w:p><w:r><w:t>第二段：Logo 必須保留安全邊距</w:t></w:r></w:p></w:body></w:document>')
    with zipfile.ZipFile(lib_dir / "規範" / "提案.pptx", "w") as z:
        z.writestr("ppt/slides/slide1.xml", "<p:sld><a:t>封面</a:t></p:sld>")
        z.writestr("ppt/slides/slide2.xml", "<p:sld><a:t>競品分析與定價策略</a:t></p:sld>")
    (inc / "新").mkdir(parents=True)
    (inc / "新" / "q1.png").write_bytes(b"\x89PNG fake 2")
    (inc / "新" / "q1.json").write_text(json.dumps({"prompt": "藍色極簡海報 留白"}, ensure_ascii=False), "utf-8")
    (inc / "dup.png").write_bytes(b"\x89PNG fake 1")
    import subprocess

    def run(*a, check=True):
        r = subprocess.run([sys.executable, str(me), *a, "--root", str(lib_dir), "--json"],
                           capture_output=True, text=True, encoding="utf-8")
        if check and r.returncode != 0:
            raise AssertionError(f"{a} 失敗：{r.stderr}")
        return json.loads(r.stdout) if r.stdout.strip() else {}

    steps = []
    try:
        run("init"); steps.append("init")
        assert run("index")["total_indexed"] == 6; steps.append("index")
        r = run("find", "深海蓝")["results"]
        assert r[0]["locations"][0]["line"] == 4, r; steps.append("行號定位")
        r = run("find", "安全邊距")["results"]
        assert r and r[0]["hit"].endswith(".docx"); steps.append("docx 全文")
        r = run("find", "定價策略")["results"]
        assert r[0]["locations"][0]["page"] == 2, r; steps.append("pptx 頁碼定位")
        assert len(run("find", "深海蓝|安全邊距")["results"]) == 2; steps.append("或 |")
        if _st_variants("檢索"):
            assert run("find", "深海藍")["results"]; steps.append("繁簡互通")
        assert not run("find", "復古海報 -手寫體")["results"]; steps.append("排除 -")
        c = run("cat", "規範/品牌手冊.md", "--around", "4", "--ctx", "1")
        assert [x["n"] for x in c["lines"]] == [3, 4, 5]; steps.append("cat 精確讀取")
        assert run("cat", "規範/提案.pptx", "--page", "2")["lines"][1]["text"].startswith("競品"); steps.append("cat 按頁")
        cfgp = lib_dir / ".steward" / "config.json"
        cfg = json.loads(cfgp.read_text("utf-8")); cfg["synonyms"] = {"復古海報": ["vintage"]}
        cfgp.write_text(json.dumps(cfg, ensure_ascii=False), "utf-8")
        assert run("find", "vintage")["results"]; steps.append("同義詞")
        pk = run("pick", "復古海報", "--to", str(tmp / "out"))
        assert pk["count"] == 2 and (tmp / "out" / "_picked.json").exists(); steps.append("pick 整組取出")
        assert run("vocab")[0]["term"]; steps.append("vocab")
        r = run("find", "復古海報")["results"]
        assert r and len(r[0]["members"]) == 2, r; steps.append("find 中文+圖文成組")
        assert run("find", "黑體")["results"]; steps.append("find 兩字短詞")
        run("snapshot", "--label", "before"); steps.append("snapshot")
        d = run("ingest", str(inc), "--collection", "海報風格", "--source", "測試官網")
        assert d["to_add"] == 2 and d["duplicates_skipped"] == 1 and not d["applied"]; steps.append("ingest 演練+去重")
        d = run("ingest", str(inc), "--collection", "海報風格", "--source", "測試官網", "--apply")
        bid = d["batch"]; steps.append("ingest 執行")
        assert run("find", "極簡海報", "--source", "測試官網")["results"]; steps.append("按來源檢索")
        assert len(run("diff", "latest", "now")["added"]) == 2; steps.append("diff")
        run("undo", bid, "--apply"); assert not (lib_dir / "海報風格" / "新" / "q1.png").exists(); steps.append("undo")
        run("restore", bid); assert (lib_dir / "海報風格" / "新" / "q1.png").exists(); steps.append("restore")
        assert run("verify")["ok"]; steps.append("verify")
        (lib_dir / "字型" / "說明.md").write_text("被改了", "utf-8")
        v = run("verify", check=False); assert not v["ok"] and v["modified"]; steps.append("篡改檢出")
        ok = True
    except AssertionError as e:
        ok = False; steps.append(f"失敗：{e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    out(args, {"ok": ok, "steps": steps}, ("自檢通過 ✔ " if ok else "自檢失敗 ✘ ") + " → ".join(steps))
    if not ok:
        sys.exit(1)

# ----------------------------------------------------------------- main

def main():
    _utf8_stdout()
    ap = argparse.ArgumentParser(prog="steward.py", description="本地資料庫接管/檢索/管理 CLI")
    ap.add_argument("--version", action="version", version=VERSION)
    sp = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, help_):
        p = sp.add_parser(name, help=help_)
        p.add_argument("--root", help="庫根目錄（預設：向上查詢 .steward 或 STEWARD_ROOT）")
        p.add_argument("--json", action="store_true", help="JSON 輸出")
        p.set_defaults(fn=fn)
        return p

    p = add("survey", cmd_survey, "摸底，輸出庫地圖"); p.add_argument("--out", help="把地圖寫到檔案（如 LIBRARY_MAP.md）")
    p = add("init", cmd_init, "生成適配配置")
    p.add_argument("--collection-depth", type=int, default=1)
    p.add_argument("--collections", help='JSON 或 JSON 檔案：{"集合名":"相對路徑"}')
    p.add_argument("--exclude", help="額外排除，逗號分隔的通配")
    p.add_argument("--no-hash", action="store_true"); p.add_argument("--force", action="store_true")
    p = add("index", cmd_index, "增量索引"); p.add_argument("--full", action="store_true"); p.add_argument("-v", "--verbose", action="store_true")
    p = add("find", cmd_find, "檢索 + 精確定位（行號/頁碼）")
    p.add_argument("query", help='空格=且，a|b=或，-詞=排除，"短語"'); p.add_argument("-c", "--collection"); p.add_argument("-e", "--ext", help="png,jpg")
    p.add_argument("-s", "--source"); p.add_argument("-p", "--path", help="路徑通配，如 '海報/*'")
    p.add_argument("-n", "--limit", type=int, default=10); p.add_argument("--files", action="store_true", help="不按組聚合")
    p.add_argument("--name", action="store_true", help="只搜檔名/路徑"); p.add_argument("--since", help="7d / 12h / 2026-10-01")
    p.add_argument("--loc", type=int, default=3, help="每組最多顯示幾處命中行"); p.add_argument("--ctx", type=int, default=0, help="命中行上下文行數")
    p = add("cat", cmd_cat, "精確讀取檔案片段"); p.add_argument("target")
    p.add_argument("--lines", help="120-160"); p.add_argument("--around", type=int); p.add_argument("--ctx", type=int, default=8)
    p.add_argument("--page", type=int)
    p = add("pick", cmd_pick, "把檢索結果整組取出到工作目錄"); p.add_argument("query", nargs="?")
    p.add_argument("--to", required=True); p.add_argument("--paths", nargs="+"); p.add_argument("-c", "--collection")
    p.add_argument("-e", "--ext", help="只取這些副檔名，如 png"); p.add_argument("--only-hits", action="store_true", help="-e 用作檢索過濾而非取件過濾")
    p.add_argument("-s", "--source"); p.add_argument("-p", "--path"); p.add_argument("-n", "--limit", type=int, default=10)
    p.add_argument("--since"); p.add_argument("--flat", action="store_true", help="不保留目錄結構")
    p = add("vocab", cmd_vocab, "庫的高頻片段"); p.add_argument("-n", type=int, default=60)
    p = add("show", cmd_show, "檢視檔案/組"); p.add_argument("target")
    add("status", cmd_status, "現狀概覽")
    p = add("source", cmd_source, "來源登記"); p.add_argument("action", choices=["add", "list"])
    p.add_argument("--name"); p.add_argument("--url"); p.add_argument("--collection"); p.add_argument("--notes")
    p = add("ingest", cmd_ingest, "入庫（預設演練）")
    p.add_argument("incoming"); p.add_argument("--collection", required=True); p.add_argument("--source")
    p.add_argument("--url"); p.add_argument("--dest", help="集合內子目錄"); p.add_argument("--move", action="store_true")
    p.add_argument("--apply", action="store_true")
    p = add("undo", cmd_undo, "撤回批次（預設演練）"); p.add_argument("batch"); p.add_argument("--apply", action="store_true")
    p = add("restore", cmd_restore, "恢復已撤回批次"); p.add_argument("batch")
    p = add("snapshot", cmd_snapshot, "版本快照"); p.add_argument("--label")
    p = add("diff", cmd_diff, "比較快照"); p.add_argument("a", nargs="?", default="latest"); p.add_argument("b", nargs="?", default="now")
    p = add("verify", cmd_verify, "完整性校驗"); p.add_argument("-c", "--collection")
    add("doctor", cmd_doctor, "健康檢查")
    add("selftest", cmd_selftest, "全流程自檢")
    args = ap.parse_args()
    if args.cmd == "source" and args.action == "add" and not args.name:
        die("source add 需要 --name")
    args.fn(args)


if __name__ == "__main__":
    main()
