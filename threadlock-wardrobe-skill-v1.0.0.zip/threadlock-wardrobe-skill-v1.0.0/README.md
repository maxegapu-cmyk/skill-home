# Threadlock Wardrobe Skill

A clean-room, model-agnostic garment asset and continuity layer for anime and photoreal generation workflows.

## Why this exists

Most clothing workflows fail for the same reason: the outfit exists only as a prompt or a reference image. Every new pose asks the model to rediscover the garment. Threadlock instead stores the outfit as a small structured asset with evidence, unknowns, lock levels and continuity rules.

This package does **not** bundle or copy third-party model code. Public GitHub projects are treated as optional execution backends. The original contribution here is the representation, routing logic, compiler, QA gate, schemas and workflow discipline around them.

## Core idea

`reference(s) -> evidence map -> garment asset -> backend brief -> render/try-on -> continuity gate -> local repair`

The asset is the authority. Generated images are candidates.

## Included

- `SKILL.md` — operating instructions for an AI coding/creative agent.
- `threadlock/` — dependency-free Python CLI.
- `schemas/` — JSON schemas for assets and review scores.
- `examples/` — anime and real garment assets plus a QA example.
- `docs/` — architecture, backend routing, production workflows and public-source notes.
- `configs/backends.example.json` — example routing configuration.
- `tests/` — release checks.

## Quick start

```bash
cd threadlock-wardrobe-skill-v1.0.0
python -m threadlock.cli validate examples/anime_asset.json
python -m threadlock.cli compile examples/anime_asset.json --mode anime --task render
python -m threadlock.cli report examples/real_asset.json -o report.html
python -m threadlock.cli score examples/continuity_score.json
```

## What makes it different

### 1. Unknowns stay unknown

Occluded regions are recorded as unknown, not silently hallucinated into the canonical design.

### 2. Outfit identity is separated from person identity

Face/body references, pose controls, garment references and style references are different control channels. They should not fight for the same attention path when the backend allows separation.

### 3. Anime and real share facts, not rendering rules

A zipper, pocket layout, wrap direction or emblem position can be shared across domains. Fabric microtexture, shading, folds and linework are presentation-specific.

### 4. Continuity is a release gate

Every output is checked against garment structure, not just aesthetic similarity.

## Important limitation

Threadlock can organize and constrain reconstruction, but it cannot recover truly invisible design facts from a single image. If the back of a jacket is never shown, a generated back view is an informed reconstruction, not evidence.
