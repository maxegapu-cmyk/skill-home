# Threadlock v1.0.0 Test Report

Date: 2026-10-01

## Development-directory tests

- `python -m unittest discover -s tests -p 'test_*.py' -v` — PASS (4/4)
- `./tests/test_cli.sh` — PASS

Covered:

- anime + real example manifest validation;
- execution brief compilation;
- explicit unknown-region output;
- continuity weighted scoring;
- HTML report generation;
- CLI smoke path.

## Release-package test

The ZIP was extracted into a fresh temporary directory and tested from the extracted package.

- `sha256sum -c MANIFEST.sha256` — PASS
- unit tests — PASS (4/4)
- CLI smoke tests — PASS
- offline local install with `pip install . --no-deps --no-build-isolation --target <temp>` — PASS
- installed-package CLI validation — PASS
- installed-package real try-on brief compilation — PASS

## Environment note

A first isolated PEP 517 install attempt tried to download the declared build dependency (`setuptools>=68`) and failed because the execution sandbox has no internet access. Re-running with `--no-build-isolation` against the already installed setuptools 82.0.1 passed. This is an environment/network limitation, not an application test failure.

## Not tested

External GPU/model backends and their checkpoints are not bundled, so their inference quality and installation were not tested in this package release.
