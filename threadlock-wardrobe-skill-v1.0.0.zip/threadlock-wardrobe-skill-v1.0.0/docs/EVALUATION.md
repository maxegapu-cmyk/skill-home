# Evaluation protocol

## Golden test set

For a serious project, keep a small fixed set of views for every canonical outfit:

- neutral front;
- neutral back if actually known;
- left/right 3/4;
- seated or bent pose;
- arm raised / high cloth deformation;
- one close detail view of the most distinctive construction feature.

## Hard-fail examples

Regardless of numeric score, repair or reject when any approved hard-lock fact changes:

- garment disappears or merges with another layer;
- left/right asymmetry flips;
- logo/emblem moves sides;
- zipper becomes buttons;
- pocket count or placement changes;
- jacket length changes category (cropped -> hip length, etc.);
- skirt/pants layering order changes;
- material class changes drastically (matte canvas -> glossy satin);
- an unknown region becomes a repeated invented detail and is then treated as canonical without approval.

## Why the scorer is partly manual

Pixel similarity is not garment identity. A garment can have similar colors while its construction is wrong. Threadlock therefore keeps a human/vision-model review rubric as the authority. Automated CV metrics may assist but should not replace structural review.
