import json
import tempfile
import unittest
from pathlib import Path

from threadlock.core import load_asset
from threadlock.compiler import compile_brief
from threadlock.qa import ContinuityScore
from threadlock.report import render_html

ROOT = Path(__file__).resolve().parents[1]

class ThreadlockTests(unittest.TestCase):
    def test_examples_validate(self):
        for name in ["anime_asset.json", "real_asset.json"]:
            asset = load_asset(ROOT / "examples" / name)
            self.assertEqual(asset.validate(), [])

    def test_compile_contains_hard_lock(self):
        asset = load_asset(ROOT / "examples" / "anime_asset.json")
        text = compile_brief(asset, "anime", "render")
        self.assertIn("HARD-LOCK GARMENT FACTS", text)
        self.assertIn("cropped_jacket", text)
        self.assertIn("UNKNOWN / UNPROVEN REGIONS", text)

    def test_score(self):
        raw = json.loads((ROOT / "examples" / "continuity_score.json").read_text())
        score = ContinuityScore(**raw)
        self.assertEqual(score.validate(), [])
        self.assertGreater(score.weighted_total(), 0.92)
        self.assertEqual(score.verdict(), "release")

    def test_report(self):
        asset = load_asset(ROOT / "examples" / "real_asset.json")
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "report.html"
            render_html(asset, out)
            self.assertTrue(out.exists())
            self.assertIn("Ivory Travel Set", out.read_text())

if __name__ == "__main__":
    unittest.main()
