from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List

@dataclass
class ContinuityScore:
    component_presence: float
    silhouette: float
    color_blocking: float
    material: float
    construction: float
    logos_marks: float
    layering: float
    uncertainty_discipline: float

    def validate(self) -> List[str]:
        errors = []
        for key, value in asdict(self).items():
            if not 0 <= value <= 1:
                errors.append(f"{key} must be between 0 and 1")
        return errors

    def weighted_total(self) -> float:
        weights: Dict[str, float] = {
            "component_presence": 0.16,
            "silhouette": 0.18,
            "color_blocking": 0.10,
            "material": 0.12,
            "construction": 0.16,
            "logos_marks": 0.10,
            "layering": 0.12,
            "uncertainty_discipline": 0.06,
        }
        raw = asdict(self)
        return sum(raw[k] * w for k, w in weights.items())

    def verdict(self) -> str:
        total = self.weighted_total()
        if total >= 0.92:
            return "release"
        if total >= 0.84:
            return "repair"
        return "reject"
