from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List

LOCK_LEVELS = {"hard", "soft", "free"}
CERTAINTY_LEVELS = {"observed", "inferred", "unknown"}

@dataclass
class Evidence:
    source: str
    region: str
    certainty: str = "observed"
    note: str = ""

    def validate(self) -> List[str]:
        errors: List[str] = []
        if self.certainty not in CERTAINTY_LEVELS:
            errors.append(f"invalid certainty: {self.certainty}")
        if not self.source:
            errors.append("evidence.source is required")
        if not self.region:
            errors.append("evidence.region is required")
        return errors

@dataclass
class GarmentPart:
    name: str
    category: str
    lock: str = "hard"
    silhouette: str = ""
    material: str = ""
    color: str = ""
    construction: List[str] = field(default_factory=list)
    surface_marks: List[str] = field(default_factory=list)
    evidence: List[Evidence] = field(default_factory=list)
    unknowns: List[str] = field(default_factory=list)

    def validate(self) -> List[str]:
        errors: List[str] = []
        if not self.name:
            errors.append("garment part name is required")
        if not self.category:
            errors.append(f"{self.name or '<unnamed>'}: category is required")
        if self.lock not in LOCK_LEVELS:
            errors.append(f"{self.name or '<unnamed>'}: invalid lock={self.lock}")
        for item in self.evidence:
            errors.extend(f"{self.name}: {e}" for e in item.validate())
        return errors

@dataclass
class Asset:
    asset_id: str
    display_name: str
    domain: str
    parts: List[GarmentPart]
    global_invariants: List[str] = field(default_factory=list)
    allowed_variations: List[str] = field(default_factory=list)
    forbidden_changes: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def validate(self) -> List[str]:
        errors: List[str] = []
        if not self.asset_id:
            errors.append("asset_id is required")
        if self.domain not in {"anime", "real", "hybrid"}:
            errors.append("domain must be anime, real, or hybrid")
        if not self.parts:
            errors.append("at least one garment part is required")
        seen = set()
        for part in self.parts:
            if part.name in seen:
                errors.append(f"duplicate garment part name: {part.name}")
            seen.add(part.name)
            errors.extend(part.validate())
        return errors

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def load_asset(path: str | Path) -> Asset:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    parts: List[GarmentPart] = []
    for raw in data.get("parts", []):
        evidence = [Evidence(**ev) for ev in raw.get("evidence", [])]
        clean = dict(raw)
        clean["evidence"] = evidence
        parts.append(GarmentPart(**clean))
    clean_asset = dict(data)
    clean_asset["parts"] = parts
    return Asset(**clean_asset)


def save_asset(asset: Asset, path: str | Path) -> None:
    Path(path).write_text(json.dumps(asset.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
