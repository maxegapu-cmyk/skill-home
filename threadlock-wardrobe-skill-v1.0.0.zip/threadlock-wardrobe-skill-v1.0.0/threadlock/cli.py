from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

from .compiler import compile_brief
from .core import load_asset
from .qa import ContinuityScore
from .report import render_html


def cmd_validate(args: argparse.Namespace) -> int:
    asset = load_asset(args.asset)
    errors = asset.validate()
    if errors:
        print("INVALID")
        for e in errors:
            print(f"- {e}")
        return 2
    print(f"OK: {asset.asset_id} ({len(asset.parts)} garment parts)")
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    asset = load_asset(args.asset)
    errors = asset.validate()
    if errors:
        for e in errors:
            print(e, file=sys.stderr)
        return 2
    text = compile_brief(asset, args.mode, args.task, args.shot or "")
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(args.output)
    else:
        print(text, end="")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    asset = load_asset(args.asset)
    errors = asset.validate()
    if errors:
        for e in errors:
            print(e, file=sys.stderr)
        return 2
    render_html(asset, args.output)
    print(args.output)
    return 0


def cmd_score(args: argparse.Namespace) -> int:
    raw = json.loads(Path(args.score).read_text(encoding="utf-8"))
    score = ContinuityScore(**raw)
    errors = score.validate()
    if errors:
        for e in errors:
            print(e, file=sys.stderr)
        return 2
    result = {"weighted_total": round(score.weighted_total(), 4), "verdict": score.verdict(), "inputs": asdict(score)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="threadlock", description="Garment asset continuity toolkit")
    sp = p.add_subparsers(dest="cmd", required=True)

    v = sp.add_parser("validate", help="validate an asset manifest")
    v.add_argument("asset")
    v.set_defaults(func=cmd_validate)

    c = sp.add_parser("compile", help="compile an execution brief")
    c.add_argument("asset")
    c.add_argument("--mode", required=True, choices=["anime", "real"])
    c.add_argument("--task", required=True, choices=["extract", "reconstruct", "render", "tryon", "video"])
    c.add_argument("--shot")
    c.add_argument("-o", "--output")
    c.set_defaults(func=cmd_compile)

    r = sp.add_parser("report", help="build a local HTML asset report")
    r.add_argument("asset")
    r.add_argument("-o", "--output", required=True)
    r.set_defaults(func=cmd_report)

    s = sp.add_parser("score", help="score a continuity review JSON")
    s.add_argument("score")
    s.set_defaults(func=cmd_score)
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    raise SystemExit(args.func(args))

if __name__ == "__main__":
    main()
