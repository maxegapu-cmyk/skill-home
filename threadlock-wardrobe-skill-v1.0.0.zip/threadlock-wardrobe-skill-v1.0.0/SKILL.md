# Threadlock Wardrobe Skill v1.0.0

## Purpose

Threadlock is a model-agnostic clothing asset system for extracting, reconstructing, designing, reusing, and verifying outfits across anime and photoreal workflows.

Its central rule is simple: **a garment is an asset with evidence and invariants, not a paragraph of prompt text.**

Use it when the user wants any combination of:

- extract clothing from one or more references;
- rebuild partially occluded clothing without uncontrolled redesign;
- create a reusable garment/outfit asset;
- place the same outfit on different people or characters;
- preserve clothing across poses, camera angles, scenes, shots, or video;
- convert the same garment concept between anime and photoreal presentation;
- design a new outfit while keeping later generations consistent;
- audit whether a generated image/video still matches the approved clothing asset.

## Non-goals

Threadlock is not a model checkpoint and does not ship third-party weights. It does not pretend that every hidden surface can be recovered from a single image. It does not treat face identity, body identity, pose, art style, and clothing identity as one fused reference signal.

## Five-layer representation

Every job should be reasoned through five layers. Keep them separate.

1. **Evidence layer** — what is actually visible, from which source, at what certainty.
2. **Garment fact layer** — silhouette, topology, construction, material, color blocking, marks, layering.
3. **Wear-state layer** — open/closed, tucked/untucked, sleeve state, fastening, fit adaptation, deformation from pose.
4. **Presentation layer** — anime or real. Presentation may change rendering language, never unapproved garment facts.
5. **Shot-state layer** — pose, camera, motion, occlusion and temporary wrinkles in this particular image/shot.

Never let a lower layer silently rewrite a higher one.

## Operating modes

### EXTRACT
Use when references already contain the desired outfit.

1. Inventory all visible garment parts.
2. Create a source-to-region evidence table.
3. Mark each fact as observed, inferred, or unknown.
4. Split garments by functional layer, not merely color region.
5. Record silhouette, construction, material, color, surface marks and inter-layer relationships.
6. Preserve unknowns explicitly.
7. Produce an asset manifest and, when tools permit, isolated masks/crops/reference views.

### RECONSTRUCT
Use when important regions are occluded or missing.

1. Lock all observed facts first.
2. Identify exactly which regions need reconstruction.
3. Infer only what is necessary for physical continuity.
4. Prefer symmetric or construction-consistent completion only when evidence supports it.
5. Mark reconstructed regions as inferred.
6. Do not invent logos, seams, pockets, closures, decoration, or back designs without evidence.

### DESIGN
Use when the user wants a new outfit.

1. Convert the design brief into garment parts.
2. For each part specify silhouette, material, color, construction and marks.
3. Decide which details are hard-lock invariants versus soft-lock wear behavior.
4. Freeze the approved version into an asset manifest before generating more poses/scenes.
5. From that point onward, treat additions as revisions, not casual prompt variation.

### RENDER
Use when applying an existing asset to an anime or real target.

1. Keep clothing reference control independent from pose/body control whenever the backend allows it.
2. Compile the asset manifest into a backend brief using `threadlock compile`.
3. Use masks/region editing for local repair rather than regenerating the whole image when only clothing is wrong.
4. Verify against the continuity gate before accepting.

### VIDEO
Use when the outfit must persist over time.

1. Lock a canonical still first.
2. Define a shot contract: camera, action, visible garment regions, wear state.
3. Use a video-capable try-on/reference backend when available.
4. Keep a continuity ledger across shots: component presence, topology, marks, layering, color blocking, material response.
5. Use the last approved frame only as a temporal aid, never as authority over the canonical asset.
6. Repair local drift instead of allowing drift to accumulate through chained generations.

## Lock levels

- `hard`: structural identity. Preserve unless the user explicitly revises the asset.
- `soft`: expected to remain similar but may adapt to body, pose, physics or perspective.
- `free`: deliberately variable styling or accessory state.

Typical hard locks: garment count, silhouette family, hem position, pocket count/placement, closure type, logo/emblem geometry and side, dominant color blocks, major seam lines, layering order.

Typical soft locks: wrinkle placement, minor fit adaptation, cuff bunching, fold direction, small perspective-dependent proportions.

Typical free fields: background, camera, lighting, pose, hair movement, environment, non-garment props unless separately locked.

## Evidence discipline

When multiple references conflict, use the reference where the disputed region is most visible and least distorted. Do not average incompatible designs. If the conflict cannot be resolved, keep it unresolved and request/seek another view only when that missing information blocks the task.

For a cropped or close-up reference, never infer full-body garment facts from absent regions. For distant references, do not use blurry details to overwrite a clearer close view.

## Backend routing

Backends are replaceable. Choose by task, not loyalty.

- **Segmentation / object isolation:** Grounded-SAM-2 or SAM 2; SCHP is useful for human/clothing parsing.
- **Body correspondence / try-on preprocessing:** DensePose where supported.
- **Real still try-on:** CatVTON is a lightweight default; IDM-VTON is a strong alternative; CtrlVTON is interesting when fine control of tuck/open/closed/placement is important.
- **Real video try-on:** CatV2TON when its constraints fit the job.
- **Anime:** use an image-reference adapter plus independent pose control. IP-Adapter + ControlNet is a common open stack. Avoid feeding a full character sheet at excessive weight if it drags composition/framing into every shot.

Do not claim a backend supports a feature unless verified against its current documentation.

## Anime policy

Priority order:

1. garment topology and layering;
2. silhouette and major color blocks;
3. distinctive marks and trim placement;
4. material cues translated into the target anime language;
5. linework/shading/style.

Stylization is allowed to simplify microtexture, but it must not erase structural facts. A zipper cannot become buttons merely because the target style is simple. A wrap skirt cannot become a plain skirt because the camera moved.

## Real policy

Priority order:

1. construction and layering;
2. cut and fit intent;
3. material class, thickness, sheen and drape;
4. closures, seams, pockets, labels/marks;
5. pose-dependent wrinkles and contact behavior.

Reject painted-on clothing, merged layers, incorrect fabric gloss, texture-only imitation of a structurally different garment, and body anatomy that deforms only to force a garment match.

## Continuity gate

Review every candidate on eight axes, each 0..1:

- component presence;
- silhouette;
- color blocking;
- material;
- construction;
- logos / marks;
- layering;
- uncertainty discipline.

The included scorer uses weighted thresholds:

- >= 0.92: `release`
- 0.84–0.9199: `repair`
- < 0.84: `reject`

These thresholds are workflow defaults, not scientific guarantees. A hard-lock failure can override the numeric score and force repair/reject.

## Minimal CLI

Validate an asset:

```bash
python -m threadlock.cli validate examples/anime_asset.json
```

Compile a real try-on brief:

```bash
python -m threadlock.cli compile examples/real_asset.json --mode real --task tryon
```

Compile an anime scene brief:

```bash
python -m threadlock.cli compile examples/anime_asset.json --mode anime --task render --shot "3/4 full body, running, low camera; jacket front and right side visible"
```

Build a local HTML report:

```bash
python -m threadlock.cli report examples/anime_asset.json -o /tmp/threadlock-report.html
```

Score a continuity review:

```bash
python -m threadlock.cli score examples/continuity_score.json
```

## Deliverables for a complete user job

When tools and inputs permit, return:

1. canonical outfit asset manifest;
2. evidence/unknown map;
3. isolated garment references or masks;
4. anime and/or real execution brief;
5. approved canonical render(s);
6. continuity review with failures called out specifically;
7. local repair instructions for failed regions;
8. video shot contracts if the task includes motion.

Do not call the job finished solely because an image looks attractive. It must still match the approved asset.
