---
name: universal-web-harvester
description: Adaptive website harvesting for Codex. Use when the user asks to crawl, scrape, collect, download, archive, extract, enumerate, or structure content from websites, including public pages, JavaScript sites, paginated listings, files, and sites the user is authorized to access after login.
---

# Universal Web Harvester 2.1

Turn a natural-language collection request into the least-complex authorized acquisition path, execute it, download requested page assets, and verify the output before claiming success. Version 2.1 strengthens complex-asset completeness with browser-first media routing, correct `<base href>` resolution, more lazy/gallery/embed asset patterns, and stylesheet dependency discovery on top of the v2 rendered-DOM/network/mirror pipeline.

The user's explicit task instructions take precedence over this playbook. Do not turn a simple one-page extraction into a site crawl unless the user asked for broader scope.

## Non-negotiable access boundary

Operate on public content or content the user is authorized to access. Never add or use CAPTCHA solvers, credential stuffing, stolen/replayed third-party sessions, paywall or account-permission bypasses, stealth fingerprint spoofing, rotating identities to evade rate limits, or techniques whose purpose is defeating a site's access controls.

A 403/429/challenge is a diagnostic signal, not a command to become more evasive. Prefer ordinary authorized alternatives: official API, RSS/Atom, sitemap, export/download, the site's own search/print endpoint, or a normal user-established browser session.

Authentication state may contain sensitive cookies/tokens. Keep it under `.harvester/auth/`, never print its contents, never put it in job output, and never commit it.

## Runtime commands

Resolve `SKILL_ROOT` as the directory containing this `SKILL.md`. Run scripts from that directory unless the surrounding project requires another working directory.

Probe first:

```bash
python scripts/probe.py "https://example.com/path" --browser auto
```

Harvest text:

```bash
python scripts/harvest.py "https://example.com/path" --mode extract --scope page --browser auto
```

Deep capture of complex page text + images + files:

```bash
python scripts/harvest.py "https://example.com/path" --mode deep --scope page --browser auto
```

Create/recreate an authorized browser session when login is required:

```bash
python scripts/auth_session.py "https://example.com/login" --profile default
```

Extract known fields with CSS selectors:

```bash
python scripts/harvest.py "https://example.com/list" --scope site --fields-json '{"title":"h2.card-title","price":".price"}'
```

For complex selector maps, write JSON to a temporary file and pass `--fields-json @path/to/fields.json`.


## 2.1 mission modes

Choose the mode from the user's actual requested result, not from the site's apparent complexity:

- `extract`: text, links, tables, JSON-LD and structured CSS fields only.
- `media`: asset-first capture. With browser auto it prefers rendered capture so lazy/gallery/computed-CSS/runtime assets are included; use browser never only when a fast HTML-only pass is explicitly sufficient.
- `mirror`: rendered browser capture plus web assets and rewritten local HTML.
- `deep`: strongest general capture: rendered DOM, bounded lazy-load hydration, safe content-expansion clicks, frames/open Shadow DOM discovery, network media/web resources, sanitized useful JSON responses, files, canvas screenshot fallback, full-page screenshot, mirror build and completeness audit.

Natural-language routing defaults:

- “提取正文/表格/字段” -> `extract`
- “下载这个普通页面里的图片/附件” -> `media`
- “离线保存/镜像这个网站” -> `mirror`
- “扒光/全部文字图片附件/复杂网页尽可能完整下载” -> `deep`

For `media`/`deep`/`mirror`, leave `--browser auto` unless the user explicitly asks for an HTTP-only pass or forbids browser use. For large asset jobs raise `--max-assets` and byte caps deliberately; do not silently remove safety limits.

## Decision workflow

### 1. Convert the user's request into a mission

Determine without asking unless the answer materially changes the result:

- seed URL(s)
- scope: `page`, `prefix`, or `site`
- desired assets: text, records, tables, images/files, offline mirror, or mixed
- mode: `extract`, `media`, `mirror`, or `deep`
- maximum reasonable page count and depth
- output fields and format
- whether the user refers to content visible only after login

Safe defaults:

- one URL with no broad language -> `scope=page`
- "all / entire section / every item" -> `prefix` or `site` as appropriate
- start with `max-pages=50`; raise it only when the user's task requires more
- `browser=auto`
- use `deep` for complex “全部扒下来” requests
- respect robots.txt
- keep a per-host delay

### 2. Probe before crawling

Run `scripts/probe.py`. Read its route, reason, status, dynamic-shell signal, login signal, content type, same-origin links, RSS hints, sitemap hints, and challenge signal.

Do not skip the probe just because a site "looks simple" in a browser.

### 3. Choose the cheapest route that can actually obtain the requested content

Route priority:

1. Direct downloadable resource -> download route.
2. Server-rendered HTML/JSON/XML -> HTTP route.
3. Sitemap/RSS/structured source can enumerate the requested corpus more directly -> use it for discovery, then fetch target records.
4. Client-rendered shell, infinite-scroll UI, interaction-gated content -> browser route.
5. Login required and an authorized local profile exists -> authenticated browser route.
6. Login required and no profile exists -> create a session with `auth_session.py`; the user performs login in the real browser; then retry.
7. CAPTCHA/WAF/permission barrier remains -> stop evasion attempts and report `BLOCKED` with the best legitimate alternative.

Do not repeatedly retry the same failing method. A method change must be justified by new evidence from the probe/report.

### 4. Login handling

If the user asks for content behind their own login, first try the requested profile if one exists. If not, launch `auth_session.py` directly. Tell the user to complete login in the browser window; do not ask them to paste passwords, OTPs, passkeys, or recovery codes into chat/Codex.

After saving the session, rerun the probe with `--auth-profile <name>` and then harvest with the same profile.

If output pages become login pages again, treat the session as expired. Recreate it; do not silently return contaminated data.

### 5. Dynamic/browser escalation and deep hydration

When HTTP returns an app shell or unusably empty content, rerun with browser auto/always. `deep` and `mirror` intentionally prefer rendered browser capture even when server HTML exists, because asset completeness can depend on lazy loading, computed CSS, frames, open Shadow DOM, safe “load more” expansion, or runtime network responses.

If browser mode loads the real page, harvest the rendered DOM and continue same-origin traversal within the user's scope. `deep` also captures visible canvas elements as screenshot fallbacks and a full-page screenshot.

### 6. Structured-source shortcut

Before brute-force clicking thousands of pages, look for evidence that the same requested information is available through:

- sitemap indexes / sitemap URL sets
- RSS or Atom feeds
- JSON-LD embedded in pages
- downloadable CSV/JSON/XML
- official documented APIs
- structured JSON responses naturally used by the page while the authorized browser session is open

Prefer these when they reduce requests and preserve the same authorization boundary. Do not discover a private endpoint and then weaken/forge its authorization.

### 7. Crawl discipline

Keep traversal bounded and deterministic:

- same-origin only unless the user explicitly requests linked external domains
- canonicalize URLs and remove common tracking parameters
- deduplicate before enqueueing
- obey page/depth caps
- honor Retry-After on 429
- bounded exponential retry for transient network/5xx failures
- respect robots.txt by default
- never use identity rotation to beat a site's rate limit

If the user explicitly owns/administers the target and instructs you to ignore robots.txt for a legitimate internal crawl, `--ignore-robots` is available. Explain that robots.txt is crawl guidance, not authentication.

### 8. Extraction strategy

Use generic extraction first: title, cleaned main text, links, JSON-LD, tables. For repeated card/detail layouts, inspect a representative page and pass explicit CSS selectors with `--fields-json`.

For list + detail jobs:

1. use sitemap/list pages to enumerate canonical detail URLs
2. deduplicate
3. harvest detail pages
4. calculate field fill rates
5. inspect failures/low-fill fields before declaring success

### 9. Media, files, mirror, and attachments

When the target is a PDF/ZIP/Office/media resource or a response indicates an attachment, save the bytes under the job output. v2 uses `files/` as the canonical file directory and keeps `downloads/` for v1 compatibility. Do not convert a file download into scraped HTML unless the user asked for text extraction from that file.

For `media`/`deep`, discover `img`, `srcset`, lazy `picture/source`, common gallery original attributes, icons/social media metadata, object/embed/track/input-image assets, lazy frames, inline/computed CSS backgrounds, external stylesheet dependencies, media/posters and browser-observed resources. Respect `<base href>` semantics when resolving relative asset URLs. Prefer explicit original/high-resolution candidates when the page actually exposes them; never fabricate an “original URL” by guessing filename patterns.

For `mirror`/`deep`, rewrite saved HTML/CSS references toward local captured assets after downloading. Optional `--warc` adds WARC archival but does not replace the human-readable directory output.

### 10. Verify before reporting completion

Every job produces a report. Read it.

Do not call the job complete merely because requests returned HTTP 200.

Required checks:

- record count
- failed URL count
- duplicate count
- empty/near-empty count
- login-page contamination count
- requested-field fill rates
- downloaded files/assets exist and are non-empty
- discovered-vs-downloaded asset counts and unresolved/failed assets
- mirror page count for mirror/deep jobs
- page/depth caps did not truncate a task that explicitly required the whole corpus

Verdicts:

- `PASS`: no detected completeness/contamination problem inside the requested bounded scope
- `PARTIAL`: usable data exists, but failures, duplicates, empty pages, low fill rates, or other incompleteness remain
- `BLOCKED`: no usable records or an access barrier prevents authorized acquisition

On `PARTIAL`, retry only the specific failed class with a justified route change. Preserve the first job output for comparison.

## Output contract to the user

Report concisely:

- route actually used
- pages/records/downloads obtained
- failures and why
- validation verdict
- exact output/report paths
- any material limitation (for example, max-pages cap or blocked authenticated section)

Never claim "all" unless the requested corpus had an enumerable boundary and validation supports that claim.

## Examples

User: "把这个博客这个分类下面所有文章弄下来。"

Action: probe category -> choose prefix scope -> use sitemap if it exposes category URLs, otherwise follow pagination -> HTTP first -> browser only if rendered shell -> validate article count and failed URLs.

User: "把我登录以后才能看到的订单全整理出来。"

Action: probe -> login detected -> create/reuse authorized profile -> authenticated browser -> traverse order pagination/detail pages -> selector extraction -> verify no login-page contamination.

User: "这个网站怎么都抓不到，你想别的办法。"

Action: compare HTTP vs rendered browser -> inspect sitemap/RSS/download/official structured sources -> if normal authorized browser works, use that path -> if a CAPTCHA/WAF/permission wall remains, stop evasive escalation and report legitimate alternatives.
