# Universal Web Harvester 2.1 — Known Limits

- No generic crawler can prove it has found URLs that a site never exposes through reachable pages, sitemap/feed/API/export or an authorized browser state. v2 reports bounded completeness; it does not invent certainty.
- Browser mode requires both the Playwright Python package and a Playwright browser executable (`python -m playwright install chromium`).
- Authentication systems bound to device attestation, corporate SSO containers, hardware keys or very short-lived challenges may require a fresh manual login. The runtime does not bypass them.
- Storage state can contain sensitive authorization material. It is intentionally kept under `.harvester/auth/`, excluded from job output, and git-ignored.
- `deep` can inspect open Shadow DOM and accessible frames. Closed Shadow DOM, inaccessible cross-origin internals, DRM-protected media, encrypted streams, or resources never delivered to the authorized browser may not be extractable.
- Canvas has no universal original-file URL. In `deep` mode a visible canvas can be saved as an element screenshot fallback; this preserves appearance, not the unknown original source asset.
- Blob/data-URI/application-generated objects may not have a stable downloadable URL. Browser/network capture can often recover the underlying delivered resource, but not in every application.
- Safe hydration only clicks a narrow allowlist of content-expansion controls. It intentionally does not click purchase, delete, submit, follow, like, comment, account-changing or arbitrary controls.
- `media` is optimized for server-rendered asset discovery. Use `deep` when completeness depends on JavaScript, lazy loading, galleries, iframe content, computed CSS backgrounds or runtime network responses.
- Network JSON capture is deliberately conservative: sensitive auth/session endpoints are excluded and recognized credential-like keys are redacted. Non-JSON private binary APIs are not dumped merely because the browser touched them.
- Offline mirror fidelity is best-effort. Service workers, live APIs, WebSockets, DRM, server-side personalization and complex application state may not replay offline even when the visible page assets were saved.
- The runtime is bounded and single-process by design. It is for reliable Codex-assisted acquisition, not billion-URL distributed crawling.
