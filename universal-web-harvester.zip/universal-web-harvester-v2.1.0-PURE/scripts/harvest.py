#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime.harvester.models import BrowserPolicy, HarvestMission, HarvestMode, InteractionMode, Verdict
from runtime.harvester.runner import run_mission


def _load_fields(value: str | None) -> dict[str, str]:
    if not value:
        return {}
    if value.startswith("@"):
        raw = Path(value[1:]).read_text(encoding="utf-8")
    else:
        raw = value
    data = json.loads(raw)
    if not isinstance(data, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in data.items()):
        raise ValueError("--fields-json must be a JSON object mapping field names to CSS selectors")
    return data


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Universal Web Harvester 2.1")
    ap.add_argument("url")
    ap.add_argument("--mode", choices=[x.value for x in HarvestMode], default="extract")
    ap.add_argument("--interaction", choices=[x.value for x in InteractionMode], default="safe")
    ap.add_argument("--scope", choices=["page", "prefix", "site"], default="page")
    ap.add_argument("--max-pages", type=int, default=50)
    ap.add_argument("--max-depth", type=int, default=2)
    ap.add_argument("--browser", choices=[x.value for x in BrowserPolicy], default="auto")
    ap.add_argument("--auth-profile", default=None)
    ap.add_argument("--fields-json", default=None, help="JSON object or @path mapping field names to CSS selectors")
    ap.add_argument("--output", default=None)
    ap.add_argument("--delay", type=float, default=0.5)
    ap.add_argument("--timeout", type=float, default=20.0)
    ap.add_argument("--retries", type=int, default=2)
    ap.add_argument("--max-assets", type=int, default=1000)
    ap.add_argument("--max-asset-mb", type=float, default=25.0)
    ap.add_argument("--max-total-asset-mb", type=float, default=500.0)
    ap.add_argument("--max-scroll-rounds", type=int, default=12)
    ap.add_argument("--stable-rounds", type=int, default=2)
    ap.add_argument("--keep-variants", action="store_true")
    ap.add_argument("--screenshot", action="store_true")
    ap.add_argument("--resume", default=None, help="reuse an existing job directory and its asset hash/url map")
    ap.add_argument("--warc", action="store_true", help="also emit WARC archive; requires optional warcio dependency")
    network = ap.add_mutually_exclusive_group()
    network.add_argument("--capture-network-json", dest="capture_network_json", action="store_true", default=True)
    network.add_argument("--no-network-json", dest="capture_network_json", action="store_false")
    discovery = ap.add_mutually_exclusive_group()
    discovery.add_argument("--discover", dest="discover", action="store_true", default=True)
    discovery.add_argument("--no-discover", dest="discover", action="store_false")
    robots = ap.add_mutually_exclusive_group()
    robots.add_argument("--respect-robots", dest="respect_robots", action="store_true", default=True)
    robots.add_argument("--ignore-robots", dest="respect_robots", action="store_false")
    ns = ap.parse_args(argv)

    try:
        if ns.max_pages < 1 or ns.max_depth < 0 or ns.delay < 0 or ns.timeout <= 0 or ns.retries < 0:
            raise ValueError("Invalid crawl limits")
        if ns.max_assets < 0 or ns.max_asset_mb <= 0 or ns.max_total_asset_mb <= 0 or ns.max_scroll_rounds < 0 or ns.stable_rounds < 1:
            raise ValueError("Invalid asset/browser limits")
        mission = HarvestMission(
            url=ns.url,
            mode=HarvestMode(ns.mode),
            interaction=InteractionMode(ns.interaction),
            scope=ns.scope,
            max_pages=ns.max_pages,
            max_depth=ns.max_depth,
            browser=BrowserPolicy(ns.browser),
            auth_profile=ns.auth_profile,
            fields=_load_fields(ns.fields_json),
            output_dir=Path(ns.output) if ns.output else None,
            delay=ns.delay,
            timeout=ns.timeout,
            respect_robots=ns.respect_robots,
            retries=ns.retries,
            discover=ns.discover,
            max_assets=ns.max_assets,
            max_asset_bytes=int(ns.max_asset_mb * 1024 * 1024),
            max_total_asset_bytes=int(ns.max_total_asset_mb * 1024 * 1024),
            keep_variants=ns.keep_variants,
            max_scroll_rounds=ns.max_scroll_rounds,
            stable_rounds=ns.stable_rounds,
            capture_network_json=ns.capture_network_json,
            screenshot=ns.screenshot,
            resume_dir=Path(ns.resume) if ns.resume else None,
            warc=ns.warc,
        )
        result = run_mission(mission)
        validation = result.validation
        print(json.dumps({
            "verdict": result.verdict.value,
            "records": len(result.records),
            "failures": len(result.failures),
            "assets": {
                "discovered": validation.asset_discovered_count if validation else 0,
                "downloaded": validation.asset_downloaded_count if validation else 0,
                "duplicates": validation.asset_duplicate_count if validation else 0,
                "failed": validation.asset_failed_count if validation else 0,
                "unresolved": validation.asset_unresolved_count if validation else 0,
            },
            "frames": validation.frame_count if validation else 0,
            "mirror_pages": validation.mirror_page_count if validation else 0,
            "job_dir": str(result.job_dir),
            "report_path": str(result.report_path),
            "reasons": validation.reasons if validation else [],
        }, ensure_ascii=False, indent=2))
        return 3 if result.verdict is Verdict.BLOCKED else 0
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
