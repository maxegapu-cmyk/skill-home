#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from runtime.harvester.auth import capture_auth_session


def main() -> int:
    ap = argparse.ArgumentParser(description="Create a local authorized browser session for Universal Web Harvester")
    ap.add_argument("url")
    ap.add_argument("--profile", default="default")
    ap.add_argument("--auth-dir", default=None)
    ap.add_argument("--browser", choices=["chromium", "firefox", "webkit"], default="chromium")
    ns = ap.parse_args()
    path = capture_auth_session(ns.url, ns.profile, ns.auth_dir, ns.browser)
    print(f"Saved authorized session state to: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
