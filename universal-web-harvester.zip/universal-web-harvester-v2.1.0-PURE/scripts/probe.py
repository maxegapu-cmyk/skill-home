#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime.harvester.models import BrowserPolicy, HarvestMission, HarvestMode
from runtime.harvester.runner import probe_target


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Probe a target and choose the least-complex harvest route")
    ap.add_argument("url")
    ap.add_argument("--browser", choices=[x.value for x in BrowserPolicy], default="auto")
    ap.add_argument("--mode", choices=[x.value for x in HarvestMode], default="extract")
    ap.add_argument("--auth-profile", default=None)
    ap.add_argument("--timeout", type=float, default=20.0)
    ap.add_argument("--delay", type=float, default=0.0)
    ap.add_argument("--no-discover", action="store_true")
    ns = ap.parse_args(argv)
    try:
        mission = HarvestMission(url=ns.url, mode=HarvestMode(ns.mode), browser=BrowserPolicy(ns.browser), auth_profile=ns.auth_profile, timeout=ns.timeout, delay=ns.delay, discover=not ns.no_discover)
        print(json.dumps(probe_target(mission), ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
