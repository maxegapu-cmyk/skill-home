#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md", "pyproject.toml", "INSTALL.md", ".gitignore", "config/defaults.json",
    "scripts/harvest.py", "scripts/probe.py", "scripts/auth_session.py",
    "runtime/harvester/models.py", "runtime/harvester/crawler.py", "runtime/harvester/browser_engine.py",
    "runtime/harvester/assets.py", "runtime/harvester/asset_manager.py", "runtime/harvester/hydration.py", "runtime/harvester/mirror.py",
    "runtime/harvester/archive.py", "runtime/harvester/network_safety.py",
]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Universal Web Harvester self-check")
    ap.add_argument("--browser", action="store_true", help="also verify a Playwright browser executable can launch")
    ap.add_argument("--archive", action="store_true", help="also verify optional WARC support is installed")
    ns = ap.parse_args(argv)
    failures = []
    if sys.version_info < (3, 11):
        failures.append(f"Python 3.11+ required; found {platform.python_version()}")
    for rel in REQUIRED:
        if not (ROOT / rel).is_file():
            failures.append(f"missing file: {rel}")
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8") if (ROOT / "SKILL.md").exists() else ""
    if not skill.startswith("---\n") or "name: universal-web-harvester" not in skill:
        failures.append("invalid SKILL.md frontmatter")
    gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8") if (ROOT / ".gitignore").exists() else ""
    if ".harvester/auth/" not in gitignore:
        failures.append("auth directory is not protected by .gitignore")
    deps = {name: bool(importlib.util.find_spec(name)) for name in ["httpx", "bs4", "lxml"]}
    missing_deps = [k for k, ok in deps.items() if not ok]
    if missing_deps:
        failures.append("missing core Python dependencies: " + ", ".join(missing_deps))
    browser_extra = bool(importlib.util.find_spec("playwright"))
    archive_extra = bool(importlib.util.find_spec("warcio"))
    if ns.archive and not archive_extra:
        failures.append("warcio Python package is not installed; install the archive extra")
    browser_launch = None
    if ns.browser:
        if not browser_extra:
            browser_launch = False
            failures.append("Playwright Python package is not installed")
        else:
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    browser.close()
                browser_launch = True
            except Exception as exc:
                browser_launch = False
                failures.append("Playwright Chromium launch failed: " + str(exc).splitlines()[0])
    payload = {
        "ok": not failures,
        "version": "2.1.0",
        "python": platform.python_version(),
        "core_dependencies": deps,
        "playwright_python_package": browser_extra,
        "warcio_python_package": archive_extra,
        "playwright_chromium_launch": browser_launch,
        "failures": failures,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
