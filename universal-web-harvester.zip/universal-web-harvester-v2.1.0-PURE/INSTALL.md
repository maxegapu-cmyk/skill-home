# Universal Web Harvester v2.1.0 — Codex Installation

Universal Web Harvester 2.1 is a Codex Skill plus a local Python runtime. It can extract text/records, download page media and attachments, hydrate complex JavaScript pages in a real browser, reuse an authorized login session, resolve lazy/gallery/CSS-linked assets, build an offline mirror, and optionally emit a WARC archive.

## Recommended install on Windows / PowerShell

Install the whole extracted directory as one Codex Skill. Preserve `SKILL.md`, `scripts/`, `runtime/`, `config/`, and the requirement files.

```powershell
$SkillRoot = "$env:USERPROFILE\.codex\skills\universal-web-harvester"
New-Item -ItemType Directory -Force -Path $SkillRoot | Out-Null
# Extract/copy this package into $SkillRoot
Set-Location $SkillRoot
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -U pip
.\.venv\Scripts\python.exe -m pip install -e ".[browser]"
.\.venv\Scripts\python.exe -m playwright install chromium
.\.venv\Scripts\python.exe scripts\self_check.py --browser
```

If `CODEX_HOME` is customized, install beneath that Codex Skill directory instead.

## Optional WARC archive support

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[browser,archive]"
```

Verify optional archive support:

```powershell
.\.venv\Scripts\python.exe scripts\self_check.py --archive
```

or install everything:

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[all]"
```

## Core-only install

For server-rendered public pages only, without JavaScript/login capture:

```powershell
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\python.exe scripts\self_check.py
```

`deep` and high-fidelity `mirror` jobs are designed to use the browser extra. If Chromium is unavailable, the runtime can fall back to useful server-rendered HTML where safe, but it reports that fallback as incomplete rather than pretending browser-only assets were verified.

## First smoke tests

```powershell
.\.venv\Scripts\python.exe scripts\probe.py "https://example.com" --browser auto
.\.venv\Scripts\python.exe scripts\harvest.py "https://example.com" --mode extract --scope page
```

Full-page asset capture:

```powershell
.\.venv\Scripts\python.exe scripts\harvest.py "https://example.com" --mode deep --scope page --browser auto
```

## Login sites

```powershell
.\.venv\Scripts\python.exe scripts\auth_session.py "https://target.example/login" --profile default
```

A visible browser opens. Complete login there yourself, then return to the terminal and press Enter. Authorization state is stored only under `.harvester\auth\...` and that directory is git-ignored.

Do not send passwords, OTPs, passkeys, recovery codes, cookies, or `storage_state.json` to another person.
