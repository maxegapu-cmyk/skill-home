from __future__ import annotations

import importlib.util
from io import BytesIO
from pathlib import Path


class WarcDependencyError(RuntimeError):
    pass


def ensure_warc_available() -> None:
    if importlib.util.find_spec("warcio") is None:
        raise WarcDependencyError(
            "WARC archive output requires the optional `warcio` dependency. "
            "Install with `pip install .[archive]` or `pip install warcio`."
        )


class WarcArchive:
    def __init__(self, path: str | Path):
        ensure_warc_available()
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write_response(self, url: str, status_code: int, headers: dict[str, str], body: bytes) -> None:
        from warcio.statusandheaders import StatusAndHeaders
        from warcio.warcwriter import WARCWriter

        http_headers = StatusAndHeaders(
            f"{status_code} Response",
            [(str(k), str(v)) for k, v in (headers or {}).items()],
            protocol="HTTP/1.1",
        )
        with self.path.open("ab") as stream:
            writer = WARCWriter(stream, gzip=True)
            record = writer.create_warc_record(url, "response", payload=BytesIO(body), http_headers=http_headers)
            writer.write_record(record)
