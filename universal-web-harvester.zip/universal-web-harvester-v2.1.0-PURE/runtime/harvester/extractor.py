from __future__ import annotations

import json
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .models import PageRecord
from .urltools import canonicalize_url


def _text(node) -> str:
    return " ".join(node.stripped_strings) if node else ""


def extract_document(url: str, html: str, fields: dict[str, str] | None = None, *, status_code: int = 200, content_type: str = "text/html", route: str = "") -> PageRecord:
    soup = BeautifulSoup(html, "lxml")
    title = _text(soup.title) or _text(soup.find("h1"))
    main = soup.find("main") or soup.find("article") or soup.body or soup
    for tag in main.find_all(["script", "style", "noscript", "svg"]):
        tag.decompose()
    text = _text(main)

    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = a.get("href", "").strip()
        if not href or href.startswith(("javascript:", "mailto:", "tel:")):
            continue
        absolute = urljoin(url, href)
        if absolute.startswith(("http://", "https://")):
            links.append(canonicalize_url(absolute))

    jsonld = []
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text(strip=True)
        if not raw:
            continue
        try:
            jsonld.append(json.loads(raw))
        except json.JSONDecodeError:
            continue

    tables: list[list[list[str]]] = []
    for table in soup.find_all("table"):
        rows: list[list[str]] = []
        for tr in table.find_all("tr"):
            cells = [_text(cell) for cell in tr.find_all(["th", "td"])]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)

    extracted_fields: dict[str, str] = {}
    for name, selector in (fields or {}).items():
        nodes = soup.select(selector)
        extracted_fields[name] = " | ".join(_text(n) for n in nodes if _text(n))

    low = html.lower()
    login_like = "type='password'" in low or 'type="password"' in low or ("password" in low and ("sign in" in low or "log in" in low or "login" in low))

    return PageRecord(
        url=canonicalize_url(url),
        status_code=status_code,
        content_type=content_type,
        title=title,
        text=text,
        links=list(dict.fromkeys(links)),
        jsonld=jsonld,
        tables=tables,
        fields=extracted_fields,
        route=route,
        login_like=login_like,
    )
