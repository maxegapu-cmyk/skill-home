from __future__ import annotations

from collections import deque

from .asset_manager import download_http_assets, merge_candidates, store_browser_resources
from .assets import discover_asset_candidates, resolve_asset_candidates
from .auth import auth_profile_exists, auth_state_path
from .browser_engine import BrowserDependencyError, BrowserEngine
from .discovery import discover_sitemap_urls
from .extractor import extract_document
from .http_engine import HttpEngine
from .mirror import finalize_mirror
from .models import AssetCandidate, FailureRecord, HarvestMission, HarvestMode, JobResult, Route
from .network_safety import is_sensitive_endpoint
from .profiler import profile_html
from .robots import RobotsPolicy
from .router import choose_route
from .storage import JobStore
from .urltools import canonicalize_url, same_scope
from .validator import validate_job


def _capture_with_browser(browser, url: str, mission: HarvestMission, robots):
    if hasattr(browser, "capture"):
        return browser.capture(
            url,
            interaction=mission.interaction,
            max_scroll_rounds=mission.max_scroll_rounds,
            stable_rounds=mission.stable_rounds,
            collect_assets=mission.mode is not HarvestMode.EXTRACT,
            capture_network=mission.mode in {HarvestMode.MEDIA, HarvestMode.MIRROR, HarvestMode.DEEP},
            capture_network_json=mission.capture_network_json,
            capture_supporting_resources=mission.mode in {HarvestMode.MEDIA, HarvestMode.MIRROR, HarvestMode.DEEP},
            capture_screenshot=mission.screenshot or mission.mode is HarvestMode.DEEP,
            capture_canvas=mission.mode is HarvestMode.DEEP,
            max_assets=mission.max_assets,
            max_asset_bytes=mission.max_asset_bytes,
            max_total_asset_bytes=mission.max_total_asset_bytes,
            keep_variants=mission.keep_variants or mission.mode in {HarvestMode.MIRROR, HarvestMode.DEEP},
            asset_allowed=(lambda target: (not mission.respect_robots) or robots.allowed(target)),
        )
    return None


def crawl(mission: HarvestMission, *, http_engine=None, browser_engine_factory=None, auth_base_dir=None) -> JobResult:
    seed = canonicalize_url(mission.url)
    if not seed.startswith(("http://", "https://")):
        raise ValueError("Only http:// and https:// URLs are supported")
    mission.url = seed
    store = JobStore(mission)
    engine = http_engine or HttpEngine(timeout=mission.timeout, retries=mission.retries, delay=mission.delay, user_agent="UniversalWebHarvester/2.1")
    browser_engine_factory = browser_engine_factory or (lambda **kwargs: BrowserEngine(**kwargs))
    robots = RobotsPolicy(timeout=mission.timeout, user_agent="UniversalWebHarvester/2.1")
    queue = deque([(seed, 0)])
    queued = {seed}
    if mission.discover and mission.scope != "page":
        for discovered_url in discover_sitemap_urls(seed, engine, max_urls=mission.max_pages):
            if discovered_url not in queued and same_scope(seed, discovered_url, mission.scope):
                queued.add(discovered_url)
                queue.append((discovered_url, 0))
                if len(queued) >= mission.max_pages:
                    break
    visited: set[str] = set()
    records = []
    failures: list[FailureRecord] = []
    discovered_asset_urls: set[str] = set()
    frame_urls: set[str] = set()

    while queue and len(visited) < mission.max_pages:
        url, depth = queue.popleft()
        if url in visited:
            continue
        if mission.respect_robots and not robots.allowed(url):
            visited.add(url)
            continue
        visited.add(url)
        try:
            fetched = engine.fetch(url)
        except Exception as exc:
            failure = FailureRecord(url=url, reason=f"network error: {exc}", retryable=True)
            failures.append(failure); store.append_failure(failure)
            continue
        if mission.warc and not is_sensitive_endpoint(fetched.final_url or url):
            store.archive_response(fetched.final_url or url, fetched.status_code, fetched.headers, fetched.body)

        original_text = fetched.text
        profile = profile_html(fetched.final_url or url, fetched.status_code, fetched.content_type, original_text)
        has_auth = bool(mission.auth_profile and auth_profile_exists(url, mission.auth_profile, auth_base_dir))
        decision = choose_route(profile, mission, auth_exists=has_auth)

        if decision.route in {Route.STOP_AUTH_REQUIRED, Route.STOP_BLOCKED}:
            failure = FailureRecord(url=url, reason=decision.reason, retryable=decision.route is Route.STOP_AUTH_REQUIRED, status_code=fetched.status_code)
            failures.append(failure); store.append_failure(failure)
            continue

        if decision.route is Route.DOWNLOAD:
            candidate = AssetCandidate(url=fetched.final_url or url, page_url=url, kind="file", discovered_by="direct-download")
            store.save_asset(candidate, fetched.body, content_type=fetched.content_type, final_url=fetched.final_url)
            # v1 compatibility copy is maintained by save_download.
            store.save_download(fetched.final_url or url, fetched.body, fetched.headers.get("content-disposition"))
            discovered_asset_urls.add(candidate.url)
            continue

        active_fetch = fetched
        active_route = decision.route
        browser_capture = None
        if decision.route in {Route.BROWSER, Route.AUTH_BROWSER}:
            state_path = None
            if decision.route is Route.AUTH_BROWSER:
                state_path = auth_state_path(url, mission.auth_profile or "default", auth_base_dir)
            try:
                browser = browser_engine_factory(timeout=mission.timeout, headless=True, state_path=state_path)
                browser_capture = _capture_with_browser(browser, url, mission, robots)
                active_fetch = browser_capture.fetch if browser_capture is not None else browser.fetch(url)
            except (BrowserDependencyError, FileNotFoundError, RuntimeError) as exc:
                # For fidelity-only browser preference, keep useful server-rendered content as an explicit partial fallback.
                if not profile.dynamic_shell and not profile.login_required and "html" in fetched.content_type.lower():
                    failure = FailureRecord(url=url, reason=f"browser enhancement unavailable; HTTP fallback used: {exc}", retryable=True, status_code=fetched.status_code)
                    failures.append(failure); store.append_failure(failure)
                    active_fetch = fetched
                    active_route = Route.HTTP
                else:
                    failure = FailureRecord(url=url, reason=str(exc), retryable=True, status_code=fetched.status_code)
                    failures.append(failure); store.append_failure(failure)
                    continue
            rendered_profile = profile_html(active_fetch.final_url or url, active_fetch.status_code, active_fetch.content_type, active_fetch.text)
            if rendered_profile.login_required:
                failure = FailureRecord(url=url, reason="Authorized browser session is missing or expired", retryable=True, status_code=active_fetch.status_code)
                failures.append(failure); store.append_failure(failure)
                continue

        body_text = active_fetch.text
        ctype = active_fetch.content_type.lower()
        if "html" in ctype:
            record = extract_document(active_fetch.final_url or url, body_text, mission.fields, status_code=active_fetch.status_code, content_type=active_fetch.content_type, route=active_route.value)
        else:
            record = extract_document(active_fetch.final_url or url, f"<main><pre>{body_text}</pre></main>", mission.fields, status_code=active_fetch.status_code, content_type=active_fetch.content_type, route=active_route.value)
        record.depth = depth
        records.append(record); store.append_record(record)

        local_frame_urls: set[str] = set()
        if "html" in ctype and mission.mode is not HarvestMode.EXTRACT:
            store.save_page_html(url, original_text, rendered=False)
            # Always register the effective DOM as rendered content for deferred mirror building.
            store.save_page_html(record.url, body_text, rendered=True)

            static_candidates = discover_asset_candidates(record.url, body_text)
            browser_candidates = browser_capture.assets if browser_capture is not None else []
            all_candidates = merge_candidates(static_candidates, browser_candidates)
            keep_all = mission.keep_variants or mission.mode in {HarvestMode.MIRROR, HarvestMode.DEEP}
            effective_candidates = resolve_asset_candidates(all_candidates, keep_variants=keep_all)
            for c in effective_candidates:
                store.append_asset_relationship(c)
                if c.kind == "frame":
                    frame_urls.add(c.url); local_frame_urls.add(c.url)
                else:
                    discovered_asset_urls.add(c.url)

            if browser_capture is not None:
                store_browser_resources(all_candidates, browser_capture.resources, store=store, mission=mission, page_url=record.url)
                if browser_capture.screenshot:
                    store.save_screenshot(record.url, browser_capture.screenshot)
                for artifact in browser_capture.inline_artifacts:
                    store.save_screenshot(record.url, artifact.body, artifact.name)
                for f in browser_capture.frames:
                    if f and f != record.url:
                        canonical_frame = canonicalize_url(f)
                        frame_urls.add(canonical_frame); local_frame_urls.add(canonical_frame)
            else:
                download_http_assets(all_candidates, engine=engine, store=store, mission=mission, robots=robots)

        if mission.scope != "page" and depth < mission.max_depth:
            asset_urls_for_page = {c.url for c in discover_asset_candidates(record.url, body_text) if c.kind != "frame"}
            links = list(record.links)
            if mission.mode in {HarvestMode.MIRROR, HarvestMode.DEEP}:
                links.extend([f for f in local_frame_urls if same_scope(seed, f, mission.scope)])
            for link in links:
                link = canonicalize_url(link)
                if link in asset_urls_for_page:
                    continue
                if link not in queued and same_scope(seed, link, mission.scope):
                    queued.add(link)
                    queue.append((link, depth + 1))

    if mission.mode in {HarvestMode.MIRROR, HarvestMode.DEEP}:
        finalize_mirror(store)
    all_discovered_asset_urls = discovered_asset_urls | {a.source_url for a in store.asset_records if a.source_url}

    report = validate_job(
        records,
        failures,
        assets=store.asset_records,
        discovered_assets=len(all_discovered_asset_urls),
        frame_count=len(frame_urls),
        mirror_page_count=store.mirror_page_count,
    )
    store.finalize(report)
    return JobResult(
        verdict=report.verdict,
        job_dir=store.job_dir,
        report_path=store.report_path,
        records=records,
        failures=failures,
        validation=report,
    )
