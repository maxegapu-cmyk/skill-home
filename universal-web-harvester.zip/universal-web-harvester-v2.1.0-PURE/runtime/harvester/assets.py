from __future__ import annotations

import re
from collections import defaultdict
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup

from .models import AssetCandidate
from .urltools import canonicalize_url

_FILE_EXTS = {
    '.pdf', '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz',
    '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.csv', '.epub',
}
_IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.avif', '.bmp', '.tif', '.tiff', '.ico', '.svg'}
_VIDEO_EXTS = {'.mp4', '.webm', '.mov', '.m4v', '.avi', '.mkv'}
_AUDIO_EXTS = {'.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac'}
_FONT_EXTS = {'.woff', '.woff2', '.ttf', '.otf', '.eot'}
_STYLESHEET_EXTS = {'.css'}
_URL_RE = re.compile(r"url\(\s*(['\"]?)(.*?)\1\s*\)", re.I)
_IMPORT_RE = re.compile(r"@import\s+(?:url\(\s*)?(['\"]?)([^'\")\s;]+)\1\s*\)?", re.I)


def _abs(base: str, value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip()
    if not value or value.startswith(('data:', 'blob:', 'javascript:', 'mailto:', 'tel:', '#')):
        return None
    out = urljoin(base, value)
    return canonicalize_url(out) if out.startswith(('http://', 'https://')) else None


def _kind(url: str, hint: str = '') -> str:
    ext = urlsplit(url).path.lower()
    suffix = '.' + ext.rsplit('.', 1)[-1] if '.' in ext.rsplit('/', 1)[-1] else ''
    if hint and hint != 'other':
        return hint
    if suffix in _IMAGE_EXTS: return 'image'
    if suffix in _VIDEO_EXTS: return 'video'
    if suffix in _AUDIO_EXTS: return 'audio'
    if suffix in _FONT_EXTS: return 'font'
    if suffix in _STYLESHEET_EXTS: return 'stylesheet'
    if suffix in _FILE_EXTS: return 'file'
    return 'other'


def parse_srcset(value: str | None) -> list[tuple[str, str | None, int | None]]:
    out = []
    for part in (value or '').split(','):
        part = part.strip()
        if not part: continue
        bits = part.split()
        url = bits[0]
        desc = bits[1] if len(bits) > 1 else None
        width = None
        if desc and desc.endswith('w') and desc[:-1].isdigit():
            width = int(desc[:-1])
        elif desc and desc.endswith('x'):
            try: width = int(float(desc[:-1]) * 1000)
            except ValueError: pass
        out.append((url, desc, width))
    return out


def discover_asset_candidates(page_url: str, html: str) -> list[AssetCandidate]:
    soup = BeautifulSoup(html, 'lxml')
    base_tag = soup.find('base', href=True)
    effective_base = page_url
    if base_tag is not None:
        raw_base = str(base_tag.get('href') or '').strip()
        if raw_base and not raw_base.startswith(('data:', 'blob:', 'javascript:', 'mailto:', 'tel:', '#')):
            resolved_base = urljoin(page_url, raw_base)
            if resolved_base.startswith(('http://', 'https://')):
                # Preserve a trailing slash here: urljoin uses it to distinguish a directory
                # base from a file base. Canonicalization happens on each final asset URL.
                effective_base = resolved_base
    items: list[AssetCandidate] = []
    img_index = 0

    def add(raw, kind='other', by='unknown', group=None, descriptor=None, width=None, height=None, alt='', frame_url=None):
        url = _abs(effective_base, raw)
        if not url: return
        items.append(AssetCandidate(url=url, page_url=page_url, kind=_kind(url, kind), discovered_by=by,
                                    group_id=group, descriptor=descriptor, width=width, height=height,
                                    alt=alt or '', frame_url=frame_url))

    for img in soup.find_all('img'):
        img_index += 1
        group = f'img-{img_index}'
        alt = img.get('alt', '')
        w = img.get('width')
        h = img.get('height')
        try: w = int(w) if w else None
        except (TypeError, ValueError): w = None
        try: h = int(h) if h else None
        except (TypeError, ValueError): h = None
        for attr in ('src', 'currentSrc', 'data-src', 'data-original', 'data-lazy-src', 'data-lazy', 'data-url', 'data-full', 'data-fullsrc', 'data-hi-res-src', 'data-zoom-image'):
            add(img.get(attr), 'image', f'img:{attr}', group, width=w, height=h, alt=alt)
        for raw, desc, sw in parse_srcset(img.get('srcset')):
            add(raw, 'image', 'img:srcset', group, descriptor=desc, width=sw or w, height=h, alt=alt)
        for attr in ('data-srcset', 'data-lazy-srcset'):
            for raw, desc, sw in parse_srcset(img.get(attr)):
                add(raw, 'image', f'img:{attr}', group, descriptor=desc, width=sw or w, height=h, alt=alt)
        parent = img.find_parent('picture')
        if parent is not None:
            for source in parent.find_all('source'):
                for attr in ('srcset', 'data-srcset', 'data-lazy-srcset'):
                    for raw, desc, sw in parse_srcset(source.get(attr)):
                        add(raw, 'image', f'picture:{attr}', group, descriptor=desc, width=sw, alt=alt)

    for n, source in enumerate(soup.find_all('source'), 1):
        parent = getattr(source.parent, 'name', '')
        if parent == 'picture':
            continue
        hint = 'video' if parent == 'video' else 'audio' if parent == 'audio' else 'other'
        add(source.get('src'), hint, f'{parent or "source"}:src', f'{hint}-{n}')
        for raw, desc, sw in parse_srcset(source.get('srcset')):
            add(raw, hint, f'{parent or "source"}:srcset', f'{hint}-{n}', descriptor=desc, width=sw)

    for n, tag in enumerate(soup.find_all(['video', 'audio']), 1):
        kind = tag.name
        add(tag.get('src'), kind, f'{kind}:src', f'{kind}-{n}')
        if kind == 'video': add(tag.get('poster'), 'image', 'video:poster', f'poster-{n}')

    for n, frame in enumerate(soup.find_all(['iframe', 'frame']), 1):
        for attr in ('src', 'data-src', 'data-lazy-src'):
            add(frame.get(attr), 'frame', f'{frame.name}:{attr}', f'frame-{n}')

    for n, image in enumerate(soup.find_all('image'), 1):
        add(image.get('href') or image.get('xlink:href'), 'image', 'svg:image', f'svg-image-{n}')

    for n, meta in enumerate(soup.find_all('meta'), 1):
        key = (meta.get('property') or meta.get('name') or '').strip().lower()
        if key in {'og:image', 'og:image:url', 'twitter:image', 'twitter:image:src'}:
            add(meta.get('content'), 'image', f'meta:{key}', f'meta-image-{n}')
        elif key in {'og:video', 'og:video:url', 'twitter:player:stream'}:
            add(meta.get('content'), 'video', f'meta:{key}', f'meta-video-{n}')
        elif key in {'og:audio', 'og:audio:url'}:
            add(meta.get('content'), 'audio', f'meta:{key}', f'meta-audio-{n}')

    for n, link in enumerate(soup.find_all('link', href=True), 1):
        rel = {str(x).lower() for x in (link.get('rel') or [])}
        as_type = str(link.get('as') or '').lower()
        if ('preload' in rel and as_type == 'image') or 'image_src' in rel:
            add(link.get('href'), 'image', 'link:preload-image', f'link-image-{n}')
        if rel & {'icon', 'shortcut', 'apple-touch-icon', 'mask-icon'}:
            add(link.get('href'), 'image', 'link:icon', f'link-icon-{n}')

    for n, obj in enumerate(soup.find_all('object'), 1):
        add(obj.get('data'), 'other', 'object:data', f'object-{n}')

    for n, emb in enumerate(soup.find_all('embed'), 1):
        add(emb.get('src'), 'other', 'embed:src', f'embed-{n}')

    for n, track in enumerate(soup.find_all('track'), 1):
        add(track.get('src'), 'file', 'track:src', f'track-{n}')

    for n, inp in enumerate(soup.find_all('input'), 1):
        if str(inp.get('type') or '').lower() == 'image':
            add(inp.get('src'), 'image', 'input:image', f'input-image-{n}')

    for n, use in enumerate(soup.find_all('use'), 1):
        add(use.get('href') or use.get('xlink:href'), 'image', 'svg:use', f'svg-use-{n}')

    for a in soup.find_all('a', href=True):
        raw = a.get('href')
        url = _abs(effective_base, raw)
        if not url: continue
        kind = 'file' if a.has_attr('download') else _kind(url)
        if kind in {'file', 'image', 'video', 'audio'}:
            add(raw, kind, 'a:download' if a.has_attr('download') else 'a:asset')

    css_chunks = [tag.string or tag.get_text() for tag in soup.find_all('style')]
    css_chunks += [tag.get('style', '') for tag in soup.find_all(style=True)]
    for idx, chunk in enumerate(css_chunks, 1):
        for _, raw in _URL_RE.findall(chunk or ''):
            add(raw, 'image', 'css:url', f'css-{idx}')

    # Stable URL + provenance dedup. Same URL may intentionally belong to different image groups;
    # keep one candidate per URL/group so the resolver can make group-level choices.
    seen = set(); out = []
    for item in items:
        key = (item.url, item.group_id, item.kind)
        if key in seen: continue
        seen.add(key); out.append(item)
    return out



def discover_css_asset_candidates(stylesheet_url: str, css_text: str, *, page_url: str | None = None) -> list[AssetCandidate]:
    """Discover external assets referenced by a stylesheet.

    URLs are resolved against the stylesheet URL (not the page URL), while the
    relationship remains attached to the page that caused the stylesheet load.
    """
    items: list[AssetCandidate] = []
    relationship_page = page_url or stylesheet_url

    def add(raw: str | None, *, kind: str = 'other', by: str = 'css:url'):
        url = _abs(stylesheet_url, raw)
        if not url:
            return
        items.append(AssetCandidate(
            url=url,
            page_url=relationship_page,
            kind=_kind(url, kind),
            discovered_by=by,
            group_id=f'css:{stylesheet_url}',
        ))

    import_urls = set()
    for _, raw in _IMPORT_RE.findall(css_text or ''):
        import_urls.add(raw)
        add(raw, kind='stylesheet', by='css:@import')

    for _, raw in _URL_RE.findall(css_text or ''):
        if raw in import_urls:
            continue
        add(raw, kind='other', by='css:url')

    seen = set(); out = []
    for item in items:
        if item.url in seen:
            continue
        seen.add(item.url); out.append(item)
    return out

def _score(candidate: AssetCandidate) -> tuple[int, int, int]:
    # explicit original/lazy source is a strong hint; width descriptor is stronger still
    provenance = 2 if 'original' in candidate.discovered_by else 1 if 'srcset' in candidate.discovered_by else 0
    width = candidate.width or 0
    area = (candidate.width or 0) * (candidate.height or 0)
    return width, area, provenance


def resolve_asset_candidates(candidates: list[AssetCandidate], *, keep_variants: bool = False) -> list[AssetCandidate]:
    if keep_variants:
        selected = candidates
    else:
        grouped: dict[str, list[AssetCandidate]] = defaultdict(list)
        ungrouped = []
        for c in candidates:
            if c.kind == 'image' and c.group_id and c.group_id.startswith(('img-', 'poster-')):
                grouped[c.group_id].append(c)
            else:
                ungrouped.append(c)
        selected = ungrouped[:]
        for group in grouped.values():
            # data-original without width commonly means the original; assign it a tie-break bonus.
            best = max(group, key=lambda c: (_score(c), 1 if 'original' in c.discovered_by else 0))
            # If an explicit original exists, prefer it even if it lacks a width descriptor.
            originals = [c for c in group if 'original' in c.discovered_by]
            if originals:
                best = max(originals, key=lambda c: _score(c))
            selected.append(best)
    seen = set(); out = []
    for c in selected:
        if c.url in seen: continue
        seen.add(c.url); out.append(c)
    return out
