from __future__ import annotations

from .assets import resolve_asset_candidates
from .models import AssetCandidate, AssetRecord, CapturedResource, HarvestMission, HarvestMode
from .network_safety import sanitize_json_body, should_store_json_response, is_sensitive_endpoint


def _kind_from_content_type(content_type: str, fallback: str = "other") -> str:
    mime = (content_type or "").split(";", 1)[0].strip().lower()
    if mime.startswith("image/"): return "image"
    if mime.startswith("video/"): return "video"
    if mime.startswith("audio/"): return "audio"
    if mime.startswith(("font/", "application/font-", "application/vnd.ms-fontobject")): return "font"
    if mime == "text/css": return "stylesheet"
    if mime in {"application/javascript", "text/javascript"}: return "script"
    if mime == "application/wasm": return "web"
    if mime in {"application/pdf", "application/zip", "application/x-zip-compressed"}: return "file"
    return fallback


def merge_candidates(*groups: list[AssetCandidate]) -> list[AssetCandidate]:
    seen = set(); out = []
    for group in groups:
        for item in group:
            key = (item.url, item.group_id, item.kind, item.frame_url)
            if key in seen:
                continue
            seen.add(key); out.append(item)
    return out


def _keep_variants(mission: HarvestMission) -> bool:
    return mission.keep_variants or mission.mode in {HarvestMode.MIRROR, HarvestMode.DEEP}


def download_http_assets(candidates: list[AssetCandidate], *, engine, store, mission: HarvestMission, robots=None) -> list[AssetRecord]:
    selected = resolve_asset_candidates(candidates, keep_variants=_keep_variants(mission))
    records: list[AssetRecord] = []
    total = store.existing_asset_bytes
    count = store.existing_asset_count
    for candidate in selected:
        if candidate.kind == "frame":
            continue
        if store.has_asset_url(candidate.url):
            continue
        if mission.respect_robots and robots is not None and not robots.allowed(candidate.url):
            records.append(store.record_asset_failure(candidate, "asset blocked by robots.txt policy"))
            continue
        if count >= mission.max_assets:
            records.append(store.record_asset_failure(candidate, f"asset limit reached ({mission.max_assets})"))
            continue
        count += 1
        try:
            fetched = engine.fetch(candidate.url)
        except Exception as exc:
            records.append(store.record_asset_failure(candidate, f"asset network error: {exc}"))
            continue
        if fetched.status_code >= 400:
            records.append(store.record_asset_failure(candidate, f"HTTP {fetched.status_code}"))
            continue
        if len(fetched.body) > mission.max_asset_bytes:
            records.append(store.record_asset_failure(candidate, f"asset exceeds max_asset_bytes ({len(fetched.body)})"))
            continue
        if total + len(fetched.body) > mission.max_total_asset_bytes:
            records.append(store.record_asset_failure(candidate, "total asset byte limit reached"))
            continue
        candidate.kind = _kind_from_content_type(fetched.content_type, candidate.kind)
        record = store.save_asset(candidate, fetched.body, content_type=fetched.content_type, final_url=fetched.final_url)
        records.append(record)
        if mission.warc and not is_sensitive_endpoint(fetched.final_url or candidate.url):
            store.archive_response(fetched.final_url or candidate.url, fetched.status_code, fetched.headers, fetched.body)
        total += len(fetched.body)
    return records


def store_browser_resources(
    candidates: list[AssetCandidate],
    resources: list[CapturedResource],
    *,
    store,
    mission: HarvestMission,
    page_url: str = "",
) -> list[AssetRecord]:
    selected = resolve_asset_candidates(candidates, keep_variants=_keep_variants(mission))
    by_url = {c.url: c for c in selected if c.kind != "frame"}
    saved_urls: set[str] = {url for url in by_url if store.has_asset_url(url)}
    records: list[AssetRecord] = []
    total = store.existing_asset_bytes
    count = store.existing_asset_count

    def resource_priority(resource: CapturedResource) -> int:
        if resource.url in by_url:
            return 0
        kind = _kind_from_content_type(resource.content_type, "other")
        if kind in {"image", "video", "audio", "file"}:
            return 1
        if kind in {"stylesheet", "font"}:
            return 2
        if kind in {"script", "web"}:
            return 3
        mime = (resource.content_type or "").split(";", 1)[0].lower()
        if "json" in mime or resource.resource_type in {"xhr", "fetch"}:
            return 4
        return 5

    for resource in sorted(resources, key=resource_priority):
        mime = (resource.content_type or "").split(";", 1)[0].lower()
        is_json = "json" in mime or (resource.resource_type in {"xhr", "fetch"} and mime == "text/plain")
        if is_json:
            payload = {
                "url": resource.url,
                "status_code": resource.status_code,
                "content_type": resource.content_type,
                "resource_type": resource.resource_type,
                "frame_url": resource.frame_url,
                "saved": False,
                "redacted": False,
            }
            if mission.capture_network_json and resource.body is not None and should_store_json_response(resource.url):
                cleaned = sanitize_json_body(resource.body)
                if cleaned:
                    path = store.save_network_data(resource.url, cleaned, "application/json")
                    payload["saved"] = True
                    payload["redacted"] = cleaned != resource.body
                    payload["local_path"] = path.relative_to(store.job_dir).as_posix()
                    payload["bytes"] = len(cleaned)
            store.append_network_metadata(payload)
            if mission.warc and resource.body is not None and should_store_json_response(resource.url):
                cleaned = sanitize_json_body(resource.body)
                if cleaned:
                    store.archive_response(resource.url, resource.status_code, {"content-type": "application/json"}, cleaned)
            continue

        candidate = by_url.get(resource.url)
        kind = _kind_from_content_type(resource.content_type, candidate.kind if candidate else "other")
        network_asset_kinds = {"image", "video", "audio", "file"}
        if mission.mode in {HarvestMode.MIRROR, HarvestMode.DEEP}:
            network_asset_kinds |= {"stylesheet", "script", "font", "web"}
        if candidate is None and kind in network_asset_kinds:
            candidate = AssetCandidate(
                url=resource.url,
                page_url=resource.frame_url or page_url,
                kind=kind,
                discovered_by="network",
                frame_url=resource.frame_url,
            )
            by_url[resource.url] = candidate
        if candidate is None:
            continue
        if resource.url in saved_urls:
            continue
        if resource.status_code >= 400:
            records.append(store.record_asset_failure(candidate, f"HTTP {resource.status_code}"))
            saved_urls.add(resource.url)
            continue
        if resource.body is None:
            continue
        if count >= mission.max_assets:
            records.append(store.record_asset_failure(candidate, f"asset limit reached ({mission.max_assets})"))
            saved_urls.add(resource.url)
            continue
        if len(resource.body) > mission.max_asset_bytes or total + len(resource.body) > mission.max_total_asset_bytes:
            records.append(store.record_asset_failure(candidate, "asset byte limit reached"))
            saved_urls.add(resource.url)
            continue
        candidate.kind = kind
        records.append(store.save_asset(candidate, resource.body, content_type=resource.content_type, final_url=resource.url))
        if mission.warc and not is_sensitive_endpoint(resource.url):
            store.archive_response(resource.url, resource.status_code, {"content-type": resource.content_type}, resource.body)
        saved_urls.add(resource.url)
        total += len(resource.body)
        count += 1

    for url, candidate in by_url.items():
        if url not in saved_urls:
            records.append(store.record_asset_failure(candidate, "asset discovered but no downloadable body captured"))
            saved_urls.add(url)
    return records
