from __future__ import annotations

import os
import re
from pathlib import Path
from urllib.parse import urlsplit

_SAFE = re.compile(r"^[A-Za-z0-9._-]+$")


def auth_state_path(url: str, profile: str = "default", base_dir: str | Path | None = None) -> Path:
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError("Authentication profiles require an http(s) URL")
    if not _SAFE.fullmatch(profile) or profile in {".", ".."}:
        raise ValueError("Profile name may contain only letters, numbers, dot, underscore, and hyphen")
    host = parsed.hostname.lower()
    base = (Path(base_dir) if base_dir is not None else Path.cwd() / ".harvester" / "auth").resolve()
    path = (base / host / profile / "storage_state.json").resolve()
    if base not in path.parents:
        raise ValueError("Auth profile path escaped the auth base directory")
    return path



def session_storage_path(url: str, profile: str = "default", base_dir: str | Path | None = None) -> Path:
    return auth_state_path(url, profile, base_dir).with_name("session_storage.json")


def auth_profile_exists(url: str, profile: str = "default", base_dir: str | Path | None = None) -> bool:
    return auth_state_path(url, profile, base_dir).is_file()


def capture_auth_session(url: str, profile: str = "default", base_dir: str | Path | None = None, browser_name: str = "chromium") -> Path:
    state_path = auth_state_path(url, profile, base_dir)
    state_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("Playwright is required for browser authentication. Install browser extras first.") from exc

    with sync_playwright() as p:
        browser_type = getattr(p, browser_name, None)
        if browser_type is None:
            raise ValueError(f"Unsupported browser: {browser_name}")
        browser = browser_type.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()
        page.goto(url, wait_until="domcontentloaded")
        print("Complete login in the opened browser. Do not paste passwords into Codex.")
        input("When the target page is fully logged in, press Enter here to save the authorized session... ")
        try:
            context.storage_state(path=str(state_path), indexed_db=True, credentials=True)
        except TypeError:
            try:
                context.storage_state(path=str(state_path), indexed_db=True)
            except TypeError:
                context.storage_state(path=str(state_path))
        session_path = session_storage_path(url, profile, base_dir)
        try:
            session_data = page.evaluate("() => Object.fromEntries(Object.entries(sessionStorage))")
        except Exception:
            session_data = {}
        if session_data:
            import json
            from urllib.parse import urlsplit
            parsed = urlsplit(page.url)
            origin = f"{parsed.scheme}://{parsed.netloc}"
            session_path.write_text(json.dumps({"origin": origin, "data": session_data}, ensure_ascii=False), encoding="utf-8")
        browser.close()
    for protected in (state_path, session_storage_path(url, profile, base_dir)):
        if protected.exists():
            try:
                os.chmod(protected, 0o600)
            except OSError:
                pass
    return state_path
