from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from .auth import auth_profile_exists
from .crawler import crawl
from .discovery import discover_sitemap_urls
from .http_engine import HttpEngine
from .models import HarvestMission
from .profiler import profile_html
from .router import choose_route
from .urltools import canonicalize_url


def probe_target(mission: HarvestMission) -> dict:
    url = canonicalize_url(mission.url)
    if not url.startswith(("http://", "https://")):
        raise ValueError("Only http:// and https:// URLs are supported")
    engine = HttpEngine(timeout=mission.timeout, retries=mission.retries, delay=mission.delay)
    fetched = engine.fetch(url)
    profile = profile_html(fetched.final_url or url, fetched.status_code, fetched.content_type, fetched.text)
    auth_exists = bool(mission.auth_profile and auth_profile_exists(url, mission.auth_profile))
    decision = choose_route(profile, mission, auth_exists)
    payload = asdict(profile)
    sitemap_sample = discover_sitemap_urls(url, engine, max_urls=20) if mission.discover else []
    return {
        "route": decision.route.value,
        "reason": decision.reason,
        "auth_profile_available": auth_exists,
        "profile": payload,
        "discovery": {
            "rss_links": profile.rss_links,
            "sitemap_sample": sitemap_sample,
            "same_origin_link_sample": profile.same_origin_links[:20],
            "jsonld_blocks": profile.jsonld_count,
        },
    }


def run_mission(mission: HarvestMission):
    return crawl(mission)
