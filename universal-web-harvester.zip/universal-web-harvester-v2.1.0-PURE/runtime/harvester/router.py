from __future__ import annotations

from .models import BrowserPolicy, HarvestMission, HarvestMode, Route, RouteDecision, SiteProfile


def choose_route(profile: SiteProfile, mission: HarvestMission, auth_exists: bool) -> RouteDecision:
    if profile.challenge_detected or (profile.blocked and not profile.login_required):
        return RouteDecision(Route.STOP_BLOCKED, "Access challenge/block detected; do not evade")
    if profile.direct_download:
        return RouteDecision(Route.DOWNLOAD, "Target content type is downloadable")
    if profile.login_required:
        if auth_exists:
            return RouteDecision(Route.AUTH_BROWSER, "Login required and authorized session profile exists")
        return RouteDecision(Route.STOP_AUTH_REQUIRED, "Login required but no authorized session profile exists")
    if mission.browser is BrowserPolicy.ALWAYS:
        return RouteDecision(Route.BROWSER, "Browser explicitly requested")
    if mission.mode in {HarvestMode.MEDIA, HarvestMode.DEEP, HarvestMode.MIRROR} and mission.browser is not BrowserPolicy.NEVER:
        return RouteDecision(Route.BROWSER, f"{mission.mode.value} mode prefers rendered browser capture")
    if profile.dynamic_shell:
        if mission.browser is BrowserPolicy.NEVER:
            return RouteDecision(Route.STOP_BLOCKED, "Dynamic rendering required but browser use is disabled")
        return RouteDecision(Route.BROWSER, "HTTP response is a client-rendered shell")
    return RouteDecision(Route.HTTP, "Server-rendered response is sufficient")
