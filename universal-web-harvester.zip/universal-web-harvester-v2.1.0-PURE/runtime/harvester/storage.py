from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import re
import shutil
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote, urlsplit

from .models import AssetCandidate, AssetRecord, FailureRecord, HarvestMission, PageRecord, ValidationReport
from .archive import WarcArchive

_SAFE = re.compile(r"[^A-Za-z0-9._-]+")
_MIME_EXT = {
    "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/gif": ".gif",
    "image/avif": ".avif", "image/svg+xml": ".svg", "application/pdf": ".pdf",
    "application/zip": ".zip", "application/json": ".json", "text/css": ".css",
    "video/mp4": ".mp4", "video/webm": ".webm", "audio/mpeg": ".mp3", "audio/ogg": ".ogg",
}


def _jsonable(obj):
    if isinstance(obj, Path):
        return str(obj)
    if hasattr(obj, "value"):
        return obj.value
    raise TypeError(f"Not JSON serializable: {type(obj).__name__}")


def _filename_from_url(url: str, content_type: str = "") -> str:
    name = unquote(Path(urlsplit(url).path).name or "asset")
    name = _SAFE.sub("_", name)[:160] or "asset"
    if "." not in name:
        mime = (content_type or "").split(";", 1)[0].strip().lower()
        ext = _MIME_EXT.get(mime) or mimetypes.guess_extension(mime) or ""
        name += ext
    return name


class JobStore:
    def __init__(self, mission: HarvestMission):
        root = Path(mission.output_dir) if mission.output_dir else Path.cwd() / ".harvester" / "jobs"
        host = _SAFE.sub("_", urlsplit(mission.url).netloc or "job")
        if mission.resume_dir:
            self.job_dir = Path(mission.resume_dir)
            self.job_dir.mkdir(parents=True, exist_ok=True)
        else:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            self.job_dir = root / f"{stamp}-{host}"
            self.job_dir.mkdir(parents=True, exist_ok=False)

        self.content_dir = self.job_dir / "content"
        self.pages_dir = self.content_dir / "markdown"  # v1 compatibility alias
        self.html_dir = self.content_dir / "html"
        self.media_dir = self.job_dir / "media"
        self.images_dir = self.media_dir / "images"
        self.video_dir = self.media_dir / "video"
        self.audio_dir = self.media_dir / "audio"
        self.other_media_dir = self.media_dir / "other"
        self.web_dir = self.job_dir / "web"
        self.css_dir = self.web_dir / "css"
        self.js_dir = self.web_dir / "js"
        self.fonts_dir = self.web_dir / "fonts"
        self.web_other_dir = self.web_dir / "other"
        self.files_dir = self.job_dir / "files"
        self.download_dir = self.job_dir / "downloads"  # v1 compatibility directory
        self.mirror_dir = self.job_dir / "mirror"
        self.screenshots_dir = self.job_dir / "screenshots"
        self.network_dir = self.job_dir / "network" / "data"
        self.manifests_dir = self.job_dir / "manifests"
        for path in [self.pages_dir, self.html_dir, self.images_dir, self.video_dir, self.audio_dir,
                     self.other_media_dir, self.css_dir, self.js_dir, self.fonts_dir, self.web_other_dir, self.files_dir, self.download_dir, self.mirror_dir, self.screenshots_dir,
                     self.network_dir, self.manifests_dir]:
            path.mkdir(parents=True, exist_ok=True)

        self.manifest_path = self.job_dir / "manifest.json"
        self.records_path = self.manifests_dir / "pages.jsonl"
        self.failures_path = self.manifests_dir / "failures.jsonl"
        self.assets_path = self.manifests_dir / "assets.jsonl"
        self.network_path = self.manifests_dir / "network.jsonl"
        self.relationships_path = self.manifests_dir / "relationships.jsonl"
        self.report_path = self.job_dir / "report.json"
        self.url_map_path = self.manifests_dir / "url-map.json"
        self._hash_paths: dict[str, str] = {}
        self._url_map: dict[str, str] = {}
        self.asset_records: list[AssetRecord] = []
        self.mirror_page_count = 0
        self._rendered_html_paths: dict[str, Path] = {}
        self._mirror_url_map: dict[str, str] = {}
        self._relationship_keys: set[tuple[str, str, str, str | None, str | None]] = set()
        self.warc_archive = WarcArchive(self.job_dir / "archive" / "site.warc.gz") if mission.warc else None

        if self.assets_path.is_file():
            for line in self.assets_path.read_text(encoding="utf-8").splitlines():
                try:
                    d = json.loads(line)
                    allowed = {f.name for f in __import__('dataclasses').fields(AssetRecord)}
                    record = AssetRecord(**{k: v for k, v in d.items() if k in allowed})
                    self.asset_records.append(record)
                    if record.sha256 and record.local_path:
                        self._hash_paths[record.sha256] = record.local_path
                    if record.source_url and record.local_path:
                        self._url_map[record.source_url] = record.local_path
                    if record.final_url and record.local_path:
                        self._url_map[record.final_url] = record.local_path
                except Exception:
                    continue

        if self.relationships_path.is_file():
            for line in self.relationships_path.read_text(encoding="utf-8").splitlines():
                try:
                    d = json.loads(line)
                    self._relationship_keys.add((
                        d.get("page_url", ""), d.get("asset_url", ""), d.get("kind", "other"),
                        d.get("group_id"), d.get("frame_url"),
                    ))
                except Exception:
                    continue

        manifest = asdict(mission)
        manifest.pop("auth_profile", None)
        self.manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=_jsonable), encoding="utf-8")

    @property
    def url_map(self) -> dict[str, str]:
        return dict(self._url_map)

    @property
    def rendered_html_paths(self) -> dict[str, Path]:
        return dict(self._rendered_html_paths)

    @property
    def mirror_url_map(self) -> dict[str, str]:
        return dict(self._mirror_url_map)

    def mirror_relative_path(self, url: str) -> str:
        name = hashlib.sha1(url.encode()).hexdigest()[:16] + ".html"
        return (Path("mirror") / name).as_posix()

    def archive_response(self, url: str, status_code: int, headers: dict[str, str], body: bytes) -> None:
        if self.warc_archive is not None:
            self.warc_archive.write_response(url, status_code, headers, body)

    def append_record(self, record: PageRecord) -> None:
        with self.records_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(record), ensure_ascii=False, default=_jsonable) + "\n")
        if record.text:
            name = hashlib.sha1(record.url.encode()).hexdigest()[:16] + ".md"
            content = f"# {record.title or record.url}\n\nSource: {record.url}\n\n{record.text}\n"
            (self.pages_dir / name).write_text(content, encoding="utf-8")

    def save_page_html(self, url: str, html: str, *, rendered: bool = True) -> Path:
        suffix = "rendered" if rendered else "original"
        name = hashlib.sha1(url.encode()).hexdigest()[:16] + f"-{suffix}.html"
        path = self.html_dir / name
        path.write_text(html, encoding="utf-8")
        if rendered:
            self._rendered_html_paths[url] = path
        return path

    def save_mirror(self, url: str, html: str) -> Path:
        rel = self.mirror_relative_path(url)
        path = self.job_dir / rel
        path.write_text(html, encoding="utf-8")
        self._mirror_url_map[url] = rel
        self.mirror_page_count = len(self._mirror_url_map)
        return path

    def save_screenshot(self, url: str, body: bytes, name: str = "full-page") -> Path:
        stem = hashlib.sha1(url.encode()).hexdigest()[:16]
        path = self.screenshots_dir / f"{stem}-{_SAFE.sub('_', name)}.png"
        path.write_bytes(body)
        return path

    def append_failure(self, failure: FailureRecord) -> None:
        with self.failures_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(failure), ensure_ascii=False, default=_jsonable) + "\n")

    def append_asset_relationship(self, candidate: AssetCandidate) -> None:
        key = (candidate.page_url, candidate.url, candidate.kind, candidate.group_id, candidate.frame_url)
        if key in self._relationship_keys:
            return
        self._relationship_keys.add(key)
        payload = {
            "page_url": candidate.page_url,
            "asset_url": candidate.url,
            "kind": candidate.kind,
            "discovered_by": candidate.discovered_by,
            "group_id": candidate.group_id,
            "frame_url": candidate.frame_url,
        }
        with self.relationships_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")

    def append_asset_record(self, record: AssetRecord) -> None:
        self.asset_records.append(record)
        with self.assets_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(record), ensure_ascii=False, default=_jsonable) + "\n")

    def _asset_dir(self, kind: str) -> Path:
        return {
            "image": self.images_dir,
            "video": self.video_dir,
            "audio": self.audio_dir,
            "file": self.files_dir,
            "stylesheet": self.css_dir,
            "script": self.js_dir,
            "font": self.fonts_dir,
            "web": self.web_other_dir,
        }.get(kind, self.other_media_dir)

    def has_asset_url(self, url: str) -> bool:
        rel = self._url_map.get(url)
        return bool(rel and (self.job_dir / rel).is_file())

    @property
    def existing_asset_bytes(self) -> int:
        seen = set()
        total = 0
        for record in self.asset_records:
            if record.status not in {"downloaded", "duplicate"} or not record.local_path:
                continue
            if record.local_path in seen:
                continue
            seen.add(record.local_path)
            path = self.job_dir / record.local_path
            if path.is_file():
                total += path.stat().st_size
        return total

    @property
    def existing_asset_count(self) -> int:
        return len({r.source_url for r in self.asset_records if r.status in {"downloaded", "duplicate"} and r.local_path})

    def save_asset(self, candidate: AssetCandidate, body: bytes, *, content_type: str = "", final_url: str | None = None) -> AssetRecord:
        self.append_asset_relationship(candidate)
        digest = hashlib.sha256(body).hexdigest()
        if digest in self._hash_paths:
            record = AssetRecord.from_candidate(candidate, final_url=final_url or candidate.url,
                                                mime=(content_type or candidate.mime).split(";", 1)[0], bytes=len(body),
                                                sha256=digest, status="duplicate", local_path=self._hash_paths[digest])
            self._url_map[candidate.url] = record.local_path
            self.append_asset_record(record)
            return record

        directory = self._asset_dir(candidate.kind)
        filename = _filename_from_url(final_url or candidate.url, content_type)
        path = directory / filename
        if path.exists():
            path = directory / f"{path.stem}-{hashlib.sha1(candidate.url.encode()).hexdigest()[:8]}{path.suffix}"
        path.write_bytes(body)
        rel = path.relative_to(self.job_dir).as_posix()
        self._hash_paths[digest] = rel
        self._url_map[candidate.url] = rel
        if final_url:
            self._url_map[final_url] = rel
        record = AssetRecord.from_candidate(candidate, final_url=final_url or candidate.url,
                                            mime=(content_type or candidate.mime).split(";", 1)[0], bytes=len(body),
                                            sha256=digest, status="downloaded", local_path=rel)
        self.append_asset_record(record)
        return record

    def record_asset_failure(self, candidate: AssetCandidate, error: str) -> AssetRecord:
        self.append_asset_relationship(candidate)
        record = AssetRecord.from_candidate(candidate, status="failed", error=error)
        self.append_asset_record(record)
        return record

    def save_network_data(self, url: str, body: bytes, content_type: str = "application/octet-stream") -> Path:
        digest = hashlib.sha1(url.encode()).hexdigest()[:16]
        ext = _MIME_EXT.get(content_type.split(";", 1)[0].lower(), ".bin")
        path = self.network_dir / f"{digest}{ext}"
        path.write_bytes(body)
        return path

    def append_network_metadata(self, payload: dict) -> None:
        with self.network_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False, default=_jsonable) + "\n")

    def save_download(self, url: str, body: bytes, content_disposition: str | None = None) -> Path:
        filename = ""
        if content_disposition:
            m = re.search(r"filename\*?=(?:UTF-8''|\")?([^\";]+)", content_disposition, re.I)
            if m:
                filename = m.group(1).strip().strip('"')
        if not filename:
            filename = _filename_from_url(url)
        filename = _SAFE.sub("_", filename)[:180] or "download.bin"
        legacy = self.download_dir / filename
        if legacy.exists():
            legacy = self.download_dir / (legacy.stem + "-" + hashlib.sha1(url.encode()).hexdigest()[:8] + legacy.suffix)

        digest = hashlib.sha256(body).hexdigest()
        existing_rel = self._hash_paths.get(digest)
        if existing_rel and (self.job_dir / existing_rel).is_file():
            canonical = self.job_dir / existing_rel
        else:
            canonical = self.files_dir / filename
            if canonical.exists():
                canonical = self.files_dir / (canonical.stem + "-" + hashlib.sha1(url.encode()).hexdigest()[:8] + canonical.suffix)
            canonical.write_bytes(body)

        # Legacy v1 path is an alias when the filesystem supports hardlinks, so large direct
        # downloads do not consume twice the disk space. Fall back to a copy on restricted filesystems.
        try:
            os.link(canonical, legacy)
        except Exception:
            shutil.copyfile(canonical, legacy)
        return legacy

    def finalize(self, report: ValidationReport) -> None:
        self.url_map_path.write_text(json.dumps(self._url_map, ensure_ascii=False, indent=2), encoding="utf-8")
        self.report_path.write_text(json.dumps(asdict(report), ensure_ascii=False, indent=2, default=_jsonable), encoding="utf-8")
