from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class HarvestMode(str, Enum):
    EXTRACT = "extract"
    MEDIA = "media"
    MIRROR = "mirror"
    DEEP = "deep"


class InteractionMode(str, Enum):
    PASSIVE = "passive"
    SAFE = "safe"


class BrowserPolicy(str, Enum):
    AUTO = "auto"
    NEVER = "never"
    ALWAYS = "always"


class Route(str, Enum):
    HTTP = "http"
    BROWSER = "browser"
    AUTH_BROWSER = "auth_browser"
    DOWNLOAD = "download"
    STOP_AUTH_REQUIRED = "stop_auth_required"
    STOP_BLOCKED = "stop_blocked"


class Verdict(str, Enum):
    PASS = "PASS"
    PARTIAL = "PARTIAL"
    BLOCKED = "BLOCKED"


@dataclass(slots=True)
class HarvestMission:
    url: str
    mode: HarvestMode = HarvestMode.EXTRACT
    interaction: InteractionMode = InteractionMode.SAFE
    scope: str = "page"
    max_pages: int = 50
    max_depth: int = 2
    browser: BrowserPolicy = BrowserPolicy.AUTO
    auth_profile: str | None = None
    fields: dict[str, str] = field(default_factory=dict)
    output_dir: Path | None = None
    delay: float = 0.5
    timeout: float = 20.0
    respect_robots: bool = True
    retries: int = 2
    discover: bool = True
    max_assets: int = 1000
    max_asset_bytes: int = 25 * 1024 * 1024
    max_total_asset_bytes: int = 500 * 1024 * 1024
    keep_variants: bool = False
    max_scroll_rounds: int = 12
    stable_rounds: int = 2
    capture_network_json: bool = True
    screenshot: bool = False
    resume_dir: Path | None = None
    warc: bool = False


@dataclass(slots=True)
class SiteProfile:
    url: str
    status_code: int
    content_type: str
    text_length: int
    visible_text_length: int
    dynamic_shell: bool = False
    login_required: bool = False
    blocked: bool = False
    direct_download: bool = False
    challenge_detected: bool = False
    rss_links: list[str] = field(default_factory=list)
    sitemap_links: list[str] = field(default_factory=list)
    same_origin_links: list[str] = field(default_factory=list)
    jsonld_count: int = 0
    notes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class RouteDecision:
    route: Route
    reason: str


@dataclass(slots=True)
class FetchResult:
    url: str
    status_code: int
    content_type: str
    body: bytes
    final_url: str | None = None
    headers: dict[str, str] = field(default_factory=dict)

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")




@dataclass(slots=True)
class AssetCandidate:
    url: str
    page_url: str
    kind: str = "other"
    discovered_by: str = "unknown"
    group_id: str | None = None
    descriptor: str | None = None
    width: int | None = None
    height: int | None = None
    alt: str = ""
    caption: str = ""
    mime: str = ""
    frame_url: str | None = None


@dataclass(slots=True)
class AssetRecord:
    page_url: str
    source_url: str
    final_url: str | None = None
    kind: str = "other"
    discovered_by: str = "unknown"
    group_id: str | None = None
    mime: str = ""
    width: int | None = None
    height: int | None = None
    bytes: int = 0
    sha256: str = ""
    status: str = "discovered"
    local_path: str = ""
    error: str | None = None

    @classmethod
    def from_candidate(cls, candidate: "AssetCandidate", **kwargs):
        data = {
            "page_url": candidate.page_url,
            "source_url": candidate.url,
            "kind": candidate.kind,
            "discovered_by": candidate.discovered_by,
            "group_id": candidate.group_id,
            "mime": candidate.mime,
            "width": candidate.width,
            "height": candidate.height,
        }
        data.update(kwargs)
        return cls(**data)


@dataclass(slots=True)
class CapturedResource:
    url: str
    status_code: int = 200
    content_type: str = ""
    resource_type: str = ""
    body: bytes | None = None
    frame_url: str | None = None


@dataclass(slots=True)
class InlineArtifact:
    name: str
    kind: str
    body: bytes
    page_url: str


@dataclass(slots=True)
class BrowserCapture:
    fetch: FetchResult
    assets: list[AssetCandidate] = field(default_factory=list)
    resources: list[CapturedResource] = field(default_factory=list)
    frames: list[str] = field(default_factory=list)
    inline_artifacts: list[InlineArtifact] = field(default_factory=list)
    screenshot: bytes | None = None

@dataclass(slots=True)
class PageRecord:
    url: str
    status_code: int
    content_type: str
    title: str = ""
    text: str = ""
    links: list[str] = field(default_factory=list)
    jsonld: list[Any] = field(default_factory=list)
    tables: list[list[list[str]]] = field(default_factory=list)
    fields: dict[str, Any] = field(default_factory=dict)
    route: str = ""
    depth: int = 0
    login_like: bool = False
    error: str | None = None


@dataclass(slots=True)
class FailureRecord:
    url: str
    reason: str
    retryable: bool = False
    status_code: int | None = None


@dataclass(slots=True)
class ValidationReport:
    verdict: Verdict
    record_count: int
    failure_count: int
    duplicate_count: int
    empty_count: int
    login_contamination_count: int
    field_fill_rates: dict[str, float] = field(default_factory=dict)
    reasons: list[str] = field(default_factory=list)
    asset_discovered_count: int = 0
    asset_downloaded_count: int = 0
    asset_failed_count: int = 0
    asset_duplicate_count: int = 0
    asset_unresolved_count: int = 0
    frame_count: int = 0
    mirror_page_count: int = 0


@dataclass(slots=True)
class JobResult:
    verdict: Verdict
    job_dir: Path
    report_path: Path
    records: list[PageRecord] = field(default_factory=list)
    failures: list[FailureRecord] = field(default_factory=list)
    validation: ValidationReport | None = None
