from __future__ import annotations

from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

_TRACKING_PREFIXES = ("utm_",)
_TRACKING_KEYS = {"fbclid", "gclid", "yclid", "mc_cid", "mc_eid"}


def canonicalize_url(url: str) -> str:
    p = urlsplit(url.strip())
    scheme = p.scheme.lower()
    host = (p.hostname or "").lower()
    port = p.port
    if port and not ((scheme == "http" and port == 80) or (scheme == "https" and port == 443)):
        netloc = f"{host}:{port}"
    else:
        netloc = host
    path = p.path or "/"
    if path != "/":
        path = path.rstrip("/")
    q = []
    for key, value in parse_qsl(p.query, keep_blank_values=True):
        lk = key.lower()
        if lk in _TRACKING_KEYS or any(lk.startswith(prefix) for prefix in _TRACKING_PREFIXES):
            continue
        q.append((key, value))
    q.sort()
    query = urlencode(q, doseq=True)
    return urlunsplit((scheme, netloc, path, query, ""))


def resolve_url(base: str, href: str) -> str:
    return canonicalize_url(urljoin(base, href))


def same_scope(seed: str, candidate: str, scope: str) -> bool:
    s = urlsplit(canonicalize_url(seed))
    c = urlsplit(canonicalize_url(candidate))
    if c.scheme not in {"http", "https"} or c.netloc != s.netloc:
        return False
    if scope == "site":
        return True
    if scope == "prefix":
        seed_path = s.path if s.path.endswith("/") else s.path.rsplit("/", 1)[0] + "/"
        return c.path.startswith(seed_path)
    return canonicalize_url(seed) == canonicalize_url(candidate)
