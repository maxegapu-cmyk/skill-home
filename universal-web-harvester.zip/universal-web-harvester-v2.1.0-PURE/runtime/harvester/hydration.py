from __future__ import annotations

import re
import time

from .models import InteractionMode

_SAFE_PATTERNS = [
    re.compile(r"^\s*(load|show|expand|view)\s+more\s*$", re.I),
    re.compile(r"^\s*(加载更多|查看更多|展开更多|显示更多)\s*$"),
]


def is_safe_expand_label(text: str) -> bool:
    value = " ".join((text or "").split())
    return any(p.fullmatch(value) for p in _SAFE_PATTERNS)


def _page_signature(page) -> tuple[int, int, int]:
    data = page.evaluate(
        """() => ({
            height: Math.max(document.body?.scrollHeight || 0, document.documentElement?.scrollHeight || 0),
            images: document.images ? document.images.length : 0,
            textLength: (document.body?.innerText || '').length
        })"""
    )
    return int(data.get("height", 0)), int(data.get("images", 0)), int(data.get("textLength", 0))


def _click_safe_expand_controls(page, max_clicks: int = 3) -> int:
    clicked = 0
    # We inspect actual visible labels first; only a tiny allowlist is accepted.
    for selector in ("button", "[role=button]", "a"):
        try:
            nodes = page.locator(selector)
            count = min(nodes.count(), 200)
        except Exception:
            continue
        for i in range(count):
            if clicked >= max_clicks:
                return clicked
            node = nodes.nth(i)
            try:
                if not node.is_visible():
                    continue
                label = (node.inner_text(timeout=300) or "").strip()
                if not is_safe_expand_label(label):
                    continue
                node.click(timeout=1000)
                clicked += 1
                time.sleep(0.15)
            except Exception:
                continue
    return clicked


def hydrate_page(
    page,
    *,
    interaction: InteractionMode = InteractionMode.SAFE,
    max_scroll_rounds: int = 12,
    stable_rounds: int = 2,
    settle_seconds: float = 0.2,
    max_expand_clicks: int = 3,
) -> dict[str, int]:
    """Bounded lazy-load hydration.

    Safe mode only clicks narrowly recognized content-expansion controls.
    It never clicks arbitrary navigation, transactional, social, or account controls.
    """
    stable = 0
    rounds = 0
    clicks = 0
    previous = None
    for _ in range(max(0, max_scroll_rounds)):
        rounds += 1
        try:
            page.evaluate("() => window.scrollTo(0, Math.max(document.body?.scrollHeight || 0, document.documentElement?.scrollHeight || 0))")
        except Exception:
            break
        if settle_seconds:
            time.sleep(settle_seconds)
        if interaction is InteractionMode.SAFE and clicks < max_expand_clicks:
            clicks += _click_safe_expand_controls(page, max_clicks=max_expand_clicks - clicks)
            if settle_seconds and clicks:
                time.sleep(settle_seconds)
        try:
            current = _page_signature(page)
        except Exception:
            break
        if current == previous:
            stable += 1
        else:
            stable = 0
        previous = current
        if stable >= max(1, stable_rounds):
            break
    try:
        page.evaluate("() => window.scrollTo(0, 0)")
    except Exception:
        pass
    return {"rounds": rounds, "safe_expand_clicks": clicks, "stable_rounds": stable}
