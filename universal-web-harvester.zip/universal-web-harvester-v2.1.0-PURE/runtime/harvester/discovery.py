from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from collections import deque
from urllib.parse import urlsplit, urlunsplit

from .urltools import canonicalize_url


def parse_robots_sitemaps(text: str) -> list[str]:
    out: list[str] = []
    for line in text.splitlines():
        m = re.match(r"\s*Sitemap\s*:\s*(\S+)\s*$", line, re.I)
        if m:
            out.append(m.group(1))
    return list(dict.fromkeys(out))


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def parse_sitemap_locations(xml_text: str) -> tuple[list[str], bool]:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return [], False
    nested = _local(root.tag) == "sitemapindex"
    urls: list[str] = []
    for elem in root.iter():
        if _local(elem.tag) == "loc" and elem.text and elem.text.strip():
            urls.append(elem.text.strip())
    return list(dict.fromkeys(urls)), nested


def discover_sitemap_urls(seed_url: str, engine, *, max_urls: int = 100, max_sitemaps: int = 8) -> list[str]:
    p = urlsplit(seed_url)
    origin = urlunsplit((p.scheme, p.netloc, "", "", ""))
    sitemap_queue: deque[str] = deque()
    seen_maps: set[str] = set()
    discovered: list[str] = []

    try:
        robots = engine.fetch(origin + "/robots.txt")
        if robots.status_code < 400:
            sitemap_queue.extend(parse_robots_sitemaps(robots.text))
    except Exception:
        pass
    if not sitemap_queue:
        sitemap_queue.append(origin + "/sitemap.xml")

    while sitemap_queue and len(seen_maps) < max_sitemaps and len(discovered) < max_urls:
        sm_url = canonicalize_url(sitemap_queue.popleft())
        if sm_url in seen_maps:
            continue
        seen_maps.add(sm_url)
        try:
            fetched = engine.fetch(sm_url)
        except Exception:
            continue
        if fetched.status_code >= 400:
            continue
        locations, nested = parse_sitemap_locations(fetched.text)
        if nested:
            for loc in locations:
                if loc.startswith(("http://", "https://")) and len(seen_maps) + len(sitemap_queue) < max_sitemaps:
                    sitemap_queue.append(loc)
        else:
            for loc in locations:
                if loc.startswith(("http://", "https://")):
                    discovered.append(canonicalize_url(loc))
                    if len(discovered) >= max_urls:
                        break
    return list(dict.fromkeys(discovered))
