from __future__ import annotations

import re
from html import unescape
from urllib.parse import urljoin, urlsplit

from .models import SiteProfile

_TAG_RE = re.compile(r"<[^>]+>", re.S)
_WS_RE = re.compile(r"\s+")
_HREF_RE = re.compile(r"href\s*=\s*['\"]([^'\"]+)['\"]", re.I)

_DOWNLOAD_TYPES = (
    "application/pdf", "application/zip", "application/x-zip", "application/octet-stream",
    "application/vnd.openxmlformats", "application/msword", "application/vnd.ms-",
    "image/", "audio/", "video/",
)
_LOGIN_TERMS = ("sign in", "signin", "log in", "login", "password", "登录", "登陆", "验证码")
_CHALLENGE_TERMS = ("captcha", "verify you are human", "attention required", "cloudflare ray id", "cf-chl", "人机验证")


def _visible_text(html: str) -> str:
    no_script = re.sub(r"<(script|style)\b[^>]*>.*?</\1>", " ", html, flags=re.I | re.S)
    text = unescape(_TAG_RE.sub(" ", no_script))
    return _WS_RE.sub(" ", text).strip()


def profile_html(url: str, status_code: int, content_type: str, html: str) -> SiteProfile:
    ctype = (content_type or "").split(";", 1)[0].lower().strip()
    low = html.lower()
    visible = _visible_text(html) if "html" in ctype or "<html" in low or "<div" in low else html
    direct_download = any(ctype.startswith(x) if x.endswith("/") else x in ctype for x in _DOWNLOAD_TYPES)
    password_input = bool(re.search(r"<input[^>]+type\s*=\s*['\"]?password", low, re.I))
    login_term_hits = sum(term in visible.lower() for term in _LOGIN_TERMS)
    login_required = password_input or (status_code in {401, 403} and login_term_hits > 0)
    challenge = any(term in low for term in _CHALLENGE_TERMS)
    blocked = status_code in {401, 403, 429} and not login_required or challenge

    app_root = bool(re.search(r"<div[^>]+id\s*=\s*['\"](?:app|root|__next)['\"][^>]*>\s*</div>", low, re.I | re.S))
    script_count = len(re.findall(r"<script\b", low, re.I))
    dynamic_shell = bool((app_root and len(visible) < 200) or (script_count >= 3 and len(visible) < 120))

    origin = urlsplit(url).netloc.lower()
    links: list[str] = []
    rss_links: list[str] = []
    sitemap_links: list[str] = []
    for href in _HREF_RE.findall(html):
        absolute = urljoin(url, href)
        p = urlsplit(absolute)
        if p.scheme in {"http", "https"} and p.netloc.lower() == origin:
            links.append(absolute)
        hlow = href.lower()
        if "rss" in hlow or "atom" in hlow or hlow.endswith(".xml") and "feed" in hlow:
            rss_links.append(absolute)
        if "sitemap" in hlow:
            sitemap_links.append(absolute)

    jsonld_count = len(re.findall(r"type\s*=\s*['\"]application/ld\+json['\"]", low, re.I))
    notes: list[str] = []
    if dynamic_shell:
        notes.append("HTML appears to be a client-rendered shell")
    if login_required:
        notes.append("Login indicators detected")
    if challenge:
        notes.append("Human-verification/challenge indicators detected")

    return SiteProfile(
        url=url,
        status_code=status_code,
        content_type=ctype,
        text_length=len(html),
        visible_text_length=len(visible),
        dynamic_shell=dynamic_shell,
        login_required=login_required,
        blocked=blocked,
        direct_download=direct_download,
        challenge_detected=challenge,
        rss_links=list(dict.fromkeys(rss_links)),
        sitemap_links=list(dict.fromkeys(sitemap_links)),
        same_origin_links=list(dict.fromkeys(links)),
        jsonld_count=jsonld_count,
        notes=notes,
    )
