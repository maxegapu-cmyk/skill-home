from __future__ import annotations

import email.utils
import time
from datetime import datetime, timezone

import httpx

from .models import FetchResult


class HttpEngine:
    def __init__(self, *, timeout: float = 20.0, retries: int = 2, delay: float = 0.5, user_agent: str = "UniversalWebHarvester/2.1"):
        self.timeout = timeout
        self.retries = retries
        self.delay = max(0.0, delay)
        self.user_agent = user_agent

    def _retry_after_seconds(self, value: str | None) -> float:
        if not value:
            return 0.0
        try:
            return max(0.0, float(value))
        except ValueError:
            try:
                dt = email.utils.parsedate_to_datetime(value)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return max(0.0, (dt - datetime.now(timezone.utc)).total_seconds())
            except Exception:
                return 0.0

    def fetch(self, url: str) -> FetchResult:
        last_exc: Exception | None = None
        headers = {"User-Agent": self.user_agent, "Accept": "*/*"}
        with httpx.Client(timeout=self.timeout, follow_redirects=True, headers=headers) as client:
            for attempt in range(self.retries + 1):
                if attempt and self.delay:
                    time.sleep(self.delay * (2 ** (attempt - 1)))
                try:
                    response = client.get(url)
                    if response.status_code == 429 and attempt < self.retries:
                        time.sleep(self._retry_after_seconds(response.headers.get("Retry-After")))
                        continue
                    if 500 <= response.status_code < 600 and attempt < self.retries:
                        continue
                    return FetchResult(
                        url=url,
                        final_url=str(response.url),
                        status_code=response.status_code,
                        content_type=response.headers.get("content-type", "application/octet-stream"),
                        body=response.content,
                        headers={k.lower(): v for k, v in response.headers.items()},
                    )
                except httpx.RequestError as exc:
                    last_exc = exc
                    if attempt >= self.retries:
                        raise
        assert last_exc is not None
        raise last_exc
