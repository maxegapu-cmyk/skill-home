from __future__ import annotations

from urllib.parse import urlsplit, urlunsplit
from urllib.robotparser import RobotFileParser

import httpx


class RobotsPolicy:
    def __init__(self, *, user_agent: str = "UniversalWebHarvester/2.1", timeout: float = 10.0):
        self.user_agent = user_agent
        self.timeout = timeout
        self._cache: dict[str, RobotFileParser | None] = {}

    def _origin(self, url: str) -> str:
        p = urlsplit(url)
        return urlunsplit((p.scheme, p.netloc, "", "", ""))

    def _load(self, url: str) -> RobotFileParser | None:
        origin = self._origin(url)
        if origin in self._cache:
            return self._cache[origin]
        robots_url = origin + "/robots.txt"
        try:
            r = httpx.get(robots_url, timeout=self.timeout, follow_redirects=True, headers={"User-Agent": self.user_agent})
            if r.status_code >= 400:
                self._cache[origin] = None
                return None
            parser = RobotFileParser()
            parser.set_url(robots_url)
            parser.parse(r.text.splitlines())
            self._cache[origin] = parser
            return parser
        except httpx.RequestError:
            self._cache[origin] = None
            return None

    def allowed(self, url: str) -> bool:
        parser = self._load(url)
        return True if parser is None else parser.can_fetch(self.user_agent, url)
