from __future__ import annotations

import posixpath
import re
from pathlib import Path
from urllib.parse import urljoin

from bs4 import BeautifulSoup

_URL_RE = re.compile(r"url\(\s*(['\"]?)(.*?)\1\s*\)", re.I)


def build_mirror_html(html: str, page_url: str, url_map: dict[str, str]) -> str:
    soup = BeautifulSoup(html, "lxml")

    def rewrite(value: str | None) -> str | None:
        if not value:
            return value
        absolute = urljoin(page_url, value)
        return url_map.get(absolute, url_map.get(value, value))

    for tag in soup.find_all(True):
        for attr in ("src", "poster", "href"):
            if tag.has_attr(attr):
                tag[attr] = rewrite(tag.get(attr))
        if tag.has_attr("srcset"):
            parts = []
            for item in str(tag.get("srcset", "")).split(","):
                bits = item.strip().split()
                if not bits:
                    continue
                parts.append(" ".join([rewrite(bits[0]) or bits[0], *bits[1:]]))
            tag["srcset"] = ", ".join(parts)
        for attr in ("data-src", "data-original", "data-lazy-src", "data-url"):
            if tag.has_attr(attr):
                tag[attr] = rewrite(tag.get(attr))
        for attr in ("data-srcset", "data-lazy-srcset"):
            if tag.has_attr(attr):
                parts = []
                for item in str(tag.get(attr, "")).split(","):
                    bits = item.strip().split()
                    if not bits:
                        continue
                    parts.append(" ".join([rewrite(bits[0]) or bits[0], *bits[1:]]))
                tag[attr] = ", ".join(parts)
        if tag.has_attr("style"):
            style = str(tag.get("style", ""))
            def repl(match):
                raw = match.group(2)
                new = rewrite(raw) or raw
                return f"url('{new}')"
            tag["style"] = _URL_RE.sub(repl, style)

    for style in soup.find_all("style"):
        raw = style.string or style.get_text()
        if raw:
            def repl(match):
                old = match.group(2)
                new = rewrite(old) or old
                return f"url('{new}')"
            style.string = _URL_RE.sub(repl, raw)
    return str(soup)


def rewrite_css_urls(css: str, css_url: str, url_map: dict[str, str], css_local_path: str) -> str:
    start = posixpath.dirname(css_local_path) or "."

    def repl(match):
        raw = match.group(2)
        if not raw or raw.startswith(("data:", "blob:", "#")):
            return match.group(0)
        absolute = urljoin(css_url, raw)
        target = url_map.get(absolute)
        if not target:
            return match.group(0)
        relative = posixpath.relpath(target, start=start)
        return f"url('{relative}')"

    return _URL_RE.sub(repl, css)


def rewrite_saved_css_assets(store) -> None:
    processed: set[str] = set()
    for record in store.asset_records:
        if record.kind != "stylesheet" or record.status not in {"downloaded", "duplicate"} or not record.local_path:
            continue
        if record.local_path in processed:
            continue
        processed.add(record.local_path)
        path = store.job_dir / record.local_path
        if not path.is_file():
            continue
        try:
            css = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            css = path.read_text(encoding="utf-8", errors="replace")
        source = record.final_url or record.source_url
        path.write_text(rewrite_css_urls(css, source, store.url_map, record.local_path), encoding="utf-8")


def build_all_mirrors(store) -> None:
    rendered = store.rendered_html_paths
    if not rendered:
        return
    page_targets = {url: store.mirror_relative_path(url) for url in rendered}
    for page_url, html_path in rendered.items():
        mirror_rel = page_targets[page_url]
        start = posixpath.dirname(mirror_rel) or "."
        mapping: dict[str, str] = {}
        for source, target_rel in store.url_map.items():
            mapping[source] = posixpath.relpath(target_rel, start=start)
        for source, target_rel in page_targets.items():
            mapping[source] = posixpath.relpath(target_rel, start=start)
        html = html_path.read_text(encoding="utf-8")
        store.save_mirror(page_url, build_mirror_html(html, page_url, mapping))


def finalize_mirror(store) -> None:
    rewrite_saved_css_assets(store)
    build_all_mirrors(store)
