from __future__ import annotations

import json
import re

_SENSITIVE_KEY = re.compile(
    r"(?:password|passwd|secret|access[_-]?token|refresh[_-]?token|id[_-]?token|authorization|cookie|session(?:id)?|csrf|xsrf|otp|api[_-]?key|credential)",
    re.I,
)
_SENSITIVE_PATH = re.compile(r"/(?:oauth|auth|login|signin|sign-in|token|session|logout)(?:/|\?|$)", re.I)


def is_sensitive_endpoint(url: str) -> bool:
    return bool(_SENSITIVE_PATH.search(url or ""))


def should_store_json_response(url: str) -> bool:
    return not is_sensitive_endpoint(url)


def _redact(value):
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if _SENSITIVE_KEY.search(str(k)):
                out[k] = "[REDACTED]"
            else:
                out[k] = _redact(v)
        return out
    if isinstance(value, list):
        return [_redact(v) for v in value]
    return value


def sanitize_json_body(body: bytes) -> bytes:
    try:
        parsed = json.loads(body.decode("utf-8", errors="strict"))
    except Exception:
        return b""
    return json.dumps(_redact(parsed), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
