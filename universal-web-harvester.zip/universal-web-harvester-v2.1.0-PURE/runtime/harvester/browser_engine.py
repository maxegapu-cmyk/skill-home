from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import urljoin

from .assets import discover_css_asset_candidates, parse_srcset, resolve_asset_candidates
from .hydration import hydrate_page
from .models import (
    AssetCandidate,
    BrowserCapture,
    CapturedResource,
    FetchResult,
    InlineArtifact,
    InteractionMode,
)


class BrowserDependencyError(RuntimeError):
    pass


def _absolute(base: str, raw: str | None) -> str | None:
    if not raw:
        return None
    raw = str(raw).strip()
    if not raw or raw.startswith(("data:", "blob:", "javascript:", "#")):
        return None
    value = urljoin(base, raw)
    return value if value.startswith(("http://", "https://")) else None


def normalize_browser_asset_payload(page_url: str, payload: list[dict], *, frame_url: str | None = None) -> list[AssetCandidate]:
    out: list[AssetCandidate] = []
    for idx, item in enumerate(payload or []):
        kind = str(item.get("kind") or "other")
        group = str(item.get("group") or f"browser-{idx}")
        by = str(item.get("by") or "browser-dom")
        width = item.get("width")
        height = item.get("height")
        try: width = int(width) if width else None
        except (TypeError, ValueError): width = None
        try: height = int(height) if height else None
        except (TypeError, ValueError): height = None
        alt = str(item.get("alt") or "")

        def add(raw, discovered_by, descriptor=None, candidate_width=None):
            url = _absolute(page_url, raw)
            if not url:
                return
            out.append(AssetCandidate(
                url=url,
                page_url=page_url,
                kind=kind,
                discovered_by=discovered_by,
                group_id=group,
                descriptor=descriptor,
                width=candidate_width or width,
                height=height,
                alt=alt,
                frame_url=frame_url,
            ))

        add(item.get("url"), by)
        if item.get("currentSrc"):
            add(item.get("currentSrc"), "browser:currentSrc")
        for raw, desc, sw in parse_srcset(item.get("srcset")):
            add(raw, "browser:srcset", descriptor=desc, candidate_width=sw)

    seen = set(); dedup = []
    for item in out:
        key = (item.url, item.group_id, item.frame_url)
        if key in seen:
            continue
        seen.add(key); dedup.append(item)
    return dedup


def network_capture_priority(content_type: str, resource_type: str) -> int:
    mime = (content_type or "").split(";", 1)[0].strip().lower()
    if mime.startswith(("image/", "audio/", "video/")) or resource_type in {"image", "media"}:
        return 0
    if mime in {"application/pdf", "application/zip", "application/x-zip-compressed", "application/octet-stream"}:
        return 1
    if mime == "text/css" or mime.startswith(("font/", "application/font-", "application/vnd.ms-fontobject")) or resource_type in {"stylesheet", "font"}:
        return 2
    if mime in {"application/javascript", "text/javascript", "application/wasm"} or resource_type == "script":
        return 3
    if "json" in mime or resource_type in {"xhr", "fetch"}:
        return 4
    return 5


def should_capture_network_body(content_type: str, resource_type: str) -> bool:
    mime = (content_type or "").split(";", 1)[0].strip().lower()
    if mime.startswith(("image/", "audio/", "video/")):
        return True
    if mime in {
        "application/pdf", "application/zip", "application/x-zip-compressed",
        "application/json", "application/ld+json", "application/vnd.api+json",
        "application/octet-stream", "application/javascript", "text/javascript",
        "text/css", "application/wasm",
    }:
        return True
    if mime.startswith(("font/", "application/font-", "application/vnd.ms-fontobject")):
        return True
    if resource_type in {"xhr", "fetch"} and ("json" in mime or mime == "text/plain"):
        return True
    if resource_type in {"stylesheet", "script", "font"}:
        return True
    return False


_DOM_COLLECTOR = r"""
() => {
  const out = [];
  let seq = 0;
  const visitedRoots = new Set();
  function push(o) { out.push(o); }
  function scan(root) {
    if (!root || visitedRoots.has(root)) return;
    visitedRoots.add(root);
    const nodes = root.querySelectorAll ? Array.from(root.querySelectorAll('*')).slice(0, 6000) : [];
    for (const el of nodes) {
      seq += 1;
      const tag = (el.tagName || '').toLowerCase();
      const group = `${tag || 'el'}-${seq}`;
      if (tag === 'img') {
        push({kind:'image', url:el.getAttribute('src'), currentSrc:el.currentSrc || '', srcset:el.getAttribute('srcset') || '', group, width:el.naturalWidth || el.width || 0, height:el.naturalHeight || el.height || 0, alt:el.getAttribute('alt') || '', by:'browser:img'});
        for (const a of ['data-src','data-original','data-lazy-src','data-lazy','data-url','data-full','data-fullsrc','data-hi-res-src','data-zoom-image']) {
          const v = el.getAttribute(a); if (v) push({kind:'image', url:v, group, width:el.naturalWidth || 0, height:el.naturalHeight || 0, alt:el.getAttribute('alt') || '', by:`browser:${a}`});
        }
      } else if (tag === 'video') {
        if (el.currentSrc || el.getAttribute('src')) push({kind:'video', url:el.currentSrc || el.getAttribute('src'), group, by:'browser:video'});
        if (el.getAttribute('poster')) push({kind:'image', url:el.getAttribute('poster'), group:`poster-${seq}`, by:'browser:poster'});
      } else if (tag === 'audio') {
        if (el.currentSrc || el.getAttribute('src')) push({kind:'audio', url:el.currentSrc || el.getAttribute('src'), group, by:'browser:audio'});
      } else if (tag === 'source') {
        const p = (el.parentElement?.tagName || '').toLowerCase();
        const kind = p === 'picture' ? 'image' : p === 'video' ? 'video' : p === 'audio' ? 'audio' : 'other';
        push({kind, url:el.getAttribute('src'), srcset:el.getAttribute('srcset') || '', group:`source-${seq}`, by:'browser:source'});
      } else if (tag === 'iframe' || tag === 'frame') {
        if (el.src) push({kind:'frame', url:el.src, group, by:`browser:${tag}`});
      }
      try {
        const bg = getComputedStyle(el).backgroundImage || '';
        const re = /url\(["']?(.*?)["']?\)/g;
        let m; while ((m = re.exec(bg)) !== null) { if (m[1]) push({kind:'image', url:m[1], group:`bg-${seq}`, by:'computed-background'}); }
      } catch (_) {}
      if (el.shadowRoot) scan(el.shadowRoot);
    }
  }
  scan(document);
  return out;
}
"""


class BrowserEngine:
    def __init__(self, *, timeout: float = 20.0, headless: bool = True, state_path: str | Path | None = None, browser_name: str = "chromium"):
        self.timeout = timeout
        self.headless = headless
        self.state_path = Path(state_path) if state_path else None
        self.browser_name = browser_name

    def fetch(self, url: str) -> FetchResult:
        return self.capture(url, collect_assets=False, capture_network=False).fetch

    def capture(
        self,
        url: str,
        *,
        interaction: InteractionMode = InteractionMode.SAFE,
        max_scroll_rounds: int = 12,
        stable_rounds: int = 2,
        collect_assets: bool = True,
        capture_network: bool = True,
        capture_network_json: bool = True,
        capture_supporting_resources: bool = False,
        capture_screenshot: bool = False,
        capture_canvas: bool = False,
        max_assets: int = 1000,
        max_asset_bytes: int = 25 * 1024 * 1024,
        max_total_asset_bytes: int = 500 * 1024 * 1024,
        keep_variants: bool = False,
        asset_allowed=None,
    ) -> BrowserCapture:
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError, sync_playwright
        except ImportError as exc:
            raise BrowserDependencyError("Playwright is not installed. Install the browser extra and run `playwright install chromium`.") from exc

        with sync_playwright() as p:
            browser_type = getattr(p, self.browser_name, None)
            if browser_type is None:
                raise ValueError(f"Unsupported browser: {self.browser_name}")
            try:
                browser = browser_type.launch(headless=self.headless)
            except Exception as exc:
                raise BrowserDependencyError("Playwright browser executable is unavailable. Run `playwright install chromium`.") from exc
            kwargs = {}
            if self.state_path:
                if not self.state_path.is_file():
                    browser.close()
                    raise FileNotFoundError(f"Auth state not found: {self.state_path}")
                kwargs["storage_state"] = str(self.state_path)
            context = browser.new_context(**kwargs)
            if self.state_path:
                session_path = self.state_path.with_name("session_storage.json")
                if session_path.is_file():
                    try:
                        payload = json.loads(session_path.read_text(encoding="utf-8"))
                        origin = payload.get("origin", "")
                        data = payload.get("data", {})
                        if origin and isinstance(data, dict):
                            script = """(payload => {
                              if (window.location.origin === payload.origin) {
                                for (const [k, v] of Object.entries(payload.data)) sessionStorage.setItem(k, v);
                              }
                            })(%s)""" % json.dumps({"origin": origin, "data": data})
                            context.add_init_script(script=script)
                    except Exception:
                        pass
            page = context.new_page()
            page.set_default_timeout(self.timeout * 1000)
            observed = []
            if capture_network:
                page.on("response", lambda response: observed.append(response))
            try:
                response = page.goto(url, wait_until="domcontentloaded", timeout=self.timeout * 1000)
                try:
                    page.wait_for_load_state("networkidle", timeout=min(self.timeout, 5) * 1000)
                except PlaywrightTimeoutError:
                    pass
                hydrate_page(page, interaction=interaction, max_scroll_rounds=max_scroll_rounds, stable_rounds=stable_rounds)
                html = page.content()
                final_url = page.url
                status = response.status if response else 200
                headers = {k.lower(): v for k, v in (response.headers.items() if response else [])}
                content_type = headers.get("content-type", "text/html")
                fetch = FetchResult(url=url, final_url=final_url, status_code=status, content_type=content_type, body=html.encode("utf-8"), headers=headers)

                assets: list[AssetCandidate] = []
                frames: list[str] = []
                if collect_assets:
                    for frame in page.frames:
                        frame_url = frame.url or final_url
                        if frame_url and frame_url not in frames:
                            frames.append(frame_url)
                        try:
                            payload = frame.evaluate(_DOM_COLLECTOR)
                        except Exception:
                            continue
                        assets.extend(normalize_browser_asset_payload(frame_url, payload, frame_url=frame_url))

                resources: list[CapturedResource] = []
                resource_by_url: dict[str, CapturedResource] = {}
                total = 0
                if capture_network:
                    rows = []
                    for resp in observed:
                        try:
                            rurl = resp.url
                            ctype = (resp.headers.get("content-type") or "").lower()
                            rtype = resp.request.resource_type
                            item = CapturedResource(url=rurl, status_code=resp.status, content_type=ctype, resource_type=rtype, body=None, frame_url=getattr(resp.request.frame, "url", None))
                            resource_by_url[rurl] = item
                            rows.append((network_capture_priority(ctype, rtype), resp, item))
                        except Exception:
                            continue
                    # Visible media/files first, then CSS/fonts, then JS, then API data. This keeps
                    # support bundles from consuming the entire byte budget before user-visible assets.
                    for priority, resp, item in sorted(rows, key=lambda row: row[0]):
                        try:
                            ctype = item.content_type
                            rtype = item.resource_type
                            if not should_capture_network_body(ctype, rtype):
                                continue
                            is_json = "json" in ctype or rtype in {"xhr", "fetch"}
                            is_support = priority in {2, 3}
                            if is_json and not capture_network_json:
                                continue
                            if is_support and not capture_supporting_resources:
                                continue
                            body = resp.body()
                            limit = min(max_asset_bytes, 2 * 1024 * 1024) if is_json else max_asset_bytes
                            if len(body) <= limit and total + len(body) <= max_total_asset_bytes:
                                item.body = body
                                total += len(body)
                        except Exception:
                            continue
                    resources.extend(resource_by_url.values())

                # External stylesheets often hide background images, fonts, and imported stylesheets.
                # Resolve their URLs against the stylesheet itself, then fetch those candidates through
                # the same authorized browser context.
                if collect_assets:
                    for resource in resources:
                        mime = (resource.content_type or '').split(';', 1)[0].strip().lower()
                        if mime == 'text/css' and resource.body is not None:
                            try:
                                css_text = resource.body.decode('utf-8', errors='replace')
                                assets.extend(discover_css_asset_candidates(
                                    resource.url, css_text, page_url=resource.frame_url or final_url
                                ))
                            except Exception:
                                continue
                    assets = resolve_asset_candidates(assets, keep_variants=keep_variants)

                # Fetch high-resolution DOM/CSS candidates through the authenticated browser request context.
                if collect_assets:
                    existing = {r.url for r in resources if r.body is not None}
                    for candidate in assets[:max_assets]:
                        if candidate.kind == "frame" or candidate.url in existing or total >= max_total_asset_bytes:
                            continue
                        if asset_allowed is not None:
                            try:
                                if not asset_allowed(candidate.url):
                                    resources.append(CapturedResource(url=candidate.url, status_code=0, content_type="", resource_type="robots-blocked", frame_url=candidate.frame_url))
                                    continue
                            except Exception:
                                pass
                        try:
                            r = context.request.get(candidate.url, timeout=self.timeout * 1000, fail_on_status_code=False)
                            ctype = (r.headers.get("content-type") or "").lower()
                            if r.status >= 400:
                                resources.append(CapturedResource(url=candidate.url, status_code=r.status, content_type=ctype, resource_type=candidate.kind))
                                continue
                            body = r.body()
                            if len(body) > max_asset_bytes or total + len(body) > max_total_asset_bytes:
                                resources.append(CapturedResource(url=candidate.url, status_code=r.status, content_type=ctype, resource_type=candidate.kind))
                                continue
                            resources.append(CapturedResource(url=candidate.url, status_code=r.status, content_type=ctype, resource_type=candidate.kind, body=body, frame_url=candidate.frame_url))
                            total += len(body)
                            existing.add(candidate.url)
                        except Exception:
                            continue

                inline_artifacts: list[InlineArtifact] = []
                if capture_canvas:
                    try:
                        canvases = page.locator("canvas")
                        for i in range(min(canvases.count(), 20)):
                            node = canvases.nth(i)
                            if node.is_visible():
                                body = node.screenshot(type="png", timeout=2000)
                                inline_artifacts.append(InlineArtifact(name=f"canvas-{i+1}", kind="canvas", body=body, page_url=final_url))
                    except Exception:
                        pass
                screenshot = None
                if capture_screenshot:
                    try:
                        screenshot = page.screenshot(full_page=True, type="png", timeout=min(self.timeout, 10) * 1000)
                    except Exception:
                        screenshot = None
                return BrowserCapture(fetch=fetch, assets=assets, resources=resources, frames=frames,
                                      inline_artifacts=inline_artifacts, screenshot=screenshot)
            finally:
                context.close()
                browser.close()
