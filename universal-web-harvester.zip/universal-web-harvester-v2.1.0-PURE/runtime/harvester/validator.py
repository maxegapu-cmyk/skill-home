from __future__ import annotations

from collections import Counter

from .models import AssetRecord, FailureRecord, PageRecord, ValidationReport, Verdict


def validate_job(
    records: list[PageRecord],
    failures: list[FailureRecord],
    expected: int | None = None,
    *,
    assets: list[AssetRecord] | None = None,
    discovered_assets: int = 0,
    frame_count: int = 0,
    mirror_page_count: int = 0,
) -> ValidationReport:
    assets = assets or []
    urls = [r.url for r in records]
    counts = Counter(urls)
    duplicate_count = sum(n - 1 for n in counts.values() if n > 1)
    empty_count = sum(1 for r in records if len((r.text or "").strip()) < 20 and not r.content_type.startswith(("application/", "image/", "audio/", "video/")))
    login_contamination_count = sum(1 for r in records if r.login_like)

    field_names = sorted({name for r in records for name in r.fields})
    fill_rates: dict[str, float] = {}
    for name in field_names:
        present = sum(1 for r in records if str(r.fields.get(name, "")).strip())
        fill_rates[name] = present / len(records) if records else 0.0

    asset_downloaded = sum(1 for a in assets if a.status == "downloaded")
    asset_duplicates = sum(1 for a in assets if a.status == "duplicate")
    asset_failed = sum(1 for a in assets if a.status == "failed")
    satisfied = asset_downloaded + asset_duplicates
    asset_unresolved = max(0, discovered_assets - satisfied - asset_failed)

    reasons: list[str] = []
    if failures:
        reasons.append(f"{len(failures)} failed URL(s)")
    if duplicate_count:
        reasons.append(f"{duplicate_count} duplicate record(s)")
    if empty_count:
        reasons.append(f"{empty_count} empty/near-empty record(s)")
    if login_contamination_count:
        reasons.append(f"{login_contamination_count} login-like record(s) contaminated output")
    if expected is not None and len(records) < expected:
        reasons.append(f"expected at least {expected} record(s), got {len(records)}")
    low_fill = {k: v for k, v in fill_rates.items() if v < 0.8}
    if low_fill:
        reasons.append("low selector field fill rate: " + ", ".join(f"{k}={v:.0%}" for k, v in low_fill.items()))
    if asset_failed:
        reasons.append(f"{asset_failed} asset download(s) failed")
    if asset_unresolved:
        reasons.append(f"{asset_unresolved} discovered asset(s) unresolved")

    if not records and failures and not assets:
        verdict = Verdict.BLOCKED
    elif reasons:
        verdict = Verdict.PARTIAL
    else:
        verdict = Verdict.PASS

    return ValidationReport(
        verdict=verdict,
        record_count=len(records),
        failure_count=len(failures),
        duplicate_count=duplicate_count,
        empty_count=empty_count,
        login_contamination_count=login_contamination_count,
        field_fill_rates=fill_rates,
        reasons=reasons,
        asset_discovered_count=discovered_assets,
        asset_downloaded_count=asset_downloaded,
        asset_failed_count=asset_failed,
        asset_duplicate_count=asset_duplicates,
        asset_unresolved_count=asset_unresolved,
        frame_count=frame_count,
        mirror_page_count=mirror_page_count,
    )
