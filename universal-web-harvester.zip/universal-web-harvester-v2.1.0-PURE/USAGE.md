# Universal Web Harvester 2.1 — Usage Recipes

## Pick the right mode

- `extract` — text, links, tables, JSON-LD and explicit CSS fields. Cheapest route.
- `media` — asset-first capture. With `--browser auto` it prefers a rendered browser so lazy images, computed backgrounds, runtime media and stylesheet-referenced assets are less likely to be missed; use `--browser never` for a faster HTML-only pass.
- `mirror` — render pages in a browser, capture web assets, and build local rewritten HTML.
- `deep` — strongest general mode: rendered DOM + safe hydration + media/files + network assets + canvas fallback + screenshots + completeness audit.

For requests such as “把这个复杂页面里的文字图片附件全部扒下来 / 尽可能扒完整”, use `deep`.

## 1. One public page — text only

```powershell
python scripts\harvest.py "https://example.com/article" --mode extract --scope page
```

## 2. One complex page — text + every discoverable image/file

```powershell
python scripts\harvest.py "https://example.com/gallery" --mode deep --scope page --browser auto --max-assets 3000 --max-total-asset-mb 2048
```

`deep` scrolls the page, waits for lazy-loaded content, safely clicks narrowly recognized “load/show more” controls, inspects rendered DOM/Shadow DOM/frames, records relevant browser responses, saves downloadable assets, captures canvas elements when no ordinary source exists, and emits a full-page screenshot.

## 3. Entire section/category

```powershell
python scripts\harvest.py "https://example.com/category/ai" --mode deep --scope prefix --max-pages 500 --max-depth 5 --max-assets 10000 --max-total-asset-mb 8192
```

The crawler uses sitemap discovery when available, then bounded same-origin traversal and deduplication.

## 4. Media-heavy site — force the fast HTML-only path

```powershell
python scripts\harvest.py "https://example.com/photos" --mode media --scope site --browser never --max-pages 300
```

This is faster than browser-backed `media`/`deep`, but it cannot verify assets injected only after JavaScript interaction. Leave `--browser auto` on when completeness matters.

## 5. Logged-in site you are authorized to access

```powershell
python scripts\auth_session.py "https://example.com/login" --profile myaccount
python scripts\probe.py "https://example.com/account" --auth-profile myaccount
python scripts\harvest.py "https://example.com/account" --mode deep --scope prefix --auth-profile myaccount
```

The Skill never asks for the password in chat. Login happens in the real browser window.

## 6. Repeated records with known fields

```powershell
python scripts\harvest.py "https://shop.example.com/products" --mode extract --scope site --max-pages 1000 --fields-json '{"name":"h1","price":".price","sku":"[data-sku]"}'
```

Low selector fill rates produce `PARTIAL`, not a false success.

## 7. Keep every image variant

Normally the resolver prefers the strongest candidate for one image group. To keep thumbnails plus `srcset`/original variants:

```powershell
python scripts\harvest.py "https://example.com/gallery" --mode deep --scope page --keep-variants
```

`mirror` and `deep` already retain variants needed for fidelity.

## 8. Resume a large asset job

```powershell
python scripts\harvest.py "https://example.com/gallery" --mode deep --scope site --resume "C:\path\to\previous-job"
```

Downloaded asset hashes and URL mappings are reused so already-saved files are not downloaded again.

## 9. Optional WARC archive

After installing the archive extra, verify it and then harvest:

```powershell
python scripts\self_check.py --archive
python scripts\harvest.py "https://example.com" --mode deep --scope prefix --warc
```

The friendly directory output remains the primary result; WARC is additional archival output.

## Output layout

A v2 job can contain:

```text
job/
  content/
    markdown/          cleaned readable text
    html/              original/rendered HTML
  media/
    images/
    video/
    audio/
    other/
  files/               PDF/ZIP/Office/etc.
  web/
    css/
    js/
    fonts/
    other/
  mirror/              rewritten offline HTML
  screenshots/         full-page/canvas fallbacks
  network/data/        sanitized useful JSON responses
  manifests/
    pages.jsonl
    assets.jsonl
    network.jsonl
    failures.jsonl
    relationships.jsonl  page -> asset provenance
    url-map.json
  archive/site.warc.gz # only with --warc
  manifest.json
  report.json
```

`assets.jsonl` preserves source page, source URL, final URL, kind, MIME, dimensions when known, byte size, SHA-256, status, local path and failure reason.

## Validation meanings

- `PASS` — no detected failure/completeness issue inside the bounded requested scope.
- `PARTIAL` — useful output exists but some page/asset/field/browser enhancement was incomplete.
- `BLOCKED` — access control/challenge or total failure prevented useful authorized acquisition.

Never interpret `PASS` as mathematical proof that an unbounded website has no hidden URLs. “All” can only be claimed when the corpus has an enumerable boundary and the audit supports it.
