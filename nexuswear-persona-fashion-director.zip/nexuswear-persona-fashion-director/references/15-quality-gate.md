# Quality Gate

Score 0–10 each. Total /100.

1. Intent Accuracy — solves what client actually wants.
2. Persona Credibility — wearer feels like a person, not a mannequin.
3. Silhouette + Motion — clear still and moving identity.
4. Garment Architecture — materials and construction support shape.
5. Outfit Relationships — head-to-toe logic is controlled.
6. Human Direction — action/expression reveal rather than hide design.
7. Image Direction — scene/camera/light serve the deliverable.
8. Originality — works without protected identity or near-copy dependence.
9. Commercial/Production Logic — appropriate realism for requested use.
10. Consistency — identity survives body translation, angle and series.

## Verdict
- PASS: 90–100 and no dimension below 8
- REWORK: 78–89 or any 6–7
- FAIL: below 78 or any dimension <=5

## Cause-first repair
Repair the lowest causal layer, not wording.
- weak intent → reconstruct brief
- weak persona → change role/scene/social audience
- weak silhouette → change proportion before details
- weak outfit → reassign item roles
- weak movement → redesign Action Geometry
- weak originality → rebuild motif/proportion/material/construction dependency
- weak consistency → repair ledger invariants

## Final challenge
Ask: “Could I remove the brand name, trend label and scene caption and still recognize who this person is supposed to be?” If no, do not PASS.
