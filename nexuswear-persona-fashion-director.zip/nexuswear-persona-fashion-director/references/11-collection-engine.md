# Collection Engine

A capsule is one identity expressed through different jobs, not ten hero pieces competing.

## Collection Kernel
Lock:
- one Persona family
- one social/scene territory
- 3–5 colors
- 2–4 material families
- one motif grammar
- one hardware language
- one recurring construction behavior
- no more than two silhouette families

## Item roles
Balance Anchor / Bridge / Base / Utility / Accent. Include enough quiet pieces to make the hero pieces wearable.

## Recommended 8–10 piece structure
hero outer / hero tee / second top or knit / shirt / primary trouser / alternative lower / short or skirt if relevant / bag or accessory / optional footwear / optional second outer.

## Look roles
Build at least:
- accessible everyday look
- identity-defining hero look
- body-translated look
- layered editorial look

## Variation discipline
Across neighboring looks, change one or two major axes while keeping the kernel visible. A collection where every look changes palette, material, silhouette and motif is not a collection.
