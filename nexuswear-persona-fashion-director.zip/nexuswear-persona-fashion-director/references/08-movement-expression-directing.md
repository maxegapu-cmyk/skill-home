# Movement + Expression Directing

The wearer is directed like an actor. Pose is not decoration; it is evidence of personality and garment behavior.

## Action Geometry
Define:
- support leg / free leg
- torso angle
- shoulder rotation
- arm destination
- hand task
- head direction
- gaze target
- motion phase: before / during / after action
- which garment feature the action reveals

## Action library by purpose
- reveal fit: walking mid-step, mild weight shift, seated edge, hands relaxed near pocket
- reveal back: shoulder turn, bag adjustment with clear back plane
- reveal sleeve/cuff: hand lifting headphones, cuff pull, phone check
- street energy: stepping off curb, board carry, jacket swing, quick glance across traffic
- quiet attitude: leaning lightly, one hand occupied, gaze outside frame
- playful: interrupted laugh, small hop, shared interaction, not generic peace-sign posing

## Movement Signature
Choose one recurring physical quality: compact, loose, springy, precise, heavy, drifting, restless, controlled. This quality should agree with silhouette and scene.

## Expression
Build from social intention:
`confidence level + warmth + attention target + mouth state + eye energy`.
Avoid default “cool serious face.”

## Occlusion gate
Reject any action that hides the hero graphic, collapses the silhouette, covers footwear when footwear matters, or turns the body away from the client-facing feature.
