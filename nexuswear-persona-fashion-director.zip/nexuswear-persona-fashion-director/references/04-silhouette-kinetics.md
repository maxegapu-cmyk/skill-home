# Silhouette Kinetics

Design silhouette and movement together. A garment has two identities: still shape and moving shape.

## Static geometry
Lock:
- shoulder extent
- torso width
- garment length
- waist position/definition
- rise/crotch impression
- lower-body volume
- hem opening
- exposure ratio
- footwear mass

Use relationships, not empty adjectives. Example: tee ends around high hip; sleeve approaches elbow; trouser volume visually balances a compact upper; shoe mass anchors the lower third.

## Kinetic geometry
For the chosen Movement Signature, predict:
- where fabric folds
- which hem lifts or swings
- whether a graphic bends
- whether a bag crosses the hero area
- whether hair hides neckline/back print
- whether wide trousers collapse or balloon

## Action-compatible silhouette
A skate/rest pose needs knee and hip freedom. A compact nightlife look can tolerate tighter geometry. A commuting look needs seated and walking behavior. A product look needs shape stability.

## Three-second test
Mentally reduce the person to a dark thumbnail. If identity disappears before graphics and accessories are visible, silhouette needs redesign.
