# Persona + Scene Model

## Persona Lock
Build the wearer as a role, not a mannequin.

- age band and clearly adult status when required
- gender target: male / female / unisex / open
- body/fit needs known from brief
- cultural literacy: mainstream / enthusiast / subculture-native
- social role: student, creator, rider, skater, club-goer, designer, traveler, performer, etc.
- confidence style: quiet / playful / confrontational / detached / warm / precise
- body energy: loose / compact / elastic / heavy / brisk / languid
- grooming intensity: raw / casual / polished / theatrical
- **Movement Signature**: the recurring way this persona occupies space

## Scene Pressure
A scene is not background decoration. It creates constraints and behavior.
Record:
- location type
- time/weather
- physical task
- crowd/social distance
- surfaces the wearer touches
- required mobility
- lighting source
- camera purpose

## Persona-to-clothing rule
Translate personality into visible mechanics rather than labels.
“冷淡” can become restrained palette, low graphic density, controlled drape, reduced jewelry and minimal facial performance. It does not automatically mean all-black.

## Credibility test
Ask: if the logo and trend labels disappeared, would this still look like the same person in the same life? If no, the persona is under-built.
