# Garment Identity Ledger

Use this whenever one garment must survive multiple views, repeated prompts or a series of images.

## Principle
Define the garment once as a persistent identity record. Each image is a **visibility projection** of that identity under a viewpoint; a new angle does not authorize new design decisions.

## Ledger fields
- garment class
- body silhouette and length
- material + surface
- base color
- collar/neck geometry
- sleeve geometry
- closure map
- seam map
- pocket map
- graphic/artwork map
- hem geometry
- hardware map
- wash/distress map
- front-only facts
- side-visible facts
- back-only facts
- invariants that must never change

## Visibility projection
For a requested angle:
1. expose only ledger facts visible from that angle;
2. preserve all invariants;
3. where a hidden fact cannot be inferred safely, leave it unspecified rather than inventing detail;
4. preserve the same display body, scale, baseline, background and light when comparison consistency matters.

## Drift check
Reject a view if pocket count, seam location, garment length, sleeve volume, graphic scale/placement, hem geometry, color or material behavior changes without an explicit redesign instruction.

## Boundary
This ledger supports visual consistency. It is not a factory specification; factory execution additionally requires measurements, BOM, operation details, artwork files, graded sizing and tolerances.
