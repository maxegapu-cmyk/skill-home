# Image Direction

Choose image language from the deliverable, not from habit.

## Product clarity
Neutral background, readable construction, restrained perspective, truthful material color, minimal occlusion. Camera serves the garment.

## Lookbook clarity
Full body, complete footwear, simple stance or small weight shift, consistent scale, low visual noise, enough depth to read proportions.

## Editorial energy
Scene must causally belong to Persona Lock. Use environmental interaction, lived-in action and motivated light. Clothing remains readable even when the image feels spontaneous.

## Camera decisions
State:
- focal-length family
- camera height
- distance
- full/three-quarter/close framing
- perspective intent
- body visibility requirements
- which garment plane must face camera

## Lens logic
- 28–35mm: spatial energy, youth/street, higher distortion risk
- 35–50mm: natural full-body balance
- 70–85mm: compressed catalog/portrait cleanliness

## Light causality
Name the actual source and direction: overcast sky, storefront spill, hard noon sun, train-car fluorescent, window bounce, studio softbox, etc. Then explain which materials catch or absorb it.
