# Body Translation

Gender is not a style preset. Translate the same identity system to a specific body and fit intent.

## Preserve across translations
- Identity Outcome
- core palette
- material family
- motif grammar
- Anchor role
- main construction idea
- scene and social intention

## Adjust only when needed
- shoulder balance
- chest/bust accommodation
- torso length
- waist position
- hip ease
- rise
- lower-body geometry
- exposure
- shoe mass
- size adjustability

## Male / female / unisex
Do not automatically make male versions darker, larger or harder. Do not automatically crop, tighten, brighten or add heels to female versions. Unisex should survive body variation through geometry and adjustability rather than by simply making everything oversized.

## Translation gate
Put variants side by side mentally. If they look like different brands, the translation drifted into redesign.
