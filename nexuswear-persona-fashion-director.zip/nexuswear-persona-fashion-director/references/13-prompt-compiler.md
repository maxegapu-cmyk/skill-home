# Prompt Compiler

Compile decisions; do not brainstorm inside the final prompt.

## Prompt order
1. deliverable + aspect ratio/presentation
2. wearer identity / Persona Lock
3. head-to-toe garment facts
4. fit + material behavior
5. Action Geometry + expression + gaze
6. environment + interaction
7. composition + camera
8. lighting causality
9. material/skin realism
10. high-risk fidelity anchors
11. negative constraints

## Product prompt
No unnecessary persona performance. Prioritize garment plane, construction, surface, color and graphic placement.

## Lookbook prompt
Full body with complete footwear; restrained action; clean background; true proportion; minimal occlusion.

## Editorial prompt
Use lived behavior and environmental causality without sacrificing garment readability.

## Fidelity anchors
Repeat only facts with high drift cost: garment length, base color, hero graphic location, key seam/pocket count, footwear visibility, body orientation. Do not repeat every adjective.

## Exact typography
If exact text is a purchase-critical feature, output a text-safe visual prompt plus post-typesetting instructions instead of pretending the image model will render perfect copy.
