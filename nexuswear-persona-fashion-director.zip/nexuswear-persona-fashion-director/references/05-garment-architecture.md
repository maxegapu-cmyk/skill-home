# Garment Architecture

Each item is a designed object with a job in the outfit.

## Garment Card
- category
- role: Anchor / Frame / Bridge / Utility / Accent / Base
- fit and length
- material family and hand
- surface/finish
- seam map
- collar/neckline/cuff/hem
- closure
- pocket logic
- hardware
- color
- wash/distress
- movement behavior
- construction risk

## Material causality
Material must explain shape. Heavy jersey can hold a box; light jersey drapes and twists. Raw denim preserves geometry; washed denim collapses softer. Shell fabrics give specular folds; wool diffuses edges. If the concept requires unnatural behavior, explain the structure that causes it: bonding, padding, interfacing, layered panels, elastic, drawcord, etc.

## Detail hierarchy
For a hero item use:
- 1 dominant structural move
- 1 supporting construction move
- 0–2 micro details
A garment with every seam, pocket and edge screaming is unresolved.

## Wear test
Check standing, walking, sitting and the primary action. A concept that only works in one frozen pose is an image trick, not robust apparel design.
