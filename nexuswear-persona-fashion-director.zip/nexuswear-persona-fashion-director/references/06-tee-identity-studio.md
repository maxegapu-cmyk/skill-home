# Tee Identity Studio

A T-shirt is not “a blank plus a cool print.” It is a body, surface, symbol system and behavior.

## 1. Tee Body
Define:
- gender intent/body translation
- shoulder geometry
- chest ease
- body length
- sleeve length + opening
- neck rib width/height
- hem behavior
- jersey hand/visual weight
- base color + wash

## 2. Graphic Meaning
Write a **graphic sentence**: what should the viewer understand from two meters away?
Choose one dominant grammar:
- typography
- original emblem/symbol
- illustration
- photographic/collage
- diagram/data language
- sport/number language
- hand mark
- abstract texture

## 3. Graphic Map
Specify front/back/neck/sleeve relationships:
- placement relative to garment landmarks
- scale relative to chest/back area
- asymmetry or centering
- negative space
- hero / secondary / micro hierarchy
- whether the back echoes, answers or stays silent

## 4. Surface Method
Choose a plausible behavior: screen print, water-based, discharge, puff, flock, reflective transfer, embroidery, applique or complex digital print. The method must support the intended tactile/visual result.

## 5. Exact Text Safety
If exact wording matters, create a composition-safe graphic version plus explicit typesetting layout instructions. Do not rely on an image model to spell critical copy correctly.

## 6. Worn Proof
Before accepting the tee, place it on the Persona Lock and verify the chosen action does not fold, cover or crop the hero information beyond recognition.

## Tee delivery
`identity sentence → body → surface → graphic map → technique → micro construction → complete outfit → human direction → product prompt → worn prompt → gate`.
