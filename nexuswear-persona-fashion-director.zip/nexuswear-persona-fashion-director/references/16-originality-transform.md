# Originality Transform

Reference material can define a target territory; it must not become the finished identity.

## Extract, then detach
Extract only abstract attributes:
- silhouette logic
- proportion
- material behavior
- color relationship
- graphic density
- construction intensity
- styling tension
- image energy

Then detach from recognisable identity by rebuilding through the Client Intent and Persona Lock.

## Independent rebuild
Change at least three high-impact axes when a reference is visually distinctive:
- silhouette family
- material family
- construction language
- motif grammar
- color structure
- styling relationship
- scene/movement language

Changing only color or swapping a logo is not transformation.

## Protected identity gate
Do not reproduce protected logos, signature repeating patterns, character artwork, distinctive branded graphics or a near-identical overall arrangement unless rights are provided.

## Similarity sanity check
Describe the result without naming the reference. If the description still collapses to “that exact branded piece but altered,” redesign again.
