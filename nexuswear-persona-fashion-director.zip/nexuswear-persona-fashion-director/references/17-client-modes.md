# Client Modes

Choose the mode from the requested outcome.

## Personal Style
Priority: identity, comfort, repeat wear, scene fit. Avoid fragile microtrends.

## Social Content
Priority: three-second silhouette, recognisable hero idea, movement, camera readability. Permit more current signals.

## Merch / T-Shirt Drop
Priority: graphic thesis, blank-body quality, print behavior, brand independence, front/back logic and production plausibility.

## Fashion Editorial
Priority: identity tension, proportion, movement, image energy. Still preserve garment readability.

## Commercial Capsule
Priority: shared collection kernel, item roles, production realism, multiple entry-price looks and controlled novelty.

## Character / IP Styling
Priority: visual storytelling and identity continuity across scenes. Clothing must support character behavior rather than act as detached fashion decoration.

## Existing Garment Revision
First mark immutable facts and editable zones. Preserve the former; redesign only the latter.
