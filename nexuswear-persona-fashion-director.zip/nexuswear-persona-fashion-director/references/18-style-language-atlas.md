# Style Language Atlas

Use a style family as a coordinate system, never as a costume recipe. The Persona Lock decides which parts are allowed to survive.

| Language | Typical mechanics | Common failure | Useful tension |
|---|---|---|---|
| Street / Hype | graphic hierarchy, relaxed volume, sneaker mass | logo dependence, random oversized pieces | tailoring, prep |
| Cityboy | practical soft layers, relaxed trousers, modest graphics | generic “Japanese” costume shorthand | tech, skate |
| Clean Youth | controlled palette, proportion-led basics, polished casual | bland influencer uniform | archive, sport |
| Tech / Utility | shell surfaces, ergonomic seams, modular function | fake straps and cyberpunk clutter | formal, romantic |
| Gorpcore / Outdoor | trail function, tactile layers, weather logic | hiking cosplay in urban scene | minimal, prep |
| Workwear | canvas/denim, durability, pocket logic | costume-worker stiffness | sheer, tailoring |
| Skate | movement room, boxy jersey, worn surface | lazy giant tee + giant pants formula | prep, formal |
| Neo-Y2K | compact/elongated proportion shifts, synthetic shine, nostalgia | cheap retro prop stacking | utility, minimal |
| Sport Archive | jersey codes, piping, track shapes, athletic typography | team-uniform imitation | tailoring, western |
| Neo-Preppy | shirt/knit structure, collegiate restraint | school-uniform costume | punk, skate |
| Dark Archive | elongated or controlled geometry, worn dark surface, seam focus | all-black = “archive” shortcut | athletic, clean |
| Contemporary Minimal | material, fit and finish do the work | expensive-looking but anonymous basics | western, utility |
| Americana / Western | denim, checks, leather, boot/waist relationships | cowboy costume | technical, sport |
| Fluid Tailoring | suiting language separated from rigid gender coding | shapeless “unisex” suit | street, sport |
| Moto / Racing | panel rhythm, protective cues, speed graphics | flames/checkers pasted everywhere | prep, minimal |
| Club / Night | compact silhouette, light-reactive surfaces, body rhythm | generic shiny black outfit | workwear, tailoring |
| Soft Rebellion | clean base + one damaged/off-center signal | fake punk accessorizing | prep, romantic |
| Art-School Eclectic | unexpected layering, authored color, odd proportion | five unrelated aesthetics at once | minimal anchor |

## Mixing rule
Select one dominant language, optionally one tension language, then translate them through the persona. Do not “average” two styles. Decide which layer each controls:
- dominant may control silhouette + materials;
- tension may control one item, motif or styling relation;
- current trend signals may alter proportion, color or accessory scale without replacing identity.

## Theme-first example
“Night rider, restrained, young, no cyberpunk cliché” does not mean full Techwear. Use utility only where the scene needs weather/movement logic; let the rest come from compact street geometry, reflective road-marking motif and controlled accessories.
