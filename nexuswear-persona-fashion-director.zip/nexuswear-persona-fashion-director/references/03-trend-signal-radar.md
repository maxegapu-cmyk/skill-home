# Trend Signal Radar

Trend is a timing choice, not a shopping list.

## Three signal bands
- **Foundation** — durable apparel languages that can survive years: jersey, denim, tailoring, workwear, sport, skate, outdoor, military, prep, western, minimal, punk, utility.
- **Now** — current shifts in proportion, color, material, styling conflict, accessory scale, footwear, waist/rise, graphic density.
- **Edge** — fast-moving micro-signals with high novelty and short shelf life.

## Position presets
- Personal daily wear: Foundation dominant, light Now.
- Commercial youth line: Foundation + Now balanced.
- Editorial/viral content: Now dominant with limited Edge.
- Experimental concept: Edge may rise, but function and persona must remain legible.

## Signal extraction
When current information is available, capture attributes only:
`signal / band / visual effect / target audience fit / shelf-life risk / replacement path`.

## Rejection rules
Reject a trend signal when it:
- needs a famous brand mark to make sense;
- contradicts scene or wearer movement;
- makes the wearer look dressed by an algorithm rather than by intention;
- dates the whole concept without business value;
- competes with the primary identity idea.
