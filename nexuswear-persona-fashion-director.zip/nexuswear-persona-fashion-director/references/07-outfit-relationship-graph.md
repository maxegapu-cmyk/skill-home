# Outfit Relationship Graph

A complete look is a network. Every item has a role and a relationship to the hero idea.

## Roles
- **Anchor** — the identity-defining item or idea.
- **Frame** — shapes the Anchor by controlling proportion around it.
- **Bridge** — connects two visual worlds, e.g. sporty tee to tailored trouser.
- **Utility** — solves the scene: bag, shell, hat, functional layer.
- **Accent** — small controlled contrast.
- **Base** — intentionally quiet support.

## Required nodes
upper / lower / optional layer / footwear / socks or legwear / bag / headwear / jewelry or hardware / hair / grooming.
Not every node needs a visible item; “none” can be an intentional choice.

## Relationship edges
For each visible node define one relationship to another:
- repeats color
- balances mass
- continues material
- creates tension
- reveals subculture
- solves function
- clears visual space

## Conflict budget
Use one major tension only. Example: neat prep upper × damaged skate lower. Small details may echo that tension, but do not introduce a third unrelated world.

## Removal test
Remove each accessory mentally. If removing it improves the look and loses no function or identity, leave it out.

## Head-to-toe test
The eye should travel through the look without hitting an unexplained item. Shoes are never an afterthought: they control the final mass and often decide whether the look reads youthful, technical, refined or costume-like.
