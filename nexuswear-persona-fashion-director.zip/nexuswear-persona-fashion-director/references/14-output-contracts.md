# Output Contracts

## A. Single T-Shirt
Verdict → Client Intent → Persona Lock → tee identity sentence → body spec → graphic map → surface/print method → micro construction → complete outfit → Movement Signature + Action Geometry → image direction → PRODUCT PROMPT → WORN PROMPT → gate.

## B. Complete Look
Verdict → Intent → Persona → silhouette/kinetics → Outfit Relationship Graph → item specs → human direction → image direction → FINAL PROMPT → gate.

## C. Multi-view Garment
Garment Identity Ledger → angle visibility projections → presentation lock → prompts by angle → drift gate.

## D. Capsule
Collection Kernel → item roles → item specs → look roles → body translations → hero prompt set → collection gate.

## E. Reference-led Design
Intent → Persona → abstract attribute extraction → recognisability break → independent rebuild → complete look → originality gate → prompt.

## F. Fast Mode
When the user wants speed, output only:
`Intent sentence → Persona Lock → design spec → complete styling → Action Geometry → FINAL PROMPT → verdict`.
Keep internal checks; shorten narration, not reasoning.
