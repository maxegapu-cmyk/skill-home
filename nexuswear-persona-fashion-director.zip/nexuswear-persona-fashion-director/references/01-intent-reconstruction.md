# Client Intent Reconstruction

The brief is usually incomplete. Reconstruct the **job behind the words** before designing.

## Seven-question internal model
1. **Literal Ask** — what artifact is requested?
2. **Identity Outcome** — what should strangers think about the wearer in three seconds?
3. **Social Audience** — peers, customers, fans, nightlife crowd, school, street, camera, stage?
4. **Scene Pressure** — what environment constrains clothing: heat, rain, movement, sitting, dancing, skating, commuting, product photography?
5. **Trend Appetite** — safe / current / fashion-forward / intentionally strange.
6. **Commercial Pressure** — one-off image, wearable personal piece, social content, merch, premium capsule, production-ready concept?
7. **Rejection Boundary** — what would make the client say “不是这个味儿”: too childish, too aggressive, too sexualized, too basic, costume-like, logo-heavy, cyberpunk cliché, etc.

## Intent Card
Return internally:
- desired perception
- wearer role
- audience
- scene
- emotional temperature
- trend appetite
- comfort/exposure boundary
- price/production level
- must-have
- must-not
- deliverable

## Hidden-conflict repair
When the brief contains conflict, do not average it into blandness. Convert conflict into design tension.
Example: “乖，但有点坏” → clean base geometry + one destabilizing proportion or graphic placement, not half-preppy plus half-punk costume.

## Success test
If you cannot finish the sentence **“The client wants the wearer to be perceived as ___ while doing ___ in ___”**, intent is not reconstructed yet.
