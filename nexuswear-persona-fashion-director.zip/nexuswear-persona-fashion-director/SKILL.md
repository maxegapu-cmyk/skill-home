---
name: nexuswear-persona-fashion-director
description: Use when a user wants original trend-aware clothing, T-shirts, complete character styling, fashion looks, apparel concepts, capsule collections, lookbook/editorial prompts, or consistent garment presentation for male, female, or unisex wearers.
---

# NEXUSWEAR — Persona Fashion Director v2.0

## Mission
Design **the person-in-context first, then the clothes that make that person believable**. The target is not “fashionable items”; it is a coherent identity outcome carried by silhouette, garments, styling, movement, expression, environment and image direction.

## Runtime
1. **Client Intent Reconstruction** — recover what the client literally asks for, what they want the wearer to communicate, who will see it, where it appears, trend appetite, commercial pressure, comfort limits and forbidden clichés. Read `references/01-intent-reconstruction.md`.
2. **Persona Lock** — define wearer role, age band, body/fit needs, Social Audience, Scene Pressure, emotional temperature and Identity Outcome. Read `references/02-persona-scene-model.md`.
3. **Trend Position** — choose whether the job needs durable, current or edge signals; use trends as adjustable evidence, never as the identity itself. Read `references/03-trend-signal-radar.md` and `references/18-style-language-atlas.md`.
4. **Silhouette + Motion** — design the body outline together with Movement Signature. Read `references/04-silhouette-kinetics.md`.
5. **Garment Architecture** — build each item from role, proportion, material behavior, construction and production reality. Read `references/05-garment-architecture.md`.
6. **Tee Identity Studio** — if a T-shirt is involved, design body, surface, motif system, placement, print behavior, back/neck logic and worn context. Read `references/06-tee-identity-studio.md`.
7. **Outfit Relationship Graph** — assign every item a job and define how top, lower, footwear, socks, bag, headwear, jewelry, hair and grooming support or tension the hero idea. Read `references/07-outfit-relationship-graph.md`.
8. **Direct the Human** — lock Action Geometry, gaze, hand behavior, posture, expression and interaction so the wearer reveals the design instead of hiding it. Read `references/08-movement-expression-directing.md`.
9. **Direct the Image** — choose scene, camera, crop, light and material rendering from the client goal. Read `references/09-image-direction.md`.
10. **Body Translation** — preserve identity across male, female and unisex bodies without stereotype. Read `references/10-body-translation.md`.
11. **Originality Transform** — when references are supplied, extract abstract attributes, break recognisable dependency, then rebuild from the Persona Lock. Read `references/16-originality-transform.md`.
12. **Compile** — output only the artifacts the client needs. Read `references/13-prompt-compiler.md` and `references/14-output-contracts.md`.
13. **Consistency Ledger** — for multiple views or repeated generations, create one Garment Identity Ledger and project visible facts per view. Read `references/12-garment-identity-ledger.md`.
14. **Judge** — run the quality gate; repair causes, not adjectives. Read `references/15-quality-gate.md`.

## Decision Priority
Client intent > persona credibility > scene/function > silhouette > material/construction > outfit relationships > movement readability > trend freshness > decorative novelty.

## Default Delivery Order
**Verdict → Client Intent → Persona Lock → Design Thesis → Silhouette/Movement → Garment Specs → Complete Look → Human Direction → Image Direction → FINAL PROMPT(S) → Quality Gate.**
