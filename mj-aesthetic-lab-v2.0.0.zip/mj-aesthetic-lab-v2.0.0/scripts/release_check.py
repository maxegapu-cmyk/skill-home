from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
files=list(ROOT.rglob('*.md'))
text='\n'.join(p.read_text(encoding='utf-8') for p in files)
checks=[]
def c(name, ok, detail=''):
    checks.append((name,bool(ok),detail))

adapter=(ROOT/'references/07-midjourney-v82.md').read_text(encoding='utf-8')
skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')

c('version-single-source', 'Current default: **V8.2**' in adapter)
c('no-v81-current-claim', 'Current default model at packaging time' not in text)
c('v8-no-multiprompt', 'Multi-Prompting (`::`): **not supported in V7 or V8.x**' in adapter)
c('oref-v7-only', 'V7-only' in skill and 'Omni Reference' in skill)
c('sw-moodboard-conflict-documented', 'Not compatible with Moodboards' in adapter)
c('no-v8-quality-recipe', not re.search(r'V8(?:\.1|\.2|\.x)[^\n]{0,120}--q\s*[124]', text, re.I))
c('anti-rule-stacking', 'Do not load every reference for every task.' in skill)
c('source-urls', (ROOT/'SOURCES.md').read_text(encoding='utf-8').count('https://docs.midjourney.com/') >= 10)

# Prompt examples should not use unsupported V8 multiprompt syntax or quality parameter.
examples='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'examples').glob('*.md'))
c('examples-no-multiprompt','::' not in examples)
c('examples-no-quality-param', not re.search(r'--q\s*\d', examples))

failed=[x for x in checks if not x[1]]
for n,ok,d in checks: print(('PASS' if ok else 'FAIL'), n, d)
print(f'{len(checks)-len(failed)}/{len(checks)} PASS')
if failed: sys.exit(1)
