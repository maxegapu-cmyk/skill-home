from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
required = [
    'SKILL.md','README.md','INSTALL.md','SOURCES.md','PROJECT-FILE-LIST.txt','VERSION',
    'references/00-runtime.md','references/01-aesthetic-diagnostic.md','references/02-prompt-compiler.md',
    'references/03-composition.md','references/04-camera-light-color.md','references/05-material-texture.md',
    'references/06-style-dna.md','references/07-midjourney-v82.md','references/08-experiment-protocol.md',
    'references/09-critique-repair.md','references/10-genre-recipes.md','references/11-casting-engine.md',
    'references/12-realism-anti-ai.md','references/13-quality-gates.md',
    'examples/portrait_upgrade.md','examples/cinematic_scifi.md','examples/style_lab.md'
]
checks=[]
def check(n,c): checks.append((n,bool(c)))
for f in required: check('file:'+f,(ROOT/f).exists())
text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
for m in ['MODE A — AESTHETIC UPGRADE','9-axis Aesthetic Scan','Three-lever rule','Prompt compiler','Style search lattice','Reference ownership','Current Midjourney adapter','Experiment engine','Aesthetic scorecard','Casting engine compatibility']:
    check('marker:'+m,m in text)
check('v82-current','Current default is **V8.2**' in text)
check('repair-limit','at most three primary variables' in text)
check('selective-loading','Do not load every reference for every task.' in text)
failed=[n for n,v in checks if not v]
for n,v in checks: print(('PASS' if v else 'FAIL'), n)
print(f'{len(checks)-len(failed)}/{len(checks)} PASS')
if failed: sys.exit(1)
