# INSTALL

Install the entire `mj-aesthetic-lab-v2.0.0` folder.
Main entry: `SKILL.md`.
No external Python dependencies.

Verification:
```bash
python scripts/selftest.py
python scripts/release_check.py
```

If the host supports Skills with selective reference loading, keep `SKILL.md` as the only public entry and let it route to `references/`.
