# Realism / Anti-AI System

## Realism is variation with causality
A real-looking image has different behaviors in different regions/materials.

### Human skin
- local tone variation;
- different highlight behavior on forehead/nose/cheek/lip;
- believable under-eye structure;
- visible-but-refined microtexture;
- peach fuzz or facial hair when scale supports it;
- nonuniform lip texture;
- controlled asymmetry.

### Hair
- believable hairline;
- baby hairs;
- strand grouping at multiple scales;
- gravity and weight;
- accessory attachment with real contact.

### Eyes
- plausible sclera tone;
- restrained wetness/catchlights;
- no universal giant glass eyes unless stylized intentionally.

### Objects/environments
- contact shadows;
- wear where contact/friction occurs;
- dirt/moisture where environment causes it;
- material-specific edge and reflection behavior;
- imperfect repetition.

## Anti-oil / anti-plastic portrait route
Reduce:
- uniform glossy specular layer;
- over-smoothed pores;
- waxy translucent cheeks;
- identical wet highlights on every facial plane.
Increase:
- regional roughness variation;
- matte-to-satin skin response;
- fine texture with selective retouch rather than pore erasure;
- soft physically plausible highlight rolloff.
