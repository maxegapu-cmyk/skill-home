# Quality Gates

## G0 — Intent
Can a viewer understand what matters first?

## G1 — Hierarchy
There is a deliberate first/second/quiet zone.

## G2 — Composition
Masses, crop and depth serve the image rather than fill the frame randomly.

## G3 — Camera & Light
Viewpoint and light have explicit roles and do not contradict each other.

## G4 — Color
Palette has hierarchy, not equal saturation everywhere.

## G5 — Material
Hero surfaces behave plausibly or consistently stylized.

## G6 — Style coherence
One dominant visual language. No accidental style soup.

## G7 — Originality
At least one specific authored choice survives removal of generic quality words.

## G8 — Reference discipline
Each reference has a clear job; no blind stack.

## G9 — Experiment validity
If claiming an improvement, the test isolated enough variables to support that claim.

## G10 — Prompt economy
Removing empty adjectives does not harm the intended image.

## G11 — Production continuity
Winning aesthetic DNA can be reused without rediscovering from zero.
