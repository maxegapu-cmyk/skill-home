# Material & Texture Lab

## Material realism
For each hero material, define only what matters:
- base material;
- surface finish / roughness;
- microtexture scale;
- edge behavior;
- translucency/subsurface behavior when relevant;
- wear / manufacturing traces;
- interaction with light and environment.

## Examples
Metal is not just "metallic": brushed, bead-blasted, anodized, cast, oxidized, polished, scratched, oily, heat-tinted.
Fabric is not just "detailed": weave scale, nap, stiffness, drape, seam tension, pilling, embroidery depth.
Stone: grain size, pores, chips, polish, moisture, tool marks.
Glass: thickness, tint, edge refraction, smudges, condensation, internal reflection.
Skin: regional texture, sebum distribution, dry/wet differences, peach fuzz, local redness, lip and under-eye behavior.

## Luxury rule
Luxury is restraint + material confidence + proportion + craft. It is not automatically gold, gloss, marble and black backgrounds.
