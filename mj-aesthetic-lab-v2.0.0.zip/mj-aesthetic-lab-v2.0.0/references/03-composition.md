# Composition Lab

## First-eye design
Decide:
- primary focal point;
- secondary anchor;
- eye path;
- quiet area.

## Composition levers
- center vs off-center balance;
- symmetry vs controlled imbalance;
- frame-within-frame;
- leading lines;
- triangular / diagonal massing;
- foreground occlusion;
- scale contrast;
- repetition with one exception;
- negative-space pressure;
- horizon placement;
- crop tension;
- overlap and depth stacking.

## Depth grammar
For cinematic images, build at least two useful planes when appropriate:
foreground / subject plane / environmental background.
Do not add random foreground blur unless it supports viewpoint and space.

## Aspect ratio is a design choice
Portrait ratios emphasize vertical body/face and controlled negative space.
Wide ratios support lateral relationships, environment, isolation, procession, pursuit, architecture.
Square favors icon-like balance and graphic massing.

## Failure test
If the subject can move 15% left/right or the camera can zoom 20% without changing the image's meaning, composition may be under-authored.
