# Camera, Light & Color

## Camera grammar
Use focal-length *character*, not brand-name worship.
- wide: spatial exaggeration, intimacy-at-close-range, environmental presence;
- normal: balanced perspective, observational realism;
- long: compression, isolation, graphic layering.

Also specify when relevant:
- camera height;
- subject distance;
- angle;
- depth of field;
- motion behavior;
- perspective distortion or compression.

## Lighting grammar
Define a motivated source.
Consider:
- direction: frontal / side / back / top / under;
- source size: hard pinpoint ↔ broad soft;
- ratio: low contrast ↔ deep chiaroscuro;
- falloff: rapid ↔ even;
- practicals: windows, lamps, screens, fire, signage;
- atmosphere: haze, dust, rain, smoke only when causally useful;
- specular behavior by material.

## Color grammar
Build a hierarchy:
1. base neutrals / dominant family;
2. secondary support family;
3. one accent or exception.

Control:
- warm/cool separation;
- saturation by importance;
- luminance contrast;
- skin/product color integrity;
- background color pressure.

Avoid universal orange-teal, neon cyberpunk, or pastel palettes unless the brief actually calls for them.
