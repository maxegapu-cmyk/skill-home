# SOURCES / PLATFORM BASELINE

Platform facts were checked against official Midjourney documentation at packaging time (2026-08-10).

Used only for platform behavior:
- current default model: V8.1;
- Raw;
- Stylize;
- Chaos / Variety;
- Style Reference;
- V7 Omni Reference;
- V6/Niji 6 Character Reference.

The creative framework, Candidate Lattice, Selection Grid, Minimal Repair Protocol and quality gates are original system design for this package.

Because Midjourney changes over time, platform-specific adapters should be rechecked when a major version changes.
