# Example — Cinematic Sci-Fi Keyframe

## Brief
"A soldier finds a giant alien ruin. Make it epic and cinematic."

## Visual thesis
Human-scale vulnerability against impossible engineered scale.

## Structure
- foreground: wet black rock edge framing bottom-left;
- midground: lone soldier, small silhouette, back turned;
- background: vertical alien structure disappearing into cloud;
- low camera but not heroic; soldier remains tiny;
- cold overcast ambient, one warm practical from suit;
- palette: graphite, mineral blue-gray, one amber accent;
- surfaces: rain-dark basalt, matte composite armor, ancient nonhuman stone/ceramic hybrid.

## Prompt
lone adult expedition soldier discovering an impossibly tall alien ruin, soldier kept small in frame, wet basalt foreground partially occluding the lower edge, enormous vertical structure rising through low cloud in the background, low camera close to ground but with restrained perspective, cold overcast diffuse light, one weak amber suit lamp as the only warm accent, graphite and mineral blue-gray palette, rain-dark rock, matte worn composite armor, ancient ceramic-stone megastructure with subtle nonhuman joint logic, mist reacting to scale and wind, quiet awe rather than action spectacle, premium science-fiction film still --ar 21:9 --s 180 --c 12

## Test
A/B only the camera distance: intimate wide foreground vs longer compressed observation. Keep all other variables fixed.
