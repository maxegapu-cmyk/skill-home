---
name: portrait-retouch
version: 2.0.0
description: GPT/image-edit portrait retouching that makes AI or photographic portraits more attractive, alive and believable while preserving identity, age, anatomy, expression, pose, camera and scene unless the user explicitly asks otherwise.
---

# Portrait Retouch Skill v2.0.0 — Alive Realism Edition

## 0. Mission
Use an image-editing model (especially GPT-style conversational image editing) to repair and refine an EXISTING portrait.

The default target is:
**same person + same shot + fewer defects + better presentation + more believable human presence.**

This is NOT a classical face-restoration pipeline, upscaler, face-swap system, or a request to regenerate a prettier stranger.

## 1. Core Constitution
1. **Source authority:** the edit target owns identity, facial geometry, age, phenotype, body proportions, pose, expression, gaze, hairstyle, wardrobe, camera, crop and scene.
2. **Preservation before improvement:** every edit must first define what is immutable.
3. **Beauty is presentation-first:** improve attractiveness primarily through skin condition, local tone, eye clarity, hair grooming, facial light, color harmony and removal of distractions—not silent geometry redesign.
4. **Livingness is physiological, not cosmetic:** believable skin variation, moist eyes/lips, coherent specular response, fine hair behavior, natural micro-contrast and non-uniform texture matter more than flawless smoothness.
5. **Minimal sufficient intervention:** only repair defects that are visible or requested.
6. **Evidence rule:** never invent high-confidence anatomical or texture detail where the source provides no evidence.
7. **Original-source retry:** if an edit drifts identity, retry from the ORIGINAL image, not from the failed edited result.
8. **Single-target iteration:** after a failed pass, change one major cause at a time.

## 2. Default Behavior
If the user simply says "修一下 / 修人像 / 更好看 / 更真人 / 更有活人感":
- run `ALIVE_NATURAL`
- edit budget `MEDIUM`
- preserve composition and identity
- do not ask questions unless the target image is missing or the requested change is genuinely ambiguous and consequential
- produce a concise, high-signal edit directive rather than a giant prompt dump

### Modes
- `ALIVE_NATURAL` — default. Natural, attractive, believable, unretouched-looking finish.
- `BEAUTY_LIFT` — visibly better-looking but identity-safe; no silent face reshaping.
- `AI_HUMANIZE` — remove synthetic/CG/AI portrait cues while preserving the designed person.
- `EDITORIAL_REAL` — refined commercial/editorial polish with real skin and restrained cleanup.
- `LOCAL_RESCUE` — repair malformed local features or artifacts with minimal collateral change.
- `LOW_QUALITY_RESCUE` — source is compressed, blurry or damaged; recover only evidence-supported detail.

Modes may combine, e.g. `AI_HUMANIZE + BEAUTY_LIFT`.

### Edit Budget
- `LOW`: one or two local distractions only.
- `MEDIUM`: normal full portrait refinement; default.
- `HIGH`: multiple AI artifacts / difficult rescue. HIGH still does not authorize redesign.

### Independent Control Axes
Treat these as separate controls rather than one vague "quality" slider:
- `BEAUTY_GAIN`: LOW / MEDIUM / HIGH — how much presentation polish is requested. Default MEDIUM when the user asks to look better, otherwise LOW.
- `REALISM_GAIN`: LOW / MEDIUM / HIGH — how strongly to remove synthetic rendering cues. Default HIGH for visibly AI-looking portraits, otherwise MEDIUM.
- `STRUCTURE_CHANGE`: OFF by default. It becomes ON only for an explicit user-requested structural facial/body change.

A common strong default for AI portraits is: `BEAUTY_GAIN=MEDIUM + REALISM_GAIN=HIGH + STRUCTURE_CHANGE=OFF`.

## 2.1 Runtime Behavior
Determine whether the user wants EXECUTION or a PROMPT.

### DIRECT_EDIT — default when possible
Use this when:
- an actual portrait image is available as the edit target, AND
- the user asks to repair, retouch, beautify, humanize, make realistic, or otherwise change that image.

Behavior:
1. inspect the visible portrait
2. build the edit contract internally
3. compile a concise image-edit directive
4. invoke the host image-edit/generation tool on the EXISTING image
5. do not stop at giving instructions unless the user asked for instructions only

### PROMPT_ONLY
Use only when:
- the user explicitly asks for a prompt/template, or
- no executable image-edit tool is available.

### NO_TARGET
If actual editing is requested but no usable image target is present, request the portrait image. Do not pretend an edit was executed.

### Image-role rule
For multiple images, assign each one a role before editing: `EDIT_TARGET`, `IDENTITY_REFERENCE`, `STYLE_REFERENCE`, or `SUPPORT_REFERENCE`. Never silently treat a style/reference portrait as the edit target.

## 3. Stage A — Fast Visual Triage
Internally classify only what is actually present.

### A1. Source type
- real photo
- AI-generated photoreal portrait
- hybrid / edited photo
- uncertain

### A2. Defect families
- skin: transient blemish, waxiness, flat color, pore stamping, over-sharpening, patchiness
- eyes: dead/glassy look, malformed iris/lashes, unnatural sclera, incoherent catchlight
- mouth/teeth: plastic lips, broken lip edge, generic white teeth, merged teeth
- hair/facial hair: helmet clumps, fused strands, missing edge hairs, bad hairline, artificial beard texture
- anatomy/rendering: ear/neck/hand/accessory artifacts, face-to-neck mismatch
- light/color: face pasted into scene, wrong local exposure, clipped/oily highlights, muddy shadows, skin color disconnected from environment
- camera/rendering: fake depth-of-field, over-HDR, oversharpening, edge halos, synthetic micro-detail
- expression/presence: frozen facial tension or unfocused artificial gaze; only treat if clearly synthetic or requested

### A3. Do-not-fix list
Anything normal, identity-bearing or merely imperfect is NOT automatically a defect.

## 4. Stage B — Build the Edit Contract
Before the final prompt, define these internally.

### HARD LOCKS (default)
- identity / likeness
- face width-height relationship
- jaw, chin, cheekbone placement
- eye spacing, eye shape, eyelid type, iris color and gaze vector
- nose bridge/tip/nostril proportions
- lip contour and resting tension
- hairline, haircut and major hair volume
- age presentation and natural age cues
- skin tone / phenotype
- freckles, moles, scars and stable identity marks
- expression and head angle
- body proportions and pose
- wardrobe/accessories
- camera viewpoint, focal perspective, crop, depth of field
- background and scene

### ALLOWED CHANGES (default)
- temporary blemishes and distracting redness
- uneven local tone that is not identity-bearing
- malformed AI artifacts
- subtle under-eye color cleanup without erasing anatomy
- restrained shine control
- hair flyaways / broken clumps / edge halos
- local exposure and color continuity
- realistic detail recovery supported by source evidence
- subtle professional grooming/polish

### STRUCTURAL BEAUTY CHANGES
Disabled by default. Face slimming, eye enlargement, nose narrowing, lip inflation, jaw sharpening, body reshaping, age regression or ethnicity/phenotype changes require explicit user instruction.

## 5. Stage C — The Human Realism Stack
Apply only relevant layers. See `references/REALISM_STACK.md` for deeper rules.

### C1. Skin as living material
- preserve regional variation: forehead, nose, cheeks, under-eye and jaw must not become one uniform surface
- retain believable pores, fine texture, peach fuzz where visible, tiny tonal variation and natural creases
- preserve subtle translucency and vascular warmth where already plausible
- specular highlights must follow the scene light and skin condition, not become a uniform glossy mask
- remove temporary distractions selectively; never chase "flawless"

### C2. Eyes as wet optical surfaces
- preserve shape, gaze and iris identity
- keep sclera naturally off-white with subtle variation
- keep coherent catchlights tied to existing lighting
- restore natural corneal moisture and iris depth only if the source looks glassy/flat
- no doll eyes, oversized pupils, artificial sparkle or extra catchlights

### C3. Lips / teeth
- preserve lip geometry and color family
- keep fine lip texture and restrained moisture response
- teeth remain individualized and warm off-white, never a single porcelain block

### C4. Hair / brows / beard
- preserve growth direction and density
- break up synthetic clumps with source-consistent strand hierarchy
- retain fine edge hairs and a believable hairline
- avoid hyper-detailed "wire hair"

### C5. Face-to-scene integration
- skin, hair, eyes and clothing must share the same light direction, color contamination, contrast range and depth cues as the scene
- fix "face pasted on" feeling locally; do not invent a new lighting setup unless requested

### C6. Camera credibility
- preserve source lens perspective and depth-of-field
- avoid crispy digital edges, HDR halos and uniform high-frequency detail
- do not add film grain or sensor artifacts unless consistent with the source/look

## 6. Stage D — Beauty Lift Without Identity Drift
When the user asks for "更好看" use this order:
1. remove temporary distractions
2. rebalance local skin tone while preserving skin tone identity
3. improve under-eye presentation without deleting eye-bag anatomy
4. improve natural eye clarity and catchlight coherence
5. clean lip edge/color continuity; preserve volume
6. groom brows/hair/facial hair without redesign
7. improve facial light separation and healthy color relationship
8. reduce background distractions only if they directly weaken the portrait and the user allows it
9. stop before geometry redesign

Beauty goal: **healthier, cleaner, more present, more photogenic** — not "different facial template".

## 7. Stage E — AI Humanization
Use for AI-generated or obviously synthetic portraits.

Target the CAUSES of synthetic appearance:
- overly perfect bilateral symmetry
- repeated/uniform pore texture
- wax/plastic surface response
- globally smooth skin with locally over-sharp eyelashes/hair
- generic glass eyes or impossible catchlights
- over-white sclera/teeth
- helmet hair / strand noise
- perfect makeup edges with no material transition
- face and neck having different rendering logic
- high-clarity skin sitting on a soft lens/background
- excessive "cinematic" glow, bloom or HDR microcontrast
- accessory/ear/hair intersections that look generated

Do NOT "humanize" by randomly adding scars, acne, wrinkles, asymmetry, red eyes or dirt. Human realism comes from coherent material and optical behavior, not forced ugliness.

## 8. Scenario Adapters
Load only the relevant adapter. Full matrix: `references/SCENARIO_MATRIX.md`.

- **close-up beauty:** highest sensitivity to skin frequency, eyes, lip texture, hairline; lowest tolerance for invented pores
- **selfie / phone photo:** preserve casual lens perspective, local phone sharpening and ordinary light; do not turn it into studio photography unless asked
- **studio portrait:** preserve controlled light and makeup; add realism through texture, not random imperfections
- **male portrait:** do not feminize face or erase beard/skin character unless requested
- **elderly portrait:** preserve age structure, wrinkles and sun texture; remove only transient distractions
- **dark / deep skin tones:** preserve hue and luminance relationships; never "beautify" by whitening or flattening tonal depth
- **glasses:** preserve frame geometry; reflections must match scene light; do not erase eyes or invent impossible reflections
- **profile / three-quarter view:** never frontalize or normalize asymmetry
- **group portrait:** lock each face independently; no averaging, face swapping or cross-person feature leakage
- **full body:** face edits must not silently alter body, hands, pose or clothing
- **minor / child:** conservative cleanup only; preserve age; no adultification or sexualized beautification
- **low-resolution source:** recover broad believable structure first; do not hallucinate microtexture as fact

## 9. Prompt Compiler — GPT/Image Edit
Build the final directive from only relevant clauses.

### Required order
1. **Action** — what to improve
2. **Hard invariants** — what must remain identical
3. **Visible repair targets** — only diagnosed problems
4. **Living realism cues** — only the 2–5 most relevant
5. **Beauty/polish level** — if requested
6. **Lighting/camera continuity**
7. **Avoid / failure guards**
8. **Success condition**

### Prompt density rule
- Prefer 120–260 words for a normal edit.
- Do not paste the entire Skill into the image prompt.
- Avoid redundant synonyms such as "ultra realistic, hyper realistic, 8K, masterpiece" when they do not encode a concrete correction.
- Avoid conflicting directives such as "preserve expression exactly" + "give a bigger smile" unless the user explicitly requests the expression change.

### Default compiled directive
Use as a base, then REMOVE clauses that do not apply:

> Edit this existing portrait, not as a redesign. Keep the same person and same shot. Preserve identity, facial proportions, eye shape/spacing and gaze, nose, lips, jaw, hairline, age, skin tone, expression, pose, wardrobe, camera perspective, crop and background. Improve only visible defects and presentation: selectively clean temporary blemishes/artifacts, rebalance local skin tone, and refine malformed hair/eye/lip details where needed. Make the face feel more alive and genuinely photographed through natural regional skin texture, subtle tonal variation, believable skin highlights, moist but not glossy eyes/lips, coherent catchlights and source-consistent fine hair. Keep pores and fine texture irregular and restrained; do not create poreless, waxy, plastic, over-sharpened or "perfect" skin. Keep sclera and teeth naturally off-white. Match all face edits to the existing light direction, color spill, depth of field and lens rendering. The result should look more attractive, healthy and present, but unmistakably the same person—like excellent invisible retouching on a real photograph, not a regenerated beauty-filter face.

## 10. Quick Mode Compiler
When speed matters, output ONE direct image-edit instruction using this formula:

`KEEP SAME PERSON/SHOT -> FIX [top 2-4 defects] -> HUMANIZE [top 2-3 realism causes] -> BEAUTY [presentation only] -> MATCH ORIGINAL LIGHT/CAMERA -> BAN [top failures]`

Do not expose the triage unless the user asks for diagnosis.

## 11. Negative Guard Library
Select only relevant guards:
- no identity drift
- no face replacement
- no face slimming or symmetry normalization
- no larger eyes / narrower nose / inflated lips / sharper jaw unless requested
- no age regression
- no skin whitening or phenotype change
- no poreless/porcelain/wax/plastic skin
- no repeated pore pattern or fake microtexture
- no fake eyelashes or extra catchlights
- no paper-white sclera or porcelain teeth
- no helmet hair / wire hair / redesigned hairline
- no HDR halo / bloom / excessive clarity / crunchy sharpening
- no background, wardrobe, pose, crop or lens changes unless requested
- no invented scars, freckles, acne or wrinkles merely to "look real"

## 12. Retry Logic
### If identity drifted
- return to ORIGINAL source
- reduce edit budget one level
- remove generic beauty adjectives
- repeat hard locks at start and end
- target one local defect cluster only

### If skin became plastic
- return to ORIGINAL source
- remove "flawless / smooth / perfect / porcelain"
- request regional texture variation + restrained natural specular response
- do not ask for more sharpness

### If still looks AI
Determine the dominant cause first:
- material problem -> fix skin/eye/hair response
- integration problem -> fix face-to-scene light/color/depth continuity
- geometry artifact -> local rescue only
- camera problem -> preserve/restore source lens softness and depth cues
Then retry only that family.

### If result looks older/rougher
Do NOT erase age cues. Reduce artificial microcontrast, coarse invented pores and shadow exaggeration; improve local color/light instead.

### If result is prettier but no longer the same person
Fail. Likeness outranks beauty.

## 13. Acceptance Gates
A PASS requires all applicable gates:

### G1 Identity
A close acquaintance would immediately recognize the same person; geometry/gaze/age remain stable.

### G2 Beauty
The person looks cleaner, healthier or more photogenic without obvious beautification mechanics.

### G3 Livingness
Eyes, skin, lips, hair and facial light behave like one living photographed subject rather than separate generated materials.

### G4 Realism
No plastic skin, generic beauty-face, fake microtexture, impossible highlights, HDR edge halos or synthetic oversharpening.

### G5 Continuity
Camera, depth-of-field, scene lighting, wardrobe, background and pose remain consistent unless explicitly changed.

### G6 Restraint
No visible evidence that unaffected areas were unnecessarily regenerated.

If any critical gate fails, retry from ORIGINAL with a smaller, more local instruction.

## 14. Execution Rules
- Existing portrait + user asks to change it = EDIT, not new generation.
- Treat every input image role explicitly: edit target, identity reference, style reference, or supporting reference.
- If a second identity reference is supplied, use it only to resolve identity evidence; do not import its lighting, pose, makeup or scene unless asked.
- Whole-image edit: put hard invariants near the beginning and restate the most important one in the success condition.
- Local/mask edit when available: prefer it for a truly local artifact.
- For iterative edits, repeat invariants every pass.
- Never chain repeated beauty passes on the last output by default; identity drift compounds.

## 15. What This Skill Must NOT Do
- route the task into GFPGAN/CodeFormer/restoration-model workflows unless the user explicitly asks for those tools
- claim pixel-perfect identity preservation is guaranteed
- invent measurements or visual facts not inspected from the source
- treat normal human variation as defects
- equate "real" with dirty, old, freckled, scarred or asymmetrical
- equate "beautiful" with paler skin, smaller face, larger eyes or younger age
