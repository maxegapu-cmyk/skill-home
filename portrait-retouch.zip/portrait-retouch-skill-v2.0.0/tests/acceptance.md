# Acceptance / Adversarial Test Matrix

A release candidate should answer these scenarios without violating the expected invariants.

1. "帮我修漂亮一点" on AI close-up -> BEAUTY_LIFT + identity lock; no face reshape.
2. "更有活人感" -> diagnose synthetic cues; no random freckles/scars/acne.
3. "皮肤太假" -> plastic-skin local rescue; no global redesign.
4. "眼睛像玻璃珠" -> eye-only rescue; gaze unchanged.
5. "毛发像钢丝" -> hair hierarchy; hairline unchanged.
6. "脸太白跟脖子不是一个人" -> face-to-scene color/light integration, not skin whitening.
7. deep skin portrait -> preserve tone; no brightening-as-beauty.
8. elderly portrait -> no de-aging.
9. heavy makeup portrait -> preserve makeup design.
10. side profile -> no frontalization.
11. selfie -> no unrequested studio conversion.
12. low-resolution portrait -> no invented microtexture.
13. group photo -> per-person locks.
14. full-body -> face edit does not alter hands/body/clothing.
15. glasses -> preserve frames and coherent reflections.
16. user requests face slimming explicitly -> allowed only because explicit; other identity anchors stay locked.
17. failed beauty output loses likeness -> retry from ORIGINAL.
18. failed skin output becomes rough/old -> reduce invented microdetail; preserve age.
19. user provides identity reference + edit target -> reference resolves identity only unless roles say otherwise.
20. user gives no target image but asks to execute an edit -> request/identify image target rather than pretending execution occurred.

## Package-level criteria
- Main Skill clearly states image-edit/GPT-style use case.
- Traditional restoration model route is explicitly excluded by default.
- Beauty and humanization are separate concerns.
- "Alive" is decomposed into material/light/optical causes.
- Prompt compiler has a concise fast path.
- Retry strategy prevents cumulative identity drift.
- Coverage includes gender/age/skin-tone/camera/group/low-res edge cases.
