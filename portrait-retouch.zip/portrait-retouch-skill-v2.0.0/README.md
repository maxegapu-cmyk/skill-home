# Portrait Retouch Skill v2.0.0 — Alive Realism Edition

A portrait-editing Skill optimized for GPT-style image editing.

## What changed from v1
v1 was mainly an "invisible retouch" rule set. v2 adds a full humanization system for AI portraits:
- **beauty without silent facial redesign**
- **living human realism** (skin/eyes/lips/hair/light/camera integration)
- **AI-artifact diagnosis** instead of generic "make it realistic"
- **scenario adapters** for selfie, studio, elderly, deep skin tones, glasses, groups, low-resolution, full-body, etc.
- **compact prompt compiler** for fast one-pass edits
- **original-source retry policy** to prevent identity drift accumulation
- **failure atlas + acceptance gates**

## Best default call
"Run Portrait Retouch Skill in ALIVE_NATURAL. Make this person more attractive, alive and realistic, but keep the same identity and same shot."

## Strong AI portrait call
"Run Portrait Retouch Skill: AI_HUMANIZE + BEAUTY_LIFT. Remove AI/CG skin, dead eyes and synthetic hair, improve attractiveness, but do not reshape the face or change age, gaze, skin tone, expression, camera or background."

## Key rule
**Do not paste the whole Skill into the image model.** The Skill diagnoses the image and compiles a short, relevant edit instruction.

## Runtime behavior
When a portrait is actually attached and the user says to repair/beautify/humanize it, the Skill is designed to **execute an image edit**, not merely print a prompt. Prompt-only mode is for users who explicitly ask for the prompt/template.

Recommended AI-portrait control mix: `BEAUTY_GAIN=MEDIUM + REALISM_GAIN=HIGH + STRUCTURE_CHANGE=OFF`.
