# Scenario Matrix

| Scenario | Priority | Preserve especially | Common trap | Recommended mode |
|---|---|---|---|---|
| AI female close-up | skin/eyes/hair integration | face geometry, gaze, makeup | doll eyes, wax skin, generic beauty face | AI_HUMANIZE + BEAUTY_LIFT |
| AI male close-up | skin/beard/hair | jaw character, facial hair | accidental feminization, airbrushed beard | AI_HUMANIZE |
| Real selfie | cleanup + phone realism | lens distortion, casual light | turning into studio headshot | ALIVE_NATURAL |
| Studio beauty | high-end invisible retouch | makeup, controlled light | over-smoothing, changing face | EDITORIAL_REAL |
| Elderly person | local cleanup | wrinkles, age, skin history | de-aging or coarse fake pores | ALIVE_NATURAL |
| Deep skin tone | tone continuity | actual hue/luminance | whitening, flattening highlights | ALIVE_NATURAL |
| Heavy makeup | material realism | makeup design | removing/redesigning makeup | EDITORIAL_REAL |
| Glasses | eyes + reflections | frame geometry | deleting reflection or warping eyes | LOCAL_RESCUE |
| Side profile | local surface | profile silhouette | frontalization / symmetry correction | ALIVE_NATURAL |
| Low-light portrait | noise/light integration | shadow mood | lifting face to daylight, wax shadows | ALIVE_NATURAL |
| Backlit portrait | edge/hair/skin response | backlight direction | fake front fill / halo | ALIVE_NATURAL |
| Low-resolution source | broad forms | identity | invented pores/iris detail | LOW_QUALITY_RESCUE |
| Group portrait | per-person identity | each face separately | face averaging / swapping | LOCAL_RESCUE |
| Full-body portrait | face + body continuity | body/pose/hands/clothes | face repair silently changes body | ALIVE_NATURAL |
| Minor/child | conservative cleanup | age, anatomy | adultification / glamorization | ALIVE_NATURAL |
| Generated jewelry portrait | intersections | jewelry geometry | earrings merging with hair/ear | LOCAL_RESCUE |

## Scenario-specific prompt patches

### AI female close-up
"Preserve the exact facial design and makeup. Humanize material response, not facial proportions. Keep skin naturally varied at close range, eyes moist with coherent catchlights, hair organized into natural clusters and fine edge strands. No generic beauty-face replacement."

### Real selfie
"Keep the original phone-camera perspective, casual framing and ordinary light. Do not convert the image into a studio portrait."

### Elderly
"Preserve age, wrinkles, sun texture and facial character. Remove temporary distractions only; do not de-age or smooth away history."

### Deep skin tone
"Preserve the person's actual skin tone and tonal depth. Improve local color continuity without whitening, graying or flattening highlights/shadows."

### Low-resolution
"Restore only evidence-supported broad detail. Do not fabricate pores, iris patterns, eyelashes or fine hair beyond the source's usable information."

### Group
"Treat each person's face as a separate identity lock. Do not average features or transfer details between people."
