# Research Notes — What Was Absorbed Into v2.0

This file documents design principles, not copied repository content.

## OpenAI Codex imagegen sample skill
Useful principles adopted:
- distinguish generate vs edit
- for edits, preserve invariants aggressively
- label image roles explicitly
- use camera/composition language for photographic realism
- keep prompts structured but not blindly verbose
- repeat invariants on iterative edits
- iterate with a single targeted change

## OpenAI Cookbook image generation prompting guides
Useful direction adopted:
- describe believable images as photographs/captures with concrete camera/light/material language
- use image editing as controlled transformation rather than unconstrained re-generation

## cliprise/awesome-ai-photo-editor-prompts
Useful principles adopted:
- portrait editing should preserve identity, facial structure, expression, skin texture and natural proportions
- avoid over-editing and heavy beauty-filter behavior
- improvement prompts work better when they say what must stay unchanged and what may change

## GPT-Image2 prompt libraries / skills
Examples repeatedly emphasize:
- candid / real-camera context
- real skin texture and ordinary material detail
- no glamorization / no heavy retouching for documentary realism
- identity-preserving local portrait edits

## v2.0 synthesis
The new Skill does NOT copy a repository's prompt library. It converts the common useful ideas into a portrait-specific control system:
1. edit contract / invariants
2. beauty-without-geometry policy
3. human realism stack
4. AI-artifact cause diagnosis
5. scenario adapters
6. compact prompt compiler
7. original-source retry strategy
8. failure atlas and acceptance gates
