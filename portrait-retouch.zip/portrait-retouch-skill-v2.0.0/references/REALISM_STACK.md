# Realism Stack — Practical Cues for GPT-Style Image Editing

Use this reference to choose a SMALL number of high-value realism cues. Do not dump all cues into one edit.

## 1. Skin
### Strong cues
- regional texture differences rather than uniform texture
- tiny color/brightness variation within one skin tone
- restrained pores and fine facial texture at the source's resolution
- soft vellus hair only where visible / plausible at the shot scale
- natural creases around eyelids, nasolabial region and lips
- local specular response following existing light
- subtle subsurface warmth around thin/translucent areas only when consistent with source

### Failure cues
- identical pore size across face
- pores stronger than hair/clothing texture despite shallow depth of field
- perfectly even matte skin
- universal oily gloss
- orange/pink "healthy skin" cast painted everywhere
- frequency-detail pasted on a low-resolution face

## 2. Eyes
### Strong cues
- consistent corneal wetness
- one coherent catchlight family derived from scene lights
- off-white sclera with restrained local variation
- iris detail limited by source resolution and focus
- natural eyelid/lash contact and tear-line transitions

### Failure cues
- glowing irises
- extra catchlights
- paper-white sclera
- identical eyelashes
- hyper-sharp iris inside a soft-focus portrait

## 3. Lips / Mouth / Teeth
- keep lip ridges and local color variation
- moisture is a small specular response, not lacquer gloss
- teeth have individual geometry and warm-neutral variation
- gums/tongue should not be over-saturated

## 4. Hair / Brows / Facial Hair
- hierarchical detail: masses -> clusters -> selected strands
- natural root density and edge hairs
- believable strand crossing at silhouette
- beard/stubble follows growth direction and does not become gray noise

## 5. Physiological Color
Use only as a subtle continuity cue. Real skin is not one flat RGB patch. Preserve small regional differences already supported by the image; never force stereotyped redness.

## 6. Light Integration
Check:
- highlight direction
- shadow softness
- ambient color spill
- contrast level
- depth-of-field / blur
- edge sharpness
- exposure relationship between face and neck/body

The face should not look as if it came from a different rendering pipeline than the rest of the photograph.

## 7. Camera Credibility
Photographic realism is helped by camera-consistent language, not generic quality words. Preserve the source's apparent lens perspective, framing, focus falloff, motion sharpness and dynamic range. Do not add dramatic bokeh, film grain, lens flare, chromatic aberration or motion blur merely because they sound photographic.

## 8. "Alive" Without Identity Change
Livingness can be improved by restoring natural material behavior and facial tension while preserving the source emotion. Do not shift gaze, smile size, eye opening or head pose unless requested.

Useful wording:
- "restore natural eye moisture and focus without changing gaze"
- "retain subtle facial muscle tension and expression; do not change emotion"
- "preserve naturally uneven texture and color rather than smoothing to uniformity"
- "match face highlights and shadow softness to the existing scene"

Avoid vague instructions like "make her more alive" by themselves; they may invite expression or geometry changes.
