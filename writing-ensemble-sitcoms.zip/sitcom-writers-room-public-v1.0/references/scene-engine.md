# Scene Engine — Make It Play on Screen

## 1. Scene card before dialogue

Before writing lines, define seven items:

1. **Activity:** what are people physically doing right now?
2. **Objective:** what does each active character want before leaving?
3. **Friction:** what makes those wants incompatible?
4. **Information asymmetry:** who knows, suspects, misunderstands, or hides what?
5. **Pressure source:** deadline, witness, task, space, money, pride, rule, interruption, etc.
6. **Turn:** what becomes different by the end?
7. **Exit pressure:** what unfinished problem pushes into the next scene?

If you cannot define the turn, the scene is probably a sketch, not story.

## 2. Anti-stage-play rule

A screen scene is not improved by adding random movement. Physical behavior must alter timing, access, evidence, status, or meaning.

Useful physical behavior:
- a task occupies hands while someone is trying to lie;
- an object contains evidence or becomes leverage;
- distance prevents a private conversation;
- a customer/child/boss/neighbor changes what can be said;
- someone keeps trying to leave but practical duties pull them back;
- a noise masks a crucial line;
- a person enters at the worst **causally prepared** moment;
- one character controls a key, phone, receipt, door, queue, order, tool, or seat another needs.

Decorative blocking:
- “walks around nervously” with no consequence;
- “rolls eyes,” “crosses arms,” “looks shocked” on every exchange;
- entrances only because the writer needs a new speaker;
- constant actor instructions for obvious emotion.

## 3. Action-line standard

Action lines should be concise, observable, and selective.

Prefer:
> Lin seals the last takeout box. Jun reaches for the label before she can stick it down.

Over:
> Lin looks very nervous and carefully seals the box while Jun suspiciously watches her, wondering whether she is hiding something.

Write what an audience can perceive. Let performance emerge from behavior and dialogue.

## 4. Beat progression

A scene usually needs several pressure beats, not several topics.

A strong beat changes at least one of:
- leverage;
- knowledge;
- suspicion;
- status;
- available options;
- time remaining;
- who is present;
- ownership/control of an object or task;
- relationship temperature.

The next beat should respond to that change.

## 5. Enter late, leave on the turn

Do not warm up with greetings and logistics unless they are the joke/problem. Enter when a want is already active. Leave soon after the scene’s state change becomes clear.

Do not append a paragraph explaining what the audience just understood.

## 6. Visual discovery without over-directing

Default screenplay prose does not need shot lists. Give the camera something worth seeing:
- contradictory behavior;
- a revealing object;
- a failed concealment;
- a reaction someone else misses;
- an unfinished task accumulating cost;
- a public/private contrast.

Use explicit camera instructions only when the information cannot be understood otherwise.

## 7. Scene rewrite questions

- If dialogue disappeared, what important physical event would remain?
- If action lines disappeared, what story information would be lost?
- What did each person want at entry?
- Who has more/less leverage at exit?
- What new problem now exists because of choices in this scene?
