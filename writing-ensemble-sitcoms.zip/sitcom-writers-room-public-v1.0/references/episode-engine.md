# Episode Engine — Pressure, Cross-Contamination, Convergence

## 1. Start with disturbance, not theme

Define one concrete event that breaks the usual equilibrium today:
- an unexpected guest;
- missing money;
- a new rule;
- a broken object;
- a deadline;
- a mistaken message;
- a public promise;
- a rumor;
- a reservation conflict;
- a favor called in;
- a resource shortage;
- a small lie that must now be maintained.

Theme can emerge from how characters respond. Do not begin by forcing characters to debate a theme.

## 2. Thread count follows capacity

Use **A/B** by default. Add **C** only when the runtime, cast, and premise support it.

A thread should have:
1. a concrete want;
2. a resisting force;
3. an escalating maintenance cost;
4. at least one decision that worsens the situation;
5. a consequence or collision.

A thread that merely supplies extra jokes is not a thread.

## 3. Thread design

### A story
The episode’s strongest practical/emotional pressure. It should touch at least one important relationship.

### B story
A distinct but compatible problem that reveals another relationship or value conflict. It should eventually **change the conditions** of A, not merely cut away from it.

### C story (optional)
Small, clean, high-comedy line that can act as a fuse, witness, obstacle, false solution, or payoff carrier. Keep it light enough not to steal structural oxygen.

## 4. Escalation ladder

Do not escalate by making people louder. Escalate by increasing cost and reducing available exits.

A useful ladder:
1. **manageable inconvenience** — character believes they can contain it;
2. **first bad choice** — a tactic creates a second problem;
3. **social exposure risk** — someone else learns, suspects, or depends on the wrong thing;
4. **maintenance burden** — lie/favor/plan now needs extra work;
5. **cross-contamination** — B or C makes A harder;
6. **forced choice** — character must sacrifice pride, money, status, secrecy, convenience, or relationship comfort;
7. **consequence** — the choice changes the local social state.

## 5. Causality test

For every beat, complete:

**Because [previous action/revelation], therefore [next action].**

If the link is “and then,” search for a stronger cause.

Coincidences may create trouble. They should rarely solve it.

## 6. Convergence

The most satisfying sitcom convergence happens when separate character strategies collide.

Good convergence:
- A’s lie causes B to make a confident wrong decision;
- B’s attempt to help removes A’s escape route;
- C’s minor obsession produces the object/witness/timing that exposes both;
- the final problem is recognizably built from earlier choices.

Weak convergence:
- everyone happens to enter the same room;
- a stranger explains the truth;
- a phone call fixes everything;
- a new fact appears only to finish the plot.

## 7. Resolution is not reset

Resolve the episode’s practical question while allowing social residue:
- someone owes a new favor;
- trust improves or worsens slightly;
- a secret survives but becomes harder to maintain;
- a running gag gains new meaning;
- an object changes hands;
- status temporarily flips;
- a character wins publicly and loses privately.

Sitcom continuity thrives on **small durable deltas**, not constant life-changing arcs and not total amnesia.

## 8. Cold open and tag

Use them only when useful.

**Cold open:** a compact comic event that establishes the social world, seeds the episode, or gives a self-contained relationship joke. It should not be mandatory filler.

**Tag:** a final consequence, reversal, delayed payoff, or quiet aftershock. Do not use the tag to explain the joke or undo the episode.
