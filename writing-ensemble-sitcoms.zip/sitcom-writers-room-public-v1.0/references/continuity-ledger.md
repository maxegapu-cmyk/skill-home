# Continuity Ledger — Let Episodes Leave Small Scars

## 1. What to record after each episode

Record only durable changes that can affect future behavior.

### Facts
- new job/role/rule;
- object ownership;
- known preference or skill;
- discovered history;
- recurring location constraint.

### Social debts
- money/favor owed;
- promise made;
- secret kept;
- lie believed;
- embarrassing knowledge;
- apology accepted/rejected;
- boundary crossed;
- someone covered for someone else.

### Relationship delta
For each affected pair:
- trust: up/down/same;
- status: who gained/lost leverage;
- closeness: warmer/cooler/unchanged;
- unresolved tension;
- new shorthand or taboo.

### Running material
- setup still alive;
- callback already spent;
- recurring object/rule/person that remains usable;
- gag that should rest before reuse.

## 2. Use continuity as pressure, not recap

Do not remind the audience of old material unless a present choice activates it.

Strong reuse:
- a prior favor changes who can refuse whom;
- an old lie makes a new truthful statement sound suspicious;
- a repaired relationship changes who comes to whom first;
- a minor object still being in someone’s possession complicates today’s problem.

Weak reuse:
- a character announces, “Remember when…” only so the audience recognizes a callback;
- a famous old joke is repeated without new function;
- every episode drags all prior history into the room.

## 3. Contradiction handling

When new story needs conflict with established state:
1. verify the ledger;
2. decide whether the contradiction is intentional growth, deception, ignorance, or error;
3. if intentional, dramatize the reason;
4. if accidental, revise the new material rather than silently overwriting canon.

## 4. Character growth in sitcom

Growth can be slow and domain-specific. A person may learn to apologize to one friend while remaining terrible at admitting fault elsewhere.

Avoid two extremes:
- **total reset:** no episode matters;
- **serial-drama inflation:** every episode permanently transforms the entire cast.

Aim for accumulated familiarity: the audience feels these people have history because present behavior carries small traces of what happened before.

## 5. Pre-draft continuity pull

Before a new episode, retrieve only the relevant state:
- affected relationships;
- active debts/promises/secrets;
- recent changes in the arena;
- running material directly connected to the premise.

Too much continuity context can make dialogue sound like fan-service. Pull narrowly and causally.
