# Series Engine — Build a Social Machine, Not a Cast List

## 1. The recurring arena

A sitcom needs a place or social structure that repeatedly forces the same people into contact: workplace, apartment cluster, inn, family business, neighborhood, school office, club, clinic, restaurant, shared studio, repair shop, community center, etc.

The arena must provide **repeatable traffic**:
- reasons people cannot simply leave;
- recurring tasks, customers, neighbors, obligations, money problems, schedules, rules, traditions, or resources;
- public and private zones where different conversations become possible;
- objects or systems that can become pressure points without feeling invented for a gag.

A fixed set does not mean static drama. The place should behave like a machine with doors, queues, deadlines, deliveries, chores, noise, interruptions, shortages, and witnesses.

## 2. Character design: contradiction beats quirk

Do not define a recurring character as “the sarcastic one,” “the dumb one,” or “the neat freak.” Those are surface handles, not engines.

For each regular, define:

| Field | Question |
|---|---|
| Public identity | What do they need others to believe about them? |
| Private need | What do they actually need but resist admitting? |
| Social fear | What kind of humiliation, rejection, dependence, or loss bothers them most? |
| Default tactic | When pressured, do they bargain, charm, lecture, lie, withdraw, perform competence, over-help, attack, joke, appease? |
| Blind spot | What do they consistently misread about themselves or others? |
| Moral line | What will they not normally do, even for a win? |
| Resource | What can they provide that keeps others needing them? |
| Liability | What repeatedly creates trouble without making them unusable? |
| Repair style | After hurting someone, how do they try to restore the relationship? |

A useful sitcom character can be right for the wrong reason, wrong for an understandable reason, generous in an irritating way, or selfish in a way that exposes vulnerability.

## 3. Relationship graph: the real series engine

The series does not have one version of each character. People change register depending on who is in front of them.

For every important pair, define:
- **power balance:** who usually has leverage, and in what domain?
- **affection:** what do they genuinely like about each other?
- **irritant:** what tiny recurring behavior gets under the skin?
- **dependency:** what does one need from the other?
- **forbidden truth:** what can they not comfortably say directly?
- **misreading:** what does A believe about B that B would reject?
- **repair ritual:** how do they usually make peace without saying “I’m sorry”?
- **comic asymmetry:** who notices what the other misses?

Do not make every pair antagonistic. Affection is comic fuel because people tolerate absurd behavior from people they love.

## 4. Standing obligations create future episodes

Track durable social debts:
- money owed;
- favors owed;
- promises;
- secrets held;
- favors refused;
- embarrassing knowledge;
- professional authority;
- family expectations;
- romantic ambiguity;
- objects borrowed;
- routines one person relies on another to perform.

A new episode becomes stronger when its fresh problem activates an old obligation naturally.

## 5. Ensemble balance

Avoid making everyone equally witty, equally self-aware, or equally chaotic.

Useful asymmetries include:
- one sees the social problem before the practical problem;
- one solves practical problems while making social ones worse;
- one cannot lie well;
- one lies too well and creates maintenance cost;
- one treats small matters as principles;
- one treats principles as small matters;
- one performs adulthood but secretly needs care;
- one looks unserious but notices emotional truth.

Do not freeze characters into functions. Rotate who is competent, needy, ridiculous, protective, or mistaken depending on domain.

## 6. Series promise

Write one sentence answering:

**What repeatable collision can this show generate for dozens of episodes without resetting its characters to zero?**

Bad: “A group of funny friends hang out.”

Better pattern: “People who rely on one another to keep a fragile shared life functioning repeatedly turn small practical problems into tests of pride, loyalty, status, and belonging.”

## 7. Sustainable episode seeds

Generate episode ideas from intersections, not random premises:

`fresh practical problem × standing character need × relationship debt × arena pressure`

Example pattern:
- practical problem: a delivery arrives for the wrong person;
- character need: someone is desperate to look financially successful;
- relationship debt: another person promised not to expose their money trouble;
- arena pressure: customers are present and the package cannot be hidden.

The situation now contains story before any joke is written.
