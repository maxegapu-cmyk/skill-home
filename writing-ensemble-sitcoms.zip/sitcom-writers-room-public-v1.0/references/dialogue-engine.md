# Dialogue Engine — Voice, Subtext, Rhythm, Comedy

## 1. Voice is a decision pattern

Do not build voice from catchphrases. Build it from how a person thinks under pressure.

For each recurring character, define:
- **tempo:** fast/slow, interrupting/allowing space;
- **sentence shape:** clipped, winding, precise, evasive, over-qualified;
- **concreteness:** speaks in examples, rules, feelings, numbers, status, stories, practical details;
- **social tactic:** charm, bargain, lecture, tease, deny, redirect, perform innocence, over-explain, understate;
- **self-protection:** joke first, attack first, apologize too soon, become formal, go silent, change subject;
- **truth style:** blunt, strategic, reluctant, accidental, technically truthful;
- **anger style:** colder, louder, more polite, more literal, more personal, more procedural;
- **affection style:** favors, insults, food, advice, logistics, touch, teasing, quiet presence;
- **blind phrase territory:** what subjects make their language suddenly less fluent?

Then add **relationship-specific register**. A person may bully a sibling, over-explain to a boss, become childish with a parent, and speak plainly only to one trusted friend.

## 2. Immediate intent before wording

Every line should perform an action, even when casual:
- get information;
- hide information;
- test a suspicion;
- save face;
- make someone stay;
- make someone leave;
- recruit an ally;
- shift blame;
- avoid committing;
- ask for care without asking;
- reassert status;
- repair damage;
- punish lightly;
- change the subject.

If a line exists only because the audience needs information, redesign the moment.

## 3. Subtext is unequal willingness

Natural dialogue often works because people are not equally willing to name the real subject.

Tools:
- answer the question beside the question;
- correct a trivial detail to avoid the important one;
- become unusually formal;
- use logistics to express affection or resentment;
- volunteer too much on a safe topic;
- mishear selectively;
- make a joke that is also a warning;
- accept a practical favor instead of an apology.

Do not make every line cryptic. Subtext needs plain lines around it.

## 4. Exposition rule

People do not tell each other what both already know unless the **present interaction gives them a reason**: accusation, correction, weaponizing history, testing memory, bargaining, humiliation, legal/procedural necessity, or emotional repair.

Bad function:
> “As you know, you quit college three years ago after Dad stopped paying tuition.”

Better function pattern:
> “Don’t give me the ‘finish what you start’ speech. You used mine on me already.”

The second line implies history while fighting today’s fight.

## 5. Unequal joke density

Do not optimize each line separately for maximum wit. That creates synthetic cadence.

Let roles rotate:
- one sets up unintentionally;
- one spots the absurdity;
- one refuses the joke and makes it funnier;
- one takes a metaphor literally;
- one is too invested to see what the audience sees;
- one lands a rare devastating line because they normally do not joke.

A straight line can be the load-bearing beam for a later laugh.

## 6. Comedy sources

Prefer layered sources:

### Character-choice comedy
A person solves the wrong problem because of pride, fear, or habit.

### Status comedy
Someone tries to look powerful, competent, desirable, moral, relaxed, or unbothered and loses control of that image.

### Information comedy
Audience and characters possess different pieces of truth.

### Expectation/reversal
A setup points toward one social interpretation; the next beat reveals a more embarrassing or inconvenient one.

### Physical consequence
An earlier verbal choice creates a concrete task, obstacle, witness, or object problem.

### Callback
A prior detail returns with changed meaning. The callback must affect the current scene; recognition alone is not enough.

## 7. Interruption and overlap

Use interruption when someone has a reason to seize the turn, prevent a word, finish a known pattern, or correct a dangerous implication. Do not sprinkle dashes everywhere to simulate realism.

Fragments, unfinished thoughts, self-correction, and silence are useful when tied to thought pressure.

## 8. Line polish order

Polish in this order:
1. Is the character trying to do something?
2. Is this the line this person would choose with this listener?
3. Does it reveal too much too cleanly?
4. Can it be shorter without losing character?
5. Does the next line actually respond?
6. Is the joke earned by the scene?
7. Would removing the joke improve truth or timing?

Never sacrifice steps 1–5 for step 6.
