# Quality Gates — Rewrite Before Delivery

Use this after planning and again after the draft.

## Gate 1: Story still works without jokes

Temporarily ignore overt punchlines.

Pass only if:
- characters still want incompatible things;
- events still cause later events;
- scenes still turn;
- the episode still produces a consequence.

If removing jokes collapses the story, rebuild the story engine.

## Gate 2: Voices survive without names

Read a sample with character names hidden.

Pass only if speakers can often be inferred from:
- tactic;
- rhythm;
- what they notice;
- what they refuse to say;
- relationship-specific behavior.

If distinction depends mainly on catchphrases, redesign voice.

## Gate 3: Action is causal

Delete action lines mentally.

If almost nothing changes, the draft is too close to radio/stage banter. Add meaningful tasks, objects, spatial constraints, witnesses, timing, or physical consequences — but only where they affect choices.

## Gate 4: Exposition is motivated

Highlight every line that tells the audience background information.

For each, ask: **Why does this speaker need to say this to this listener now?**

If the answer is “so the audience understands,” rewrite through present conflict/behavior or remove it.

## Gate 5: Joke ecology

Flag:
- three or more consecutive lines that all chase punchlines;
- multiple characters using the same kind of sarcasm;
- a joke requiring a character to forget obvious information;
- a callback that exists only for recognition;
- a gag that pauses the practical problem instead of worsening/revealing it.

Restore setup lines, straight reactions, silence, embarrassment, or task pressure where needed.

## Gate 6: Causality

Between major beats write “because/therefore.”

Hard fail if a major turn depends on:
- unexplained new information;
- an unrelated coincidence that solves the problem;
- someone entering only because the writer needs them;
- a sudden personality shift;
- an off-screen fix to the central complication.

## Gate 7: Scene-turn audit

For every scene, write:

`entry state -> exit state`

Examples:
- “secret safe -> one person suspicious”
- “A has leverage -> B gets the receipt”
- “friends aligned -> privately offended”
- “door can stay locked -> customer now needs item inside”

If you cannot write a meaningful arrow, cut, combine, or rebuild the scene.

## Gate 8: Anti-stage-play hard fail

Rewrite if the scene mostly contains:
- greetings, seated discussion, and reaction parentheticals;
- action directions such as “looks shocked,” “sarcastically,” “walks around nervously” without story effect;
- long speeches that would work unchanged on an empty stage;
- entrances/exits with no practical motivation;
- characters describing action instead of doing it.

Screenplay action should create or reveal story.

## Gate 9: Relationship truth

Ask of every major comic beat:
- Would this person do this to **this** person?
- What are they risking socially?
- What do they hope the other person believes?
- After the laugh, has trust/status/affection/embarrassment shifted?

Comedy that ignores relationship cost becomes sketch comedy.

## Gate 10: Final score

Use `tests/scoring-rubric.md`.

**Delivery threshold: 88/100 and zero hard fails.**

If below threshold, revise the weakest structural category first. Do not polish wording on a scene whose causality, objective, or turn is broken.
