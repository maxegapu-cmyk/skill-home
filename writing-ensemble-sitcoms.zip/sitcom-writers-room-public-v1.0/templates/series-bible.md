# Series Bible — Compact Sitcom Worksheet

## Series promise
- Working title:
- Format/runtime:
- Recurring arena:
- Why these people repeatedly cannot avoid one another:
- Repeatable collision in one sentence:
- Tone boundaries (what kind of humor belongs / does not belong):

## Arena pressure
- Daily/weekly routines:
- Money/resource constraints:
- Rules/authority:
- Recurring visitors/customers/neighbors:
- Public zones:
- Private zones:
- Objects/systems that can create recurring pressure:

## Regular cast
For each character:
- Public identity:
- Private need:
- Social fear:
- Default pressure tactic:
- Blind spot:
- Moral line:
- Useful resource:
- Recurring liability:
- Repair style:
- Voice tempo/sentence shape:
- Truth style:
- Anger style:
- Affection style:

## Relationship pairs
For each important pair:
- Power balance:
- Genuine affection:
- Irritant:
- Dependency:
- Forbidden truth:
- Misreading:
- Repair ritual:
- Comic asymmetry:

## Standing continuity
- Favors/debts:
- Promises:
- Secrets:
- Lies currently believed:
- Objects borrowed/owned:
- Romantic ambiguity:
- Professional leverage:
- Family/social obligations:
