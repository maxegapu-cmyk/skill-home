# Episode Room — Sitcom Planning Sheet

## Episode core
- Disturbance today:
- Why today cannot remain normal:
- Main relationship under pressure:
- Practical question the episode must answer:
- Social/emotional residue that may remain:

## Thread map

### A thread
- Want:
- Resistance:
- First bad choice:
- Maintenance cost:
- Forced choice:
- Consequence:

### B thread
- Want:
- Resistance:
- First bad choice:
- How it changes A’s conditions:
- Consequence:

### C thread (only if needed)
- Small want/problem:
- Why it deserves screen time:
- Where it collides with A/B:
- Payoff/consequence:

## Escalation ladder
1. Manageable inconvenience:
2. First bad choice:
3. Exposure risk:
4. Maintenance burden:
5. Cross-contamination:
6. Forced choice:
7. Consequence:

## Scene cards
Repeat for each scene:
- Scene heading / location-time:
- Present activity:
- Characters present:
- Each character’s immediate objective:
- Friction:
- Information asymmetry:
- Pressure source:
- Beat 1 because/therefore:
- Beat 2 because/therefore:
- Beat 3 because/therefore:
- Turn (entry state -> exit state):
- Exit pressure:

## Continuity delta after draft
- New facts:
- Favors/debts/promises:
- Secrets/lies changed:
- Relationship deltas:
- Objects/status changed:
- Running material still alive:
