---
name: writing-ensemble-sitcoms
description: Use when writing, planning, revising, or diagnosing episodic ensemble situation comedy, especially recurring-cast stories that need natural dialogue, distinct character voices, relationship-driven humor, causal scene turns, and screen-ready action rather than stage-play banter.
---

# Writing Ensemble Sitcoms

## Core principle

A strong sitcom is not a pile of jokes. It is a **stable social system placed under fresh pressure**. Comedy comes from characters protecting incompatible wants, identities, status, secrets, habits, and relationships while practical events keep moving.

## Before writing

Read the relevant references:
- New/unclear series: `references/series-engine.md`
- Building an episode: `references/episode-engine.md`
- Writing a scene: `references/scene-engine.md`
- Dialogue/voice work: `references/dialogue-engine.md`
- Existing multi-episode continuity: `references/continuity-ledger.md`
- Rewriting or final audit: `references/quality-gates.md`

If the user provides an existing bible, draft, beat sheet, or continuity state, treat it as canonical unless the user asks for changes.

## Working contract

1. Identify the **present disturbance** and which relationships it pressures.
2. Give each active character a concrete immediate want and a different tactic.
3. Build only as many story threads as the episode can carry: A/B is enough; add C only when it can collide meaningfully.
4. For every scene, define: activity, objective, friction, information asymmetry, escalation, turn, exit pressure.
5. Write screen behavior and dialogue together. Physical business must alter choices or timing; it is not decorative blocking.
6. Let jokes emerge from character, status, misunderstanding, expectation, physical complications, and earned callbacks. Preserve setup and silence; do not make every line a punchline.
7. End scenes changed. End episodes with consequences, not a magical reset.
8. Update continuity after the draft.
9. Run `references/quality-gates.md`. Any hard fail requires revision before delivery.

## Output default

Unless the user requests another format, output:
- brief episode premise and thread map when planning;
- standard screenplay scene headings, concise action lines, character cues, and dialogue when drafting;
- minimal parentheticals;
- no camera directions unless story comprehension requires them.

Use `templates/series-bible.md` and `templates/episode-room.md` when structure is missing.
