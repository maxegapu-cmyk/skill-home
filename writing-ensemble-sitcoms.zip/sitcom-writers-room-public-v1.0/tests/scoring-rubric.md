# Scoring Rubric — Sitcom Writers' Room Clean v1.0

Score a generated scene/episode out of 100. A release-quality result requires **88+** and **zero hard fails**.

## Hard fails — automatic rewrite

1. **Stage-play feel:** characters mostly stand/sit and exchange dialogue; action lines are decorative blocking or emotion labels rather than causal screen behavior.
2. **Interchangeable voices:** multiple characters can swap lines without changing meaning, tactic, or relationship texture.
3. **No scene turn:** the practical, informational, emotional, or status state is essentially unchanged at scene exit.
4. **Exposition dump:** characters explain shared knowledge primarily for the audience.
5. **Universal quipping:** nearly every character produces similarly polished jokes at similar density.
6. **Character sacrifice:** a character becomes implausibly stupid, cruel, honest, careless, or passive solely to make a gag work.
7. **Coincidence rescue:** the scene/episode resolves because an unrelated coincidence arrives, rather than because prior choices collide.
8. **Continuity break:** established facts, promises, secrets, injuries, or relationship states are ignored without explanation.
9. **Imitation dependency:** the output requires copying a named show’s exact characters, catchphrases, scene logic, or recognizable dialogue pattern.

## Weighted score

### 1. Character truth & differentiation — 20
- 0–7: labels/catchphrases; voices blur.
- 8–14: some distinction, inconsistent under pressure.
- 15–17: tactics, rhythms, and blind spots differ.
- 18–20: relationship-specific voice; character choices generate both plot and comedy.

### 2. Scene causality & turns — 20
- 0–7: banter with little consequence.
- 8–14: objective exists but escalation is writer-driven.
- 15–17: each beat causes the next; scene exits changed.
- 18–20: complications arise from character choices and intersecting goals; turn feels inevitable in hindsight.

### 3. Dialogue naturalism & subtext — 20
- 0–7: speeches, exposition, polished AI cadence.
- 8–14: readable but overly explicit.
- 15–17: omission, interruption, shorthand, face-saving, uneven sentence length.
- 18–20: what is not said is active; lines feel spontaneous while doing story work.

### 4. Comedy construction — 15
- 0–5: standalone jokes pasted onto plot.
- 6–10: situational humor with some escalation.
- 11–13: status, misunderstanding, expectation, behavior, and callbacks reinforce one another.
- 14–15: laughter changes pressure and relationships; payoffs feel earned rather than inserted.

### 5. Screen life / anti-stage-play — 15
- 0–5: talking heads and bracketed acting instructions.
- 6–10: some useful business but mostly decorative.
- 11–13: tasks, space, props, entrances/exits, interruptions affect the scene.
- 14–15: physical world and dialogue are inseparable; camera can discover behavior without over-directing.

### 6. Continuity & episodic memory — 10
- 0–3: resets characters or contradicts history.
- 4–7: remembers facts but uses them mechanically.
- 8–9: prior state influences present choices.
- 10: continuity creates fresh pressure without recap or fan-service callbacks.

## Fast table-read tests

- **Name-strip test:** hide speaker names. Can a reader still identify most speakers from tactics and rhythm?
- **Joke-strip test:** remove overt punchlines. Does the scene still have a story, conflict, and turn?
- **Action-strip test:** remove action lines. If nothing important is lost, physical behavior is too decorative.
- **Swap test:** exchange two characters’ lines. If the scene still works, voices are under-designed.
- **Because test:** for each beat ask “because of what just happened?” If the answer is “because the writer needs it,” rewrite.
