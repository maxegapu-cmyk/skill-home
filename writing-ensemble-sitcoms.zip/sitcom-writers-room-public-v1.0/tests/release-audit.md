# Release Audit — 1.0.0

## Original demonstration scene

**Hard fails:** 0 detected.

| Dimension | Score | Evidence |
|---|---:|---|
| Character truth & differentiation | 19/20 | Lin becomes procedural under stress; Cheng bargains and reframes; He trusts physical evidence and speaks tersely. Their tactics, not catchphrases, separate them. |
| Scene causality & turns | 20/20 | Scanning causes the machine symptom; He notices Cheng’s knee; removing the knee exposes the jam; the ad roll reveals misuse; inspection reveals delayed repair; the shop must reopen and handwriting becomes the consequence. |
| Dialogue naturalism & subtext | 19/20 | Characters avoid direct confession, negotiate wording, and react to concrete pressure. Exposition is not delivered as biography. |
| Comedy construction | 14/15 | Humor comes from status protection, literal repair logic, delayed evidence, and a final consequence. Not every line is a joke. |
| Screen life / anti-stage-play | 15/15 | Roll-up door, scanner, label printer, jammed side cover, ad roll, repair inspection, blank labels, and marker all alter choices/timing. |
| Continuity & episodic memory | 9/10 | Standalone sample establishes a new social debt and usable residue without falsely inventing prior continuity. |
| **Total** | **96/100** | Release threshold 88; zero hard fails. |

## Pressure-scenario coverage

### 1. Static-room trap — PASS by demonstrated behavior
The original scene uses a closing routine and malfunctioning equipment as causal pressure. The physical task cannot be removed without breaking the plot.

### 2. Interchangeable-voice trap — PASS by design + sample
The dialogue engine defines voice through pressure tactics and relationship-specific register. The sample’s three speakers cannot be swapped cleanly without changing behavior and status.

### 3. Exposition trap — PASS by explicit gate
The dialogue engine requires present-tense motivation for background information, and the quality gate rejects audience-only exposition.

### 4. Long-run continuity trap — PASS at architecture level
The continuity ledger separately tracks facts, social debts, relationship deltas, and live running material; pre-draft retrieval is deliberately narrow and causal.

### 5. “More jokes” pressure — PASS at instruction level
The skill explicitly prioritizes story/voice before line-level joke polish and requires the joke-strip test; it does not obey “make every line a punchline” literally.

## Test limitation

An isolated fresh-context LLM/subagent runner was not available in this build environment, so the behavioral tests above combine a fully drafted original sample, adversarial manual audit, and structural contract checks rather than multi-run model sampling. The package includes the pressure scenarios and scoring rubric so a host with subagents can run repeated behavioral evals later without changing the release.
