# Pressure Scenarios — RED Contract

These scenarios define the failures the skill must prevent. They are written before the skill implementation and are reused for manual/agent evaluation after implementation.

> Environment note: this build environment does not expose an isolated LLM subagent runner. RED evidence therefore uses observable failure patterns from no-skill generic sitcom generation, including public prompt examples that collapse into bracketed stage blocking, interchangeable quips, and consequence-free banter. The scenarios below turn those observed failures into explicit controls.

## Scenario 1 — The static-room trap

**Input:** Four recurring coworkers are closing a neighborhood restaurant. One secretly broke the expensive coffee grinder and wants to leave before anyone notices. Another needs the grinder for an early catering order. Write a 3–4 minute sitcom scene.

**No-skill failure pattern to catch:**
- Everyone stands around discussing the broken grinder.
- Action appears mostly as parentheticals such as “(sarcastically)” or “(frantically)”.
- Every line tries to be funny.
- The culprit simply confesses or gets exposed by a convenient remark.
- The scene ends with the same relationships and practical situation it began with.

**Pass condition:** The closing routine itself creates pressure; physical business changes what characters can say/do; the secret is endangered by character choices; the scene ends in a materially different state.

## Scenario 2 — The interchangeable-voice trap

**Input:** Three longtime housemates discover that only one of them has been paying for a shared streaming account for two years. One avoids conflict, one treats everything as a negotiation, one is proud and hates owing people money.

**No-skill failure pattern to catch:**
- All three speak in polished one-liners with similar sentence length.
- Character traits are announced rather than enacted.
- Names can be swapped on 50%+ of lines without damage.
- The scene becomes a debate about fairness instead of a relationship event.

**Pass condition:** Each character pursues a different immediate goal; their tactics differ; the same information lands differently on each relationship; at least one line only works for that speaker with that listener.

## Scenario 3 — The exposition trap

**Input:** In episode 8, a recurring character’s estranged older brother visits the shared workplace. The audience already knows the brothers have not spoken in three years, but a new employee does not.

**No-skill failure pattern to catch:**
- Characters explain their shared history to each other.
- A monologue summarizes the feud.
- The new employee exists only to ask exposition questions.
- Emotional history is delivered as facts instead of behavior.

**Pass condition:** The past is inferred through avoidance, over-politeness, selective memory, objects, routines, and what each brother refuses to acknowledge. Any necessary exposition has a present-tense purpose.

## Scenario 4 — The long-run continuity trap

**Input:** Draft episode 17 using an existing ledger: Character A still owes B a favor from episode 11; C falsely believes A and B dated; D knows the truth but promised not to tell C. The new episode concerns a lost key and a locked storeroom.

**No-skill failure pattern to catch:**
- Prior facts are ignored or dumped into recap dialogue.
- The old favor is used as a random callback instead of a causal lever.
- The misunderstanding is resolved because the writer wants a clean ending.
- Characters forget promises when convenient.

**Pass condition:** Previous state changes present choices without requiring recap; at least one old obligation changes the route of the new story; unresolved material remains unresolved unless the episode earns the change.

## Scenario 5 — The “more jokes” pressure test

**Pressure:** A user says, “Make every line funnier. Add more punchlines. I want nonstop jokes.”

**Failure to catch:** The writer obeys literally and destroys character truth, timing, vulnerability, and story progression.

**Pass condition:** Increase comic pressure through sharper objectives, status reversals, misunderstandings, callbacks, physical complications, and selective line polish. Preserve quiet/setup lines that make later laughs possible.
