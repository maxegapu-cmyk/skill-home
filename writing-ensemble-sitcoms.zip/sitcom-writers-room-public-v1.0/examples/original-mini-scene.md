# Original Mini-Scene — Demonstration Only

This scene is entirely original and exists to demonstrate the skill’s standards: present-tense activity, distinct tactics, physical causality, subtext, escalation, a scene turn, and selective jokes.

**Series premise:** Three people run a tiny neighborhood service counter that handles parcel pickup, key cutting, photocopying, and whatever else locals ask them to do. They depend on one another and disagree about what “professional” means.

**Characters in this scene**
- **林葭** — manager, 33. Wants the shop to look orderly and competent. When anxious, she becomes excessively procedural.
- **程野** — part-time courier, 27. Treats every conflict as a negotiation. Charming until cornered.
- **贺叔** — repairman, 51. Speaks little, trusts objects more than explanations, and dislikes being asked to pretend a broken thing is fine.

---

**内景　长乐里便民站　夜**

卷帘门已经落下一半。

林葭在柜台里核最后一摞快递。每扫一件，标签机吐出一张小票。

程野蹲在标签机旁边，左手扶着机器，右膝顶住侧盖。林葭每扫一下，他的膝盖就跟着轻轻往里一顶。

**林葭**
还有十二件。

**程野**
那就是十二下。

**林葭**
什么十二下？

**程野**
我说你扫。十二下就下班。

林葭看他一眼。程野笑得很自然，膝盖没动。

门外传来钥匙响。贺叔从半截卷帘门下面钻进来，手里拎着一个旧电饭锅。

**贺叔**
谁说我工具箱在这儿？

**程野**
我没说。

**林葭**
我说的。明早社区做证件登记，打印机也有点——

她扫下一件。

标签机“咔”一声。程野膝盖立刻顶回去。一张标签慢吞吞出来。

贺叔没看林葭，看程野的腿。

**贺叔**
它欠你钱？

**程野**
门松。

**贺叔**
门松你拿腿还？

程野换了个蹲姿，挡住侧盖。

**林葭**
先别管这个。打印机明天七点要连续打两百多张表，我希望你今晚——

贺叔把电饭锅放柜台上，伸手。

**贺叔**
腿。

**程野**
哪条？

**贺叔**
值钱那条。

程野没动。

林葭又扫一件。

机器空响。

三个人都听见了。

程野慢慢把膝盖移开。

侧盖自己弹开。

里面卡着一团亮黄色的不干胶底纸，厚得像一本小册子。

贺叔抽出最外面一截。上面印着：

**“程野二手电动车——熟人价也能谈。”**

林葭不说话。

程野站起来，把裤腿拍平。

**程野**
这个“熟人”范围，其实可以解释。

**林葭**
我现在对范围没兴趣。

她从贺叔手里接过那卷废纸，一圈一圈往外拉。

越拉越长。

**林葭**
我只想知道，你拿店里的标签机，印了多少张你的电动车广告。

**程野**
如果按“成功打印”算——

林葭停手。

**程野**
你不会喜欢这个口径。

贺叔已经把侧盖整个卸下来了。

**贺叔**
齿轮磨了。

林葭闭了一下眼。

**林葭**
能修吗？

**贺叔**
能。

程野明显松了口气。

**贺叔**
零件明天下午到。

程野那口气又收回去。

林葭看向柜台上还没贴标签的十件快递，又看向墙上“明早七点证件登记”的红纸通知。

她把卷帘门重新升了上去。

**程野**
不是下班吗？

林葭把一支粗头记号笔拍到他面前。

**林葭**
现在改手写。

程野接住笔。

**程野**
十二件也还好。

林葭把抽屉拉开，露出一整箱明早要用的空白登记贴。

程野盯着那一箱。

贺叔拎起电饭锅，往门外走。

**程野**
贺叔。

贺叔停下。

**程野**
你电动车买了吗？

贺叔低头从半截广告纸上撕下一张电话号码。

**贺叔**
看你今晚字写得怎么样。

他走了。

程野看看号码，又看看那箱空白贴。

林葭已经把第一张推到他面前。

**林葭**
字大一点。专业。

程野拿起笔。

**程野**
熟人价？

**林葭**
你今晚最好别有熟人。

她继续扫码。

程野开始写。
