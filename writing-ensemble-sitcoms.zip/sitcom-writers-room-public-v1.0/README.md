# Sitcom Writers' Room — Public Edition 1.0

A reusable agent skill for writing and revising ensemble situation comedy with natural dialogue, strong character differentiation, causal episode structure, and screen-playable scenes.

## What this release is for

Use it for recurring-cast sitcoms in fixed or semi-fixed social arenas: workplaces, apartments, inns, family businesses, restaurants, neighborhoods, schools, clubs, clinics, shops, or other places where people repeatedly need one another.

It is designed to prevent five common AI-writing failures:
1. stage-play-like talking heads;
2. every character sounding like the same joke writer;
3. exposition disguised as dialogue;
4. scenes that contain banter but no state change;
5. callbacks and coincidences replacing causality.

## Package map

- `SKILL.md` — the compact entry point agents should load first.
- `references/series-engine.md` — recurring arena, character contradictions, relationship graph.
- `references/episode-engine.md` — A/B(/C) threads, escalation, cross-contamination, convergence.
- `references/scene-engine.md` — playable scenes and anti-stage-play rules.
- `references/dialogue-engine.md` — voice, subtext, exposition control, joke ecology.
- `references/continuity-ledger.md` — multi-episode memory and durable social deltas.
- `references/quality-gates.md` — mandatory rewrite checks and final threshold.
- `templates/` — clean series and episode worksheets.
- `tests/` — pressure scenarios and scoring rubric.
- `examples/original-mini-scene.md` — entirely original demonstration scene.

## Recommended use

For a new series, start with `templates/series-bible.md`. For an existing series, provide the current cast/relationship state and only the continuity relevant to the episode. Build the episode in `templates/episode-room.md`, then draft scenes. Run the quality gates before delivery.

The system does **not** require a three-thread episode. A/B is the default; C is optional and must earn its screen time by changing A/B conditions.

## Originality note

This package is a standalone synthesis of public screenwriting/agent patterns and original craft rules. It does not reproduce source prompts or television-script text. The demonstration scene is original, and named television series are not required as writing templates.

## Public inspirations consulted

The architecture was informed at a high level by publicly available screenwriting/agent projects, without copying their prompt text or script material:

- Couchbase Examples — `multi-agent-capella-ai-services` / Seinfeld Script Generator: specialized roles and A/B/C plot-thread convergence.
  https://github.com/couchbase-examples/multi-agent-capella-ai-services
- `bflandev/script-doctor`: Story Bible, beat planning, acceptance-criteria-driven scene drafting, continuity and coverage concepts.
  https://github.com/bflandev/script-doctor
- Astronomer — `multi-agent-airflow-pipeline`: public character-writer prompt emphasizing voice, subtext, relationship dynamics, and comedy timing.
  https://github.com/astronomer/multi-agent-airflow-pipeline
- `abengkris/scripthis`: character bibles, world rules, outlines, draft state, and screenplay-project organization.
  https://github.com/abengkris/scripthis
- `596600892/screenplay-agent`: public feature framing around character development, scene breakdown, dialogue naturalism, and screenplay formatting.
  https://github.com/596600892/screenplay-agent
- Beat / Fountain ecosystem: plain-text screenplay formatting conventions and scene-oriented authoring.
  https://github.com/lmparppei/Beat

## Version

**1.0.0 — Public Edition**
