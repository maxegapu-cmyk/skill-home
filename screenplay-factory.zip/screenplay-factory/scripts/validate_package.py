#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path

REQUIRED = [
    'SKILL.md','README.md','RESEARCH.md','PACKAGE-NOTES.md',
    'references/feature-film-engine.md','references/short-drama-engine.md',
    'references/shared-dramaturgy.md','references/character-engine.md',
    'references/scene-engine.md','references/dialogue-engine.md',
    'references/adaptation-engine.md','references/revision-review.md',
    'references/screenplay-format.md','references/output-recipes.md',
    'scripts/screenplay_lint.py','assets/screenplay.md'
]
FORBIDDEN_IDENTITY = [
    'world'+'wonderer', 'linux'+'.do', 'the new '+'ideal community',
    'github.com/'+'world'+'wonderer', 'drama'+'-skills', '孤身'+'入魔',
    'screenplay factory contributors', 'provided by screenplay factory',
    'maintained by screenplay factory', 'created by screenplay factory'
]
LINK_RE = re.compile(r'\[[^\]]+\]\(([^)]+\.md)(?:#[^)]+)?\)')


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()


def check_frontmatter(skill: Path, errors: list[str]):
    text=skill.read_text(encoding='utf-8')
    if not text.startswith('---\n'):
        errors.append('SKILL.md missing YAML frontmatter opener')
        return
    parts=text.split('---\n',2)
    if len(parts)<3:
        errors.append('SKILL.md frontmatter not closed')
        return
    fm=parts[1]
    for key in ('name:', 'description:'):
        if key not in fm: errors.append(f'SKILL.md missing {key[:-1]}')
    if 'name: screenplay-factory' not in fm:
        errors.append('SKILL.md name must be screenplay-factory')
    if 'FEATURE_FILM' not in text or 'SHORT_DRAMA' not in text:
        errors.append('SKILL.md must expose both narrative engines')


def check_links(root: Path, errors: list[str]):
    for p in root.rglob('*.md'):
        text=p.read_text(encoding='utf-8')
        for target in LINK_RE.findall(text):
            if '://' in target: continue
            resolved=(p.parent/target).resolve()
            try: resolved.relative_to(root.resolve())
            except ValueError:
                errors.append(f'link escapes package: {p.relative_to(root)} -> {target}')
                continue
            if not resolved.exists():
                errors.append(f'broken link: {p.relative_to(root)} -> {target}')


def check_identity(root: Path, errors: list[str]):
    for p in root.rglob('*'):
        rel=p.relative_to(root).as_posix() if p.exists() else ''
        if rel == 'scripts/validate_package.py' or rel.startswith('tests/'):
            continue
        if not p.is_file() or p.suffix.lower() in {'.pyc','.png','.jpg','.jpeg','.webp','.zip'}: continue
        try: text=p.read_text(encoding='utf-8').lower()
        except UnicodeDecodeError: continue
        for term in FORBIDDEN_IDENTITY:
            if term.lower() in text:
                errors.append(f'forbidden legacy identity term {term!r} in {p.relative_to(root)}')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('root', nargs='?', default='.')
    ap.add_argument('--manifest', action='store_true', help='write PACKAGE-MANIFEST.json after validation')
    args=ap.parse_args()
    root=Path(args.root).resolve()
    errors=[]
    for rel in REQUIRED:
        if not (root/rel).is_file(): errors.append(f'missing required file: {rel}')
    if (root/'SKILL.md').is_file(): check_frontmatter(root/'SKILL.md', errors)
    check_links(root, errors)
    check_identity(root, errors)
    # Explicit architectural separation checks.
    if (root/'references/feature-film-engine.md').is_file():
        f=(root/'references/feature-film-engine.md').read_text(encoding='utf-8')
        if '电影不是“更长的短剧”' not in f: errors.append('feature engine separation anchor missing')
    if (root/'references/short-drama-engine.md').is_file():
        s=(root/'references/short-drama-engine.md').read_text(encoding='utf-8')
        if '短剧不是“把电影切碎”' not in s: errors.append('short engine separation anchor missing')
    if errors:
        print('PACKAGE VALIDATION: FAIL')
        for e in errors: print(' -', e)
        return 1
    if args.manifest:
        files=[]
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.name != 'PACKAGE-MANIFEST.json' and '__pycache__' not in p.parts:
                files.append({'path':str(p.relative_to(root)).replace('\\','/'),'sha256':sha256(p),'bytes':p.stat().st_size})
        manifest={'name':'screenplay-factory','version':'1.0.1','files':files}
        (root/'PACKAGE-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PACKAGE VALIDATION: PASS')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
