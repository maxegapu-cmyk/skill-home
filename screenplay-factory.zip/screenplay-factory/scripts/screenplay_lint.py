#!/usr/bin/env python3
from __future__ import annotations
import argparse,re,sys
from pathlib import Path

FEATURE_HEAD=re.compile(r'^##\s+(SC\d{3,4})\s+(内|外|内/外|外/内)\s*·')
SHORT_HEAD=re.compile(r'^##\s+(EP\d{3}-SC\d{3,4})\s+(内|外|内/外|外/内)\s*·')
PLACEHOLDERS=('【用现在时写可见动作。】','【场景结束时，至少一种状态已经改变。】','角色：台词。','TODO','TBD','待补')

def lint(text:str, mode:str):
    findings=[]
    ids=[]
    lines=text.splitlines()
    head_re=SHORT_HEAD if mode=='short' else FEATURE_HEAD
    scene_starts=[]
    for i,line in enumerate(lines,1):
        if line.startswith('## '):
            m=head_re.match(line)
            if not m:
                findings.append(('ERROR',i,'invalid_scene_heading',line))
            else:
                sid=m.group(1); ids.append((sid,i)); scene_starts.append((i,sid))
        for ph in PLACEHOLDERS:
            if ph in line:
                findings.append(('ERROR',i,'placeholder_left_in_script',ph))
    seen={}
    for sid,i in ids:
        if sid in seen: findings.append(('ERROR',i,'duplicate_scene_id',sid))
        seen[sid]=i
    # scene must contain at least one nonblank body line before next heading
    for idx,(start,sid) in enumerate(scene_starts):
        end=(scene_starts[idx+1][0]-1) if idx+1<len(scene_starts) else len(lines)
        body=[x.strip() for x in lines[start:end] if x.strip() and not x.startswith('## ')]
        if not body: findings.append(('ERROR',start,'empty_scene',sid))
    if not scene_starts: findings.append(('ERROR',1,'no_scene_headings',''))
    return findings

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('screenplay')
    ap.add_argument('--mode',choices=['feature','short'],required=True)
    args=ap.parse_args()
    p=Path(args.screenplay)
    text=p.read_text(encoding='utf-8')
    fs=lint(text,args.mode)
    if fs:
        print('SCREENPLAY LINT: FAIL')
        for sev,line,code,detail in fs: print(f'{sev} L{line} {code}: {detail}')
        return 1
    print('SCREENPLAY LINT: PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
