# Screenplay Factory 1.0.1

一个安装即用的双引擎剧本 Skill：

- `FEATURE_FILM`：电影长片，按单次完整观看的累积、人物转化、主题回响和终局选择组织。
- `SHORT_DRAMA`：短剧 / 微短剧 / 漫剧，按可持续系列引擎、集级局部兑现、状态交接和跨集升级组织。

它不是把同一套“节拍模板”改两个名字。主路由明确禁止电影被短剧留存逻辑污染，也禁止短剧被电影长距离蓄力拖死。

## 能做什么

从一句点子、小说/长材料、梗概、人物设定、分集大纲或已有剧本开始，完成：故事开发、改编、电影 blueprint、短剧 series engine、分集、场景、对白、完整剧本、续写、重写、去模板感、审查和结构校验。

## 不做什么

不负责分镜、生图、生视频、提示词生产或媒体生成。剧本完成后可交给其他生产系统，但这里不让执行端反向污染编剧决策。

## 安装

把整个 `screenplay-factory` 目录放进支持 Agent Skill 的 skills 目录即可。不要拆散 `references/`、`assets/` 与 `scripts/`。

## 验证

```bash
python3 scripts/validate_package.py .
python3 -m unittest discover -v tests
```

校验器只证明包结构、链接、frontmatter、身份痕迹清理与基础脚本行为，不宣称证明创作质量。
