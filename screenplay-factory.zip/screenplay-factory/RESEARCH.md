# Research Basis

本 Skill 的规则不是从单一“编剧公式”复制而来。重构时只吸收可解释、可迁移的方法，并明确拒绝把比例/页码/固定转折当成硬门槛。

## 电影 / 专业剧本格式

- Academy Nicholl Screenwriting Resources：专业 submission screenplay 存在格式变体；总体上使用 master scenes，通常不写 scene numbers，极少指定 camera shots；同时强调避免过长描述等读稿障碍。
  - https://www.oscars.org/nicholl/screenwriting-resources
- Sundance Collab 的长片编剧课程把人物行为、对白、潜台词、场景推动故事、主题与情绪 stakes 作为核心训练内容；改编课程强调提炼原作核心、复杂人物、主题、story engine、人物 wants/needs。
  - https://collab.sundance.org/catalog/Screenwriting-Beyond-the-First-Act-Finishing-Your-First-Draft
  - https://collab.sundance.org/catalog/Writing-Screenplay-Adaptations

## 短剧 / 微短剧

- 国家广播电视总局 2026《“微短剧精品创作传播计划”实施方案》强调内容为本、品质为魂、精品化，并明确反对唯流量倾向。这支持本 Skill 保留留存机制，但拒绝把“钩子流水线”当成唯一短剧法则。
  - https://www.nrta.gov.cn/art/2026/5/26/art_113_73378.html
- 2026 论文 One Sentence, One Drama 把短剧常见失败概括为 pacing、hook、escalation、ending 等问题，并使用分层规划与复审；本 Skill 只吸收“分层开发 + 针对性修订”的思想，不复制其具体系统。
  - https://arxiv.org/abs/2605.22144
- 2026 DramaDirector 研究强调短剧的快速镜头节奏、对白驱动注意转移与跨镜一致性。由于本 Skill 只负责剧本，相关启发被限制在“状态清晰、对白行动、连续性可追踪”，不扩张到分镜或生成管线。
  - https://arxiv.org/abs/2606.24107

## 研究使用边界

- 这些来源提供的是外部校准，不是权威结构模板。
- 不从公开样例复制具体剧情、台词或独特表达。
- 不把市场常见套路自动提升为结构定律。
