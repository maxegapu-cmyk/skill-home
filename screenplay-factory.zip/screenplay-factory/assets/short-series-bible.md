# Short Drama Series Bible

## 系列戏剧承诺

## 主角行动模型

## 主要对抗者

## Series Engine
```text
压力 → 主角策略 → 反制 → 局部结果/代价 → 状态变化 → 下一轮压力
```

## 可升级维度
- power：
- knowledge：
- relationship：
- exposure：
- resource：
- risk：
- commitment：

## 关键关系

## 信息 / 秘密

## 终止条件
