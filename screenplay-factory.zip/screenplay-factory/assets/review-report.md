# Screenplay Review

## 判决
PASS / PASS_WITH_RISKS / REWRITE_REQUIRED / INSUFFICIENT_EVIDENCE

## BLOCKER

## MAJOR

## MINOR

## 最小修复顺序

## Preserve Set
