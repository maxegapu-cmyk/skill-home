from pathlib import Path
import unittest,re
ROOT=Path(__file__).resolve().parents[1]

class ContentContractTests(unittest.TestCase):
    def test_skill_frontmatter(self):
        text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(text.startswith('---\n'))
        self.assertIn('name: screenplay-factory',text)
        self.assertNotIn('license:',text.lower())

    def test_no_fixed_page_mandate(self):
        text=(ROOT/'references/feature-film-engine.md').read_text(encoding='utf-8')
        self.assertIn('不使用固定页码三幕法作为质量门',text)
        self.assertIn('默认不要说“第 25 页必须进入第二幕”',text)

    def test_short_does_not_require_every_episode_cliffhanger(self):
        text=(ROOT/'references/short-drama-engine.md').read_text(encoding='utf-8')
        self.assertIn('不要求每集都使用 cliffhanger',text)

    def test_media_scope_removed(self):
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('分镜、生图、生视频',skill)
        self.assertIn('不属于本 Skill',skill)

if __name__=='__main__': unittest.main()
