from pathlib import Path
import subprocess, tempfile, unittest

ROOT=Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_package_validator_passes(self):
        r=subprocess.run(['python3',str(ROOT/'scripts/validate_package.py'),str(ROOT)],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        self.assertIn('PASS',r.stdout)

    def test_feature_and_short_are_separate(self):
        feature=(ROOT/'references/feature-film-engine.md').read_text(encoding='utf-8')
        short=(ROOT/'references/short-drama-engine.md').read_text(encoding='utf-8')
        self.assertIn('电影不是“更长的短剧”',feature)
        self.assertIn('短剧不是“把电影切碎”',short)
        self.assertIn('终局选择',feature)
        self.assertIn('局部兑现',short)

    def test_old_identity_is_absent(self):
        bad=['world'+'wonderer','linux'+'.do','github.com/'+'world'+'wonderer','drama'+'-skills','孤身'+'入魔']
        corpus='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix not in {'.pyc'} and not p.relative_to(ROOT).as_posix().startswith('tests/') and p.relative_to(ROOT).as_posix() != 'scripts/validate_package.py')
        for term in bad:
            self.assertNotIn(term.lower(),corpus.lower())


    def test_no_attribution_metadata(self):
        self.assertFalse((ROOT/'LICENSE').exists())
        corpus='\n'.join(
            p.read_text(encoding='utf-8', errors='ignore')
            for p in ROOT.rglob('*')
            if p.is_file() and p.suffix != '.pyc'
            and not p.relative_to(ROOT).as_posix().startswith('tests/')
            and p.relative_to(ROOT).as_posix() != 'scripts/validate_package.py'
        ).lower()
        for term in ('screenplay factory contributors','provided by screenplay factory','maintained by screenplay factory','created by screenplay factory'):
            self.assertNotIn(term, corpus)
        skill=(ROOT/'SKILL.md').read_text(encoding='utf-8').lower()
        self.assertNotIn('license:', skill)

    def test_feature_lint_pass_and_fail(self):
        good='# T\n\n## SC001 内 · 房间 · 日\n\n他关门。\n\n甲：走。\n'
        bad='# T\n\n## EP001-SC001 内 · 房间 · 日\n\nTODO\n'
        with tempfile.TemporaryDirectory() as td:
            a=Path(td)/'good.md'; a.write_text(good,encoding='utf-8')
            b=Path(td)/'bad.md'; b.write_text(bad,encoding='utf-8')
            ok=subprocess.run(['python3',str(ROOT/'scripts/screenplay_lint.py'),str(a),'--mode','feature'])
            no=subprocess.run(['python3',str(ROOT/'scripts/screenplay_lint.py'),str(b),'--mode','feature'])
            self.assertEqual(ok.returncode,0)
            self.assertNotEqual(no.returncode,0)

    def test_short_lint_passes(self):
        text='# T\n\n## EP001-SC001 外 · 门口 · 夜\n\n她把钥匙扔进下水道。\n\n乙：现在谁也走不了。\n'
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'s.md'; p.write_text(text,encoding='utf-8')
            r=subprocess.run(['python3',str(ROOT/'scripts/screenplay_lint.py'),str(p),'--mode','short'])
            self.assertEqual(r.returncode,0)

if __name__=='__main__': unittest.main()
