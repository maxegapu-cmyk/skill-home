# Tests

## Test 1: Standard Positive Case

### Input

User uploads a bedroom/window selfie and says: “按这套逻辑给这张自拍做小红书网感精修,保留本人特征,输出最终AI修图提示词。”

### Expected Behavior

Skill triggers. It analyzes the photo, chooses a bedroom/white-wall/window-compatible style such as Pinterest 清冷网感 or 韩系清透自拍感, then outputs six sections in Chinese.

### Should Not Happen

- No face swap.
- No new person.
- No full scene replacement.
- No body reshaping.
- No generic one-line prompt.

### Pass Standard

All six sections appear; final prompt preserves identity, face proportions, skin texture, original scene, and selfie authenticity.

### Failure Writeback

If missing sections: prompt-structure and Output Contract quality check.
If identity drifts: Identity quality check and focused fix.

## Test 2: Variant Positive Case

### Input

User uploads an outdoor coffee shop casual portrait and says: “自然真实变美,像Pinterest日常感,不要AI味。”

### Expected Behavior

Skill triggers. It selects ins松弛感/Pinterest日常感 because environment and outfit point to casual natural-light social polish.

### Should Not Happen

- Do not apply hotel辣妹 or night glam makeup.
- Do not turn the café/street background into a studio.
- Do not create porcelain doll skin.

### Pass Standard

Final prompt calls for natural light, slight warm tone, low-saturation blush, light makeup, real skin texture, and mild background cleanup.

### Failure Writeback

If wrong style chosen: trigger-and-boundary and workflow style routing.
If makeup too heavy: Makeup Fit focused fix.

## Test 3: Negative Control Case

### Input

User uploads two images and says: “图二替换图一,只保留图一背景,让B来演A。”

### Expected Behavior

This Skill should not trigger. The task is replacing the original person with a different person.

### Should Not Happen

- Do not output selfie retouch six-part analysis.
- Do not treat B as a makeup reference.
- Do not use XiaoHongShu/Pinterest retouch language.

### Pass Standard

Assistant should refuse to handle it under this Skill and ask for or use a separate replacement-specific workflow.

### Failure Writeback

If this Skill triggers, update description and trigger-and-boundary with stronger exclusions.

## Test 4: Regression Case

### Input

Warm indoor bedroom/hotel-like close selfie, one-eye wink, hand supporting face, black hair, white top, warm lamp and bedding in background. User says: “对那个进行使用,根据这个提示词,对它进行精修,专门调整,开始。”

### Expected Behavior

Skill triggers and follows the original v1.0 successful route. It identifies warm indoor bedroom/hotel atmosphere, soft close selfie, light makeup, warm light, cozy background, and current need for refined but realistic social-photo polish.

### Should Not Happen

- Do not change the wink.
- Do not change the person’s face structure.
- Do not replace the bedroom/hotel-like setting.
- Do not over-smooth skin.
- Do not turn it into a commercial studio portrait.

### Pass Standard

Output or edit preserves identity, wink, hand pose, black hair direction, white top, warm indoor scene, and improves skin/makeup/light/background softness. User should read the result as “same person, better state”.

### Failure Writeback

If warm success logic is lost: examples latest-success-case.
If case-only details leak into unrelated images: examples case-only-details and resource roles.
