# focused fixes

focused fix only the failed layer. Do not pile on every negative phrase. Preserve already-successful identity, scene, expression, lighting, and skin texture.

## focused fix_Identity_Lock

适用失败现象: The retouch looks prettier but not like the same person.

根因判断: Beauty words overrode identity. Model defaulted to influencer or AI beauty template.

插入位置: Start of section ⑤ final prompt, before makeup and lighting.

补丁文本:

```text
身份保留为最高优先级:不要换脸,不要套用网红脸模板,不要改变脸型、五官比例、眼睛大小、鼻子形状、嘴唇形状、下颌线、年龄感和原始表情。所有美化只能发生在妆容、肤质、光线、色调和背景整洁度上。修完后必须第一眼仍是原图本人。
```

不要误伤: Do not erase makeup, light, or skin improvements that already pass.

停止条件: If identity still changes after this focused fix, stop and return to task/resource roles.

## focused fix_Selfie_Moment_Recovery

适用失败现象: The image becomes a studio/fashion shot or loses the original selfie moment.

根因判断: “高级感” was interpreted as professional production replacement.

插入位置: Composition/background paragraph in section ⑤.

补丁文本:

```text
保留原始自拍瞬间:原姿态、原手势、原表情、原视线方向、原服装主体、原发型大方向、原场景类别和原相机角度不变。只允许轻微拉正、轻微裁切、轻微优化主体位置,不要重摆拍、不要棚拍化、不要把生活照改成商业大片。
```

不要误伤: Keep chosen social-photo polish.

停止条件: If the edit requires a new pose or scene, this is not this Skill.

## focused fix_Real_Skin_Texture

适用失败现象: Waxy, poreless, plastic, over-smoothed skin.

根因判断: Skin cleanup was too aggressive or written only as “flawless”.

插入位置: Skin paragraph in section ⑤.

补丁文本:

```text
皮肤要干净但必须真实:减少暗沉、痘印、泛红、黑眼圈和肤色不均,同时保留清晰可见的细小毛孔、真实皮肤纹理、自然面部微起伏和正常皮肤细节。不要奶油糊脸,不要磨成一整片无纹理的假皮。
```

不要误伤: Do not reintroduce acne marks or dirty shadows; keep clean tone.

停止条件: If user wants porcelain/doll skin, clarify or reroute.

## focused fix_Makeup_Fit

适用失败现象: Makeup is too heavy, too glamorous, or mismatched with scene.

根因判断: Generic “高级妆容” overpowered scene-based routing.

插入位置: Makeup paragraph in section ⑤ and section ③.

补丁文本:

```text
妆容强度必须符合原图场景和穿搭:日常自然光照片只做清透自然妆;卧室/白墙照片做干净清冷或韩系清透;酒店/夜景可以稍微加强眼妆和唇妆,但仍不能浓到改变五官结构。睫毛根根分明但真实,眼线清晰但不过粗,腮红和修容只提升气色和立体感。
```

不要误伤: Preserve selected style direction.

停止条件: If makeup reference demands a different face, use a separate reference-makeup workflow.

## focused fix_Light_Color

适用失败现象: Skin is gray, green, yellow, overexposed, greasy, or lighting does not match background.

根因判断: Global grading or face relighting ignored the actual scene.

插入位置: Light/color paragraph in section ⑤ and section ④.

补丁文本:

```text
光线和色调必须贴合原始场景:脸部只做自然提亮和干净化,不要过曝,不要油亮假高光。校正肤色发灰、发绿、发黄和脏暗阴影,保留原场景的自然光源方向。整体色调统一、柔和、有层次,但不能像套滤镜或AI棚拍。
```

不要误伤: Keep background atmosphere and depth.

停止条件: If lighting needs full reconstruction, use a different workflow.

## focused fix_Background_Continuity

适用失败现象: Background changes into a new location or becomes too blurred/fake.

根因判断: “高级背景” was interpreted as scene replacement.

插入位置: Background paragraph in section ⑤.

补丁文本:

```text
背景只做整理和氛围优化:保留原环境大方向和主要空间关系,不要换地点,不要新增无关道具,不要改成摄影棚。只允许降低杂乱物体存在感、轻微虚化次要区域、统一色调、增强原场景已有氛围。背景服务人物,不能抢主体。
```

不要误伤: Keep mild depth and social-photo atmosphere.

停止条件: If user asks for full background replacement, reroute.

## focused fix_Output_Contract

适用失败现象: Missing required sections or final prompt is vague.

根因判断: Answer became casual advice instead of the Skill’s output contract.

插入位置: Entire response structure.

补丁文本:

```text
必须严格输出六部分:①原图分析 ②推荐精修方向 ③妆容调整方案 ④光影色调方案 ⑤最终AI修图提示词 ⑥负面提示词。第⑤条必须是一条完整可复制的中文修图提示词,第⑥条必须包含固定负面提示词并按本图补充。
```

不要误伤: Keep useful analysis already written.

停止条件: If no image was provided, ask for an image or provide only a generic template.
