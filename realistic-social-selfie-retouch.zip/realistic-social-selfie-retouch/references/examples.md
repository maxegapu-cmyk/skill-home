# Examples

## latest-success-case

### Input

A close, warm indoor bedroom/hotel-like selfie portrait of a young woman. Visible traits include black hair with bangs, one-eye wink, soft smile, hand supporting face, white top, warm lamp in the background, bed/sofa/pillow/certain cozy indoor elements, warm beige lighting, and shallow social-photo framing.

### User Goal

Apply the user-provided realistic XiaoHongShu/Pinterest selfie retouch workflow to the image. Preserve identity, expression, pose, hairstyle direction, clothing subject, and cozy indoor setting while improving polish.

### Output Result Description

The successful result kept the same person, same wink, same soft smile, same hand-on-face pose, same black hair direction, same white top, and same warm bedroom/hotel atmosphere. It improved skin cleanliness, makeup delicacy, facial brightness, warm light balance, background softness, and overall social-photo polish. The image still felt like a real intimate selfie moment rather than a studio remake or a new AI-generated person.

### Why It Passed

Decisive rules:

- Identity remained the highest priority.
- The wink and pose were preserved, so the original selfie moment survived.
- Skin became cleaner but did not need to become a poreless plastic mask.
- Warm indoor light was improved rather than replaced.
- The background stayed cozy and softly blurred without becoming a new scene.
- Makeup stayed in a soft refined direction rather than heavy glam.

### What To Look At In New Chats

For similar warm indoor selfies, copy the decision logic, not the literal content. The important reusable move is: preserve the actual person and moment, then improve skin, makeup, light, and background softness in a believable way.

Do not assume every future image should be warm, hotel-like, winking, black-haired, or sweet.

## failed-cases

No separate failed generated images were provided in this v1.0 packaging round. Failure boundaries are derived from the original workflow’s explicit constraints and negative prompt requirements.

### Failure Boundary 1: Identity Drift

表现: Face becomes prettier but no longer the same person.

根因: Model defaulted to influencer template or generic beauty face.

Write back to: Identity quality check, Identity focused fix, negative prompt.

### Failure Boundary 2: Plastic Skin

表现: Poreless wax face, over-smoothing, oily fake highlights.

根因: “flawless skin” or “beauty retouch” overpowered real texture.

Write back to: Skin Texture quality check, Real Skin Texture focused fix.

### Failure Boundary 3: Scene Replacement

表现: Bedroom/hotel/street/café becomes a studio or unrelated scene.

根因: “high-end” was misread as commercial studio remake.

Write back to: Background Continuity quality check, Selfie Moment quality check, Background focused fix.

### Failure Boundary 4: Makeup Template

表现: Heavy lashes, overdone contour, over-glossy lips, face reads as another style category.

根因: Makeup not routed by the actual scene and outfit.

Write back to: Makeup Fit quality check and Makeup Fit focused fix.

### Failure Boundary 5: Output Contract Failure

表现: Only a prompt is written, or sections are missing.

根因: The workflow was treated as generic advice instead of a six-part production output.

Write back to: Output Contract quality check and Output Contract focused fix.

## reusable-lessons

- Same-person identity preservation is the hard rule.
- Each new photo must be analyzed from scratch.
- Retouch style is selected by scene first and outfit second.
- Clean skin must retain real skin texture.
- Background is refined, not replaced.
- Social-photo polish should not erase selfie authenticity.
- The six-part answer structure is part of the workflow, not optional decoration.

## case-only-details

These belong only to the latest success example and must not become universal rules:

- warm lamp
- cozy hotel/bedroom background
- bed/pillow/sofa elements
- one-eye wink
- black hair with bangs
- white top
- sweet warm indoor atmosphere
- close face framing

Use them only when a new input actually contains similar evidence.
