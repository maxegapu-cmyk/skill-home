# Changelog

## v1.0.0

Initial packaging of the realistic XiaoHongShu/Pinterest selfie retouch workflow.

### Source Workflow

Extracted from a ChatGPT conversation where the user supplied a detailed role, goal, identity lock, workflow, output format, prompt standards, negative prompt, and self-check for ordinary female selfie retouching. The workflow was then applied to a warm indoor bedroom/hotel-like selfie and the user approved the result as especially successful.

### Core Capabilities Included

- Six-part Chinese output contract.
- Scene-first, outfit-second retouch direction selection.
- Same-person identity preservation.
- Makeup planning by selected style.
- Clean-but-real skin texture rule.
- Scene-matched light and color treatment.
- Background cleanup without scene replacement.
- Composition improvement without body/face reshaping.
- Fixed negative prompt family.
- quality checks and focused fixes for identity, skin, scene, makeup, light/color, background, and output structure.

### Successful Rules Written Into Main Flow

- The uploaded selfie owns identity, facial proportions, expression, pose, clothing subject, hairstyle direction, scene, camera angle, and selfie authenticity.
- The edited result must be the same person in a better state.
- Real skin texture is mandatory.
- The original environment category must remain.
- Retouch direction must be decided from each new image, not copied from the previous success case.

### Failure Experience Written Into quality checks/fixes

The v1.0 package did not include separate failed generated images, so failure rules come from explicit user constraints and negative prompt boundaries:

- identity drift
- AI plastic skin
- over-smoothing
- scene replacement
- fake studio feeling
- heavy makeup template
- overexposed or dirty skin color
- six-part output omission

### Case-Only Material Not Generalized

The latest success case included warm indoor light, cozy bedroom/hotel background, wink expression, black hair, white top, and close framing. These remain only in examples and regression tests. They are not universal style rules.

### Limits

- This Skill does not guarantee identical pixels across image models, seeds, or tools.
- It does not directly edit images unless the host environment provides an image-editing tool and the user explicitly asks for execution.
- It does not handle face swaps, replacing the person, body reshaping, full scene replacement, or avatar generation.
- More real failed-image samples would improve future v1.1 quality check/fix precision.
