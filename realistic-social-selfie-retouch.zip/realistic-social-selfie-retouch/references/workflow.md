# Workflow

## Purpose

This Skill turns an ordinary selfie or casual portrait into a structured, realistic, social-media-ready retouch plan and Chinese AI editing prompt. The target is a XiaoHongShu/Pinterest-style refined photo that still looks like the same person in the same moment.

The workflow is intentionally narrow. It is not a general beauty generator, not a face swap, and not a full editorial remake.

## Input Material Check

Before writing or editing, inspect the available input:

1. Is there a selfie or casual portrait?
2. Is the subject identity visible enough to preserve?
3. Is the user asking for realistic retouching rather than replacement?
4. Is the scene visible enough to route the style?
5. Is the clothing/pose visible enough to preserve?
6. Did the user request a direct image edit or only a prompt?

If the image is too unclear to analyze a category, write “无法判断” instead of inventing details.

If there is no image, ask for one unless the user only wants a generic template.

## Task Type Decision

Trigger this workflow only when the core task is realistic selfie retouching:

- keep the same person
- improve skin, makeup, lighting, color, and background neatness
- preserve the real selfie feel
- produce a six-part analysis and final AI retouch prompt, or execute the edit if explicitly requested

Reject or reroute if the request is actually:

- changing identity
- replacing a person
- changing body shape
- turning the person into an anime/avatar/model
- full scene replacement
- commercial studio shoot reconstruction
- eroticized or age-inappropriate styling

## First Success Condition Confirmation

Before final output, restate internally:

The final image must still read as the same person in the same casual photo moment, with improved makeup, cleaner skin, better light/color, weaker background clutter, and visible real skin texture.

If a proposed edit would damage identity or selfie authenticity, do not apply it.

## Resource Role Assignment

Assign roles before writing:

- Uploaded photo: identity, face proportions, expression, pose, outfit subject, hairstyle direction, scene, camera angle, original authenticity.
- User style request: target platform feeling, such as XiaoHongShu, Pinterest, Instagram, hotel, bedroom, night, coffee shop, street, or travel.
- Original workflow prompt: six-part output contract and retouch logic.
- Latest success case: calibration sample for realism and identity preservation, not a universal look.
- Failure descriptions: do-not list, quality checks, and focused fixes.

Never let a style word override identity.

## Main Execution Flow

### Step 1: Original Photo Analysis

Write concrete observations:

- facial features and face shape
- hairstyle and hair state
- expression and pose
- selfie angle and framing
- makeup state: 素颜 / 淡妆 / 浓妆 / 伪素颜 / 夜景妆 / 无法判断
- outfit style: 辣妹 / 休闲 / T恤牛仔 / 吊带 / 裙装 / 通勤 / 韩系 / Y2K / 甜酷 / 简约 / 无法判断
- scene: 酒店 / 卧室 / 浴室 / 电梯 / 街头 / 咖啡店 / 商场 / 车内 / 户外 / 夜景 / 旅行 / 无法判断
- current problems: dark face, underexposure, dull skin, oil shine, dark circles, acne marks, redness, uneven color, messy background, yellow/green cast, ordinary framing, heavy selfie feel, low premium feeling

### Step 2: Retouch Direction Selection

Choose by environment first, outfit second:

- Hotel, night indoor, mirror selfie plus cami/dress/black tight outfit: 小红书酒店辣妹高级感
- T-shirt/jeans/casual plus street, coffee shop, travel, natural light: ins 松弛感 / Pinterest 日常感
- White wall, bedroom, window, minimal indoor: Pinterest 清冷网感 / 韩系清透自拍感
- Car, elevator, mall, night, neon: 都市夜景氛围感 / 小红书辣妹自拍感
- Beach, sun, vacation: 自然度假氛围感 / 轻欧美 ins 风

If multiple match, explain the choice. If uncertain, choose the least destructive realistic direction.

### Step 3: Makeup Plan

Design makeup that fits the chosen direction. Do not apply every makeup element at maximum strength.

Write separate adjustments for:

- base makeup
- eye makeup
- brows
- blush
- contour
- highlight
- lips

### Step 4: Skin Texture Plan

Clean but alive:

Remove or reduce: dullness, acne marks, redness, dark circles, uneven tone, dirty local shadows, oversized pore appearance.

Retain: real pores, fine texture, natural facial structure, original facial proportions, normal skin micro-relief, recognizable details.

Do not write only “不要磨皮”. Prefer positive controls such as “保留清晰可见的皮肤毛孔和真实纹理”.

### Step 5: Lighting and Color Plan

Match the scene:

- Hotel: low-saturation warm tone, soft shadow, clean face lift, mild background blur
- Street: natural light, slightly warm temperature, light film feeling, reduced background clutter
- Coffee shop: creamy warm tone, soft light, life feeling, mild background blur
- Bedroom/white wall: cool white or cream tone, low contrast, clean soft light, quiet clear feeling
- Night: keep dark environment, clean visible face, natural local light, light grain, no dirty shadows

### Step 6: Background Plan

Keep the original scene category. Hotel stays hotel, street stays street, bedroom stays bedroom.

Allowed:

- reduce clutter
- soften secondary background objects
- unify background color
- add mild depth
- enhance existing atmosphere

Forbidden:

- unrelated new scene
- fake studio set
- new props that change the story
- removing selfie authenticity

### Step 7: Composition Plan

Allowed:

- slight crop
- straighten
- improve head/shoulder ratio
- place subject more comfortably
- keep a natural selfie feeling

Forbidden:

- body reshaping
- face length/width change
- pose replacement
- clothing reshaping
- camera perspective rewrite

## Output Format

Always output:

① 原图分析:人物、场景、穿搭、妆容、光线和照片问题。
② 推荐精修方向:这张最适合哪种风格,为什么。
③ 妆容调整方案:底妆、眼妆、眉毛、腮红、修容、高光、唇妆分别怎么调。
④ 光影色调方案:光线、色温、色调、对比度、颗粒度、背景虚化怎么处理。
⑤ 最终 AI 修图提示词:一条完整中文提示词,可直接粘进修图工具。
⑥ 负面提示词:需要避免的问题。

## Failure Diagnosis Flow

If output is attractive but wrong, diagnose in this order:

1. Identity drift: did the face become another person?
2. Texture failure: did skin become wax/plastic or overly smooth?
3. Scene failure: did the environment change too much?
4. Makeup failure: is makeup too heavy or template-like?
5. Lighting failure: is the face overexposed, greasy, gray, green, or yellow?
6. Selfie authenticity failure: does it look like a fake studio photo?
7. Prompt structure failure: did the answer omit one of the six required sections?

Use only one main focused fix and, if necessary, one secondary focused fix.

## When to Stop

Stop when:

- identity is preserved
- scene remains recognizable
- skin is clean but textured
- makeup matches the chosen scene/style
- lighting and color are polished but believable
- background supports the subject without becoming a new scene
- the six-part output is complete

Do not keep adding beautification after these pass.

## When to Return to Task Decision or Resource Roles

Return to task routing if the user actually wants replacing the person, body transformation, cosplay, complete scene replacement, or style transfer.

Return to resource roles if multiple layers conflict, such as a style request trying to override identity, a success case trying to impose its hotel look on a street photo, or a makeup reference trying to change facial structure.
