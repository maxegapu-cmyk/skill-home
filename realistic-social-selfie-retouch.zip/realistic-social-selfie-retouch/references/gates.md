# quality checks

Each quality check catches “looks good but failed” cases. Run quality checks after producing the final prompt or evaluating an edited result.

## quality check 1: Task Route quality check

Checks: Is this realistic selfie retouching?

Why important: This Skill should not handle person replacement, complete visual rewrite, or body reshaping.

Pass standard: User wants same-person natural beautification and social-platform polish.

Failure表现: User asks to replace face/person, change body, make anime, change scene entirely, or generate a new person.

focused fix: No focused fix. Reroute to the correct workflow.

Hard failure: Any explicit person replacement request.

## quality check 2: Identity Preservation quality check

Checks: Same facial features, face shape, proportions, age impression, expression, and recognizable identity.

Why important: The task fails if the person becomes prettier but no longer the same person.

Pass standard: First glance reads “same person, better state”.

Failure表现: enlarged eyes, reshaped nose, changed lips, slimmer face, new jawline, younger/older look, influencer template face.

focused fix: focused fix_Identity_Lock.

Hard failure: Face reads as a different person.

## quality check 3: Selfie Moment quality check

Checks: Same pose, gesture, gaze/expression, clothing subject, hairstyle direction, camera angle, and scene category.

Why important: Social retouch must improve the original moment, not replace it.

Pass standard: Same selfie/casual photo moment remains.

Failure表现: studio pose, new body angle, changed gesture, replaced clothing, new scene, over-composed editorial shot.

focused fix: focused fix_Selfie_Moment_Recovery.

Hard failure: Original photo moment is gone.

## quality check 4: Skin Texture quality check

Checks: Clean but real skin.

Why important: XiaoHongShu/Pinterest realism collapses when skin becomes waxy or plastic.

Pass standard: blemishes/dullness reduced, pores and micro-texture still visible.

Failure表现: poreless skin, wax face, plastic AI smoothing, overexposed skin, oily fake highlight.

focused fix: focused fix_Real_Skin_Texture.

Hard failure: skin has no real texture.

## quality check 5: Makeup Fit quality check

Checks: Makeup matches scene, outfit, and original face.

Why important: Wrong makeup makes the edit look like a template.

Pass standard: makeup improves polish without overriding identity or scene mood.

Failure表现: heavy false lashes, overdone eyeliner, too much contour, greasy lip, nightclub makeup on casual daylight photo.

focused fix: focused fix_Makeup_Fit.

Hard failure: makeup changes facial structure or expression.

## quality check 6: Light and Color quality check

Checks: lighting, color temperature, contrast, grain, and exposure are believable for the scene.

Why important: Bad color or overexposure creates AI/cheap filter feeling.

Pass standard: face is clean and readable; scene light still makes sense.

Failure表现: gray/green/yellow skin, blown highlights, dirty shadows, mismatched face lighting, over-sharpened image.

focused fix: focused fix_Light_Color.

Hard failure: face lighting obviously does not belong to the scene.

## quality check 7: Background Continuity quality check

Checks: Original environment category is preserved.

Why important: The user asked for realistic retouch, not scene replacement.

Pass standard: background is cleaner and more atmospheric but still the same type of place.

Failure表现: hotel becomes studio, bedroom becomes commercial set, street becomes unrelated café, too much background blur.

focused fix: focused fix_Background_Continuity.

Hard failure: new scene created without request.

## quality check 8: Output Contract quality check

Checks: Six required sections are present and actionable.

Why important: The Skill is also a prompt-design workflow, not just an image aesthetic.

Pass standard: all sections ①-⑥ are present; section ⑤ is a complete prompt; section ⑥ includes negative controls.

Failure表现: only a prompt, no analysis; no negative prompt; vague makeup plan; no identity lock.

focused fix: focused fix_Output_Contract.

Hard failure: final prompt lacks identity preservation.
