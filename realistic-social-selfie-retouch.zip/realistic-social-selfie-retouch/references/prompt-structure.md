# Prompt Structure

## Main Output Module Order

Always answer in this order:

1. 原图分析
2. 推荐精修方向
3. 妆容调整方案
4. 光影色调方案
5. 最终 AI 修图提示词
6. 负面提示词

Do not skip section 5 or 6. Do not output only a generic prompt unless the user explicitly asks for a short prompt.

## Module Responsibilities

### ① 原图分析

Responsible for grounding the edit in the actual photo.

Must include:

- person/facial read
- scene
- outfit
- makeup state
- lighting
- photo problems

Use “无法判断” when unclear.

### ② 推荐精修方向

Responsible for choosing one retouch route.

Use scene first, outfit second. Explain why this route fits this photo.

### ③ 妆容调整方案

Responsible for makeup-specific edits.

Must separate:

- 底妆
- 眼妆
- 眉毛
- 腮红
- 修容
- 高光
- 唇妆

### ④ 光影色调方案

Responsible for photographic finish.

Must cover:

- light
- color temperature
- tone
- contrast
- grain
- background blur or depth

### ⑤ 最终 AI 修图提示词

Responsible for a directly usable Chinese prompt.

Must include:

- edit uploaded photo only
- preserve identity, face shape, proportions, hairstyle direction, clothing subject, expression, pose
- selected style direction
- makeup plan
- skin cleanup plus real texture retention
- light/color treatment
- background cleanup while preserving original environment
- natural XiaoHongShu/Pinterest social-photo feel
- no AI plastic or over-retouched look

### ⑥ 负面提示词

Responsible for blocking common failure modes.

Must include the fixed negative family, optionally extended for this image.

## Non-Optional Modules

Never omit:

- identity lock
- skin texture preservation
- scene continuity
- platform style direction
- positive final prompt
- negative prompt

## Replaceable Modules

These can change per image:

- style direction
- makeup strength
- color temperature
- contrast level
- grain level
- crop suggestion
- background depth

## Short Start Card

Use this internally when time is short:

```text
Route as realistic selfie retouch. Uploaded photo owns identity, face proportions, expression, pose, clothing, hairstyle direction, scene, and selfie camera logic. Analyze this photo from scratch. Choose scene-first style direction. Output six parts: 原图分析, 推荐精修方向, 妆容调整方案, 光影色调方案, 最终AI修图提示词, 负面提示词. Final prompt must preserve same person, real skin texture, original environment, and selfie authenticity while improving makeup, skin, light, color, and background neatness.
```

## Full Production Prompt Template

```text
请只编辑上传的原图,不要换脸,不要重新生成另一个人。完整保留原人物的五官特征、脸型轮廓、五官比例、年龄感、表情、视线方向、姿态、发型大方向、服装主体和原始场景氛围。修完后第一眼必须仍然是同一个人,只是像本人状态最好、妆造最好、光线最好的一天。

根据这张照片的场景和穿搭,将整体优化为【填入风格方向】。妆容调整为【填入妆容方案】:底妆干净通透但不过度磨皮,眼妆【填入眼妆】,眉毛【填入眉毛】,腮红【填入腮红】,修容【填入修容】,高光【填入高光】,唇妆【填入唇妆】。

改善肤色暗沉、黑眼圈、泛红、痘印、肤色不均和局部脏阴影,但保留清晰可见的真实皮肤纹理、细小毛孔、自然面部结构和真人皮肤微小起伏。皮肤要干净有气色,不能变成蜡像、塑料皮或AI磨皮假脸。

优化原图光线、色温、色调、对比度和颗粒度:【填入光影色调方案】。脸部清晰干净,光线自然贴合原场景,不过曝、不发灰、不发黄、不发绿。背景保留原始环境大方向,只降低杂乱感、轻微虚化次要物体、统一色调并增强氛围,不要凭空换成无关场景或商业棚拍。

允许轻微裁切和拉正画面,优化头肩比例和主体位置,但必须保持身体比例、脸的长度和宽度、体型、服装版型、姿态和自拍真实感。整体呈现自然真实的小红书/Pinterest网感精修照,像懂行摄影师顺手拍到的好状态,不像AI生成,不像过度精修。
```

## Fixed Negative Prompt Foundation

```text
AI塑料感,过度磨皮,蜡像皮肤,油亮假高光,脸部油光,皮肤过曝,五官变形,脸型改变,眼睛过大,鼻子变形,嘴巴变形,网红脸模板化,假睫毛过重,妆容过浓,肤色发灰,肤色发绿,肤色发黄,背景脏乱,背景虚化过度,手指变形,身体比例错误,服装变形,头发融化,边缘模糊,过度锐化,假棚拍感,失去自拍真实感
```

## Self-Check Card

Before final answer, verify:

1. Same person?
2. Same face proportions?
3. Same expression and pose?
4. Real skin texture preserved?
5. Original scene category preserved?
6. Retouch direction chosen from this exact image?
7. Six sections complete?
8. Negative prompt included?
