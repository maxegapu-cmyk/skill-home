# Resource Roles

## Core Principle

Every input can only control the layer it is authorized to control. The uploaded selfie is always the highest source of truth for identity and photo reality.

## Uploaded Selfie

Owns:

- person identity
- face shape and facial proportions
- eyes, nose, mouth, brows, cheek/chin/jaw relationships
- age impression
- expression and gaze direction
- pose and gesture
- body proportion
- clothing subject and visible clothing structure
- hairstyle direction and broad hair layout
- scene category
- camera angle, crop, perspective, and selfie authenticity

Does not allow:

- replacement identity
- new face template
- new body shape
- unrelated scene
- new camera logic that makes it no longer the same photo moment

## User Style Request

Owns:

- desired social-platform feeling
- strength of retouch
- target style direction such as XiaoHongShu, Pinterest, Korean clear selfie, hotel warm tone, urban night vibe

Does not own:

- face structure
- age/race identity
- body shape
- scene replacement unless explicitly requested and routed outside this Skill

## Original Workflow Prompt

Owns:

- six-part output format
- identity lock
- scene-first style selection
- makeup categories
- skin texture rule
- light/color/background/crop treatment
- default negative prompt family

Does not own:

- a fixed look for every photo
- mandatory hotel/warm/cozy aesthetics
- any single face type or makeup type

## Latest Success Case

Owns:

- calibration for successful balance: same person plus better makeup, cleaner skin, warmer light, softer background, real selfie feeling
- proof that strong improvement can still preserve identity
- regression example for warm indoor/hotel-like selfie retouch

Does not own:

- universal warm color grading
- universal wink expression
- universal bedroom/hotel scene
- universal black hair or white top
- universal “sweet” makeup direction

## Failure Cases and Failure Boundaries

Own:

- do-not rules
- quality check checks
- focused fix triggers
- negative control tests

They should never become new style goals. A failure case only says what to avoid.

## Old Prompt

Owns:

- v1.0 baseline workflow and exact deliverable structure
- required analysis granularity
- fixed negative prompt foundation

Does not replace visual inspection. Every new image must be analyzed again.

## Final Successful Prompt and Result

Own:

- proof of a working prompt structure
- example of how to phrase identity preservation, skin realism, makeup polish, lighting, and scene continuity

Do not copy its case-specific visual content into unrelated tasks.

## User Approval Standard

Owns:

- acceptance threshold
- final judgement of whether the balance feels right
- evidence that the v1.0 route works

If user approval conflicts with generic beauty trends, user approval wins.

## Forbidden Cross-Contamination

Do not allow:

- success-case scene details to leak into new photos
- makeup style to override face identity
- platform style to change age or race impression
- beautification to enlarge eyes, reshape nose/mouth, or slim face/body
- background cleanup to become background replacement
- skin cleanup to erase real pores and texture
