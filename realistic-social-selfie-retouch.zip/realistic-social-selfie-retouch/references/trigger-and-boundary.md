# Trigger and Boundary

## Should Trigger

Use this Skill when the user uploads or references a selfie/casual portrait and asks for realistic social-platform retouching while preserving the person.

Clear triggers:

- “按这套逻辑精修这张自拍”
- “小红书网感精修”
- “Pinterest 自拍精修”
- “自然真实变美”
- “把这张随手拍修高级”
- “保留本人特征修好看”
- “不要AI感,不要网红脸”
- “给我分析这张自拍该怎么修”
- “输出最终AI修图提示词”
- “对这个进行使用,根据这个提示词精修”

Implicit triggers:

- The user asks for “本人状态最好的一天”.
- The user asks for “真实皮肤纹理” and “小红书/Pinterest”.
- The user wants makeup, skin, lighting, color, background, and crop improvements, not a new person.
- The user asks for a six-part analysis and final retouch prompt.

## Should Not Trigger

Do not use this Skill for:

- “图二替换图一” or “把另一个人换进来”.
- “只换脸其他别动”.
- “把整张照片改成另一种完全不同的画面”.
- “生成一个美女日常照片” from scratch.
- “做成古风/动漫/角色写真” if the request changes identity or scene substantially.
- Product photography, UI design, poster design, spreadsheet/document tasks.
- Body slimming, height/weight reshaping, age change, race change.
- Sexualized styling, especially if age is ambiguous.

## Easy Misroutes

### Mistake 1: Treating selfie retouch as face swap

Wrong: replacing the face with a prettier identity.

Correct: keep the same face structure, proportions, age impression, expression, and recognizable identity.

### Mistake 2: Treating social polish as full studio remake

Wrong: replacing bedroom/hotel/street with a polished studio background.

Correct: keep the original environment category and improve only light, color, depth, and clutter.

### Mistake 3: Applying the latest success look to every case

Wrong: warm hotel lamp, cozy bed, wink, black hair, and white top become universal.

Correct: these are latest-success case details only. Each new image must be routed by its own scene and outfit.

### Mistake 4: Making skin too perfect

Wrong: waxy, poreless, plastic AI face.

Correct: clean tone, reduced blemishes, visible pores and natural micro-texture.

## Under-triggering Risk

The Skill may fail to load if the description only says “retouch image” or “beauty prompt”. Include real user phrases such as “小红书网感精修”, “Pinterest自拍精修”, “保留本人特征”, and “自然真实变美”.

## Over-triggering Risk

The Skill may load for unrelated image editing if the description is too broad. Explicitly exclude face swaps, replacing the person, style transfer, full scene replacement, body reshaping, and from-scratch beauty generation.

## Recommended Description Logic

Description should contain:

1. What it does: six-part realistic selfie retouch analysis and Chinese AI edit prompt.
2. When to use it: uploaded selfie/casual portrait, XiaoHongShu/Pinterest/social-photo retouch, preserve identity.
3. Trigger phrases: direct Chinese phrases users actually say.
4. Negative scope: not for replacement, body reshaping, full scene replacement, or avatar generation.

## Bad Description Patterns

Avoid:

- “Helps optimize images.”
- “Improves beauty photos.”
- “Processes portrait prompts.”
- “Advanced image editing workflow.”
- “Makes photos better.”

These are too broad and cause over-triggering.
