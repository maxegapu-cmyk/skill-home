#!/usr/bin/env python3
"""Validate the realistic-social-selfie-retouch Skill package.

Usage:
    python scripts/validate_skill.py .

Inputs:
    One optional path to the skill root. Defaults to current directory.

Outputs:
    Prints validation findings and exits with 0 on pass, 1 on failure.

Dependencies:
    Python standard library only. No network access, no external packages.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

REQUIRED_REFERENCES = [
    "workflow.md",
    "trigger-and-boundary.md",
    "resource-roles.md",
    "prompt-structure.md",
    "gates.md",
    "patches.md",
    "examples.md",
    "tests.md",
    "changelog.md",
]

KEBAB = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        raise ValueError("SKILL.md must start with YAML frontmatter delimiter ---")
    end = text.find("\n---", 4)
    if end == -1:
        raise ValueError("SKILL.md must contain a closing YAML frontmatter delimiter ---")
    block = text[4:end].strip().splitlines()
    data: dict[str, str] = {}
    for line in block:
        if not line.strip() or line.startswith(" ") or line.startswith("metadata:"):
            continue
        if ":" in line:
            key, value = line.split(":", 1)
            data[key.strip()] = value.strip().strip('"').strip("'")
    return data


def fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    raise SystemExit(1)


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    root = root.resolve()

    if not root.exists() or not root.is_dir():
        fail(f"skill root does not exist or is not a directory: {root}")

    folder_name = root.name
    if not KEBAB.match(folder_name):
        fail(f"folder name is not kebab-case: {folder_name}")

    skill_md = root / "SKILL.md"
    if not skill_md.exists():
        fail("missing SKILL.md")

    wrong_names = [p.name for p in root.iterdir() if p.name.lower() == "skill.md" and p.name != "SKILL.md"]
    if wrong_names:
        fail(f"invalid SKILL.md casing found: {wrong_names}")

    if (root / "README.md").exists():
        fail("README.md must not be inside the skill folder")

    text = skill_md.read_text(encoding="utf-8")
    try:
        frontmatter = parse_frontmatter(text)
    except ValueError as exc:
        fail(str(exc))

    name = frontmatter.get("name", "")
    description = frontmatter.get("description", "")

    if not name:
        fail("frontmatter missing name")
    if not description:
        fail("frontmatter missing description")
    if not KEBAB.match(name):
        fail(f"name is not kebab-case: {name}")
    if name != folder_name:
        fail(f"frontmatter name {name!r} does not match folder name {folder_name!r}")
    if "<" in description or ">" in description:
        fail("description must not contain XML angle brackets")
    if len(description) > 1024:
        fail("description exceeds 1024 characters")

    refs = root / "references"
    if not refs.exists() or not refs.is_dir():
        fail("missing references/ directory")

    missing = [r for r in REQUIRED_REFERENCES if not (refs / r).exists()]
    if missing:
        fail(f"missing reference files: {missing}")

    scripts = root / "scripts"
    if scripts.exists():
        validator = scripts / "validate_skill.py"
        if not validator.exists():
            fail("scripts/ exists but validate_skill.py is missing")

    print(f"OK: {name} v1.0.0 skill structure is valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
