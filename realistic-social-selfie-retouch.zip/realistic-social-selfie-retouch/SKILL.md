---
name: realistic-social-selfie-retouch
description: Creates a six-part XiaoHongShu/Pinterest-style realistic selfie retouch plan and Chinese AI image-edit prompt while preserving the original person's identity, face proportions, expression, pose, clothing, hairstyle direction, and scene. Use when the user uploads a normal selfie or casual portrait and says phrases like “按这套逻辑精修”, “小红书网感精修”, “Pinterest自拍精修”, “自然真实变美”, “保留本人特征修好看”, or “把这张随手拍修成高级网感照”. Do NOT use for face swaps, replacing the person with someone else, body reshaping, full scene replacement, cosplay transformation, commercial studio remake, avatar generation, or sexualized edits.
metadata:
  version: 1.0.0
  category: image-editing-prompt-workflow
  output_language: zh-CN
---

# Realistic Social Selfie Retouch

## First Success Condition

The edited image must read as the same person in the same casual photo moment, with cleaner skin, better makeup, better light, and stronger XiaoHongShu/Pinterest social-photo polish, while still retaining visible real skin texture and selfie authenticity.

## When to Use

Use this Skill when all of these are true:

1. The user provides a selfie, casual portrait, or ordinary daily photo of one person.
2. The goal is realistic natural beautification, makeup refinement, light/color improvement, and social-media-ready polish.
3. The user wants a structured analysis, a reusable Chinese AI retouch prompt, or direct image-edit guidance.
4. The desired output is still the same person, not a new identity, not a generated model, and not a full fashion/studio reconstruction.

Typical triggers include: “对这个使用”, “根据这个提示词精修”, “小红书精修”, “Pinterest网感”, “真实自然变美”, “本人状态最好”, “不要AI感”, “保留本人五官”, “把普通自拍修高级”.

## When Not to Use

Do not use this Skill for:

- Face swap or replacing one person with another.
- Replacing the original person with a different person or character.
- Complete visual rewrite or complete scene replacement.
- Fashion editorial generation from scratch.
- Anime/avatar/idol-face transformation.
- Body reshaping, age transformation, race/ethnicity transformation, or sexualized retouching.
- Product, interior, poster, UI, document, spreadsheet, or video-only tasks.

If the request is person replacement, complete visual rewrite, complete scene replacement, or makeup extraction from a separate reference image, this Skill should not handle it. Use a separate workflow suited to that task.

## Core Workflow

1. Identify task type: confirm this is realistic selfie/portrait retouching, not replacement or full transformation.
2. Assign input/resource roles: the uploaded selfie is the identity, pose, clothing, hairstyle-direction, expression, and scene source of truth.
3. Analyze the photo from scratch: person, facial features, face shape, hairstyle, expression, pose, angle, makeup state, clothing, scene, lighting, and current photo problems. Say “无法判断” for unclear items.
4. Choose a retouch direction by scene first and outfit second. Do not reuse a previous photo’s style blindly.
5. Design makeup, skin, light/color, background, and crop adjustments that fit this exact photo.
6. Produce the required six-part output and a complete Chinese AI retouch prompt.
7. Run quality checks. If a quality check fails, route to one focused fix and preserve already-correct layers.
8. Stop when identity, real skin texture, scene continuity, and platform-ready social-photo polish all pass.

## Resource Role Summary

- Uploaded selfie: highest truth for identity, facial proportions, face shape, expression, pose, body proportion, clothing subject, hairstyle direction, scene type, camera angle, and selfie authenticity.
- Original workflow prompt: v1.0 baseline for six-part output, identity lock, scene-based style routing, makeup/skin/light/background/crop logic, and fixed negative prompt family.
- Latest success case: proof that warm indoor/hotel selfie retouch can improve polish while keeping the same wink, pose, hair, cozy room, and authentic social-photo feeling.
- Final successful image result: visual target for “same person, cleaner and warmer, better makeup/light, not a new AI model”. It is not a universal style template.
- User approval standard: the strongest acceptance signal. Preserve “效果太好了,特别好” as evidence that this workflow’s realism and identity-preservation balance is correct.
- Failure boundaries: identity drift, plastic skin, over-smoothing, fake studio lighting, scene replacement, enlarged eyes, altered nose/mouth, heavy false lashes, waxy highlights, and loss of selfie reality.

Never let the success case’s hotel room, warm lamp, wink, black hair, white top, or cozy bed become mandatory universal content. Those are case-only details.

## Output Contract

Always output six parts in Chinese unless the user explicitly requests another language:

1. ① 原图分析
2. ② 推荐精修方向
3. ③ 妆容调整方案
4. ④ 光影色调方案
5. ⑤ 最终 AI 修图提示词
6. ⑥ 负面提示词

If the user explicitly asks to directly edit/generate and the environment has an image editing tool, compile the prompt first internally, run the edit, then report only the result or a short note. Otherwise, provide the six-part text output.

## References Index

Read these files when needed:

- Full workflow: `references/workflow.md`
- Triggers and boundaries: `references/trigger-and-boundary.md`
- Resource roles: `references/resource-roles.md`
- Prompt structure: `references/prompt-structure.md`
- quality checks: `references/gates.md`
- focused fixes: `references/patches.md`
- Examples: `references/examples.md`
- Tests: `references/tests.md`
- Changelog: `references/changelog.md`

## Validation

If file integrity needs checking, run:

```bash
python scripts/validate_skill.py .
```
