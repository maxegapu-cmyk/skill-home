#!/usr/bin/env python3
"""短剧剧本质检 lint。

检查项：
  1. 对比否定句式（不是…而是 / 是…而不是 / 不像…倒像 / 并不是 / 没有…但也 / 与其说…不如说）
  2. 广告绝对化用语与功效承诺
  3. 小说化描写（感到、心中、仿佛……）
  4. 台词过长
  5. 每集是否有「卡点：」
  6. 品牌名在台词中的出现次数（每集建议 ≤ 1）
  7. 正文场次中缺少 ▲ 的动作行

用法：
  python3 lint_script.py 剧本.md [--brand 品牌名 --brand 别名] [--max-line 25]

只检查正文部分时，脚本会自动识别场次头（如「1-1  夜/内  场景：…」）之后的内容；
集纲与说明性文字只做句式与合规检查。
"""
import argparse
import re
import sys
from collections import defaultdict

CONTRAST_PATTERNS = [
    (r"不是[^。！？!?\n]{0,40}?而是", "不是……而是……"),
    (r"并不是", "并不是……"),
    (r"是[^。！？!?\n]{1,30}?而不是", "是……而不是……"),
    (r"不像[^。！？!?\n]{0,40}?倒像", "不像……倒像……"),
    (r"没有[^。！？!?\n]{0,30}?但也", "没有……但也……"),
    (r"与其说[^。！？!?\n]{0,40}?不如说", "与其说……不如说……"),
    (r"不是[^。！？!?\n]{0,20}?，?是[^否]", "不是……，是……（疑似）"),
]

AD_WORDS = [
    "最好的", "最佳", "最低价", "最便宜", "最强", "最顶级", "最高级", "最正宗",
    "唯一", "顶级", "极品", "国家级", "世界级", "全网最", "全国第一", "销量第一",
    "100%", "百分百", "根治", "治愈", "治好", "治疗", "疗效", "药用", "包治",
    "美白", "减肥", "瘦身", "祛斑", "祛湿", "排毒", "延年益寿", "抗衰",
]

# 「最X」与「第一」用正则查，排除常见非广告用法
AD_REGEX = [
    (re.compile(r"最(?![后近初终少多早晚先底下上里外想前]|好(?!的))[\u4e00-\u9fa5]"), "最X"),
    (re.compile(r"第一(?![集场次眼天个句步口时遍回轮声件页条位排帧])"), "第一"),
]

NOVEL_WORDS = [
    "感到", "心中", "内心深处", "仿佛", "似乎", "五味杂陈", "百感交集",
    "眼神中闪过", "眼中闪过", "与此同时", "不禁", "心里一", "心头一",
]

EPISODE_RE = re.compile(r"^\s*#*\s*(?:【)?第\s*([0-9一二三四五六七八九十百]+)\s*集")
SCENE_RE = re.compile(r"^\s*(\d+)\s*[-－]\s*(\d+)\b")
DIALOGUE_RE = re.compile(r"^\s*([^\s▲【#：:（(]{1,8}?)(?:OS|VO)?\s*(?:（[^）]{0,12}）|\([^)]{0,12}\))?\s*[：:]\s*(.+)$")
NON_ROLE_PREFIX = ("卡点", "场景", "人物", "字幕", "【", "产品", "弹簧", "注", "备注")


def is_dialogue(line):
    m = DIALOGUE_RE.match(line)
    if not m:
        return None
    role = m.group(1)
    if role.startswith(NON_ROLE_PREFIX) or role.endswith("特写") or "特写" in role:
        return None
    return role, m.group(2).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--brand", action="append", default=[], help="品牌名或别名，可多次指定")
    ap.add_argument("--max-line", type=int, default=25, help="台词超长报警阈值（字）")
    ap.add_argument("--all", action="store_true", help="广告用语检查覆盖全文（方案、小传、集纲），交付前建议开启")
    args = ap.parse_args()

    with open(args.path, encoding="utf-8") as f:
        lines = f.read().splitlines()

    issues = defaultdict(list)
    episode = None
    episodes_seen = []
    ep_has_kadian = {}
    ep_has_scene = {}
    brand_counts = defaultdict(int)
    in_scene = False
    in_code = False
    dialogue_lengths = []

    for no, raw in enumerate(lines, 1):
        line = raw.rstrip()
        if line.strip().startswith("```"):
            in_code = not in_code
        m_ep = EPISODE_RE.match(line)
        if m_ep:
            episode = m_ep.group(1)
            if episode not in ep_has_kadian:
                episodes_seen.append(episode)
                ep_has_kadian[episode] = False
                ep_has_scene[episode] = False
            in_scene = False
        if line.lstrip("#").strip().startswith("##") or re.match(r"^#{1,2}\s", line):
            # 大标题：离开正文场次
            if not m_ep:
                in_scene = False
        if SCENE_RE.match(line):
            in_scene = True
            if episode is not None:
                ep_has_scene[episode] = True
            continue
        text = line.strip()
        if not text:
            continue
        if text.startswith("卡点") and episode is not None:
            ep_has_kadian[episode] = True

        tag = f"L{no}" + (f" 第{episode}集" if episode else "")
        dlg = is_dialogue(text)

        # 1 对比否定
        for pat, name in CONTRAST_PATTERNS:
            m = re.search(pat, text)
            if m:
                where = "台词（人物自然否认可保留）" if dlg else "描写"
                issues["对比否定句式"].append(f"{tag} [{where}] {name}：…{text[max(0, m.start()-8):m.end()+8]}…")
                break  # 每行只报一次

        # 2 广告用语（只查正文、台词与片尾字幕；策划说明、节拍标注不查）
        if text.startswith("【片尾") or text.startswith("【字幕"):
            in_scene = True
        is_note = text.startswith(("【产品节拍", "【弹簧", "【注", "【备注"))
        check_ad = (in_scene or args.all) and not is_note
        if check_ad:
            for w in AD_WORDS:
                if w in text:
                    issues["广告绝对化/功效用语"].append(f"{tag} 「{w}」：{text[:60]}")
            for rx, name in AD_REGEX:
                m = rx.search(text)
                if m and not any(w in text for w in AD_WORDS):
                    issues["广告绝对化/功效用语"].append(f"{tag} 「{m.group(0)}」（{name}，确认是否广告用语）：{text[:60]}")

        # 3 小说化
        if in_scene and not dlg:
            for w in NOVEL_WORDS:
                if w in text:
                    issues["小说化描写"].append(f"{tag} 「{w}」：{text[:60]}")

        if in_scene:
            if dlg:
                role, content = dlg
                pm = re.match(r"^\s*[^：:]*?[（(]([^）)]*)[）)]\s*[：:]", text)
                if pm and len(pm.group(1)) > 4:
                    issues["台词括号情绪过长（>4字，应拆成▲行）"].append(f"{tag} {role}（{pm.group(1)}）")
                clean = re.sub(r"[（(][^）)]*[）)]", "", content)
                n = len(re.sub(r"[\s，。！？、…—“”\"'：:；;,.!?]", "", clean))
                dialogue_lengths.append(n)
                if n > args.max_line:
                    issues["台词过长"].append(f"{tag} {role}（{n}字）：{content[:40]}…")
                if args.brand and episode is not None:
                    for b in args.brand:
                        brand_counts[episode] += content.count(b)
            else:
                ok_prefix = ("▲", "卡点", "【", "#", ">", "-", "|", "*", "抖音", "剧中同款", "快手", "搜索")
                if not text.startswith(ok_prefix) and "特写" not in text[:12] and not in_code:
                    issues["正文缺少▲的动作行"].append(f"{tag}：{text[:50]}")

    for ep in episodes_seen:
        if ep_has_scene.get(ep) and not ep_has_kadian.get(ep):
            issues["缺少卡点"].append(f"第{ep}集 正文没有「卡点：」")
    for ep, c in brand_counts.items():
        if c > 1:
            issues["品牌名台词口播过多"].append(f"第{ep}集 台词中出现品牌名 {c} 次（建议 ≤1）")

    print(f"# 剧本 lint 报告：{args.path}\n")
    if dialogue_lengths:
        short = sum(1 for n in dialogue_lengths if n <= 15)
        print(f"台词共 {len(dialogue_lengths)} 句，≤15 字占 {short * 100 // len(dialogue_lengths)}%（建议 ≥ 70%）\n")
    if not issues:
        print("未发现问题。")
        return 0
    total = 0
    for k, v in issues.items():
        print(f"## {k}（{len(v)}）")
        for item in v[:60]:
            print(f"- {item}")
        if len(v) > 60:
            print(f"- ……另有 {len(v) - 60} 条")
        print()
        total += len(v)
    print(f"共 {total} 条提示。对比否定、广告用语、缺少卡点为必改；其余按语境判断。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
