# Changelog

## 1.0.0
- First public-ready release.
- Seven-layer editorial engine.
- Physical pose and camera-geometry compiler.
- Material/reality pass.
- Anti-AI rejection gate.
- Optional reference-control mode.
- Three production modes.
