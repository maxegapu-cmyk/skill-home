# Example — Mediterranean White

## Concept
A quiet post-swim luxury portrait where wet hair, white swimwear, limestone and late-afternoon sea light do most of the visual work.

## Main prompt
Adult East Asian woman in her mid-20s, refined oval face, long wet dark hair with loose strands, natural skin texture and minimal luminous makeup; white triangle bikini with small brushed-gold ring hardware and realistic wet/dry fabric variation. She kneels at the shallow edge of a Mediterranean infinity pool, left palm supporting her weight on pale limestone, torso turned slightly toward camera, shoulders relaxed, gaze calm and direct. Three-quarter environmental portrait, camera at upper-abdomen height, mild 65 mm portrait perspective, subject placed just left of center, foreground stone softly entering the lower edge, sea and white hillside architecture falling into gentle optical blur. Late-afternoon side light from camera-right, warm highlights tracing wet hair and shoulders, soft reflected pool light lifting the shadow side of the face. Fine water beads, subtle fabric tension, tiny seam details, believable skin compression at the supporting palm and knee, coherent reflections and horizon perspective. Photographic realism, restrained retouching, natural skin texture, coherent anatomy, believable fabric tension, optical depth, editorial color separation, no synthetic beauty-filter look.

## Avoid
child, teen, underage, plastic skin, wax face, extreme beauty filter, malformed hands, duplicate straps, impossible bikini construction, broken torso, extreme wide-angle distortion, fake logo, text artifacts, CGI look, uniform sharpness, oversaturated water.

## Alternate shot
Full-body side-profile walking shot at ankle-deep water, camera near hip height and farther back; preserve the same wardrobe, hair state, light direction and location palette.
