# Swimwear Editorial Brief

Subject: adult, 21+
Vibe: 
Swimwear: 
Location: 
Time: 
Framing: 
Optional identity reference: none
Optional pose reference: none
Optional location reference: none
Optional style reference: none

Priority: photographed realism > anatomy > garment credibility > lighting > polish.
