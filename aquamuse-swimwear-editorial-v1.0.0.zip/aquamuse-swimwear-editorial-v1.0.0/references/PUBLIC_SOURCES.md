# Public reference notes

These links are for optional technical reading only; AquaMuse itself is independently designed.

- ComfyUI official workflow templates:
  https://github.com/Comfy-Org/workflow_templates
- ComfyUI official ControlNet concept documentation:
  https://github.com/Comfy-Org/workflow_templates/blob/main/site/knowledge/concepts/controlnet.md
- ComfyUI official IP-Adapter concept documentation:
  https://github.com/Comfy-Org/workflow_templates/blob/main/site/knowledge/concepts/ip-adapter.md
- ComfyUI Impact Pack:
  https://github.com/comfyorg/comfyui-impact-pack
- ComfyUI ControlNet auxiliary preprocessors documentation:
  https://github.com/Comfy-Org/workflow_templates/blob/main/site/knowledge/custom-nodes/comfyui-controlnet-aux.md
