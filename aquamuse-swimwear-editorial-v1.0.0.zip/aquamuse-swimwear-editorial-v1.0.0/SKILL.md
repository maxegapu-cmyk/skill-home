# AquaMuse Swimwear Editorial v1.0.0

## Purpose
Create premium adult swimwear editorials that feel photographed, art-directed, and publication-ready rather than like generic AI glamour images.

## Scope
- Adult subjects only (explicitly 21+ when age is not otherwise established).
- Swimwear / resortwear / poolside / beach / yacht / spa / coastal editorial imagery.
- Works as a prompt-planning Skill for text-to-image and image-to-image systems.
- Designed to be model-agnostic. Optional references can be used with image-prompt / identity / pose-control systems.

## Core principle: SELECT BEFORE YOU DESCRIBE
Do not begin by listing beauty adjectives. First decide why an editor would keep this frame.

A finished frame must have:
1. one dominant visual idea;
2. one readable body action;
3. one light story;
4. one environmental anchor;
5. one tactile material contrast;
6. a believable camera position;
7. restrained styling.

If two or more of these are missing, rebuild the concept before generating.

## 7-Layer Editorial Engine

### L1 — Editorial Thesis
Write one sentence only.
Examples:
- "A quiet post-swim portrait where wet skin, white stone and hard Mediterranean light carry the luxury."
- "A sunset poolside fashion frame built around long silhouette, metallic fabric and negative space."

### L2 — Subject Identity
Describe only stable, visually useful traits:
- adult age band;
- face geometry;
- hair length / texture / state;
- skin finish;
- body silhouette in neutral language;
- expression energy.

Avoid adjective piles such as "perfect, gorgeous, stunning, flawless". They carry little structural information.

### L3 — Wardrobe Logic
Specify:
- garment type: one-piece / triangle bikini / bandeau / asymmetrical / sporty / retro;
- color family;
- fabric response: matte, ribbed, satin sheen, metallic knit, terry, textured lycra;
- construction detail: ring hardware, side ties, piping, ruching, high-cut leg, square neckline;
- one accessory maximum unless the concept is deliberately styled.

### L4 — Body Action
Use a physically readable verb + support surface + weight distribution.
Good:
- "kneeling at the shallow pool edge, weight on left palm, right shoulder relaxed"
- "reclining diagonally on a sunbed, one knee raised, torso turning toward the light"
- "walking out of ankle-deep water, left foot forward, hands loosely brushing wet hair"

Bad:
- "sexy pose"
- "beautiful posture"
- "dynamic pose"

### L5 — Camera Geometry
Always state:
- framing: close portrait / waist-up / 3/4 / full body / environmental portrait;
- camera height;
- viewing angle;
- distance or lens character;
- subject position in frame;
- depth relationship between foreground / subject / background.

Default premium portrait recipe:
- 3/4 environmental portrait;
- camera around upper-abdomen to chest height;
- mild 50–85 mm perspective;
- subject slightly off-axis;
- foreground texture present but not blocking anatomy;
- background recognizable but optically softened.

### L6 — Light Story
Choose ONE main lighting logic:
- hard noon sun + negative fill;
- late-afternoon side light;
- golden-hour backlight + frontal bounce;
- soft overcast coastal light;
- pool caustics + shaded face;
- indoor window light reflected from water.

Then specify what it does to skin, hair, garment and background.
Do not mix five cinematic lighting clichés in one prompt.

### L7 — Reality Pass
Add photographic evidence, not quality slogans:
- flyaway hair catching light;
- small beads of water;
- uneven wet/dry fabric zones;
- subtle pressure marks where skin meets chair/stone;
- real shadow falloff under chin and limbs;
- pores retained in lit facial areas;
- tiny textile seams and hardware reflections;
- horizon, architecture and pool edge obeying perspective.

## Anti-AI Gate
Reject or regenerate when any of these appear:
- doll-like face or wax skin;
- duplicated straps / jewelry;
- impossible swimsuit construction;
- broken clavicle / shoulder / ribcage transitions;
- hands fused into hair or furniture;
- overinflated anatomy created by lens distortion;
- waterline crossing the body impossibly;
- luxury background with no perspective logic;
- random brand logos/text artifacts;
- every surface equally sharp;
- face retouched harder than the body.

## Prompt Compiler
Build prompts in this order:

[EDITORIAL THESIS]
[ADULT SUBJECT]
[WARDROBE]
[BODY ACTION]
[CAMERA GEOMETRY]
[LIGHT STORY]
[ENVIRONMENT]
[MATERIAL / REALITY EVIDENCE]
[FINISH]

The order matters: concept and geometry must appear before polish.

## Default Finish
Use concise finishing language:
"photographic realism, restrained retouching, natural skin texture, coherent anatomy, believable fabric tension, optical depth, editorial color separation, no synthetic beauty-filter look"

## Negative / Avoid List
"child, teen, underage, youthful minor appearance, plastic skin, wax face, excessive beauty filter, malformed hands, fused fingers, duplicated limbs, duplicate straps, impossible bikini construction, broken anatomy, extreme lens distortion, floating jewelry, text artifacts, fake logo, flat lighting, uniform sharpness, oversaturated cyan water, CGI skin, game-render look"

## Reference-Control Mode (optional)
When using visual references, assign each reference one job only:
- identity reference -> face / identity;
- pose reference -> pose / body line;
- location reference -> space / architecture;
- style reference -> palette / light / finish.

Do not ask one image to control identity, pose, wardrobe, style and location at once unless the model is specifically built for multi-condition decomposition.

If using ComfyUI-like tooling:
- use pose/depth control for body and space;
- use identity/image adapters only as strongly as necessary;
- reduce reference strength when it begins copying composition or wardrobe unintentionally;
- face-detailing should be a late local pass, not the source of the entire facial design.

## Three Production Modes

### A. Clean Resort Editorial
For commercial, polished, luxury output.
- bright architecture;
- clear garment readability;
- medium contrast;
- restrained expression;
- clean body line.

### B. Cinematic Coastal Portrait
For stronger atmosphere.
- directional sun;
- foreground obstruction allowed;
- wind / wet hair;
- more environmental depth;
- skin remains natural.

### C. Fashion-Campaign Graphic
For bold cover/key art.
- simplified background geometry;
- stronger pose silhouette;
- controlled color pairing;
- hard shadow or sculptural light;
- minimal accessories.

## One-Click Brief Format
User can provide only:
- subject vibe;
- swimwear color/type;
- location;
- time of day;
- framing.

Missing fields should be chosen coherently rather than queried unless they materially alter the requested identity/reference.

## Output Format
Return:
1. Concept sentence
2. Main prompt
3. Avoid list
4. Optional reference-control notes
5. One alternate shot that changes camera geometry, not merely adjectives

## Final QA
A result passes only if:
- face, torso, hands and garment construction are credible;
- pose can be physically reenacted;
- light direction is consistent;
- environment has depth and scale;
- image has one visual hierarchy;
- skin/fabric/water are materially distinct;
- it feels like an editorial frame, not a generic beauty render.
