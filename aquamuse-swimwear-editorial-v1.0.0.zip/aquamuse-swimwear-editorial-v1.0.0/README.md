# AquaMuse Swimwear Editorial

An original prompt-planning Skill for high-end adult swimwear photography.

The system is built around editorial selection, camera geometry, physical pose logic, lighting, materials, and final defect rejection. It intentionally avoids relying on long adjective chains or named-photographer imitation.

## Quick start
Give the Skill a short brief such as:

> Adult East Asian woman, white bikini, Mediterranean infinity pool, late afternoon, three-quarter portrait, expensive but natural.

It should return one concept, one main prompt, an avoid list, reference-control notes when useful, and one alternate shot.

## Public technical inspirations
The package is independently authored, but its optional control-layer recommendations are compatible with publicly documented ideas such as:
- ComfyUI official workflow templates
- ControlNet pose/depth conditioning
- IP-Adapter visual conditioning
- ComfyUI Impact Pack / FaceDetailer

No third-party workflow, prompt template, or code is copied into this package.
