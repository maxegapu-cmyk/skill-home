# Codex：同一个“重连”提示可能来自不同层

仅在 Codex CLI、桌面版、IDE、WSL 或远程控制出现连接问题时读取。先记录产品表面、实际运行的 `codex` 进程位置及版本、故障动作、首个错误与时间，不把浏览器成功、另一份 CLI 成功或工具进程成功当作当前会话成功。桌面 UI、与本地 app-server 的连接、模型流、MCP 工具和远程控制是不同故障面；先确认哪一个最先失败。

## 按首个失败点分流

- **连接拒绝 / `os error 61` 或 `10061`：** 先找这次请求选用的是直连还是代理。核对当前 Codex 状态目录中的 `.env`、进程继承的代理变量、操作系统/PAC 代理与所有本机代理监听端口；只在相关设置存在时检查其值，展示时遮盖凭据。[公开案例 #38885](https://github.com/openai/codex/issues/38885) 的真实原因是 `.env` 指向一个已经关闭的本地代理。当前 [Codex 源码](https://github.com/openai/codex/blob/e72da2b53805894878023d01949a25a082e0a5cb/codex-rs/arg0/src/lib.rs) 会在启动时读取状态目录里的 `.env`，因此终端里改变量未必覆盖已运行的进程。
- **普通 HTTPS 成功，模型流在 WebSocket 阶段超时或断开：** 核对实际目标和代理是否允许 WebSocket 升级、TLS 检查和长连接空闲时间；[OpenAI 网络要求](https://help.openai.com/en/articles/9247338-network-recommendations-for-chatgpt-errors-on-web-and-apps) 指出 Codex 流可用 `wss://chatgpt.com/`。系统代理与显式进程代理可能被不同传输路径采用；[公开案例 #29958](https://github.com/openai/codex/issues/29958) 是线索，不能据此强制所有机器设置代理变量。复测必须使用真实 Codex 流式任务。
- **浏览器或 Windows CLI 可用，桌面版失败：** 确认桌面版实际使用 Windows 还是 WSL、独立还是共享的状态目录、两侧解析器和代理。只在确认 WSL 是故障执行环境时，从该 WSL 环境查 A/AAAA 和路由。[公开案例 #44990](https://github.com/openai/codex/issues/44990) 是 Windows 测试正常、WSL 仅有不可达 IPv6 的例子。
- **认证网页成功，但 token exchange 或首轮请求失败：** 分开检查浏览器回调、代理主机名解析、到认证服务的 TCP/TLS、HTTP 状态与应用进程路径；不要先退出账号或删除认证文件。[公开案例 #45426](https://github.com/openai/codex/issues/45426) 显示代理名 A 正常而 AAAA `SERVFAIL`，请求在连接前失败。
- **TLS/证书错误：** 对照故障进程的证书相关环境变量、系统信任与是否有组织级 TLS 检查；先证明哪条证书链和哪个请求失败，不关闭证书验证。[公开案例 #43507](https://github.com/openai/codex/issues/43507) 中，一组继承的证书变量曾使诊断输出误导排查。
- **界面持续写“Reconnecting”，网络/WebSocket 检查却通过：** 检查桌面日志中任务创建、`turn/start`、会话 ID 和渲染事件是否一致。[公开案例 #43507](https://github.com/openai/codex/issues/43507) 报告过会话状态不一致；此时继续重置 DNS、改代理或卸载网卡没有针对性。
- **切网、唤醒或 VPN 模式切换后才卡住：** 先确认旧长连接是否失效、代理核心是否重启、新进程是否读到新路由和 DNS。稳定后重启受影响的 Codex 进程再做同任务对照；不要在仍依赖该连接的远程会话中强行切网。

## 使用案例的限度

这些 GitHub Issue 是特定用户、特定版本和网络的原始报告，部分仍开放。它们提供**优先检查什么**，不构成当前版本的通用修复证明。按本机的首个错误和同路径 A/B 结果选择最小操作；若返回 HTTP `403`、`429` 或 `503`，先确认它来自代理 `CONNECT`、中间网关还是目标服务，核对服务状态和响应语义，不能把它与 DNS 无响应、TCP 被拒绝混为一类。[RFC 9110](https://www.rfc-editor.org/rfc/rfc9110.html) 区分 CONNECT 隧道响应和隧道建立后的目标响应。引用日志时只保留必要的时间、错误码、目标类别和状态，不公开令牌、会话 ID、完整代理 URL 或内部域名。
