# 公开案例与官方依据

这些案例用于提出可检验的假设。每个案例来自不同环境；先确认本机症状、版本和路径，再决定是否适用。

| 现象 | 公开资料里的定位 | 本机应核对什么 |
| --- | --- | --- |
| Windows 上普通 HTTPS 可用，Codex WebSocket 超时并反复重连 | [Codex Issue #29958](https://github.com/openai/codex/issues/29958) 的报告者称 Windows 系统代理可用于 HTTPS，但给进程明确设置 `HTTP_PROXY`/`HTTPS_PROXY` 后 WebSocket 才恢复。这是用户报告，Issue 仍开放。 | 目标应用版本、实际代理入口、WebSocket 握手与真实会话；不要直接复制案例中的端口。 |
| Codex 报本机连接拒绝，看起来像服务端断流 | [Codex Issue #38885](https://github.com/openai/codex/issues/38885) 将故障定位到状态目录 `.env` 的过期本机代理端口；相同二进制移走该配置后恢复。 | 先确认实际状态目录、代理变量和对应监听端口，再考虑重装或 DNS 重置。 |
| Windows 上的诊断正常，但桌面 Codex 继续报发送失败 | [Codex Issue #44990](https://github.com/openai/codex/issues/44990) 的桌面版实际在 WSL 内运行，WSL 返回不可达的 IPv6 地址。 | 确认执行环境，在同一 WSL/容器内对照 A、AAAA 与 IPv4/IPv6 路由。 |
| 代理主机名有 IPv4，Codex 却在连接前失败 | [Codex Issue #45426](https://github.com/openai/codex/issues/45426) 报告 A 正常但 AAAA `SERVFAIL`；请求没有进入 TCP 连接。 | 分开查**代理主机名**与目标域名，记录 DNS 失败码，避免误判为账号或证书问题。 |
| 代理启用 Fake-IP 后，Codex 某个嵌入资源失败 | [Codex Issue #43741](https://github.com/openai/codex/issues/43741) 报告一个受限 UI 中的图片请求因合成地址而失败；针对单一主机名的临时过滤使该资源恢复。 | 限于同类受限资源与可复现证据，检查代理 DNS 模式和单域名 A/B；不能把 Fake-IP 整体视为故障。 |
| Codex 显示 Reconnecting，网络和 WebSocket 握手均正常 | [Codex Issue #43507](https://github.com/openai/codex/issues/43507) 报告过任务会话与界面收到的会话 ID 不一致。 | 查应用日志和会话事件，停止重复更改 DNS/代理。 |
| 桌面应用在代理后运行一会儿才断流 | [Codex Issue #18647](https://github.com/openai/codex/issues/18647) 记录了流式回复中 TLS EOF 和反复重连。 | 代理或安全网关是否切换节点、提前关闭长连接，及目标应用自己的日志。 |
| ChatGPT/Codex 的网页能打开，但通知或生成过程停滞 | [OpenAI 网络建议](https://help.openai.com/en/articles/9247338-network-recommendations-for-chatgpt-errors-on-web-and-apps) 指出部分功能需要 TCP 443 上的 WebSocket 升级；TLS 检查、过滤、空闲超时或消息大小策略也可能中断长连接。 | 先确认目标产品和连接类型；短 HTTPS 测试不能代替 WebSocket/流式任务。 |
| Wi-Fi 已连接但网页或应用间歇失败 | [Microsoft Windows Wi-Fi 排障](https://support.microsoft.com/en-us/windows/experience/connectivity-networking/fix-wi-fi-connection-issues-in-windows) 建议检查网关、设备与路由器；[Apple 无线诊断](https://support.apple.com/en-gw/guide/mac-help/mchlf4de377f/mac) 可只读分析 Mac 无线网络。 | 同网其他设备、换有线或热点、网关丢包与无线诊断结果。 |
| 只有启用 VPN、过滤软件或某网络时失败 | [Apple 的网络连接建议](https://support.apple.com/en-gb/102281) 把 VPN/安全软件列为可能因素，并建议换网络对照；[Microsoft 代理文档](https://support.microsoft.com/en-us/windows/experience/connectivity-networking/use-a-proxy-server-in-windows) 说明 VPN 代理与常规代理可分别配置。 | 实际使用的 VPN/代理模式、监听端口、应用进程路径以及组织策略。 |

诊断结果分三类报告：**已证实**（同设备或同应用的前后对照）、**较可能**（错误时间线和路径吻合但尚无完整复现）、**待验证**（仅来自类似公开案例）。提供链接时引用原文；不要把社区案例写成厂商承诺，也不要把连接错误写成服务端封禁或地区拒绝。DNS 深入检查见 [DNS 定位](dns-diagnosis.md)，Codex 专用分流见 [Codex 连接定位](codex-network.md)。
