# Quality Gates and Repair Priorities

Use these silently before delivery.

## Gate 1 — Narrative Fidelity

PASS when:

- all causal events remain in correct order;
- no unsupported person/object/event changes the meaning;
- the scene turn is visually represented;
- essential dialogue meaning remains readable through behavior/staging even if text is not printed in the board.

FAIL symptoms:

- beautiful shots but wrong story;
- missing reaction that makes the next action irrational;
- an invented prop solves a problem the script did not solve.

Repair: restore source truth before improving style.

## Gate 2 — Visual Legibility

PASS when a storyboard artist could draw every frame without asking:

- who is visible;
- where they are;
- what exact instant is shown;
- which direction they face/move/look;
- what object/environment relationship matters.

FAIL: “dramatic close-up of tension” with no visible event.

Repair: rewrite Frame and Staging first.

## Gate 3 — Shot Necessity

For every frame ask:

> If this frame disappears, what becomes harder to understand, feel, or edit?

If the answer is “nothing,” delete or merge it.

Do not keep shots solely for lens variety, beauty, coverage, or because the source paragraph was long.

## Gate 4 — Spatial Coherence

PASS when:

- entrances/exits and key anchors remain stable;
- axis and screen direction are understandable;
- major action can be reconstructed;
- close shots do not erase geography for too long.

Repair priority:

1. insert/rebuild one spatial anchor;
2. fix left/right and eye-lines;
3. fix action overlap;
4. only then adjust style.

## Gate 5 — Emotional Causality

PASS when the viewer can see:

```text
trigger → processing → decision/reaction → consequence
```

Not every stage needs a shot, but no essential psychological jump should be unexplained.

Repair with performance or staging before adding voice-over or symbolism.

## Gate 6 — Continuity

Check:

- character positions;
- facing/eye-line;
- movement direction;
- body pose;
- props;
- wardrobe/hair/injury;
- environment layout;
- light/time;
- emotional residue.

A deliberate reset requires an explicit transition: time jump, new scene, dream, montage, axis-crossing move, etc.

## Gate 7 — Visual Rhythm

FAIL patterns:

- 70%+ frames use the same shot size without deliberate formal reason;
- every frame is a close-up;
- every frame is a wide;
- every frame moves;
- repeated “push-in for emotion” regardless of scene function.

Repair by changing information distance, not randomly changing lenses.

## Gate 8 — Board Readability

For multi-panel boards:

- exact panel count is stated;
- reading order is stated;
- each panel contains one shot;
- panel descriptions are frozen moments;
- annotations are minimal;
- no poster typography;
- no duplicated characters to show multiple motion phases;
- important faces/gestures are large enough to read.

## Gate 9 — Reference Fidelity

If references are supplied:

- identities remain matched;
- environment topology is not reinvented without reason;
- costume and key props persist;
- reference style does not overwrite script event.

## Gate 10 — Downstream Usefulness

The output should support at least one downstream action without reconstruction:

- an artist can draw it;
- an image model can generate a storyboard sheet;
- a director can review blocking;
- a video prompt compiler can convert the shots into model prompts.

If not, the storyboard is still conceptual notes, not a usable board.

## Repair Order

When several things fail, repair in this order:

```text
story truth
→ action causality
→ geography
→ visible performance
→ continuity
→ shot rhythm
→ composition
→ lens/movement polish
→ rendering style
```

Never polish a false scene.
