# Shot Design and Continuity Reference

## 1. Start With Geography

A sequence is only as clear as its hidden map.

Before shot design, locate:

```text
A = primary character
B = counterpart / threat / objective
E1/E2 = entrances and exits
P = key prop
L = dominant light or readable orientation cue
AXIS = primary interaction or movement axis
```

You do not need to output a diagram. You do need to know the answers.

## 2. Camera Questions

Choose shot size and angle by function:

- **Where are we?** wide / full / spatial two-shot.
- **What are they doing?** full / medium / over-shoulder / tracking relation.
- **What changed emotionally?** close / detail / reaction, only when the face or gesture contains new information.
- **What must the viewer notice?** insert / POV / selective focus / reframe.
- **How large is the consequence?** pull back, reveal, scale comparison, aftermath wide.

No shot size is intrinsically “cinematic.”

## 3. Axis and Screen Direction

Maintain a stable interaction axis unless a deliberate crossing is motivated and visually explained.

Useful principles:

- A looking screen-right should normally cut to B oriented screen-left.
- Movement traveling left→right should continue that direction through connected action.
- If crossing the axis, let the camera visibly cross, let a subject move through the axis, or insert a neutral/on-axis shot.
- A deliberate disorientation can break the rule, but the viewer should feel **intended instability**, not accidental geography loss.

## 4. Match on Action

When an action spans shots, overlap enough motion that the edit feels continuous.

Examples:

- hand reaches → cut after movement begins → next frame continues reach;
- character turns → cut during turn → next frame lands in new angle;
- door opens → cut while door is moving → next frame continues motion.

Do not teleport objects or limbs between frames.

## 5. Prop State

Track only story-relevant and highly visible props.

For each, track:

```text
owner / location / orientation / amount / damage / open-closed / lit-unlit / clean-dirty
```

The state may evolve, but every change needs a visible cause or a time transition.

## 6. Character State

Maintain:

- costume layer and accessories;
- hair arrangement when visually distinctive;
- blood, dirt, wetness, damage;
- injuries and which side of body;
- held objects;
- seated/standing/kneeling state;
- emotional energy at the cut.

## 7. Composition Continuity

Avoid three accidental patterns:

- three or more nearly identical shot sizes with no rhythmic reason;
- alternating close-ups that erase spatial relationships for too long;
- constant symmetrical center placement because the image model prefers it.

Use depth and negative space deliberately. Preserve look-room and travel-room when the viewer needs to anticipate action.

## 8. Camera Movement

Movement is justified when it does at least one:

- follows necessary action;
- reveals information;
- changes relationship to a character;
- increases/decreases pressure;
- connects spaces or subjects;
- creates a deliberate subjective sensation.

If a fixed frame communicates the beat better, keep it fixed.

## 9. Lens Guidance Without Numerology

Prefer functional categories unless exact lenses matter downstream:

- wide spatial: roughly 18–28mm equivalent;
- natural relational: 32–55mm;
- compressed intimate / observational: 70–135mm;
- detail / macro: true close-focus or macro behavior.

Wide lenses exaggerate spatial relation and motion; long lenses compress relation and isolate. Do not select 85mm merely because the scene is emotional.

## 10. Transitions Between Blocks

Use a Continuity Baton at any point where the next generation may happen in another call, another image, or another video clip.

A baton should carry only visually consequential state, not a full recap.

Good:

```text
last frame: Mira foreground-right, half turned toward exit; Anton background-left seated
movement: Mira begins moving rightward
prop: red folder now in Mira's left hand
light: same cold dawn through east window
aftertaste: Mira has decided to leave; Anton has not yet understood
next obligation: next shot must either continue her departure or explicitly mark a time jump
```

Bad: a page-long summary of every prior shot.
