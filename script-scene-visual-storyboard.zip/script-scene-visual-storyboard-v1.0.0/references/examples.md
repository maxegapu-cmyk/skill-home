# Compact Examples

## Example 1 — Quiet Betrayal

### Source

```text
INT. KITCHEN — NIGHT
Lin sees a second phone on the counter. Her husband keeps talking about work as if nothing is wrong. She picks up the phone. He stops mid-sentence.
```

### Scene Visual Contract

```text
Scene: kitchen, night
Dramatic movement: ordinary conversation → contradiction discovered → power flips
Visual tone: mundane, contained, increasingly still
Space anchors: island counter, second phone, husband near sink, Lin opposite island
Character geography: initially separated by island; phone sits between them
Key continuity: phone untouched → Lin takes it; husband remains mid-task until he sees her take it
```

### Storyboard

```text
SHOT 01 — ANCHOR
Narrative function: establish normality and the hidden contradiction in one frame
Frame: medium-wide two-shot across the island; husband rinses a glass in background-left while talking; Lin foreground-right sets down her keys; a second phone lies near the center edge of the island, visible but not emphasized
Staging: island physically separates them; neither looks at the phone yet
Camera: eye-level, stable relational view
Composition: phone sits on the line between their bodies; domestic space remains readable
Motion: fixed
Continuity: establishes positions and prop location

SHOT 02 — SUPPORT
Narrative function: show the exact moment Lin notices the contradiction
Frame: close view on Lin's hand stopping halfway toward her bag as her eyes shift downward past frame toward the phone; husband soft in background still speaking
Staging: her body remains facing away from the phone; only attention changes first
Camera: restrained close, no dramatic angle
Composition: husband stays present as causal context
Motion: very slight reframe or none
Continuity: eye-line must lead toward phone position from Shot 01

SHOT 03 — ANCHOR
Narrative function: make the power shift visible
Frame: low tabletop two-shot; Lin's hand lifts the second phone into foreground while husband freezes with wet glass in hand in background; neither speaks
Staging: phone now physically belongs to Lin's side of the frame
Camera: near-table height, natural perspective
Composition: phone and husband's frozen reaction share depth axis
Motion: fixed
Continuity: glass remains in husband's hand; phone moves from island to Lin
```

Why it works: the betrayal is not illustrated with a random close-up of a sad face. The phone's state, gaze shift, and interrupted action create the meaning.

## Example 2 — Corridor Threat

### Source

```text
The guard walks down the empty hospital corridor. A light behind him goes out. He hears something and stops. At the far end, a human-shaped silhouette steps into the corridor.
```

### Board Logic

1. orientation: long corridor, guard moving away from camera, exit/door rhythm visible;
2. anomaly: same direction preserved; rear section of corridor falls dark;
3. listening: medium rear three-quarter frame, guard stops but does not turn yet;
4. reveal: wider forward-facing relation showing guard foreground and distant silhouette background;
5. compression only after geography is understood: closer reaction or hand reaching for weapon.

Bad version: five tight horror close-ups with shaking camera. It may feel intense but the audience cannot locate the threat.

## Example 3 — Action With Geography

### Source

```text
A courier runs across a market toward a blue van. Two attackers enter from the left alley. She changes direction, vaults a fruit stall, and disappears through a narrow passage before they can cut her off.
```

### Spatial truth

```text
courier travel: center → right toward van
attackers: enter screen-left from alley
escape passage: back-right beyond fruit stall
fruit stall: midground barrier between attackers and passage
```

### Essential frames

- wide anchor showing van, alley, courier and stall relation;
- attackers entering from left while courier registers them;
- action frame of courier changing vector toward back-right;
- vault phase with direction preserved;
- attackers blocked by stall / courier entering narrow passage;
- optional aftermath wide if the scene needs consequence.

The board does not need a close-up of shoes, hand, eyes, fruit, weapon and van unless those details change story information.

## Example 4 — Visual Board Prompt Excerpt

```text
Create a 16:9 horizontal director storyboard sheet with exactly 6 panels, read left-to-right and top-to-bottom. One panel equals one shot. Use black-and-white graphite and marker planning drawings, clean silhouettes, minimal shading, simple camera arrows, no polished concept-art finish.

Global continuity: same adult female courier in dark jacket and messenger bag in every panel; blue van remains on the right side of the market; attackers enter from the left alley; escape passage stays back-right; preserve left-to-right then back-right travel logic.

Panel 1 — wide market geography: courier mid-left running toward blue van at frame-right, fruit stall midground center, left alley visible, back-right passage visible...
Panel 2 — medium-wide: two attackers emerge from left alley as courier turns her head toward them without stopping...
...

No poster composition, no duplicated courier, no extra attackers, no rearranged market architecture, no wrong panel order, no decorative title text.
```
