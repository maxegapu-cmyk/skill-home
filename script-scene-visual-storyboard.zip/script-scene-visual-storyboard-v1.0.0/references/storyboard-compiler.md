# Storyboard Compiler

This reference converts a finished shot plan into a **single-sheet or multi-sheet visual storyboard prompt**.

## 1. Choose Sheet Size

Recommended readable densities:

- 2–4 panels: emotional or composition-sensitive sequence;
- 5–8 panels: normal scene block;
- 9–12 panels: action/previs overview only when each panel can remain legible;
- over 12: split into multiple sheets.

The board's job is legibility, not showing off how much content fits on one image.

## 2. Global Prompt Skeleton

```text
Create a [ASPECT RATIO] horizontal director storyboard sheet containing exactly [N] distinct panels.
Read panels left-to-right, top-to-bottom. One panel equals one shot. Never merge two shots into one panel and never duplicate a character to represent motion phases inside the same panel.

SOURCE AUTHORITY
- screenplay/event: [source]
- character references: [mapping]
- environment references: [mapping]
- preserve identity, wardrobe, architecture, prop and era continuity unless the shot list explicitly changes them.

RENDERING MODE
[director board / clean previs / cinematic color board]

GLOBAL CONTINUITY
[screen axis, travel direction, recurring props, time/light, key state]

PANELS
PANEL 1 — SHOT 01:
[exact frozen visible moment]
[subject placement and depth]
[camera viewpoint / shot size]
[critical continuity state]

PANEL 2 — SHOT 02:
...

ANNOTATIONS
Allow only small shot numbers, simple motion arrows, camera arrows and short timing notes. No dialogue blocks, no decorative typography, no poster title.

NEGATIVE CONSTRAINTS
no poster composition, no key art, no splash illustration, no comic splash page, no duplicated actors, no extra characters, no invented props, no panel order changes, no merged scenes, no inconsistent costume, no flipped screen direction unless explicitly requested, no beautification that changes age or identity, no excessive rendering that hides blocking.
```

## 3. Director Board Rendering

Add:

```text
black-and-white director storyboard, graphite and marker linework, fast confident gesture drawing, minimal tonal wash, clean panel borders, readable silhouettes, clear spatial blocking, production previs, motion arrows where needed, white or light paper background, unfinished planning-art character, not polished concept art
```

Avoid “rough” if the model interprets it as unreadable scribbles. Prefer **clear planning drawing with economical detail**.

## 4. Clean Previs Rendering

Add:

```text
clean grayscale cinematic previs, simplified realistic forms, readable faces and body posture, clear architecture and depth layers, restrained value design, consistent characters and wardrobe, storyboard panel borders, production planning image, not final key art
```

## 5. Cinematic Color Board Rendering

Add:

```text
cinematic color storyboard, production-design preview, controlled palette and lighting, readable staging and silhouette first, moderate finish, consistent costume/material/environment, still presented as sequential storyboard panels rather than individual poster frames
```

## 6. Panel Wording

Each panel should describe one **freeze-frame**, even if the eventual video shot moves.

Weak:

> Camera tracks him through the hall, then he turns and sees the monster and runs.

Strong:

> Mid-wide frame at the instant he has stopped halfway down the corridor and turned over his left shoulder; his body points away from camera while his face looks back into the dark end of the hall; the monster is only a narrow silhouette between two doorframes in deep background; strong empty corridor between them.

Movement belongs in a separate camera/motion clause or arrow note.

## 7. Reference Mapping

When images are supplied, make the mapping explicit once globally and only repeat it in panels where a model could confuse subjects.

Example:

```text
@charA = adult woman in all panels; identity/face/hair/costume authority
@env1 = apartment interior; room layout/material/architecture authority
```

Do not ask the image model to “use the style” of a character reference when the reference is only identity evidence.

## 8. Multi-Sheet Continuity

At the end of Sheet A, define:

```text
SHEET A END STATE
[positions / facing / active action / prop / wardrobe / light / emotion]
```

At the start of Sheet B:

```text
SHEET B MUST OPEN FROM SHEET A END STATE
[repeat only the state needed to avoid drift]
```

This is more reliable than relying on “same as previous image.”
