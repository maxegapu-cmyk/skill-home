# Scene Strategy Library

These are tendencies, not presets. Story needs outrank genre clichés.

## Dialogue / Negotiation

Primary problem: power and information move invisibly.

Prioritize:

- spatial hierarchy before close-up coverage;
- listening reactions;
- changes in eye contact;
- who controls shared objects and distance;
- when two people share a frame vs become isolated;
- the exact line that changes the relationship.

Avoid endless shot/reverse-shot symmetry.

## Suspense / Horror

Primary problem: information must be controlled.

Prioritize:

- what the viewer knows vs what the character knows;
- occlusion and partial visibility;
- stable geography before disorientation;
- negative space with a narrative reason;
- delayed reveal;
- sound-implied attention translated to where the character looks.

Avoid making everything dark. If the audience cannot read the space, suspense becomes confusion.

## Action / Pursuit

Primary problem: speed destroys geography.

Design phases:

1. objective and obstacle;
2. orientation;
3. initiation;
4. exchange / pursuit change;
5. reversal;
6. impact;
7. consequence.

Not every phase needs a separate frame, but the audience must understand the causal chain.

Use wide frames when a new spatial relation matters. Use close frames for impact, decision, injury, grip, trigger, or reaction — not to hide choreography.

## Romance / Intimacy

Primary problem: small changes carry large meaning.

Prioritize:

- distance and proximity;
- shared vs separated frames;
- gaze timing;
- touch and almost-touch;
- object sharing;
- who initiates movement;
- silence after the meaningful line.

Do not overuse glamour close-ups. Intimacy often depends on two bodies occupying one space.

## Comedy

Primary problem: timing and information asymmetry.

Prioritize:

- clear setup frame;
- hold long enough for expectation;
- reaction or reveal at the precise beat;
- composition that lets the audience notice something before or after the character, depending on the joke.

Too many cuts can kill a gag.

## Exposition

Primary problem: text-heavy information becomes inert.

Find the visual action carrying the information:

- demonstration;
- discovery;
- map/object manipulation;
- disagreement over evidence;
- consequence in background;
- simultaneous task while dialogue occurs.

Do not invent unrelated B-roll merely to avoid talking heads.

## Spectacle / Worldbuilding

Primary problem: scale without meaning becomes wallpaper.

Sequence often works best as:

human reference → environmental reveal → scale relation → meaningful detail → consequence/reaction.

Use spectacle to change the character's options or the audience's understanding.

## Ritual / Ceremony

Primary problem: order, hierarchy and collective behavior.

Prioritize:

- symmetry or repetition when story supports it;
- procession direction;
- height and rank;
- synchronized actions;
- one intentional break in order when the drama turns.

## Dream / Memory / Subjective Passage

Primary problem: visual freedom can destroy story legibility.

Keep at least one anchor stable:

- identity;
- repeated object;
- spatial motif;
- movement direction;
- color/value logic;
- sound-linked visual action.

Declare where normal continuity rules are intentionally relaxed.
