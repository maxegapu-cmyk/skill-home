# Visual Translation Reference

## 1. The Translation Problem

Screenplays contain three kinds of information:

1. **already visible** — “she closes the door”; keep it concrete;
2. **visually implied** — “he hesitates”; choose evidence;
3. **non-visual meaning** — “he realizes his life has been a lie”; construct a chain of attention, reaction, and consequence.

The goal is not to illustrate every noun. The goal is to preserve the dramatic meaning with the smallest set of visible proofs.

## 2. Translation Ladder

When prose is abstract, move down this ladder until it becomes drawable:

```text
meaning
→ dramatic change
→ observable behavior
→ body part / object / spatial relation
→ frozen visual moment
```

Example:

```text
“He no longer trusts her.”
→ trust relationship changes
→ he stops accepting her reassurance
→ her hand reaches; his hand withdraws
→ two hands separated by a small gap on the table, faces soft in the background
```

## 3. Evidence Families

### Performance evidence
Eyes, jaw, breath, posture, hand tension, weight shift, delay, interruption, avoidance, touch.

Best for: internal conflict, intimacy, shame, fear, decision.

### Spatial evidence
Distance, barriers, shared frame vs separated frames, foreground obstruction, height difference, crowd isolation, doorway thresholds.

Best for: power, alienation, belonging, entrapment, social hierarchy.

### Object evidence
Possession, transfer, damage, residue, absence, repeated handling.

Best for: plot information, memory, threat, decisions with physical consequences.

### Environmental evidence
Light source, weather, traffic, room activity, empty space, texture, movement in background.

Best for: context and atmosphere. Do not let environment replace character action unless the script deliberately externalizes emotion.

### Rhythm evidence
Hold, interruption, delayed cut, sudden shortening, repetition, silence.

Best for: dread, comedy, shock, hesitation, release.

## 4. Subtext → Behavior

| Subtext | Weak visualization | Better visualization |
|---|---|---|
| wants to leave | sad close-up | body already angled to exit while conversation continues |
| lies calmly | dramatic shadow | answer comes without eye contact; hand covers the relevant object |
| is jealous | angry face | watches an intimate gesture before rejoining the conversation |
| feels excluded | lonely wide | group shares one plane; subject sits behind an obstruction or outside their eye-line loop |
| gains power | low angle automatically | others stop moving when the character speaks; blocking reorganizes around them |
| realizes danger | fast zoom | attention lands on a contradiction, then body becomes still before action |

## 5. Motifs

Use motifs only when they are:

- already present in the scene;
- causally connected to the event;
- understandable without explanation;
- repeated with variation or consequence.

Avoid random clocks, mirrors, birds, rain, candles, chess pieces, shattered glass, or floating dust simply because they look cinematic.

## 6. Dialogue Visualization

Dialogue scenes become visual through **listening** and **power shifts**, not constant coverage.

Track:

- who controls the floor;
- who interrupts;
- who refuses eye contact;
- who moves first;
- who can invade whose space;
- who touches or controls shared objects;
- which line changes the relationship.

A reaction may be more important than the speaking face.

## 7. Abstract Scale

For ideas like “cosmic loneliness,” “national collapse,” or “the weight of history,” do not jump straight to spectacle. First identify whose experience gives the abstraction meaning.

Possible strategies:

- human scale against overwhelming space;
- repeated empty positions where people should be;
- a small action continuing inside a huge environment;
- accumulated physical evidence rather than a symbolic montage;
- sound or movement thinning while the frame holds.

Choose the strategy supported by the story world.
