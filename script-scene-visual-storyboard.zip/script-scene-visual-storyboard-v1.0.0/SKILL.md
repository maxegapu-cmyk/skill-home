---
name: script-scene-visual-storyboard
description: Use when a screenplay, scene, story passage, dialogue sequence, or narrative beat needs to be converted into high-quality visual storyboards, shot designs, scene blocking, storyboard-image prompts, or model-agnostic cinematic previs.
---

# Script Scene Visual Storyboard

Version: 1.0.0

## Purpose

This skill turns written drama into **visible, spatially coherent, emotionally purposeful storyboard frames**.

It is not a screenplay writer, a generic prompt beautifier, or a machine that assigns one shot to every sentence. Its job is narrower and harder:

> Preserve what the scene means, decide what the audience must see, build a believable space for the action, and express the scene as a sequence of frames that can actually be drawn, generated, edited, or handed to a video system.

The core principle is **story first, visible evidence second, camera third**. Camera language is chosen only after the dramatic function and physical staging are understood.

## When to Use

Use this skill when the user asks for any of the following:

- 根据剧本生成视觉分镜 / 场景分镜 / 分镜故事板
- 剧本可视化、scene visualization、storyboard、previs
- 把一场戏设计成镜头并生成多格分镜图
- 从对白、动作、小说片段或剧情段落推导可拍画面
- 生成角色位置、机位、构图、景别、运动、镜头顺序
- 把现有分镜脚本编译成一张或多张视觉故事板
- 需要兼顾角色、场景、道具、轴线和跨镜连续性的分镜设计

Do not use it to rewrite plot or dialogue unless the user explicitly requests that too. If the source has a real story flaw, preserve it and flag it rather than silently rewriting the story.

## Operating Modes

Infer the lightest mode that completes the request.

### A. DIRECT-STORYBOARD
Input: screenplay / scene / narrative passage.
Output: finished storyboard sequence plus visual-board prompt.

Default mode. Do the analysis internally and keep the visible output clean.

### B. SHOT-DESIGN
Input: approved scene or existing beat list.
Output: director shot plan only; no board-image prompt unless useful.

### C. VISUAL-BOARD
Input: existing shot list / storyboard script.
Output: one or more multi-panel storyboard-image prompts. Do not redesign story unless the existing shots are impossible to visualize.

### D. PREVIS-CONTINUITY
Input: long sequence, action scene, multi-scene passage, or an existing board with continuity problems.
Output: storyboard plus explicit spatial/continuity anchors.

## Default Assumptions

Do not interrupt a usable request with unnecessary questions. When unspecified:

- Preserve the script's era, location, identity, wardrobe, props, and causal order.
- Infer a fitting cinematic grammar from genre and dramatic temperature.
- Use 16:9 for a storyboard sheet unless the project supplies another aspect ratio.
- Use neutral monochrome director-board rendering for planning; use color cinematic previs only when the user asks for a more finished visual board.
- Treat 15 seconds as a **generation window**, never as a mandatory story unit.
- If reference images are supplied, they are identity/environment evidence, not permission to rewrite the scene.
- If a missing detail does not alter the story, choose the least surprising plausible default and continue.

Only ask when a missing fact changes identity, causality, location topology, or the meaning of the scene and cannot be safely inferred.

## The Core Model: SCENE → SPACE → PRESSURE → FRAME

Think through the following internally. Do not dump the reasoning unless the user asks for it.

### 1. SCENE TRUTH — What is really happening?

Extract:

- **dramatic action**: what one person is trying to make happen;
- **counterforce**: what resists it;
- **turn**: what changes before the scene ends;
- **audience information**: what must be understood or felt;
- **subtext**: what is true but not directly spoken;
- **state changes**: emotion, injury, possession, distance, alliances, knowledge.

A storyboard is wrong if it looks attractive but changes any of these.

### 2. VISIBLE EVIDENCE — What can a camera actually see?

Convert non-visible prose into observable evidence.

Examples:

- “he loses confidence” → gaze drops, answer delayed, shoulders collapse, hand releases the object;
- “she realizes he lied” → eye-line freezes on the contradictory object, breathing stops, then attention returns to him;
- “the room feels hostile” → excessive negative space, obstructed sightlines, hard separation between figures, background activity that never acknowledges the protagonist;
- “time seems to stop” → movement and ambient detail reduce; use one held reaction or suspended physical event rather than literal fantasy unless the story is supernatural.

Never invent decorative symbolism when simple behavior communicates the beat better.

### 3. SPACE MODEL — Where is everyone, really?

Before choosing close-ups, build the scene's physical truth:

- entrances/exits;
- major environment anchors;
- character positions and facing directions;
- interaction axis;
- important props and who owns/touches them;
- foreground / midground / background opportunities;
- travel direction;
- light sources when relevant to readability or continuity.

If the audience cannot mentally reconstruct the room, the board is not yet stable.

### 4. PRESSURE CURVE — How should visual attention change?

Do not choose shots by variety. Choose them by pressure.

A scene usually moves among five pressures:

- **orientation** — understand place, participants, threat or objective;
- **observation** — read behavior and relationship;
- **compression** — remove space, increase intimacy or danger;
- **impact** — reveal, decision, collision, attack, emotional hit;
- **release** — aftermath, distance, silence, consequence.

The curve can skip stages. A quiet scene may stay in observation for a long time. An ambush can start at impact.

### 5. FRAME DESIGN — Why does this frame exist?

Every storyboard frame must answer at least one:

- What new information becomes visible?
- What action becomes understandable?
- What emotion becomes readable?
- What spatial relationship becomes clear?
- What transition becomes possible?

If removing a frame changes nothing, remove it.

## Shot Construction

For each necessary frame, define only what improves execution:

1. **Narrative function** — what the audience receives here.
2. **Visible event** — exact physical moment, not abstract intention.
3. **Staging** — who is where, facing where, doing what.
4. **Shot size / angle** — chosen for information and pressure.
5. **Composition** — balance, negative space, foreground obstruction, depth layers, eye room.
6. **Camera behavior** — fixed, pan, track, push, pull, handheld, POV, etc.; motion must have a reason.
7. **Continuity hook** — gaze, movement, prop, screen direction, pose, light, or shape that connects to adjacent frames.
8. **Duration or rhythm** — only when timing matters.

Lens and aperture are optional. Add them when the downstream model or user benefits; do not turn artistic judgment into fake precision.

## Shot Hierarchy

Use three practical classes rather than treating all frames equally.

### Anchor Shot
Carries the main dramatic information of a beat. Every meaningful beat needs at least one.

### Support Shot
Clarifies reaction, geography, detail, prop state, or action continuity that the anchor cannot carry alone.

### Punctuation Shot
Very short insert, impact, reaction, cutaway, or visual stop. Use sparingly. It must still change rhythm or meaning.

## Continuity Rules

Continuity is a dramatic aid, not paperwork. Track only states that can visibly break the sequence.

At minimum check:

- screen axis and left/right relationship;
- eye-line direction;
- movement direction and match-on-action;
- body pose and contact state;
- prop possession/state;
- wardrobe/hair/injury state;
- environment layout;
- time/light state;
- emotional energy carried into the next frame.

Intentional violations are allowed when they serve a clear dramatic effect. Make the violation legible rather than accidental.

For multi-scene or multi-generation work, create a compact **Continuity Baton** after each block:

```text
CONTINUITY BATON
last-frame visual state:
character positions / facing:
active movement direction:
key prop states:
wardrobe / injury state:
light / time state:
emotional residue:
next-frame obligation:
```

## Storyboard Output Contract

Default visible output should be concise and production-usable.

### 1. Scene Visual Contract

```text
SCENE VISUAL CONTRACT
Scene:
Dramatic movement:
Visual tone:
Space anchors:
Character geography:
Key continuity states:
```

Keep this short. It exists to prevent drift, not to explain film theory.

### 2. Storyboard Frames

```text
SHOT 01 — ANCHOR
Narrative function:
Frame:
Staging:
Camera:
Composition:
Motion:
Continuity:
Timing: [only if useful]

SHOT 02 — SUPPORT
...
```

The **Frame** line is the most important line. It must describe a drawable frozen moment with clear subject, action, environment relationship, and visual emphasis.

### 3. Visual Storyboard Prompt

After the shot plan, compile the same sequence into a single board-generation prompt when the user wants an actual storyboard image or a prompt for image generation.

The prompt must specify:

- board aspect ratio and panel order;
- number of panels in this sheet;
- one panel = one shot, no merged events;
- character/environment reference sovereignty;
- each panel's exact visible moment and composition;
- continuity of screen direction and state;
- restrained annotations: shot number, arrows, timing only;
- storyboard rendering mode;
- negatives against posters, splash art, duplicated characters, wrong panel order, and invented props.

Use the compiler pattern in `references/storyboard-compiler.md`.

## Board Density

Do not force a fixed number of frames.

Use the scene's **information load + action complexity + emotional turns**:

- simple quiet beat: 2–4 frames;
- normal dialogue or discovery: 4–8 frames;
- action / pursuit / complex reveal: 6–14 frames;
- longer scene: divide into coherent board blocks rather than making a tiny unreadable mega-sheet.

A new panel is justified by a change in information, action phase, emotional pressure, geography, or transition — not because a sentence ended.

## Visual Rendering Modes

Choose one; never mix modes accidentally.

### Director Board — default
Black-and-white / graphite / marker / rough digital line; strong silhouettes; minimal shading; arrows allowed; readable staging; no polished illustration.

### Clean Previs
Neutral grayscale or restrained color; simplified but accurate anatomy and environment; clearer lighting and depth; still obviously previsualization, not key art.

### Cinematic Color Board
More finished production-design preview. Use only when the user needs lighting, palette, costume, material, or atmosphere judged visually. Preserve storyboard readability over beauty.

## Reference Image Sovereignty

When references exist, assign roles before generating:

- **character reference** owns identity, age appearance, face, hair, body type, costume details explicitly visible;
- **environment reference** owns architecture, layout, key objects, era, material vocabulary;
- **script** owns event, relationships, causal order, dialogue meaning;
- **shot design** owns camera placement, crop, staging adjustments required to depict the script.

Do not let a beautiful reference image override story truth.

## Scene-Type Adaptation

Do not apply one fashionable style to everything. See `references/scene-strategies.md`.

In brief:

- dialogue → prioritize relationship geometry, eye-lines, reactions, restraint;
- suspense/horror → control information, occlusion, negative space, delayed reveal;
- action → prioritize geography before speed, readable phases, directional continuity;
- romance/intimacy → prioritize distance, gaze, touch, timing, shared/isolated frames;
- exposition → turn information into discovery, demonstration, conflict, or visual evidence;
- spectacle → establish scale and human reference before beauty shots.

## Quality Gate

Before output, silently run six questions:

1. **Story fidelity** — Could a viewer reconstruct what the script says happened?
2. **Dramatic purpose** — Does every frame have a reason beyond looking cinematic?
3. **Spatial clarity** — Can the viewer understand where people and important objects are?
4. **Emotional readability** — Is the intended change visible without explanatory prose?
5. **Continuity** — Do adjacent frames preserve or intentionally transform state?
6. **Board usability** — Could an artist or image model draw each frame without guessing the core event?

If two or more fail, redesign the block rather than patching random details.

Use `references/quality-gates.md` for deeper checks.

## Failure Handling

### Source is only an outline
Do not refuse. Infer a conservative staging and label invented connective actions only when they materially affect interpretation.

### Pure dialogue with no action
Create behavior from subtext, conversational power, listening, interruption, physical distance, and prop interaction. Do not make everyone constantly gesture.

### Abstract or poetic prose
Translate meaning into behavior, environment relationship, rhythm, or a concrete visual motif. If several translations are equally valid, choose the least story-distorting one.

### Action is physically unclear
Establish geography first. Never hide confusion behind frantic camera movement.

### Long script
Process scene by scene or dramatic block by dramatic block. Preserve a compact continuity baton between blocks.

### Existing storyboard is already good
Do not redesign for novelty. Preserve strong choices and repair only actual weaknesses.

## Anti-Patterns

Never default to:

- one sentence = one shot;
- every scene starts with an establishing wide;
- every emotion gets a face close-up;
- every shot moves;
- arbitrary lens numerology;
- constant center framing;
- random inserts for “cinematic texture”;
- hiding action geography with blur, darkness, smoke, or shaky camera;
- replacing character acting with symbolic objects when the performance already carries the beat;
- turning a storyboard sheet into a poster, comic splash page, or polished key art;
- adding characters, props, architecture, costume changes, injuries, or supernatural effects not supported by the source.

## Fast Invocation

A minimal user instruction such as:

```text
根据这个剧本做场景视觉分镜。
```

is sufficient. Read the source, infer the mode, and execute.

For a deliberately lighter output:

```text
快速视觉分镜：只给 Scene Visual Contract + 镜头 + 故事板生图提示词。
```

For maximum continuity:

```text
连续性优先：按 PREVIS-CONTINUITY 模式处理，保留跨段 Continuity Baton。
```

## Supporting References

- `references/visual-translation.md` — abstract prose → visible evidence
- `references/shot-and-continuity.md` — staging, camera, spatial continuity
- `references/storyboard-compiler.md` — shot plan → multi-panel visual-board prompt
- `references/scene-strategies.md` — scene-type adaptation
- `references/quality-gates.md` — acceptance criteria and repair priorities
- `references/examples.md` — compact worked examples
