import json,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from continuity_engine import lint
from contract_validate import validate

class TestV2(unittest.TestCase):
    def load_example(self): return json.loads((ROOT/'assets/templates/continuity-contract.example.json').read_text(encoding='utf-8'))
    def test_example_schema(self): self.assertEqual(validate(self.load_example()),[])
    def test_example_engine(self): self.assertEqual(lint(self.load_example()),[])
    def test_invalid_persistence_rejected(self):
        d=self.load_example(); d['shots'][0]['entry_facts'][0]['persistence']='ULTRA'; self.assertTrue(validate(d))
    def test_missing_evidence_rejected(self):
        d=self.load_example(); del d['shots'][0]['entry_facts'][0]['evidence']; self.assertTrue(validate(d))
    def test_bad_cut_intent_rejected(self):
        d=self.load_example(); d['cuts'][0]['intent']='CONTINUOUS_ACTON'; self.assertTrue(validate(d))
    def test_unexpected_property_rejected(self):
        d=self.load_example(); d['shots'][0]['entry_facts'][0]['magic']=1; self.assertTrue(validate(d))
    def test_missing_adjacent_cut_rejected(self):
        d=self.load_example(); d['cuts']=[]; self.assertTrue(validate(d))
    def test_low_conflict_blocks(self):
        d=self.load_example(); d['shots'][1]['entry_facts'][0]['value']='none'; d['shots'][1]['entry_facts'][0]['confidence']='LOW'; fs=lint(d); self.assertTrue(any(x['severity']=='NEEDS_REVIEW' for x in fs))
    def test_smash_cut_does_not_bypass_world_state(self):
        d=self.load_example(); d['cuts'][0]['intent']='SMASH_CUT'; d['shots'][1]['entry_facts'][0]['value']='none'; fs=lint(d); self.assertTrue(any(x['type']=='GLOBAL_STATE_DRIFT' for x in fs))
    def test_event_allows_change(self):
        d=self.load_example(); d['shots'][1]['entry_facts'][0]['value']='none'; d['cuts'][0]['intent']='LEGAL_ELLIPSIS'; d['cuts'][0]['transition_events']=[{'id':'C1','kind':'legal_ellipsis','evidence':'明确收枪','authorized_by':'cut_intent','temporal_fit':'VERIFIED','effects':[{'entity':'char:hero','attribute':'held_prop','from':'prop:gun:right_hand','to':'none','persistence':'hard','scope':'timeline'}]}]
        fs=lint(d); self.assertFalse(any(x.get('entity')=='char:hero' and x.get('attribute')=='held_prop' and x['severity'] in {'MAJOR','CRITICAL','NEEDS_REVIEW'} for x in fs))

    def test_scope_downgrade_is_blocked(self):
        d=self.load_example(); d['shots'][0]['entry_facts'][0]['scope']='instance'; fs=lint(d); self.assertTrue(any(x['type']=='STATE_POLICY_MISMATCH' for x in fs))
    def test_hard_event_without_from_reviews(self):
        d=self.load_example(); d['cuts'][0]['transition_events']=[{'id':'C2','kind':'legal_ellipsis','evidence':'收枪','authorized_by':'cut_intent','temporal_fit':'VERIFIED','effects':[{'entity':'char:hero','attribute':'held_prop','to':'none','persistence':'hard','scope':'timeline'}]}]; d['shots'][1]['entry_facts'][0]['value']='none'; fs=lint(d); self.assertTrue(any(x['type']=='HARD_EVENT_MISSING_PRECONDITION' for x in fs))
    def test_duplicate_entity_rejected(self):
        d=self.load_example(); d['entities'].append(dict(d['entities'][0])); self.assertTrue(validate(d))
    def test_nonadjacent_cut_rejected(self):
        d=self.load_example(); d['shots'].append({'id':'SHOT_03','source':'第三镜','context':dict(d['shots'][1]['context']),'entry_facts':[],'events':[],'exit_facts':[]}); d['cuts'].append({'from':'SHOT_02','to':'SHOT_03','intent':'CONTINUOUS_ACTION','transition_events':[]}); d['cuts'].append({'from':'SHOT_01','to':'SHOT_03','intent':'MATCH_CUT','transition_events':[]}); self.assertTrue(validate(d))
    def test_boundary_extractor_smoke(self):
        import shutil
        if not shutil.which('ffmpeg') or not shutil.which('ffprobe'): self.skipTest('ffmpeg unavailable')
        with tempfile.TemporaryDirectory() as td:
            td=Path(td); a=td/'a.mp4'; b=td/'b.mp4'; out=td/'out'
            for path,color,dur in [(a,'red','1.2'),(b,'blue','1.1')]:
                r=subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i',f'color=c={color}:s=160x90:d={dur}:r=24','-c:v','libx264','-pix_fmt','yuv420p',str(path)],capture_output=True,text=True)
                self.assertEqual(r.returncode,0,r.stderr)
            r=subprocess.run([sys.executable,str(ROOT/'scripts/extract_boundary_frames.py'),'--a',str(a),'--b',str(b),'--out-dir',str(out)],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stdout+r.stderr); self.assertEqual(len(list(out.glob('*.png'))),6); self.assertTrue((out/'manifest.json').is_file())

    def test_regression_runner(self):
        r=subprocess.run([sys.executable,str(ROOT/'scripts/run_regression.py')],capture_output=True,text=True); self.assertEqual(r.returncode,0,r.stdout+r.stderr)
    def test_package_validator(self):
        r=subprocess.run([sys.executable,str(ROOT/'scripts/validate_package.py'),str(ROOT)],capture_output=True,text=True); self.assertEqual(r.returncode,0,r.stdout+r.stderr)

if __name__=='__main__': unittest.main()
