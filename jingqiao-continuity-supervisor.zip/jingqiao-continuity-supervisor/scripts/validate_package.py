#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,sys,py_compile
from pathlib import Path

REQUIRED=['SKILL.md','README.md','VERSION','MANIFEST.json','SHA256SUMS.txt','agents/openai.yaml','schemas/continuity-contract.schema.json','scripts/contract_validate.py','scripts/continuity_engine.py','scripts/run_regression.py','scripts/extract_boundary_frames.py','evals/deterministic_cases.jsonl','evals/semantic_cases.jsonl']

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root',nargs='?',default='.')
    args=ap.parse_args(); root=Path(args.root).resolve(); issues=[]
    for rel in REQUIRED:
        if not (root/rel).is_file(): issues.append(f'missing {rel}')
    if (root/'VERSION').is_file() and (root/'VERSION').read_text().strip()!='2.0.0': issues.append('VERSION must be 2.0.0')
    # Parse JSON/JSONL and require meaningful regression volume.
    for rel in ['schemas/continuity-contract.schema.json','assets/templates/continuity-contract.example.json']:
        try: json.loads((root/rel).read_text(encoding='utf-8'))
        except Exception as e: issues.append(f'invalid JSON {rel}: {e}')
    for rel,minc in [('evals/deterministic_cases.jsonl',50),('evals/semantic_cases.jsonl',30)]:
        p=root/rel; ids=set(); count=0
        if p.is_file():
            for n,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
                if not line.strip(): continue
                count+=1
                try:o=json.loads(line)
                except Exception as e: issues.append(f'{rel}:{n} invalid JSON {e}'); continue
                if o.get('id') in ids: issues.append(f'{rel}: duplicate id {o.get("id")}')
                ids.add(o.get('id'))
            if count<minc: issues.append(f'{rel}: too few cases {count} < {minc}')
    # Check JSONL contracts are not empty shells.
    sem=root/'evals/semantic_cases.jsonl'
    if sem.is_file():
        for n,line in enumerate(sem.read_text(encoding='utf-8').splitlines(),1):
            if not line.strip(): continue
            o=json.loads(line)
            for k in ('id','prompt','expected'):
                if not isinstance(o.get(k),str) or not o.get(k).strip(): issues.append(f'evals/semantic_cases.jsonl:{n} missing/empty {k}')
    # Compile every Python source.
    for py in sorted((root/'scripts').glob('*.py'))+sorted((root/'tests').glob('*.py')):
        try: py_compile.compile(str(py),doraise=True)
        except Exception as e: issues.append(f'python compile failed {py.relative_to(root)}: {e}')
    # Verify release hashes when present. SHA256SUMS intentionally excludes itself.
    hp=root/'SHA256SUMS.txt'
    if hp.is_file():
        for n,line in enumerate(hp.read_text(encoding='utf-8').splitlines(),1):
            if not line.strip(): continue
            try: digest,rel=line.split('  ',1)
            except ValueError: issues.append(f'SHA256SUMS.txt:{n} malformed'); continue
            fp=root/rel
            if not fp.is_file(): issues.append(f'SHA256SUMS.txt:{n} missing target {rel}'); continue
            got=hashlib.sha256(fp.read_bytes()).hexdigest()
            if got!=digest: issues.append(f'hash mismatch {rel}')
    if issues:
        print('FAIL'); [print('-',x) for x in issues]; return 1
    # Run the actual validators/regression; static PASS alone is insufficient.
    ex=root/'assets/templates/continuity-contract.example.json'
    cmds=[[sys.executable,str(root/'scripts/contract_validate.py'),str(ex)],
          [sys.executable,str(root/'scripts/continuity_engine.py'),str(ex)],
          [sys.executable,str(root/'scripts/run_regression.py')]]
    for cmd in cmds:
        r=subprocess.run(cmd,capture_output=True,text=True)
        if r.returncode:
            print('FAIL:', ' '.join(cmd)); print(r.stdout); print(r.stderr); return 1
    print('PASS: package structure + schema + example + deterministic regression')
    return 0
if __name__=='__main__': sys.exit(main())
