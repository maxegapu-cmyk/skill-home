#!/usr/bin/env python3
import json,sys,tempfile
from pathlib import Path
from continuity_engine import lint

ROOT=Path(__file__).resolve().parents[1]
CASES=ROOT/'evals'/'deterministic_cases.jsonl'

def main():
    total=passed=0; failures=[]
    for n,line in enumerate(CASES.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        total+=1; case=json.loads(line); findings=lint(case['contract'])
        types=[f.get('type') for f in findings]; sevs=[f.get('severity') for f in findings]
        ok=True
        for t in case.get('must_include_types',[]):
            if t not in types: ok=False
        for t in case.get('must_not_include_types',[]):
            if t in types: ok=False
        if 'expected_blocking' in case:
            blocking=any(s in {'MAJOR','CRITICAL','NEEDS_REVIEW'} for s in sevs)
            if blocking != case['expected_blocking']: ok=False
        if ok: passed+=1
        else: failures.append({'id':case['id'],'types':types,'findings':findings})
    print(f'REGRESSION: {passed}/{total} PASS')
    if failures:
        for f in failures:
            print('FAIL',f['id'],'types=',f['types'])
        return 1
    return 0
if __name__=='__main__': sys.exit(main())
