#!/usr/bin/env python3
"""Strict schema validator for Jingqiao 2.0 with no required third-party dependency.
It reads the packaged JSON Schema as the single source of structural truth.
"""
import argparse, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCHEMA_PATH=ROOT/'schemas'/'continuity-contract.schema.json'

def resolve_ref(schema, ref):
    if not ref.startswith('#/'):
        raise ValueError(f'unsupported ref: {ref}')
    cur=schema
    for part in ref[2:].split('/'):
        cur=cur[part.replace('~1','/').replace('~0','~')]
    return cur

def typename(v):
    if isinstance(v,bool): return 'boolean'
    if isinstance(v,dict): return 'object'
    if isinstance(v,list): return 'array'
    if isinstance(v,str): return 'string'
    if isinstance(v,(int,float)) and not isinstance(v,bool): return 'number'
    if v is None: return 'null'
    return type(v).__name__

def check_type(v,t):
    return {
      'object': isinstance(v,dict), 'array': isinstance(v,list), 'string': isinstance(v,str),
      'boolean': isinstance(v,bool), 'number': isinstance(v,(int,float)) and not isinstance(v,bool),
      'integer': isinstance(v,int) and not isinstance(v,bool), 'null': v is None
    }.get(t,True)

def validate_node(v, rule, schema, path='$'):
    issues=[]
    if '$ref' in rule:
        return validate_node(v, resolve_ref(schema,rule['$ref']), schema, path)
    if 'const' in rule and v != rule['const']:
        issues.append(f'{path}: expected const {rule["const"]!r}, got {v!r}')
    if 'enum' in rule and v not in rule['enum']:
        issues.append(f'{path}: invalid enum {v!r}; allowed={rule["enum"]}')
    t=rule.get('type')
    if t and not check_type(v,t):
        return issues+[f'{path}: expected {t}, got {typename(v)}']
    if isinstance(v,str) and len(v) < rule.get('minLength',0):
        issues.append(f'{path}: string shorter than minLength {rule["minLength"]}')
    if isinstance(v,list):
        if len(v) < rule.get('minItems',0): issues.append(f'{path}: too few items')
        if 'items' in rule:
            for i,item in enumerate(v): issues += validate_node(item,rule['items'],schema,f'{path}[{i}]')
    if isinstance(v,dict):
        for k in rule.get('required',[]):
            if k not in v: issues.append(f'{path}: missing required {k}')
        props=rule.get('properties',{})
        if rule.get('additionalProperties') is False:
            for k in v:
                if k not in props: issues.append(f'{path}: unexpected property {k}')
        for k,sub in props.items():
            if k in v: issues += validate_node(v[k],sub,schema,f'{path}.{k}')
    return issues

def semantic_structure_checks(data):
    issues=[]
    entity_ids=[e['id'] for e in data.get('entities',[]) if isinstance(e,dict) and 'id' in e]
    entities=set(entity_ids)
    if len(entity_ids)!=len(entities): issues.append('$.entities: entity ids must be unique')
    rule_ids=[r['id'] for r in data.get('world_rules',[]) if isinstance(r,dict) and 'id' in r]
    if len(rule_ids)!=len(set(rule_ids)): issues.append('$.world_rules: rule ids must be unique')
    reserved_prefix='sys:'
    shots=data.get('shots',[])
    ids=[s.get('id') for s in shots if isinstance(s,dict)]
    if len(ids)!=len(set(ids)): issues.append('$.shots: shot ids must be unique')
    cut_pairs=set()
    for i,c in enumerate(data.get('cuts',[])):
        if c['from'] not in ids: issues.append(f'$.cuts[{i}].from: unknown shot {c["from"]!r}')
        if c['to'] not in ids: issues.append(f'$.cuts[{i}].to: unknown shot {c["to"]!r}')
        pair=(c['from'],c['to'])
        if pair in cut_pairs: issues.append(f'$.cuts[{i}]: duplicate cut {pair}')
        cut_pairs.add(pair)
    known=entities
    for si,s in enumerate(shots):
        event_ids=set()
        for area in ('entry_facts','exit_facts'):
            seen=set()
            for fi,f in enumerate(s.get(area,[])):
                if not (f['entity'] in known or f['entity'].startswith(reserved_prefix)):
                    issues.append(f'$.shots[{si}].{area}[{fi}].entity: unknown entity {f["entity"]!r}')
                key=(f['entity'],f['attribute'])
                if key in seen: issues.append(f'$.shots[{si}].{area}: duplicate fact {key}')
                seen.add(key)
        for motion_name in ('entry_motion','exit_motion'):
            m=s.get(motion_name)
            if m and not (m['subject'] in known or m['subject'].startswith(reserved_prefix)):
                issues.append(f'$.shots[{si}].{motion_name}.subject: unknown entity {m["subject"]!r}')
        for ei,e in enumerate(s.get('events',[])):
            if e['id'] in event_ids: issues.append(f'$.shots[{si}].events: duplicate event id {e["id"]}')
            event_ids.add(e['id'])
            for fx,effect in enumerate(e['effects']):
                if not (effect['entity'] in known or effect['entity'].startswith(reserved_prefix)):
                    issues.append(f'$.shots[{si}].events[{ei}].effects[{fx}].entity: unknown entity')
    all_event_ids=set()
    for s in shots:
        for e in s.get('events',[]):
            if e['id'] in all_event_ids: issues.append(f'event id must be globally unique: {e["id"]}')
            all_event_ids.add(e['id'])
    for ci,c in enumerate(data.get('cuts',[])):
        for ei,e in enumerate(c.get('transition_events',[])):
            if e['id'] in all_event_ids: issues.append(f'event id must be globally unique: {e["id"]}')
            all_event_ids.add(e['id'])
            for fx,effect in enumerate(e.get('effects',[])):
                if not (effect['entity'] in known or effect['entity'].startswith(reserved_prefix)):
                    issues.append(f'$.cuts[{ci}].transition_events[{ei}].effects[{fx}].entity: unknown entity')
    # Cuts describe the actual sequential boundaries: require all adjacent pairs and reject extras.
    adjacent=set(zip(ids,ids[1:]))
    for a,b in adjacent:
        if (a,b) not in cut_pairs: issues.append(f'$.cuts: missing adjacent cut {a}->{b}')
    for pair in cut_pairs:
        if pair not in adjacent: issues.append(f'$.cuts: non-adjacent cut is not part of sequence order {pair[0]}->{pair[1]}')
    return issues

def validate(data):
    schema=json.loads(SCHEMA_PATH.read_text(encoding='utf-8'))
    return validate_node(data,schema,schema)+semantic_structure_checks(data)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('file'); ap.add_argument('--json',action='store_true')
    args=ap.parse_args()
    try: data=json.loads(Path(args.file).read_text(encoding='utf-8'))
    except Exception as e:
        print(json.dumps({'ok':False,'issues':[f'invalid JSON: {e}']},ensure_ascii=False) if args.json else f'INVALID JSON: {e}')
        return 2
    issues=validate(data)
    if args.json: print(json.dumps({'ok':not issues,'issues':issues},ensure_ascii=False,indent=2))
    elif issues:
        print('FAIL'); [print('-',x) for x in issues]
    else: print('PASS: contract matches schema and structural invariants')
    return 1 if issues else 0
if __name__=='__main__': sys.exit(main())
