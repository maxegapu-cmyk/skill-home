#!/usr/bin/env python3
"""Deterministic continuity ledger for explicit facts/events.
No semantic guessing: if a fact/event is absent, the engine does not invent it.
"""
import argparse,json,sys
from pathlib import Path
from contract_validate import validate

CONF_RANK={'UNKNOWN':0,'LOW':1,'MEDIUM':2,'HIGH':3}
FAIL_SEV={'MAJOR','CRITICAL','NEEDS_REVIEW'}

def ctx_key(fact,ctx,shot_id):
    e,a=fact['entity'],fact['attribute']; scope=fact['scope']
    if scope=='instance': return ('instance',e,a)
    if scope=='world': return ('world',ctx['world_id'],e,a)
    if scope=='timeline': return ('timeline',ctx['world_id'],ctx['timeline_id'],ctx['reality_layer'],e,a)
    if scope=='scene': return ('scene',ctx['world_id'],ctx['timeline_id'],ctx['reality_layer'],ctx['scene_id'],e,a)
    return ('shot',shot_id,e,a)

def base_key(x): return (x['entity'],x['attribute'])
def effect_key(effect,ctx,shot_id): return ctx_key(effect,ctx,shot_id)

def mismatch_severity(old_conf,new_conf,persistence):
    if persistence!='hard': return 'NOTE'
    if CONF_RANK.get(old_conf,0) < 2 or CONF_RANK.get(new_conf,0) < 2: return 'NEEDS_REVIEW'
    return 'MAJOR'

def add(findings, **kw): findings.append(kw)

def check_policy(item,policies,shot_id,where,findings):
    """The same entity.attribute must not silently change persistence/scope.
    Otherwise a contract could evade the ledger by re-declaring a hard timeline fact as soft/shot-local.
    """
    bk=base_key(item); policy=(item['persistence'],item['scope'])
    old=policies.get(bk)
    if old and old != policy:
        add(findings,shot=shot_id,where=where,type='STATE_POLICY_MISMATCH',severity='CRITICAL',entity=item['entity'],attribute=item['attribute'],old_policy={'persistence':old[0],'scope':old[1]},new_policy={'persistence':policy[0],'scope':policy[1]},note='Persistence/scope changed for the same state attribute; this can bypass global continuity.')
        return False
    policies.setdefault(bk,policy); return True

def process_assertions(facts,ledger,policies,ctx,shot_id,where,findings):
    for f in facts:
        policy_ok=check_policy(f,policies,shot_id,where,findings)
        key=ctx_key(f,ctx,shot_id); old=ledger.get(key)
        if old and old['value'] != f['value'] and f['persistence']!='shot_local':
            sev=mismatch_severity(old['confidence'],f['confidence'],'hard' if (old['persistence']=='hard' or f['persistence']=='hard') else 'soft')
            add(findings,shot=shot_id,where=where,type='GLOBAL_STATE_DRIFT' if old.get('shot')!=shot_id else 'UNEXPLAINED_STATE_CHANGE',severity=sev,
                entity=f['entity'],attribute=f['attribute'],old=old['value'],new=f['value'],old_shot=old.get('shot'),
                note='Persistent fact changed without an applied event in the active continuity scope.')
        # A policy mismatch must not replace the canonical ledger policy/value.
        if policy_ok and (not old or old['value']==f['value'] or CONF_RANK[f['confidence']] >= CONF_RANK.get(old.get('confidence','UNKNOWN'),0)):
            ledger[key]={**f,'shot':shot_id,'where':where}

def apply_event(event,ledger,policies,ctx,shot_id,where,findings,world_rules):
    tf=event['temporal_fit']
    if tf=='CONFLICT':
        add(findings,shot=shot_id,where=where,type='EVENT_TIME_CONFLICT',severity='CRITICAL',event=event['id'])
        return
    if tf=='UNKNOWN':
        add(findings,shot=shot_id,where=where,type='EVENT_TIME_UNKNOWN',severity='NEEDS_REVIEW',event=event['id'])
    if event['authorized_by']=='world_rule':
        rid=event.get('world_rule_id','')
        if not rid or rid not in world_rules:
            add(findings,shot=shot_id,where=where,type='WORLD_RULE_UNVERIFIED',severity='CRITICAL',event=event['id'],world_rule_id=rid)
    for eff in event['effects']:
        policy_ok=check_policy(eff,policies,shot_id,where,findings)
        key=effect_key(eff,ctx,shot_id); old=ledger.get(key)
        if old is not None and (old.get('persistence')=='hard' or eff['persistence']=='hard') and 'from' not in eff:
            add(findings,shot=shot_id,where=where,type='HARD_EVENT_MISSING_PRECONDITION',severity='NEEDS_REVIEW',event=event['id'],entity=eff['entity'],attribute=eff['attribute'],note='Hard-state event must name its prior value when one is already known.')
        if 'from' in eff and old is not None and old['value'] != eff['from']:
            add(findings,shot=shot_id,where=where,type='EVENT_PRECONDITION_MISMATCH',severity='MAJOR',event=event['id'],entity=eff['entity'],attribute=eff['attribute'],expected=eff['from'],actual=old['value'])
        if policy_ok:
            ledger[key]={
                'entity':eff['entity'],'attribute':eff['attribute'],'value':eff['to'],'confidence':'HIGH',
                'persistence':eff['persistence'],'scope':eff['scope'],'evidence':f"event:{event['id']} {event['evidence']}",
                'shot':shot_id,'where':where,'event':event['id']
            }

def motion_finding(a,b,cut,findings):
    am=a.get('exit_motion'); bm=b.get('entry_motion')
    if not am or not bm: return
    if am['subject']!=bm['subject'] or cut['intent']!='CONTINUOUS_ACTION': return
    opposites={('L_TO_R','R_TO_L'),('R_TO_L','L_TO_R'),('TOWARD','AWAY'),('AWAY','TOWARD')}
    if (am['direction'],bm['direction']) in opposites:
        if CONF_RANK[am['confidence']]>=2 and CONF_RANK[bm['confidence']]>=2:
            add(findings,shot=b['id'],where=f"cut:{a['id']}->{b['id']}",type='MOTION_DIRECTION_BREAK',severity='MAJOR',subject=am['subject'],old=am['direction'],new=bm['direction'],note='Continuous-action cut reverses explicit motion direction; semantic review may accept only with a visible turn or camera-space explanation.')
        else:
            add(findings,shot=b['id'],where=f"cut:{a['id']}->{b['id']}",type='MOTION_DIRECTION_UNCERTAIN',severity='NEEDS_REVIEW',subject=am['subject'])

def lint(data):
    schema_issues=validate(data)
    if schema_issues:
        return [{'type':'INVALID_CONTRACT','severity':'CRITICAL','issues':schema_issues}]
    findings=[]; ledger={}; policies={}; world_rules={x['id'] for x in data.get('world_rules',[])}
    shots=data['shots']; cuts={(c['from'],c['to']):c for c in data['cuts']}
    for idx,s in enumerate(shots):
        ctx=s['context']; sid=s['id']
        process_assertions(s['entry_facts'],ledger,policies,ctx,sid,'entry',findings)
        for e in s['events']: apply_event(e,ledger,policies,ctx,sid,'shot_event',findings,world_rules)
        process_assertions(s['exit_facts'],ledger,policies,ctx,sid,'exit',findings)
        if idx < len(shots)-1:
            nxt=shots[idx+1]; c=cuts[(sid,nxt['id'])]
            motion_finding(s,nxt,c,findings)
            # Cut intent NEVER bypasses persistent world facts. Only concrete transition events can change ledger.
            for e in c['transition_events']:
                apply_event(e,ledger,policies,ctx,sid,f"cut_event:{sid}->{nxt['id']}",findings,world_rules)
    return findings

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('file'); ap.add_argument('--json',action='store_true')
    args=ap.parse_args(); data=json.loads(Path(args.file).read_text(encoding='utf-8'))
    findings=lint(data)
    if args.json: print(json.dumps(findings,ensure_ascii=False,indent=2))
    else:
        if not findings: print('PASS: deterministic continuity ledger found no explicit blocking conflict')
        else:
            print(f'REVIEW: {len(findings)} finding(s)')
            for f in findings: print(f"- {f.get('severity')} | {f.get('type')} | {f.get('where','')} | {f.get('entity','')} {f.get('attribute','')}")
    return 1 if any(f.get('severity') in FAIL_SEV for f in findings) else 0
if __name__=='__main__': sys.exit(main())
