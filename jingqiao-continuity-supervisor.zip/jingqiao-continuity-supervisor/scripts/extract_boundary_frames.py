#!/usr/bin/env python3
"""Extract A-tail and B-head boundary frames using ffmpeg/ffprobe.
No Python package dependencies. Verifies every requested output exists.
"""
import argparse,json,shutil,subprocess,sys
from fractions import Fraction
from pathlib import Path

def run(cmd):
    return subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)

def video_info(path):
    r=run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','format=duration:stream=avg_frame_rate','-of','json',str(path)])
    if r.returncode: raise RuntimeError(r.stderr.strip() or 'ffprobe failed')
    d=json.loads(r.stdout); dur=float(d['format']['duration']); fr=d.get('streams',[{}])[0].get('avg_frame_rate','0/1')
    try: fps=float(Fraction(fr)) if fr and fr!='0/0' else 0.0
    except Exception: fps=0.0
    return dur,fps

def safe_last_time(dur,fps):
    # Container duration often extends slightly past the final decodable frame.
    # Stay one frame (or 40 ms) inside the end so ffmpeg reliably returns pixels.
    margin=(1.0/fps) if fps>0 else 0.04
    return max(0.0,dur-max(margin,0.001))

def frame(path,t,out):
    r=run(['ffmpeg','-y','-loglevel','error','-ss',f'{max(t,0):.6f}','-i',str(path),'-frames:v','1',str(out)])
    if r.returncode or not out.is_file() or out.stat().st_size==0:
        raise RuntimeError((r.stderr.strip() or 'ffmpeg returned no decodable frame')+f' @ {t:.6f}s')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--a',required=True); ap.add_argument('--b',required=True); ap.add_argument('--out-dir',required=True)
    ap.add_argument('--tail-offsets',nargs=3,type=float,default=[0.50,0.25,0.0]); ap.add_argument('--head-offsets',nargs=3,type=float,default=[0.0,0.25,0.50])
    args=ap.parse_args()
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        print('ERROR: ffmpeg and ffprobe are required',file=sys.stderr); return 2
    A=Path(args.a); B=Path(args.b); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    try:
        da,fpa=video_info(A); db,fpb=video_info(B)
        enda=safe_last_time(da,fpa); endb=safe_last_time(db,fpb); items=[]
        for i,off in enumerate(args.tail_offsets,1):
            t=max(0.0, enda-off if off>0 else enda); p=out/f'A_tail_{i}_{t:.3f}s.png'; frame(A,t,p); items.append({'side':'A','slot':i,'time_s':t,'path':p.name})
        for i,off in enumerate(args.head_offsets,1):
            t=min(max(0.0,off),endb); p=out/f'B_head_{i}_{t:.3f}s.png'; frame(B,t,p); items.append({'side':'B','slot':i,'time_s':t,'path':p.name})
    except Exception as e:
        print(f'ERROR: {e}',file=sys.stderr); return 1
    manifest={'a':str(A),'b':str(B),'duration_a':da,'duration_b':db,'fps_a':fpa,'fps_b':fpb,'frames':items}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(out/'manifest.json'); return 0
if __name__=='__main__': sys.exit(main())
