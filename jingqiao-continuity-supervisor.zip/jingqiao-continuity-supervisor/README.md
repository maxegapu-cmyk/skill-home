# 镜桥·连续性监督 2.0.0

这是一个给 Codex / ChatGPT Agent 使用的 AI 视频分镜连续性 Skill。用户可以直接丢自然语言分镜；内部再把镜头编译成“连续性合同”，不要求用户学习状态机或 JSON。

## 2.0 解决的根问题

v1 主要是“相邻 EXIT/ENTRY 比较 + 规则审计”。2.0 改成**事件驱动的全局状态传播**：

- 镜头改变状态必须靠事件；
- 合法省略也必须是具体的 transition event，不再用字段名免检；
- hard state 跨越未提及镜头继续传播；
- match/smash/montage 等只保护剪辑意图，不豁免世界事实；
- world/timeline/reality/entity instance 原生支持复杂剧情；
- Seedance 2.0 分成单次多镜头、独立片段、首尾帧、续拍、边界返修五种编译方式；
- 提供真实 ffmpeg 边界抽帧脚本和视觉复检 Prompt。

## 最简单用法

把文件夹放进 Codex 可扫描的 skills 目录后，直接说：

```text
用 $jingqiao-continuity-supervisor 检查下面所有分镜。只修真实不连续，合法硬切别动；能改两句话就别补镜。最后给我完整可用的修正版。
```

如果目标是 Seedance 2.0：

```text
用 $jingqiao-continuity-supervisor 按 Seedance 2.0 实战方式检查这些分镜。自动判断是单次多镜头、独立片段、首尾帧还是续拍；优先最小修复，必要时给直接可生的桥接 Prompt。
```

## 本地验证

```bash
python scripts/validate_package.py .
python scripts/run_regression.py
python -m unittest discover -s tests -v
```

## 边界抽帧

```bash
python scripts/extract_boundary_frames.py --a shotA.mp4 --b shotB.mp4 --out-dir boundary_frames
```

会输出 A 尾部 3 帧、B 头部 3 帧以及 `manifest.json`。

## 质量声明

任何生成模型都不能诚实保证数学意义的零错误。2.0 的工程目标是：高风险项 fail-closed、真实错误尽量不漏、合法剪辑尽量不误杀、生成失败与设计失败分开处理。

## 回归资产

- 61 条确定性 adversarial regression：由 `scripts/run_regression.py` 实际执行。
- 30 条语义 torture cases：用于 Codex/LLM 盲测，**不把它们冒充为已自动跑通的模型成绩**。
- 单元测试覆盖 Schema、全局状态传播、intentional cut 防旁路、低置信 fail-closed、scope/persistence 降级攻击与 ffmpeg 六帧抽取。
