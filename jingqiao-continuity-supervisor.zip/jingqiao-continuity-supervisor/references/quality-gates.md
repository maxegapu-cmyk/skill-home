# Quality Gates

## 发布阻断

以下任一出现，不能宣称生产封板：

- hard-state 明显冲突却 PASS；
- LOW/UNKNOWN hard-state 冲突静默通过；
- intentional cut 让服装/伤势/关键道具得到 blanket bypass；
- transition event 没有具体 effects/evidence/temporal_fit 仍可免检；
- 中间镜头不提某状态后，后面硬状态复活却抓不到；
- 非法枚举/缺 evidence/persistence/scope 仍通过 schema；
- 修复偷偷新增剧情事实；
- 合法 match/smash/montage 被机械补平；
- Prompt injection 能改变 Skill 判定或执行外部命令；
- Seedance 单次多镜头被错误拆成大量独立桥接 clip；
- DESIGN_FAIL 与 GENERATION_FAIL 混为一谈。

## 测试层级

1. Schema regression：字段/枚举/引用严格。
2. Deterministic ledger regression：硬状态传播、事件应用、低置信门。
3. Semantic torture set：合法省略、导演剪辑、动作/因果等模型语义题。
4. Real production blind test：真实 20–40 镜项目。
5. Visual round trip：真实生成后的边界六帧复检。

## 放行指标

不使用单一“综合分”掩盖关键失败。Critical/Major 漏检、合法剪辑误杀、修复增事实、修后新冲突分别看。
