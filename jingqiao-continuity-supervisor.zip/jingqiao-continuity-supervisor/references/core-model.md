# Core Model — Continuity Contract

## 为什么不用“12 条规则硬扫”做核心

分镜错误看似很多：换手、瞬移、服装漂移、门状态回退、时间不够、动机断裂……底层其实只有一件事：**某个状态发生了变化，却没有一个成立的事件负责这个变化。**

因此 2.0 以 `FACT -> EVENT -> FACT` 为核心。

## Fact

每个事实必须回答：

- `entity`：谁/什么；
- `attribute`：哪个属性；
- `value`：现在是什么；
- `confidence`：证据有多强；
- `persistence`：是否必须持续；
- `scope`：持续到哪个世界/时间线/场景；
- `evidence`：原始材料哪里支持。

### persistence

- `hard`：不能自己变。服装、伤势、关键道具、门/车辆/破坏状态、知识状态等典型属于此类。
- `soft`：可被正常表演/省略改变，如轻微表情、精确站姿。
- `shot_local`：构图、瞬时景别等，不向后传播。

### scope

- `instance`：同一实体实例跨所有上下文持续。适合身份、不应随时间线变的固有属性。
- `world`：同一 world 内持续。
- `timeline`：同一 world + timeline 内持续。服装、伤势、携带物常用。
- `scene`：只在同场戏持续。
- `shot`：只在当前镜头有效。

## Entity instance

不要用“名字”当身份。平行宇宙 Alice、Alice 的克隆体、变形前后若属于不同实体实例，必须有不同 `entity id`。这样不会把合理差异误判成漂移。

## Context

每镜强制有：

- `world_id`
- `timeline_id`
- `reality_layer`
- `scene_id`

普通剧情默认：`W0 / T0 / objective / SCENE_x`。

闪回只需切 `timeline_id` 或 story-time 语义；梦境可切 `reality_layer`；平行宇宙切 `world_id`。不需要给主算法塞大量题材特例。

## Event

Event 是唯一合法的状态改变来源。

必须包含：

- 具体 `effects`（从什么变到什么）；
- `evidence`；
- `authorized_by`；
- 若发生在切口省略区，必须给 `temporal_fit = VERIFIED | UNKNOWN | CONFLICT`。

`UNKNOWN` 不能自动 PASS；`CONFLICT` 直接阻断。

## Ledger

按镜头顺序处理：

1. 用 entry facts 对账既有 ledger；
2. 应用镜头内 events；
3. 用 exit facts 对账；
4. 应用 cut transition events；
5. 进入下一镜。

hard facts 中间即使没再提也继续存在。因此非相邻漂移能被抓住。

## 复杂剧情为什么不需要无限规则

- 时间旅行：timeline/context 变化；
- 平行宇宙：world 变化；
- 梦境：reality layer 变化；
- 克隆/分身：entity instance 变化；
- 变身：同 entity + explicit transformation event；
- 复活：explicit world-rule event；
- 夺舍/换身：identity/body ownership 由事件改变。

只要“谁、在哪个世界/时间线、什么状态、由什么事件改变”表达清楚，就仍然是同一套合同。
