# ComfyUI Boundary Adapter

用户现有“即梦2视频分镜图获取（首尾帧连续）”工作流已经具备可复用的骨架：视频载入、ImageFromBatch+ 抽帧、ImageConcatMulti 拼图、SaveImage，以及多模态节点读取拼图和原 Prompt。

2.0 不依赖该工作流，但可这样改造成视觉验尸器：

1. 不再抽整段 16 格做剧情概括，只抽 A 尾 3 帧 + B 头 3 帧；
2. 拼图顺序固定：A(-0.5) / A(-0.25) / A(last) / B(first) / B(+0.25) / B(+0.5)；
3. 原“80字总结剧情”提示词替换为 `assets/prompts/visual_boundary_audit_prompt.md`；
4. 输出 JSON 视觉事实，不输出创作性解释；
5. 把 OBSERVED facts 与镜桥的 INTENDED facts 对账；
6. 如果只是生成失败，返修视频，不改正确分镜。

独立使用时也可直接运行 `scripts/extract_boundary_frames.py`，不需要 ComfyUI。
