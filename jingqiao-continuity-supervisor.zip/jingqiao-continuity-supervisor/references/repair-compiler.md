# Repair Compiler

## 只修 delta

先锁住 A.EXIT 与 B.ENTRY 不可改的事实，再找最小的缺失 delta。修复不能顺便润色剧情、换镜头风格、加新角色或新道具。

## R0 KEEP

合法切口，不改。

## R1 ANCHOR_PATCH

只补一句/几句状态锚：

- “延续上一镜向右冲刺的惯性……”
- “右手仍握上一镜的手枪……”
- “额角伤口与血迹保持不变……”

适用于“事实本来能接，只是 Prompt 没明确”。

## R2 BOUNDARY_REWRITE

只改 A 尾部与 B 头部，让必要动作真正发生。通常比独立补一镜更稳、更省生成成本。

模板：

```text
A 尾部：在原动作结束前加入 [必要变化]，并明确落到 [目标状态]。
B 开头：从该目标状态直接承接，保持 [身份/持物/方向/伤势/环境锁]。
```

## R3 BRIDGE_OR_REPLAN

只有两种情况：

### Bridge
关键动作/空间/因果必须展示，无法合法省略。

```text
Purpose:
Duration:
START STATE:
MINIMUM TRANSITION:
END STATE:
CAMERA HANDOFF:
AUDIO HANDOFF:
CONTINUITY LOCKS:
DO NOT:
```

### Replan
A.EXIT 和 B.ENTRY 本身互斥，桥接只能靠偷偷新增剧情救场。直接改其中一镜，不做“补镜掩盖”。

## 修后回归

修 `N -> N+1` 后必须重新看：

- `N-1 -> N`
- `N -> N+1`
- `N+1 -> N+2`

若修改了 hard fact，从该点继续传播到序列结束。
