# Cut Intent & Handoff

剪辑意图决定“哪些差异是允许的”，但不负责修改世界事实。

## 常见意图

- `CONTINUOUS_ACTION`：动作/空间/状态强承接。
- `LEGAL_ELLIPSIS`：省略不重要过程；关键状态改变仍要能解释。
- `TIME_JUMP` / `LOCATION_JUMP`：允许时空变化；hard facts 按 scope 传播。
- `SHOT_REVERSE_SHOT`：重点看眼线、屏幕侧和说话/反应逻辑。
- `POV_CUT`：重点看 POV 来源与被看对象。
- `MATCH_CUT`：保护匹配锚点，不要求地点/人物相同。
- `SMASH_CUT`：保护反差，不做“平滑化”。
- `JUMP_CUT_INTENTIONAL`：允许动作/时间跳跃，但不自动允许衣服/伤势/关键道具凭空变。
- `MONTAGE`：局部物理连续权重下降，进度/全局目标/持久状态仍传播。
- `DREAM_OR_SUBJECTIVE`：物理规则可弱化；主观锚点与 reality layer 必须明确。
- `INTENTIONAL_DISCONTINUITY`：只说明视觉/叙事断裂是故意的，不等于 hard-state reset。
- `UNKNOWN_INTENT`：证据不足时不自创导演意图。

## Motion Handoff

动作不靠“角度规则”判断，而看四件事：

1. phase：动作进行到哪里；
2. vector：运动主要方向；
3. energy：速度/惯性是延续、衰减还是刻意突变；
4. contact：人与道具/地面/敌人的接触关系。

换机位可以改变画面方向，但必须让观众仍能理解空间关系。30°/180°只作提示，不是死刑。

## Attention / Audio

连续性正确后再优化流畅：

- A 尾部注意力落点能否被 B 快速接住；
- B 是否回应 A 刚建立的动作/问题/情绪；
- J-cut/L-cut/环境声/动作声可承担接力；
- 喜剧、恐怖、smash cut 的“突然”本身可能就是正确节奏。
