# Changelog

## 2.0.0

- 从“规则叠加”重构为 Continuity Contract + Event Ledger。
- 删除 `explained_changes` 免检机制，所有状态变化必须对应具体事件。
- intentional cut 不再 blanket bypass 持久状态。
- hard fact 的 LOW/UNKNOWN 冲突统一进入 NEEDS_REVIEW。
- 增加跨任意镜头的全局 hard-state propagation。
- 增加 entity instance / world / timeline / reality / scene scope。
- 正式 Schema 由 validator 直接读取并执行，无第三方依赖也能验证。
- 增加 Seedance 2.0 五模式编译策略。
- 增加 ffmpeg 边界 6 帧真实抽取脚本。
- 增加视觉事实审计 Prompt 和 ComfyUI 接入说明。
- 增加确定性 adversarial regression runner 与发布阻断门。
- 默认输出重做为小白友好的“结论 -> 最小修复 -> 完整修正版”。
