# Source Policy — No-X / No-Person Dependency

## 1. Hard firewall

The skill does **not** use X/Twitter as a source, discovery surface, citation target, or corroboration layer. Block direct links, mirrors, screenshots, quoted posts, embedded posts, `t.co`, Nitter-style mirrors, and articles whose underlying evidence is an X/Twitter post.

The stronger rule is **person-source minimization**: a claim must not become publishable merely because a famous researcher, founder, employee, investor, journalist, or influencer said it. This avoids having to maintain a brittle blacklist of people who happen to own an X account.

### Institutional exception

A company/lab/standards body may publish an artifact with a named byline. It is allowed only when the claim is independently embodied in the institution's product state or artifact (release note, docs, repo, model card, price page, status page, policy, paper). Ignore personal commentary and quotes.

## 2. Evidence tiers

| Tier | Evidence | Default use |
|---|---|---|
| A | official release/docs/status/pricing/repo/model card; primary paper; standards body | can establish facts directly |
| B | reproducible independent test; GitHub issue/discussion with artifacts; multiple technical community reports | corroboration / early warning |
| C | reputable secondary media with independent reporting | context and corroboration, not enough for technical specifics when primary artifacts should exist |
| D | anonymous rumor, aggregator copy, SEO listicle, affiliate review, repost, person-centered prediction | do not publish as fact |

## 3. Claim-specific proof requirements

- **New model / feature:** official release or docs/model card/repo.
- **Price / quota / limits:** official pricing, plan docs, billing UI/help center. A user's screenshot is only a lead.
- **Deprecation / shutdown:** official changelog/deprecation docs.
- **Outage:** official status page + user reports if impact matters.
- **Benchmark:** methodology + dataset + settings + date + preferably independent reproduction. Vendor chart alone is marketing evidence.
- **Open-source project:** original repository, release tags, commit history, issue health, license, maintainer/org identity.
- **Security incident:** vendor advisory/CVE/maintainer advisory + independent security reporting when available.
- **Rumor:** default off. If explicitly requested, require at least 3 independent non-person-dependent signals and label `UNVERIFIED`; never upgrade without a primary artifact.

## 4. Anti-scam / anti-hype checks

Hold or block when any of these are present:

- lookalike/misspelled domains or org identity mismatch;
- download binaries/weights from a third-party host when an official host exists;
- coupon/referral/affiliate pressure mixed into a supposed review;
- impossible claims with no artifact (`unlimited`, `free forever`, `100%`, `guaranteed`);
- benchmark without methodology or cherry-picked single-task charts;
- GitHub fork presented as the original project;
- model file/license mismatch;
- article is mostly copied social posts or screenshots;
- a "breaking" story has no event date, only a publication date.

## 5. Independence test

Two pages are **not** independent if one copied the other, both quote the same person/post, both originate from one press release without extra evidence, or they are mirrors/syndication. Count independent evidence chains, not URL count.
