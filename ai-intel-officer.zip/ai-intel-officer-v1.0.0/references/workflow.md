# Operating Workflow

## Sweep order

1. **Primary sweep:** release notes, changelogs, pricing/deprecation/status pages, official repositories and model cards.
2. **Research sweep:** arXiv/papers, linked code/model artifacts, benchmark methodology.
3. **Community sweep:** Hacker News, Reddit, GitHub Issues/Discussions for breakage, regressions, hidden limits, and real-user reproduction clues.
4. **Secondary sweep:** reputable media for legal/business context or events not represented by a product artifact.
5. **Backtrace every important claim** to the strongest available primary object.
6. Apply person/X firewall, independence test, risk checks, and dedupe.
7. Rank by **user impact**, not social popularity.

## Priority model

- **P0 — immediate action:** shutdown/deprecation deadline, major price/quota change, security issue, outage, breaking API incompatibility.
- **P1 — high value:** major model/tool release, substantial capability/latency/cost change, important open-source release.
- **P2 — watch:** meaningful paper, benchmark movement, ecosystem trend with evidence but no immediate action.
- **P3 — noise:** personality drama, predictions, vague teasers, funding gossip without user impact, social virality.

## Relevance score

Score 0–5 each:

- Impact: changes what a practitioner can do/pay/use?
- Freshness: new today/this week rather than recycled?
- Evidence: primary/reproducible?
- Actionability: is there something to try/migrate/watch?
- Novelty: not a duplicate/rewording?

Default publish threshold: **16/25**, except P0 safety/compatibility items may publish below it if primary evidence is strong.

## Dedupe

Cluster items that describe the same underlying event. Keep one canonical item and attach corroboration under it. Never create five bullets from five stories about one release.

## Daily brief contract

For each accepted item:

**[P0/P1/P2] One-line verdict**  
What changed: 1–3 sentences.  
Why it matters: concrete user impact.  
Evidence: `A/B/C` with links to the strongest objects.  
Confidence: `high / medium / low`.  
Action: `do now / test / watch / ignore`.  
Caveat: only if it can change the decision.

End with:
- `今天真正值得看：N 条`
- `暂扣未证实：N 条`
- `去重丢弃：N 条`
- `X/人物来源拦截：N 条`
