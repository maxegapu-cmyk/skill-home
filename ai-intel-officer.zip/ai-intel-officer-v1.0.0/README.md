# AI Intel Officer v1.0.0

高信噪比 AI 信息员 Skill。核心是“物证优先、人物降权、X/Twitter 硬屏蔽”。

## 安装/使用

把整个 `ai-intel-officer-v1.0.0` 文件夹放进你使用的 Agent Skills 目录；不同运行时目录可能不同。Skill 主入口是 `SKILL.md`。

无需第三方 Python 包。可先运行：

```bash
python scripts/intel_guard.py --selftest
python -m unittest discover -s tests -v
```

## 适合的问法

- “做今天 AI 圈情报，别给我人物八卦，只要真有用的。”
- “查最近 7 天模型、价格、额度、下线变化。”
- “盯 AI 视频模型最近有什么真更新。”
- “GitHub 最近有哪些值得用的 AI 项目，排除刷星垃圾。”
- “这个传闻是真的假的？只认能核验的东西。”

## 设计取舍

这套 Skill 会故意漏掉一部分“最早由名人放出来的风声”。这是主动设计：它追求的是可核验和不坑人，而不是社交媒体最快速度。
