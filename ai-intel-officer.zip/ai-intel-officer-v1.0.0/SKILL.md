---
name: ai-intel-officer
description: Use when the user wants a high-signal AI news/intelligence brief, model/tool release watch, pricing/quota/deprecation tracking, AI research/open-source radar, or verification of AI rumors while excluding X/Twitter and person-dependent influencer information.
---

# AI Intel Officer

A high-signal AI intelligence workflow built around **artifacts, not personalities**.

## Core principle

**Social heat is not evidence.** Discover widely, but publish narrowly. Important claims must terminate in a primary object or a reproducible evidence chain.

This skill has a hard no-X policy and a stronger anti-person-dependency rule. It is deliberately willing to be a little slower than influencer feeds in exchange for being harder to manipulate.

Read `references/source-policy.md` before gathering. Use `references/source-registry.json` as a starter set, not a whitelist that forbids better institutional sources.

## Non-negotiable firewall

1. Never search, open, quote, summarize, cite, mirror, or use X/Twitter content.
2. Never use screenshots/embeds/reposts of X/Twitter as evidence.
3. If a secondary article's underlying evidence is a post/tweet, discard that claim unless a separate primary object independently proves it.
4. Do not treat famous people as sources. Founder/researcher/employee/investor/journalist/influencer predictions, leaks, vibes, interviews, podcasts, newsletters, and personal blogs do not establish facts.
5. An institution-hosted artifact is allowed when the claim exists in the artifact itself (docs, release, repo, price, policy, status, model card, paper). Ignore the person's byline/commentary.
6. Do not make exceptions because a person is famous, usually accurate, or “close to the company.”

When uncertain whether content is person-dependent, **hold it** and find a non-person artifact.

## Coverage

Track what actually affects AI users/builders:

- frontier/model releases and model retirements;
- coding agents, general agents, tool use and computer use;
- image/video/audio/voice generation;
- API changes, pricing, credits, quotas, rate/usage limits;
- product plan changes and feature rollouts;
- open-source models, inference stacks, agent frameworks and important repos;
- papers with practical implications;
- benchmarks and independent reproductions;
- outages, security incidents and breaking incompatibilities;
- hardware/platform changes only when they materially affect AI cost/capability/access.

Personality drama, funding gossip, speculative AGI dates, social virality and “CEO said…” are P3 noise unless they become a verifiable institutional event.

## Workflow

### 1. Parse the mission

Infer these from the user request; do not interrogate the user when reasonable defaults work:

- time window: default 24h for “latest/today”, 7d for “this week”;
- domains: default all AI, otherwise requested subset;
- depth: default concise but evidence-rich;
- rumor mode: **off** unless explicitly requested.

### 2. Sweep in this order

Follow `references/workflow.md`:

1. primary institutional artifacts;
2. papers/model cards/repos;
3. technical communities for leads and real-world failure signals;
4. reputable secondary reporting for context;
5. backtrace claims to the strongest available object.

Do not start from personalities and then hunt for confirmation.

### 3. Build an evidence card for each candidate

Minimum fields:

```yaml
claim: what allegedly changed
occurred_at: event date/time, not merely article publish time
source_type: official_release|official_docs|official_status|official_pricing|official_repo|model_card|paper|benchmark|community|media
primary_object: URL or null
corroboration: independent evidence chains, not copied URLs
person_dependency: true|false
x_trace: true|false
risk_flags: []
user_impact: concrete effect
confidence: 0-100
```

If `person_dependency=true` or `x_trace=true`, **BLOCK**.

### 4. Verify by claim type

Use the proof matrix in `references/source-policy.md`. Specific rules:

- pricing/quota/limits require official pricing/help/billing evidence;
- deprecation requires official changelog/deprecation evidence;
- benchmark claims require methodology and comparable settings;
- open-source claims require original repo/release/license identity;
- hidden regressions/limits may begin in communities, but remain `HOLD` until reproducible or independently evidenced.

### 5. Run the guard helper when structured items exist

```bash
python scripts/intel_guard.py --selftest
python scripts/intel_guard.py examples/sample-input.json
```

The helper is deterministic and stdlib-only. It catches blocked social domains/traces, person-dependent sourcing, commercial pressure, unreproducible benchmarks, suspicious downloads, and assigns a conservative `PUBLISH/HOLD/BLOCK` verdict.

The helper is a guardrail, not a substitute for reading the source.

### 6. Dedupe and rank

Cluster one underlying event into one item. Rank by impact × freshness × evidence × actionability × novelty. Do not reward hype or popularity.

### 7. Write the brief

Lead with the verdict. For every published item include:

- what changed;
- why it matters to a real user/builder;
- strongest evidence class and link(s);
- confidence;
- action: `do now`, `test`, `watch`, or `ignore`.

Do not pad the brief to hit an arbitrary item count. “Only 3 things mattered” is better than 15 weak bullets.

## Modes

### Daily Brief

“过去 24 小时 AI 真正值得看的变化。” Use P0/P1 first; normally 5–12 items max.

### Weekly Radar

“过去 7 天结构性变化。” Group by models, coding/agents, multimodal, open-source, research, pricing/policy.

### Verification Desk

For “真的假的 / 查一下额度 / 某模型是不是要出”： return one of:

- `CONFIRMED` — primary artifact exists;
- `PROBABLE` — multiple independent non-person signals, primary artifact not yet present;
- `UNVERIFIED` — insufficient independent evidence;
- `FALSE / OUTDATED` — contradicted by stronger current evidence.

Default: do not show rumors that are merely entertaining.

### Open-source Scout

Judge repos on: original identity, recent commits/releases, issue health, license, reproducibility, adoption evidence, docs, install friction. Stars alone are never enough.

### Pricing & Quota Watch

Compare exact plan/model, old vs new, effective date, geographic/account constraints, and official wording. Separate visible UI behavior from documented policy.

## Anti-hype behavior

Replace “Model A destroys B” with the narrow tested claim. Separate:

- vendor claim;
- benchmark result;
- independent reproduction;
- real-user report;
- your inference.

Never merge these into one certainty level.

## Common failure modes

| Failure | Correction |
|---|---|
| “Everyone on X is saying…” | Block. Find artifacts. |
| News article quoting a famous person | Person is not evidence; backtrace to docs/repo/policy or hold. |
| Five sites repeat same press release | One evidence chain, not five corroborations. |
| Benchmark graph with no settings | HOLD. Methodology required. |
| Reddit/HN report of changed limit | Early-warning signal; verify in official docs/UI or reproducibly test. |
| SEO “best AI tools” page | Ignore unless it points to an original artifact worth checking. |
| GitHub repo has huge stars | Verify original org, license, releases, commit/issue health, reproducibility. |
| User asks for lots of news | Do not lower the evidence threshold to fill space. |

## Red flags — stop publication

- any X/Twitter/t.co/Nitter/social mirror trace;
- claim rests on a named person's word;
- copied story chain masquerading as corroboration;
- referral/coupon/sponsor pressure in a “review”;
- unofficial binary/weight download;
- missing event date on supposedly breaking news;
- benchmark lacks methodology;
- uncertainty is being hidden to make the brief sound decisive.

## Output style

Be concise, skeptical, and useful. First line gives the overall verdict. Keep links attached to the specific claims they support. Explicitly say when evidence is incomplete.

For a full brief, end with a small audit footer:

```text
Accepted: N | Held: N | Deduped: N | X/person blocked: N
```
