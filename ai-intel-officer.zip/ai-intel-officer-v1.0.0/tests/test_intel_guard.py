import json
import sys
import unittest
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from intel_guard import evaluate_item, normalize_title, story_fingerprint  # noqa: E402


class IntelGuardTests(unittest.TestCase):
    def test_blocks_x_domain(self):
        r = evaluate_item({"url": "https://x.com/someone/status/1", "source_type": "institution", "title": "Model rumor"})
        self.assertEqual(r["verdict"], "BLOCK")
        self.assertIn("blocked_social_domain", r["reasons"])

    def test_blocks_twitter_domain(self):
        r = evaluate_item({"url": "https://twitter.com/someone/status/1", "source_type": "media", "title": "AI update"})
        self.assertEqual(r["verdict"], "BLOCK")

    def test_blocks_person_source_even_off_x(self):
        r = evaluate_item({"url": "https://example.com/interview", "source_type": "person", "title": "Famous researcher predicts AGI"})
        self.assertEqual(r["verdict"], "BLOCK")
        self.assertIn("person_dependent_source", r["reasons"])

    def test_blocks_person_as_primary_evidence(self):
        r = evaluate_item({
            "url": "https://news.example.com/story",
            "source_type": "media",
            "title": "CEO says new model is coming",
            "named_person_as_primary_evidence": True,
        })
        self.assertEqual(r["verdict"], "BLOCK")

    def test_official_release_can_publish(self):
        r = evaluate_item({
            "url": "https://openai.com/products/release-notes/",
            "source_type": "official_release",
            "title": "Release notes update",
            "has_primary_artifact": True,
            "corroboration_count": 1,
            "published_at": "2026-10-02",
        })
        self.assertEqual(r["verdict"], "PUBLISH")
        self.assertGreaterEqual(r["confidence"], 85)

    def test_single_community_claim_is_hold(self):
        r = evaluate_item({
            "url": "https://news.ycombinator.com/item?id=123",
            "source_type": "community",
            "title": "Users report model limit changed",
            "corroboration_count": 1,
        })
        self.assertEqual(r["verdict"], "HOLD")
        self.assertLess(r["confidence"], 70)

    def test_benchmark_without_methodology_is_hold(self):
        r = evaluate_item({
            "url": "https://example.org/benchmark",
            "source_type": "benchmark",
            "title": "Model A destroys Model B",
            "benchmark_methodology": False,
            "corroboration_count": 2,
        })
        self.assertEqual(r["verdict"], "HOLD")
        self.assertIn("benchmark_without_methodology", r["reasons"])

    def test_affiliate_or_coupon_is_flagged(self):
        r = evaluate_item({
            "url": "https://example.org/best-ai?ref=abc",
            "source_type": "media",
            "title": "Best AI tool - 50% off with coupon",
            "corroboration_count": 3,
        })
        self.assertIn("commercial_pressure", r["risk_flags"])
        self.assertNotEqual(r["verdict"], "PUBLISH")

    def test_tco_is_blocked(self):
        r = evaluate_item({"url": "https://t.co/abc", "source_type": "official_release", "title": "update"})
        self.assertEqual(r["verdict"], "BLOCK")

    def test_x_trace_in_text_is_blocked(self):
        r = evaluate_item({
            "url": "https://example.org/post",
            "source_type": "media",
            "title": "Rumor roundup",
            "text": "According to a tweet from @famousperson, the model launches tomorrow.",
        })
        self.assertEqual(r["verdict"], "BLOCK")
        self.assertIn("social_attribution_trace", r["reasons"])

    def test_explicit_x_trace_field_blocks(self):
        r = evaluate_item({
            "url": "https://example.org/story",
            "source_type": "media",
            "title": "AI update",
            "x_trace": True,
        })
        self.assertEqual(r["verdict"], "BLOCK")

    def test_explicit_person_dependency_field_blocks(self):
        r = evaluate_item({
            "url": "https://example.org/story",
            "source_type": "media",
            "title": "AI update",
            "person_dependency": True,
        })
        self.assertEqual(r["verdict"], "BLOCK")

    def test_xgboost_not_false_positive(self):
        r = evaluate_item({
            "url": "https://arxiv.org/abs/1234.5678",
            "source_type": "paper",
            "title": "XGBoost for tabular learning",
            "has_primary_artifact": True,
        })
        self.assertNotEqual(r["verdict"], "BLOCK")

    def test_title_normalization(self):
        self.assertEqual(normalize_title("  GPT-Next: BIG Update!!! "), "gpt next big update")

    def test_story_fingerprint_dedupes_minor_punctuation(self):
        a = story_fingerprint("Model-X v2 released!", "official_release")
        b = story_fingerprint("Model X v2 — released", "official_release")
        self.assertEqual(a, b)


class RegistryTests(unittest.TestCase):
    def test_registry_has_no_blocked_allowed_domains(self):
        registry = json.loads((ROOT / "references" / "source-registry.json").read_text(encoding="utf-8"))
        blocked_hosts = {"x.com", "www.x.com", "twitter.com", "www.twitter.com", "t.co", "www.t.co", "nitter.net", "www.nitter.net", "twimg.com", "pbs.twimg.com", "video.twimg.com"}
        for source in registry["sources"]:
            if source.get("status") != "allowed":
                continue
            host = (urlparse(source["url"]).hostname or "").lower()
            self.assertNotIn(host, blocked_hosts, source)


if __name__ == "__main__":
    unittest.main()
