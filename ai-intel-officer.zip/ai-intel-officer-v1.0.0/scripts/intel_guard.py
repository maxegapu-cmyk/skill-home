#!/usr/bin/env python3
"""Deterministic guardrail/scoring helper for AI Intel Officer.

Stdlib-only. It does not browse the web. It evaluates already-collected items,
so the same policy can be used in ChatGPT, Codex, Claude Code, or a cron job.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, parse_qs

BLOCKED_HOSTS = {
    "x.com", "www.x.com", "mobile.x.com",
    "twitter.com", "www.twitter.com", "mobile.twitter.com",
    "t.co", "www.t.co",
    "nitter.net", "www.nitter.net",
    "twimg.com", "pbs.twimg.com", "video.twimg.com",
}

PERSON_TYPES = {"person", "personal_blog", "personal_newsletter", "social"}
PRIMARY_TYPES = {
    "official_release", "official_docs", "official_status", "official_pricing",
    "official_repo", "model_card", "paper", "standards_body",
}
COMMUNITY_TYPES = {"community", "forum", "issue", "discussion"}
SECONDARY_TYPES = {"media", "database", "aggregator"}

SOCIAL_TRACE_RE = re.compile(
    r"(?:https?://(?:www\.)?(?:x\.com|twitter\.com|t\.co)/|\b(?:tweet|tweeted|twitter|on x)\b|"
    r"(?:according to|via)\s+@\w+)",
    re.IGNORECASE,
)
COMMERCIAL_RE = re.compile(
    r"\b(?:coupon|promo\s*code|discount\s*code|sponsored|affiliate|limited\s*time\s*offer|"
    r"buy\s*now|50%\s*off|%\s*off)\b",
    re.IGNORECASE,
)
HYPE_RE = re.compile(
    r"\b(?:destroys|obliterates|kills|game[- ]changer|insane|unbelievable|guaranteed|"
    r"best\s+ever|revolutionary)\b",
    re.IGNORECASE,
)


def _host(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").lower().rstrip(".")
    except Exception:
        return ""


def normalize_title(title: str) -> str:
    s = title.lower().strip()
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def story_fingerprint(title: str, source_type: str = "") -> str:
    # Source type is deliberately not part of the fingerprint: the same story
    # from a release page and a news article should dedupe together.
    normalized = normalize_title(title)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def _has_commercial_pressure(item: dict[str, Any]) -> bool:
    text = " ".join(str(item.get(k, "")) for k in ("title", "text", "url"))
    if COMMERCIAL_RE.search(text):
        return True
    try:
        qs = parse_qs(urlparse(str(item.get("url", ""))).query)
        return any(k.lower() in {"ref", "referral", "affiliate", "aff", "coupon", "promo"} for k in qs)
    except Exception:
        return False


def evaluate_item(item: dict[str, Any]) -> dict[str, Any]:
    """Return deterministic verdict, confidence and reasons.

    Required-ish fields: url, source_type, title.
    Optional fields are intentionally simple booleans/counts so an LLM or a
    scraper can populate them without a custom SDK.
    """
    url = str(item.get("url", ""))
    source_type = str(item.get("source_type", "")).lower().strip()
    title = str(item.get("title", ""))
    text = str(item.get("text", ""))

    reasons: list[str] = []
    risk_flags: list[str] = []

    # HARD BLOCK: social/X traces and person-dependent sourcing.
    host = _host(url)
    if host in BLOCKED_HOSTS or host.endswith(".twitter.com") or host.endswith(".x.com"):
        reasons.append("blocked_social_domain")
    if SOCIAL_TRACE_RE.search(" ".join((url, title, text))) or bool(item.get("x_trace")):
        reasons.append("social_attribution_trace")
    if source_type in PERSON_TYPES or bool(item.get("person_centric")) or bool(item.get("person_dependency")):
        reasons.append("person_dependent_source")
    if bool(item.get("named_person_as_primary_evidence")):
        reasons.append("named_person_primary_evidence")

    if reasons:
        return {
            "verdict": "BLOCK",
            "confidence": 0,
            "reasons": sorted(set(reasons)),
            "risk_flags": risk_flags,
            "fingerprint": story_fingerprint(title, source_type),
        }

    # Risk flags: these do not automatically make a source false; they lower
    # confidence and may force HOLD until independently verified.
    if _has_commercial_pressure(item):
        risk_flags.append("commercial_pressure")
    if HYPE_RE.search(title):
        risk_flags.append("hype_language")
    if source_type == "benchmark" and not bool(item.get("benchmark_methodology")):
        reasons.append("benchmark_without_methodology")
        risk_flags.append("unreproducible_benchmark")
    if bool(item.get("download_from_unofficial_host")):
        risk_flags.append("unofficial_download")
    if bool(item.get("domain_mismatch")):
        risk_flags.append("domain_or_identity_mismatch")
    if bool(item.get("anonymous_single_source")):
        risk_flags.append("anonymous_single_source")

    corroboration = max(0, int(item.get("corroboration_count", 0) or 0))
    primary_artifact = bool(item.get("has_primary_artifact"))

    # Base confidence by evidence class.
    if source_type in PRIMARY_TYPES:
        confidence = 82
    elif source_type == "benchmark":
        confidence = 58 if item.get("benchmark_methodology") else 35
    elif source_type in COMMUNITY_TYPES:
        confidence = 35
    elif source_type in SECONDARY_TYPES:
        confidence = 45
    else:
        confidence = 30

    if primary_artifact:
        confidence += 10
    confidence += min(corroboration, 4) * 4

    penalties = {
        "commercial_pressure": 35,
        "hype_language": 8,
        "unreproducible_benchmark": 25,
        "unofficial_download": 40,
        "domain_or_identity_mismatch": 50,
        "anonymous_single_source": 30,
    }
    for flag in risk_flags:
        confidence -= penalties.get(flag, 0)
    confidence = max(0, min(100, confidence))

    # Publishing contract.
    if "domain_or_identity_mismatch" in risk_flags or "unofficial_download" in risk_flags:
        verdict = "BLOCK"
        reasons.append("unsafe_source_identity")
    elif "commercial_pressure" in risk_flags:
        verdict = "HOLD"
        reasons.append("needs_noncommercial_verification")
    elif source_type == "benchmark" and not item.get("benchmark_methodology"):
        verdict = "HOLD"
    elif source_type in PRIMARY_TYPES and confidence >= 85:
        verdict = "PUBLISH"
    elif source_type in COMMUNITY_TYPES:
        # Community reports remain a signal unless there is a real artifact.
        verdict = "PUBLISH" if (primary_artifact and corroboration >= 2 and confidence >= 65) else "HOLD"
    elif source_type in SECONDARY_TYPES:
        verdict = "PUBLISH" if (primary_artifact and corroboration >= 2 and confidence >= 70) else "HOLD"
    else:
        verdict = "PUBLISH" if (primary_artifact and confidence >= 75) else "HOLD"

    return {
        "verdict": verdict,
        "confidence": confidence,
        "reasons": sorted(set(reasons)),
        "risk_flags": sorted(set(risk_flags)),
        "fingerprint": story_fingerprint(title, source_type),
    }


def _selftest() -> int:
    samples = [
        ({"url": "https://x.com/a/status/1", "source_type": "official_release", "title": "x"}, "BLOCK"),
        ({"url": "https://openai.com/products/release-notes/", "source_type": "official_release", "title": "release", "has_primary_artifact": True, "corroboration_count": 1}, "PUBLISH"),
        ({"url": "https://news.ycombinator.com/item?id=1", "source_type": "community", "title": "report", "corroboration_count": 1}, "HOLD"),
        ({"url": "https://example.org/p", "source_type": "person", "title": "prediction"}, "BLOCK"),
    ]
    failed = 0
    for item, expected in samples:
        actual = evaluate_item(item)["verdict"]
        if actual != expected:
            failed += 1
            print(f"FAIL expected={expected} actual={actual} item={item}")
    if failed:
        return 1
    print(f"SELFTEST PASS: {len(samples)}/{len(samples)}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate AI intel items against no-X/person firewall policy")
    parser.add_argument("json_file", nargs="?", help="JSON array or JSONL file of items")
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        return _selftest()
    if not args.json_file:
        parser.error("provide json_file or --selftest")

    p = Path(args.json_file)
    raw = p.read_text(encoding="utf-8").strip()
    if not raw:
        return 0
    try:
        payload = json.loads(raw)
        items = payload if isinstance(payload, list) else [payload]
    except json.JSONDecodeError:
        items = [json.loads(line) for line in raw.splitlines() if line.strip()]

    for item in items:
        out = dict(item)
        out["policy"] = evaluate_item(item)
        print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
