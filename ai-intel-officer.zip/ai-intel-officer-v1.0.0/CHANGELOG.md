# Changelog

## 1.0.0 — 2026-10-05

- Hard-block X/Twitter, mirrors, social traces and attribution laundering.
- Add stronger person-dependent-source firewall.
- Add artifact-first evidence tiers and claim-specific proof matrix.
- Add anti-scam, anti-affiliate and benchmark-methodology checks.
- Add P0–P3 priority model, dedupe and relevance scoring.
- Add deterministic stdlib-only `intel_guard.py` and unit tests.
- Add starter institutional/community source registry.
