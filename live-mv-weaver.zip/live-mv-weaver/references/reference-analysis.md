# Reference Analysis

Use the reference as structural evidence, not aesthetic decoration.

## Deterministic pass

```bash
python scripts/analyze_reference.py reference.mp4 --output-dir analysis --contact-sheet
```

This records media metadata, visual change candidates, interval statistics, representative frames and contact sheets. A cut candidate means only that the picture changed.

## Semantic pass

Label every interval with one role:
`performance_anchor`, `performance_detail`, `audience_reaction`, `audience_dialogue`, `callback_dialogue`, `emotional_carrier`, `crowd_witness`, `band_detail`, `payoff`.

Also record: `subjects`, `thread_id`, `location_id`, `camera`, `action`, `emotion_stage`, `music_trigger`, `dialogue_present`, and whether the sequence returns to performance.

Then derive the working profile:

```bash
python scripts/derive_reference_profile.py annotated_reference.json --output reference_style_profile.json
```

## What to measure

- performer screen share;
- performance-anchor and reaction medians;
- longest non-performance excursion;
- number and placement of dialogue overlays;
- recurring audience threads;
- emotional stage changes;
- setup/callback structure;
- camera-map reuse and same-world continuity.

At every audience cut ask:
1. Why leave the performer now?
2. What exact musical/dramatic event brings us back?

“For variety” means the analysis is unfinished.
