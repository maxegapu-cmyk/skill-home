# QA Gates

## Hard gates

1. **SONG CLOCK:** no pause/reset/replacement after the performance begins.
2. **TIMELINE:** no unintended gap or overlap.
3. **WORLD:** no unauthorized live-world jump.
4. **DIALOGUE:** overlay mode, plausible density, defensible music clearance and non-destructive ducking.
5. **WEAVE:** every non-performance insertion has leave/return logic.
6. **THREADS:** audience shots belong to recurring threads with controlled emotion stages.
7. **CALLBACK:** a declared setup is closed, then the ending is handed back to performance.
8. **REFERENCE PROFILE:** in strict mode, screen share, medians and excursion density stay inside the calibrated band.
9. **IDENTITY/STATE:** recurring people retain identity, wardrobe, geography, props and observable state.

## Semantic gates

- lyric meaning produces human consequence before literal illustration;
- early reactions leave headroom for later emotion;
- crowd-wide proof follows smaller individual evidence;
- one clip contains one executable beat;
- camera variety never changes the underlying room;
- a prettier candidate does not beat a more continuous candidate when the prettier one breaks the world.

## Verdict

`qc_report.md` ends with `PASS`, `REVISE`, or `REFERENCE_CONFLICT`. A `PASS` needs zero hard errors and a semantic reference-fidelity score of at least 90/100 unless the user explicitly approves a reference override.
