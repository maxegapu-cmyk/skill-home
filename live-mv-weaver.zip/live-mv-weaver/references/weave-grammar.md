# Weave Grammar

## Roles

| Role | Job | Tendency |
|---|---|---|
| `performance_anchor` | Re-lock viewer to singer/event/song | longer |
| `performance_detail` | Face, hands, instrument, breath | medium |
| `audience_reaction` | Attention/emotion micro-beat | short |
| `audience_dialogue` | One quick in-world line over song | short |
| `callback_dialogue` | Close the setup/proposition | short-medium |
| `emotional_carrier` | Strong recurring personal reaction | short |
| `crowd_witness` | Prove communal contagion | short-medium |
| `band_detail` | Keep live performance physically present | short |
| `payoff` | Applause/release/final joke/community | as needed |

## Leave/return contract

Every non-performance shot in strict mode contains:
- `leave_reason`: why the edit leaves the performer at this exact moment;
- `return_trigger`: what phrase, reaction completion, downbeat, callback completion or energy change returns the edit to performance.

Do not use “visual variety.”

## Audience thread ledger

Every audience role carries `thread_id` and `emotion_stage` (0–5). Store seat/mark, partner, wardrobe, prop/hand state, stage eyeline, last observable emotion and callback opportunity. Strict reference mode expects at least two recurring audience threads by default.

Emotion stages are not acting labels; they are escalation budget:
`0 casual → 1 notices → 2 listens → 3 personal resonance → 4 visibly affected → 5 peak/release`.

A sharp regression needs an explicit visible reset reason.

## Weave rhythm

A useful unit is `P → A → P → A/A → P → D/A → P`, but never repeat it mechanically. In the calibrated profile, non-performance runs usually finish inside 2–5 seconds and one to three shots. The song continues across every arrow.
