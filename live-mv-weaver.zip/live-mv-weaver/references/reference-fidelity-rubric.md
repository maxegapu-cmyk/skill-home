# Reference Fidelity Rubric

Use deterministic validation first. Then score the semantic result out of 100.

| Dimension | Weight | Full-credit test |
|---|---:|---|
| Master-song continuity | 20 | The song remains perceptually continuous through every cut and in-world line. |
| Performance/audience weave | 20 | Every excursion has a dramatic leave reason and a musically clean return; the singer remains the spine. |
| Same-minute world | 15 | Venue geography, light, wardrobe, props, eyelines and current action all feel like the same live minute. |
| Audience threads/callback | 15 | Recurring people accumulate state; setup characters return; payoff remembers the beginning. |
| Emotional escalation | 10 | Attention precedes resonance, resonance precedes visible emotion, communal proof arrives after individual proof. |
| Rhythm profile | 10 | Performance anchors breathe longer than reactions and the reference-derived coverage/excursion pattern is recognizable. |
| Generation executability | 5 | Each generated clip asks for one feasible action beat with a useful start/end state. |
| Audio/editorial polish | 5 | Dialogue is intelligible without muting the song; J/L behavior and cut timing feel intentional. |

## Verdicts

- `90–100`: reference grammar is strongly preserved; only polish remains.
- `80–89`: usable but at least one layer feels generic or weak.
- `70–79`: recognizable concept, insufficient fidelity for a demanding reference-replica brief.
- `<70`: redesign the weave before spending more generation budget.

Hard failures override the numeric score. A broken master-song clock, world jump, missing callback required by the setup, or dialogue that replaces the song cannot be averaged away by pretty images.
