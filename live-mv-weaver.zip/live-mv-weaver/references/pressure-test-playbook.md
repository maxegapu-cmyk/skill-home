# Pressure-Test Playbook

Before calling a plan production-ready, try to break it.

Run:

```bash
python -m unittest discover -s tests -v
python scripts/validate_mv_plan.py examples/live-bar-example.json --json
```

The packaged pressure suite covers these failure families:

1. song paused/reset after performance begins;
2. audience dialogue replaces rather than overlays the song;
3. illegal same-world location jump;
4. timeline gap/overlap;
5. unknown shot role or missing required field;
6. non-performance cut with no leave/return logic;
7. random one-off spectators instead of recurring audience threads;
8. impossible dialogue density for the visual window;
9. music ducking deep enough to make the song feel interrupted;
10. dialogue inserted without a music-clearance reason;
11. emotional peak spent too early;
12. recurring audience thread regresses sharply without a visible reset reason;
13. reference rhythm drifts: wrong performance share, reaction median or excursion length;
14. setup/callback exists but the ending is stolen from the performer;
15. too many consecutive non-performance shots.

## Stress-test mindset

A plan can be technically continuous and still fail the archetype. Attack the exact temptations that make AI MVs feel synthetic: random beauty shots, explanatory flashbacks, dialogue scenes that hijack the song, immediate crying, new spectators every cut, unmotivated camera variety, and long generated clips with too many internal beats.

Fix the smallest failing layer: timeline → thread/state → shot intent → keyframe → motion prompt → clip candidate → edit. Do not rewrite the whole MV because one clip failed.
