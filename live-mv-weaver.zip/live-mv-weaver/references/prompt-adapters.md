# Prompt Adapters

## One unit, one beat

A generated clip gets one clear start state, one observable action, one dominant camera behavior and one explicit end state. Exact cut timing belongs to the EDL/shot manifest.

## Keyframe prompt order

`identity/state + exact live-world zone + framing/composition + current action + eyeline/partner geometry + lighting/material continuity + emotional micro-state + lens/camera feel`

Use a cinematic frame that already resembles the final MV. Neutral character cards and grids are upstream references, not the primary moving frame.

## Motion prompt order

1. first-frame state;
2. single main action;
3. camera behavior;
4. interaction geometry and props;
5. performance relation to the ongoing master song;
6. final handoff state.

For readable singer shots, use a complete vocal phrase as the performance unit when phrase-guided sync is supported. For audience shots, prefer tiny physical changes: smile stops, gaze shifts, fingers still, swallow, slow blink, one tear forming, friend noticing.

## Reference-video use

When the active video system supports reference-video guidance, use it for camera/cut/motion character where appropriate, but do not let it override identity, world geometry, current thread state or the master-song edit contract. Verify the returned clip; reference input is not proof of fidelity.
