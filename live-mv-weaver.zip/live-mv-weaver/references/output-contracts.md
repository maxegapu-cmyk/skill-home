# Output Contracts

The shot manifest is an edit contract, not prose.

## Project/audio/profile

```json
{
  "project": {
    "song_start_sec": 24.5,
    "song_end_sec": 99.75,
    "single_world": true,
    "primary_location_id": "venue-main",
    "setup_interaction": true
  },
  "audio": {
    "master_song_continuous": true,
    "dialogue_mode": "overlay"
  },
  "style_profile": {
    "strict_reference_mode": true,
    "performance_share_min": 0.43,
    "performance_share_max": 0.57,
    "max_nonperformance_run_sec": 5.0,
    "min_recurring_audience_threads": 2,
    "require_callback": true
  }
}
```

## Every shot

Required: `id`, `start`, `end`, `role`, `location_id`, `song_state`, `director_intent`, `subjects`, `camera`, `action`, `continuity_state`, `music_trigger`, `image_prompt`, `video_prompt`.

Strict non-performance shots also require `leave_reason` and `return_trigger`.

Strict audience shots also require `thread_id` and integer `emotion_stage`.

Dialogue roles additionally contain:

```json
"dialogue": {
  "speaker_id": "audience-a",
  "text": "We lost that bet.",
  "mode": "overlay",
  "music_clearance": "brief low-vocal-density pocket",
  "mix": {"duck_db": -5.0, "prelap_ms": 120, "release_ms": 240}
}
```

Run `python scripts/validate_mv_plan.py shot_manifest.json --json` before generation handoff and again after timing changes.
