# Continuity Bible

The strongest continuity is the feeling that everyone is hearing the same song in the same minute.

## Lock before shots

### Live world
Venue/floor map, stage, bar/tables, doors/windows, practical-light positions, time-of-night, crowd density and traffic paths.

### Performer/band
Identity references, wardrobe state, instrument/mic/stool position, stage mark, facing direction, band positions and current performance-energy state.

### Audience
For recurring subjects store `thread_id`, seat/standing mark, table partner, wardrobe, prop/drink, stage eyeline, emotion stage, hand/body state and who has noticed whom.

## Camera map

Use a small reusable coverage map: stage frontal anchor, stage 3/4 close angle, table cluster A/B, bar reaction angle, aisle/crowd witness and band detail. Moving the camera is allowed; reinventing the architecture is not.

## State handoff

Each appearance writes a concise `continuity_state` that the next appearance consumes, for example:
`A2 table-right; glass in right hand; eyes wet, no tear fallen; friend camera-left has noticed.`

Later shots may advance that state, not silently reset it.
