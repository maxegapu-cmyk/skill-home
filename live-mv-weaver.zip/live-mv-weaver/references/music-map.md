# Music Map

The song is the master timeline, not a soundtrack pasted under finished visuals. Build the timing map before designing the weave.

## Required `song_map.json`

Record:
- exact master-song file/id and immutable timeline origin;
- `song_start_sec`, `song_end_sec`, sections, phrase boundaries and lyric text;
- energy changes, downbeats, releases, pauses, instrumental pockets and climax windows;
- visible-singer phrase candidates;
- candidate audience-dialogue windows with a reason: `instrumental_pocket`, `low_vocal_density`, `intentional_overlap`, or a reference-specific equivalent.

## Visible singing

When the singer's mouth is readable, bind the shot to a complete vocal phrase when the production stack supports phrase-guided lip sync. Do not choose a random five-second video window first and then chop a vocal line to fit it. If precise lip sync is unavailable, preserve believable breath, phrasing, jaw/mouth rhythm and body performance while final audio still comes from the locked master song.

## Rhythm hierarchy

Do not cut on every beat merely because beats exist. Use music at three scales:
1. **Section:** controls chapter-level intensity and coverage density.
2. **Phrase:** controls performance-anchor entries, exits and dialogue clearance.
3. **Beat/onset:** sharpens selected cuts, gestures, glances and payoff moments.

The reference profile controls average shot behavior; the music map decides exactly where exceptions belong.
