# Audio Continuity

## Three buses

**A — MASTER SONG:** locked full-song source; continuous throughout the performance window; never reconstructed from generated clip audio.

**B — DIEGETIC VOICE:** audience dialogue, laughter and small vocal reactions belonging to the same room and minute.

**C — LIVE AMBIENCE:** room tone, glasses, chair movement, applause and crowd bed.

## Dialogue insertion

Default shape:
`song full → short duck → one in-world line → smooth recovery`.

In strict mode every dialogue shot includes `dialogue.music_clearance`: explain why the musical moment can carry speech. Prefer instrumental pockets or lower vocal density. Intentional overlap is allowed when dramaturgically justified.

Start roughly around 3–8 dB of music ducking, then adjust by ear. The packaged reference profile treats deeper ducking as a warning/error because it makes the song feel interrupted. J/L behavior is useful: a tiny voice prelap can motivate the visual cut while the song remains perceptually dominant.

Dialogue should normally be one quick human thought, tease, observation or callback. `validate_mv_plan.py` estimates whether the line is implausibly dense for its window.
