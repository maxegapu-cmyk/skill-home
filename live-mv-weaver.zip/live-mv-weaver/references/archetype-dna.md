# Archetype DNA — Continuous Live Song + Audience Micro-Drama

## Formula

`UNINTERRUPTED SONG × ONE LIVE WORLD × PERFORMANCE SPINE × RECURRING AUDIENCE THREADS × HUMAN REACTION × DIEGETIC DIALOGUE × ESCALATION × CALLBACK`

The song is not background music for a separate story. The live performance is the event that causes the story.

## Calibrated reference behavior

The supplied reference, after formal singing begins, is approximately:
- performer/band screen share: **49.4%**;
- performer-anchor median: **3.05s**;
- pure audience-reaction median: **1.53s**;
- longest non-performance excursion: **4.83s**;
- dialogue/callback screen share: roughly **8.4%**.

The relationship matters more than any single number: performance anchors breathe longer; audience beats strike quickly; the edit keeps returning to the live source of the emotion.

## Narrative engine

A reliable progression is:
`SETUP PROPOSITION → SKEPTICISM → ATTENTION → PERSONAL RESONANCE → VISIBLE EMOTION → CONTAGION → CALLBACK → COMMUNAL RELEASE`

Do not spend the strongest tears or crowd response in the opening third.

## Audience functions

**Anchor audience:** establishes the proposition and later returns, giving the MV memory.

**Emotional carrier:** carries a private consequence of the lyrics through observable behavior. Do not explain the full backstory unless the brief demands it.

**Environmental witness:** crowd, bartender, bandmate or table group proving the performance is affecting a shared real room.

## Improvement without genre drift

Make the reference better through more precise micro-performance, cleaner eyelines, stronger state handoffs, better dialogue clearance, more musical cut timing and stronger candidate selection. Do not “upgrade” it by adding unrelated locations, literal lyric montages, random spectacle or long dialogue scenes.
