# Review and Repair Loop

High-quality AI MV production is a selection problem, not a one-prompt problem.

## Candidate loop

For every generation unit:
1. verify the cinematic keyframe against identity, wardrobe, seat/stage mark, light direction and eyeline;
2. generate the clip with one dominant action and one dominant camera behavior;
3. inspect start, middle and end frames plus motion continuity;
4. score the candidate in `candidate_qc.json`;
5. keep the best usable candidate or reshoot only that unit.

## `candidate_qc.json` fields

For each candidate record:
- `shot_id`, `candidate_id`, `verdict` (`accept`, `trim`, `reshoot`);
- `identity`, `world_geometry`, `continuity_state`, `action_readability`, `performance_sync`, `camera_control`, `emotional_truth`, `handoff_quality` scored 0–5;
- `hard_failures`;
- `best_trim_in`, `best_trim_out` if trimming solves the issue;
- `repair_instruction` containing one concrete repair target.

Reject a beautiful candidate if it breaks identity, geography, current emotional state, song relation or handoff. Do not reward spectacle that weakens the reference grammar.

## Repair ladder

Use the cheapest valid fix:
`trim/re-time` → `change edit point` → `rewrite motion prompt` → `replace keyframe` → `reshoot clip` → `re-plan shot`.

Do not regenerate accepted neighboring shots unless their shared continuity invariant is actually broken.
