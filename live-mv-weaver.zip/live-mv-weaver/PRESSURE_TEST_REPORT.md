# Pressure-Test Report — v2.0.0

## Baseline break test

The previous validator was challenged with 13 advanced failure cases that can still produce superficially attractive AI MV plans. It blocked **0/13 as the required hard gate**. The upgraded validator blocks **13/13**.

Covered failures:
- missing leave/return logic;
- missing audience thread identity;
- destructive song ducking;
- dialogue too dense for its window;
- unknown/random B-roll role;
- overlong non-performance excursion;
- peak emotion too early;
- unexplained emotional regression;
- reaction-duration profile drift;
- callback with no performer re-anchor;
- missing required shot contract field;
- no recurring audience threads;
- dialogue with no music-clearance reason.

## Automated suite

The release suite contains validator pressure tests, reference-profile derivation tests, candidate-selection tests and package-cleanliness checks. The release gate is:

```bash
python -m unittest discover -s tests -v
```

## Supplied-reference regression

The local analyzer reads the supplied reference as:
- duration: **99.751020s**;
- video: **720×1280, 30 fps**;
- significant visual cut candidates at threshold 0.18: **47**.

An anonymized semantic annotation of the formal-song section (24.566667s–99.751020s) derives:
- performance screen share: **49.434%**;
- dialogue/callback share: **8.424%**;
- performance-anchor median: **3.05s**;
- reaction median: **1.533s**;
- maximum non-performance excursion: **4.833s**.

These values are stored as calibration evidence, not as immutable creative rules.

## Known test boundary

This runtime does not expose an independent fresh-context LLM subagent, so the reproducible release gate is deterministic manifest/candidate pressure testing plus direct visual/reference analysis. Semantic director judgment remains covered by the rubric and must still be applied to actual generated clips.
