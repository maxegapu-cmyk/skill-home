import copy
import importlib.util
import json
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("validator", ROOT / "scripts" / "validate_mv_plan.py")
validator = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(validator)
BASE = json.loads((ROOT / "examples" / "live-bar-example.json").read_text(encoding="utf-8"))


def codes(report, bucket="errors"):
    return {x["code"] for x in report[bucket]}


def strict_plan():
    p = copy.deepcopy(BASE)
    p.setdefault("style_profile", {})["strict_reference_mode"] = True
    return p


class ValidatorPressureTests(unittest.TestCase):
    def test_nonperformance_requires_leave_and_return_reasons(self):
        p = strict_plan()
        shot = next(s for s in p["shots"] if s["role"] == "audience_reaction")
        shot.pop("leave_reason", None)
        shot.pop("return_trigger", None)
        r = validator.validate(p)
        self.assertIn("LEAVE_REASON_MISSING", codes(r))
        self.assertIn("RETURN_TRIGGER_MISSING", codes(r))

    def test_audience_shot_requires_thread_id(self):
        p = strict_plan()
        shot = next(s for s in p["shots"] if s["role"] == "audience_reaction")
        shot.pop("thread_id", None)
        r = validator.validate(p)
        self.assertIn("AUDIENCE_THREAD_MISSING", codes(r))

    def test_dialogue_ducking_outside_reference_safe_range_rejected(self):
        p = strict_plan()
        shot = next(s for s in p["shots"] if s["role"] == "audience_dialogue")
        shot["dialogue"]["mix"]["duck_db"] = -18.0
        r = validator.validate(p)
        self.assertIn("DIALOGUE_DUCK_OUT_OF_RANGE", codes(r))

    def test_dialogue_too_dense_for_window_rejected(self):
        p = strict_plan()
        shot = next(s for s in p["shots"] if s["role"] == "audience_dialogue")
        shot["dialogue"]["text"] = "This sentence is deliberately far too long to be spoken naturally inside such a tiny reaction window while preserving the song as the perceptual master."
        r = validator.validate(p)
        self.assertIn("DIALOGUE_TOO_DENSE", codes(r))

    def test_unknown_role_is_error(self):
        p = strict_plan()
        p["shots"][2]["role"] = "random_pretty_broll"
        r = validator.validate(p)
        self.assertIn("UNKNOWN_ROLE", codes(r))

    def test_strict_profile_turns_long_excursion_into_error(self):
        p = strict_plan()
        # Re-role S04 so S02-S06 become one long non-performance excursion.
        next(s for s in p["shots"] if s["id"] == "S04")["role"] = "crowd_witness"
        r = validator.validate(p)
        self.assertIn("NONPERFORMANCE_RUN_LONG", codes(r))

    def test_early_peak_emotion_is_rejected(self):
        p = strict_plan()
        shot = next(s for s in p["shots"] if s["id"] == "S02")
        shot["emotion_stage"] = 5
        r = validator.validate(p)
        self.assertIn("EMOTION_PEAK_TOO_EARLY", codes(r))

    def test_thread_emotion_regression_requires_reset_reason(self):
        p = strict_plan()
        # Make one recurring thread peak then regress later.
        s2 = next(s for s in p["shots"] if s["id"] == "S02")
        s6 = next(s for s in p["shots"] if s["id"] == "S06")
        s2["thread_id"] = s6["thread_id"] = "audience-a"
        s2["emotion_stage"] = 3
        s6["emotion_stage"] = 1
        s6.pop("emotion_reset_reason", None)
        r = validator.validate(p)
        self.assertIn("EMOTION_REGRESSION", codes(r))

    def test_reference_profile_checks_reaction_median(self):
        p = strict_plan()
        # Convert most short reaction shots to unnaturally long audience roles while preserving coverage.
        for s in p["shots"]:
            if s["role"] in {"audience_reaction", "emotional_carrier", "crowd_witness"}:
                s["role"] = "audience_reaction"
        p["style_profile"]["reaction_median_min_sec"] = 1.0
        p["style_profile"]["reaction_median_max_sec"] = 1.4
        # One existing 2s crowd shot plus others should push median above a tight custom reference.
        r = validator.validate(p)
        self.assertIn("REACTION_MEDIAN_OUTSIDE_PROFILE", codes(r))

    def test_callback_must_return_to_performer_before_song_end(self):
        p = strict_plan()
        last = p["shots"][-1]
        last["role"] = "crowd_witness"
        last["thread_id"] = "crowd"
        last["leave_reason"] = "show room response"
        last["return_trigger"] = "song end"
        last["emotion_stage"] = 4
        r = validator.validate(p)
        self.assertIn("ENDING_NOT_REANCHORED", codes(r))

    def test_requires_recurring_audience_threads(self):
        p = strict_plan()
        for i, shot in enumerate(p["shots"]):
            if shot["role"] in {"audience_reaction", "emotional_carrier", "crowd_witness", "audience_dialogue", "callback_dialogue"}:
                shot["thread_id"] = f"one-off-{i}"
                shot.setdefault("emotion_stage", 1)
        p["style_profile"]["min_recurring_audience_threads"] = 2
        r = validator.validate(p)
        self.assertIn("NO_RECURRING_AUDIENCE_THREAD", codes(r))

    def test_dialogue_requires_music_clearance_reason(self):
        p = strict_plan()
        shot = next(s for s in p["shots"] if s["role"] == "audience_dialogue")
        shot["dialogue"].pop("music_clearance", None)
        r = validator.validate(p)
        self.assertIn("DIALOGUE_CLEARANCE_MISSING", codes(r))

    def test_report_labels_automatic_score_as_deterministic(self):
        r = validator.validate(strict_plan())
        self.assertIn("deterministic_gate_score", r)

    def test_missing_required_shot_field_is_error(self):
        p = strict_plan()
        p["shots"][0].pop("camera", None)
        r = validator.validate(p)
        self.assertIn("SHOT_FIELD_MISSING", codes(r))


if __name__ == "__main__":
    unittest.main()
