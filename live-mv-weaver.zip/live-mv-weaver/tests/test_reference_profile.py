import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("derive", ROOT / "scripts" / "derive_reference_profile.py")
derive = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(derive)


class ReferenceProfileTests(unittest.TestCase):
    def test_derives_reference_style_metrics(self):
        annotated = {
            "project": {"song_start_sec": 10.0, "song_end_sec": 30.0},
            "shots": [
                {"id": "P1", "start": 10.0, "end": 14.0, "role": "performance_anchor"},
                {"id": "A1", "start": 14.0, "end": 15.5, "role": "audience_reaction", "thread_id": "a"},
                {"id": "D1", "start": 15.5, "end": 17.0, "role": "audience_dialogue", "thread_id": "a"},
                {"id": "P2", "start": 17.0, "end": 21.0, "role": "performance_anchor"},
                {"id": "E1", "start": 21.0, "end": 22.5, "role": "emotional_carrier", "thread_id": "b"},
                {"id": "W1", "start": 22.5, "end": 24.0, "role": "crowd_witness", "thread_id": "crowd"},
                {"id": "P3", "start": 24.0, "end": 28.0, "role": "performance_anchor"},
                {"id": "C1", "start": 28.0, "end": 29.0, "role": "callback_dialogue", "thread_id": "a"},
                {"id": "P4", "start": 29.0, "end": 30.0, "role": "performance_anchor"},
            ],
        }
        result = derive.derive_profile(annotated)
        observed = result["observed"]
        profile = result["style_profile"]
        self.assertAlmostEqual(observed["performance_screen_share"], 13.0 / 20.0, places=6)
        self.assertAlmostEqual(observed["dialogue_screen_share"], 2.5 / 20.0, places=6)
        self.assertEqual(observed["max_nonperformance_run_sec"], 3.0)
        self.assertEqual(observed["performance_anchor_median_sec"], 4.0)
        self.assertEqual(observed["reaction_median_sec"], 1.5)
        self.assertTrue(observed["has_callback"])
        self.assertLess(profile["performance_share_min"], observed["performance_screen_share"])
        self.assertGreater(profile["performance_share_max"], observed["performance_screen_share"])
        self.assertTrue(profile["strict_reference_mode"])

    def test_rejects_invalid_song_window(self):
        with self.assertRaises(ValueError):
            derive.derive_profile({"project": {"song_start_sec": 5, "song_end_sec": 5}, "shots": []})


if __name__ == "__main__":
    unittest.main()
