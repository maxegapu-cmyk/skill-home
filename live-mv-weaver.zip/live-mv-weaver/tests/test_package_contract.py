from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PackageContractTests(unittest.TestCase):
    def test_required_v2_references_exist(self):
        for rel in [
            "references/music-map.md",
            "references/pressure-test-playbook.md",
            "references/reference-fidelity-rubric.md",
            "references/review-and-repair.md",
            "examples/reference-style-profile.json",
        ]:
            self.assertTrue((ROOT / rel).is_file(), rel)

    def test_skill_declares_v2_core_artifacts(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        for token in [
            "reference_style_profile.json",
            "song_map.json",
            "live_director_score.json",
            "candidate_qc.json",
            "strict_reference_mode",
            "REPLICA_PLUS",
        ]:
            self.assertIn(token, text)

    def test_public_package_has_no_source_project_fingerprints_or_placeholders(self):
        forbidden = [
            "musical" + "-mv-storyboard", "Auto" + "MV", "huang" + "serva", "multimodal" + "-art-projection",
            "kissd" + "studio", "guig" + "ulaoshi", "github" + ".com", "TO" + "DO", "T" + "BD",
        ]
        public_files = [p for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts and "docs" not in p.parts and p.name != "test_package_contract.py"]
        for path in public_files:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for needle in forbidden:
                self.assertNotIn(needle, text, f"{needle!r} leaked in {path.relative_to(ROOT)}")


if __name__ == "__main__":
    unittest.main()
