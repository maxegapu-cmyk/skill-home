import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("candidate_qc", ROOT / "scripts" / "validate_candidate_qc.py")
qc = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(qc)

DIMS = {
    "identity": 5,
    "world_geometry": 5,
    "continuity_state": 5,
    "action_readability": 4,
    "performance_sync": 4,
    "camera_control": 4,
    "emotional_truth": 5,
    "handoff_quality": 4,
}


def base():
    return {
        "policy": {
            "min_accept_average": 4.0,
            "min_critical_score": 3,
            "critical_dimensions": ["identity", "world_geometry", "continuity_state", "handoff_quality"]
        },
        "candidates": [
            {"shot_id": "S01", "candidate_id": "S01-A", "verdict": "accept", "selected": True, "scores": dict(DIMS), "hard_failures": []},
            {"shot_id": "S01", "candidate_id": "S01-B", "verdict": "reshoot", "selected": False, "scores": dict(DIMS, identity=2), "hard_failures": ["face drift"], "repair_instruction": "restore locked singer identity"},
        ]
    }


class CandidateQCTests(unittest.TestCase):
    def test_good_selection_passes(self):
        r = qc.validate(base())
        self.assertTrue(r["valid"])

    def test_selected_accept_cannot_have_hard_failure(self):
        p = base(); p["candidates"][0]["hard_failures"] = ["wrong venue"]
        r = qc.validate(p)
        self.assertIn("SELECTED_HAS_HARD_FAILURE", {e["code"] for e in r["errors"]})

    def test_selected_accept_must_meet_score_floor(self):
        p = base(); p["candidates"][0]["scores"]["identity"] = 1
        r = qc.validate(p)
        self.assertIn("CRITICAL_SCORE_LOW", {e["code"] for e in r["errors"]})

    def test_exactly_one_selected_candidate_per_shot(self):
        p = base(); p["candidates"][1]["selected"] = True; p["candidates"][1]["verdict"] = "accept"; p["candidates"][1]["hard_failures"] = []
        r = qc.validate(p)
        self.assertIn("SELECTION_COUNT_INVALID", {e["code"] for e in r["errors"]})

    def test_missing_score_dimension_is_error(self):
        p = base(); p["candidates"][0]["scores"].pop("handoff_quality")
        r = qc.validate(p)
        self.assertIn("SCORE_DIMENSION_MISSING", {e["code"] for e in r["errors"]})


if __name__ == "__main__":
    unittest.main()
