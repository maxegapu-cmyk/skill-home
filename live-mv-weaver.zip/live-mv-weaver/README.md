# Live MV Weaver v2.0

A reference-driven Skill for continuous live-performance MVs where the master song never stops while the picture intercuts singer, recurring audience reactions, short in-world dialogue, band details and callbacks inside one shared live event.

## Why this version exists

Generic MV systems often preserve faces but lose the deeper continuity: the audience starts behaving like unrelated B-roll, dialogue pauses the song, emotional peaks arrive too early, or the edit wanders into separate mini-scenes. V2 makes those failure modes explicit and testable.

## Quick start

1. Analyze a reference:
   `python scripts/analyze_reference.py reference.mp4 --output-dir analysis --contact-sheet`
2. Semantically label its cut intervals and derive the reference profile:
   `python scripts/derive_reference_profile.py annotated_reference.json --output reference_style_profile.json`
3. Build the song map, continuity assets and weave plan using `SKILL.md`.
4. Validate the timed shot manifest:
   `python scripts/validate_mv_plan.py shot_manifest.json --json`
5. Run the packaged pressure tests:
   `python -m unittest discover -s tests -v`

See `examples/live-bar-example.json` for a strict-mode manifest that passes all gates.
