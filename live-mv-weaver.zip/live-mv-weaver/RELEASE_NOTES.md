# v2.0.0

- Added strict reference-fidelity mode.
- Added deterministic gates for leave/return logic, recurring audience threads, emotion progression, dialogue density/ducking/music clearance, reference shot-duration medians, non-performance excursion density and ending re-anchor.
- Added reference-profile derivation from semantically labeled cuts.
- Added a music map, candidate review/reshoot loop, fidelity rubric and pressure-test playbook.
- Calibrated the default archetype to the supplied continuous-live-song reference rather than a generic MV template.
