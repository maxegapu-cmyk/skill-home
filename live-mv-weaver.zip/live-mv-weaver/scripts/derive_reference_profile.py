#!/usr/bin/env python3
"""Derive a strict Live MV Weaver style profile from semantically labeled cuts."""
from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path
from typing import Any

PERFORMANCE_ROLES = {"performance_anchor", "performance_detail"}
REACTION_ROLES = {"audience_reaction", "emotional_carrier", "crowd_witness"}
DIALOGUE_ROLES = {"audience_dialogue", "callback_dialogue"}


def _dur(s: dict[str, Any]) -> float:
    return max(0.0, float(s.get("end", 0)) - float(s.get("start", 0)))


def _median(vals: list[float]) -> float:
    return float(statistics.median(vals)) if vals else 0.0


def _band(value: float, *, rel: float, floor: float = 0.0, cap: float | None = None) -> tuple[float, float]:
    delta = max(floor, abs(value) * rel)
    lo = max(0.0, value - delta)
    hi = value + delta
    if cap is not None:
        hi = min(cap, hi)
    return lo, hi


def derive_profile(annotated: dict[str, Any]) -> dict[str, Any]:
    p = annotated.get("project") or {}
    start = float(p.get("song_start_sec", 0))
    end = float(p.get("song_end_sec", 0))
    if end <= start:
        raise ValueError("song_end_sec must be greater than song_start_sec")
    song_duration = end - start
    shots = sorted(annotated.get("shots") or [], key=lambda s: float(s.get("start", 0)))

    perf = 0.0
    dialogue = 0.0
    anchors: list[float] = []
    reactions: list[float] = []
    role_counts: dict[str, int] = {}
    role_duration: dict[str, float] = {}
    has_callback = False

    max_run = 0.0
    run_start: float | None = None
    run_end: float | None = None

    for shot in shots:
        role = str(shot.get("role", "unknown"))
        dur = _dur(shot)
        role_counts[role] = role_counts.get(role, 0) + 1
        role_duration[role] = role_duration.get(role, 0.0) + dur
        if role in PERFORMANCE_ROLES:
            perf += dur
        if role == "performance_anchor":
            anchors.append(dur)
        if role in REACTION_ROLES:
            reactions.append(dur)
        if role in DIALOGUE_ROLES:
            dialogue += dur
        if role == "callback_dialogue":
            has_callback = True

        if role not in PERFORMANCE_ROLES:
            if run_start is None:
                run_start = float(shot.get("start", 0))
            run_end = float(shot.get("end", 0))
        else:
            if run_start is not None and run_end is not None:
                max_run = max(max_run, run_end - run_start)
            run_start = run_end = None
    if run_start is not None and run_end is not None:
        max_run = max(max_run, run_end - run_start)

    perf_share = perf / song_duration
    dialogue_share = dialogue / song_duration
    anchor_med = _median(anchors)
    reaction_med = _median(reactions)

    perf_lo, perf_hi = _band(perf_share, rel=0.14, floor=0.04, cap=0.95)
    anchor_lo, anchor_hi = _band(anchor_med, rel=0.28, floor=0.35)
    reaction_lo, reaction_hi = _band(reaction_med, rel=0.32, floor=0.25)

    observed = {
        "song_duration_sec": round(song_duration, 6),
        "performance_screen_share": round(perf_share, 6),
        "dialogue_screen_share": round(dialogue_share, 6),
        "performance_anchor_median_sec": round(anchor_med, 6),
        "reaction_median_sec": round(reaction_med, 6),
        "max_nonperformance_run_sec": round(max_run, 6),
        "has_callback": has_callback,
        "role_counts": dict(sorted(role_counts.items())),
        "role_duration_sec": {k: round(v, 6) for k, v in sorted(role_duration.items())},
    }

    style_profile = {
        "profile_source": "semantic_reference_annotation",
        "strict_reference_mode": True,
        "performance_share_min": round(perf_lo, 6),
        "performance_share_max": round(perf_hi, 6),
        "performance_anchor_median_min_sec": round(anchor_lo, 6),
        "performance_anchor_median_max_sec": round(anchor_hi, 6),
        "reaction_median_min_sec": round(reaction_lo, 6),
        "reaction_median_max_sec": round(reaction_hi, 6),
        "max_nonperformance_run_sec": round(max(max_run * 1.08, max_run + 0.15), 6),
        "max_consecutive_nonperformance_shots": 3,
        "max_consecutive_reaction_shots": 3,
        "dialogue_share_warn": round(max(dialogue_share * 1.25, dialogue_share + 0.02), 6),
        "dialogue_duck_min_db": -8.0,
        "dialogue_duck_max_db": -3.0,
        "dialogue_prelap_max_ms": 320,
        "dialogue_release_min_ms": 120,
        "dialogue_release_max_ms": 650,
        "dialogue_density_factor": 0.75,
        "peak_emotion_stage": 5,
        "peak_emotion_earliest_fraction": 0.55,
        "require_callback": has_callback,
    }
    return {"observed": observed, "style_profile": style_profile}


def main() -> int:
    ap = argparse.ArgumentParser(description="Derive a Live MV Weaver style profile from annotated reference cuts")
    ap.add_argument("annotation", type=Path)
    ap.add_argument("--output", type=Path, default=Path("reference_style_profile.json"))
    args = ap.parse_args()
    try:
        annotated = json.loads(args.annotation.read_text(encoding="utf-8"))
        result = derive_profile(annotated)
    except Exception as exc:
        print(f"profile derivation failed: {exc}")
        return 2
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output), **result["observed"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
