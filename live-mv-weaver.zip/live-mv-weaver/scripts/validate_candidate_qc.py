#!/usr/bin/env python3
"""Validate generated-clip candidate selection for Live MV Weaver."""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

REQUIRED_DIMS = {
    "identity",
    "world_geometry",
    "continuity_state",
    "action_readability",
    "performance_sync",
    "camera_control",
    "emotional_truth",
    "handoff_quality",
}


def issue(code: str, message: str, candidate_id: str | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {"code": code, "message": message}
    if candidate_id:
        out["candidate_id"] = candidate_id
    return out


def validate(data: dict[str, Any]) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    policy = data.get("policy") or {}
    candidates = data.get("candidates") or []
    min_avg = float(policy.get("min_accept_average", 4.0))
    min_critical = float(policy.get("min_critical_score", 3.0))
    critical = list(policy.get("critical_dimensions") or ["identity", "world_geometry", "continuity_state", "handoff_quality"])

    selected_by_shot: dict[str, list[str]] = defaultdict(list)
    accepted_averages: list[float] = []

    for i, c in enumerate(candidates):
        cid = str(c.get("candidate_id", f"candidate-{i+1}"))
        sid = str(c.get("shot_id", "")).strip()
        verdict = str(c.get("verdict", "")).strip()
        scores = c.get("scores") or {}
        missing = sorted(REQUIRED_DIMS - set(scores))
        if missing:
            errors.append(issue("SCORE_DIMENSION_MISSING", f"missing score dimension(s): {', '.join(missing)}", cid))

        numeric_scores: dict[str, float] = {}
        for dim, raw in scores.items():
            try:
                value = float(raw)
            except (TypeError, ValueError):
                errors.append(issue("SCORE_INVALID", f"score {dim} must be numeric", cid))
                continue
            if not (0.0 <= value <= 5.0):
                errors.append(issue("SCORE_INVALID", f"score {dim}={value:g} must be within 0-5", cid))
            numeric_scores[dim] = value

        selected = bool(c.get("selected", False))
        if selected:
            if not sid:
                errors.append(issue("SHOT_ID_MISSING", "selected candidate requires shot_id", cid))
            else:
                selected_by_shot[sid].append(cid)
            if verdict != "accept":
                errors.append(issue("SELECTED_NOT_ACCEPTED", "selected candidate must have verdict=accept", cid))
            hard = c.get("hard_failures") or []
            if hard:
                errors.append(issue("SELECTED_HAS_HARD_FAILURE", f"selected candidate has hard failure(s): {hard}", cid))
            if not missing and numeric_scores:
                avg = sum(numeric_scores[d] for d in REQUIRED_DIMS) / len(REQUIRED_DIMS)
                accepted_averages.append(avg)
                if avg < min_avg:
                    errors.append(issue("ACCEPT_AVERAGE_LOW", f"selected candidate average {avg:.3f} is below {min_avg:.3f}", cid))
                for dim in critical:
                    if dim in numeric_scores and numeric_scores[dim] < min_critical:
                        errors.append(issue("CRITICAL_SCORE_LOW", f"critical score {dim}={numeric_scores[dim]:.3f} is below {min_critical:.3f}", cid))

        if verdict == "reshoot" and not str(c.get("repair_instruction", "")).strip():
            warnings.append(issue("RESHOOT_REPAIR_MISSING", "reshoot candidate should name one concrete repair target", cid))
        if verdict == "trim":
            if c.get("best_trim_in") is None or c.get("best_trim_out") is None:
                errors.append(issue("TRIM_BOUNDS_MISSING", "trim verdict requires best_trim_in and best_trim_out", cid))

    shot_ids = {str(c.get("shot_id", "")).strip() for c in candidates if str(c.get("shot_id", "")).strip()}
    for sid in sorted(shot_ids):
        selected = selected_by_shot.get(sid, [])
        if len(selected) != 1:
            errors.append(issue("SELECTION_COUNT_INVALID", f"shot {sid} must have exactly one selected candidate; found {len(selected)}"))

    metrics = {
        "candidate_count": len(candidates),
        "shot_count": len(shot_ids),
        "selected_count": sum(len(v) for v in selected_by_shot.values()),
        "selected_average_mean": round(sum(accepted_averages) / len(accepted_averages), 6) if accepted_averages else 0.0,
    }
    return {"valid": not errors, "errors": errors, "warnings": warnings, "metrics": metrics}


def main() -> int:
    ap = argparse.ArgumentParser(description="Validate Live MV Weaver candidate_qc.json")
    ap.add_argument("qc", type=Path)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    try:
        data = json.loads(args.qc.read_text(encoding="utf-8"))
        report = validate(data)
    except Exception as exc:
        report = {"valid": False, "errors": [{"code": "READ_ERROR", "message": str(exc)}], "warnings": [], "metrics": {}}
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("PASS" if report["valid"] else "FAIL")
        for e in report["errors"]:
            print(f"ERROR {e['code']}: {e['message']}")
        for w in report["warnings"]:
            print(f"WARN  {w['code']}: {w['message']}")
    return 0 if report["valid"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
