#!/usr/bin/env python3
"""Validate a Live MV Weaver shot manifest.

The validator deliberately separates hard continuity failures from reference-style
profile deviations. When ``style_profile.strict_reference_mode`` is true, the
reference grammar becomes a production gate instead of advisory guidance.
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
from pathlib import Path
from typing import Any

PERFORMANCE_ROLES = {"performance_anchor", "performance_detail"}
REACTION_ROLES = {"audience_reaction", "emotional_carrier", "crowd_witness"}
DIALOGUE_ROLES = {"audience_dialogue", "callback_dialogue"}
AUDIENCE_ROLES = REACTION_ROLES | DIALOGUE_ROLES
OTHER_ROLES = {"band_detail", "payoff"}
ALL_ROLES = PERFORMANCE_ROLES | AUDIENCE_ROLES | OTHER_ROLES
NONPERFORMANCE_ROLES = ALL_ROLES - PERFORMANCE_ROLES

REQUIRED_SHOT_FIELDS = {
    "id", "start", "end", "role", "location_id", "song_state",
    "director_intent", "subjects", "camera", "action", "continuity_state",
    "music_trigger", "image_prompt", "video_prompt",
}

CJK_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
WORD_RE = re.compile(r"\b[\w'-]+\b", re.UNICODE)


def issue(code: str, message: str, shot_id: str | None = None) -> dict[str, Any]:
    data: dict[str, Any] = {"code": code, "message": message}
    if shot_id:
        data["shot_id"] = shot_id
    return data


def _put_profile_issue(errors: list[dict[str, Any]], warnings: list[dict[str, Any]], strict: bool,
                       code: str, message: str, shot_id: str | None = None) -> None:
    (errors if strict else warnings).append(issue(code, message, shot_id))


def _duration(shot: dict[str, Any]) -> float:
    try:
        return max(0.0, float(shot.get("end", 0)) - float(shot.get("start", 0)))
    except (TypeError, ValueError):
        return 0.0


def _speech_estimate_sec(text: str) -> float:
    """Conservative speech-duration estimate for density gating.

    It is intentionally permissive: the purpose is to catch obviously impossible
    dialogue stuffing, not to replace a voice timing pass.
    """
    text = (text or "").strip()
    if not text:
        return 0.0
    cjk = len(CJK_RE.findall(text))
    visible = len(re.sub(r"\s+", "", text))
    pauses = len(re.findall(r"[,，。.!！？?…;；:]", text)) * 0.08
    if visible and cjk / visible >= 0.35:
        return cjk / 4.2 + pauses
    words = len(WORD_RE.findall(text))
    return words / 2.7 + pauses


def _median(values: list[float]) -> float:
    return float(statistics.median(values)) if values else 0.0


def validate(plan: dict[str, Any], tolerance: float = 0.04) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    p = plan.get("project") or {}
    audio = plan.get("audio") or {}
    profile = plan.get("style_profile") or {}
    strict = bool(profile.get("strict_reference_mode", False))
    shots = sorted(plan.get("shots") or [], key=lambda s: float(s.get("start", 0) or 0))

    try:
        song_start = float(p.get("song_start_sec", 0))
        song_end = float(p.get("song_end_sec", p.get("duration_sec", 0)))
    except (TypeError, ValueError):
        song_start = song_end = 0.0
        errors.append(issue("INVALID_SONG_WINDOW", "song timing fields must be numeric"))

    if song_end <= song_start:
        errors.append(issue("INVALID_SONG_WINDOW", "song_end_sec must be greater than song_start_sec"))
    if not shots:
        errors.append(issue("NO_SHOTS", "shots must cover the song window"))
        return _report(plan, errors, warnings, {})

    if audio.get("master_song_continuous") is not True:
        errors.append(issue("MASTER_SONG_NOT_LOCKED", "audio.master_song_continuous must be true"))
    if audio.get("dialogue_mode", "overlay") != "overlay":
        errors.append(issue("DIALOGUE_MODE_INVALID", "default dialogue_mode must be overlay"))

    if abs(float(shots[0].get("start", 0) or 0) - song_start) > tolerance:
        errors.append(issue("TIMELINE_START_GAP", "first shot must begin at song_start_sec", str(shots[0].get("id", "?"))))

    # Hard per-shot and timeline checks.
    for i, shot in enumerate(shots):
        sid = str(shot.get("id", f"shot-{i+1}"))
        missing = sorted(k for k in REQUIRED_SHOT_FIELDS if k not in shot or shot.get(k) in (None, "", []))
        if missing:
            errors.append(issue("SHOT_FIELD_MISSING", f"missing required shot field(s): {', '.join(missing)}", sid))

        try:
            start = float(shot.get("start", 0))
            end = float(shot.get("end", 0))
        except (TypeError, ValueError):
            errors.append(issue("SHOT_TIME_INVALID", "shot start/end must be numeric", sid))
            continue
        if end <= start:
            errors.append(issue("NONPOSITIVE_DURATION", "shot end must be greater than start", sid))

        role = shot.get("role")
        if role not in ALL_ROLES:
            errors.append(issue("UNKNOWN_ROLE", f"unsupported role: {role!r}", sid))

        if shot.get("song_state") != "continuous":
            errors.append(issue("SONG_NOT_CONTINUOUS", "every shot after song start must stay on the continuous master-song clock", sid))

        if role in DIALOGUE_ROLES:
            dialog = shot.get("dialogue") or {}
            if dialog.get("mode", "overlay") != "overlay":
                errors.append(issue("DIALOGUE_REPLACES_SONG", "audience dialogue must overlay the master song, not replace it", sid))
            mix = dialog.get("mix") or {}
            try:
                duck = float(mix.get("duck_db"))
            except (TypeError, ValueError):
                duck = None
            if duck is None:
                _put_profile_issue(errors, warnings, strict, "DIALOGUE_MIX_MISSING", "dialogue mix requires numeric duck_db", sid)
            else:
                duck_min = float(profile.get("dialogue_duck_min_db", -8.0))
                duck_max = float(profile.get("dialogue_duck_max_db", -3.0))
                if not (duck_min <= duck <= duck_max):
                    _put_profile_issue(errors, warnings, strict, "DIALOGUE_DUCK_OUT_OF_RANGE",
                                       f"duck_db {duck:.1f} is outside reference-safe range {duck_min:.1f} to {duck_max:.1f} dB", sid)
            for field, lo, hi, code in (
                ("prelap_ms", 0.0, float(profile.get("dialogue_prelap_max_ms", 320.0)), "DIALOGUE_PRELAP_OUT_OF_RANGE"),
                ("release_ms", float(profile.get("dialogue_release_min_ms", 120.0)), float(profile.get("dialogue_release_max_ms", 650.0)), "DIALOGUE_RELEASE_OUT_OF_RANGE"),
            ):
                try:
                    value = float(mix.get(field))
                except (TypeError, ValueError):
                    value = None
                if value is None or not (lo <= value <= hi):
                    _put_profile_issue(errors, warnings, strict, code, f"{field} must be within {lo:g}-{hi:g} ms", sid)

            clearance = str(dialog.get("music_clearance", "")).strip()
            if strict and not clearance:
                errors.append(issue("DIALOGUE_CLEARANCE_MISSING", "dialogue must state why this song moment can carry an in-world line (for example instrumental pocket, low vocal density, or intentional overlap)", sid))

            text = str(dialog.get("text", "")).strip()
            if not text:
                errors.append(issue("DIALOGUE_TEXT_MISSING", "dialogue role requires text", sid))
            else:
                estimate = _speech_estimate_sec(text)
                available = max(0.0, end - start)
                density_factor = float(profile.get("dialogue_density_factor", 0.75))
                if available + tolerance < estimate * density_factor:
                    _put_profile_issue(errors, warnings, strict, "DIALOGUE_TOO_DENSE",
                                       f"estimated speech {estimate:.2f}s is too dense for {available:.2f}s window", sid)

        if p.get("single_world") is True:
            primary = p.get("primary_location_id")
            if primary and shot.get("location_id") != primary:
                errors.append(issue("WORLD_BREAK", "single-world mode requires the primary live-event location for every shot", sid))

        if strict and role in NONPERFORMANCE_ROLES:
            if not str(shot.get("leave_reason", "")).strip():
                errors.append(issue("LEAVE_REASON_MISSING", "non-performance insertion must state why the edit leaves the performer now", sid))
            if not str(shot.get("return_trigger", "")).strip():
                errors.append(issue("RETURN_TRIGGER_MISSING", "non-performance insertion must state what returns the edit to performance", sid))

        if strict and role in AUDIENCE_ROLES:
            if not str(shot.get("thread_id", "")).strip():
                errors.append(issue("AUDIENCE_THREAD_MISSING", "audience shot must belong to a recurring audience thread", sid))
            if "emotion_stage" not in shot:
                errors.append(issue("EMOTION_STAGE_MISSING", "audience shot requires emotion_stage for escalation control", sid))

        if i:
            prev_end = float(shots[i - 1].get("end", 0) or 0)
            delta = start - prev_end
            if delta > tolerance:
                errors.append(issue("TIMELINE_GAP", f"gap of {delta:.3f}s before shot", sid))
            elif delta < -tolerance:
                errors.append(issue("TIMELINE_OVERLAP", f"overlap of {-delta:.3f}s before shot", sid))

    if abs(float(shots[-1].get("end", 0) or 0) - song_end) > tolerance:
        errors.append(issue("TIMELINE_END_GAP", "last shot must end at song_end_sec", str(shots[-1].get("id", "?"))))

    # Aggregate metrics.
    song_duration = max(0.0, song_end - song_start)
    role_duration: dict[str, float] = {}
    perf_duration = 0.0
    dialogue_duration = 0.0
    anchor_durations: list[float] = []
    reaction_durations: list[float] = []
    for shot in shots:
        dur = _duration(shot)
        role = str(shot.get("role", "unknown"))
        role_duration[role] = role_duration.get(role, 0.0) + dur
        if role in PERFORMANCE_ROLES:
            perf_duration += dur
        if role == "performance_anchor":
            anchor_durations.append(dur)
        if role in REACTION_ROLES:
            reaction_durations.append(dur)
        if role in DIALOGUE_ROLES:
            dialogue_duration += dur

    perf_share = perf_duration / song_duration if song_duration else 0.0
    dialogue_share = dialogue_duration / song_duration if song_duration else 0.0
    anchor_median = _median(anchor_durations)
    reaction_median = _median(reaction_durations)

    min_share = float(profile.get("performance_share_min", 0.42))
    max_share = float(profile.get("performance_share_max", 0.58))
    if perf_share < min_share or perf_share > max_share:
        _put_profile_issue(errors, warnings, strict, "PERFORMANCE_SHARE_OUTSIDE_PROFILE",
                           f"performance screen share {perf_share:.3f} is outside {min_share:.3f}-{max_share:.3f}")

    dialogue_warn = float(profile.get("dialogue_share_warn", 0.12))
    if dialogue_share > dialogue_warn:
        _put_profile_issue(errors, warnings, strict, "DIALOGUE_SHARE_HIGH",
                           f"dialogue screen share {dialogue_share:.3f} exceeds profile maximum {dialogue_warn:.3f}")

    anchor_min = float(profile.get("performance_anchor_median_min_sec", 2.5))
    anchor_max = float(profile.get("performance_anchor_median_max_sec", 4.2))
    if anchor_durations and not (anchor_min <= anchor_median <= anchor_max):
        _put_profile_issue(errors, warnings, strict, "PERFORMANCE_ANCHOR_MEDIAN_OUTSIDE_PROFILE",
                           f"performance-anchor median {anchor_median:.3f}s is outside {anchor_min:.3f}-{anchor_max:.3f}s")

    reaction_min = float(profile.get("reaction_median_min_sec", 1.0))
    reaction_max = float(profile.get("reaction_median_max_sec", 2.3))
    if reaction_durations and not (reaction_min <= reaction_median <= reaction_max):
        _put_profile_issue(errors, warnings, strict, "REACTION_MEDIAN_OUTSIDE_PROFILE",
                           f"reaction median {reaction_median:.3f}s is outside {reaction_min:.3f}-{reaction_max:.3f}s")

    # Longest non-performance excursion and shot-count density.
    max_excursion = float(profile.get("max_nonperformance_run_sec", 5.0))
    max_nonperf_shots = int(profile.get("max_consecutive_nonperformance_shots", 3))
    run_start: float | None = None
    run_end: float | None = None
    run_ids: list[str] = []
    max_run = 0.0
    max_run_ids: list[str] = []
    for shot in shots + [{"role": "performance_anchor", "start": song_end, "end": song_end, "id": "__sentinel__"}]:
        role = shot.get("role")
        if role not in PERFORMANCE_ROLES:
            if run_start is None:
                run_start = float(shot.get("start", 0) or 0)
                run_ids = []
            run_end = float(shot.get("end", 0) or 0)
            run_ids.append(str(shot.get("id", "?")))
        elif run_start is not None and run_end is not None:
            dur = run_end - run_start
            if dur > max_run:
                max_run, max_run_ids = dur, list(run_ids)
            if dur > max_excursion + tolerance:
                _put_profile_issue(errors, warnings, strict, "NONPERFORMANCE_RUN_LONG",
                                   f"non-performance excursion {dur:.3f}s exceeds {max_excursion:.3f}s ({', '.join(run_ids)})")
            if len(run_ids) > max_nonperf_shots:
                _put_profile_issue(errors, warnings, strict, "NONPERFORMANCE_CLUSTER_DENSE",
                                   f"{len(run_ids)} consecutive non-performance shots exceed profile max {max_nonperf_shots} ({', '.join(run_ids)})")
            run_start = run_end = None
            run_ids = []

    max_reactions = int(profile.get("max_consecutive_reaction_shots", 3))
    reaction_count = 0
    for shot in shots:
        if shot.get("role") in REACTION_ROLES:
            reaction_count += 1
            if reaction_count > max_reactions:
                _put_profile_issue(errors, warnings, strict, "REACTION_CLUSTER_LONG",
                                   f"more than {max_reactions} consecutive reaction shots", str(shot.get("id", "?")))
                break
        elif shot.get("role") in PERFORMANCE_ROLES or shot.get("role") in DIALOGUE_ROLES:
            reaction_count = 0

    # Audience emotional progression.
    peak_earliest_fraction = float(profile.get("peak_emotion_earliest_fraction", 0.55))
    peak_stage = int(profile.get("peak_emotion_stage", 5))
    thread_last: dict[str, tuple[int, str]] = {}
    for shot in shots:
        if shot.get("role") not in AUDIENCE_ROLES or "emotion_stage" not in shot:
            continue
        sid = str(shot.get("id", "?"))
        try:
            stage = int(shot.get("emotion_stage"))
        except (TypeError, ValueError):
            errors.append(issue("EMOTION_STAGE_INVALID", "emotion_stage must be an integer", sid))
            continue
        if stage < 0 or stage > peak_stage:
            errors.append(issue("EMOTION_STAGE_INVALID", f"emotion_stage must be 0-{peak_stage}", sid))
            continue
        frac = ((float(shot.get("start", song_start)) - song_start) / song_duration) if song_duration else 0.0
        if strict and stage >= peak_stage and frac < peak_earliest_fraction:
            errors.append(issue("EMOTION_PEAK_TOO_EARLY",
                                f"peak emotion stage {stage} appears at {frac:.1%}, before profile threshold {peak_earliest_fraction:.1%}", sid))
        tid = str(shot.get("thread_id", "")).strip()
        if tid:
            prev = thread_last.get(tid)
            if prev and stage < prev[0] - 1 and not str(shot.get("emotion_reset_reason", "")).strip():
                _put_profile_issue(errors, warnings, strict, "EMOTION_REGRESSION",
                                   f"thread {tid} drops from stage {prev[0]} to {stage} without an explicit reset reason", sid)
            thread_last[tid] = (stage, sid)

    # Recurrence is what makes audience inserts feel like threads rather than random B-roll.
    if strict:
        appearances: dict[str, int] = {}
        for shot in shots:
            if shot.get("role") in AUDIENCE_ROLES:
                tid = str(shot.get("thread_id", "")).strip()
                if tid:
                    appearances[tid] = appearances.get(tid, 0) + 1
        recurring = [tid for tid, count in appearances.items() if count >= 2]
        min_recurring = int(profile.get("min_recurring_audience_threads", 2))
        if len(recurring) < min_recurring:
            errors.append(issue("NO_RECURRING_AUDIENCE_THREAD", f"strict reference mode requires at least {min_recurring} recurring audience thread(s); found {len(recurring)}"))

    # Callback closure: a setup/callback must yield the ending back to performance.
    if profile.get("require_callback", False) and p.get("setup_interaction", False):
        callbacks = [i for i, s in enumerate(shots) if s.get("role") == "callback_dialogue"]
        if not callbacks:
            errors.append(issue("CALLBACK_MISSING", "setup_interaction is true but no callback_dialogue closes the setup"))
        else:
            last_callback = callbacks[-1]
            if not any(s.get("role") in PERFORMANCE_ROLES for s in shots[last_callback + 1:]):
                _put_profile_issue(errors, warnings, strict, "ENDING_NOT_REANCHORED",
                                   "after the final callback, return to the performer before the song window ends")

    metrics = {
        "song_duration_sec": round(song_duration, 6),
        "performance_screen_share": round(perf_share, 6),
        "dialogue_screen_share": round(dialogue_share, 6),
        "performance_anchor_median_sec": round(anchor_median, 6),
        "reaction_median_sec": round(reaction_median, 6),
        "max_nonperformance_run_sec": round(max_run, 6),
        "max_nonperformance_run_shots": max_run_ids,
        "role_duration_sec": {k: round(v, 6) for k, v in sorted(role_duration.items())},
        "strict_reference_mode": strict,
    }
    return _report(plan, errors, warnings, metrics)


def _report(plan: dict[str, Any], errors: list[dict[str, Any]], warnings: list[dict[str, Any]], metrics: dict[str, Any]) -> dict[str, Any]:
    hard_penalty = min(100, len(errors) * 12)
    soft_penalty = min(30, len(warnings) * 3)
    score = max(0, 100 - hard_penalty - soft_penalty)
    return {
        "valid": not errors,
        "deterministic_gate_score": score,
        "errors": errors,
        "warnings": warnings,
        "metrics": metrics,
        "shot_count": len(plan.get("shots") or []),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Validate a Live MV Weaver JSON plan")
    ap.add_argument("plan", type=Path)
    ap.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = ap.parse_args()
    try:
        plan = json.loads(args.plan.read_text(encoding="utf-8"))
    except Exception as exc:
        print(json.dumps({"valid": False, "deterministic_gate_score": 0, "errors": [{"code": "READ_ERROR", "message": str(exc)}], "warnings": [], "metrics": {}, "shot_count": 0}, ensure_ascii=False, indent=2))
        return 2
    report = validate(plan)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("PASS" if report["valid"] else "FAIL")
        print(f"deterministic_gate_score={report['deterministic_gate_score']}")
        for e in report["errors"]:
            print(f"ERROR {e['code']}: {e['message']}")
        for w in report["warnings"]:
            print(f"WARN  {w['code']}: {w['message']}")
        print(json.dumps(report["metrics"], ensure_ascii=False, indent=2))
    return 0 if report["valid"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
