#!/usr/bin/env python3
"""Local structural analyzer for reference videos used by Live MV Weaver.

Requires ffmpeg + ffprobe. No cloud APIs, OCR, speech recognition, or model calls.
It extracts deterministic media metadata, visual scene-cut candidates, interval
statistics, representative scene frames, and contact sheets for human/agent review.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import statistics
import subprocess
import sys
from pathlib import Path
from typing import Any

PTS_RE = re.compile(r"pts_time:([0-9.]+)")


def _need(binary: str) -> str:
    path = shutil.which(binary)
    if not path:
        raise RuntimeError(f"required executable not found: {binary}")
    return path


def _run(cmd: list[str], *, capture: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        check=True,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )


def probe(video: Path) -> dict[str, Any]:
    ffprobe = _need("ffprobe")
    proc = _run([
        ffprobe, "-v", "error", "-show_entries",
        "format=duration:stream=index,codec_type,codec_name,width,height,r_frame_rate,avg_frame_rate,sample_rate,channels",
        "-of", "json", str(video)
    ], capture=True)
    raw = json.loads(proc.stdout)
    streams = raw.get("streams", [])
    v = next((s for s in streams if s.get("codec_type") == "video"), {})
    a = next((s for s in streams if s.get("codec_type") == "audio"), {})
    return {
        "duration_sec": round(float(raw.get("format", {}).get("duration", 0.0)), 6),
        "video_codec": v.get("codec_name"),
        "width": v.get("width"),
        "height": v.get("height"),
        "r_frame_rate": v.get("r_frame_rate"),
        "avg_frame_rate": v.get("avg_frame_rate"),
        "audio_codec": a.get("codec_name"),
        "sample_rate": int(a["sample_rate"]) if a.get("sample_rate") else None,
        "channels": a.get("channels"),
    }


def detect_scene_cuts(video: Path, threshold: float) -> list[float]:
    ffmpeg = _need("ffmpeg")
    proc = subprocess.run([
        ffmpeg, "-hide_banner", "-i", str(video),
        "-vf", f"select='gt(scene,{threshold})',showinfo",
        "-an", "-f", "null", "-"
    ], text=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-2000:])
    cuts: list[float] = []
    for line in proc.stderr.splitlines():
        m = PTS_RE.search(line)
        if m:
            value = round(float(m.group(1)), 6)
            if not cuts or abs(value - cuts[-1]) > 1e-4:
                cuts.append(value)
    return cuts


def interval_stats(duration: float, cuts: list[float]) -> dict[str, Any]:
    points = [0.0] + [c for c in cuts if 0 < c < duration] + [duration]
    intervals = [points[i + 1] - points[i] for i in range(len(points) - 1)]
    if not intervals:
        return {"count": 0}
    return {
        "count": len(intervals),
        "mean_sec": round(statistics.mean(intervals), 6),
        "median_sec": round(statistics.median(intervals), 6),
        "min_sec": round(min(intervals), 6),
        "max_sec": round(max(intervals), 6),
    }


def make_contact_sheets(video: Path, outdir: Path, threshold: float, columns: int = 5, rows: int = 5) -> list[str]:
    ffmpeg = _need("ffmpeg")
    frames = outdir / "scene_frames"
    frames.mkdir(parents=True, exist_ok=True)
    pattern = frames / "scene_%03d.jpg"
    _run([
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", str(video),
        "-vf", f"select='eq(n,0)+gt(scene,{threshold})',scale=180:-2",
        "-vsync", "vfr", "-q:v", "3", str(pattern)
    ])
    count = len(list(frames.glob("scene_*.jpg")))
    if count == 0:
        return []
    nb = columns * rows
    sheet_pattern = outdir / "contact_sheet_%03d.jpg"
    _run([
        ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-framerate", "1",
        "-i", str(pattern),
        "-vf", f"tile={columns}x{rows}:nb_frames={nb}:padding=4:margin=4",
        "-vsync", "vfr", "-q:v", "3", str(sheet_pattern)
    ])
    sheets = sorted(outdir.glob("contact_sheet_*.jpg"))
    # Stable convenience name for single-sheet consumers/tests.
    if sheets:
        shutil.copy2(sheets[0], outdir / "contact_sheet.jpg")
    return [p.name for p in sheets]


def analyze(video: Path, outdir: Path, threshold: float, contact_sheet: bool) -> dict[str, Any]:
    outdir.mkdir(parents=True, exist_ok=True)
    media = probe(video)
    cuts = detect_scene_cuts(video, threshold)
    manifest: dict[str, Any] = {
        "source_filename": video.name,
        "media": media,
        "scene_threshold": threshold,
        "scene_cuts_sec": cuts,
        "visual_intervals": interval_stats(media["duration_sec"], cuts),
        "notes": [
            "Scene cuts are visual-change candidates, not semantic shot labels.",
            "Use contact sheets to annotate performer/audience/dialogue/band/crowd roles.",
            "Do not infer song pauses from picture cuts; audio continuity must be assessed from the locked song/event structure."
        ],
    }
    if contact_sheet:
        manifest["contact_sheets"] = make_contact_sheets(video, outdir, threshold)
    (outdir / "reference_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return manifest


def main() -> int:
    ap = argparse.ArgumentParser(description="Analyze a reference MV locally with ffmpeg/ffprobe")
    ap.add_argument("video", type=Path)
    ap.add_argument("--output-dir", type=Path, default=Path("reference-analysis"))
    ap.add_argument("--scene-threshold", type=float, default=0.18)
    ap.add_argument("--contact-sheet", action="store_true")
    args = ap.parse_args()
    if not args.video.exists():
        print(f"video not found: {args.video}", file=sys.stderr)
        return 2
    if not (0.0 < args.scene_threshold < 1.0):
        print("scene threshold must be between 0 and 1", file=sys.stderr)
        return 2
    try:
        manifest = analyze(args.video, args.output_dir, args.scene_threshold, args.contact_sheet)
    except Exception as exc:
        print(f"analysis failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({
        "manifest": str(args.output_dir / "reference_manifest.json"),
        "duration_sec": manifest["media"]["duration_sec"],
        "scene_cut_count": len(manifest["scene_cuts_sec"]),
        "contact_sheets": manifest.get("contact_sheets", []),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
