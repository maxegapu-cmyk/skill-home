---
name: live-mv-weaver
description: Use when creating, reconstructing, or adapting a music video where one continuous live song remains the master timeline while performer coverage is interwoven with recurring audience reactions, in-world dialogue, band details, callbacks, and same-location micro-drama; especially when a supplied reference MV uses this grammar.
---

# Live MV Weaver

## Core principle

Treat the performance as the event that causes the story. The camera may leave the singer; the song clock never leaves the singer. Audience material is not B-roll: it is recurring human evidence that the performance is changing the room.

Use `REPLICA` when structural fidelity to the reference is the priority. Use `REPLICA_PLUS` when the same grammar must be preserved but micro-performance, continuity, audio clarity, cut precision, and candidate selection should be improved without adding unrelated spectacle or locations.

## Hard contract

1. Lock one master song from `song_start_sec` to `song_end_sec`. Generated clip audio never replaces it.
2. Audience dialogue is diegetic overlay. Choose a defensible music window, duck gently, then recover the song immediately.
3. Keep one continuous live world unless the brief/reference explicitly authorizes a break.
4. Maintain a performance spine. Every non-performance insertion states `leave_reason` and `return_trigger`.
5. Maintain recurring audience threads. Strict mode requires thread IDs, emotion stages, continuity state, and later recurrence.
6. Translate lyric meaning into observable human consequence before literal lyric illustration.
7. One generation unit performs one clear beat. The edit owns exact timing and cuts.
8. Reference evidence overrides generic defaults. Do not improve the MV by destroying the reference grammar.

## Workflow

1. Read `references/reference-analysis.md`. Run `scripts/analyze_reference.py` on the reference, label the cut intervals, then run `scripts/derive_reference_profile.py` to create `reference_style_profile.json`.
2. Read `references/music-map.md`. Lock `song_map.json`: structure, lyric phrases, energy/climax windows, and safe dialogue windows.
3. Read `references/archetype-dna.md` and `references/continuity-bible.md`. Lock `mv_dna.json`, `live_world.json`, and `character_bank.json`.
4. Read `references/weave-grammar.md`. Write `live_director_score.json`, audience threads, escalation, callbacks, and `weave_plan.json` before writing shots.
5. Read `references/audio-continuity.md` and `references/prompt-adapters.md`. Build `shot_manifest.json`, `audio_mix_plan.json`, keyframes, and one prompt per generation unit.
6. Run `python scripts/validate_mv_plan.py shot_manifest.json --json`. With `strict_reference_mode`, profile drift becomes a hard failure.
7. Read `references/review-and-repair.md`. Generate candidates, write `candidate_qc.json`, run `python scripts/validate_candidate_qc.py candidate_qc.json --json`, keep only approved clips, and reshoot the smallest failed unit.
8. Apply `references/reference-fidelity-rubric.md` and `references/qa-gates.md`; deliver only after hard gates pass.

## Reference-calibrated default

When no stronger new reference contradicts it, start near: performance screen share 43–57%; performance-anchor median 2.4–4.1s; audience-reaction median 1.0–2.1s; non-performance excursion ≤5s; no more than three consecutive non-performance shots; dialogue ≤12% of the active song; at least two recurring audience threads; callback followed by a performer re-anchor.

## Required artifacts

`reference_manifest.json` → `reference_style_profile.json` → `song_map.json` → `mv_dna.json` → `live_world.json` → `character_bank.json` → `live_director_score.json` → `weave_plan.json` → `shot_manifest.json` → `audio_mix_plan.json` → `prompt_pack.md` → `candidate_qc.json` → `qc_report.md`.
