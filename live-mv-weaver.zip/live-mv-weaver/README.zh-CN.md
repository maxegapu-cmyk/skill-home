# Live MV Weaver v2.0

这是一个针对“连续现场演唱 + 观众微剧情”类型 MV 的参考视频驱动 Skill。核心不是把歌曲切成一段段剧情，而是让**完整歌曲始终作为母时间轴**：画面可以从歌手切到观众、乐队、短对白和情绪反应，但所有人都仍然活在同一场演出、同一分钟里。

## 这版重点解决什么

普通 AI MV 最容易出现几种假感：
- 一切到观众，歌就像停了；
- 观众变成随机 B-roll，每次都是陌生人；
- 开头就哭到顶，后面没有情绪空间；
- 对白太长，把歌压没；
- 场景、座位、灯光、服装在不同生成片段里漂移；
- 镜头很漂亮，但为什么此刻切走、为什么此刻切回完全说不清；
- 最后的 callback 抢走歌手结尾。

v2.0 把这些变成了结构化字段和可执行验证，而不是只写成“导演建议”。

## 使用顺序

1. 参考视频分析：
   `python scripts/analyze_reference.py reference.mp4 --output-dir analysis --contact-sheet`
2. 对切点做语义标注，再生成参考风格参数：
   `python scripts/derive_reference_profile.py annotated_reference.json --output reference_style_profile.json`
3. 按 `SKILL.md` 建立歌曲时间轴、人物/场景连续性、观众线程和导演总谱。
4. 生成 `shot_manifest.json` 后执行：
   `python scripts/validate_mv_plan.py shot_manifest.json --json`
5. 每个镜头生成多个候选后，写 `candidate_qc.json`，执行：
   `python scripts/validate_candidate_qc.py candidate_qc.json --json`
6. 全部压力测试：
   `python -m unittest discover -s tests -v`

`examples/live-bar-example.json` 是严格模式下可通过门禁的完整示例。
