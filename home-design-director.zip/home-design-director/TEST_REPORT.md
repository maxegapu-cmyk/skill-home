# Test Report — v1.0.0

验证日期：2026-09-09

## 自动测试
执行：`pytest -q`

结果：31 passed。

覆盖范围：
- Room Model：concept/dimensioned、枚举校验、重复 ID、负/零尺寸、门窗坏引用、精确模式无尺寸。
- 布局检查：严重窄通道、边界窄通道、正常通道、门扇碰撞、缺门扇几何时不猜。
- 视觉 Brief：锁几何、带入已知尺寸、未知尺寸保持未知、未知 room_id 拒绝。
- Skill 合同：小白首轮、最多 3 问、几何唯一真源、安全边界。
- 8 个压力样本：正常两居、无比例尺截图、重复房间、坏门窗引用、负尺寸、假精确、窄通道、安全约束。

## CLI 压力样本
- `clean_dimensioned.json` → rc=0
- `no_scale_concept.json` → rc=0
- `safety_constraints.json` → rc=0
- `duplicate_room.json` → rc=2
- `broken_opening.json` → rc=2
- `negative_dimension.json` → rc=2
- `dimensioned_no_dims.json` → rc=2
- `narrow_corridor.json` → rc=2

其中 rc=2 表示检测到 error 级问题，并非程序崩溃。

## 静态检查
- Python `compileall`：通过。
- 发布文本扫描：无未完成占位符，无本项目不应出现的外部项目名或私有系统名。

## 能力边界
- 图像中的户型识别依赖宿主模型的视觉能力；脚本负责对识别后的 Room Model 做确定性检查。
- 无比例尺图片不会被恢复成“精确尺寸”。
- 结构、燃气、电气、消防、防水等仍需原始图纸/物业/现场专业人员核验。
