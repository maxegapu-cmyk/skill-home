# Room Model：空间几何唯一真源

Room Model 用来保存“已经确认的空间事实”，不是用来装饰效果图。

原则：
- 看不清、没有比例尺、没有标注的尺寸写 `null`，不要猜一个看起来合理的数字。
- `concept`：允许缺尺寸，只做概念布局和风格方向。
- `dimensioned`：至少存在一项可验证尺寸，适合更严格的家具尺度与动线检查。
- 门窗用 `room_ids` 指向相邻房间；ID 必须稳定、唯一。
- 承重墙、燃气、排水立管等不可随意修改的信息放入 `constraints`。

最小示例：
```json
{
  "project_name": "我的家",
  "mode": "concept",
  "units": "mm",
  "rooms": [{"id": "living", "name": "客厅", "width": null, "length": null}],
  "openings": [],
  "constraints": [],
  "assumptions": ["当前图片无比例尺"],
  "confidence": "medium"
}
```
