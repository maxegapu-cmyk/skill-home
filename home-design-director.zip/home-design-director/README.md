# Home Design Director

一个面向普通屋主的室内设计 Agent Skill。核心不是“多生成几张漂亮图”，而是先把空间事实锁住，再做布局、风格和视觉效果。

## 最简单的用法
1. 启用本 Skill。
2. 上传户型图/平面图/开发商截图。
3. 直接说目标，例如：“两个人住，宅家多，收纳要强，别太网红。”
4. Skill 会先读图，只问少量关键问题，再给 2–3 套方向。
5. 选一套后继续细化房间和效果图。

## 内置脚本
- `scripts/room_model.py`：Room Model 基础校验。
- `scripts/layout_checks.py`：净空与门扇碰撞的早期风险检查。
- `scripts/visual_brief.py`：生成锁几何的效果图任务 Brief。
- `scripts/run_checks.py`：对一个 Room Model 做命令行检查（完成版包含）。

## 重要说明
没有比例尺或可靠尺寸时，本 Skill 会使用概念模式。概念效果图不能替代施工图、现场复尺、结构/燃气/电气/消防/防水等专业核验。
