#!/usr/bin/env python3
"""Build geometry-preserving visual briefs from a Room Model."""
from __future__ import annotations
from typing import Any


def _fmt(value: Any, units: str) -> str:
    return "未知" if value is None else f"{value:g} {units}"


def build_visual_brief(model: dict[str, Any], room_id: str, style: str, intent: str) -> str:
    rooms = model.get("rooms", [])
    room = next((r for r in rooms if isinstance(r, dict) and r.get("id") == room_id), None)
    if room is None:
        raise ValueError(f"room_id not found: {room_id}")

    units = model.get("units", "mm")
    constraints = [c.get("text", str(c)) if isinstance(c, dict) else str(c) for c in model.get("constraints", [])]
    assumptions = [str(x) for x in model.get("assumptions", [])]
    openings = [o for o in model.get("openings", []) if isinstance(o, dict) and room_id in (o.get("room_ids") or [])]
    opening_summary = "、".join(f"{o.get('type', 'opening')}:{o.get('id', '?')}" for o in openings) or "无已登记门窗"
    constraint_text = "；".join(constraints) if constraints else "无额外锁定约束"
    assumption_text = "；".join(assumptions) if assumptions else "无"

    return f"""# {room.get('name', room_id)}｜视觉效果图任务

【几何唯一真源】
- 房间：{room.get('name', room_id)}（room_id={room_id}）
- 宽：{_fmt(room.get('width'), units)}
- 长：{_fmt(room.get('length'), units)}
- 层高：{_fmt(room.get('ceiling_height'), units)}
- 已登记门窗：{opening_summary}
- 锁定约束：{constraint_text}
- 当前假设/未知：{assumption_text}

【不可改规则】
不得移动、增加或删除墙体、门、窗；不得擅自改变房间比例、开口位置或已锁定约束。不得把未知尺寸视觉化为已确认事实。若模型无法严格保持几何，应优先保持空间关系并明确标记为概念效果图。

【设计方向】
- 风格：{style}
- 居住/空间意图：{intent}
- 材质、软装、灯光、家具款式可以围绕上述方向变化，但不得反向修改几何事实。

【输出要求】
生成真实可居住尺度的室内效果图；避免超广角把空间虚假拉大；家具比例服从已知房间尺寸；看不清或未确认的信息保持保守，不自行补成施工事实。
"""
