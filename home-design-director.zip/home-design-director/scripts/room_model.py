#!/usr/bin/env python3
"""Deterministic validation for Home Design Director Room Models."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any

VALID_MODES = {"concept", "dimensioned"}
VALID_UNITS = {"mm", "cm", "m"}
VALID_CONFIDENCE = {"low", "medium", "high"}
DIMENSION_KEYS = ("width", "length", "ceiling_height")


def finding(code: str, message: str, severity: str = "error", path: str | None = None) -> dict[str, Any]:
    item: dict[str, Any] = {"code": code, "severity": severity, "message": message}
    if path:
        item["path"] = path
    return item


def load_model(path: str) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data, dict):
        raise ValueError("Room Model root must be a JSON object")
    return data


def validate_room_model(model: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if model.get("mode") not in VALID_MODES:
        findings.append(finding("invalid_mode", "mode 必须是 concept 或 dimensioned。", path="mode"))
    if model.get("units") not in VALID_UNITS:
        findings.append(finding("invalid_units", "units 必须是 mm、cm 或 m。", path="units"))
    if model.get("confidence") not in VALID_CONFIDENCE:
        findings.append(finding("invalid_confidence", "confidence 必须是 low、medium 或 high。", path="confidence"))

    rooms = model.get("rooms", [])
    if not isinstance(rooms, list):
        return findings + [finding("invalid_rooms", "rooms 必须是列表。", path="rooms")]

    seen: set[str] = set()
    known_dimensions = 0
    for idx, room in enumerate(rooms):
        if not isinstance(room, dict):
            findings.append(finding("invalid_room", "房间记录必须是对象。", path=f"rooms[{idx}]"))
            continue
        room_id = room.get("id")
        name = room.get("name")
        if not room_id:
            findings.append(finding("missing_room_id", "每个房间都需要稳定的 id。", path=f"rooms[{idx}].id"))
        elif room_id in seen:
            findings.append(finding("duplicate_id", f"重复的 room id：{room_id}。", path=f"rooms[{idx}].id"))
        else:
            seen.add(room_id)
        if not name:
            findings.append(finding("missing_room_name", "每个房间都需要名称。", path=f"rooms[{idx}].name"))
        for key in DIMENSION_KEYS:
            value = room.get(key)
            if value is None:
                continue
            if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
                findings.append(finding("non_positive_dimension", f"{name or room_id or '房间'} 的 {key} 必须是正数或 null。", path=f"rooms[{idx}].{key}"))
            else:
                known_dimensions += 1

    openings = model.get("openings", [])
    if not isinstance(openings, list):
        findings.append(finding("invalid_openings", "openings 必须是列表。", path="openings"))
        openings = []
    opening_ids: set[str] = set()
    for idx, opening in enumerate(openings):
        if not isinstance(opening, dict):
            findings.append(finding("invalid_opening", "门窗记录必须是对象。", path=f"openings[{idx}]"))
            continue
        oid = opening.get("id")
        if oid:
            if oid in opening_ids or oid in seen:
                findings.append(finding("duplicate_id", f"重复的 id：{oid}。", path=f"openings[{idx}].id"))
            opening_ids.add(oid)
        for rid in opening.get("room_ids", []) or []:
            if rid not in seen:
                findings.append(finding("unknown_room_reference", f"门窗 {oid or idx} 引用了不存在的房间：{rid}。", path=f"openings[{idx}].room_ids"))

    if model.get("mode") == "dimensioned" and known_dimensions == 0:
        findings.append(finding("dimensioned_without_dimensions", "dimensioned 模式至少需要一个可验证的房间尺寸；否则请改用 concept 模式。", path="mode"))

    return findings
