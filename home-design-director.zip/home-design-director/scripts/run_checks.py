#!/usr/bin/env python3
"""Run deterministic Room Model and optional layout checks."""
from __future__ import annotations
import json
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from room_model import load_model, validate_room_model  # noqa: E402
from layout_checks import check_clearances, check_door_swings  # noqa: E402


def evaluate_model(model: dict[str, Any]) -> list[dict[str, Any]]:
    findings = list(validate_room_model(model))
    layout = model.get("layout_checks") or {}
    if isinstance(layout, dict):
        clearances = layout.get("clearances") or []
        doors = layout.get("doors") or []
        items = layout.get("items") or []
        if isinstance(clearances, list):
            findings.extend(check_clearances(clearances))
        if isinstance(doors, list) and isinstance(items, list):
            findings.extend(check_door_swings(doors, items))
    return findings


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) != 1:
        print("用法: python scripts/run_checks.py <room-model.json>")
        return 2
    try:
        model = load_model(argv[0])
        findings = evaluate_model(model)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"code": "input_error", "severity": "error", "message": str(exc)}, ensure_ascii=False))
        return 2

    print(json.dumps(findings, ensure_ascii=False, indent=2))
    return 2 if any(f.get("severity") == "error" for f in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
