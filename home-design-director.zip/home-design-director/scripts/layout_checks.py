#!/usr/bin/env python3
"""Lightweight layout-risk checks using only supplied geometry.

These checks are heuristics for early design review, not code-compliance certification.
"""
from __future__ import annotations
from typing import Any


def _finding(code: str, severity: str, message: str, **extra: Any) -> dict[str, Any]:
    item = {"code": code, "severity": severity, "message": message}
    item.update(extra)
    return item


def check_clearances(items: list[dict[str, Any]], critical_mm: float = 600, warning_mm: float = 750) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for item in items:
        value = item.get("clearance_mm")
        if value is None:
            findings.append(_finding("clearance_unknown", "info", f"{item.get('label', item.get('id', '该位置'))} 没有可验证的净空尺寸，先不猜。", item_id=item.get("id")))
            continue
        if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
            findings.append(_finding("invalid_clearance", "error", f"{item.get('label', '净空')} 的数值无效。", item_id=item.get("id")))
        elif value < critical_mm:
            findings.append(_finding("clearance_too_narrow", "error", f"{item.get('label', '通道')} 当前净空约 {value:g} mm，明显偏紧，建议重新布置并现场复核。", item_id=item.get("id")))
        elif value < warning_mm:
            findings.append(_finding("clearance_tight", "warning", f"{item.get('label', '通道')} 当前净空约 {value:g} mm，使用体验可能偏紧，建议结合家具真实尺寸复核。", item_id=item.get("id")))
    return findings


def _valid_bbox(value: Any) -> bool:
    return isinstance(value, list) and len(value) == 4 and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in value)


def _rects_overlap(a: list[float], b: list[float]) -> bool:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return max(ax1, ax2) > min(bx1, bx2) and max(bx1, bx2) > min(ax1, ax2) and max(ay1, ay2) > min(by1, by2) and max(by1, by2) > min(ay1, ay2)


def check_door_swings(doors: list[dict[str, Any]], items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for door in doors:
        swing = door.get("swing_bbox")
        if not _valid_bbox(swing):
            findings.append(_finding("door_geometry_unknown", "info", f"{door.get('label', door.get('id', '门'))} 缺少开门范围，无法可靠判断碰撞，先不猜。", door_id=door.get("id")))
            continue
        for item in items:
            bbox = item.get("bbox")
            if _valid_bbox(bbox) and _rects_overlap(swing, bbox):
                findings.append(_finding(
                    "door_swing_collision",
                    "warning",
                    f"{door.get('label', door.get('id', '门'))} 的开启范围与 {item.get('label', item.get('id', '家具'))} 重叠，建议调整家具位置或复核门扇方向。",
                    door_id=door.get("id"), item_id=item.get("id"),
                ))
    return findings
