# Changelog

## 1.0.0 - 2026-09-25

- First external release.
- Three input routes: separately installed Mac local-vault backend, authorized Windows plaintext snapshot, and JSON/JSONL.
- Exact group resolution before Mac digest extraction.
- Privacy modes, deterministic evidence IDs, duplicate/system/revoke filtering, candidate extraction, chunking, and source fingerprint.
- Two-phase prepare/commit state so failed AI runs do not skip unread history.
- No WeChat UI control, message sending, key capture, or bundled upstream source.
