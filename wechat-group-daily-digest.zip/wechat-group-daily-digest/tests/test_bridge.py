import json
import os
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import source_bridge  # noqa: E402


class SourceBridgeTests(unittest.TestCase):
    def test_locate_yichen_cli_from_env(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            script = root / "scripts" / "vault_cli.py"
            script.parent.mkdir(parents=True)
            script.write_text("print('x')", encoding="utf-8")
            old = os.environ.get("YICHEN_WECHAT_VAULT_DIR")
            os.environ["YICHEN_WECHAT_VAULT_DIR"] = str(root)
            try:
                found = source_bridge.locate_yichen_cli()
                self.assertEqual(found, script)
            finally:
                if old is None:
                    os.environ.pop("YICHEN_WECHAT_VAULT_DIR", None)
                else:
                    os.environ["YICHEN_WECHAT_VAULT_DIR"] = old

    def test_file_backend_reads_upstream_digest_json(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "source.json"
            payload = {
                "group": {"name": "群A", "username": "secret@chatroom"},
                "stats": {"last_message_timestamp": 9},
                "messages": [{"sender": "A", "timestamp": 9, "time": "t", "type": "文本", "content": "hi"}],
            }
            path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            result = source_bridge.load_file_source(path)
            self.assertEqual(result["group_name"], "群A")
            self.assertEqual(result["last_timestamp"], 9)
            self.assertEqual(len(result["messages"]), 1)
            self.assertNotIn("secret@chatroom", json.dumps(result, ensure_ascii=False))

    def test_yichen_bridge_uses_only_read_only_contacts_then_digest_source(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            fake_root = td / "backend"
            fake_script = fake_root / "scripts" / "vault_cli.py"
            fake_script.parent.mkdir(parents=True)
            source_json = td / "source.json"
            source_json.write_text(json.dumps({
                "group": {"name": "群A", "username": "secret@chatroom"},
                "stats": {"last_message_timestamp": 7},
                "messages": [{"sender": "A", "timestamp": 7, "time": "t", "type": "文本", "content": "hello"}],
            }, ensure_ascii=False), encoding="utf-8")
            log = td / "argv.json"
            fake_script.write_text(
                "import json,sys\n"
                f"log={str(log)!r}\n"
                "args=sys.argv[1:]\n"
                "with open(log,'a',encoding='utf-8') as f: f.write(json.dumps(args,ensure_ascii=False)+'\\n')\n"
                "if args and args[0]=='contacts':\n"
                " print(json.dumps({'count':1,'contacts':[{'username':'room@chatroom','display_name':'群A','is_group':True}]},ensure_ascii=False))\n"
                "else:\n"
                f" print(json.dumps({{'source_json': {str(source_json)!r}, 'last_message_timestamp': 7}}, ensure_ascii=False))\n",
                encoding="utf-8",
            )
            result = source_bridge.fetch_from_yichen(
                fake_script,
                group="群A",
                start="2026-09-25 00:00:00",
                end="2026-09-25 23:59:59",
                data_root=td / "data",
                limit=123,
            )
            calls = [json.loads(x) for x in log.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(calls[0][0], "contacts")
            self.assertEqual(calls[1][0], "digest-source")
            self.assertEqual(calls[1][1], "room@chatroom")
            joined = " ".join(" ".join(x) for x in calls)
            self.assertNotIn("extract_keys.py", joined)
            self.assertNotIn("decrypt_all_dbs.py", joined)
            self.assertEqual(result["group_name"], "群A")
            self.assertEqual(result["last_timestamp"], 7)


class SnapshotBridgeTests(unittest.TestCase):
    def test_snapshot_bridge_resolves_unique_group_then_reads_history(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            script = td / "vault_cli.py"
            snapshot = td / "snap"
            snapshot.mkdir()
            log = td / "calls.jsonl"
            script.write_text(
                "import json,sys\n"
                f"log={str(log)!r}\n"
                "args=sys.argv[1:]\n"
                "with open(log,'a',encoding='utf-8') as f: f.write(json.dumps(args,ensure_ascii=False)+'\\n')\n"
                "if 'chats' in args:\n"
                " print(json.dumps({'chats':[{'chat_id':'abc123','display_name':'测试群','kind':'group'}]},ensure_ascii=False))\n"
                "elif 'history' in args:\n"
                " print(json.dumps({'chat':{'chat_id':'abc123','display_name':'测试群','kind':'group'},'messages':[{'message_id':'m1','time':'2026-09-25 10:00:00','timestamp':10,'type':1,'sender':'A','content':'hello'}]},ensure_ascii=False))\n"
                "else:\n"
                " print(json.dumps({'valid':True}))\n",
                encoding="utf-8",
            )
            result = source_bridge.fetch_from_snapshot(
                script,
                snapshot=snapshot,
                group="测试群",
                chat_id=None,
                start="2026-09-25",
                end="2026-09-25",
                limit=500,
            )
            calls = [json.loads(x) for x in log.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(calls[0][0:3], ["snapshot", "--snapshot", str(snapshot)])
            self.assertIn("chats", calls[0])
            self.assertIn("history", calls[1])
            self.assertEqual(result["group_name"], "测试群")
            self.assertEqual(result["messages"][0]["type"], "文本")
            self.assertNotIn("abc123", json.dumps(result, ensure_ascii=False))

    def test_snapshot_bridge_rejects_ambiguous_group(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            script = td / "vault_cli.py"
            snapshot = td / "snap"
            snapshot.mkdir()
            script.write_text(
                "import json,sys\n"
                "print(json.dumps({'chats':[{'chat_id':'a','display_name':'群','kind':'group'},{'chat_id':'b','display_name':'群','kind':'group'}]},ensure_ascii=False))\n",
                encoding="utf-8",
            )
            with self.assertRaises(RuntimeError):
                source_bridge.fetch_from_snapshot(
                    script,
                    snapshot=snapshot,
                    group="群",
                    chat_id=None,
                    start="2026-09-25",
                    end="2026-09-25",
                    limit=500,
                )

class MacGroupResolutionTests(unittest.TestCase):
    def test_yichen_bridge_rejects_duplicate_exact_group_names(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            script = td / "vault_cli.py"
            source_json = td / "source.json"
            source_json.write_text(json.dumps({"group":{"name":"群A"},"messages":[],"stats":{}}, ensure_ascii=False), encoding="utf-8")
            script.write_text(
                "import json,sys\n"
                "args=sys.argv[1:]\n"
                "if args and args[0]=='contacts':\n"
                " print(json.dumps({'count':2,'contacts':[{'username':'a@chatroom','display_name':'群A','is_group':True},{'username':'b@chatroom','display_name':'群A','is_group':True}]},ensure_ascii=False))\n"
                "else:\n"
                f" print(json.dumps({{'source_json':{str(source_json)!r}}},ensure_ascii=False))\n",
                encoding="utf-8",
            )
            with self.assertRaises(RuntimeError):
                source_bridge.fetch_from_yichen(
                    script,
                    group="群A",
                    start="2026-09-25 00:00:00",
                    end="2026-09-25 23:59:59",
                    data_root=td / "data",
                    limit=100,
                )


if __name__ == "__main__":
    unittest.main()
