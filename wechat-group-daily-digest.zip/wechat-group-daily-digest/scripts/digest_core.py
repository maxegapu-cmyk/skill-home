from __future__ import annotations

from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
from typing import Iterable

URL_RE = re.compile(r"https?://[^\s<>()\[\]{}]+", re.I)
DECISION_RE = re.compile(r"(?:决定|结论|确定|确认|定了|拍板|最终方案|采用|就按|统一为|改为)[:：]?", re.I)
ACTION_RE = re.compile(r"(?:TODO|待办|记得|需要|请|麻烦|负责|跟进|补充|更新|提交|处理|完成|截止|deadline|明天|今晚|本周)", re.I)
OPEN_RE = re.compile(r"(?:未解决|还没解决|待确认|待定|有没有|是否|怎么|为什么|谁知道|求助|问题|疑问|卡住|报错|失败)", re.I)
REVOKE_RE = re.compile(r"revokemsg|撤回了一条消息", re.I)
MEDIA_TYPES = {"图片", "语音", "视频", "表情", "位置", "名片", "链接/文件", "文件", "链接"}


def _alpha_label(index: int) -> str:
    # A..Z, AA..AZ ...
    out = ""
    n = index
    while True:
        out = chr(ord("A") + (n % 26)) + out
        n = n // 26 - 1
        if n < 0:
            return out


def _privacy_sender(sender: str, privacy: str, mapping: dict[str, str]) -> str:
    sender = (sender or "未知").strip() or "未知"
    if privacy == "strict":
        if sender not in mapping:
            mapping[sender] = f"成员{_alpha_label(len(mapping))}"
        return mapping[sender]
    return sender


def _is_noise(row: dict) -> bool:
    typ = str(row.get("type") or "")
    content = str(row.get("content") or "").strip()
    if typ == "系统":
        return True
    if REVOKE_RE.search(content):
        return True
    if not content:
        return True
    return False


def normalize_messages(rows: Iterable[dict], privacy: str = "balanced") -> list[dict]:
    if privacy not in {"none", "balanced", "strict"}:
        raise ValueError("privacy must be one of: none, balanced, strict")
    sender_map: dict[str, str] = {}
    out: list[dict] = []
    recent: dict[tuple[str, str, str], int] = {}
    for row in sorted(rows, key=lambda r: (int(r.get("timestamp") or 0), str(r.get("local_id") or ""))):
        if _is_noise(row):
            continue
        sender_raw = str(row.get("sender") or "未知")
        sender = _privacy_sender(sender_raw, privacy, sender_map)
        typ = str(row.get("type") or "未知")
        content = str(row.get("content") or "").strip()
        ts = int(row.get("timestamp") or 0)
        key = (sender, typ, content)
        previous = recent.get(key)
        if previous is not None and ts and previous and abs(ts - previous) <= 60:
            continue
        recent[key] = ts
        item = {
            "sender": sender,
            "timestamp": ts,
            "time": str(row.get("time") or ""),
            "type": typ,
            "content": content,
        }
        # privacy=none still intentionally strips storage IDs/paths; the digest layer never needs them.
        out.append(item)
    return out


def _extract_candidates(messages: list[dict]) -> dict:
    links: list[dict] = []
    decisions: list[dict] = []
    actions: list[dict] = []
    open_questions: list[dict] = []
    for m in messages:
        content = m["content"]
        for url in URL_RE.findall(content):
            links.append({"id": m["id"], "sender": m["sender"], "url": url.rstrip(".,;:!?)，。；：！？）")})
        candidate = {"id": m["id"], "sender": m["sender"], "content": content}
        if DECISION_RE.search(content):
            decisions.append(candidate)
        if ACTION_RE.search(content):
            actions.append(candidate)
        if OPEN_RE.search(content) or content.rstrip().endswith(("?", "？")):
            open_questions.append(candidate)
    return {
        "decisions": decisions[:50],
        "actions": actions[:80],
        "open_questions": open_questions[:80],
        "links": links[:100],
    }


def _fingerprint(group_name: str, messages: list[dict], source_meta: dict) -> str:
    payload = {
        "group": group_name,
        "messages": messages,
        "source": {k: source_meta.get(k) for k in sorted(source_meta) if k not in {"source_json", "source_markdown", "folder"}},
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def build_digest_pack(group_name: str, rows: Iterable[dict], privacy: str, source_meta: dict) -> dict:
    messages = normalize_messages(rows, privacy=privacy)
    for index, item in enumerate(messages, 1):
        item["id"] = f"m{index:04d}"
    speakers = Counter(m["sender"] for m in messages)
    types = Counter(m["type"] for m in messages)
    timestamps = [m["timestamp"] for m in messages if m["timestamp"]]
    safe_group_key = hashlib.sha256(group_name.encode("utf-8")).hexdigest()[:16]
    source = dict(source_meta)
    source["last_timestamp"] = max(timestamps, default=int(source_meta.get("last_timestamp") or 0))
    pack = {
        "schema_version": 1,
        "group": {"name": group_name, "key": safe_group_key},
        "privacy": privacy,
        "source": source,
        "stats": {
            "messages": len(messages),
            "speakers": len(speakers),
            "top_speakers": [{"name": k, "count": v} for k, v in speakers.most_common(10)],
            "types": dict(types.most_common()),
            "first_timestamp": min(timestamps, default=0),
            "last_timestamp": max(timestamps, default=0),
        },
        "messages": messages,
        "candidates": _extract_candidates(messages),
    }
    pack["fingerprint"] = _fingerprint(group_name, messages, source_meta)
    return pack


def chunk_messages(messages: list[dict], max_chars: int = 14000) -> list[list[dict]]:
    if max_chars < 200:
        max_chars = 200
    chunks: list[list[dict]] = []
    current: list[dict] = []
    current_chars = 0
    for item in messages:
        size = len(json.dumps(item, ensure_ascii=False)) + 1
        if current and current_chars + size > max_chars:
            chunks.append(current)
            current = []
            current_chars = 0
        current.append(item)
        current_chars += size
    if current:
        chunks.append(current)
    return chunks


def render_source_markdown(pack: dict) -> str:
    lines = [
        f"# {pack['group']['name']} · AI 日报素材",
        "",
        f"- 消息：{pack['stats']['messages']} 条",
        f"- 发言者：{pack['stats']['speakers']} 人",
        f"- 隐私模式：{pack['privacy']}",
        f"- Source fingerprint：`{pack['fingerprint']}`",
        "",
        "## 消息证据",
        "",
    ]
    for m in pack["messages"]:
        lines.append(f"- [{m['id']}] {m['time']} · {m['sender']} · {m['type']} · {m['content']}")
    return "\n".join(lines).rstrip() + "\n"


def render_ai_prompt(pack: dict) -> str:
    return f"""# 任务：生成微信群爬楼日报

你只根据随附的 source.md / pack.json 总结群「{pack['group']['name']}」。

## 事实约束
- 所有具体结论、待办、争议、资源和关键事件都必须附证据 ID，例如 `[m0012]`。
- 证据里没有的内容不要编造；图片、语音、视频只有占位符时，不猜内容。
- 把“事实”与“推断”分开。推断只能在确有上下文时出现，并明确写“推断：”。
- 不根据聊天时间、昵称、头像或措辞推断成员所在地、作息、年龄、健康、家庭、政治立场等私人属性。
- 不做人身评价，不给成员贴稳定人格标签。
- 链接只保留素材中真实出现的 URL，不自行补链接。

## 输出结构
1. `# 群聊日报｜日期/时间范围`
2. `## 30 秒看完`：3–6 条真正重要的信息，每条带证据 ID。
3. `## 今天聊了什么`：按话题组织；每个话题写“发生了什么 / 得出了什么 / 还有什么分歧”。
4. `## 已确认的结论`：没有就写“无明确结论”。
5. `## 待办与跟进`：只写明确或高度可验证的任务；负责人/时间不确定时标“未明确”。
6. `## 资源与链接`：去重列出链接及它在群里的用途；用途不确定就只写原始上下文。
7. `## 还没解决的问题`：列出需要继续追的点。
8. `## 值得回看的原话`：最多 5 条，每条尽量短，附证据 ID；不要摘录敏感私人信息。

## 写作要求
- 像一个靠谱群友帮大家爬完楼，不写会议纪要腔。
- 优先信息密度，不复述流水账。
- 多人重复表达同一观点时合并；有明显分歧时分别写清。
- 候选提取只是线索，不是事实判断；最终以消息证据为准。

Source fingerprint: {pack['fingerprint']}
"""


def commit_state(pack_path: Path, report_path: Path, state_path: Path) -> dict:
    if not report_path.exists() or not report_path.read_text(encoding="utf-8").strip():
        raise ValueError("report is missing or empty; refuse to advance state")
    pack = json.loads(pack_path.read_text(encoding="utf-8"))
    state = {
        "group_key": pack["group"]["key"],
        "group_name": pack["group"].get("name", ""),
        "last_timestamp": int(pack.get("source", {}).get("last_timestamp") or pack.get("stats", {}).get("last_timestamp") or 0),
        "fingerprint": pack.get("fingerprint", ""),
        "report": str(report_path.resolve()),
        "committed_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return state
