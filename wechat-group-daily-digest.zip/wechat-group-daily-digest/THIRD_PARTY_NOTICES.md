# Third-Party Notices

## Optional compatibility backend: mcncarl/yichen-skills / yichen-wechat-local-vault

Upstream repository:

`https://github.com/mcncarl/yichen-skills/tree/main/yichen-wechat-local-vault`

This package does **not** include, vendor, copy, modify, or redistribute that repository's source code. It interoperates with a separately installed copy through documented command-line interfaces (`contacts`, `digest-source`, and the read-only `snapshot` query path).

At the time this package was prepared (2026-09-25), the upstream repository stated that its original contributions are for personal learning and non-commercial personal use, that commercial use requires explicit written authorization, and that redistributors should not repackage the repository as a public Skill bundle. Always check the current upstream license before use.

The upstream project also documents its own third-party provenance and licenses. Those remain the responsibility of the upstream project and its user; this compatibility package does not relicense them.
