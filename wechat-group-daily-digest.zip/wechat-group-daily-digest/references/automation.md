# 定时运行与自动化边界

## 推荐结构

把自动化拆成两层：

1. **数据准备**：定时生成 `pack.json / source.md / chunks/`。
2. **AI 总结**：由你选择的 Agent 读取最新 run，生成 `report.md`，成功后执行 `commit`。

这样即使 AI 超时、额度耗尽或报告失败，`since-last` 的锚点也不会前移。

## 最稳模式：文件输入

如果你已经有一个合规、稳定的导出器每天生成 JSON/JSONL，可让系统计划任务执行：

```bash
python3 /path/to/wechat-group-daily-digest/scripts/wechat_group_digest.py prepare \
  --input /path/to/today-chat.json \
  --data-root /path/to/digest-data \
  --privacy strict
```

然后让 Agent 读取命令返回的 `run_dir/AI_PROMPT.md` 与 `source.md`。

## Mac 本地 Vault

本 Skill 不负责刷新或解密 `yichen-wechat-local-vault` 的原始数据库。定时任务只应在底座明文 Vault 已经由用户自己的、授权的流程保持新鲜时运行：

```bash
python3 /path/to/wechat-group-daily-digest/scripts/wechat_group_digest.py prepare \
  --group "目标群" \
  --since-last \
  --data-root "$HOME/Documents/wechat-group-daily-digest"
```

不要把“抓 key / 解密 / 登录 / 控制 UI”偷偷塞进同一个计划任务里。需要这些能力时，按底座自己的文档和许可单独配置。

## Windows 离线快照

快照模式不是实时监听。每次只读取用户明确提供的、已经 checkpoint 完成的静态明文快照。先由快照提供流程产生新快照，再运行本 Skill；本 Skill不会复制、修复、删除 WAL/SHM，也不会自动寻找微信目录。

## AI 调度

不同 Agent CLI 的非交互命令经常变化，所以本包不硬编码 `codex exec`、`claude -p` 一类命令。更稳的做法是让你当前使用的 Agent/自动化平台执行一条固定任务：

```text
运行 wechat-group-daily-digest：为「目标群」从上次成功日报继续；读取生成的 AI_PROMPT.md 和 source/chunks，写 report.md；只有报告成功写完才 commit。
```

如果平台支持系统级计划任务，建议每天固定一次；不要高频轮询微信。

## 失败恢复

- `prepare` 失败：不产生有效 run，不推进状态。
- AI 总结失败：不要执行 `commit`，下次仍可从旧锚点重来。
- `commit` 失败：保留 `report.md`，修复路径后重试 commit。
- 同名群：Windows 快照可直接传 `--chat-id`；若同时用 `--since-last`，仍需提供精确 `--group` 作为稳定状态名。
- 数据过大：调小日期范围，或按 `chunks/` 分块总结，不要提高到无限上下文。
