# Public Notes

本包为独立可外发版本。

内容采用通用的产品 CGI、PBR 材质、摄影棚布光和电商视觉原则组织，可独立使用。

适合与 Blender、Cinema 4D、KeyShot、Maya、3ds Max、ComfyUI 图生图流程，以及支持图片参考的通用生成式图像工具配合。
