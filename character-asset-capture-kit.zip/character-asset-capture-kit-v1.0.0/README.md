# Character Asset Capture Kit v1.0.0

A standalone skill for extracting reusable character assets from existing images, screenshots, reference sets and video.

Its design is intentionally simple:

**Scan → Capture → Normalize → Package → Reuse**

The package focuses on practical extraction rather than character invention. It distinguishes visible source facts from missing information, preserves original visual style, and treats outfit/props as part of the captured character asset instead of generic decorations.

## Quick use

- `/人物提取` — source-faithful extraction only
- `/人物资产` — build a reusable asset package
- `/批量提取` — extract multiple characters from references or video

## Local helper scripts

```bash
python scripts/capture_frames.py input.mp4 --out frames --interval 2
python scripts/make_contact_sheet.py --input frames --out contact.jpg
python scripts/init_asset_card.py --id CH01 --name "Character 01" --source frame_000001.jpg --out character.json
python scripts/validate_asset_card.py character.json
```

The scripts are optional. ChatGPT can use the skill directly with uploaded images/video; Codex can use the scripts for lightweight local preparation.
