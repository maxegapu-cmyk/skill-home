#!/usr/bin/env python3
import argparse, math, sys
from pathlib import Path
try:
    from PIL import Image, ImageOps, ImageDraw
except Exception as exc:
    print(f"Pillow required: {exc}", file=sys.stderr)
    sys.exit(3)

EXTS = {".jpg", ".jpeg", ".png", ".webp"}

def main():
    ap = argparse.ArgumentParser(description="Build a contact sheet for visual frame review.")
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--cell", default="320x240")
    args = ap.parse_args()
    src = Path(args.input)
    images = sorted(p for p in src.iterdir() if p.suffix.lower() in EXTS) if src.exists() else []
    if not images:
        print("no images found", file=sys.stderr); return 2
    try:
        cw, ch = map(int, args.cell.lower().split("x", 1))
    except Exception:
        print("cell must look like 320x240", file=sys.stderr); return 2
    cols = max(1, args.cols); rows = math.ceil(len(images) / cols)
    sheet = Image.new("RGB", (cols * cw, rows * ch), "white")
    for i, path in enumerate(images):
        with Image.open(path) as im:
            im = im.convert("RGB")
            fitted = ImageOps.contain(im, (cw, ch - 24))
            x = (i % cols) * cw + (cw - fitted.width) // 2
            y = (i // cols) * ch + (ch - 24 - fitted.height) // 2
            sheet.paste(fitted, (x, y))
        d = ImageDraw.Draw(sheet)
        d.text(((i % cols) * cw + 6, (i // cols) * ch + ch - 20), path.name[:44], fill="black")
    out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(out, quality=92)
    print(out)
    return 0

if __name__ == "__main__":
    sys.exit(main())
