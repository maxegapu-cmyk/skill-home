#!/usr/bin/env python3
import argparse, json
from pathlib import Path

FIELDS = ["face", "hair", "body", "feet", "back_view", "outfit", "props", "style"]

def main():
    ap = argparse.ArgumentParser(description="Create a simple character asset card from known source files.")
    ap.add_argument("--id", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--source", action="append", default=[])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    capture = {}
    for field in FIELDS:
        capture[field] = {"status": "unconfirmed", "value": [] if field == "props" else "", "source": []}
    data = {
        "format": "character-asset-card/1",
        "asset_id": args.id,
        "name": args.name,
        "source_files": args.source,
        "capture": capture,
        "approved_additions": [],
        "notes": []
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(out)

if __name__ == "__main__":
    main()
