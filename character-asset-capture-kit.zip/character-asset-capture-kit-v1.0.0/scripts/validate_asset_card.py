#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path

ALLOWED = {"seen", "partial", "unconfirmed"}
REQUIRED = {"face", "hair", "body", "feet", "back_view", "outfit", "props", "style"}

def main():
    ap = argparse.ArgumentParser(description="Validate a character asset card without turning guesses into source facts.")
    ap.add_argument("card")
    args = ap.parse_args()
    data = json.loads(Path(args.card).read_text(encoding="utf-8"))
    errors = []
    if data.get("format") != "character-asset-card/1": errors.append("wrong format")
    if not data.get("asset_id"): errors.append("missing asset_id")
    if not data.get("source_files"): errors.append("missing source_files")
    cap = data.get("capture", {})
    missing = REQUIRED - set(cap)
    if missing: errors.append("missing capture fields: " + ", ".join(sorted(missing)))
    for k, item in cap.items():
        status = item.get("status")
        if status not in ALLOWED:
            errors.append(f"{k}: invalid status {status}")
            continue
        sources = item.get("source", [])
        if status == "seen" and not sources:
            errors.append(f"{k}: seen field requires source")
        if status == "partial" and not sources:
            errors.append(f"{k}: partial field requires source")
        if status == "unconfirmed" and sources:
            errors.append(f"{k}: unconfirmed field must not claim source")
    for addition in data.get("approved_additions", []):
        if addition.get("origin") != "completion":
            errors.append("approved addition must keep origin=completion")
        if addition.get("approved") is not True:
            errors.append("approved addition must have approved=true")
        if not addition.get("field"):
            errors.append("approved addition missing field")
    if errors:
        for e in errors: print("ERROR:", e)
        return 1
    print("PASS")
    return 0

if __name__ == "__main__":
    sys.exit(main())
