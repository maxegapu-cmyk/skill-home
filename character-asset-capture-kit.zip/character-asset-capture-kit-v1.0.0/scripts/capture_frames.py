#!/usr/bin/env python3
import argparse, shutil, subprocess, sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser(description="Extract evenly spaced stills from a video for character inspection.")
    ap.add_argument("video", nargs="?")
    ap.add_argument("--out", default="frames")
    ap.add_argument("--interval", type=float, default=2.0, help="seconds between frames")
    ap.add_argument("--quality", type=int, default=2, help="ffmpeg JPEG q:v value; lower is better")
    args = ap.parse_args()
    if not args.video:
        ap.print_help(); return 0
    if args.interval <= 0:
        print("interval must be > 0", file=sys.stderr); return 2
    if shutil.which("ffmpeg") is None:
        print("ffmpeg not found", file=sys.stderr); return 3
    video = Path(args.video)
    if not video.exists():
        print("video not found", file=sys.stderr); return 4
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    fps = 1.0 / args.interval
    pattern = str(out / "frame_%06d.jpg")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video), "-vf", f"fps={fps}", "-q:v", str(args.quality), pattern]
    p = subprocess.run(cmd)
    if p.returncode != 0: return p.returncode
    print(f"extracted {len(list(out.glob('frame_*.jpg')))} frames to {out}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
