---
name: character-asset-capture-kit
description: Use when a user wants to extract a reusable person or character asset from an existing image, screenshot, set of references, or video while preserving the character's visible identity, body proportions, outfit, personal props, and original visual style. Supports single-character extraction, asset boards, and batch extraction from video.
---

# Character Asset Capture Kit

## Core flow

**Scan → Capture → Normalize → Package → Reuse**

This skill extracts an existing character. It does not treat extraction as character redesign.

## User commands

### `/人物提取`
Extract only what the source actually supports. Return a concise character record and, when requested, a clean isolated character image/cutout. Unknown or hidden regions stay unconfirmed.

### `/人物资产`
Build a reusable character asset package from the supplied source material. Preserve the visible face, hair, body proportions, outfit, footwear, accessories, props, and source visual medium. Complete missing regions only when needed, and label them as completion candidates until approved.

### `/批量提取`
For multi-image or video input, identify the characters and build separate asset packages. Use complementary frames for each character rather than treating every frame as equally useful.

## Non-negotiable rule

**不要把不可见内容写成来源事实。**

If the source does not show the back of a coat, shoes, hidden hair, or a prop detail, say so. A generated completion may be useful for production, but it is not evidence of the original design.

## What the asset must preserve

### Character identity
Preserve distinctive face shape, feature relationships, stable marks, hairline and recognizable hair structure. Do not beautify toward a generic face.

### Body and completeness
Preserve the source character's visible silhouette and proportions. When making a full-body asset, keep the full figure in frame and check head, torso, both arms/hands, legs and feet relative to the source anatomy. Do not "fix" deliberate stylization or non-standard anatomy.

### Outfit
Capture the actual layer order, silhouette, main seams/closures, color relationships and footwear visible in the source. Do not redesign the clothing to look more fashionable or modern.

### Personal props and accessories
Capture only items that belong to the character in the source: glasses, bags, jewelry, weapons, tools, helmets, badges, etc. Preserve their approximate scale and where they are worn or held. Do not add a generic prop because similar characters usually have one.

### Visual style
Keep the character in the source medium unless the user explicitly requests a conversion. Preserve stable line/shape/rendering behavior. Do not automatically turn old animation into modern glossy anime, a game render into photography, or a stylized illustration into a photoreal human.

## Single-image procedure

1. Scan the image and list what is fully visible, partly visible, and not visible.
2. Capture face/hair, body silhouette, outfit, props/accessories and visual style.
3. Flag perspective or pose that makes proportions unreliable.
4. Build the requested asset using only confirmed information plus explicitly labeled completion candidates.
5. Check the result against the source for identity, proportions, outfit, prop placement and style.

## Multi-reference procedure

Use each reference for the details it actually shows best. Do not allow a sharp face crop to invent shoes or a back view to overwrite the front face. If sources disagree, first check whether they show different outfits, states, mirrored footage or different design versions.

## Video procedure

Read `references/video-workflow.md`. For Codex/local work, use the frame and contact-sheet utilities. Select complementary frames: a face frame, a useful body frame, rear/outfit frame, and prop/detail frame when available. Avoid building the character from one dramatic frame if better evidence exists elsewhere.

## Asset-card statuses

The optional `character-asset-card/1` file uses only three capture states:
- `seen`: clearly visible and supported by one or more source files
- `partial`: only part of the feature is visible or perspective/occlusion limits certainty
- `unconfirmed`: not supported by the current source material

Approved completions live separately in `approved_additions`; they never rewrite the original capture status.

## Output guidance

For a normal `/人物资产` request, prefer a compact useful package:
1. clean character asset / asset board
2. short character record
3. unconfirmed items that matter to production
4. approved completion candidates, if any
5. source references used for each critical feature

Do not drown the user in internal bookkeeping unless they ask for it.

## Quality check

Reject or redo the asset when the result visibly changes the character's identity, major body proportion, outfit structure, important prop geometry/placement, or source visual medium. A visually attractive redesign is still a failed extraction.

Read `references/capture-rules.md` for edge cases and `references/asset-board.md` for presentation guidance.
