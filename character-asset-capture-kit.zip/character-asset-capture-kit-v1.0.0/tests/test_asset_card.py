import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(*args):
    return subprocess.run([sys.executable, *map(str, args)], text=True, capture_output=True)


def test_init_asset_card_marks_unseen_as_unconfirmed(tmp_path):
    out = tmp_path / "card.json"
    p = run(ROOT / "scripts" / "init_asset_card.py", "--id", "CH01", "--name", "Subject", "--source", "frame.png", "--out", out)
    assert p.returncode == 0, p.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["asset_id"] == "CH01"
    assert data["source_files"] == ["frame.png"]
    assert data["capture"]["feet"]["status"] == "unconfirmed"
    assert data["capture"]["back_view"]["status"] == "unconfirmed"


def test_validator_rejects_claimed_fact_without_source(tmp_path):
    card = {
        "format": "character-asset-card/1",
        "asset_id": "CH01",
        "name": "Subject",
        "source_files": ["frame.png"],
        "capture": {
            "face": {"status": "seen", "value": "oval", "source": []},
            "hair": {"status": "seen", "value": "black", "source": ["frame.png"]},
            "body": {"status": "partial", "value": "upper body visible", "source": ["frame.png"]},
            "feet": {"status": "unconfirmed", "value": "", "source": []},
            "back_view": {"status": "unconfirmed", "value": "", "source": []},
            "outfit": {"status": "partial", "value": "jacket", "source": ["frame.png"]},
            "props": {"status": "unconfirmed", "value": [], "source": []},
            "style": {"status": "seen", "value": "2D animation", "source": ["frame.png"]}
        },
        "approved_additions": []
    }
    pth = tmp_path / "bad.json"
    pth.write_text(json.dumps(card), encoding="utf-8")
    p = run(ROOT / "scripts" / "validate_asset_card.py", pth)
    assert p.returncode != 0
    assert "seen field requires source" in (p.stdout + p.stderr)


def test_validator_allows_approved_completion_without_rewriting_history(tmp_path):
    card = {
        "format": "character-asset-card/1",
        "asset_id": "CH01",
        "name": "Subject",
        "source_files": ["frame.png"],
        "capture": {
            "face": {"status": "seen", "value": "oval", "source": ["frame.png"]},
            "hair": {"status": "seen", "value": "black", "source": ["frame.png"]},
            "body": {"status": "partial", "value": "upper body visible", "source": ["frame.png"]},
            "feet": {"status": "unconfirmed", "value": "", "source": []},
            "back_view": {"status": "unconfirmed", "value": "", "source": []},
            "outfit": {"status": "partial", "value": "jacket", "source": ["frame.png"]},
            "props": {"status": "unconfirmed", "value": [], "source": []},
            "style": {"status": "seen", "value": "2D animation", "source": ["frame.png"]}
        },
        "approved_additions": [
            {"field": "feet", "value": "dark boots", "origin": "completion", "approved": True}
        ]
    }
    pth = tmp_path / "good.json"
    pth.write_text(json.dumps(card), encoding="utf-8")
    p = run(ROOT / "scripts" / "validate_asset_card.py", pth)
    assert p.returncode == 0, p.stdout + p.stderr
