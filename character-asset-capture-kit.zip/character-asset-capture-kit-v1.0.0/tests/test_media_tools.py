import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_contact_sheet_requires_images(tmp_path):
    out = tmp_path / "sheet.jpg"
    p = subprocess.run([sys.executable, str(ROOT / "scripts" / "make_contact_sheet.py"), "--input", str(tmp_path), "--out", str(out)], text=True, capture_output=True)
    assert p.returncode != 0
    assert "no images" in (p.stdout + p.stderr).lower()


def test_capture_frames_help_runs():
    p = subprocess.run([sys.executable, str(ROOT / "scripts" / "capture_frames.py"), "--help"], text=True, capture_output=True)
    assert p.returncode == 0
    assert "interval" in p.stdout.lower()
