from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_skill_contract_exists_and_is_independent():
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    assert skill.startswith("---\n")
    assert "name: character-asset-capture-kit" in skill
    assert "Scan → Capture → Normalize → Package → Reuse" in skill
    assert "/人物提取" in skill
    assert "/人物资产" in skill
    assert "/批量提取" in skill
    assert "不要把不可见内容写成来源事实" in skill


def test_required_support_files_exist():
    for rel in [
        "README.md",
        "references/capture-rules.md",
        "references/video-workflow.md",
        "references/asset-board.md",
        "scripts/init_asset_card.py",
        "scripts/validate_asset_card.py",
        "scripts/capture_frames.py",
        "scripts/make_contact_sheet.py",
    ]:
        assert (ROOT / rel).exists(), rel
