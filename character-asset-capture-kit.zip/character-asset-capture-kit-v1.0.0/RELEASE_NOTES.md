# v1.0.0

- standalone character asset extraction skill
- single-image, multi-reference and video workflows
- source-fact vs completion separation
- body completeness and proportion cautions
- outfit, footwear, accessory and personal-prop capture
- original visual-style preservation
- simple JSON asset card with validation
- optional FFmpeg frame extraction and Pillow contact sheet helpers
