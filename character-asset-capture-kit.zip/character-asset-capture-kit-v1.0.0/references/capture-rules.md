# Capture Rules

## Goal
Extract a reusable character asset from existing visual material without silently redesigning the character.

## Source truth rule
For every visible claim, keep the source frame or image that supports it. If something is hidden, cropped, blurred, or ambiguous, mark it as `unconfirmed` instead of inventing a fact.

## What to capture
- face: stable facial structure and distinctive marks
- hair: front shape, parting, length, volume, fixed ornaments
- body: visible proportions, silhouette, shoulder/torso/leg relation when actually observable
- outfit: layer order, silhouette, major seams, closures, footwear when visible
- props: object shape, scale relative to the body, carry/wear location
- style: the source medium and stable visual treatment, not accidental one-frame artifacts

## Completion candidate
If production requires a hidden region, make a **completion candidate**. Keep it separate from source facts. After a human approves it, it can be reused consistently, but its origin remains completion.

## Completeness
A final full-body asset should show the full head, body, hands and feet unless the source character itself has a different anatomy. Do not crop away missing information and call the result complete.

## Proportion caution
Do not derive canonical body proportions from a single extreme wide-angle, low-angle, foreshortened or action pose. Prefer multiple neutral views. When uncertain, describe only what can be supported.

## Style preservation
Do not automatically modernize, photorealize, sharpen, repaint, or beautify the source. A 2D animation character should still read as the same 2D production language; a game render should remain a game-render asset unless the user asks for conversion.
