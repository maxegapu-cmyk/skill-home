# Video Workflow

Use this path only when the input is video.

1. Extract inspection frames at a practical interval with `scripts/capture_frames.py`.
2. Build a contact sheet with `scripts/make_contact_sheet.py`.
3. Pick complementary views instead of one "best" frame: clear face, body, back/hair, outfit, footwear, and important prop views when present.
4. Create one asset card per character. Do not merge different people merely because clothing is similar.
5. Prefer frames with low motion blur and low occlusion. Keep action frames only when they reveal useful shape or prop relationships.
6. When several frames disagree, do not average them blindly. Check whether the character changed clothes/state, the source was mirrored, or one frame is distorted by perspective.
7. Only create missing-view completions when the current production task needs them.

For long footage, first sample sparsely; increase sampling around useful scenes instead of extracting every frame.
