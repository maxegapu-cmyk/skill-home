# Asset Board Guidance

The board is a readable packaging surface, not the source of truth.

Recommended layout for a general-purpose character asset board:
- large neutral full-body view
- face close-up
- left or right three-quarter head view when available
- back or rear-hair view when available
- outfit detail area
- footwear detail when visible
- important personal prop/accessory detail
- small source thumbnails or source labels
- a short "unconfirmed" note for hidden regions

Keep all generated panels in the source visual medium. Do not let the board layout redesign the character.

If a requested panel is unknown, either leave it absent or label a completion candidate. Never disguise a completion as extracted evidence.
