# Style DNA 2.0 — 从“感觉像”到可重复摄影语言

## 1. 八层摄影指纹

### A. Capture signature
- 焦段感：超广/广角/标准/中长焦/长焦；
- 相机距离：贴近人物还是后退压缩；
- 机位：眼平/胸口/腰部/低机位/高机位；
- 透视：四肢夸张还是压缩平整；
- 景深：环境是否可读；
- 裁切：头顶、脚、膝、腰、手的裁切习惯。

### B. Light graph
记录方向，而不是只写“柔光”：
- key azimuth：左/右/前/后；
- key elevation：高/平/低；
- source size：大窗/天光/裸闪/太阳；
- hardness：阴影边缘；
- fill：暗部抬多少；
- contrast：低/中/高；
- rim/specular：是否有轮廓或材质高光；
- exposure bias：亮肤、保高光、压暗背景等。

### C. Color pipeline
- 白平衡；
- 皮肤倾向；
- 饱和度；
- 对比与黑位；
- 高光/阴影色相；
- 颗粒与锐度；
- 暗角、褪色、色散等。

### D. Composition grammar
- 主体偏左/右/居中；
- 负空间方向；
- 地平线与建筑垂直线；
- 前景遮挡频率；
- 对称/不对称；
- 留头顶/留脚下空间；
- 画面是否故意“有点挤”。

### E. Direction grammar
- 摆拍还是抓拍；
- 视线比例；
- 动作幅度；
- 手部习惯；
- 身体是否经常旋转/侧身；
- 表情是冷静、松弛、轻笑还是更戏剧化。

### F. Environment grammar
- 地点类型；
- 材质；
- 主色板；
- 标志性但可泛化的环境元素；
- 人与空间的比例；
- 场景是干净还是信息丰富。

### G. Imperfection signature
- 轻微运动模糊；
- 轻微失焦；
- 直闪硬影；
- 高光溢出；
- 胶片颗粒；
- 偶尔遮挡、切边；
- 真实而非完美皮肤。

### H. Sequence grammar
摄影师拍一组时是否常见：
- hero → 远景 → 近景 → 动态 → 细节；
- 全身与半身交替；
- 直视只占少数；
- 某些图故意更松、更像过渡帧。

## 2. CORE / FLEX / OUTLIER

- CORE：多数图共同支持，或高度辨识且有重复证据；
- FLEX：允许为卖点服务；
- OUTLIER：单张偶然，不写入全套硬锁；
- FORBID：原作品内容，不允许复刻。

## 3. 组合规则

Style Fingerprint 不能是形容词堆：

坏：`cinematic, premium, editorial, aesthetic`。

好：`camera slightly below chest height; moderate wide-angle perspective; model placed right of center with open wall on camera-left; soft daylight from camera-right/back; low fill with detailed shadows; warm neutral skin; muted background saturation; lifted blacks and fine grain; candid mid-step with gaze away from camera; occasional foreground edge obstruction.`

## 4. 超越参考图

“超越”只能发生在不破坏 CORE 的地方：
- 更完整的正/背/侧信息；
- 更适合材质的光；
- 更合理的镜头节奏；
- 更少无意义遮挡；
- 更聪明的造型和手部动作；
- 更好的场景连续性。

不是把光打得更电影、更华丽、更锐就叫超越。
