# Compatibility Note — Garment & Selling Points

v2.0 已将本文件原来的职责拆分为两个唯一真源：

- 服装结构、颜色、图案、五金、证据优先级：`garment-evidence.md`
- 卖点到镜头与组照覆盖：`shot-planning.md`
- 配饰、道具和趋势适配：`styling-trend-engine.md`

不要在本文件重新维护第二份规则，避免与 v2.0 的 P0/P1/P2 证据体系冲突。
