# Scoring Rubric — 可执行验收分数

不要用一个总分掩盖硬错误。先判硬门，再评分。

## Gate 0：硬门
任一项失败则该张不能交付：
- P0 garment 错；
- 明显换脸/换人；
- 关键卖点被遮；
- 明显人体畸形；
- 出现不应有的文字/水印/他牌 Logo；
- 与整套场景时间完全冲突。

## 单张评分（100）
- garment fidelity 30
- photographer fingerprint 20
- model/identity consistency 15
- selling-point clarity 15
- scene/light continuity 10
- anatomy/photographic realism 5
- styling restraint 5

建议交付线：≥85，且 Gate 0 全通过。

## 套图评分（100）
- garment consistency across set 20
- identity consistency 15
- scene/time/light continuity 15
- style fingerprint coherence 15
- shot diversity & sequence rhythm 15
- selling-point coverage 15
- commercial usability 5

建议交付线：≥88。

## 诊断而非“刷分”
- 服装 95、风格 95，但背面结构错：仍然失败；
- 每张都漂亮但八张同一站姿：套图失败；
- 风格完全像参考但构图几乎复制原图：失败，需重新设计机位。
