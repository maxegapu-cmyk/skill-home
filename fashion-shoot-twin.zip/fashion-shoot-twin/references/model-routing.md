# Model Routing — 按模型能力拆条件

## A. 多图编辑模型 / GPT Image 类（默认）

适合：小白、快速、无需本地部署。

### 输入原则
锚点：
- 2–3 张最典型 Style；
- B 正/背/侧/关键细节；
- 可选 C 模特。

后续：
- Master Anchor；
- 1–2 张与本镜头最相关的 Style；
- 1 张本镜头最关键的 Garment 证据；
- 只有必要时再加 C 模特。

每张图在提示词里写清角色，不靠“模型自己懂”。

### 适合的修复方式
- change only X；
- preserve A/B/C；
- 重新上传对应证据图；
- 连续两次失败就从 Master Anchor 重生该镜头。

## B. ComfyUI / 本地高级链

目的不是强迫用户安装，而是当闭源模型反复漂移时提供可控路线。

### 条件解耦
- **Identity**：PuLID / FaceID 类；
- **Style**：IP-Adapter style transfer / StyleShot；
- **Composition**：IP-Adapter composition 或低权重 style adapter；
- **Pose / geometry**：OpenPose、Depth、Lineart、Segmentation ControlNet；
- **Garment try-on prepass**：IDM-VTON、CatVTON 等；
- **Final render**：SDXL / FLUX 兼容模型。

不要把一张 body/garment 参考直接作为高权重 style image，否则它会把不需要的原画面风格一起带入。

### 调参诊断
- 太像参考原帧 → 降 style/composition 权重，缩短作用区间；
- 人脸不稳 → 提升 identity 分支，减少与 style 分支冲突；
- 姿势不听 → 强化 pose/depth，而非继续堆文字；
- 服装结构错 → 强化 garment evidence / try-on prepass；
- 画面僵 → identity/pose 控制过强，放松非关键分支。

### 新一代统一条件路线（可选）
DreamO v1.1（ByteDance，SIGGRAPH Asia 2025）同时提供 IP、ID、Try-On 和 Style 任务，并用 feature routing 缓解多条件冲突，可作为高级实验路线。但其官方说明也明确：当前 Style 一致性相对不稳，且 Style 任务目前不能与其他条件组合。因此本 Skill 不把它当“一个节点包打天下”，而是按任务选择。

多轮编辑若出现“越修越糊、肢体逐步变形、纹理坍塌”，可以研究 FreqEdit 这类针对 FLUX.1-Kontext / Qwen-Image-Edit 的 multi-turn preservation 路线；核心思想与本 Skill 的 Master Anchor 原则一致：不要让连续编辑无限累计损伤。

## C. 许可提醒

本 Skill 可以把开源 VTON 工具当作研究/预演路线，但商用前必须单独核对代码、模型权重、底模和数据集许可。不要因为“GitHub 可下载”就默认可商用。

截至 2026-10 核验：
- PuLID 官方仓库代码标为 Apache-2.0；但实际使用还要继续核对所配套底模/权重条款；
- IDM-VTON 官方仓库明确写明代码和 checkpoints 为 CC BY-NC-SA 4.0；
- CatVTON 官方仓库明确写明 code/checkpoints/demo 为 CC BY-NC-SA 4.0，属于非商业许可。

所以商业广告不能默认把 IDM-VTON / CatVTON 当成可直接商用生产链。

## 参考项目（2026-10 核验）
- OpenAI Image Prompting: https://developers.openai.com/api/docs/guides/image-prompting
- OpenAI GPT Image Prompting Guide: https://developers.openai.com/cookbook/examples/multimodal/image-gen-models-prompting-guide
- ComfyUI IP-Adapter concept: https://github.com/Comfy-Org/workflow_templates/blob/main/site/knowledge/concepts/ip-adapter.md
- PuLID official: https://github.com/ToTheBeginning/PuLID
- StyleShot: https://github.com/open-mmlab/StyleShot
- IDM-VTON: https://github.com/yisol/IDM-VTON
- CatVTON: https://github.com/Zheng-Chong/CatVTON
- DreamO: https://github.com/bytedance/DreamO
- FreqEdit: https://github.com/FreqEdit/FreqEdit
