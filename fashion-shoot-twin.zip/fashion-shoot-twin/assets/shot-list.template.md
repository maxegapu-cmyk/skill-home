# Shot Portfolio

**Garment**：【】  **Core selling points**：【】  **Count**：【6/7/8】  **Ratio**：【】

| # | Commercial job | Selling point | Size | Angle | Camera / lens family | Zone | Pose / gaze | Composition | Light | Styling | Evidence inputs | Continuity anchors | Risk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Hero + Master Anchor | 【】 | full | front / 3⁄4 | 【】 | Z1 | 【】 | 【】 | 【】 | minimal | A【】+B【】+C【】 | 【】 | 【】 |

## Coverage check
- Front silhouette: #【】
- Back: #【】
- Side/3⁄4: #【】
- Upper body: #【】
- Detail: #【】
- Environment: #【】
- Motion: #【】
- P0/P1 selling point coverage: 【】
