#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI 味检查：扫描中文正文里常见的 AI 写作痕迹，按行报告。只发现问题，改法见 references/style.md。

用法：python ai_check.py 文件或目录 [--top 30]
"""
import argparse
import re
import statistics
import sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

# 否定对比句式（最典型的痕迹）
NEG = [
    (r"不是[^。！？\n]{1,30}?[，,]?\s*而是", "不是…而是"),
    (r"并不是[^。！？\n]{1,30}?[，,]\s*(?:而)?是", "并不是…是"),
    (r"是[^。！？\n，,]{1,20}?[，,]?\s*而不是", "是…而不是"),
    (r"不像[^。！？\n]{1,30}?[，,]\s*(?:倒|反而|更)像", "不像…倒像"),
    (r"与其说[^。！？\n]{1,30}?不如说", "与其说…不如说"),
    (r"没有[^。！？\n]{1,20}?[，,]\s*(?:但|却)也", "没有…但也"),
    (r"不只是[^。！？\n]{1,30}?更是", "不只是…更是"),
]
# 高频套话
CLICHE = ("仿佛 似乎 宛如 一抹 一丝 嘴角勾起 嘴角上扬 勾起一抹 眸子 眼底闪过 眼中闪过 深吸一口气 "
          "空气仿佛凝固 时间仿佛静止 心中一紧 心头一紧 难以言喻 莫名的 无尽的 交织 诉说着 命运的齿轮 "
          "这一刻 某种 不由得 不禁 微不可察 意味深长 若有所思 喃喃自语 心中涌起 一股暖流 "
          "仿若 恍若 映照 熠熠生辉 璀璨 无声地 悄然").split()
# 段尾升华
SUMMARY = [r"这或许就是", r"(?:他|她|我)终于(?:明白|懂得|意识到)", r"也许[^。]{0,20}才是", r"原来[^。]{0,15}一直都"]
TRIPLE = re.compile(r"([^，。；、\n]{2,8}的[^，。；、\n]{1,8})[，、]([^，。；、\n]{2,8}的[^，。；、\n]{1,8})[，、]([^，。；、\n]{2,8}的[^，。；、\n]{1,8})")


def sentences(text):
    return [s for s in re.split(r"(?<=[。！？!?])", text) if len(s.strip()) > 1]


def check(path):
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    lines = text.split("\n")
    hits = []
    for no, line in enumerate(lines, 1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        for pat, name in NEG:
            for m in re.finditer(pat, line):
                hits.append((3, no, f"否定对比「{name}」", m.group(0)[:40]))
        for w in CLICHE:
            if w in line:
                hits.append((1, no, f"套话「{w}」", ""))
        for pat in SUMMARY:
            m = re.search(pat, line)
            if m:
                hits.append((2, no, "升华/下结论", line[m.start():m.start() + 30]))
        m = TRIPLE.search(line)
        if m:
            hits.append((2, no, "三连排比", m.group(0)[:40]))
        if line.count("——") >= 2:
            hits.append((1, no, f"破折号 {line.count('——')} 处", ""))
    body = "".join(l for l in lines if not l.lstrip().startswith("#"))
    chars = len(re.sub(r"\s", "", body)) or 1
    sents = sentences(body)
    lens = [len(s) for s in sents]
    stats = []
    per_k = lambda n: n * 1000 / chars
    dash, ell = body.count("——"), body.count("……")
    stats.append(f"字数 {chars}，句子 {len(sents)}")
    if per_k(dash) > 3:
        stats.append(f"破折号偏多：每千字 {per_k(dash):.1f} 处")
    if per_k(ell) > 3:
        stats.append(f"省略号偏多：每千字 {per_k(ell):.1f} 处")
    if len(lens) >= 15:
        cv = statistics.pstdev(lens) / (statistics.mean(lens) or 1)
        if cv < 0.45:
            stats.append(f"句长过于均匀（变异系数 {cv:.2f}，建议 0.5 以上）：长短句交替少")
    paras = [l for l in lines if l.strip() and not l.lstrip().startswith("#")]
    if len(paras) >= 10:
        plens = [len(p) for p in paras]
        pcv = statistics.pstdev(plens) / (statistics.mean(plens) or 1)
        if pcv < 0.4:
            stats.append(f"段落长度过于均匀（变异系数 {pcv:.2f}）")
    neg_n = sum(1 for h in hits if h[0] == 3)
    cli_n = sum(1 for h in hits if h[0] == 1 and h[2].startswith("套话"))
    stats.append(f"否定对比 {neg_n} 处，套话 {cli_n} 处（每千字 {per_k(cli_n):.1f}）")
    return hits, stats


def main():
    ap = argparse.ArgumentParser(description="AI 味检查")
    ap.add_argument("path")
    ap.add_argument("--top", type=int, default=30)
    a = ap.parse_args()
    p = Path(a.path)
    files = sorted(p.rglob("*.md")) + sorted(p.rglob("*.txt")) if p.is_dir() else [p]
    for f in files:
        hits, stats = check(f)
        print(f"== {f.name} ==")
        for s in stats:
            print("  " + s)
        hits.sort(key=lambda h: (-h[0], h[1]))
        for _, no, kind, frag in hits[:a.top]:
            print(f"  第{no}行 {kind}" + (f"：{frag}" if frag else ""))
        if len(hits) > a.top:
            print(f"  ……另有 {len(hits) - a.top} 处，用 --top 查看更多")
        if not hits:
            print("  没有命中规则")


if __name__ == "__main__":
    main()
