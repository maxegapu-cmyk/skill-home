from pathlib import Path
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
contract = json.loads((ROOT / "tests/expected-contract.json").read_text(encoding="utf-8"))
errors = []

for rel in contract["required_files"]:
    if not (ROOT / rel).exists():
        errors.append(f"missing required file: {rel}")

skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
if not re.search(r"^---\nname: [a-z0-9-]+\ndescription: Use when .+?\n---", skill, re.S):
    errors.append("SKILL.md frontmatter is invalid or trigger description is malformed")

cases_path = ROOT / "tests/cases.json"
if cases_path.exists():
    cases = json.loads(cases_path.read_text(encoding="utf-8"))
    if len(cases) < contract["minimum_case_count"]:
        errors.append(f"only {len(cases)} test cases")
    ids = [c.get("id") for c in cases]
    if len(ids) != len(set(ids)):
        errors.append("duplicate test case ids")
    for c in cases:
        if not c.get("mode") or not c.get("brief") or not c.get("must"):
            errors.append(f"malformed test case: {c.get('id')}")

refs = list((ROOT / "references").glob("*.md"))
if len(refs) < contract["minimum_reference_count"]:
    errors.append(f"only {len(refs)} reference modules")

text_files = [p for p in ROOT.rglob("*") if p.is_file() and p.suffix.lower() in {".md", ".json", ".py", ".txt"}]
for p in text_files:
    text = p.read_text(encoding="utf-8", errors="ignore")
    if not p.name.startswith("verify_") and re.search(r"https?://|github\.com|git clone|author[s]?:|contact(us)?:", text, re.I):
        errors.append(f"external provenance marker in {p.relative_to(ROOT)}")
    if not p.name.startswith('verify_') and re.search(r"\b(TODO|TBD|PLACEHOLDER|FIXME)\b", text, re.I):
        errors.append(f"placeholder token in {p.relative_to(ROOT)}")

# lightweight content invariants
required_phrases = [
    "Portrait Charter", "reference", "body", "Light", "Material", "series", "repair", "Hard anchors", "Vitality State", "kinetic chain", "breath", "recovery phase", "motion residue", "energy arc"
]
joined = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in text_files if p.name != "expected-contract.json")
for phrase in required_phrases:
    if phrase.lower() not in joined.lower():
        errors.append(f"missing system concept: {phrase}")

if errors:
    print("VERIFY: FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("VERIFY: PASS")
print(f"reference_modules={len(refs)}")
print(f"scenario_cases={len(json.loads(cases_path.read_text(encoding='utf-8')))}")
print(f"text_files_scanned={len(text_files)}")
print("provenance_marker_scan=clean")
