from pathlib import Path
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

module = (ROOT / 'references/14-vitality-state-engine.md').read_text(encoding='utf-8')
required = [
    'Vitality State', 'energy level', 'shutter phase', 'kinetic chain', 'breath',
    'motion residue', 'energy contrast', 'recovery phase', 'Seated vitality',
    'Multi-person vitality', 'Series energy arc', 'Anti-cheap-sugar rules'
]
for term in required:
    if term.lower() not in module.lower():
        errors.append(f'missing vitality concept: {term}')

cases = json.loads((ROOT / 'tests/cases.json').read_text(encoding='utf-8'))
by_id = {c['id']: c for c in cases}
for n in range(61, 73):
    cid = f'T{n:02d}'
    if cid not in by_id:
        errors.append(f'missing vitality pressure case: {cid}')

# Isolation guard: this branch must not contain identifiers from prior private portrait branches.
prohibited = [
    'jinghong', '惊鸿', 'qingsheng', '绮生',
    'github.com/', 'git clone', 'source repository', 'upstream author'
]
text_files = [p for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in {'.md','.json','.py','.txt'}]
for p in text_files:
    text = p.read_text(encoding='utf-8', errors='ignore')
    if p.name.startswith('verify_'):
        continue
    for token in prohibited:
        if token.lower() in text.lower():
            errors.append(f'isolation marker found in {p.relative_to(ROOT)}: {token}')

# Vitality must be an overlay, not a replacement workflow.
router = (ROOT / 'references/01-brief-router.md').read_text(encoding='utf-8')
if 'orthogonal to modes A–G' not in router:
    errors.append('vitality overlay routing rule missing')

# The skill must reject smile-only vitality.
skill = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
if 'a large smile alone never qualifies' not in skill:
    errors.append('smile-only anti-pattern rule missing')

if errors:
    print('VITALITY VERIFY: FAIL')
    for e in errors:
        print(' -', e)
    sys.exit(1)

print('VITALITY VERIFY: PASS')
print('vitality_pressure_cases=12')
print('vitality_concepts=12')
print('private_branch_marker_scan=clean')
print('public_provenance_marker_scan=clean')
