# Brief Router

## A. Text-only portrait
Invent the missing production decisions. Default to one subject, one readable action, one dominant light source, one primary prop at most, and one clean visual motif.

## B. Subject reference
Split preservation into three levels:
- **Identity invariants**: facial proportions, age register, eye spacing, nose/mouth relationship, recognizable hairline when relevant.
- **Editable appearance**: hairstyle, makeup, clothing, accessories, expression.
- **World variables**: pose, location, light, lens, weather, color treatment.

Do not let “preserve identity” freeze expression or turn every image into a passport photo.

## C. Style reference
Extract rules in six channels:
1. framing geometry,
2. contrast and light direction,
3. palette relationships,
4. material response,
5. depth/texture treatment,
6. emotional distance between camera and subject.

Never copy the depicted person, unique costume, location layout, text, or logo unless the user explicitly asks and has the right to use it.

## D. Costume/object reference
Treat the item as an engineering object:
- silhouette,
- seam/closure logic,
- layer order,
- material,
- motif placement,
- scale relative to body,
- attachment points,
- how it deforms under action.

## E. Multi-reference authority map
Assign each source exactly one primary job where possible:

| Dimension | Authority |
|---|---|
| identity | R1 |
| pose/body | R2 |
| costume | R3 |
| environment | R4 |
| palette/light | R5 |

If two sources fight for the same dimension, choose a winner before prompt writing. Do not average incompatible geometry.

## F. Repair mode
Ask only: “what is the dominant visible failure?” Common classes: identity, anatomy, pose physics, costume structure, expression, composition, depth, light, material, over-stylization, series repetition. Repair the smallest layer that explains the failure.


## Vitality overlay
Vitality is orthogonal to modes A–G. Activate it when the user asks for 元气、鲜活、灵动、阳光、生命力、运动感、轻快、活泼, or when repair mode diagnoses “technically correct but dead/staged”. Load `14-vitality-state-engine.md`; do not create a separate workflow that bypasses identity, reference, costume, or repair logic.
