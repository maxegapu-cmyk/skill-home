# Output Contracts

## Single portrait
**Creative verdict** — one sentence.

**Final prompt** — fully compiled prompt.

**Hard anchors** — 4–8 items.

**Variation slots** — 3–6 items.

**Avoid** — only shot-specific failures.

## Reference reconstruction
Add a **Reference authority map** before the prompt:
- identity →
- pose →
- costume →
- environment →
- light/palette →

Then state which dimensions are intentionally free.

## 6–12 image series
Provide a compact table:

| Shot | Event | Distance/height | Hand task | Gaze | New information | Locked anchors |
|---|---|---|---|---|---|---|

Do not write 12 nearly identical full prompts unless the user asks. Build one series bible plus shot deltas, then compile full prompts only when needed.

## Repair request
Return in this order:
1. Verdict: dominant failure.
2. Cause: one or two causal reasons.
3. Minimal repair instruction.
4. Revised prompt fragment or local-edit instruction.
5. Keep list: what must not change from the successful parts.


## Vitality add-on
When vitality is requested, include one compact line before the final prompt:
- **Vitality State** — energy level / shutter phase / kinetic cue / breath cue / motion residue / calm contrast field.
For series work, add an **Energy** column to the shot table so the sequence has an explicit energy arc.
