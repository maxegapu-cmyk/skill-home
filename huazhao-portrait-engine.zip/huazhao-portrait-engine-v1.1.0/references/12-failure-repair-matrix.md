# Failure Repair Matrix

| Visible failure | Likely cause | Smallest effective repair |
|---|---|---|
| face no longer resembles reference | identity pressure too weak or style pressure too high | strengthen identity channel; reduce competing style on face; local face repair |
| face frozen / passport-like | identity over-constrained | keep facial invariants but free expression, gaze and head angle |
| hands malformed | no clear hand task; too many exposed fingers; local anatomy failure | simplify task, occlude naturally, local hand inpaint/repair |
| floating body | support point missing | specify foot/seat/contact and weight direction |
| sleeve intersects hand | garment action absent | describe sleeve weight, hand path and contact order |
| costume looks cosplay | decoration without construction/material logic | rebuild silhouette/layers/material, reduce symbols |
| “too AI beautiful” | symmetry + wax skin + generic soft light | add asymmetry, local skin color, motivated light, task, imperfect hair |
| flat cutout subject | no depth planes / mismatched blur | add foreground or background layer, consistent focus falloff and atmosphere |
| everything glows | uncontrolled highlight language | choose one light source, separate matte and reflective materials |
| reference style copied too literally | source content not separated from source rules | keep only framing/light/palette/texture rules; redesign subject/world |
| set feels like same image repeated | variation axes not planned | use series matrix; change distance, hand task, gaze, camera height, event |
| set loses identity/world | too much simultaneous randomization | restore series bible; randomize only declared slots |
| prompt gets worse as it grows | redundant/conflicting constraints | trim to one control phrase per variable; remove prestige adjectives |

| smiling but still stiff | vitality isolated in face | rebuild kinetic chain, hand task, breath, shutter timing and motion residue |
| big motion looks posed | only peak extension described | move to anticipation/recovery phase; add weight transfer and counter-rotation |
| lively image turns into cheap sugar portrait | grin + saturation + bright blur stacked | reduce one expression channel, mute secondary palette, protect highlights, add task/off-frame cause |
| wind/hair movement looks fake | no shared force event | define wind direction, stance compensation, hair/cloth phase lag |
| energetic series feels exhausting/repetitive | every shot uses peak energy | build an energy arc with quiet, peak, recovery and afterglow beats |
