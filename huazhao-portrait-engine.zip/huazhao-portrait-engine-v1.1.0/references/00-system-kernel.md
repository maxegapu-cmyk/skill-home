# System Kernel

## The eight-layer stack
A strong portrait is controlled as seven coupled but separable layers:

1. **Meaning** — why this picture exists; one emotional or narrative proposition.
2. **Person** — identity, age register, temperament, grooming, facial truth.
3. **Action** — a physical event with a before and after.
4. **Space** — where the body is, what supports it, what overlaps it, what the camera can actually see.
5. **Light** — a source with direction, softness, falloff and motivated reflections.
6. **Matter** — skin, hair, cloth, metal, paper, wood, water, dust, weather.
7. **Vitality** — energy level, shutter phase, kinetic chain, breath, attention, motion residue and energy contrast.
8. **Sequence** — continuity and variation across a set.

The system fails when one layer is asked to solve another. Examples: adding “cinematic” cannot fix a weightless pose; adding “ultra detailed” cannot fix wrong garment construction; a face reference cannot guarantee full-body pose; negative prompts cannot rescue contradictory composition instructions.

## Priority rule
When constraints conflict, use this order unless the user explicitly overrides it:

**identity/subject > requested action > body geometry > costume structure > environment geometry > lighting causality > style treatment > decorative detail**

This order prevents a beautiful but wrong image.

## Portrait Charter
Before prompt writing, compress the request into:

- Subject: who is visible?
- Cultural register: historically anchored / modern guofeng / fantasy classical / editorial hybrid.
- Event: what is happening at the shutter moment?
- Emotional temperature: restrained, bright, tense, wistful, playful, solemn, etc.
- Vitality State when relevant: energy level, shutter phase, breath, motion residue, energy contrast.
- Place: where exactly is the body standing/sitting/leaning?
- Visual hierarchy: what should the eye notice 1st / 2nd / 3rd?
- Hard anchors: what must not drift?
- Freedom budget: what may change?

If any line is unknown and not blocking, choose a conservative default instead of interrogating the user.

## Causal prompt order
Prompt in cause-to-effect order:

**scene + subject → event/action → body mechanics → vitality state when relevant → camera → light → materials → atmosphere → rendering/medium → guardrails**

Do not begin with a wall of style adjectives.
