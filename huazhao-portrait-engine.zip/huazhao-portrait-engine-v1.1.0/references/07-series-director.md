# Series Director

A series is not “same woman, random poses.” It is one visual world observed through controlled variation.

## Lock the series bible
Fix 6–9 anchors:
- subject identity,
- cultural register,
- main garment family,
- palette relationship,
- texture/medium,
- location family,
- lighting family,
- emotional trajectory,
- camera distance distribution.

## Variation matrix
Across 6 images, target at least:
- 3 different shot distances,
- 2 camera heights,
- 4 distinct hand tasks,
- 3 gaze targets,
- 2 lighting directions or time states,
- 3 environment interactions,
- no repeated pose skeleton in adjacent frames.

Across 9–12 images, add one visual reset: empty-space frame, silhouette/back view, detail insert, movement frame, reflection, or environmental establishing portrait.

## Sequence grammar
A robust 6-shot set:
1. Establish — person + world.
2. Approach — medium portrait with task.
3. Intimacy — close face/hands/material.
4. Disturbance — turn, wind, sound, arrival, spill, rain, movement.
5. Release — quieter frame with changed attention.
6. Signature — strongest graphic or emotional image.

## Anti-duplicate check
Before each new shot compare against the previous two:
- same body axis?
- same hand position?
- same gaze?
- same camera height?
- same negative-space side?
- same prop relationship?
If four or more match, redesign the shot.

## Continuity
Track mutable state: wet hair, opened window, moved book, loosened ribbon, candle burned lower, rain started, sleeve rolled up. Continuity creates story for free.


## Energy arc for lively sets
When vitality is central, add these to the series bible: energy baseline, allowed peak level, peak-frame count, recovery beats, and afterglow state. Across 9 images, use roughly 1 peak frame, 2–3 lively frames, 2 fresh frames, 1–2 recovery/quiet frames, and a distinct afterglow/signature. Do not keep all frames at maximum excitement.
