# Human Presence Engine

## The shutter-moment rule
Write the person as a moment with momentum:

**just before / during / just after + concrete action + attention target + residual body state**

Examples of useful structures:
- just after pulling a ribbon tight; shoulders settling; eyes checking the knot;
- mid-turn after hearing footsteps; skirt lagging behind the hips; gaze not yet at camera;
- holding a brush above wet ink; fingers still; breathing paused; attention on a spreading edge.

## Body mechanics
Every pose needs:
- support foot or seated support point,
- pelvis direction,
- ribcage direction,
- head direction,
- active hand task,
- passive hand logic,
- gaze target.

For standing poses, avoid symmetric weight unless formality is the point. For sitting poses, specify what carries the body: stool edge, floor, railing, stone step, bed platform, chair back.

## Hands
Hands fail when they are decorative. Give each visible hand one job:
- grasp, press, support, pinch, smooth, lift, turn, tuck, shield, pull, hold, test, trace.
Keep fingers partially occluded when the action allows it; this often looks more photographic than presenting every finger to camera.

## Gaze
Use one of four gaze relationships:
- task gaze — eyes on what the hands are doing;
- reactive gaze — eyes toward an off-frame cause;
- social gaze — eyes toward another person;
- camera gaze — used deliberately, not by default.

## Micro-expression
Prefer muscle-level states over emotion labels:
- lips resting but not sealed,
- one eyebrow slightly raised,
- jaw unclenched,
- smile beginning in one corner,
- eyes narrowed against backlight,
- lower eyelids tense from concentration.

## Beautiful without mannequin syndrome
Allow asymmetry: one shoulder lower, hair escaping on one side, sleeve caught differently, weight uneven, expression not perfectly mirrored. Keep skin texture and local color variation unless the user asks for beauty-retouch aesthetics.


## Vitality coupling
When vitality is requested, do not stop at pose labels. Define a kinetic chain, breath state, shutter phase and motion residue. The face should not be the only animated layer. A useful test: if the mouth were neutralized, would the body, hands, gaze, hair/cloth and timing still feel alive? If not, the vitality design is incomplete.

Prefer recovery-phase evidence for candid life: shoulders settling, grip loosening, hair still moving, breath returning, gaze arriving a fraction before or after the head.
