# Quality Gates

Score each gate 0–2. A production prompt should reach 17/20 and contain no zero in gates 1–6. When vitality is requested, also pass the Vitality Gate below.

| Gate | Question |
|---|---|
| 1 Identity | Is the subject clearly defined and preserved where required? |
| 2 Action | Is there a specific shutter-moment event? |
| 3 Physics | Do body support, hands, garments and props obey contact/gravity? |
| 4 Cultural coherence | Do clothing, grooming and setting read as one intentional register? |
| 5 Composition | Is the camera location and visual hierarchy clear? |
| 6 Light causality | Does light come from a plausible source and affect materials consistently? |
| 7 Material truth | Do skin, hair, cloth and objects have distinct response? |
| 8 Human presence | Does the person feel occupied, reactive, asymmetric, alive? |
| 9 Restraint | Are symbols, props and adjectives controlled rather than stacked? |
| 10 Series fit | If part of a set, does it add new information while preserving the bible? |

## Zero-fail examples
- hand intersects prop with no grip,
- feet float or body lacks support,
- jewelry has no attachment point,
- lighting named from several incompatible directions,
- garment description mixes incompatible structures without intentional hybrid design,
- reference roles conflict,
- every shot in a set repeats the same half-body front portrait.

## Final trim
Delete any phrase that:
- repeats an earlier constraint,
- describes prestige rather than visible evidence,
- adds a new style family late in the prompt,
- conflicts with camera, light or material instructions.


## Vitality Gate
Score 0–2 for each item; vitality work should reach 10/12 with no zero in items 1–4.

| Item | Question |
|---|---|
| 1 Timing | Is a shutter phase clear rather than a frozen pose? |
| 2 Kinetic chain | Does force travel from support through torso to active limb/head? |
| 3 Breath/attention | Is there physiological or attentional life beyond a smile? |
| 4 Motion residue | Do hair, cloth, prop or environment respond to the same event? |
| 5 Energy contrast | Is some part of the frame quiet enough for energy to read? |
| 6 Series rhythm | If a set, are peak/recovery/afterglow states varied? |

Automatic fail: “元气” is represented only by smiling, bright colors, or a generic jumping pose.
