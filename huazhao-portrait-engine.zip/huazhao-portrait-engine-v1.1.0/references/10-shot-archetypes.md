# Shot Archetypes

Use these as structural seeds, not templates to copy verbatim.

## Window interruption
Subject was doing a small task; off-frame sound causes a partial turn. Window edge or curtain creates depth; side light reveals flyaway hair and sleeve texture.

## Hands-before-face
Hands and an object occupy the near plane; face sits slightly farther back. Good for tea, ink, flowers, jewelry, ribbon, book pages, medicine, weaving.

## Weather arrival
Rain, wind or snow changes body behavior: shoulder lifts, sleeve shields, hair sticks or lifts, prop becomes functional.

## Walking recovery
Capture the half-second after a step rather than a perfect walking pose. Hem and hair lag behind body movement.

## Quiet labor
Repair, sort, wipe, fold, string, grind, write, trim, bind. Task determines posture and gives hands credibility.

## Threshold portrait
Door, moon gate, curtain, corridor corner or boat opening divides space. Subject is crossing, pausing, or listening.

## Back-view reveal
Use garment silhouette and environment first; face only partial or absent. Valuable as a reset frame in a series.

## Material close-up
Face is secondary to tactile interaction: fingertips on brocade, wet paper, lacquer box, metal hairpin, wood grain, embroidered cuff.

## Reflection
Mirror, water, polished metal or glass creates a second face plane. Keep reflection geometry plausible and do not duplicate impossible body parts.

## Group asymmetry
For two adults, give separate tasks and gaze targets. Avoid synchronized twin posing unless ceremonial symmetry is deliberate.
