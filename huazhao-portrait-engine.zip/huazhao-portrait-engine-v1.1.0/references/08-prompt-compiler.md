# Prompt Compiler

## Master grammar
Compile in this order:

1. **Format/medium** — only what affects image behavior.
2. **Subject identity** — age register, appearance essentials, grooming.
3. **Cultural/wardrobe construction** — silhouette, layers, fabric, key accessory.
4. **Event** — exact shutter moment.
5. **Body physics** — support, torso/head direction, hands, gaze.
6. **Vitality State when requested** — energy level, shutter phase, kinetic chain, breath, expression stack, motion residue, energy contrast.
7. **Camera** — distance, height, optical character, framing.
8. **Spatial layers** — foreground / subject / background.
9. **Light causality** — source, direction, softness, falloff, interaction.
10. **Material truth** — skin, hair, cloth, prop response.
11. **Atmosphere/color** — restrained relationship.
12. **Negative guardrails** — only risks relevant to the requested shot.

## Compact prompt template

`[medium + frame]. [adult subject + defining appearance] in [coherent wardrobe]. At the shutter moment, [event]. [support/weight], [hands], [gaze/micro-expression]. [when relevant: energy level + shutter phase + breath + motion residue + energy contrast]. Camera: [distance + height + optical behavior + framing]. [foreground], [subject plane], [background]. Light: [source/path/effect]. Materials: [skin/hair/fabric/prop]. Color/atmosphere: [relationship]. Avoid: [shot-specific failure risks].`

## Prompt density
Target 140–320 English words or equivalent information density in Chinese for a single complex frame. Go shorter when the image model responds poorly to long prompts. A prompt should contain no duplicated adjectives that do not add a new control variable.

## Positive language over prohibition
Describe the desired hand task, garment construction and camera geometry positively. Use negative prompts for common rendering failures, not for primary design.

## Randomization
Randomize only within declared slots:
- expression intensity,
- hand task variant,
- foreground object,
- shot distance,
- time-of-day substate,
- minor accessory.
Never randomize identity, era register, core garment construction, or scene geography in the middle of a locked series.


## Vitality density rule
Do not append a long synonym chain such as “energetic, lively, cheerful, vibrant, dynamic”. Replace it with visible evidence: one shutter phase, one kinetic chain, one breath cue, one expression cue, one motion residue cue, and one calm contrast field.
