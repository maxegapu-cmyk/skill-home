# Camera & Composition Engine

## Choose distance for meaning
- Extreme close: texture, breath, jewelry, fingers, eye line.
- Close portrait: expression and face-hair-light relationship.
- Medium: hands + torso + prop interaction.
- Three-quarter: garment silhouette + gesture + environment clues.
- Full body: body geometry, costume volume, ground contact.
- Environmental portrait: subject becomes part of architecture/weather/story.

## Camera height
- Eye level: intimacy and neutrality.
- Slightly below chest/waist: stature, garment volume, power.
- Slightly above eye: delicacy, introspection, table/hand visibility.
- High oblique: spatial pattern, floor objects, group geometry.

Avoid unexplained extreme angles; they distort body and costume faster than they add style.

## Lens character, not fake metadata
Describe optical behavior instead of random camera brands:
- intimate normal perspective,
- compressed long-lens layers,
- close wide-angle with mild edge stretch,
- shallow focus with soft foreground occlusion,
- deeper focus for architectural portrait.

## Three-plane construction
Build at least two of these:
- foreground: leaves, gauze, door frame, candle smoke, hanging beads, umbrella edge;
- subject plane: face, hands, garment;
- background: window, wall, pond, shelving, corridor, foliage.

Foreground occlusion should frame or reveal, never randomly cover eyes/hands.

## Visual hierarchy
Specify three landing points:
1. face/gesture,
2. hand/prop or garment structure,
3. environmental motif.
Lighting, contrast and focus should reinforce the same order.

## Composition repair
If a frame feels “AI staged,” reduce centered symmetry, remove one prop, create an off-frame cause, crop through an unimportant edge, and allow partial occlusion.


## Vitality camera rule
Camera movement is not required for an energetic image. First choose the shutter phase, then place the camera where force transfer and reaction are readable. Medium/three-quarter frames are the default for kinetic readability; full body when footwork/contact matters; close frames for breath and expression recovery. Keep at least one calm negative-space region as energy contrast.
