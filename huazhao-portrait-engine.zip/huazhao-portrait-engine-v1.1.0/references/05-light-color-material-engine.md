# Light, Color & Material Engine

## Light must have a source
Name the source and path:
- cold window daylight from camera-left, softened by paper screen;
- warm late sun skimming from behind, reflected by pale wall;
- lantern pool from below-right, weak ambient night fill;
- overcast courtyard skylight with dark wooden bounce;
- hard noon shaft broken by lattice, moving across sleeve and cheek.

Then state what it hits first and what falls into shadow.

## Skin
Photographic skin includes:
- local hue variation,
- pores or fine texture at appropriate distance,
- subtle under-eye structure,
- edge translucency at ears/fingers in backlight,
- nonuniform specular response.
Avoid wax, porcelain, blur-painted cheeks and universal “flawless skin.”

## Fabric families
- cotton/linen: broad soft folds, matte, visible weave near camera;
- silk satin: directional sheen, bright fold ridges, darker valleys;
- gauze: low mass, translucent overlap, visible edge and seam;
- brocade: heavier drape, structured folds, motif follows curvature;
- leather: creases near stress points, localized gloss;
- metal ornament: small hard highlights tied to light direction.

## Palette
Use relationships, not color lists:
- one dominant family,
- one supporting neutral,
- one controlled accent.
Keep skin separated from garment/background in luminance or temperature.

## Atmospheric texture
Choose at most two: humid air, pollen, rain mist, incense smoke, dust motes, film grain, window flare, fine drizzle, snow grains. Atmosphere should interact with light rather than simply sit on top of the image.


## Vitality light/color
For bright energetic work, protect highlight shape rather than simply raising exposure. Use one clean directional source, readable skin highlights, moving hair/fabric edge response, and a quieter background. Keep deep neutrals or subdued secondary colors so the active subject has luminance contrast. Candy saturation is not a substitute for vitality.
