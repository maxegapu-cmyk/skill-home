# Guofeng World Bible

This module covers Chinese-style portrait logic without forcing every image into museum reconstruction.

## Four cultural registers

### 1. Historically anchored
Use when the user names a dynasty, garment system, archaeological reference, or asks for accuracy. Keep silhouette, collar/closure logic, sleeve proportion, layer order, hair arrangement, jewelry scale, and material plausibility coherent. Decoration is subordinate to construction.

### 2. Modern guofeng editorial
Traditional cues may coexist with modern tailoring, studio lighting, fashion makeup, or contemporary composition. The image should look intentionally hybrid, not accidentally anachronistic.

### 3. Fantasy classical
Architecture, garments and ornaments may be invented, but they need one internal design language: repeated shapes, material family, color logic and social status cues.

### 4. Everyday classical life
Prioritize tasks and lived-in objects: tying a cord, mending bamboo, grinding ink, drying herbs, arranging flowers, opening shutters, carrying books, washing a cup, folding cloth. Small labor gives the body believable purpose.

## Anti-costume rules
- Avoid stacking every “Chinese” symbol in one frame.
- Do not mix incompatible closure systems, armor logic, crown types, sleeve behavior and footwear just for richness.
- Jewelry must attach to hair or clothing in a physically readable way.
- Long sleeves need weight, friction and collision with hands/props.
- Translucent fabric still has seams, folds and edge thickness.
- Embroidery follows the cloth surface; it does not float independently.

## Prop discipline
One strong prop beats five symbolic props. A prop should either:
1. cause the action,
2. reveal identity/status,
3. organize composition,
4. carry light/material interest.

If it serves none, remove it.

## Scene families
Use specific spaces rather than generic “ancient China”: lattice-window study, rain-darkened corridor, garden wall and bamboo shadow, stone landing by a pond, dyeing courtyard, apothecary shelves, lantern-lit side room, temple-side market lane, waterside pavilion, winter courtyard, boat cabin, archive room, loom room, mountain relay inn.
