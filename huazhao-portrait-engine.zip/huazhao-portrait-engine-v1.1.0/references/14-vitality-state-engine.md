# Vitality State Engine

## Purpose
Use this overlay when the brief asks for 元气、鲜活、灵动、阳光、青春感、运动感、生命力、轻快、活泼, or when a portrait looks technically correct but emotionally inert.

**Vitality is a body-state problem, not a smile keyword.** It must appear simultaneously in timing, support, breath, attention, cloth/hair response, camera timing, and light/color hierarchy.

## Vitality State
Before prompt compilation, define a compact **Vitality State**:

- **energy level**: quiet glow / fresh / lively / burst / peak;
- **shutter phase**: anticipation / action / peak / recovery phase / afterglow;
- **kinetic chain**: support → pelvis → ribcage → shoulder → hand/head;
- **breath**: held / exhale / just caught breath / relaxed recovery;
- **attention**: task / off-frame trigger / social / camera;
- **expression stack**: eyes + mouth + brow/jaw, with no more than two strong channels;
- **motion residue**: hair lag, sleeve lag, skirt swing, dust/water movement, prop rebound;
- **energy contrast**: what stays calm so the energetic element can read clearly.

Do not max all fields. A frame feels alive when one or two channels lead and the rest support them.

## Five energy modes

### Quiet glow
Alive without large motion. Use breathing, alert eyes, fingers mid-task, slight torso rotation, small environmental response. Best for seated portraits, reading, tea, waiting, close portraits.

### Fresh
Light body state, open posture, quick gaze shift, recently completed small action, soft rebound in hair/sleeve. Best default for “元气”.

### Lively
Clear weight transfer, torso counter-rotation, hands engaged, expression changing rather than held. Best for walking, turning, arranging clothes, interacting with water/plants/props.

### Burst
One obvious action impulse: leap, run, spin, throw, strike, pull, chase, dodge. Preserve anatomy and support; use one strong motion event, not five.

### Peak
Rare signature frame. Strongest gesture + strongest camera timing + strongest environmental response. Use once in a series, not as the default for every frame.

## Shutter timing
Static posing usually fails because it has no temporal phase. Pick one:

1. **Anticipation** — body loads before action; weight gathers; gaze leads.
2. **Action** — force travels through the kinetic chain.
3. **Peak** — maximum extension; hardest to keep natural.
4. **Recovery phase** — shoulders/pelvis settle, hair and fabric continue moving, breath returns. Often the most photographic phase.
5. **Afterglow** — action ended but attention, breath and material state still carry evidence.

For natural vitality, prefer anticipation, recovery phase, and afterglow more often than peak action.

## Kinetic chain
A believable energetic pose must transmit force:

**ground/contact → support leg or seat → pelvis → ribcage → shoulder line → active hand or head → hair/garment/prop**

Useful cues:
- support and free side should not carry equal weight unless intentionally braced;
- pelvis and ribcage may counter-rotate instead of facing exactly the same direction;
- head often leads or trails the torso during turns;
- the active hand receives force from the shoulder, not from an isolated wrist pose;
- hair and loose fabric trail the body by a fraction of a beat;
- after impact or a quick stop, cloth and hair can still move while the body begins to settle.

## Breath and physiological life
Use subtle physiological evidence appropriate to the scene:
- just-caught breath after movement;
- lips parted slightly on exhale;
- chest/ribcage settling;
- eyes narrowed in hard sun;
- warm skin at cheeks after exertion;
- damp flyaway hair only when heat, rain or movement justifies it;
- hand grip loosening after effort.

Do not turn every energetic portrait into sweat-heavy sports imagery.

## Expression stack
Avoid the “big smile solves vitality” trap.

Build expression from components:
- **eyes**: bright attention, squint against sun, rapid off-frame shift, social connection;
- **mouth**: half-smile, laugh beginning, laugh fading, lips parted from breath, relaxed mouth;
- **brow/jaw**: slight lift, concentration, released jaw.

Rule: one dominant expression cue + one supporting cue. Keep the rest relaxed. This produces more photographic micro-expression than “huge cheerful smile”.

## Energy without smiling
A person can feel energetic while serious or quiet. Use:
- forward attention;
- active hands;
- torso ready to move;
- quick gaze shift;
- fresh breath state;
- moving hair/sleeve;
- bright directional light;
- environmental interaction.

## Seated vitality
Do not force jumps or standing poses. For seated frames, create life through:
- one foot or knee changing support;
- torso leaning in/out of task;
- shoulder rebound after reaching;
- hand passing an object, tying hair, opening paper, lifting cup;
- gaze moving before the head fully follows;
- sleeve/hair settling after a small action.

## Environmental coupling
Energy becomes believable when the world responds:
- wind changes hair and only the free fabric edges;
- sunlight causes squint, lifted chin, shade-seeking hand, sharper shadow geometry;
- water splashes or ripples from the actual interaction point;
- dust/pollen moves near feet or garment path, not everywhere;
- rain affects grip, surface sheen, hair and garment weight;
- props have inertia and contact.

The environment must react to the same event as the person.

## Camera timing for vitality
Use camera choices that support the state:
- medium/three-quarter frames for hand + torso + action;
- full body when ground contact and garment movement matter;
- close frames for breath, eyes, flyaway hair and laughter recovery;
- eye level or slightly low for forward energy;
- slight high angle for playful hand/object interactions;
- normal to mildly wide perspective when movement toward/around camera matters;
- compressed long-lens layers when energy comes from a captured candid moment rather than spatial distortion.

Do not add extreme tilt, ultra-wide distortion, or random Dutch angles just to signal “dynamic”.

## Light and color energy
Vitality should read through luminance and temperature, not candy saturation.

Preferred strategies:
- one clean directional source with readable skin response;
- bright edge or side light on moving hair/fabric;
- controlled highlight on cheeks, nose bridge, shoulders and cloth ridges;
- background one step quieter than the subject;
- one warm/cool relationship instead of many bright colors;
- preserve deep neutrals so bright areas feel truly bright.

**Energy contrast** is mandatory: at least one calm visual field must exist so the active gesture can dominate.

## Motion residue
Motion residue is evidence that something just happened:
- sleeve still swinging after a turn;
- hair crossing cheek after stopping;
- skirt hem displaced from the body path;
- ribbon trailing behind hand movement;
- tea/water surface still moving;
- prop rebounding or settling;
- breath and expression changing after effort.

Describe residue after the body action so cause precedes effect.

## Multi-person vitality
Do not synchronize everyone.

Assign roles:
- initiator — causes the event;
- reactor — responds a beat later;
- anchor — calmer body that stabilizes the composition.

Give each person a different gaze target, hand task, and phase of the shared event. Shared cause, asynchronous response.

## Series energy arc
For 6–12 frames, design an **energy arc** rather than keeping every image equally excited.

Recommended 9-shot rhythm:
1. quiet entry;
2. fresh task;
3. social/reactive cue;
4. rising movement;
5. peak frame;
6. recovery frame;
7. intimate close detail;
8. second lighter lift;
9. afterglow/signature.

Keep the peak frame scarce. If every frame is peak energy, none reads as explosive.

## Anti-cheap-sugar rules
A frame becomes cheap when it stacks bright palette + huge grin + blown highlights + centered pose + decorative background + aggressive blur.

Repair by:
- reducing one expression channel;
- keeping skin highlights below clipping;
- muting one third of the palette;
- adding a concrete task or off-frame cause;
- letting body and environment carry part of the energy;
- preserving one quiet negative-space region;
- allowing imperfect hair/folds instead of beauty-ad perfection.

## Vitality prompt block
Insert after the event/action and before camera:

`Vitality State: [energy level], captured in [shutter phase]. Force travels from [support] through [kinetic chain]. [breath cue]. [expression stack]. [motion residue]. Keep [calm field] restrained as energy contrast.`

Do not include the literal labels if the target model responds better to natural prose; preserve the information structure.

## Vitality repair matrix

| Failure | Cause | Repair |
|---|---|---|
| smiling but stiff | face carries energy, body does not | rebuild kinetic chain, hands, breath and camera timing |
| large movement but staged | only peak pose described | switch to anticipation/recovery phase; add center-of-mass transfer and residue |
| energetic but childish/cartoonish | expression and color over-amplified | reduce grin/saturation; use body timing and light hierarchy |
| seated frame feels dead | no small action | add support shift, hand task, gaze shift, settling fabric |
| wind feels fake | hair/cloth move without stance response | add wind direction, body compensation and phase lag |
| every series frame screams | no energy arc | reserve peak, add quiet/recovery/afterglow beats |
| group looks choreographed | synchronized phase/gaze | assign initiator/reactor/anchor roles |
| bright image feels flat | no energy contrast | quiet background/palette and preserve deep neutrals |
