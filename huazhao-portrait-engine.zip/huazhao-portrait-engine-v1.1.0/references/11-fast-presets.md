# Fast Presets

These presets define decision biases, not fixed wording.

| Preset | Camera bias | Light bias | Human behavior | Texture |
|---|---|---|---|---|
| 清晨闺阁 | medium/close | soft window side light | grooming, tying, folding | cotton, wood, mirror |
| 雨巷 | three-quarter | overcast + reflected wet ground | walking, shielding, listening | wet stone, silk, umbrella |
| 荷塘 | environmental/medium | dawn or late side light | repair, gather, write, watch water | bamboo, linen, mist |
| 书斋 | medium/detail | window/lamp mixed carefully | ink, paper, book handling | paper, wood, ink sheen |
| 山寺 | environmental | cool ambient + warm localized | pause, carry, sweep, light incense | stone, smoke, coarse cloth |
| 宫廷克制 | medium/full | directional controlled soft light | stillness with task/status cue | brocade, metal, lacquer |
| 武侠旅途 | full/three-quarter | hard weathered daylight | walk, mount, rest, tighten gear | dust, leather, worn cloth |
| 商业国风 | close/medium | clean shaped studio light | confident direct gaze or precise gesture | polished fabric, clean skin |
| 先锋国风 | angle/occlusion | graphic hard or colored motivated light | unusual but physically valid gesture | mixed matte/gloss |
| 日常烟火 | medium/environmental | courtyard daylight | cooking, washing, hanging, sorting | steam, pottery, rough wood |
| 冬日庭院 | medium/full | cold skylight + warm reflected interior | warming hands, carrying cloth, brushing snow | wool, snow, breath |
| 夜灯 | close/medium | one practical warm source + weak ambient | reading, waiting, fastening jewelry | oil glow, dark wood, silk edges |


## Vitality presets

| Preset | Energy | Shutter phase | Body cue | Light/color cue |
|---|---|---|---|---|
| 清晨元气 | fresh | recovery phase | quick turn, shoulders settling, active hand | clean side/back light, cool neutral background |
| 阳光爆发 | burst | anticipation/action | loaded support leg, torso counter-rotation | hard sun with controlled highlights and strong shadow shape |
| 安静有生命力 | quiet glow | afterglow | small support shift, hand task, alert gaze | soft directional light, restrained palette |
| 风中灵动 | lively | recovery phase | stance compensation, head/torso phase offset | edge light on lagging hair/fabric |
| 双人轻快 | lively | mixed phases | initiator/reactor roles, separate gaze | one shared light source, asymmetric spacing |
| 组图能量曲线 | varied | full arc | rising action → peak → recovery | stable palette, changing tempo not random style |
