# Identity & Reference Control

## Separation principle
Identity, composition and style are different signals. Treat them as separate channels even if the generation tool exposes only one image-reference input.

## Identity lock
Preserve what makes the person recognizable:
- facial proportions,
- age register,
- key feature spacing,
- characteristic eye/nose/mouth relationships,
- stable facial volume.

Do not over-lock transient details such as one expression, one camera angle, or one hairstyle unless requested.

## Reference pressure
High reference pressure improves similarity but can reduce editability. Low pressure increases freedom but may drift. Therefore choose the minimum pressure that holds the required invariant.

Conceptual starting points:
- strict identity portrait: high identity pressure, medium style pressure;
- fashion/editorial transformation: medium-high identity, medium style;
- inspired-by style only: zero identity pressure, medium-high style;
- pose transfer: low identity from pose image, high structural pressure from pose.

Do not convert these concepts into fake universal numeric values; actual scales differ by model/tool.

## Multi-image identity
If several images of the same person are available, prefer diversity of view and expression rather than near-duplicate selfies. More references help only if they add stable identity information instead of contradictory retouching, lenses or ages.

## Crop awareness
A face-only reference is weak evidence for full-body proportions, garment and pose. A full-body reference is weak evidence for fine facial features. Match reference crop to the feature you expect it to control.

## Repair strategy
Identity drift in an otherwise good frame: repair face/identity region or rerun the identity-conditioning layer. Do not destroy successful composition, lighting and garment geometry unless the tool makes local repair impossible.
