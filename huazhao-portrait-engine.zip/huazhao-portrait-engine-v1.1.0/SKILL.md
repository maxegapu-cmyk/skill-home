---
name: huazhao-portrait-engine
description: Use when creating, directing, repairing, or expanding Chinese-style portrait photography, hanfu portraits, guofeng fashion portraits, classical beauty images, editorial portrait sets, or image-generation prompts where subject presence, costume logic, composition, lighting, reference control, realism, and series consistency must be handled together.
---

# 华照写真系统 · Vitality 1.1

## Core idea
Treat portrait generation as a directed photographic production, not a bag of aesthetic keywords. Build the image from five independent controls: **subject truth, action truth, spatial truth, light/material truth, vitality truth, and series truth**. A beautiful face is never allowed to compensate for broken body mechanics, fake clothing, arbitrary light, or repetitive posing.

## Operating modes
Route first. Do not use one workflow for every request.

| Mode | Trigger | Primary objective |
|---|---|---|
| A Text portrait | Only a written brief | invent a complete shoot |
| B Subject reference | user supplies a person | preserve identity while changing world/style |
| C Style reference | user supplies look/mood | extract visual rules, not literal content |
| D Costume/object reference | garment, prop, jewelry, makeup | preserve object structure/material |
| E Multi-reference | several refs with different jobs | assign one authority per visual dimension |
| F Series | 4+ images or a photo story | lock a visual bible, vary events and framing |
| G Repair | user shows a failed result | diagnose the dominant failure before rewriting |

## Required execution sequence
1. Read the brief and declare the mode internally.
2. Build a **Portrait Charter**: subject, era/cultural register, emotional temperature, event, location, visual hierarchy, forbidden drift. If the brief asks for 元气/鲜活/灵动/阳光/生命力, also build a **Vitality State** using `references/14-vitality-state-engine.md`.
3. Separate references by authority: identity / pose / costume / environment / color / texture. Never let one reference silently control everything.
4. Direct the human first: intention → action → weight distribution → hands → gaze → micro-expression.
5. When vitality is requested, direct timing before framing: energy level → shutter phase → kinetic chain → breath → expression stack → motion residue → energy contrast.
6. Direct the frame second: camera height → distance → lens character → foreground/midground/background → negative space.
7. Direct light and matter: light source and path → skin response → hair edges → fabric response → reflective objects → atmosphere.
8. Compile the final prompt using `references/08-prompt-compiler.md`.
9. Run the quality gates in `references/09-quality-gates.md`.
10. For a set, run the diversity matrix in `references/07-series-director.md` before producing the next frame.
11. If a result fails, repair only the failed layer using `references/12-failure-repair-matrix.md`.

## Output contract
For ordinary requests, return:
- **Creative verdict**: one sentence describing what the image/set is really about.
- **Final prompt**: production-ready, concrete, ordered by causal importance.
- **Hard anchors**: 4–8 details that must not drift.
- **Variation slots**: 3–6 details safe to randomize.
- **Negative/avoid list**: only failure risks relevant to this shot.
- **For vitality work**: energy level + shutter phase + kinetic cue, expressed compactly.
- **For series work**: a shot table showing what changes and what stays fixed.

Do not dump every available parameter. More prompt tokens are not automatically more control; conflicting or redundant constraints weaken the image.

## Non-negotiables
- The person must be doing something, reacting to something, or waiting for something specific.
- “元气” must be carried by body timing, breath, attention, environmental response and camera timing; a large smile alone never qualifies.
- Hands need tasks; eyes need targets; clothing needs gravity and contact.
- Cultural styling must be coherent enough to feel intentional. If strict historical accuracy is requested, prioritize documented silhouette and material logic over fantasy decoration.
- Beauty comes from hierarchy and timing, not universal skin smoothing or excessive ornament.
- Preserve small irregularities that support photographic truth: flyaway hair, asymmetric folds, uneven skin tone, partial occlusion, imperfect gesture.
- Repair by layer. Do not rewrite the whole image when only hands, costume, light, or identity failed.

## References
Read only the files relevant to the routed mode. Start with `references/00-system-kernel.md` and then load the specialist modules you need.
