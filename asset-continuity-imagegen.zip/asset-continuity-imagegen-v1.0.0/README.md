# Asset Continuity ImageGen

A reusable image-generation skill for continuity-sensitive visual work: recurring characters, clothing, props, products, weapons, vehicles, creatures, architecture, rooms, and locations.

## Install as a skill

Copy `skills/asset-continuity-imagegen/` into a supported skills directory.

For Codex repo-local use, a typical location is:

`.agents/skills/asset-continuity-imagegen/`

## Install as a plugin

Use the package root containing `plugin.json` with a compatible plugin installer or local plugin market.

## Typical requests

- Keep this character identical across ten new shots while changing pose and camera.
- Extract this product from a busy photo and create a reusable neutral asset view.
- Put the same vehicle in a night scene without changing its body design or markings.
- Repair only the costume drift in this image.
- Preserve this room layout while moving the camera to the opposite corner.
- Keep the same character, prop, and environment continuity across a storyboard sequence.

## Design goals

- identity and topology before style
- canonical references before generated descendants
- small evidence sets instead of indiscriminate reference piles
- targeted repair instead of full regeneration
- compact prompts backed by a persistent asset registry
