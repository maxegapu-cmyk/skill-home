---
name: asset-continuity-imagegen
description: Generate or edit raster images when recurring characters, props, products, costumes, weapons, vehicles, architecture, rooms, locations, or other visual assets must stay recognizably consistent across images. Use for reference-driven generation, multi-shot continuity, asset extraction/reconstruction, controlled variations, drift repair, or scenes containing multiple recurring assets. Prefer the built-in image generation/editing tool when available. Do not use for purely vector/code-native graphics or when continuity is irrelevant.
---

# Asset Continuity Image Generation

Use this skill when the visual task is not merely "make an image" but "keep the same things the same while changing only what the user asked to change."

## Operating principle

Treat every recurring visual subject as an asset with evidence, identity, and permitted variation.

For each asset, separate three classes of attributes:

1. **Immutable anchors** — identity-defining features that must not drift unless the user explicitly changes them.
2. **Controlled variables** — attributes that may change only when requested or when required by the shot.
3. **Free variables** — details that can vary without changing asset identity.

Never use vague instructions such as "keep it consistent" as the only continuity control. Convert the user's references and requirements into concrete anchors before generation or editing.

## Tool path

- Use the available built-in image generation/editing tool for normal image work.
- If the host does not expose an image tool, return the compiled production prompt and continuity spec instead of pretending an image was generated.
- Do not invent unsupported tool arguments.
- Do not overwrite existing project assets unless the user clearly requests replacement.

## Workflow

### 1. Identify the task mode

Choose one primary mode:

- **Bootstrap** — establish a reusable asset identity from one or more references.
- **Generate** — create a new image containing one or more established assets.
- **Edit** — modify an existing image while preserving protected content.
- **Extract/Reconstruct** — isolate or rebuild an asset from a complex source image.
- **Repair** — correct identity, topology, proportion, material, costume, or scene-layout drift.
- **Variant** — produce controlled alternatives while preserving identity.

If several modes apply, perform them in that order: bootstrap/extract first, then generate/edit, then repair.

### 2. Assign evidence roles to references

A reference image may provide one or more evidence roles:

- identity evidence
- shape/proportion evidence
- material/surface evidence
- costume or accessory evidence
- color/marking evidence
- environment/layout evidence
- style/medium evidence
- composition/camera evidence
- lighting evidence

Do not let a style reference silently redefine an asset's identity. Do not let a composition reference silently replace costume, markings, proportions, or scene topology.

When references conflict, prefer the reference the user explicitly identifies as canonical. If none is named, prefer the clearest direct evidence for the disputed attribute and state the assumption only when it materially affects the result.

### 3. Build or refresh the Asset Registry

Before continuity-sensitive work, create a compact internal registry using the schema in `references/registry-schema.md`.

Assign stable IDs such as:

- `CHAR_01`
- `COSTUME_01A`
- `PROP_03`
- `WEAPON_02`
- `VEHICLE_01`
- `ENV_04`

For every asset, record only observable or user-specified facts. Never invent hidden details and then treat them as canon.

For recurring work, save a project-local registry when the environment allows it. Update it only when the user approves or explicitly requests a canonical change.

### 4. Lock identity at the right level

Read `references/anchor-model.md` and apply the relevant asset type.

Priority order when resolving conflicts:

1. identity / topology
2. global proportions
3. distinctive local geometry
4. fixed markings and attachment points
5. material and color placement
6. costume/accessory state
7. scene spatial relationships
8. pose, expression, lighting, weather, and styling

A lower-priority request must not accidentally destroy a higher-priority anchor.

### 5. Compile a shot contract

Before calling the image tool, reduce the task to a short shot contract:

- **Assets present:** stable asset IDs
- **Protected anchors:** only the anchors at risk in this shot
- **Requested change:** what must change
- **Permitted variation:** what may naturally vary
- **Camera/composition:** framing, lens feel, viewpoint, subject scale, spatial relationship
- **Environment:** location and spatial anchors
- **Style/medium:** only if requested
- **Hard exclusions:** likely drift modes for this shot

Use the prompt patterns in `references/prompt-patterns.md`. Keep the production prompt compact. A long prompt is not automatically a stronger prompt.

### 6. Reference discipline

Use the smallest useful evidence set.

- Prefer canonical references over previous generated outputs.
- Previous outputs may be used as shot/composition evidence, but should not become the sole identity source when canonical references exist.
- For a difficult angle, select references that expose the geometry relevant to that angle.
- For obscured assets, preserve known anchors and avoid fabricating unseen structure as certainty.
- For multi-asset scenes, name each asset separately and describe their spatial relationship explicitly.

This rule prevents generational drift from accumulating across a sequence.

### 7. Generation and editing rules

For **new generation**:
- state asset IDs and the few identity anchors that matter for the requested viewpoint;
- describe the requested scene/action separately from identity;
- keep style instructions from overwriting asset geometry.

For **editing**:
- identify the exact change region or attribute;
- state what must remain unchanged;
- protect silhouette, proportions, edges, markings, and material boundaries when they are not being edited;
- if the requested edit inherently requires geometry changes, explicitly narrow those changes.

For **asset extraction/reconstruction**:
- isolate the target from unrelated people/objects/background elements;
- preserve its distinctive geometry and markings;
- reconstruct only occluded portions that are necessary, and mark them as inferred rather than observed in any saved registry;
- use neutral presentation when the user wants a reusable asset plate.

### 8. Multi-shot continuity

For a sequence, separate **continuity state** from **shot state**.

Continuity state includes asset identity, canonical costume/attachments, persistent damage, persistent dirt, environment topology, time-of-day continuity, and other facts that survive across shots.

Shot state includes pose, expression, camera, framing, temporary occlusion, motion, and local lighting response.

When moving to the next shot, carry forward only continuity state plus the new shot request. Do not blindly copy the entire previous prompt.

### 9. Drift diagnosis and repair

Before regenerating everything, classify the failure:

- identity drift
- facial/character geometry drift
- body proportion drift
- prop/product topology drift
- attachment/part-count drift
- costume drift
- marking/logo/color-placement drift
- material drift
- scale drift
- scene-layout drift
- style contamination
- lighting-induced false drift

Repair the smallest failing layer first. See `references/repair-playbook.md`.

### 10. Acceptance gate

A result is acceptable only when:

- immutable anchors remain intact;
- requested changes are present;
- unrequested canonical changes are absent;
- asset-to-asset scale and spatial relationships are plausible for the scene;
- style changes have not rewritten identity;
- no prior generated image has silently replaced the canonical source of truth.

If a hard anchor fails, treat the image as a repair candidate rather than "close enough."

## User interaction

Do not interrogate the user for details that can safely be inferred from clear references. Ask only when a missing fact would materially change asset identity or when two canonical sources directly conflict.

When the user wants rapid production, make reasonable low-risk defaults for camera, background, and free variables while protecting anchors.

## Output behavior

When images can be generated, generate/edit them and return the result.

When the user asks for a reusable prompt, return the compact shot contract plus the production prompt.

When a registry or reusable project asset is requested, write it in a stable structured form using the provided template.

## References

Load only what is needed:

- `references/registry-schema.md` — persistent asset registry structure
- `references/anchor-model.md` — anchor rules by asset type
- `references/prompt-patterns.md` — concise generation/edit prompt patterns
- `references/repair-playbook.md` — targeted drift repair
- `references/qa.md` — continuity checks and failure cases
