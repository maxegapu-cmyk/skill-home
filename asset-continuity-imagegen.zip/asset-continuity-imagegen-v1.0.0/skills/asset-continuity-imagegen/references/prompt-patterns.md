# Prompt Patterns

These are compact patterns, not mandatory wording.

## New shot with established assets

```text
Create a new image.
Assets: CHAR_01, PROP_02.
Preserve: [only the shot-relevant immutable anchors].
Scene/action: [new action and environment].
Camera: [viewpoint, framing, subject scale, lens feel].
Continuity state: [persistent costume/damage/weather/time facts].
Permitted variation: [pose, expression, natural folds, minor lighting response].
Do not change: [high-risk identity/topology/marking elements].
```

## Precise edit

```text
Edit the supplied image.
Change only: [target attribute/region].
Keep unchanged: [protected subject geometry, edges, markings, proportions, other assets, composition as relevant].
Match the new content to the existing perspective, lighting, depth, and material response.
Do not redesign unrelated parts.
```

## Asset extraction / neutral plate

```text
Reconstruct the target asset from the reference as a reusable neutral asset view.
Target: [asset ID / unambiguous description].
Preserve: [silhouette, proportions, part layout, markings, materials].
Exclude: unrelated people, props, background clutter, lighting effects that hide construction.
Presentation: neutral background, clear readable shape, complete framing.
If a hidden region must be reconstructed, keep it conservative and structurally compatible with visible evidence.
```

## Drift repair

```text
Repair the image without redesigning it.
Failure to correct: [single drift category].
Canonical evidence: [reference labels].
Restore: [specific anchors].
Keep unchanged: [all currently correct attributes].
Do not alter composition/style unless required for the repair.
```

## Multi-asset scene

```text
Create a scene containing the following distinct assets:
- CHAR_01: [shot-relevant anchors]
- VEHICLE_01: [shot-relevant anchors]
- ENV_02: [spatial anchors]
Relationship: [who/what is where, facing what, approximate relative scale].
Action: [event].
Camera: [viewpoint/framing].
Protect each asset independently; do not merge their materials, markings, silhouettes, or identities.
```
