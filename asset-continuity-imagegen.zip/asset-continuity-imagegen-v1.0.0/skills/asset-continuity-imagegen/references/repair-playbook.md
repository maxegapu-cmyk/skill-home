# Drift Repair Playbook

Repair the smallest failing layer first.

## Identity drift
Return to canonical identity references. Reduce style pressure. Protect head/body geometry before texture and mood.

## Proportion drift
State the relevant ratio or relationship in plain language. Use a view that exposes the proportion. Do not compensate by changing unrelated anatomy or parts.

## Topology / part-count drift
Name the exact missing, duplicated, fused, or displaced component. Preserve all correct components.

## Costume drift
Lock layer order, garment cut, closures, trim/motif placement, and recurring accessories. Allow pose-driven folds to vary.

## Marking / color-placement drift
Specify the marking's location relative to stable geometry, not merely "same marking." Separate color identity from lighting response.

## Material drift
Protect material category and surface behavior. Do not force identical pixel texture across different lighting.

## Scale drift
Reassert relative scale between assets and add a stable environmental size cue when useful.

## Scene-layout drift
Return to the environment's topology: doors, windows, stairs, landmarks, paths, major furniture. Camera can move; topology should not.

## Style contamination
Strip style instructions that imply new anatomy, new costume construction, or redesigned props. Reapply style after identity/topology is restored.

## Lighting-induced false drift
Before repairing identity, check whether the apparent change is caused by cast shadow, lens distortion, specular highlights, depth of field, or occlusion. Do not "repair" correct geometry into a new shape.
