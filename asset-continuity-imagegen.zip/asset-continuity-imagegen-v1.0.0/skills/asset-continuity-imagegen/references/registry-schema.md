# Asset Registry Schema

Use this schema as a compact source of truth. Keep entries factual and short.

```yaml
project: <project name>
registry_version: 1
assets:
  - id: CHAR_01
    type: character
    canonical_sources: [<reference labels or paths>]
    immutable_anchors:
      - <identity-defining observable fact>
    controlled_variables:
      - name: <attribute>
        current_state: <state>
        allowed_states: [<state A>, <state B>]
    free_variables:
      - <attribute allowed to vary>
    persistent_state:
      - <damage/dirt/accessory/state that carries across shots>
    inferred_details:
      - <detail reconstructed because the reference did not reveal it>
    notes: <only material caveats>
```

## Rules

- Canonical sources are evidence, not decoration.
- Keep immutable anchors small enough to be enforceable.
- Do not convert an inferred detail into an immutable anchor without user confirmation or new evidence.
- A later generated image is not automatically canonical.
- When the user intentionally redesigns an asset, create a new version or explicitly update the canonical state.
