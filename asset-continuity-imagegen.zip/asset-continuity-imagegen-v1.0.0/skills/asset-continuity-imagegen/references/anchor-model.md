# Anchor Model by Asset Type

## Character

Strong anchors may include:
- head and jaw proportions
- eye spacing and eye shape family
- nose bridge/tip structure
- mouth width and lip structure
- ear shape/placement when visible
- hairline, part, major silhouette, and length
- distinctive facial marks
- body height/build/proportion relationships
- recurring prosthetics, tattoos, scars, jewelry, or equipment

Do not freeze expression, pose, lens distortion, or temporary lighting into identity.

## Clothing / Costume

Strong anchors may include:
- garment category and layer order
- neckline/collar/sleeve/hem geometry
- panel and seam layout
- closure positions
- trim placement
- motif locations
- material family
- recurring wear/damage

Do not confuse folds caused by pose with construction geometry.

## Prop / Product

Strong anchors may include:
- silhouette
- width/height/depth ratios
- part count
- major cutouts and protrusions
- control/button/port layout
- label or marking positions
- material zones
- distinctive edge profiles

For branded products, preserve only marks the user is authorized to reproduce and actually requests.

## Weapon / Tool

Strong anchors may include:
- overall silhouette
- component order and attachment points
- barrel/blade/handle proportions
- magazine, guard, stock, optic, cable, or grip placement
- material zones and distinctive wear

Do not let cinematic styling redesign functional topology unless requested.

## Vehicle / Mecha

Strong anchors may include:
- wheel/track/leg count and placement
- cabin/body proportion
- panel break hierarchy
- lights, intakes, weapons, doors, windows, wings, or thrusters
- repeated asymmetries
- livery and marking placement

Perspective can distort apparent proportions; anchor the underlying structure, not a single-view pixel measurement.

## Architecture / Environment

Strong anchors may include:
- room or site topology
- door/window/stair positions
- major circulation paths
- fixed furniture or landmark positions
- wall/floor/ceiling material zones
- recurring signs, murals, fixtures, vegetation, or skyline elements
- persistent damage and weathering

Do not freeze camera perspective into the environment itself.

## Creature / Monster

Strong anchors may include:
- limb count and joint arrangement
- cranial silhouette
- torso-to-limb proportions
- horn/plate/tail/wing placement
- recurring skin/fur/scale pattern zones
- asymmetrical scars or mutations

Do not allow action poses to create or remove anatomy.
