# Continuity QA

## Hard-fail checks

Reject or repair if any unrequested change occurs to:
- character-defining geometry
- limb/part count
- product/prop topology
- fixed marking placement
- canonical costume construction
- recurring attachment points
- environment topology
- persistent damage/state that should carry across shots

## Soft checks

Inspect but do not automatically reject:
- small lighting-dependent color shifts
- natural fabric folds
- expression changes
- motion blur
- lens perspective effects
- partial occlusion
- hair strand-level variation that preserves the main hairstyle identity
- tiny texture randomness that preserves material identity

## Sequence regression set

When validating a reusable asset, test representative views rather than many near-duplicates:

1. clear frontal or primary view
2. 3/4 view
3. profile or strong angle
4. medium/full-body or full-object scale change
5. different lighting
6. partial occlusion
7. interaction with another recurring asset
8. environment change while identity stays fixed

The goal is to expose anchor failure, not to make every image look identical.

## Common false confidence

- A close-up can hide body proportion drift.
- Matching color can hide wrong topology.
- Matching style can hide a different face.
- Reusing the last generated image can look stable for 2–3 steps while drifting away from the original canonical reference.
- A text-heavy prompt can create more contradictions than control.
