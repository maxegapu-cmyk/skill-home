# Public upstream references

This package does not include third-party trainer code. It relies on public upstream projects and emits starter configs / instructions.

- OneTrainer: https://github.com/Nerogar/OneTrainer
- kohya_ss GUI: https://github.com/bmaltais/kohya_ss
- sd-scripts: https://github.com/kohya-ss/sd-scripts
- SimpleTuner: https://github.com/bghira/SimpleTuner
- AI Toolkit: https://github.com/ostris/ai-toolkit
- Hugging Face Diffusers LoRA / DreamBooth examples: https://github.com/huggingface/diffusers
- ControlNet: https://github.com/lllyasviel/ControlNet
- IP-Adapter: https://github.com/tencent-ailab/IP-Adapter
- ComfyUI ControlNet auxiliary preprocessors: https://github.com/comfyorg/comfyui-controlnet-aux
- JoyCaption: https://github.com/fpgaminer/joycaption
- DreamSim: https://github.com/ssundaram21/dreamsim

Research snapshot for this Skill: 2026-09-30. Always compare generated config fields with the upstream example from the exact version/commit installed locally.
