# Checkpoint Evaluation Rubric

Score each checkpoint 0–5 on every dimension. Do not average blindly: any hard-fail gate rejects the checkpoint.

## A. Style carryover — 0–5
Does the adapter carry brush/edge/color/surface/shape language to subjects not present in the training set?

## B. Prompt compliance — 0–5
Does changing subject, environment and framing actually change the image?

## C. Composition freedom — 0–5
Can the prompt or structure conditioner move the subject, change camera angle and alter spatial layout without the LoRA dragging the image back toward a memorized training composition?

## D. Artifact resistance — 0–5
No repeated signatures, frames, scan borders, accidental logos, gallery walls or one recurring irrelevant object.

## E. Strength stability — 0–5
The LoRA remains coherent at two useful strengths (for example ~0.6 and ~0.85) instead of only working at one brittle setting.

## F. Structure-channel compatibility — 0–5
When ControlNet/reference conditioning is enabled, the composition changes predictably while the visual language survives.

## Hard fail gates
Reject if any occurs repeatedly in the fixed matrix:
- obvious training-image copy / near-copy
- same face/object/layout appears across unrelated prompts
- prompt composition is ignored
- signatures/watermarks are reproduced
- only one LoRA strength is usable
- structure control destroys the style or the LoRA defeats the structure control

## Selection rule
Prefer the **earliest** checkpoint that clears all hard gates and scores well across A–F. A later checkpoint that looks more reference-like but loses composition freedom is overfit, not better.

## Optional automated metrics
Perceptual metrics such as DreamSim can be useful as a secondary signal, but never maximize similarity to a training image. Use automated similarity mainly for consistency checks and near-copy detection, not as the sole objective.
