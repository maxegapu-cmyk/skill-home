# Style + Composition LoRA Forge v1.0.0

这是一个“训练方法 + 自动化检查 + 多后端配置生成”的 Skill，目标是解决：

> 参考图来自同一个人/同一个时期的油画或视觉作品，普通提示词已经试很多轮，但笔触、色彩关系、造型习惯和构图总是还原不稳。

它的核心不是继续堆提示词，而是把任务拆成两条通道：

- **LoRA 学风格**：笔触、边缘、色彩、光影、表面质感、造型语言。
- **结构控制学构图**：用 ComfyUI 的 ControlNet / Reference / IP-Adapter 类条件去锁姿态、透视、边缘和画面布局。

## 为什么这样做

单个 Style LoRA 能学到“构图倾向”，但很难同时做到：

1. 像参考作者；
2. 随意换题材；
3. 还精确服从每次的新构图。

把构图硬塞进 Style LoRA，常见副作用就是：换个人物还在复读训练集那几个站位、画面重心、背景结构。

## 推荐工具链

### 最推荐：OneTrainer + ComfyUI
适合不想天天敲命令的人。OneTrainer 负责训练，ComfyUI 负责 LoRA + 构图控制。

### 进阶：SimpleTuner + ComfyUI
适合想做可复现训练、现代模型、多架构、租 GPU 的用户。

### 经典：kohya_ss / sd-scripts + ComfyUI
适合 SD1.5 / SDXL 和已有 kohya 工作流的人。

### FLUX 快速路线：AI Toolkit + ComfyUI
适合 FLUX 系 LoRA 训练。

## 30 秒上手

1. 把参考图放进一个目录。
2. 复制 `examples/project.example.json`，修改数据集路径、模型家族、触发词。
3. 先生成一张人工整理表（强烈推荐），把“题材组 / 构图组 / 时期 / 媒介 / 质量”补一下：

```bash
python scripts/forge.py curate --dataset D:/paintings --out outputs/curation.csv
```

4. 数据体检；填过整理表后把它一起喂进去，系统会检查单一题材和单一构图是否占比过高：

```bash
python scripts/forge.py audit --dataset D:/paintings --curation outputs/curation.csv --out outputs/audit.json
```

5. 自动划分 train / holdout，并确保完全重复图和近重复图不会跨集合泄漏：

```bash
python scripts/forge.py split --dataset D:/paintings --out outputs/split
```

6. 生成训练计划：

```bash
python scripts/forge.py plan --dataset D:/paintings --project examples/project.example.json --out outputs/plan.json
```

7. 选择训练器：

```bash
python scripts/forge.py emit --trainer simpletuner --project examples/project.example.json --plan outputs/plan.json --out outputs/simpletuner
```

8. 按生成目录里的 `CHECK_BEFORE_RUN.md` 对照你安装的训练器版本。
9. 训练时保留多个 checkpoint，不要一口气只保存终点。
10. 在 ComfyUI 里用固定 prompt / seed 做 checkpoint 对比，再接 ControlNet / reference conditioning 测构图。

## 数据集经验默认值

不是硬规则，但可以当第一版：

- 8 张以下：不建议开训，证据太少。
- 8–14 张：能做实验，但很容易记图。
- 15–30 张：可以做小型 style LoRA。
- 30–80 张：通常更适合稳定学习一个视觉语言。
- 80+：先确认是不是混入多个时期/媒介；更多不一定更纯。

比数量更重要的是**变化**：题材、人物、背景、视角、横竖构图都要有变化，否则 LoRA 会把“某几个内容/构图”误当成风格。

## Caption 原则

要让模型知道“哪些东西不是风格”。

例如训练图是一位坐着的女人：

```text
pntx9, a seated woman in a dark dress, interior room, three-quarter view, subject placed on the right third, eye-level viewpoint, soft side light
```

这里把人物、空间、构图说出来，但不需要把“厚涂、刮刀笔触、暖灰底、断裂边缘”每张都重复写一遍——这些正是希望 `pntx9` 去吸收的部分。

## 什么时候不要只靠 LoRA

如果用户说：

- “我要这个人还是在左下角，窗户一定在右上角”；
- “动作轮廓必须一致”；
- “透视和空间位置不能动”；

那就直接上结构控制。Style LoRA 负责“怎么画”，ControlNet / reference adapter 负责“画在哪、怎么摆”。

## 文件说明

- `SKILL.md`：完整执行协议
- `scripts/forge.py`：数据体检、计划生成、训练器适配
- `examples/project.example.json`：项目模板
- `prompts/caption_prompt.txt`：给 JoyCaption/视觉模型的 caption 提示
- `prompts/validation_prompts.json`：固定验证矩阵模板
- `references/EVAL_RUBRIC.md`：checkpoint 评分与过拟合门
- `references/BACKEND_MATRIX.md`：后端选择
- `references/SOURCES.md`：公开项目依据
- `comfyui/STRUCTURE_CHANNEL.md`：构图控制接法
- `tests/test_smoke.py`：本地冒烟测试

