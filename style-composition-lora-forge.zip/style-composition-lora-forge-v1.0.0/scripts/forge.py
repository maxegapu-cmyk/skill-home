#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
from collections import Counter, defaultdict

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}

try:
    from PIL import Image
except Exception:
    Image = None


def read_json(path: str | Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path: str | Path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def sha256_file(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dhash(path: Path):
    if Image is None:
        return None
    try:
        with Image.open(path) as im:
            im = im.convert("L").resize((9, 8))
            px = list(im.tobytes())
        bits = []
        for y in range(8):
            row = px[y * 9:(y + 1) * 9]
            for x in range(8):
                bits.append(1 if row[x] > row[x + 1] else 0)
        value = 0
        for b in bits:
            value = (value << 1) | b
        return f"{value:016x}"
    except Exception:
        return None


def color_signature(path: Path):
    """Compact 4x4 RGB signature used only as a second gate for near-duplicate detection."""
    if Image is None:
        return None
    try:
        with Image.open(path) as im:
            im = im.convert("RGB").resize((4, 4))
            return list(im.tobytes())
    except Exception:
        return None


def color_rms(a, b):
    if not a or not b or len(a) != len(b):
        return 999.0
    return math.sqrt(sum((int(x)-int(y))**2 for x,y in zip(a,b)) / len(a))


def near_duplicate(a, b, max_dhash_distance=5, max_color_rms=6.0):
    da, db = a.get("dhash"), b.get("dhash")
    if not da or not db:
        return False
    if hamming_hex(da, db) > max_dhash_distance:
        return False
    # dHash can collide badly on low-texture images; color is an independent second gate.
    return color_rms(a.get("color_signature"), b.get("color_signature")) <= max_color_rms

def hamming_hex(a: str, b: str):
    return (int(a, 16) ^ int(b, 16)).bit_count()


def ratio_bucket(w, h):
    if not w or not h:
        return "unknown"
    r = w / h
    if r < 0.75:
        return "portrait"
    if r > 1.33:
        return "landscape"
    return "near-square"


def write_curation_sheet(dataset: Path, out: Path):
    files = sorted([p for p in dataset.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS])
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["file", "include", "subject_group", "composition_group", "period", "medium", "quality_1_5", "notes"])
        for p in files:
            w.writerow([str(p.relative_to(dataset)), "yes", "", "", "", "", "", ""])
    return len(files)


def read_curation(path: Path):
    if not path or not path.exists():
        return None
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if not row.get("file"):
                continue
            rows.append(row)
    return rows


def curation_summary(rows):
    if not rows:
        return None
    included = [r for r in rows if str(r.get("include", "yes")).strip().lower() not in {"no", "0", "false", "exclude"}]
    n = max(1, len(included))
    def counts(key):
        return Counter(str(r.get(key, "")).strip() for r in included if str(r.get(key, "")).strip())
    subjects = counts("subject_group")
    comps = counts("composition_group")
    periods = counts("period")
    mediums = counts("medium")
    qualities = []
    for r in included:
        try:
            qualities.append(float(r.get("quality_1_5", "")))
        except Exception:
            pass
    warnings = []
    if subjects:
        k, v = subjects.most_common(1)[0]
        if v / n > 0.35:
            warnings.append(f"Subject group '{k}' occupies {v}/{len(included)} included images (>35%); subject leakage risk is high.")
    if comps:
        k, v = comps.most_common(1)[0]
        if v / n > 0.30:
            warnings.append(f"Composition group '{k}' occupies {v}/{len(included)} included images (>30%); layout entanglement risk is high unless intentional.")
    if len(periods) > 1:
        warnings.append("Multiple visual periods are labeled. Consider separate concepts/tokens or separate LoRAs if the periods differ materially.")
    if len(mediums) > 1:
        warnings.append("Multiple media are labeled. Mixing oil/watercolor/drawing/etc. can weaken a pure style target unless intentionally conditioned.")
    if qualities and sum(1 for q in qualities if q <= 2) / len(qualities) > 0.15:
        warnings.append("More than 15% of labeled images have quality <=2/5; exclude poor reproductions before training.")
    return {
        "rows": len(rows),
        "included": len(included),
        "subject_groups": dict(subjects),
        "composition_groups": dict(comps),
        "periods": dict(periods),
        "media": dict(mediums),
        "quality_mean": round(sum(qualities)/len(qualities), 3) if qualities else None,
        "warnings": warnings,
    }


def build_similarity_clusters(items, max_dhash_distance=5):
    # Union exact and near duplicates so a source and its crop/re-encode cannot leak across train/holdout.
    names = [it["file"] for it in items]
    parent = list(range(len(items)))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a,b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra
    by_sha = defaultdict(list)
    for i,it in enumerate(items):
        by_sha[it.get("sha256")].append(i)
    for ids in by_sha.values():
        for j in ids[1:]: union(ids[0], j)
    if len(items) <= 500:
        valid = [(i,it) for i,it in enumerate(items) if it.get("dhash")]
        for x in range(len(valid)):
            for y in range(x+1,len(valid)):
                if near_duplicate(valid[x][1], valid[y][1], max_dhash_distance=max_dhash_distance):
                    union(valid[x][0], valid[y][0])
    groups=defaultdict(list)
    for i,n in enumerate(names): groups[find(i)].append(n)
    return [sorted(v) for _,v in sorted(groups.items(), key=lambda kv: min(kv[1]))]


def make_split(dataset: Path, out: Path, holdout_fraction=0.2):
    report = audit_dataset(dataset)
    clusters = build_similarity_clusters(report["items"])
    n = report["image_count"]
    if n < 8:
        raise SystemExit("Need at least 8 images before creating a meaningful split.")
    target = max(3, int(round(n * holdout_fraction))) if n >= 15 else max(2, int(round(n * holdout_fraction)))
    target = min(target, max(2, n - 6))
    # Deterministic: select spread-out clusters, largest first only as a tie-breaker.
    clusters_sorted = sorted(clusters, key=lambda g: (hashlib.sha1("|".join(g).encode()).hexdigest(), -len(g)))
    holdout=[]; train=[]
    for g in clusters_sorted:
        if len(holdout) < target and len(holdout) + len(g) <= target + 1:
            holdout.extend(g)
        else:
            train.extend(g)
    if len(holdout) < 2:
        g = clusters_sorted[0]
        holdout.extend(g)
        train=[x for x in train if x not in g]
    out.mkdir(parents=True, exist_ok=True)
    (out/"train.txt").write_text("\n".join(sorted(train))+"\n", encoding="utf-8")
    (out/"holdout.txt").write_text("\n".join(sorted(holdout))+"\n", encoding="utf-8")
    summary={"images":n,"clusters":len(clusters),"train":len(train),"holdout":len(holdout),"holdout_fraction":round(len(holdout)/n,4),"rule":"exact/near-duplicate clusters never cross the split"}
    write_json(out/"split_summary.json", summary)
    return summary


def audit_dataset(dataset: Path, curation: Path | None = None):
    files = sorted([p for p in dataset.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS])
    if not files:
        raise SystemExit(f"No supported images found in {dataset}")

    exact = defaultdict(list)
    perceptual = []
    items = []
    ratios = Counter()
    small = 0
    captions = 0

    for p in files:
        rel = str(p.relative_to(dataset))
        s = sha256_file(p)
        exact[s].append(rel)
        width = height = None
        mode = None
        if Image is not None:
            try:
                with Image.open(p) as im:
                    width, height, mode = im.width, im.height, im.mode
            except Exception:
                pass
        if width and height:
            ratios[ratio_bucket(width, height)] += 1
            if min(width, height) < 768:
                small += 1
        cap = p.with_suffix(".txt")
        has_caption = cap.exists() and bool(cap.read_text(encoding="utf-8", errors="ignore").strip())
        captions += int(has_caption)
        d = dhash(p)
        cs = color_signature(p)
        item = {
            "file": rel,
            "width": width,
            "height": height,
            "mode": mode,
            "sha256": s,
            "dhash": d,
            "color_signature": cs,
            "has_caption": has_caption,
        }
        items.append(item)
        if d:
            perceptual.append(item)

    exact_dupes = [v for v in exact.values() if len(v) > 1]
    near_pairs = []
    # O(n^2) is intentional but capped to keep audits cheap.
    if len(perceptual) <= 500:
        for i in range(len(perceptual)):
            for j in range(i + 1, len(perceptual)):
                if near_duplicate(perceptual[i], perceptual[j]):
                    near_pairs.append({
                        "a": perceptual[i]["file"],
                        "b": perceptual[j]["file"],
                        "dhash_distance": hamming_hex(perceptual[i]["dhash"], perceptual[j]["dhash"]),
                        "color_rms": round(color_rms(perceptual[i].get("color_signature"), perceptual[j].get("color_signature")), 3)
                    })

    n = len(files)
    warnings = []
    hard_fails = []
    if n < 8:
        hard_fails.append("Fewer than 8 usable images: style evidence is too sparse for the default workflow.")
    elif n < 15:
        warnings.append("Fewer than 15 images: pilot training is possible but overfitting risk is high.")
    if sum(len(g)-1 for g in exact_dupes) / max(n, 1) > 0.10:
        hard_fails.append("More than 10% of the dataset is exact-duplicate contamination.")
    elif exact_dupes:
        warnings.append("Exact duplicates found; remove all but one copy before training.")
    if near_pairs:
        warnings.append("Near-duplicate pairs found; keep them out of train/holdout cross-splits and review for redundancy.")
    if small / n > 0.40:
        warnings.append("More than 40% of images have a short edge below 768 px; reproduction/scan quality may limit a 1024px training target.")
    if captions / n < 0.95:
        warnings.append("Some images are missing captions. Caption completeness below 95%.")

    cur = curation_summary(read_curation(curation)) if curation else None
    if cur:
        warnings.extend(cur["warnings"])

    return {
        "dataset": str(dataset),
        "image_count": n,
        "caption_count": captions,
        "caption_coverage": round(captions / n, 4),
        "aspect_buckets": dict(ratios),
        "small_image_count_short_edge_lt_768": small,
        "exact_duplicate_groups": exact_dupes,
        "near_duplicate_pairs": near_pairs[:200],
        "near_duplicate_scan_skipped": len(perceptual) > 500,
        "warnings": warnings,
        "hard_fails": hard_fails,
        "curation": cur,
        "items": items,
    }


def choose_plan(n: int, project: dict):
    family = project.get("base_model_family", "flux").lower()
    vram = int(project.get("vram_gb", 24))
    resolution = int(project.get("resolution", 1024))

    if n < 15:
        rank = 16
        step_low, step_high = 700, 1400
        save_every = 150
    elif n <= 35:
        rank = 24 if family in {"flux", "flux2", "qwen", "qwen-image"} else 32
        step_low, step_high = 1000, 2200
        save_every = 200
    elif n <= 80:
        rank = 32
        step_low, step_high = 1400, 3000
        save_every = 250
    else:
        rank = 32
        step_low, step_high = 1800, 3600
        save_every = 300

    # Lower-memory default: reduce rank before sacrificing the validation loop.
    if vram <= 12:
        rank = min(rank, 16)
    elif vram <= 16:
        rank = min(rank, 24)

    lr = 1e-4
    if family in {"sdxl", "sd1.5", "sd15", "stable-diffusion-xl"}:
        lr = 1e-4
    elif family in {"flux", "flux1", "flux2", "qwen", "qwen-image", "z-image"}:
        lr = 1e-4

    return {
        "project_name": project.get("project_name", "style-study"),
        "dataset_images": n,
        "target": project.get("target", "style"),
        "base_model_family": family,
        "base_model": project.get("base_model", ""),
        "resolution": resolution,
        "vram_gb": vram,
        "trigger": project.get("trigger", "style_token"),
        "training": {
            "lora_rank_start": rank,
            "lora_alpha_start": rank,
            "learning_rate_start": lr,
            "train_text_encoder": False,
            "batch_size_start": 1 if vram <= 24 else 2,
            "gradient_checkpointing": True,
            "step_window": [step_low, step_high],
            "save_every_steps": save_every,
            "checkpoint_selection": "fixed validation matrix; choose earliest checkpoint that passes style + generalization gates",
            "do_not_optimize_for": "lowest train loss or nearest resemblance to a single training image"
        },
        "caption_policy": {
            "caption": ["content", "action", "environment", "composition", "viewpoint", "factual lighting"],
            "usually_leave_for_trigger": ["brushwork", "edge behavior", "palette relationships", "surface treatment", "shape simplification"],
            "exclude": ["signature", "watermark", "frame", "gallery wall", "scan artifact", "quality hype"]
        },
        "validation": {
            "fixed_seed": int(project.get("seed", 42)),
            "required_tests": [
                "unseen subject",
                "unseen environment",
                "new composition",
                "alternate framing",
                "two LoRA strengths",
                "structure-control off/on"
            ],
            "strength_sweep": [0.55, 0.75, 0.95]
        },
        "structure_channel": {
            "exact_pose": "pose ControlNet / compatible pose condition",
            "major_edges": "Canny or line-art ControlNet / compatible structural conditioner",
            "perspective_depth": "depth ControlNet / compatible depth condition",
            "broad_reference": "IP-Adapter or model-family-compatible reference-image conditioner"
        },
        "notes": [
            "This plan is a pilot range, not a claim of globally optimal hyperparameters.",
            "Use the upstream preset/example for your exact trainer commit and model family.",
            "If checkpoint quality improves on references but worsens on unseen subjects/layouts, move earlier: that is overfitting."
        ]
    }


def emit_simpletuner(project, plan, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    family = plan["base_model_family"]
    model_family = "flux" if family in {"flux", "flux1"} else family
    base_model = project.get("base_model", "")
    dataset = project.get("dataset_dir", "./dataset")
    res = plan["resolution"]
    cfg = {
        "base_model_precision": "int8-quanto" if plan["vram_gb"] <= 24 and model_family not in {"sdxl", "sd15", "sd1.5"} else "no_change",
        "checkpoint_step_interval": plan["training"]["save_every_steps"],
        "controlnet": False,
        "data_backend_config": str((out / "multidatabackend.json").resolve()),
        "gradient_checkpointing": True,
        "learning_rate": plan["training"]["learning_rate_start"],
        "lora_alpha": plan["training"]["lora_alpha_start"],
        "lora_rank": plan["training"]["lora_rank_start"],
        "lora_type": "standard",
        "lr_scheduler": "constant",
        "max_train_steps": plan["training"]["step_window"][1],
        "mixed_precision": "bf16",
        "model_family": model_family,
        "model_type": "lora",
        "pretrained_model_name_or_path": base_model,
        "optimizer": "adamw_bf16",
        "output_dir": project.get("output_dir", "output/style-study"),
        "push_checkpoints_to_hub": False,
        "push_to_hub": False,
        "report_to": "none",
        "seed": int(project.get("seed", 42)),
        "train_batch_size": plan["training"]["batch_size_start"],
        "use_ema": False,
        "validation_prompt": f"{project.get('trigger','style_token')}, an old lighthouse above a stormy sea, wide shot, low horizon",
        "validation_resolution": f"{res}x{res}",
        "validation_seed": int(project.get("seed", 42)),
        "validation_steps": plan["training"]["save_every_steps"]
    }
    data = [
        {
            "id": project.get("project_name", "style-study") + "-images",
            "type": "local",
            "dataset_type": "image",
            "instance_data_dir": dataset,
            "caption_strategy": "textfile",
            "resolution": res,
            "resolution_type": "pixel_area",
            "crop": False,
            "metadata_backend": "discovery",
            "cache_dir_vae": f"cache/vae/{project.get('project_name','style-study')}"
        },
        {
            "id": project.get("project_name", "style-study") + "-text-embeds",
            "type": "local",
            "dataset_type": "text_embeds",
            "default": True,
            "cache_dir": f"cache/text/{project.get('project_name','style-study')}"
        }
    ]
    write_json(out / "config.json", cfg)
    write_json(out / "multidatabackend.json", data)
    (out / "CHECK_BEFORE_RUN.md").write_text(
        "# SimpleTuner check before run\n\n"
        "This is a current starter generated from the Forge plan, not a replacement for the upstream per-model example.\n\n"
        "1. Open the upstream example for your exact `model_family` / model flavour.\n"
        "2. Merge the Forge values (rank, alpha, LR, dataset path, checkpoint interval) into that example.\n"
        "3. Confirm model-family-specific fields such as flow schedule, flavour, quantization and validation settings.\n"
        "4. Run a short smoke test first; confirm finite loss, validation image output and LoRA checkpoint creation.\n"
        "5. Only then run the full step window.\n", encoding="utf-8")


def emit_aitoolkit(project, plan, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    trigger = project.get("trigger", "style_token")
    ds = project.get("dataset_dir", "./dataset").replace("\\", "\\\\")
    name = project.get("project_name", "style-study")
    model = project.get("base_model", "black-forest-labs/FLUX.1-dev")
    rank = plan["training"]["lora_rank_start"]
    steps = plan["training"]["step_window"][1]
    save_every = plan["training"]["save_every_steps"]
    lr = plan["training"]["learning_rate_start"]
    res = plan["resolution"]
    yaml = f'''job: extension
config:
  name: "{name}"
  process:
    - type: "sd_trainer"
      training_folder: "output"
      device: cuda:0
      trigger_word: "{trigger}"
      network:
        type: "lora"
        linear: {rank}
        linear_alpha: {rank}
      save:
        dtype: float16
        save_every: {save_every}
        max_step_saves_to_keep: 8
        push_to_hub: false
      datasets:
        - folder_path: "{ds}"
          caption_ext: "txt"
          caption_dropout_rate: 0.05
          shuffle_tokens: false
          cache_latents_to_disk: true
          resolution: [512, 768, {res}]
      train:
        batch_size: {plan['training']['batch_size_start']}
        steps: {steps}
        gradient_accumulation_steps: 1
        train_unet: true
        train_text_encoder: false
        gradient_checkpointing: true
        noise_scheduler: "flowmatch"
        optimizer: "adamw8bit"
        lr: {lr}
        dtype: bf16
      model:
        name_or_path: "{model}"
        is_flux: true
        quantize: true
      sample:
        sampler: "flowmatch"
        sample_every: {save_every}
        width: {res}
        height: {res}
        prompts:
          - "{trigger}, an old lighthouse above a stormy sea, wide shot, low horizon"
          - "{trigger}, a red city bus at dawn on an empty wet street, three-quarter view"
          - "{trigger}, a single seated figure in the far lower-left corner, large empty wall"
        neg: ""
        seed: {int(project.get('seed',42))}
        walk_seed: false
        guidance_scale: 4
        sample_steps: 20
'''
    (out / "train.yaml").write_text(yaml, encoding="utf-8")
    (out / "CHECK_BEFORE_RUN.md").write_text(
        "# AI Toolkit check before run\n\n"
        "This emitter assumes a FLUX-like job because that is AI Toolkit's most common style-LoRA route.\n"
        "Compare `train.yaml` with the upstream example for the exact model you installed.\n"
        "If you are training FLUX Schnell/Kontext/FLUX.2 or another architecture, replace model-specific scheduler, sampler, assistant adapter, resolution and quantization fields with the upstream example before launch.\n",
        encoding="utf-8")


def emit_kohya(project, plan, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    ds = project.get("dataset_dir", "./dataset")
    model = project.get("base_model", "/path/to/model.safetensors")
    rank = plan["training"]["lora_rank_start"]
    alpha = plan["training"]["lora_alpha_start"]
    steps = plan["training"]["step_window"][1]
    save_every = plan["training"]["save_every_steps"]
    res = plan["resolution"]
    script = f'''#!/usr/bin/env bash
set -euo pipefail
# Starter only. Use the model-family-specific sd-scripts entry point and flags from your installed commit.
accelerate launch train_network.py \\
  --pretrained_model_name_or_path="{model}" \\
  --train_data_dir="{ds}" \\
  --output_dir="{project.get('output_dir','output/style-study')}" \\
  --output_name="{project.get('project_name','style-study')}" \\
  --network_module=networks.lora \\
  --network_dim={rank} \\
  --network_alpha={alpha} \\
  --resolution={res},{res} \\
  --train_batch_size={plan['training']['batch_size_start']} \\
  --learning_rate={plan['training']['learning_rate_start']} \\
  --max_train_steps={steps} \\
  --save_every_n_steps={save_every} \\
  --mixed_precision=bf16 \\
  --save_precision=fp16 \\
  --gradient_checkpointing \\
  --cache_latents
'''
    (out / "train_starter.sh").write_text(script, encoding="utf-8")
    (out / "CHECK_BEFORE_RUN.md").write_text(
        "# kohya / sd-scripts check before run\n\n"
        "Do not execute this starter blindly across model families. `train_network.py` and its flags are well-established for SD-style training, but SDXL/SD3/FLUX/newer families may use different entry points or required flags in your installed sd-scripts commit.\n\n"
        "Use the upstream documentation for your exact model, then carry over: dataset, rank, alpha, LR, checkpoint interval, caption strategy and validation policy from this Forge plan.\n",
        encoding="utf-8")


def emit_onetrainer(project, plan, out: Path):
    out.mkdir(parents=True, exist_ok=True)
    preset = {
        "backup_after": 10,
        "base_model_name": project.get("base_model", ""),
        "batch_size": plan["training"]["batch_size_start"],
        "layer_filter_preset": "attn-mlp",
        "learning_rate": plan["training"]["learning_rate_start"],
        "output_model_destination": f"models/{project.get('project_name','style-study')}.safetensors",
        "output_model_format": "KOHYA_LORA",
        "resolution": str(plan["resolution"]),
        "training_method": "LORA"
    }
    write_json(out / "forge_preset_patch.json", preset)
    (out / "CHECK_BEFORE_RUN.md").write_text(
        "# OneTrainer check before run\n\n"
        "OneTrainer presets are model-family specific. This file is a Forge patch, not a complete universal OneTrainer training config.\n\n"
        "Recommended procedure:\n"
        "1. Launch OneTrainer and select the upstream LoRA preset for the exact base model family.\n"
        "2. Set the dataset as a Concept; use the image directory from project.json and text-file captions.\n"
        "3. Apply the values from forge_preset_patch.json (batch, LR, resolution, layer filter, output).\n"
        "4. Keep text encoder training off for the first pilot.\n"
        "5. Configure sampling/backup checkpoints so the fixed validation matrix can be compared throughout the run.\n"
        "6. If masked training is used, use it only for a specific reason; whole-image painterly style usually should not be masked to the subject.\n",
        encoding="utf-8")


def emit(trainer, project, plan, out):
    trainer = trainer.lower()
    out = Path(out)
    if trainer == "simpletuner":
        emit_simpletuner(project, plan, out)
    elif trainer == "aitoolkit":
        emit_aitoolkit(project, plan, out)
    elif trainer == "kohya":
        emit_kohya(project, plan, out)
    elif trainer == "onetrainer":
        emit_onetrainer(project, plan, out)
    else:
        raise SystemExit("trainer must be one of: simpletuner, aitoolkit, kohya, onetrainer")


def main():
    ap = argparse.ArgumentParser(description="Style + Composition LoRA Forge")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("curate", help="Create a manual curation CSV for subject/composition/period/medium labels")
    c.add_argument("--dataset", required=True)
    c.add_argument("--out", required=True)

    a = sub.add_parser("audit", help="Audit a training image directory")
    a.add_argument("--dataset", required=True)
    a.add_argument("--out", required=True)
    a.add_argument("--curation", required=False)

    sp = sub.add_parser("split", help="Create train/holdout lists while keeping duplicate clusters together")
    sp.add_argument("--dataset", required=True)
    sp.add_argument("--out", required=True)
    sp.add_argument("--holdout-fraction", type=float, default=0.2)

    p = sub.add_parser("plan", help="Generate an adaptive pilot training plan")
    p.add_argument("--dataset", required=True)
    p.add_argument("--project", required=True)
    p.add_argument("--out", required=True)

    e = sub.add_parser("emit", help="Emit a trainer starter from a Forge plan")
    e.add_argument("--trainer", required=True)
    e.add_argument("--project", required=True)
    e.add_argument("--plan", required=True)
    e.add_argument("--out", required=True)

    args = ap.parse_args()

    if args.cmd == "curate":
        count = write_curation_sheet(Path(args.dataset), Path(args.out))
        print(f"wrote curation sheet for {count} images to {args.out}")
    elif args.cmd == "audit":
        report = audit_dataset(Path(args.dataset), Path(args.curation) if args.curation else None)
        write_json(args.out, report)
        print(json.dumps({"image_count": report["image_count"], "warnings": report["warnings"], "hard_fails": report["hard_fails"]}, ensure_ascii=False, indent=2))
    elif args.cmd == "split":
        summary = make_split(Path(args.dataset), Path(args.out), args.holdout_fraction)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    elif args.cmd == "plan":
        audit = audit_dataset(Path(args.dataset))
        if audit["hard_fails"]:
            print("WARNING: dataset has hard-fail conditions; plan will still be emitted for inspection.")
        project = read_json(args.project)
        plan = choose_plan(audit["image_count"], project)
        plan["dataset_audit_summary"] = {
            "warnings": audit["warnings"],
            "hard_fails": audit["hard_fails"],
            "caption_coverage": audit["caption_coverage"],
            "aspect_buckets": audit["aspect_buckets"]
        }
        write_json(args.out, plan)
        print(json.dumps(plan, ensure_ascii=False, indent=2))
    elif args.cmd == "emit":
        project = read_json(args.project)
        plan = read_json(args.plan)
        emit(args.trainer, project, plan, args.out)
        print(f"emitted {args.trainer} starter to {args.out}")


if __name__ == "__main__":
    main()
