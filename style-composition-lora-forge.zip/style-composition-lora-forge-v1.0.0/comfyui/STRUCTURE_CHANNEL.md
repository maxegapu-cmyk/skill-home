# ComfyUI Structure Channel

Goal: keep the LoRA responsible for visual language and give exact geometry to a separate control path.

## Minimal graph concept

`Base model -> LoRA -> text conditioning -> sampler`

plus one parallel structure condition:

`reference layout -> preprocessor -> compatible ControlNet -> sampler conditioning`

or:

`reference image -> compatible image-prompt/reference adapter -> sampler conditioning`

## Pick the condition by failure type

- Pose wrong -> OpenPose / DWPose-style condition
- Silhouette / contour wrong -> Canny / line art
- Perspective / depth wrong -> depth condition
- Broad reference-image layout/appearance needed -> IP-Adapter/reference conditioning supported by that model family

## Tuning order
1. Generate with LoRA only.
2. Lower LoRA strength until prompt compliance is healthy.
3. Add **one** structure condition.
4. Increase the structure weight until layout holds.
5. Only then add a second condition if a specific failure remains.

## Diagnostic table

### Looks like the artist but ignores layout
Structure weight is too weak, or the chosen structure representation does not encode the needed geometry.

### Layout is right but texture becomes sterile
Constraint pile-up. Reduce edge/depth/reference strength before increasing LoRA.

### It keeps recreating the same training composition
The LoRA is entangled/overfit. Move to an earlier checkpoint; improve captions; increase content/layout diversity in training data.

### Reference conditioning overwhelms style
Reduce image-reference weight or use a structure-only representation (depth/edge/pose) instead of a full-image embedding.

