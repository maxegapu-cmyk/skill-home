# Pressure Cases

These cases define intended runtime behavior. A release should satisfy them conceptually and structurally.

## Case 1 — vague cinematic request
Input: “A woman on the last subway, lonely, cinematic.”
Expected: infers a visible story beat, one camera position, motivated carriage lighting, simple palette relationship, and one usable prompt. Does not return a catalog of styles.

## Case 2 — beginner asks for “professional”
Input: “Make it look professional. I don’t know lenses or lighting.”
Expected: chooses coherent defaults without interrogating the user or inventing a camera-body/lens/film-stock stack.

## Case 3 — reference conflict
Input: Reference A is the person. Reference B is only the visual style.
Expected: assigns identity/content to A and broad visual character to B. Does not import B's depicted objects or overwrite A's identity.

## Case 4 — weak reference evidence
Input: Identity reference is tiny and partially occluded.
Expected: does not pretend the identity can be reproduced exactly; either uses it cautiously or asks for a clearer image only if identity accuracy is critical.

## Case 5 — product advertising
Input: “Make a premium toy campaign image for a horizontal banner.”
Expected: prioritizes product form/material fidelity, hero scale, controlled reflections, usable negative space, crop resilience, and any text/logo region before decorative style.

## Case 6 — social thumbnail
Input: “I need a scroll-stopping thumbnail.”
Expected: chooses one visual thesis, strong hierarchy, readable hero at small size, and avoids a dense background with competing focal points.

## Case 7 — correct concept, flat light
Input: Existing output has correct subject/composition but flat lighting.
Expected: verdict first, changes light source/direction/contrast/environment response, and explicitly preserves the correct composition and subject.

## Case 8 — plastic realism
Input: Portrait looks like polished plastic.
Expected: diagnoses material/light behavior, adds plausible skin/fabric surface response, and removes generic “hyperreal/8K/masterpiece” filler instead of adding more quality words.

## Case 9 — text in image
Input: Poster must read “MIDNIGHT RUN” and contain no other text.
Expected: states the exact text, placement/hierarchy, legibility requirement, and no-other-text lock.

## Case 10 — multi-subject relationship
Input: “Two siblings argue at a kitchen table while their father silently watches from the doorway.”
Expected: describes spatial blocking, gaze/action relationships, hierarchy, and viewpoint clearly enough that the scene does not collapse into three unrelated portraits.

## Case 11 — unknown model
Input: User requests a prompt without naming a generator.
Expected: portable natural language only; no vendor syntax or invented parameter values.

## Case 12 — model-specific reference controls
Input: User specifies Firefly with a composition reference and a style reference.
Expected: text prompt handles subject/event/scene; dedicated reference roles remain separate and are not duplicated as conflicting prose.

## Case 13 — series continuity
Input: “Create eight frames of the same character across one story.”
Expected: defines constants once and limits each shot to action/staging/camera/local-light variables. Does not rewrite identity every shot in conflicting language.

## Case 14 — prompt-only instruction
Input: “Only give me the final prompt.”
Expected: returns only the prompt with no headings, rationale, or director notes.

## Case 15 — too many flashy elements
Input: User requests neon signs, giant moon, sparks, crowd, holograms, fire, reflections, and a hero character all equally prominent.
Expected: uses a salience budget, protects the hero, and demotes or removes competing elements instead of honoring all of them at equal intensity.

## Case 16 — edit drift
Input: “Only change the jacket from red to black; everything else is already right.”
Expected: produces a surgical edit instruction: change jacket color only; preserve identity, pose, crop, background, lighting, and all other details.
