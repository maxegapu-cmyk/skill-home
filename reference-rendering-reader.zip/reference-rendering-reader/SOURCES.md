# Sources and Adaptation Note

This package was informed by two public workflow references:

1. `AI Colorist` from `theneoai/awesome-skills`, used as a reference for describing broad color, saturation, tonal, highlight, shadow, and subject–environment relationships. The source is publicly marked MIT.

2. `image-to-prompt.md` from `LingyiChen-AI/image-prompts`, used as a reference for the general sequence of inspecting an image, organizing visible observations, and turning them into a reusable prompt.

The instructions in this package were newly written for single-image visual-style extraction. They focus on transferable visible treatment rather than literal reconstruction of the reference image. This revision keeps the same evidence-first scope while clarifying ambiguous cases, focal-versus-non-focal variation, material handling, and prompt compression.
