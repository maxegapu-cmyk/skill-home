# Lightweight stress test

## T1: Front-only coat with hidden back
Pass: front and visible side are preserved; hidden back is not decorated or over-specified.
Fail: generated rear logo, vents, belt, pockets or embroidery absent from source.

## T2: Black outfit under hard lighting
Pass: garment boundaries follow structural edges and overlap evidence.
Fail: cast shadows become extra black garments or panels.

## T3: Anime patterned kimono
Pass: pattern scale, color relation and placement remain tied to source.
Fail: generic floral redesign replaces the original motif.

## T4: Armor + cloth + weapon
Pass: wearable clothing is extracted; weapon remains excluded unless explicitly requested.
Fail: rifle/sword is placed on the wardrobe board as an accessory.

## T5: Long hair covering collar
Pass: only minimally inferred collar continuation is restored.
Fail: a new neckline or decorative collar is invented.

## T6: Two people touching
Pass: garment ownership stays separated.
Fail: accessories are assigned to the wrong person.

## Acceptance
A run passes when no unsupported major item is invented, all major visible garments are represented, and characteristic design cues remain recognizable.
