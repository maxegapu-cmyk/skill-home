# Wardrobe Extractor Skill v1.0.0

## 1. Purpose
Turn a reference image containing one or more people/characters into a clean garment-and-accessory extraction sheet.

Works with: photography, film stills, anime, manga, game screenshots, concept art, illustrations, historical costume art, low-resolution references, partial-body images, and mixed styles.

Primary goal: extract what is visibly supported by the source image without silently inventing missing garments, patterns, construction, or accessories.

## 2. Default behavior
When the user provides an image and asks to extract clothing/wardrobe/costume/outfit/accessories:

1. Detect each visible wearer.
2. Build a wardrobe inventory per wearer.
3. Separate apparel from body, hair, environment, weapons, handheld props, and unrelated objects.
4. Extract each supported item as an independent object.
5. Preserve silhouette, proportion, layering order, color relationship, pattern placement, trims, fasteners, wear, and material cues.
6. Arrange all extracted items on one clean presentation board.
7. Use a neutral white background by default.
8. Do not add a mannequin or model unless the user explicitly asks.

Default output aspect ratio: 16:9 landscape.

## 3. Evidence rule
Every detail belongs to one of three evidence levels:

### A — Directly visible
Clearly shown in the source. Preserve it.

### B — Strongly implied
A small hidden continuation is necessary to make a visible garment coherent, and the continuation follows the visible geometry with little ambiguity. Complete only the minimum required area.

### C — Unknown
The source does not provide enough evidence. Do not fabricate decorative motifs, back designs, hidden fasteners, unseen logos, lining, pockets, exact hem shapes, or complete rear views.

If an item is heavily hidden, present only a conservative partial reconstruction or mark the hidden region as unresolved rather than inventing a full design.

## 4. Clothing inventory
Recognize, when present:

- tops: shirt, T-shirt, blouse, sweater, hoodie, vest, tunic, bodice
- outerwear: jacket, coat, robe, cloak, cape, armor-overgarment
- lower garments: trousers, jeans, shorts, skirt, overskirt
- one-piece garments: dress, jumpsuit, uniform, gown
- legwear: tights, stockings, socks, leg wraps
- footwear: shoes, boots, sandals, heels
- headwear: hat, cap, hood, veil, crown-like wearable pieces
- neck items: tie, scarf, cravat, collar piece
- hand/arm wear: gloves, sleeves, bracers when primarily costume rather than weapon/armor equipment
- waist items: belt, sash, corset belt
- wearable accessories: jewelry, brooches, badges, pins, chains, shoulder ornaments, bags worn on body

Do not classify hair, skin, tattoos, makeup, weapons, phones, chairs, background ornaments, or free-standing props as clothing.

## 5. Layer logic
Before extracting, infer visible layer order only from visual evidence.

Example:
undershirt → shirt → vest → coat → scarf

Preserve overlap behavior. Do not merge separate garments just because their colors are similar. Do not split one continuous garment merely because shadows create false boundaries.

## 6. Extraction procedure
For each item:

### Step 1 — Boundary lock
Identify the visible garment boundary. Prioritize silhouette and overlap edges over texture.

### Step 2 — Identity lock
Record:
- garment category
- wearer
- dominant color family
- secondary colors
- visible pattern
- visible closures
- visible trims
- visible material cues
- visible damage/wear

### Step 3 — Occlusion handling
Remove the body and other garments from the extraction while reconstructing only the minimum hidden continuation needed for a readable standalone item.

Never create a fully imagined rear side from a front-only reference.

### Step 4 — Shape normalization
Present the item in a readable catalog pose. Flatten only enough to make the object legible; retain its original cut, drape, asymmetry, folds, and construction character.

### Step 5 — Detail preservation
Keep distinctive details at their original relative positions. Pattern scale and spacing must remain tied to the source garment rather than becoming generic decoration.

## 7. Style handling
The source style may be realistic or stylized. Choose one of two modes.

### Mode F — Faithful extraction (default)
Keep the source medium and design language. Anime clothing stays anime-styled; game clothing stays consistent with the game image; photo clothing stays photographic.

### Mode R — Real-world materialization
Use only when the user asks for “realistic”, “real material”, “physical garment”, “fashion exhibit”, or equivalent.

Translate the visible design into plausible physical textile and construction while preserving the original design identity. Convert painted highlights into believable fabric response, convert drawn seams into plausible seams only where the source supports them, and preserve the original pattern rather than redesigning it.

Mode R must not be used to invent missing costume design.

## 8. Output board
Default board:

- 16:9 landscape
- clean white or very light neutral background
- no person
- no body parts
- no environmental remnants
- no decorative scene
- items spaced clearly without overlap
- larger primary garments first
- smaller accessories grouped nearby
- consistent object scale where practical
- subtle soft grounding shadow allowed only to improve readability

If there are many items, use tidy rows. Do not crop any item.

## 9. Multi-person images
If multiple people are visible:

1. Assign temporary labels: Person A, Person B, Person C.
2. Never mix garments across people.
3. Preserve each person's own outfit grouping.
4. If two items are visually ambiguous between wearers, flag the ambiguity rather than guessing.

## 10. Failure prevention
Reject these common errors during self-check:

- inventing an unseen back design
- turning shadow into a black fabric panel
- changing sleeve length
- changing neckline shape
- replacing a unique pattern with a generic one
- adding zippers, buttons, laces, embroidery, pockets, jewelry, or logos not visible in the source
- merging scarf and collar
- merging dress and coat
- copying skin color into transparent fabric
- extracting a weapon as a clothing accessory
- changing asymmetry into symmetry
- beautifying or redesigning the outfit
- adding fashion-brand styling not present in the source

## 11. Automatic self-check
Before final output, verify:

1. Item count roughly matches the visibly supported wardrobe inventory.
2. No visible major garment is missing.
3. No unsupported major garment is added.
4. Distinctive colors and patterns remain recognizable.
5. Layer relationships are not accidentally fused.
6. Body parts and background fragments are removed.
7. Hidden regions are reconstructed conservatively.
8. All items fit inside the board.

If any check fails, correct it before returning the result.

## 12. User-facing shorthand
The following requests should trigger the skill automatically:

- “提取这张图的服装”
- “把衣服单独拿出来”
- “做成服饰白底图”
- “提取角色全套穿搭”
- “把服装和配饰整理成一张图”
- “把二次元衣服现实化再提取”

## 13. Compact generation instruction
Use this when a single generation/edit instruction is needed:

> Analyze the reference image and extract only the clothing and wearable accessories that are actually supported by visible evidence. Separate each garment into a clean standalone object, preserve its silhouette, cut, layering identity, colors, pattern placement, trims, closures, material cues and asymmetry, and reconstruct occluded areas only to the minimum extent strongly implied by the visible structure. Do not invent unseen decorations, logos, pockets, rear designs or extra garments. Remove the wearer, body parts, hair, weapons, handheld props and background. Arrange all extracted items clearly on one clean white 16:9 catalog board with no overlap and no cropping. Keep the source visual style unless the user explicitly requests real-world materialization.

## 14. Scope boundary
This skill extracts and presents wardrobe design. It is not a character identity extractor, pose copier, full character reconstruction system, costume redesign system, or automatic fashion design generator.
