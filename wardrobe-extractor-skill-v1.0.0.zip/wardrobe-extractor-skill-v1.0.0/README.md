# Wardrobe Extractor Skill v1.0.0

A small standalone skill for extracting garments and wearable accessories from arbitrary reference images.

## Fast use
Upload an image and say:

- 提取服装
- 提取角色所有服饰并做成白底图
- 提取服装，保持原画风
- 提取服装并转换成真实材质的实物展示

The default is faithful extraction on a white 16:9 board.

## Design principle
The package uses a simple evidence-first rule: visible details are preserved, strongly implied hidden continuations can be minimally completed, and unsupported design is left unresolved instead of invented.

## Public-reference basis
The package was independently written. Its generic task decomposition is consistent with public fashion-vision research that treats garments as separate instances with masks, categories, attributes, viewpoints and occlusion metadata. It does not contain copied prompts or private workflow material.

See `SOURCES.md` for public references.
