# Examples

## Example 1 — Photo
Input: “提取她身上的所有服装和首饰，白底。”
Expected behavior: preserve each visible garment and wearable accessory; remove the person and scene; avoid reconstructing an unseen back design.

## Example 2 — Anime
Input: “提取角色服饰，保持动画原画风。”
Expected behavior: retain cel-shaded/stylized garment rendering instead of forcing photorealistic fabric.

## Example 3 — Game screenshot to physical garment
Input: “提取这套服装，并把材质转换成现实中能存在的真实材质，顶级服装展览。”
Expected behavior: use Mode R; preserve design, color and pattern identity while translating surface response into believable textile/leather/metal where supported.

## Example 4 — Heavy occlusion
Input: “把外套完整提出来。”
Expected behavior: complete only obvious hidden continuations. Do not invent the entire rear panel, hidden graphics, pockets or closure system.

## Example 5 — Multiple people
Input: “把三个人的衣服都提取出来。”
Expected behavior: label Person A/B/C internally and keep their wardrobe groups separate.
