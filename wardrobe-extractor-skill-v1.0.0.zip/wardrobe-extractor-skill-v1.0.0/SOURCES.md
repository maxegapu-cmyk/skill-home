# Public references

These references informed only the general problem framing. No source text or implementation was copied into the skill.

1. Fashionpedia: Ontology, Segmentation, and an Attribute Localization Dataset — apparel categories, parts, attributes, and instance segmentation.
   https://arxiv.org/abs/2004.12276

2. DeepFashion2: A Versatile Benchmark for Detection, Pose Estimation, Segmentation and Re-Identification of Clothing Images — garment instances, masks, viewpoints, scale, and occlusion.
   https://arxiv.org/abs/1901.07973

3. Meta SAM 2 — general promptable visual segmentation reference.
   https://github.com/facebookresearch/sam2
